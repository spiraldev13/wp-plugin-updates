<?php
/**
 * Partial — Section « Bénéfices » (4 cartes icône + titre + description).
 *
 * Utilisée sur les 3 pages prestation (Création, Consultant SEO, Maintenance &
 * hébergement). Chaque page a son propre jeu de champs ACF avec des clés
 * distinctes mais des noms identiques (`ben_enabled`, `ben_eyebrow`, `ben_title`,
 * `ben_lede`, `ben_items` — sous-champs `icon`, `title`, `desc`).
 *
 * Le partial est agnostique : il lit les champs depuis le post courant via
 * `get_field()` / `have_rows()`. À inclure via `get_template_part()`.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!get_field('ben_enabled') || (!get_field('ben_title') && !have_rows('ben_items'))) {
    return;
}

$benEyebrow = (string) get_field('ben_eyebrow');
$benTitle   = (string) get_field('ben_title');
$benLede    = (string) get_field('ben_lede');
?>
<section class="section section--prestation section--no-pad-top" aria-labelledby="benefices-title">
    <div class="container">
        <?php if ($benEyebrow || $benTitle || $benLede): ?>
            <div class="section-head">
                <div class="section-head-left">
                    <?php if ($benEyebrow): ?>
                        <div class="section-eyebrow-wrap">
                            <span class="eyebrow"><?php echo esc_html($benEyebrow); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($benTitle): ?>
                        <h2 class="section-title" id="benefices-title"><?php echo esc_html($benTitle); ?></h2>
                    <?php endif; ?>
                </div>
                <?php if ($benLede): ?>
                    <p class="section-lede"><?php echo esc_html($benLede); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (have_rows('ben_items')): ?>
            <div class="benefices-grid">
                <?php while (have_rows('ben_items')): the_row();
                    $bIcon  = (string) get_sub_field('icon');
                    $bTitle = (string) get_sub_field('title');
                    $bDesc  = (string) get_sub_field('desc');
                    if (!$bTitle) continue;
                    ?>
                    <article class="benefice-card">
                        <?php if ($bIcon): ?>
                            <span class="benefice-icon"><?php evolutionr_icon($bIcon, 22); ?></span>
                        <?php endif; ?>
                        <h3 class="benefice-title"><?php echo esc_html($bTitle); ?></h3>
                        <?php if ($bDesc): ?><p class="benefice-desc"><?php echo esc_html($bDesc); ?></p><?php endif; ?>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
