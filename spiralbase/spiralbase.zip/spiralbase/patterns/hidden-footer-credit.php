<?php
/**
 * Title: Crédit du pied de page
 * Slug: spiralbase/hidden-footer-credit
 * Inserter: no
 *
 * Les templates HTML de blocs ne passent pas par gettext : toute chaîne UI
 * d'un template vit dans un pattern PHP comme celui-ci (AC 3 / NFR5).
 */
?>
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><?php echo esc_html__('Propulsé par spiralbase', 'spiralbase'); ?></p>
<!-- /wp:paragraph -->
