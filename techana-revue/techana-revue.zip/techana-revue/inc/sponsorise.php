<?php
/**
 * Variante commerciale de l'article — spec articles-sponsorises.
 *
 * Trois éléments, jamais facultatifs quand _techana_sponsorise est vraie :
 * le bandeau au-dessus de tout le contenu, le pavé de signature (rendu par
 * techana/byline), les encarts annonceur. Les liens commerciaux portent
 * rel="sponsored", y compris ceux du corps de l'article.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'techanaRevueRegisterBlocsSponsor' );
add_filter( 'the_content', 'techanaRevueRelSponsorise', 99 );

function techanaRevueRegisterBlocsSponsor() {
    register_block_type( 'techana/sponsor-bar', array(
        'api_version'     => 3,
        'render_callback' => 'techanaRevueBlocSponsorBar',
        'uses_context'    => array( 'postId' ),
    ) );
    register_block_type( 'techana/annonceur', array(
        'api_version'     => 3,
        'render_callback' => 'techanaRevueBlocAnnonceur',
        'uses_context'    => array( 'postId' ),
        'attributes'      => array(
            'position' => array( 'type' => 'string', 'default' => 'haut' ),
        ),
    ) );
}

/** Vrai si l'article du contexte est sponsorisé. */
function techanaRevueEstSponsorise( $block ): bool {
    $postId = (int) ( $block->context['postId'] ?? get_the_ID() );
    return $postId && (bool) get_post_meta( $postId, '_techana_sponsorise', true );
}

/**
 * Bandeau pleine largeur au-dessus de tout le contenu éditorial.
 */
function techanaRevueBlocSponsorBar( array $attrs, string $inner, WP_Block $block ): string {
    if ( ! techanaRevueEstSponsorise( $block ) ) {
        return '';
    }
    return '<div class="sponsor-bar"><div class="container in">'
        . '<span class="tag">Contenu sponsorisé</span>'
        . '<span>Cet article a été financé par un annonceur. Il n\'engage pas la rédaction de TechAna.</span>'
        . '</div></div>';
}

/**
 * Encart annonceur — sous le chapô (haut) et en pied d'article (pied),
 * alimenté par les métas _techana_annonceur_*.
 */
function techanaRevueBlocAnnonceur( array $attrs, string $inner, WP_Block $block ): string {
    if ( ! techanaRevueEstSponsorise( $block ) ) {
        return '';
    }
    $postId = (int) ( $block->context['postId'] ?? get_the_ID() );
    $nom    = get_post_meta( $postId, '_techana_annonceur_nom', true );
    $texte  = get_post_meta( $postId, '_techana_annonceur_texte', true );
    $url    = get_post_meta( $postId, '_techana_annonceur_url', true );
    if ( ! $nom ) {
        return '';
    }
    $style = 'pied' === ( $attrs['position'] ?? 'haut' ) ? ' style="margin:var(--g-xl) 0 0"' : '';
    $lien  = '';
    if ( $url ) {
        $hote = wp_parse_url( $url, PHP_URL_HOST );
        $lien = '<a href="' . esc_url( $url ) . '" rel="sponsored">'
            . esc_html( $hote ? $hote : $url ) . ' →</a>';
    }
    return '<div class="advertiser"' . $style . '>'
        . '<span class="k">À propos de l\'annonceur</span>'
        . '<h2>' . esc_html( $nom ) . '</h2>'
        . ( $texte ? '<p>' . esc_html( $texte ) . '</p>' : '' )
        . $lien
        . '</div>';
}

/**
 * Les liens du corps d'un article sponsorisé portent rel="sponsored"
 * — la déclaration machine suit la déclaration lecteur, sans exception.
 */
function techanaRevueRelSponsorise( string $html ): string {
    if ( ! is_singular( 'post' ) || ! get_post_meta( get_the_ID(), '_techana_sponsorise', true ) ) {
        return $html;
    }
    return preg_replace_callback(
        '|<a (.+?)>|i',
        static fn( array $m ) => wp_rel_callback( $m, 'sponsored' ),
        $html
    );
}
