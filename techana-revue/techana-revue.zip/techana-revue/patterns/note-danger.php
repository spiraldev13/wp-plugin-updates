<?php
/**
 * Title: Encadré Danger
 * Slug: techana-revue/note-danger
 * Categories: techana
 * Keywords: note, danger, encadré
 * Viewport Width: 720
 * Description: Encadré de danger du corps d'article (design article) — filet
 * rouge, titre en capitales, un paragraphe. Réservé aux actions irréversibles.
 */
?>
<!-- wp:group {"className":"note danger"} -->
<div class="wp-block-group note danger"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Danger</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>L'action irréversible ou l'exposition de sécurité à ne jamais commettre — perte de données, service ouvert sur Internet.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
