<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!evolutionr_acf_is_active() || !function_exists('acf_add_options_page')) {
    return;
}

add_action('acf/init', function (): void {
    acf_add_options_page([
        'page_title' => __('Réglages globaux Evolution\'R', 'evolutionr'),
        'menu_title' => __('Réglages globaux', 'evolutionr'),
        'menu_slug'  => 'evolutionr-options',
        'capability' => 'manage_options',
        'position'   => 60,
        'icon_url'   => 'dashicons-admin-customizer',
        'redirect'   => false,
    ]);

    // Source de vérité unique des prix du site (offres, options, taux).
    // Lue par les pages et le configurateur via evolutionr_get_pricing().
    acf_add_options_sub_page([
        'page_title'  => __('Tarifs Evolution\'R', 'evolutionr'),
        'menu_title'  => __('Tarifs', 'evolutionr'),
        'menu_slug'   => 'evolutionr-tarifs',
        'parent_slug' => 'evolutionr-options',
        'capability'  => 'manage_options',
    ]);
});
