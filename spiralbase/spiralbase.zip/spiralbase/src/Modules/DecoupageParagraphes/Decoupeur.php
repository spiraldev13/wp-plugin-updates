<?php

declare(strict_types=1);

namespace SpiralBase\Modules\DecoupageParagraphes;

/**
 * Moteur de découpage des paragraphes longs — porté du Text Enhancer
 * d'ultimate-shanks (`src/text-enhancer/processor.php`, lu intégralement)
 * et DURCI en revue 2.6 (chaque durcissement prouvé par exécution).
 *
 * Écarts assumés vs legacy :
 *  - seuil en CARACTÈRES (`mb_strlen`) et non en octets (`strlen`) — sur du
 *    français accenté, ±3 % de différence au seuil ;
 *  - pas de `<br>` injectés, pas de debug, pas d'ignore_links/classes,
 *    `apply_seo_corrections` hors périmètre (autre responsabilité) ;
 *  - abréviations exigent une frontière de mot (« complex. » n'est plus
 *    pris pour « ex. ») ; `n°/N°` retirés (code mort dans le legacy même) ;
 *  - shortcodes détectés insensiblement à la casse et sur forme plausible
 *    (biais conservateur : `[sic]` fait sauter le paragraphe, `[1]` non) ;
 *  - un regroupement qui DÉSÉQUILIBRERAIT les balises inline rend le
 *    paragraphe intact ; l'`id` ne reste que sur le premier morceau.
 *
 * Limite héritée documentée : une ponctuation fermante après le point
 * (« Stop ! » ») fusionne les phrases — direction sûre (moins de coupes).
 * Classe PURE : aucune fonction WordPress. Un échec PCRE JETTE — le
 * walker attrape et signale (derniersEchecs, 1.4).
 */
final class Decoupeur
{
    private const ELEMENTS_COMPLEXES = [
        '<figure', '<iframe', '<table', '<pre', '<code', '<form', '<script', '<style',
        '<!-- wp:gallery', '<!-- wp:columns', '<!-- wp:group',
    ];

    private const ABREVIATIONS = ['M.', 'Mme.', 'Mlle.', 'Dr.', 'Pr.', 'etc.', 'vs.', 'ex.', 'cf.'];

    private const FRONTIERE_PHRASE = '/(?<=[.!?])\s+(?=[\p{Lu}0-9«])/u';

    public function __construct(
        private readonly int $longueurMin = 400,
        private readonly int $phrasesParParagraphe = 2,
    ) {
    }

    /** Découpe les `<p>` longs — le reste du contenu est intact. */
    public function decouper(string $contenu): string
    {
        if ($contenu === '') {
            return '';
        }

        /* Attributs tolérants aux guillemets : un `>` DANS un attribut ne
           tronque plus la capture (prouvé en revue). */
        $resultat = preg_replace_callback(
            '/<p\b((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>(.*?)<\/p>/is',
            fn (array $m): string => $this->traiterParagraphe($m),
            $contenu
        );

        if (!is_string($resultat)) {
            throw new \RuntimeException('découpage : échec PCRE (' . preg_last_error_msg() . ')');
        }

        return $resultat;
    }

    /** @param array{0: string, 1: string, 2: string} $m */
    private function traiterParagraphe(array $m): string
    {
        [$original, $attributs, $html] = $m;

        if (mb_strlen(trim(strip_tags($html))) < max(1, $this->longueurMin)
            || $this->contientElementComplexe($html)) {
            return $original;
        }

        $phrases = $this->phrasesAvecHtml($html);

        if (count($phrases) <= max(1, $this->phrasesParParagraphe)) {
            return $original;
        }

        return $this->regrouper($phrases, $attributs, $original);
    }

    private function contientElementComplexe(string $html): bool
    {
        foreach (self::ELEMENTS_COMPLEXES as $element) {
            if (stripos($html, $element) !== false) {
                return true;
            }
        }

        /* Forme plausible de shortcode, casse ignorée — `[1]` reste du texte. */
        return (bool) preg_match('/\[[a-z][a-z0-9_-]*[\s\]=\/]/i', $html);
    }

    /**
     * Phrases avec HTML inline intact (placeholders, technique legacy) —
     * préfixe garanti ABSENT du contenu (collision prouvée en revue).
     *
     * @return list<string>
     */
    private function phrasesAvecHtml(string $html): array
    {
        $prefixe = '___SPIRALBASE_TAG_';

        while (str_contains($html, $prefixe)) {
            $prefixe .= 'X';
        }

        $balises = [];
        $index   = 0;

        $texte = (string) preg_replace_callback('/<[^>]+>/', static function (array $m) use (&$balises, &$index, $prefixe): string {
            $placeholder           = "{$prefixe}{$index}___";
            $balises[$placeholder] = $m[0];
            $index++;

            return $placeholder;
        }, $html);

        $brutes  = preg_split(self::FRONTIERE_PHRASE, $texte, -1, PREG_SPLIT_NO_EMPTY) ?: [$texte];
        $phrases = [];
        $tampon  = '';

        foreach ($brutes as $brute) {
            $tampon .= ($tampon !== '' ? ' ' : '') . $brute;

            if (!$this->finFactice(strtr($tampon, array_fill_keys(array_keys($balises), '')))) {
                $phrases[] = trim(strtr($tampon, $balises));
                $tampon    = '';
            }
        }

        if ($tampon !== '') {
            $phrases[] = trim(strtr($tampon, $balises));
        }

        return $phrases;
    }

    /** Frontière de mot exigée : « complex. » n'est pas « ex. » (revue 2.6). */
    private function finFactice(string $texte): bool
    {
        $texte = trim($texte);

        foreach (self::ABREVIATIONS as $abreviation) {
            if (preg_match('/(?:^|\s)' . preg_quote($abreviation, '/') . '$/u', $texte) === 1) {
                return true;
            }
        }

        return (bool) preg_match('/(?:^|\s)\d+\.$/', $texte);
    }

    /** @param list<string> $phrases */
    private function regrouper(array $phrases, string $attributs, string $original): string
    {
        $morceaux = [];
        $tampon   = [];
        $taille   = max(1, $this->phrasesParParagraphe);

        foreach ($phrases as $phrase) {
            $tampon[] = $phrase;

            if (count($tampon) >= $taille) {
                $morceaux[] = implode(' ', $tampon);
                $tampon     = [];
            }
        }

        if ($tampon !== []) {
            $morceaux[] = implode(' ', $tampon);
        }

        /* Une coupe qui déséquilibre les balises inline (em/a ouvert dans
           un morceau, fermé dans un autre — prouvé en revue) produirait un
           DOM réparé n'importe comment : paragraphe intact. */
        foreach ($morceaux as $morceau) {
            if (!$this->balisesEquilibrees($morceau)) {
                return $original;
            }
        }

        $sortie = '';

        foreach ($morceaux as $i => $morceau) {
            /* L'id ne se duplique pas : premier morceau seulement. */
            $attrs   = $i === 0 ? $attributs : (string) preg_replace('/\s+id\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $attributs);
            $sortie .= '<p' . $attrs . '>' . $morceau . '</p>';
        }

        return $sortie;
    }

    private function balisesEquilibrees(string $html): bool
    {
        preg_match_all('/<([a-z0-9]+)\b[^>]*[^\/]>|<([a-z0-9]+)>/i', $html, $ouvertures);
        preg_match_all('/<\/([a-z0-9]+)>/i', $html, $fermetures);

        $ouvertes = array_count_values(array_map('strtolower', array_filter(array_merge($ouvertures[1], $ouvertures[2]))));
        $fermees  = array_count_values(array_map('strtolower', $fermetures[1]));

        /* Les vides (br, img, hr…) ne se ferment pas. */
        foreach (['br', 'img', 'hr', 'input', 'wbr', 'source', 'embed'] as $vide) {
            unset($ouvertes[$vide]);
        }

        return $ouvertes == $fermees;
    }
}
