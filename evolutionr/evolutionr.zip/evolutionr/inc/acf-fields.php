<?php
/**
 * Comportements ACF admin du thème.
 *
 * Les GROUPES de champs ACF ne sont plus déclarés en PHP : leur source de
 * vérité est le dossier `acf-json/`, chargé automatiquement par ACF (chemin
 * configuré dans `inc/acf-config.php`). Les groupes apparaissent donc dans
 * ACF → Field Groups. Pour éditer un groupe depuis l'admin : « Sync » puis
 * modifier ; ACF réécrit alors le fichier JSON correspondant (à committer).
 *
 * Ce fichier ne conserve que les ajustements d'ergonomie admin liés aux
 * champs (repli des repeaters de la page Tarifs).
 *
 * Convention de keys : `field_evor_<groupe>_<champ>` (max 36 char ASCII).
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!evolutionr_acf_is_active()) {
    return;
}

/**
 * Replie par défaut les lignes des repeaters Offres et Promotions à
 * l'ouverture de la page d'options (lisibilité : on ne voit que les noms).
 * Ciblé par les classes de champ ACF — inerte sur les autres écrans.
 */
add_action('acf/input/admin_footer', function (): void {
    ?>
    <script>
    (function ($) {
        if (typeof acf === 'undefined') return;
        acf.addAction('ready', function () {
            $('.acf-field-field_evor_tar_offres .acf-row, .acf-field-field_evor_tar_promos .acf-row')
                .not('.acf-clone')
                .addClass('-collapsed');
        });
    })(jQuery);
    </script>
    <?php
});
