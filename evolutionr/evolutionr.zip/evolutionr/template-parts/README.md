# Template-parts — carte de référence

Ce dossier contient les fragments PHP réutilisés par les gabarits principaux du
thème (essentiellement `front-page.php`). Chaque fragment correspond à une
section visuelle bien identifiée du mockup. Les noms sont numérotés selon
l'ordre vertical d'apparition sur la page d'accueil pour qu'ils restent triés
dans l'ordre de lecture.

> **Astuce repérage** : sur le site, active `WP_DEBUG=true` et connecte-toi en
> admin → un badge cyan `📍 NN-nom.php` apparaît en haut à gauche de chaque
> section. Invisible pour les visiteurs.

---

## Vue d'ensemble — ordre vertical de la page d'accueil

Conforme à SITE.MD § 3 (10 sections + Journal conditionnel) — change `lancement-site-evolutionr`.

```
┌─────────────────────────────────────────────┐
│  header.php                                 │   sticky en haut de toutes les pages
├─────────────────────────────────────────────┤
│  01-accueil-bandeau.php          ← hero     │
│  02-chiffres-cles.php       ← réassure      │
│  03-prestations.php       ← services        │
│  04-paiement-modes.php   ← paiement (NEW)   │
│  05-raisons.php            ← pillars        │
│  06-methode-etapes.php     ← method         │
│  07-apercu-tarifs.php   ← aperçu tarifs (NEW)│
│  08-realisations.php       ← works          │
│  09-journal.php            ← blog (caché si 0 article) │
│  10-questions-reponses.php ← faq            │
│  11-contact-final.php      ← final CTA      │
├─────────────────────────────────────────────┤
│  footer.php                                 │
└─────────────────────────────────────────────┘
```

---

## Tableau de correspondance

| # | Section visuelle | Fichier | Champs ACF (front-page) | Source de données |
|---|---|---|---|---|
| 01 | Bandeau d'accueil (grand titre + SVG + stats) | `sections/01-accueil-bandeau.php` | `hero_status_text`, `hero_title_lead/accent/trail`, `hero_sub`, `hero_visual_label`, `hero_meta` (repeater), `hero_stats` (repeater), `works_url` | + options : `cta_primary_*` |
| 01b | Sous-partie : SVG node graph animé | `sections/01-accueil-bandeau-visuel.php` | — | Décor fixe |
| 02 | Barre de chiffres clés | `sections/02-chiffres-cles.php` | `reassure_items` (repeater) | — |
| 03 | 2 cartes de prestations | `sections/03-prestations.php` | `services_eyebrow`, `services_title`, `services_lede` | CPT `service` (boucle) |
| 04 | 4 raisons « Pourquoi Evolution'R » | `sections/04-raisons.php` | `pillars_eyebrow`, `pillars_title`, `pillars` (repeater) | — |
| 05 | Frise des 4 étapes de méthode | `sections/05-methode-etapes.php` | `method_eyebrow`, `method_title`, `method_lede`, `method_active_index`, `method_steps` (repeater) | — |
| 06 | Grille bento de réalisations | `sections/06-realisations.php` | `works_eyebrow`, `works_title`, `works_url` | CPT `realisation` (boucle) |
| 07 | 3 derniers articles | `sections/07-journal.php` | `blog_eyebrow`, `blog_title`, `blog_archive_url` | type natif `post` (boucle) |
| 08 | Accordéon FAQ | `sections/08-questions-reponses.php` | `faq_eyebrow`, `faq_title`, `faq_lede` | CPT `faq` (boucle) |
| 09 | CTA final (contact) | `sections/09-contact-final.php` | `final_cta_eyebrow`, `final_cta_title`, `final_cta_paragraph`, `final_cta_primary_label/url`, `final_cta_secondary_label/url` | + options : `contact_email` (fallback) |

---

## Cards réutilisables

| Fichier | Inclus depuis | Pilotage |
|---|---|---|
| `cards/carte-prestation.php` | `sections/03-prestations.php` | CPT `service` (champs `service_*`) |
| `cards/carte-realisation.php` | `sections/06-realisations.php` | CPT `realisation` (champs `realisation_*`) + taxonomie `secteur` |
| `cards/ligne-journal.php` | `sections/07-journal.php` | type natif `post` |

---

## Comment éditer chaque section

Toutes les sections du bloc « front-page » se pilotent depuis **un seul écran** :
*Pages → Modifier la page d'accueil*. ACF y affiche un groupe à onglets — un
onglet par section.

| Onglet ACF | Édite la section | Astuce |
|---|---|---|
| Hero | 01 | Le titre se construit en 3 morceaux : `lead` + `accent` (mot mis en gradient) + `trail`. |
| Réassurance | 02 | 4 items chiffrés. Si tu en mets 0, la section disparaît. |
| Services | 03 | Seuls l'eyebrow / titre / lede sont ici. Les cartes elles-mêmes se créent dans **Prestations** (CPT). |
| Piliers | 04 | Repeater de 4 items avec icône sélectionnable. |
| Méthode | 05 | Repeater d'étapes + un champ « étape mise en avant » (numéro de l'étape active). |
| Réalisations | 06 | Eyebrow / titre / URL « voir tout le portfolio ». Les visuels eux-mêmes sont dans le CPT **Réalisations**. |
| Blog | 07 | Eyebrow / titre / URL archive. Les articles sont les posts natifs. |
| FAQ | 08 | Eyebrow / titre / lede. Les questions sont dans le CPT **FAQ**. |
| CTA final | 09 | 2 boutons. Si l'URL primaire est vide → mailto auto vers `contact_email` (Réglages globaux). |

### Les contenus globaux

Pour le logo, le téléphone, l'email, les réseaux sociaux, le tagline du footer :
*Réglages → Réglages globaux Evolution'R* (page d'options ACF).

### Les contenus listables (services, réalisations, FAQ)

| Item | Menu admin | Slug d'URL |
|---|---|---|
| Prestation | Prestations | `/prestations/{slug}` |
| Réalisation | Réalisations | `/realisations/{slug}` |
| Question FAQ | FAQ | non publique (uniquement en boucle home) |

Ordre d'affichage : champ « Ordre » natif WP (Page Attributes → Order).

---

## Helpers PHP disponibles

Définis dans `inc/helpers.php`, utilisables partout dans le thème.

| Fonction | Usage | Exemple |
|---|---|---|
| `evolutionr_icon($name, $size)` | Affiche une icône SVG inline. Couleur via `currentColor`. | `evolutionr_icon('arrow-right', 16);` |
| `evolutionr_social_icon($network, $size)` | Affiche une icône réseau social. | `evolutionr_social_icon('linkedin', 14);` |
| `evolutionr_header_ctas()` | Affiche les 2 CTAs récurrents (Audit gratuit + Démarrer mon projet). | `evolutionr_header_ctas();` |
| `evolutionr_section_badge(__FILE__)` | Badge debug visible si `WP_DEBUG=true` + admin. À placer juste après `<section>`. | `evolutionr_section_badge(__FILE__);` |

Icônes disponibles (`evolutionr_icon`) : `arrow-right`, `arrow-up-right`, `check`,
`plus`, `code`, `search`, `trend`, `shield`, `zap`, `compass`, `layers`, `chart`,
`globe`.

Réseaux sociaux disponibles : `linkedin`, `github`, `twitter`, `facebook`, `instagram`.

---

## Seeder de contenu d'exemple (one-shot)

À la première activation du thème, `inc/seed-content.php` insère un jeu de
contenu d'amorçage : 3 prestations, 2 réalisations, 1 question FAQ, et la page
d'accueil si elle n'existait pas. Chaque contenu reçoit aussi son trio de méta
**Rank Math** (`rank_math_title`, `rank_math_description`, `rank_math_focus_keyword`)
pré-rempli avec un copywriting aligné sur l'activité.

L'idempotence est assurée par l'option `evolutionr_seeded` : tant qu'elle est
posée, le seeder se contente de retourner sans rien faire.

**Pour relancer le seeder** (typiquement après avoir tout supprimé en dev) :

1. Supprimer l'option : depuis WP-CLI `wp option delete evolutionr_seeded`, ou
   en SQL `DELETE FROM wp_options WHERE option_name = 'evolutionr_seeded';`.
2. Désactiver le thème puis le réactiver (le hook `after_switch_theme` se
   redéclenche).
3. Vérifier les nouvelles entrées dans les CPT.

Le seeder ne crée jamais de doublon : il vérifie l'absence préalable d'un post
du même `post_type` + `post_title` exact avant insertion. Les contenus déjà
modifiés par l'admin ne sont pas écrasés.

---

## Convention de docblock

Chaque template-part commence par un docblock standardisé qui répond à 3
questions :

1. **Quoi** : à quelle section visuelle correspond ce fichier.
2. **Comment ça s'affiche** : description en 1–2 phrases du rendu.
3. **Qu'est-ce qui le pilote** : liste des champs ACF / CPT / taxonomies utilisés.

Garde ce format en cohérence quand tu modifies ou crées un nouveau fragment.
