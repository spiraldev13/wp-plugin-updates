<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Updater unifié de la flotte (AD-13) — consolidation des trois copies du
 * mécanisme manifeste GitHub (updater-theme du starter, updater plugin
 * d'ultimate-shanks, templates makedev) en UNE classe paramétrée
 * `plugin|theme`. Bugs hérités corrigés : constante de surcharge à tirets,
 * purge de transient sur la clé réellement écrite. SHA-256 obligatoire.
 *
 * Le manifeste ne pousse QUE vers le haut : un site ne peut jamais se voir
 * proposer une version antérieure à la sienne. Republier N-1 dans le
 * manifeste ne ramène donc PAS la flotte en arrière — un retour arrière se
 * fait soit en republiant le code précédent sous un numéro SUPÉRIEUR, soit
 * à la main, site par site. C'est un arbitrage explicite (Cyril,
 * 2026-07-31) : le risque d'une descente accidentelle sur toute une flotte
 * pèse plus lourd que le confort d'un rollback automatique.
 *
 * MODÈLE DE CONFIANCE — limite connue et assumée : l'empreinte SHA-256 et
 * l'URL du paquet viennent du MÊME manifeste. Le hash protège donc le
 * transit (altération CDN/proxy), pas une compromission du dépôt de
 * distribution, qui resterait un point de défaillance unique pour toute la
 * flotte. Les gardes en place limitent la surface : hôtes de téléchargement
 * épinglés, HTTPS obligatoire, versions non-semver refusées. Une signature
 * détachée (Ed25519, clé publique embarquée) est la parade complète — voir
 * deferred-work.md : elle engage aussi la chaîne de release makedev.
 */
final class Updater
{
    public const TYPE_THEME = 'theme';
    public const TYPE_PLUGIN = 'plugin';

    /** Hôtes autorisés à servir un paquet — un manifeste ne peut pas pointer ailleurs. */
    private const HOTES_PAQUET = [
        'github.com',
        'raw.githubusercontent.com',
        'objects.githubusercontent.com',
        'codeload.github.com',
    ];

    private const DUREE_CACHE_ECHEC = 300;

    /** @var callable(string, array): (array|\WP_Error) */
    private $fetcher;

    /** @var callable(string): (string|\WP_Error) */
    private $telechargeur;

    /**
     * @param string $identifiantWp thème : slug du répertoire ; plugin :
     *                              basename `dossier/fichier.php` (clé
     *                              attendue par le transient update_plugins)
     */
    public function __construct(
        private readonly string $type,
        private readonly string $slug,
        private readonly string $versionInstallee,
        private readonly string $urlManifeste,
        ?callable $fetcher = null,
        ?callable $telechargeur = null,
        private readonly string $identifiantWp = '',
    ) {
        if (!in_array($type, [self::TYPE_THEME, self::TYPE_PLUGIN], true)) {
            throw new UpdaterException(sprintf('Type d\'updater inconnu : « %s » (theme|plugin).', $type));
        }

        if (trim($slug) === '') {
            throw new UpdaterException('Slug d\'updater vide — un updater sans slug intercepterait tous les paquets.');
        }

        $this->fetcher      = $fetcher ?? static fn (string $url, array $args): array|\WP_Error => wp_remote_get($url, $args);
        $this->telechargeur = $telechargeur ?? static fn (string $url): string|\WP_Error => download_url($url);
    }

    /**
     * URL du manifeste, surchargeable par constante. Bug hérité corrigé :
     * les tirets du slug deviennent des underscores (une constante PHP ne
     * peut pas en contenir — l'ancienne variante plugin produisait un nom
     * irrésoluble). Le nom est préfixé `SPIRALBASE_` : une constante
     * générique (`SEO_UPDATE_MANIFEST_URL`) pourrait être définie par du
     * code tiers et détourner le manifeste.
     *
     * Manifeste lu depuis raw.githubusercontent.com plutôt que l'API
     * GitHub : api.github.com est limitée à 60 requêtes/h par IP non
     * authentifiée — sur un mutualisé (IP partagée), quota vite épuisé →
     * HTTP 403 et AUCUNE mise à jour détectée. raw sert le fichier brut
     * sans cette limite.
     */
    public static function urlManifestePourSlug(
        string $slug,
        string $utilisateur = 'spiraldev13',
        string $depot = 'wp-plugin-updates',
    ): string {
        $constante = 'SPIRALBASE_' . strtoupper(str_replace('-', '_', $slug)) . '_UPDATE_MANIFEST_URL';

        if (defined($constante) && constant($constante)) {
            $surcharge = (string) constant($constante);

            if (str_starts_with($surcharge, 'https://')) {
                return esc_url_raw($surcharge);
            }

            /* Une surcharge non-HTTPS est une erreur de configuration, pas un défaut à ignorer. */
            do_action('spiralbase_updater_config', sprintf('surcharge de manifeste ignorée (HTTPS requis) : %s', $surcharge));
            error_log(sprintf('[spiralbase] updater : surcharge %s ignorée, HTTPS requis.', $constante));
        }

        return esc_url_raw(sprintf(
            'https://raw.githubusercontent.com/%s/%s/main/%s/update.json',
            $utilisateur,
            $depot,
            $slug
        ));
    }

    /** Accroche les trois hooks WordPress du cycle de mise à jour. */
    public function enregistrer(): void
    {
        $transient = $this->type === self::TYPE_THEME ? 'update_themes' : 'update_plugins';

        add_filter('pre_set_site_transient_' . $transient, [$this, 'injecterMiseAJour']);
        add_action('delete_site_transient_' . $transient, [$this, 'purgerCache']);
        add_filter('upgrader_pre_download', [$this, 'verifierIntegrite'], 10, 4);
    }

    public function injecterMiseAJour(mixed $transient): mixed
    {
        if (!is_object($transient) || $this->versionInstallee === '') {
            return $transient;
        }

        $manifeste = $this->manifeste();

        if ($manifeste === null) {
            return $transient;
        }

        /*
         * STRICTEMENT vers le haut. Une mise à jour ne fait jamais reculer un
         * site : `<`, jamais `!=`. Un site en avance sur le manifeste ne se
         * voit rien proposer, et un retour arrière est une opération MANUELLE
         * (décision Cyril, 2026-07-31, après qu'un site en 1.29.2 s'est vu
         * proposer « la version 1.11.4 » sur un dossier de thème qui était la
         * copie de travail git).
         *
         * C'est aussi le retour à la convention makedev, dont la story 1.6
         * avait dévié en croyant gagner le rollback :
         * `.make/types/wordpress-theme/templates/updater-theme.php:218` et
         * `.make/types/wordpress-plugin/templates/updater.php:363` comparent
         * tous deux avec `<`.
         */
        if (!version_compare($this->versionInstallee, $manifeste['version'], '<')) {
            return $transient;
        }

        if (!isset($transient->response) || !is_array($transient->response)) {
            $transient->response = [];
        }

        /*
         * L'empreinte voyage AVEC la proposition : au moment du clic, la
         * vérification d'intégrité compare le paquet à l'empreinte de LA
         * version proposée, même si le manifeste a été republié depuis.
         */
        $commun = [
            'new_version'  => $manifeste['version'],
            'package'      => $manifeste['download_url'],
            'url'          => $manifeste['details_url'],
            'requires'     => $manifeste['requires'],
            'requires_php' => $manifeste['requires_php'],
        ];

        if ($this->type === self::TYPE_THEME) {
            $transient->response[$this->slug] = ['theme' => $this->slug] + $commun;
        } else {
            /* update_plugins est indexé par basename `dossier/fichier.php`. */
            $cle = $this->identifiantWp !== '' ? $this->identifiantWp : $this->slug;

            $transient->response[$cle] = (object) (['slug' => $this->slug, 'plugin' => $cle] + $commun);
        }

        $this->memoriserEmpreinte($manifeste['download_url'], $manifeste['sha256']);

        return $transient;
    }

    /**
     * Bug hérité corrigé : LA clé écrite par le cache est LA clé purgée.
     * Les empreintes mémorisées survivent volontairement — c'est leur
     * raison d'être : rester vérifiables même après republication du
     * manifeste.
     */
    public function purgerCache(): void
    {
        delete_site_transient($this->cleCache());
        delete_site_transient($this->cleCache() . '_echec');
    }

    /**
     * Vérification d'intégrité SHA-256 (upgrader_pre_download) — STRICTE :
     * un paquet sans empreinte connue refuse le téléchargement. La spine
     * exige la vérification, pas « si disponible » ; makedev fournit le
     * hash. Le ciblage passe par `$hookExtra` quand WordPress le fournit
     * (fiable), avec repli sur l'URL.
     */
    public function verifierIntegrite(mixed $reply, mixed $package, mixed $upgrader = null, mixed $hookExtra = []): mixed
    {
        if ($reply !== false) {
            return $reply;
        }

        if (!is_string($package) || $package === '' || !$this->estNotrePaquet($package, is_array($hookExtra) ? $hookExtra : [])) {
            return $reply;
        }

        $attendu = $this->empreintePour($package);

        if ($attendu === null) {
            $this->signaler('spiralbase_updater_integrite', sprintf('manifeste injoignable au moment du téléchargement de %s', $package));

            return new \WP_Error(
                'spiralbase_updater_integrite',
                __('Mise à jour refusée : le manifeste est injoignable, l\'intégrité du paquet ne peut pas être vérifiée.', 'spiralbase')
            );
        }

        if ($attendu === '') {
            $this->signaler('spiralbase_updater_integrite', 'manifeste sans empreinte SHA-256 — téléchargement refusé');

            return new \WP_Error(
                'spiralbase_updater_integrite',
                __('Mise à jour refusée : le manifeste ne fournit pas d\'empreinte SHA-256.', 'spiralbase')
            );
        }

        $fichier = ($this->telechargeur)($package);

        if (is_wp_error($fichier)) {
            return $fichier;
        }

        if (!is_string($fichier) || $fichier === '' || !is_file($fichier)) {
            $this->signaler('spiralbase_updater_integrite', 'téléchargement invalide (aucun fichier exploitable)');

            return new \WP_Error(
                'spiralbase_updater_integrite',
                __('Mise à jour refusée : le paquet téléchargé est introuvable.', 'spiralbase')
            );
        }

        $obtenu = hash_file('sha256', $fichier);

        if ($obtenu === false || !hash_equals($attendu, strtolower($obtenu))) {
            $this->signaler('spiralbase_updater_integrite', sprintf('empreinte SHA-256 divergente (attendu %s, obtenu %s)', $attendu, (string) $obtenu));

            /* Ne jamais laisser traîner un paquet refusé. */
            @unlink($fichier);

            return new \WP_Error(
                'spiralbase_updater_integrite',
                sprintf(
                    /* translators: 1: empreinte attendue, 2: empreinte obtenue. */
                    __('Mise à jour refusée : empreinte SHA-256 divergente (attendue %1$s, obtenue %2$s).', 'spiralbase'),
                    $attendu,
                    (string) $obtenu
                )
            );
        }

        /* Fichier vérifié : le fournir à WordPress court-circuite un second téléchargement. */
        return $fichier;
    }

    /** Version du produit actuellement installée sur ce site. */
    public function versionInstallee(): string
    {
        return $this->versionInstallee;
    }

    /** Manifeste sanitisé, en cache transient 1 h (et cache d'échec 5 min). */
    public function manifeste(bool $forcer = false): ?array
    {
        if (!$forcer) {
            $cache = get_site_transient($this->cleCache());

            if (is_array($cache) && $cache['version'] !== '' && $cache['download_url'] !== '') {
                return $cache;
            }

            /* Cache négatif : GitHub injoignable ne doit pas coûter 15 s à chaque hook. */
            if (get_site_transient($this->cleCache() . '_echec')) {
                return null;
            }
        }

        if (!str_starts_with($this->urlManifeste, 'https://')) {
            return $this->echec('URL de manifeste non HTTPS : ' . $this->urlManifeste);
        }

        $chrono  = Profiler::start('updater.manifeste');
        $reponse = ($this->fetcher)($this->urlManifeste, [
            'timeout'   => 15,
            'sslverify' => true,
            'headers'   => ['User-Agent' => 'spiralbase-updater'],
        ]);

        Profiler::stop('updater.manifeste', $chrono, ['url' => $this->urlManifeste]);

        if (is_wp_error($reponse)) {
            return $this->echec('requête du manifeste en échec : ' . $reponse->get_error_message());
        }

        if (wp_remote_retrieve_response_code($reponse) !== 200) {
            return $this->echec(sprintf('manifeste HTTP %d', wp_remote_retrieve_response_code($reponse)));
        }

        $brut = json_decode(wp_remote_retrieve_body($reponse), true);

        if (!is_array($brut)) {
            return $this->echec('manifeste JSON invalide');
        }

        $version = isset($brut['version']) && is_scalar($brut['version']) ? sanitize_text_field(trim((string) $brut['version'])) : '';
        $paquet  = isset($brut['download_url']) && is_string($brut['download_url']) ? trim($brut['download_url']) : '';

        /* Une version non-semver reproposerait la même MAJ indéfiniment. */
        if (!preg_match('/^\d+(\.\d+)*([.-][0-9A-Za-z.-]+)?$/', $version)) {
            return $this->echec(sprintf('version de manifeste non exploitable : « %s »', $version));
        }

        if (!str_starts_with($paquet, 'https://') || !in_array((string) parse_url($paquet, PHP_URL_HOST), self::HOTES_PAQUET, true)) {
            return $this->echec(sprintf('hôte de paquet non autorisé : %s', $paquet));
        }

        $manifeste = [
            'version'      => $version,
            'download_url' => esc_url_raw($paquet),
            'details_url'  => !empty($brut['details_url']) && is_string($brut['details_url'])
                ? esc_url_raw($brut['details_url'])
                : sprintf('https://github.com/spiraldev13/%s', $this->slug),
            'tested'       => sanitize_text_field((string) ($brut['tested'] ?? '')),
            'requires'     => sanitize_text_field((string) ($brut['requires'] ?? '')),
            'requires_php' => sanitize_text_field((string) ($brut['requires_php'] ?? '')),
            'sha256'       => strtolower(trim((string) ($brut['sha256'] ?? ''))),
        ];

        set_site_transient($this->cleCache(), $manifeste, HOUR_IN_SECONDS);

        return $manifeste;
    }

    private function cleCache(): string
    {
        return $this->slug . '_' . $this->type . '_update_manifest';
    }

    /** Empreinte attachée à la proposition, sinon celle du manifeste courant. */
    private function empreintePour(string $package): ?string
    {
        $memorisee = get_site_transient($this->cleCache() . '_empreintes');

        if (is_array($memorisee) && array_key_exists($package, $memorisee)) {
            return (string) $memorisee[$package];
        }

        $manifeste = $this->manifeste();

        if ($manifeste === null) {
            return null;
        }

        return $manifeste['download_url'] === $package ? $manifeste['sha256'] : null;
    }

    private function memoriserEmpreinte(string $package, string $sha256): void
    {
        $memorisee = get_site_transient($this->cleCache() . '_empreintes');
        $memorisee = is_array($memorisee) ? $memorisee : [];

        $memorisee[$package] = $sha256;

        set_site_transient($this->cleCache() . '_empreintes', $memorisee, HOUR_IN_SECONDS * 24);
    }

    /**
     * Ciblage : `$hookExtra` d'abord (WordPress nous dit quel produit il met
     * à jour — fiable), repli sur l'URL avec correspondance ANCRÉE (la
     * comparaison par sous-chaîne héritée d'ultimate-shanks interceptait le
     * paquet d'autrui : `autre-spiralbase.zip` contient `spiralbase.zip`).
     *
     * @param array<string, mixed> $hookExtra
     */
    private function estNotrePaquet(string $package, array $hookExtra): bool
    {
        $cible = $this->type === self::TYPE_THEME
            ? ($hookExtra['theme'] ?? null)
            : ($hookExtra['plugin'] ?? null);

        if (is_string($cible) && $cible !== '') {
            return $cible === ($this->type === self::TYPE_THEME ? $this->slug : ($this->identifiantWp ?: $this->slug));
        }

        $chemin = (string) parse_url($package, PHP_URL_PATH);
        $motif  = '#(^|/)' . preg_quote($this->slug, '#') . '([.\-][0-9A-Za-z.\-]*)?\.zip$#';

        return (bool) preg_match($motif, $chemin);
    }

    private function echec(string $message): null
    {
        $this->signaler('spiralbase_updater_echec', $message);
        set_site_transient($this->cleCache() . '_echec', 1, self::DUREE_CACHE_ECHEC);

        return null;
    }

    /**
     * Signal systématique : hook (consommable par le tableau de bord 6.4)
     * et journal PHP — sans condition WP_DEBUG, un site de la flotte qui ne
     * voit plus aucune mise à jour doit laisser une trace en production.
     * Deux canaux distincts : `spiralbase_updater_integrite` (paquet
     * refusé — potentiellement une attaque) et `spiralbase_updater_echec`
     * (manifeste inexploitable — panne ou publication fautive).
     */
    private function signaler(string $hook, string $message): void
    {
        do_action($hook, $this->slug, $message);
        error_log(sprintf('[spiralbase] updater/%s : %s.', $this->slug, $message));
    }
}
