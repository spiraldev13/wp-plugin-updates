<?php

namespace Spiral\Presets;

use Spiral\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Presets de configuration réutilisables.
 *
 * Un preset capture un sous-ensemble des réglages d'un popup — affichage,
 * bouton, déclencheurs, fréquence, et optionnellement le ciblage — sans jamais
 * la planification, le titre ni le contenu (propres à chaque popup). Stocké en
 * option WordPress : faible volume, gestion admin, pas de permalien ni de
 * révision par item — comme les designs et les tailles réutilisables.
 */
final class Repository
{
    public const OPTION = 'spiral_config_presets';

    /** Sections toujours incluses dans un preset. */
    public const CORE_SECTIONS = ['display', 'button', 'triggers', 'frequency'];

    /** Section optionnelle (choix explicite de l'utilisateur). */
    public const OPTIONAL_SECTION = 'targeting';

    /**
     * Tous les presets, nettoyés, indexés par slug.
     *
     * @return array<string, array{name: string, includes_targeting: bool, settings: array}>
     */
    public static function all(): array
    {
        $raw = get_option(self::OPTION, []);

        if (!is_array($raw)) {
            return [];
        }

        $presets = [];

        foreach ($raw as $slug => $preset) {
            $slug = sanitize_key((string) $slug);

            if ($slug === '' || !is_array($preset)) {
                continue;
            }

            $presets[$slug] = self::sanitizePreset($preset);
        }

        return $presets;
    }

    /**
     * @return array{name: string, includes_targeting: bool, settings: array}|null
     */
    public static function get(string $slug): ?array
    {
        $presets = self::all();

        return $presets[sanitize_key($slug)] ?? null;
    }

    /**
     * Crée un preset depuis les réglages enregistrés d'un popup.
     * Renvoie le slug créé.
     */
    public static function createFromPopup(int $popupId, string $name, bool $includesTargeting): string
    {
        return self::create($name, Settings::get($popupId), $includesTargeting);
    }

    /**
     * Crée un preset à partir d'un tableau de réglages (bruts ou complets).
     * Renvoie le slug créé.
     */
    public static function create(string $name, array $settings, bool $includesTargeting): string
    {
        $presets = self::all();
        $name = self::cleanName($name);
        $slug = self::uniqueSlug($name, array_keys($presets));

        $presets[$slug] = self::buildPreset($name, $settings, $includesTargeting);
        self::persist($presets);

        return $slug;
    }

    public static function rename(string $slug, string $name): void
    {
        $presets = self::all();
        $slug = sanitize_key($slug);

        if (isset($presets[$slug])) {
            $presets[$slug]['name'] = self::cleanName($name);
            self::persist($presets);
        }
    }

    /**
     * Duplique un preset ; renvoie le nouveau slug, ou null si l'original manque.
     */
    public static function duplicate(string $slug): ?string
    {
        $preset = self::get($slug);

        if ($preset === null) {
            return null;
        }

        return self::create(
            $preset['name'] . ' ' . __('(copie)', 'popup-spiral'),
            $preset['settings'],
            $preset['includes_targeting']
        );
    }

    public static function delete(string $slug): void
    {
        $presets = self::all();
        unset($presets[sanitize_key($slug)]);
        self::persist($presets);
    }

    /**
     * Applique les sections choisies d'un preset aux réglages d'un popup.
     * Ne touche jamais aux sections non demandées (contenu, planification…).
     *
     * @param string[] $sections Sections à appliquer (parmi celles du preset).
     */
    public static function applyToPopup(int $popupId, string $slug, array $sections): void
    {
        $preset = self::get($slug);

        if ($preset === null) {
            return;
        }

        $current = Settings::get($popupId);
        $allowed = array_keys($preset['settings']);

        foreach ($sections as $section) {
            $section = sanitize_key((string) $section);

            if (in_array($section, $allowed, true)) {
                $current[$section] = $preset['settings'][$section];
            }
        }

        Settings::save($popupId, $current);
    }

    /**
     * Construit la structure stockée d'un preset (sections figées + optionnelle).
     */
    private static function buildPreset(string $name, array $settings, bool $includesTargeting): array
    {
        // Passage par la sanitation complète des réglages : données garanties valides.
        $full = Settings::sanitize($settings);
        $stored = [];

        foreach (self::CORE_SECTIONS as $section) {
            $stored[$section] = $full[$section];
        }

        if ($includesTargeting) {
            $stored[self::OPTIONAL_SECTION] = $full[self::OPTIONAL_SECTION];
        }

        return [
            'name' => $name,
            'includes_targeting' => $includesTargeting,
            'settings' => $stored,
        ];
    }

    /**
     * @return array{name: string, includes_targeting: bool, settings: array}
     */
    private static function sanitizePreset(array $preset): array
    {
        $includesTargeting = !empty($preset['includes_targeting']);
        $settings = isset($preset['settings']) && is_array($preset['settings']) ? $preset['settings'] : [];

        return self::buildPreset(
            self::cleanName((string) ($preset['name'] ?? '')),
            $settings,
            $includesTargeting
        );
    }

    private static function cleanName(string $name): string
    {
        $name = sanitize_text_field($name);

        return $name !== '' ? $name : __('Preset sans nom', 'popup-spiral');
    }

    /**
     * @param string[] $taken
     */
    private static function uniqueSlug(string $name, array $taken): string
    {
        $base = sanitize_key(sanitize_title($name));

        if ($base === '') {
            $base = 'preset';
        }

        $slug = $base;
        $i = 2;

        while (in_array($slug, $taken, true)) {
            $slug = $base . '-' . $i;
            $i++;
        }

        return $slug;
    }

    private static function persist(array $presets): void
    {
        update_option(self::OPTION, $presets);
    }
}
