<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Fabrique de sondes de cession (AD-3) — le wrapper commun à tous les
 * modules : transforme un FAIT (« le tiers fournit réellement cette
 * fonctionnalité ») en verdict de sonde conforme au contrat `Module`.
 *
 * Durcissement acté en revue 2.1, mutualisé ici (un renvoi plutôt qu'une
 * copie) : un fait illisible (Throwable) = MAIN GARDÉE + signal — jamais
 * le retrait à contre-sens, qui priverait le site d'une fonctionnalité
 * que le tiers défaillant ne fournit pas non plus.
 */
final class SondeCession
{
    /**
     * @param string            $slug   slug du module — attribution des
     *                                  signaux dans les logs
     * @param \Closure():bool   $fait   le tiers fournit-il réellement la
     *                                  fonctionnalité ? (faits établis
     *                                  uniquement : options, classes,
     *                                  constantes — timing 1.3/2.1)
     * @param \Closure():string $raison raison de cession, composée à
     *                                  l'évaluation (i18n paresseuse)
     *
     * @return callable():(bool|string) sonde conforme au contrat Module
     */
    public static function surFait(string $slug, \Closure $fait, \Closure $raison): callable
    {
        return static function () use ($slug, $fait, $raison): bool|string {
            try {
                if (!$fait()) {
                    return false;
                }
            } catch (\Throwable $e) {
                error_log(sprintf('[spiralbase] sonde « %s » : fait tiers illisible, main gardée — %s', $slug, $e->getMessage()));

                return false;
            }

            /* Le fait est acquis : la cession est DUE même si le libellé
               défaille — `true` déclenche la raison générique du registre,
               jamais un maintien fautif (doublon avec le tiers). */
            try {
                $texte = trim($raison());
            } catch (\Throwable $e) {
                error_log(sprintf('[spiralbase] sonde « %s » : libellé de raison illisible — cession générique. %s', $slug, $e->getMessage()));

                return true;
            }

            return $texte === '' ? true : $texte;
        };
    }
}
