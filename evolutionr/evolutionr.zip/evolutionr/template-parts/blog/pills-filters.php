<?php
/**
 * Barre de pills — filtre par catégorie sur la page Blog et ses archives.
 *
 * Approche hybride (cf. design.md du change `add-navigation-and-blog`,
 * décision D2) : chaque pill est un vrai `<a href>` vers l'archive
 * WordPress correspondante (`/blog/` pour Tous, `/category/<slug>/` pour
 * chaque catégorie). Aucun filtre JS, aucune URL `#`. Chaque catégorie
 * est ainsi indexable indépendamment par Google.
 *
 * L'état actif est détecté côté serveur via `is_home()` (page d'articles)
 * et `is_category($slug)` (archive de catégorie).
 *
 * Inclu depuis `home.php` et `category.php`.
 */

if (!defined('ABSPATH')) {
    exit;
}

// URL de la pill « Tous » : page d'articles WP si configurée, sinon /blog/.
$blog_page_id = (int) get_option('page_for_posts');
$blog_url     = $blog_page_id ? get_permalink($blog_page_id) : home_url('/blog/');

$pills = [
    [
        'slug'   => null,
        'label'  => __('Tous', 'evolutionr'),
        'url'    => $blog_url,
        'active' => is_home() && !is_category(),
    ],
    [
        'slug'   => 'creation',
        'label'  => __('Création de site web', 'evolutionr'),
    ],
    [
        'slug'   => 'seo',
        'label'  => __('Référencement naturel', 'evolutionr'),
    ],
    [
        'slug'   => 'maintenance',
        'label'  => __('Maintenance & hébergement', 'evolutionr'),
    ],
    [
        'slug'   => 'identite-visuelle',
        'label'  => __('Identité visuelle', 'evolutionr'),
    ],
];
?>
<nav class="blog-filters" aria-label="<?php esc_attr_e('Filtrer les articles par catégorie', 'evolutionr'); ?>">
    <?php foreach ($pills as $pill):
        $slug = $pill['slug'];

        if ($slug === null) {
            $url    = $pill['url'];
            $active = $pill['active'];
        } else {
            $link = get_term_link($slug, 'category');
            // Si la catégorie n'existe pas encore (slug pas seedé), on
            // omet la pill plutôt que d'afficher un lien cassé.
            if (is_wp_error($link)) {
                continue;
            }
            $url    = $link;
            $active = is_category($slug);
        }

        $classes = 'blog-filter' . ($active ? ' is-active' : '');
        ?>
        <a class="<?php echo esc_attr($classes); ?>"
           href="<?php echo esc_url($url); ?>"
           <?php if ($active): ?>aria-current="page"<?php endif; ?>>
            <?php echo esc_html($pill['label']); ?>
        </a>
    <?php endforeach; ?>
</nav>
