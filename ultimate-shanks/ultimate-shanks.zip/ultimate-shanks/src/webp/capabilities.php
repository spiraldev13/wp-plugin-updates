<?php

/**
 * WebP - Détection des capacités de conversion du serveur
 *
 * Interroge WP_Image_Editor (GD ou Imagick selon l'hébergement) pour savoir
 * quels formats de sortie sont réellement encodables. Aucun outil externe :
 * la portabilité multi-sites prime (décision D1 du design).
 *
 * Fichiers liés :
 * - src/webp/converter.php
 * - src/webp/settings.php (formats grisés si non supportés)
 *
 * @package UltimateShanks\Webp
 */

namespace UltimateShanks\Webp;

if (!defined('ABSPATH')) {
	exit;
}

class Capabilities
{
	/**
	 * Formats de sortie pris en charge par le module
	 */
	const FORMATS = [
		'webp' => ['label' => 'WebP', 'mime' => 'image/webp', 'extension' => 'webp'],
		'avif' => ['label' => 'AVIF', 'mime' => 'image/avif', 'extension' => 'avif'],
	];

	/**
	 * Types MIME source convertibles
	 */
	const SOURCE_MIMES = ['image/jpeg', 'image/png'];

	/**
	 * Cache par requête des résultats de wp_image_editor_supports()
	 *
	 * @var array
	 */
	private static $support = [];

	/**
	 * Le serveur sait-il encoder ce format ?
	 *
	 * @param string $format 'webp'|'avif'
	 * @return bool
	 */
	public static function supports($format)
	{
		if (!isset(self::FORMATS[$format])) {
			return false;
		}

		if (!isset(self::$support[$format])) {
			self::$support[$format] = wp_image_editor_supports([
				'mime_type' => self::FORMATS[$format]['mime'],
			]);
		}

		return self::$support[$format];
	}

	/**
	 * Le module est-il opérant ? (au moins le WebP doit être encodable)
	 *
	 * @return bool
	 */
	public static function is_operational()
	{
		return self::supports('webp');
	}

	/**
	 * MIME cible d'un format
	 *
	 * @param string $format
	 * @return string
	 */
	public static function mime($format)
	{
		return isset(self::FORMATS[$format]) ? self::FORMATS[$format]['mime'] : '';
	}

	/**
	 * Extension de fichier d'un format
	 *
	 * @param string $format
	 * @return string
	 */
	public static function extension($format)
	{
		return isset(self::FORMATS[$format]) ? self::FORMATS[$format]['extension'] : '';
	}
}
