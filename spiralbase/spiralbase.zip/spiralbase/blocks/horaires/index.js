/**
 * Bloc spiralbase/horaires — JS éditeur écrit à la main, SANS build (AD-12 :
 * l'artefact livré EST ce fichier). Bloc 100 % dynamique : save() rend null,
 * le serveur rend tout depuis les données métier du site.
 *
 * L'aperçu passe par ServerSideRender quand le paquet est là : l'opérateur
 * voit ses VRAIES données dans l'éditeur. Repli sur un aperçu statique
 * sinon — jamais d'éditeur cassé pour un paquet manquant.
 */
( function ( blocks, element, blockEditor, components, i18n, serverSideRender ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    function apercu( props ) {
        var Rendu = serverSideRender && ( serverSideRender.default || serverSideRender );

        if ( typeof Rendu === 'function' ) {
            return e( Rendu, {
                block: 'spiralbase/horaires',
                attributes: props.attributes,
                EmptyResponsePlaceholder: function () {
                    return e(
                        'p',
                        { style: { margin: 0, opacity: 0.8 } },
                        __( 'Aucun horaire exploitable dans les données métier du site.', 'spiralbase' )
                    );
                },
            } );
        }

        return e(
            'p',
            { style: { margin: 0, opacity: 0.8 } },
            __( 'Les horaires du site sont rendus sur le front.', 'spiralbase' )
        );
    }

    blocks.registerBlockType( 'spiralbase/horaires', {
        edit: function ( props ) {
            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-horaires-apercu',
                style: {
                    border: '1px dashed currentColor',
                    borderRadius: '4px',
                    opacity: 0.9,
                    padding: '1em',
                },
            } );

            return e(
                'div',
                blockProps,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages des horaires', 'spiralbase' ) },
                        e( components.ToggleControl, {
                            label: __( 'Afficher l’état d’ouverture', 'spiralbase' ),
                            help: __(
                                'Ajoute une indication « Ouvert » / « Fermé », calculée au fuseau horaire du site.',
                                'spiralbase'
                            ),
                            checked: !! props.attributes.etatOuverture,
                            onChange: function ( valeur ) {
                                props.setAttributes( { etatOuverture: !! valeur } );
                            },
                        } )
                    )
                ),
                e( 'strong', null, __( 'Horaires', 'spiralbase' ) ),
                e( 'div', { style: { marginTop: '0.5em' } }, apercu( props ) )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n,
    window.wp.serverSideRender
);
