---
stepsCompleted: ['step-01-init', 'step-02-discovery', 'step-02b-vision', 'step-02c-executive-summary', 'step-03-success', 'step-04-journeys', 'step-05-domain', 'step-06-innovation-skipped', 'step-07-project-type', 'step-08-scoping', 'step-09-functional', 'step-10-nonfunctional', 'step-11-polish', 'step-12-complete']
workflowCompleted: true
completionDate: '2026-04-24'
inputDocuments:
  - "_bmad-output/brainstorming/brainstorming-session-2026-04-24-1044.md"
  - "docs/visibility-impact.md"
  - "_bmad-output/img/Box.png"
  - "_bmad-output/img/Classement.png"
  - "_bmad-output/img/Custom.png"
  - "_bmad-output/img/Grille.png"
  - "_bmad-output/img/comparatif horizontal.png"
  - "_bmad-output/img/comparatifs.png"
  - "_bmad-output/img/produit vertical.png"
  - "_bmad-output/img/test produit.png"
workflowType: 'prd'
projectName: 'All Affiliate'
documentCounts:
  briefs: 0
  research: 0
  brainstorming: 1
  projectDocs: 1
  visualRefs: 8
classification:
  projectType: web_app
  projectSubType: wordpress_plugin
  domain: general
  complexity: low-medium
  projectContext: greenfield
---

# Product Requirements Document - All Affiliate

**Author:** Cyril
**Date:** 2026-04-24

> **Note sur les références visuelles** : 8 captures d'écran d'exemples ont été fournies (`_bmad-output/img/`). Elles servent de **référence fonctionnelle** (quels éléments afficher) mais **PAS de référence visuelle** : Cyril demande un design **"encore meilleur visuellement"**. Le style final doit dépasser ces exemples.

## Executive Summary

**All Affiliate** est un plugin WordPress d'affiliation produits multi-plateformes, construit pour l'usage personnel de Cyril sur plusieurs sites WordPress couvrant toutes thématiques. Il remplace la friction des plugins existants par un workflow rapide (création d'un produit en 20 secondes), un système universel de plateformes d'affiliation (Amazon, Awin, Rakuten, CJ, Affilae, Effinity, Viator, Tiqets, Musement, GetYourGuide, Headout, et Custom pour toute autre plateforme), et un design qui s'intègre automatiquement au thème du site hôte via détection des tokens et surcharge via Tailwind CSS.

**Problème résolu** : les plugins d'affiliation WP actuels forcent un compromis entre puissance (AAWP, ThirstyAffiliates) et esthétique — les premiers cassent le design du site avec des rendus datés, les seconds manquent de plateformes, de tracking et de réutilisabilité. Aucun ne combine architecture universelle, cohérence visuelle automatique et rapidité de création.

**Utilisateurs ciblés** : Cyril, propriétaire de plusieurs sites éditoriaux affiliés sous WordPress. Pas de distribution publique prévue — outil strictement personnel, réutilisable sur N sites via un système de mise à jour propriétaire (GitHub + `updater.php`).

### What Makes This Special

Six différenciateurs clés, tous dérivés d'une session de brainstorming structurée (45 idées, 9 principes directeurs, 6 templates MVP sur 16 candidats priorisés via matrice) :

1. **Platform Profiles universels** — toute plateforme d'affiliation modélisée comme un template d'URL paramétrable + tag global. Ajouter une plateforme = 1 ligne de config, pas une release. L'utilisateur peut créer ses propres profils custom depuis l'UI.

2. **Proxy `/go/xxx` natif** — toutes les URLs passent par une redirection interne qui (a) garantit le tag d'affiliation, (b) compte les clics, (c) esthétise l'URL, (d) permet de changer un lien sans toucher les articles publiés.

3. **Thème-adaptatif** — le plugin détecte automatiquement les couleurs et typographies du thème WordPress actif et en dérive ses Design Tokens. Aucun "bouton orange moche par défaut" qui casse l'identité visuelle.

4. **Split-view live-preview** — l'éditeur du plugin affiche le formulaire à gauche et la preview live à droite. Chaque modification est visible immédiatement. UX de création ~20 secondes par produit.

5. **Architecture hybride CPT + React** — stockage via Custom Post Type WordPress natif (sécurité + médias + REST API gratuits), interface via admin React 100% custom avec Tailwind CSS préfixé (`aff-*`) pour éviter les conflits avec les thèmes Tailwind existants.

6. **Zéro dépendance externe** — aucune API officielle d'affiliation requise au MVP, aucun plugin tiers obligatoire (ni Pretty Links, ni ACF, ni cache externe, ni Analytics externe — tout est natif au plugin).

**Core insight** : séparer le stockage (CPT WP = gratuit, sécurisé, éprouvé) de l'interface (admin React = contrôle visuel total) élimine le faux dilemme "puissant OU beau". On peut avoir les deux, sans coût de maintenance long-terme.

## Project Classification

- **Project Type** : `web_app` — sous-type **WordPress plugin** (admin React embedded + front serveur WP)
- **Domain** : `general` — pas de contraintes réglementaires lourdes (pas healthcare/fintech/govtech). Les seules exigences externes sont le respect des termes des programmes d'affiliation (préservation des tags) et le RGPD basique pour le tracking de clics.
- **Complexity** : `low-medium` — stack technique standard (React 18 + WordPress + Tailwind), logique métier modérée (CPT, proxy, tokens, cache). Le défi est dans l'UX et la cohérence visuelle, pas la complexité algorithmique.
- **Project Context** : `greenfield` — nouveau plugin, aucun code existant à réutiliser. Pas de migration de données.

---

## Guiding Principles

Neuf principes directeurs issus de la session de brainstorming. Chaque décision produit doit satisfaire ces principes — si une feature les contredit, elle est rejetée ou repensée.

1. **Setup rapide** — pas de config interminable ; le plugin doit être utilisable en 2 minutes après activation (Arbre 3 — onboarding 1 écran)
2. **Très visuel** — show, don't tell ; preview live, galeries de templates, skeleton loaders (A#2, A#5, DT#4)
3. **Choix de templates rapide** — gallery/picker visuel plutôt que dropdown textuel (Bloc Gutenberg FR27-28)
4. **Intégration facile dans pages/articles** — via Gutenberg uniquement, pas de shortcodes (FR26)
5. **Réutilisation des produits configurés** — bibliothèque centrale CPT, un produit = une entrée (S#1, FR31)
6. **Ajout texte + photos facile et rapide** — drag-drop natif, saisie multi-format, champs minimums (FR9, FR11, FR12)
7. **Simple ET sécurisé** — UX épurée sans sacrifier la sécurité WP (nonces, capabilities, validation URL) (NFR-S1→S10)
8. **MVP rapide → enrichissement itératif** — chaque phase est livrable indépendamment, "fail fast" validation en fin de Phase 1
9. **Léger, code factorisé, propre** — prefix Tailwind `aff-*`, zéro dépendance tierce, cache transient, tests unitaires ≥ 70% (NFR-P4, NFR-I7, NFR-R4)

---

## Design & Visual Decisions

### Champs optionnels activables/désactivables (MVP)

Au niveau produit ET/OU template, ces champs sont **toggleables**, tous **désactivés par défaut** :

- **Score produit** (jauge arc-de-cercle 0-10)
- **Badges qualitatifs** ("Coup de cœur", "Meilleur", "Moins cher" ou custom)
- **Étoiles de notation** (0-5, avec demi-étoiles)
- **Badge de réduction** (ex: "-30%", saisi manuellement)
- **Pros/Cons** (listes avantages/inconvénients)

L'éditeur active ce qui lui est utile pour un produit donné. Chaque template affiche ces champs si présents, les ignore sinon. (FR13, FR29)

### Rejetés explicitement

- **Affichage "Prix mis à jour le..."** côté front : rejeté (cohérent avec le rejet du check automatique des prix). Les exemples visuels ne doivent pas induire en erreur.
- **Scraping automatique de prix** : rejeté — prix saisi manuellement uniquement.
- **Variantes direct/agrégateur par profil** : rejeté — une seule URL par profil, en mode direct.

### Stack visuelle confirmée

- **Détection auto du thème actif** → palette de couleurs et typo héritées automatiquement (FR32)
- **Override possible** via Design Tokens (FR33)
- **Librairie de styling** : **Tailwind CSS** préfixé `aff-*`
- **Design target** : dépasser visuellement les exemples de référence fournis dans `_bmad-output/img/`

### Contrainte critique Tailwind dans un plugin WP

Certains thèmes WordPress utilisent déjà Tailwind (ex: Tailpress et thèmes modernes). Le plugin doit donc **impérativement isoler son CSS** pour éviter :
- les collisions de classes utilitaires (`p-4`, `flex`, `text-center`…)
- les conflits de configs (breakpoints, colors custom, purge list différents)
- le double chargement de Tailwind (bundle alourdi)

**Décision non-négociable** : **prefix Tailwind obligatoire**. Toutes les classes générées sont préfixées via `tailwind.config.js` → `prefix: "aff-"`. Exemple : `aff-p-4`, `aff-flex`, `aff-bg-primary`.

→ Cette contrainte remonte aux étapes Architecture et Implementation.

---

## Success Criteria

### User Success

Cyril ressent le succès du plugin quand :

- **Création fluide** : il peut créer un produit en **moins de 30 secondes** sans quitter le split-view
- **Insertion naturelle** : il peut insérer un produit existant dans un article via Gutenberg en **moins de 10 secondes** (recherche + choix template + enregistrement)
- **Confiance tag** : il n'a jamais à se demander "mon tag d'affiliation est-il bien dans le lien ?" — la construction d'URL est toujours automatique et garantie
- **Intégration visuelle** : le rendu d'un template s'intègre au thème **sans aucune config CSS manuelle** — il active le plugin, ça ressemble déjà au site
- **Zéro frustration** : aucun moment où il doit installer un autre plugin, éditer un CSS externe, ou ouvrir une doc

### Business Success

Pour Cyril, "business" = revenu d'affiliation sur ses sites :

- **100% des clics sortants** passent par le proxy `/go/xxx` et sont comptés
- **100% des tags d'affiliation** sont préservés dans les URLs finales (condition sine qua non du revenu)
- **N sites WordPress** (N = nombre actuel + futurs) font tourner le plugin sans adaptation manuelle
- **Dashboard utile** : Cyril peut en 30 secondes identifier ses **top 5 produits** en nombre de clics et décider où concentrer son effort éditorial

### Technical Success

- **Zéro dépendance plugin tiers** (pas de Pretty Links, pas d'ACF, pas de plugin cache obligatoire)
- **Aucune dépendance API officielle** requise (toutes les plateformes fonctionnent sans accès API au MVP)
- **Compatibilité** : WordPress ≥ 6.0, PHP ≥ 8.0
- **Pas de conflit CSS** avec les thèmes Tailwind (prefix `aff-*` validé sur ≥ 2 thèmes Tailwind en test)
- **Mobile-first** : tous les templates réussissent un Lighthouse Mobile ≥ 90 en Performance
- **Accessibilité** : base WCAG 2.1 AA (contrastes, nav clavier, alt textes)
- **Sécurité** : anti-fraude actif par défaut, validation URL allowlist, nonces WP sur toutes les actions admin

### Measurable Outcomes

| Métrique | Cible |
|---|---|
| Temps moyen de création d'un produit | **< 30s** (timestamp entre clic "Nouveau" et "Enregistrer") |
| Temps moyen d'insertion dans un article existant | **< 10s** |
| Taux de perte de tag d'affiliation | **0 %** (test automatisé sur les 12 profils préinstallés) |
| Poids JS en front (hors admin) | **< 50 KB** gzipped |
| Time to First Contentful Paint d'un article avec 3 templates | **< 1.5s** |
| Nombre de plugins tiers requis | **0** |
| Lighthouse Performance Mobile | **≥ 90** sur chacun des 6 templates |
| Temps de rendu serveur d'un template en cache | **< 20 ms** |
| Couverture de tests unitaires (backend PHP) | **≥ 70 %** |

---

## Product Scope

### MVP — Minimum Viable Product

Tout ce qui permet à Cyril d'utiliser le plugin **en production dès le jour 1** sur ses sites, avec les 12 plateformes, les 6 templates, et le tracking fiable.

**Fondations**
- CPT `aff_product` avec admin natif caché (`show_in_menu => false`)
- Admin React custom (page "All Affiliate") + routing
- Endpoints REST `/wp-json/aff/v1/*` + consommation REST API auto du CPT

**Platform Profiles**
- Architecture générique + **12 profils préinstallés** (Amazon, Awin, Rakuten, CJ, Affilae, Effinity, Viator, Tiqets, Musement, GetYourGuide, Headout, Custom)
- Création, édition, suppression de profils custom depuis l'UI
- Stockage du tag global par profil (1 saisie = N produits)

**Liens & tracking**
- Proxy `/go/{slug}` avec redirection 301/302
- Compteur de clics en postmeta
- Construction dynamique d'URL depuis profil + tag
- Anti click-fraud (rate-limiting IP) + validation URL allowlist
- État "Inactif" si tag plateforme manquant (DT#1)

**Workflow de création**
- Split-view formulaire / preview live (A#5)
- Champs obligatoires minimum (3) + panneau avancé replié (É#3)
- Upload image drag-drop (Media Library WP)
- Bouton "Tester le lien"
- Actions bulk (sélection multiple + édit groupé)

**Système de design**
- Design Tokens globaux (palette, typo, espacements, hover) via CSS variables
- Détection auto du thème actif (pré-remplissage tokens)
- Bibliothèque de **boutons sauvegardés** (DT#3-lite)
- Preview live multi-template
- Tailwind CSS avec prefix `aff-*`

**Templates (6)**
- Card standard, Card compacte inline, Bouton CTA, Grille multi-colonnes, Top 5/10 numéroté, Tableau Pros/Cons
- Champs optionnels toggleables : Score jauge, Badges qualitatifs, Étoiles, Badge % réduction
- Skeleton loaders (A#2)
- Mobile-first responsive
- Cache transient par template + invalidation à l'édition (R#1)

**Insertion dans articles**
- Bloc Gutenberg unique "Affiliate" avec 3 actions (Rechercher / Créer rapide / Template-first)
- Autocomplétion produits
- Galerie des 6 templates avec preview

**Data & finition**
- Dashboard de perf (clics, top 5, tendance, par template)
- Programmation saisonnière (dates début/fin)
- Import multi-source : manuel + OpenGraph scraping
- Packs de page pré-assemblés
- Tooltips contextuels + visite guidée rejouable
- Onboarding simple (1 écran "Configurer mes plateformes")

### Growth Features (Post-MVP)

- **C#3 — AI auto-fill avancé** (quand API disponibles ou via Vision IA)
- **A#4 — A/B test templates** (quand volume de clics suffisant)
- **A#8 — Export multi-canal** (lien court / HTML / Markdown pour partage externe)
- **SM#1 — Suggestion automatique de template** selon contexte (type de page)
- **DT#3 full — Bibliothèque complète** de composants sauvegardés (badges, prix, cards, pas juste boutons)
- **Import/export de profils plateformes** en JSON (partage entre sites)
- **10 templates secondaires** : Hero massif, Badge minimaliste, Liste verticale, Carrousel, Bento modular full, Face-à-face, Sticky bar mobile, Modal scroll, Widget sidebar

### Vision (Future)

- **Éditeur visuel de templates** (drag-drop de composants, création de templates sans code)
- **Attribution clic → achat** (via API officielle lorsque accessible, ex: Amazon Reports API)
- **Rapports analytiques avancés** (funnel, cohortes, comparaison périodes)
- **Multi-sites management centralisé** (dashboard qui agrège plusieurs installations du plugin sur plusieurs sites WordPress de Cyril)
- **Intégration AI assistant** pour suggestions de produits pertinents selon le contenu d'un article

---

## User Journeys

### Persona unique — Cyril

**Portrait** : créateur de contenu affilié, propriétaire de plusieurs sites WordPress (actuellement + futurs), toutes thématiques (voyage, tech, maison, bien-être). Maîtrise WordPress + code (niveau intermédiaire). Inscrit à plusieurs plateformes d'affiliation mais **sans accès aux API officielles** (critères non remplis). Son objectif : maximiser ses commissions via un contenu bien produit, sans perdre des heures à gérer techniquement ses liens affiliés.

**Besoins centraux** : rapidité, fiabilité du tracking, cohérence visuelle avec chaque site, réutilisation des produits entre articles.

### Journey 1 — "Le premier déploiement"

**Scène d'ouverture** : Cyril vient de lancer un nouveau site WordPress sur le thème "équipement outdoor". Thème Astra avec Tailwind activé. Catalogue vide. Il installe `all-affiliate.zip` via le back-office.

**Action montante** : À l'activation, il voit une notice discrète "👋 All Affiliate activé. Configure tes plateformes pour commencer." Il clique. Il arrive sur **"Mes plateformes"** : les 12 profils préinstallés sont là, aucun tag saisi. Il coche Amazon, Awin, Decathlon (via Awin) et renseigne son tag Amazon FR et son affid Awin. Valide. En 2 minutes, il est prêt.

**Climax** : Il crée son premier produit : "Tente MSR Hubba Hubba NX". Il choisit Amazon. Il **colle directement une URL Amazon prise sur son téléphone** (`https://www.amazon.fr/dp/B08N5WRWNW/ref=xyz`) dans le champ "URL ou ASIN". Le plugin extrait automatiquement l'ASIN `B08N5WRWNW` et affiche une confirmation ✓. Il drag-drop une photo. Pendant qu'il tape le nom dans le formulaire de gauche, **la preview live à droite** lui montre instantanément la card avec les couleurs du thème Astra. Il clique "Tester le lien" — le nouvel onglet ouvre Amazon avec son tag global (pas celui pris dans l'URL collée). ✅

**Résolution** : Premier produit créé en 45 secondes. Il enchaîne avec 4 autres — sur le 3ème, il colle juste un ASIN brut (`B07XYZ123`) ; sur le 4ème, une URL déjà taggée — le plugin fait le bon traitement à chaque fois. Il se dit "c'est vraiment plus rapide qu'AAWP".

**Capabilities révélées** :
- Installation zéro-config (plateformes préinstallées)
- Détection auto du thème et tokens dérivés
- Split-view formulaire/preview
- **Saisie intelligente multi-format** (ASIN brut, URL nue, URL déjà taggée)
- Bouton "Tester le lien"
- Champs minimums par défaut

### Journey 2 — "La routine article"

**Scène d'ouverture** : Cyril écrit un article "Top 5 tentes légères 2026" sur son site outdoor. Il a déjà les 5 produits dans le catalogue (créés Journey 1).

**Action montante** : Dans l'éditeur Gutenberg, il tape son intro, puis clique "+" pour ajouter un bloc. Il tape "affiliate" — le bloc unique apparaît. Il clique. Les 3 actions s'affichent. Il choisit **"Choisir template d'abord"**. Galerie des 6 templates avec preview. Il clique sur **"Top 5/10 numéroté"**. L'interface passe en mode "remplir" : 5 slots. Il commence à taper "MSR" dans le premier slot — autocomplétion, il choisit "Tente MSR Hubba Hubba NX". Slot rempli en 2 secondes. Il fait les 4 autres.

**Climax** : Le bloc est inséré dans l'article. Preview dans l'éditeur : les 5 tentes affichées numérotées 1-5, chacune avec son prix Amazon, un bouton "Voir" aux couleurs du thème, score activé pour 2 produits (il les note 9/10 et 7/10), pros/cons affichés pour le top 1 uniquement. **4 minutes** pour un bloc Top 5 complet.

**Résolution** : Il publie l'article. Quelques heures plus tard, il ouvre le dashboard et voit déjà des clics sur le n°1 de sa liste.

**Capabilities révélées** :
- Bloc Gutenberg unique avec 3 actions
- Autocomplétion de produits existants
- Template-first workflow
- Champs optionnels activables par produit (pros/cons sur 1, score sur 2)
- Tracking de clics live

### Journey 3 — "La migration de tag"

**Scène d'ouverture** : Amazon informe Cyril qu'il doit migrer son compte Amazon Partners de `cyril-21` vers `cyril2026-21` (changement d'entité légale). Il a **80 produits** déjà configurés sur ses 3 sites avec le tag actuel.

**Action montante** : Panique initiale : va-t-il devoir éditer 80 articles ? Il ouvre le plugin, va dans "Mes plateformes" → Profil Amazon FR. Change le tag : `cyril-21` → `cyril2026-21`. Sauvegarde.

**Climax** : C'est tout. **Zéro article à éditer**. Tous ses liens sortants, via le proxy `/go/xxx`, utilisent désormais le nouveau tag. Il clique "Tester le lien" sur 3 produits au hasard → le nouvel onglet Amazon affiche bien le nouveau tag dans l'URL.

**Résolution** : Ce qui aurait pris 3 heures avec un plugin classique (ou 2 jours en oubliant des articles) a pris 15 secondes. Il se rappelle pourquoi il a construit ça comme ça.

**Capabilities révélées** :
- Tag global stocké 1 seule fois par profil plateforme
- Construction dynamique d'URL via proxy
- DRY maximal sur le tag

### Journey 4 — "L'analyse stratégique"

**Scène d'ouverture** : Cyril prépare son contenu du mois suivant. Il a 3 heures à investir. Quelle niche/produit prioriser ?

**Action montante** : Il ouvre le plugin → Dashboard. Il voit les 4 graphs simples :
- Clics aujourd'hui : 47
- Top 5 produits (30 derniers jours) : la tente MSR domine largement
- Tendance 30j : courbe en hausse sur les produits outdoor
- Taux de clic par template : Top 5/10 surperforme les Cards

**Climax** : Décision claire en 20 secondes : il va écrire un article dédié **"MSR Hubba Hubba NX : test complet"** et un autre comparatif **"Tentes légères 2 places"** dans les 15 prochains jours. Il note dans son Todoist.

**Résolution** : Le dashboard n'impressionne pas par des vanity metrics. Il répond à une seule question : **"sur quoi investir mon temps d'écriture ?"**.

**Capabilities révélées** :
- Dashboard de perf minimaliste (4 graphs)
- Clics par produit / par template / tendance
- Pas de données superflues

### Journey 5 — "La nouvelle plateforme custom"

**Scène d'ouverture** : Cyril découvre qu'un fabricant de matériel outdoor qu'il aime, "TrekPartner", lance son propre programme d'affiliation en direct. URLs du type `trekpartner.com/product/xxx?aff=cyril2026`.

**Action montante** : Pas d'attente, pas de release du plugin nécessaire. Il va dans "Mes plateformes" → **"+ Créer une plateforme"**. Un formulaire simple : Nom = "TrekPartner", Template URL = `trekpartner.com/product/{PRODUCT_ID}?aff={MY_TAG}`, champ requis = `PRODUCT_ID`, regex d'extraction = `/\/product\/([^/?]+)/`, tag = `cyril2026`, icône (upload PNG). Sauvegarde.

**Climax** : Le nouveau profil "TrekPartner" apparaît dans le dropdown de création de produit. Il crée 3 produits avec ce profil. Il peut aussi y coller des URLs complètes — la regex extrait bien le `PRODUCT_ID`. Les URLs construites sont correctes, testées via "Tester le lien".

**Résolution** : Extensibilité sans release. Il a ajouté une plateforme en 2 minutes.

**Capabilities révélées** :
- Création de profils custom depuis l'UI
- Template URL avec variables `{PRODUCT_ID}` et `{MY_TAG}`
- Upload d'icône par l'utilisateur
- **Regex d'extraction configurable par profil**
- Validation que l'URL construite est conforme

### Journey 6 — "L'edge case / recovery"

**Scène d'ouverture** : Cyril crée un produit Awin en vitesse un samedi soir. Il choisit la plateforme Awin dans le dropdown, renseigne l'URL cible. Sauvegarde. Publie l'article.

**Action montante** : Le produit apparaît **grisé** dans la liste admin avec un badge ⚠️ **"Tag Awin manquant"** et un petit texte "Ce produit ne sera pas affiché côté front tant que le tag Awin n'est pas configuré dans Mes plateformes". Côté front : rien ne s'affiche (aucun lien cassé ni commission perdue).

**Climax** : Cyril clique le badge → redirigé automatiquement vers Mes plateformes, profil Awin, curseur dans le champ "affid Awin". Il saisit son affid. Sauvegarde. Retourne à son article → le produit apparaît maintenant, lien parfaitement construit.

**Résolution** : Le plugin l'a protégé d'une publication sans tag (= pas de commission). Son oubli a été détecté et corrigé en 30 secondes.

**Capabilities révélées** :
- DT#1 État "Inactif" si tag manquant
- Deep-link vers la config qui manque
- Pas de rendu front tant que le lien n'est pas valide

### Saisie intelligente multi-format (capability transversale)

Issue de la précision apportée au Journey 1, le plugin doit accepter et adapter **3 formats d'entrée** par plateforme :

| Format | Exemple (Amazon) | Comportement |
|---|---|---|
| **ID brut** (ASIN) | `B08N5WRWNW` | Construit l'URL via template + tag global |
| **URL nue** (sans tag) | `https://amazon.fr/dp/B08N5WRWNW` | Extrait l'ID via regex du profil, construit l'URL via template + tag global |
| **URL déjà taggée** | `https://amazon.fr/dp/B08N5WRWNW?tag=ancien-21` | Extrait l'ID, **ignore le tag collé**, applique le tag global du profil |

**Détails techniques** :
- Chaque Platform Profile expose une **liste de regex d'extraction** pour capter l'ID pertinent depuis divers formats d'URL
- Validation à la volée avec message d'erreur UX si format non reconnu
- **Détection cross-profile** : si l'utilisateur colle une URL Amazon dans un produit configuré Awin, le plugin propose "Cette URL ressemble à une URL Amazon. Veux-tu changer la plateforme ?"
- **Option avancée** (paramètre admin, désactivée par défaut) : override ponctuel du tag global pour un produit donné (cas rare : 2 tags Amazon différents selon le site/la niche)

### Journey Requirements Summary

**Capacités révélées par l'ensemble des journeys**

| Capacité requise | Journeys |
|---|---|
| Installation zéro-config + 12 profils préinstallés | J1 |
| Détection auto du thème + tokens dérivés | J1 |
| Création de profil custom depuis l'UI (nom, template URL, regex, icône) | J5 |
| Stockage tag global par profil | J1, J3 |
| Split-view formulaire/preview live | J1 |
| **Saisie intelligente multi-format (ASIN / URL nue / URL taggée)** | J1 (transversale) |
| Bouton "Tester le lien" | J1, J5 |
| Autocomplétion de produits existants | J2 |
| Bloc Gutenberg unique avec 3 actions | J2 |
| Template-first workflow | J2 |
| Galerie des 6 templates avec preview | J2 |
| Champs optionnels activables (score, pros/cons, étoiles, % réduction) | J2 |
| Proxy `/go/xxx` + construction dynamique d'URL | J3, J6 |
| Dashboard (clics, top 5, tendance, par template) | J4 |
| Skeleton loaders + mobile-first + cache transient | implicite front |
| DT#1 État "Inactif" + badges warning | J6 |
| Deep-link vers la config manquante | J6 |
| Drag-drop image via Media Library | J1 |
| Sauvegarde + invalidation cache à l'édition | J3 |
| Détection cross-profile + suggestion de changement | J1 |

**Ce que les journeys confirment**

- **Focus 100% sur Cyril** : aucun journey "admin tiers" ou "support" n'est pertinent (usage personnel)
- **Pas de journey "nouveau utilisateur externe"** : onboarding minimal suffit
- **Criticité du tag** validée par J3 et J6
- **Criticité de la saisie rapide** validée par J1 (3 formats acceptés)
- **Valeur du dashboard** validée par J4

---

## Domain-Specific Requirements

Domain `general` avec complexité `low-medium`. Pas de régulation lourde, mais 3 exigences opérationnelles du métier "affiliation marketing" captées ci-dessous.

### Compliance & Regulatory

1. **Disclosure d'affiliation** (obligation légale en France, Directive UE 2005/29/CE + Loi Hamon)
   - **MVP** : paramètre global "Texte de disclosure" dans les settings, **désactivé par défaut**. Quand activé, texte inséré automatiquement au-dessus de chaque bloc All Affiliate inséré via Gutenberg.
   - Texte par défaut modifiable par Cyril (ex: "En tant que partenaire Amazon, je touche une commission sur les achats éligibles.")
   - **V2** : disclosure personnalisable par template et par plateforme

2. **RGPD — Aucune donnée personnelle collectée**
   - **Aucune IP stockée** (ni en clair, ni hashée persistante)
   - **Aucun user-agent détaillé** stocké
   - **Aucun cookie** posé par le proxy `/go/`
   - **Seule donnée** : compteur d'incrémentation par produit (postmeta `aff_click_count`), totalement anonyme et agrégé
   - **Aucune bannière de consentement cookie requise** (rien n'est placé sur le navigateur)
   - **Rate-limiting anti-fraude** : réalisé via **transients WP** en mémoire volatile (hash éphémère de la requête, TTL 60 secondes). Aucune donnée personnelle ne persiste — à l'expiration du TTL, tout disparaît.

3. **Termes des programmes d'affiliation** (Amazon Associates, etc.)
   - **Prix affichés uniquement si saisis manuellement** par Cyril (champ optionnel, désactivé par défaut). Pas de scraping automatique, pas de récupération périodique.
   - **Respect Amazon** : pas d'affichage de prix non-conforme, disclosure activable selon disclosure rules Amazon (en tant qu'associate Amazon).
   - **Validation URL allowlist** (M#4-MVP) : les URLs cibles construites ne peuvent pointer que vers les domaines déclarés dans le profil plateforme — empêche toute redirection de phishing.

### Technical Constraints

- **Performance web** (Core Web Vitals) : impact SEO direct sur les sites de Cyril. Couvert par R#1 (cache), R#2 (mobile-first), A#2 (skeleton), lazy-loading des images.
- **Sécurité WP standard** : nonces sur toutes actions admin, `current_user_can()` sur endpoints REST, sanitization/escaping sur entrées/sorties, prepared statements via `$wpdb->prepare()` uniquement.
- **Scope "admin only"** : seuls les utilisateurs avec capability `edit_posts` (ou supérieure) peuvent créer/modifier des produits et profils plateformes.

### Integration Requirements

- **Gutenberg Editor** : bloc natif unique. Compatibilité Full Site Editing (FSE) et thèmes Block.
- **WordPress Media Library** : upload natif, pas de système parallèle, pas de CDN externe.
- **REST API WordPress** : endpoints sous `/wp-json/aff/v1/*` pour l'admin React.
- **WP Cron** : utilisé uniquement pour purger d'éventuels logs anciens si rétention activée (rien au MVP vu que rien n'est stocké).
- **Aucune intégration API tierce** au MVP (pas de Amazon PA-API, pas d'Awin API, pas d'OpenAI, pas de Vision AI).

### Risk Mitigations

→ Voir la table consolidée dans la section **Scoping Strategy → Consolidated Risk Mitigations** plus bas, qui couvre l'ensemble des risques du projet (techniques, sécurité, compliance, produit, ressources).

---

## WordPress Plugin Specific Requirements

### Project-Type Overview

All Affiliate est un plugin WordPress hybride :
- **Admin** : Single Page Application (SPA) React 18, rendue dans une page admin WordPress dédiée ("All Affiliate")
- **Front** : rendu serveur (PHP) via WordPress, hydraté avec un petit runtime JS (< 50 KB) pour les interactions (hover, lazy-load images, click tracking sur le proxy)

### Technical Architecture

```
┌────────────────────────────────────────────────────────┐
│ BROWSER                                                 │
│  ┌──────────────┐              ┌──────────────────┐    │
│  │ ADMIN        │              │ FRONT            │    │
│  │ SPA React    │              │ HTML pré-rendu   │    │
│  │ Tailwind aff-*│              │ + micro JS hydrat│    │
│  └──────┬───────┘              └──────────┬───────┘    │
└─────────┼─────────────────────────────────┼────────────┘
          │ REST API                         │ HTTP
          ▼                                  ▼
┌────────────────────────────────────────────────────────┐
│ WORDPRESS SERVER (PHP 8.x)                             │
│  ┌────────────────────────────────────────────────┐    │
│  │ Plugin All Affiliate                           │    │
│  │  REST /wp-json/aff/v1/*                        │    │
│  │  Block Gutenberg (editor + render_callback)    │    │
│  │  Proxy /go/{slug} (rewrite rule)               │    │
│  │  CPT aff_product + meta + hooks                │    │
│  │  Transients cache (templates rendus)           │    │
│  └────────────────────────────────────────────────┘    │
│                   │                                     │
│  ┌────────────────────────────────────────────────┐    │
│  │ MySQL (tables WordPress natives)               │    │
│  │  wp_posts, wp_postmeta, wp_options             │    │
│  └────────────────────────────────────────────────┘    │
└────────────────────────────────────────────────────────┘
```

**Admin = SPA** : React Router client-side, une seule page HTML servie par WordPress (`admin.php?page=all-affiliate`), routing client.

**Front = MPA** : chaque article est une URL WordPress standard, rendu serveur, blocs Gutenberg rendus via `render_callback` PHP → compatibilité maximale avec plugins de cache, SEO natif, zéro flash of unstyled content.

### Browser Matrix

| Navigateur | Version minimale |
|---|---|
| Chrome / Edge | 100+ (mars 2022) |
| Firefox | 100+ (mai 2022) |
| Safari | 15+ (septembre 2021) |
| Mobile Safari | iOS 15+ |
| Chrome Android | 100+ |

**Pas de support IE / Chrome < 100.** ES2020+ assumé.

### Responsive Design

- **Mobile-first** (R#2) : breakpoints Tailwind standard (`sm: 640px`, `md: 768px`, `lg: 1024px`, `xl: 1280px`)
- **Templates front** : tous responsive, Lighthouse Mobile ≥ 90
- **Admin React** : responsive mais **optimisé desktop**
- **Tailles tactiles** : boutons `aff-min-h-11` (44px) minimum côté front (WCAG 2.1 AA)

### Performance Targets

| Métrique | Cible | Contexte |
|---|---|---|
| LCP | **< 1.5 s** | article avec 3 templates |
| CLS | **< 0.1** | skeleton loaders pour éviter reflow |
| INP | **< 200 ms** | minimal JS front |
| Poids JS front total (gzipped) | **< 50 KB** | hors admin |
| Poids CSS front critique inline | **< 10 KB** | Tailwind purgé drastiquement |
| Lighthouse Mobile Performance | **≥ 90** | sur chacun des 6 templates |
| Temps de rendu cache HIT | **< 20 ms** | serveur |
| Temps de rendu cache MISS | **< 150 ms** | serveur |

**Stratégies** :
- Cache transients WP avec invalidation à l'édition (R#1)
- Images en `loading="lazy"` + format WebP préféré
- CSS critique inliné, Tailwind purgé au build (seules les classes `aff-*` utilisées)
- JS front chargé avec `defer`, split par template
- Pas de web-font custom (héritée du thème via tokens)

### SEO Strategy

- **Rendu serveur** : contenu indexable Google instantanément
- **Schema.org `Product` en JSON-LD** (MVP) : injection automatique quand un produit est affiché, avec `name`, `image`, `offers.price` si prix saisi manuellement, `aggregateRating` si étoiles/score activés. Attention : pas de fake data — les propriétés apparaissent uniquement si les champs sont réellement remplis.
- **Liens proxy `/go/xxx`** avec `rel="nofollow sponsored"` : bonne pratique SEO et signal clair à Google
- **Slugs produits propres** (`/go/tente-msr-hubba-hubba-nx`)
- **Pas d'archives CPT** : `has_archive: false`, `publicly_queryable: false` → aucune URL orpheline du produit indexable, le produit n'existe que via les articles où il est inséré

### Accessibility Level

**Cible : WCAG 2.1 AA** (standard raisonnable, vérifiable par Lighthouse + axe-core au dev)

| Critère | Implémentation |
|---|---|
| Contraste texte / fond | Ratio ≥ 4.5:1 |
| Navigation clavier | Tous les boutons/liens focusables, `focus-visible` stylé |
| Lecteurs d'écran | `alt` sur images, rôles ARIA sur widgets complexes (score jauge = `role="img"` + `aria-label`) |
| Zoom 200% | Pas de perte de contenu |
| `prefers-reduced-motion` | Respecté (désactive skeleton animations et hover scales) |
| Icônes + labels | Badges ("Coup de cœur") ont label textuel en plus de l'icône |

**Non-objectif MVP** : WCAG AAA, audits accessibilité externes payants.

### WordPress-Specific Requirements

- **WordPress** ≥ 6.0 (Gutenberg stable + FSE)
- **PHP** ≥ 8.0 (types, readonly, enums utilisables)
- **Hooks critiques** : `init` (CPT + REST), `admin_menu` (page plugin), `enqueue_block_editor_assets` (bloc Gutenberg), `save_post_aff_product` (invalidation cache), `wp_enqueue_scripts` (front), `template_redirect` (route `/go/`)
- **Plugin header** : version, licence (propriétaire), text domain `all-affiliate`
- **Uninstall** : `register_uninstall_hook()` → propose de garder ou supprimer les données (CPT, options, transients)

### Packaging & Distribution

- **ZIP GitHub + système `updater.php` existant** : **l'infrastructure de mise à jour est déjà opérationnelle** côté Cyril (voir `docs/visibility-impact.md`). Le plugin All Affiliate **réutilise cette infra sans modification**.
- Le plugin doit simplement :
  - Inclure un header WordPress conforme (version, Update URI si requis par l'updater)
  - Respecter le format de manifest attendu par `updater.php` (ex: `update.json` avec champs `version`, `download_url`, `changelog`)
  - Être packagé en ZIP avec la structure standard WP (dossier `all-affiliate/` contenant `all-affiliate.php`)
- **Pas de publication sur wordpress.org** (plugin privé)

### Skipped sections (non applicables)

- `native_features` : pas d'app native
- `cli_commands` : pas de CLI utilisateur (WP-CLI envisageable en V2 pour admin bulk)

---

## Scoping Strategy

Cette section définit **la philosophie MVP**, les **ressources** nécessaires et les **risques** consolidés. Les listes détaillées MVP / Growth / Vision sont dans **Product Scope** plus haut.

### MVP Philosophy

**Approche : "Experience MVP"** — ni "Feature MVP minimaliste", ni "Proof of Concept".

Cyril construit pour son propre usage quotidien. Un MVP moche mais fonctionnel le ferait abandonner ; un MVP beau mais incomplet serait frustrant. L'objectif est un MVP exploitable **en production dès le jour 1**, avec une UX de qualité même sur un scope réduit.

**Critère de validation MVP** : Cyril peut **remplacer intégralement** son ou ses plugins actuels d'affiliation sur au moins 1 site sans régression UX, sans perte de tracking, et avec un gain de temps mesurable.

### Resource Requirements

- **Développeur** : Cyril + assistance Claude Code
- **Durée estimée** : 7 phases d'implémentation, ~8-10 semaines de travail effectif en rythme solo
- **Skills nécessaires** : React 18, WordPress PHP (hooks, CPT, REST API), Tailwind CSS, Gutenberg Block API

### Consolidated Risk Mitigations

Table unique couvrant les risques techniques, produit et ressources.

| Catégorie | Risque | Proba | Impact | Mitigation |
|---|---|---|---|---|
| Technique | Invalidation de cache défectueuse (données obsolètes) | Moyenne | Élevé | Hooks WP exhaustifs + bouton "Purger le cache" + tests automatisés (FR46, FR47, NFR-R1) |
| Technique | Conflits CSS avec thème Tailwind | Élevée | Moyen | Prefix `aff-*` obligatoire + tests sur 2+ thèmes Tailwind réels (NFR-I9) |
| Technique | Regex d'extraction ratant une variante d'URL | Moyenne | Moyen | Tests unitaires PHP (10+ cas par profil) + fallback UX "Format non reconnu" |
| Technique | Charge admin React > 2 MB | Moyenne | Moyen | Code-splitting par route, lazy-loading templates, audit Webpack régulier |
| Technique | Migration WP 6.0 → 7.x cassante | Faible | Élevé | Suivi release notes + tests contre nightly WP |
| Sécurité / Revenu | Tag d'affiliation oublié → commission perdue | Faible | Très élevé | Construction automatique via proxy + état "Inactif" si tag manquant (FR19, FR24) |
| Sécurité | Click fraud (bots gonflent les stats) | Moyenne | Moyen | Rate-limiting volatile 60s (NFR-S7) |
| Sécurité | Redirection malveillante (admin compromis) | Faible | Élevé | Validation URL allowlist par profil (FR42, NFR-S6) |
| Compliance | Amazon suspend le compte pour non-conformité | Faible | Élevé | Disclosure activable + pas de scraping + prix saisi manuellement |
| Produit | Cyril n'utilise pas le plugin après construction | Faible | Très élevé | **Validation Phase 1** = remplacer plugin actuel sur 1 site réel |
| Produit | Scope creep pendant le dev | Moyenne | Moyen | PRD verrouillé, nouvelles idées → "Phase 2/3" |
| Ressources | Manque de temps dev de Cyril | Élevée | Élevé | Phases courtes (1-2 semaines max) livrables indépendamment |
| Ressources | Complexité cumulative entre phases | Moyenne | Moyen | Refactoring ciblé entre phases + tests automatisés |
| Ressources | Dépendance à Claude Code | Faible | Faible | Documentation architecturale claire → tout LLM peut reprendre |

### "Fail-fast" Decision Point

**Point de décision critique : fin de Phase 1 (Fondations)**. Cyril valide ou arrête le projet selon 3 critères :

- L'architecture CPT + React custom est-elle tenable à maintenir ? → sinon **pivot ou arrêt**
- Les conflits Tailwind sont-ils résolus sur les thèmes réels ? → sinon **pivot**
- Le gain de temps perçu vs plugin actuel est-il réel ? → sinon **arrêt**

**Décision Cyril** : Phase 1 = point de go/no-go explicite. Chaque phase livre indépendamment.

---

## Functional Requirements

⚠️ **Capability Contract** : cette liste est binding. Toute feature non listée ici ne sera PAS dans le MVP. Actor principal = **admin** (utilisateur WordPress avec capability `edit_posts` ou supérieure). Actor secondaire = **visiteur** du site (consumer des liens).

### A. Platform Management

- **FR1** : L'admin peut voir la liste des 12 profils de plateformes d'affiliation préinstallés (Amazon Partners, Awin, Rakuten, CJ Affiliate, Affilae, Effinity, Viator, Tiqets, Musement, GetYourGuide, Headout, Custom).
- **FR2** : L'admin peut activer/désactiver individuellement chaque profil préinstallé.
- **FR3** : L'admin peut renseigner son tag/ID d'affiliation unique pour chaque profil actif.
- **FR4** : L'admin peut créer un profil de plateforme custom (nom, template URL, champs requis, regex d'extraction, icône).
- **FR5** : L'admin peut éditer et supprimer les profils custom qu'il a créés.
- **FR6** : L'admin peut tester qu'un profil construit une URL finale conforme en cliquant un bouton de test.
- **FR7** : Le système valide que l'URL construite correspond au domaine attendu du profil avant d'autoriser la sauvegarde.

### B. Product Management

- **FR8** : L'admin peut créer un produit en choisissant une plateforme parmi les profils actifs.
- **FR9** : L'admin peut saisir l'identifiant produit dans l'un des 3 formats suivants : identifiant brut (ex: ASIN), URL nue de la page produit, URL déjà taggée. Le système détecte le format et extrait l'identifiant automatiquement.
- **FR10** : Le système ignore systématiquement les tags d'affiliation contenus dans une URL collée et applique le tag global du profil.
- **FR11** : L'admin peut ajouter une image à un produit via drag-drop (intégré à la Media Library WordPress) ou via OpenGraph scraping depuis l'URL collée.
- **FR12** : L'admin peut saisir des champs obligatoires minimaux (nom, plateforme + identifiant, image) et accéder à un panneau replié de champs optionnels (prix, description, catégorie, badges, score, étoiles, pros/cons, réduction).
- **FR13** : L'admin peut activer/désactiver individuellement par produit les champs optionnels suivants : score jauge (0-10), badges qualitatifs, étoiles de notation, badge de réduction, pros/cons.
- **FR14** : L'admin peut voir une prévisualisation live du produit dans le template par défaut pendant l'édition (split-view).
- **FR15** : L'admin peut dupliquer un produit existant.
- **FR16** : L'admin peut sélectionner plusieurs produits et effectuer des actions groupées (suppression, changement de plateforme, activation/désactivation, programmation saisonnière).
- **FR17** : L'admin peut rechercher un produit existant par nom, plateforme ou catégorie avec autocomplétion.
- **FR18** : L'admin peut programmer des dates de début et fin d'affichage par produit.
- **FR19** : Un produit dont la plateforme n'a pas de tag configuré est marqué "Inactif" dans l'admin et n'est pas rendu côté front.
- **FR20** : L'admin peut, depuis l'état "Inactif", naviguer en un clic vers le champ de configuration du tag manquant.

### C. Link & Tracking System

- **FR21** : Le système expose une route publique `/go/{slug}` qui redirige (HTTP 301/302) vers l'URL finale construite à la volée depuis le profil plateforme et le tag global.
- **FR22** : À chaque clic sur `/go/{slug}`, le système incrémente un compteur agrégé par produit, sans collecter d'IP, d'user-agent ou de cookie.
- **FR23** : Le système applique un rate-limiting anti click-fraud via transients volatiles (TTL 60s, hash éphémère non-persistant).
- **FR24** : L'admin peut changer le tag d'un profil en un seul endroit et voir tous les liens existants utiliser immédiatement le nouveau tag (sans éditer les articles).
- **FR25** : Les liens rendus côté front portent l'attribut `rel="nofollow sponsored"`.

### D. Content Authoring (Gutenberg)

- **FR26** : L'admin peut insérer un bloc "All Affiliate" unique dans l'éditeur Gutenberg.
- **FR27** : Depuis le bloc, l'admin peut accéder à trois actions : rechercher un produit existant, créer un produit rapide, choisir un template d'affichage en premier.
- **FR28** : L'admin peut choisir parmi 6 templates d'affichage pour un bloc : Card standard, Card compacte inline, Bouton CTA, Grille multi-colonnes, Top 5/10 numéroté, Tableau Pros/Cons.
- **FR29** : Chaque template affiche les champs optionnels d'un produit uniquement s'ils sont activés pour ce produit.
- **FR30** : L'admin peut insérer un pack de page pré-assemblé (ex: "Top 5 comparatif complet" combinant plusieurs templates).
- **FR31** : Un même produit du catalogue peut être réutilisé dans plusieurs articles sans duplication de données.

### E. Visual Design System

- **FR32** : À l'activation du plugin, le système détecte les couleurs et la typographie du thème WordPress actif et pré-remplit les Design Tokens (palette, typo, espacements).
- **FR33** : L'admin peut éditer tous les Design Tokens globaux (palette, typographie, espacements, paramètres hover).
- **FR34** : L'admin peut réinitialiser les Design Tokens à leurs valeurs issues du thème actif.
- **FR35** : L'admin peut créer, nommer et enregistrer des variantes de boutons personnalisés (couleurs, typo, hover, bordures) réutilisables dans tous les templates.
- **FR36** : L'admin peut éditer et supprimer les variantes de boutons qu'il a créées.
- **FR37** : L'admin peut voir une prévisualisation live de tous les templates simultanément (desktop + mobile) sur une page Preview.

### F. Performance Monitoring (Dashboard)

- **FR38** : L'admin peut consulter un dashboard affichant : nombre de clics du jour, top 5 des produits cliqués sur 30 jours, tendance des clics sur 30 jours, taux de clic comparatif par template.
- **FR39** : Les données du dashboard sont toujours à jour au moment de l'affichage (pas de délai supérieur à 1 minute).

### G. Security & Compliance

- **FR40** : L'admin peut activer/désactiver un texte de disclosure d'affiliation, désactivé par défaut, affiché automatiquement au-dessus de chaque bloc All Affiliate inséré.
- **FR41** : L'admin peut personnaliser le texte de disclosure.
- **FR42** : Le système valide que chaque URL cible d'un produit correspond au regex du template de son profil plateforme (empêche les redirections de phishing).
- **FR43** : Toutes les actions admin (création, édition, suppression de produit / profil / token) sont protégées par nonces WordPress.
- **FR44** : Seuls les utilisateurs WordPress avec la capability `edit_posts` ou supérieure peuvent créer et modifier des produits et des profils plateformes.
- **FR45** : Le système injecte un JSON-LD `Product` (Schema.org) côté front pour chaque produit rendu, avec les propriétés remplies uniquement pour les champs effectivement saisis.

### H. System Configuration & Maintenance

- **FR46** : Le système met en cache chaque rendu de template via les transients WordPress et invalide le cache concerné à chaque édition du produit ou de ses métadonnées.
- **FR47** : L'admin peut vider manuellement tout le cache du plugin depuis les settings.
- **FR48** : L'admin peut effectuer un onboarding initial en 1 écran unique (configuration des plateformes utilisées + saisie des tags).
- **FR49** : L'admin peut accéder à une visite guidée rejouable qui décrit les 3 parcours principaux (créer un produit, insérer dans un article, analyser les performances).
- **FR50** : Chaque champ de l'admin affiche un tooltip contextuel (icône `?`) expliquant son rôle.
- **FR51** : Le système est compatible avec l'infrastructure de mise à jour existante (`updater.php` + GitHub releases), via un header de plugin et un `update.json` conformes.
- **FR52** : À la désinstallation du plugin, l'admin peut choisir de conserver ou supprimer les données (CPT, options, transients).

---

## Non-Functional Requirements

NFRs = quality attributes. Sélectif : seules les catégories pertinentes pour All Affiliate sont documentées.

### Performance

| NFR | Cible | Mesure |
|---|---|---|
| **NFR-P1** LCP front | < 1.5 s | Lighthouse, article avec 3 templates |
| **NFR-P2** CLS | < 0.1 | skeleton loaders anti-reflow |
| **NFR-P3** INP | < 200 ms | Lighthouse |
| **NFR-P4** Poids JS front total (gzipped) | < 50 KB | webpack-bundle-analyzer |
| **NFR-P5** Poids CSS front critique inliné | < 10 KB | Tailwind purgé |
| **NFR-P6** Lighthouse Mobile Performance | ≥ 90 | audit par template |
| **NFR-P7** Temps de rendu serveur template (cache HIT) | < 20 ms | logs WP |
| **NFR-P8** Temps de rendu serveur template (cache MISS) | < 150 ms | logs WP |
| **NFR-P9** Latence du proxy `/go/{slug}` | < 50 ms | TTFB |
| **NFR-P10** Chargement initial de l'admin React | < 2 s sur 4G | Lighthouse Admin |
| **NFR-P11** Lag preview live (frappe → update) | < 100 ms | mesuré en dev |

### Security

| NFR | Exigence |
|---|---|
| **NFR-S1** Nonces | Toute action admin (REST, form submit, AJAX) vérifiée par `wp_verify_nonce()` |
| **NFR-S2** Capabilities | Toute modification requiert au minimum `edit_posts` via `current_user_can()` |
| **NFR-S3** Input sanitization | Toute entrée utilisateur sanitizée via fonctions WP (`sanitize_text_field`, `esc_url_raw`, `sanitize_key`, etc.) |
| **NFR-S4** Output escaping | Toute sortie HTML échappée via `esc_html`, `esc_attr`, `wp_kses_post` |
| **NFR-S5** SQL | Toutes les requêtes SQL via `$wpdb->prepare()` ou `WP_Query` (zéro concat brute) |
| **NFR-S6** Validation URL | Les URLs cibles doivent matcher le regex du template du profil, rejet sinon |
| **NFR-S7** Rate-limiting proxy | Fenêtre glissante 60s via transients, hash éphémère non-persistant |
| **NFR-S8** Aucune donnée personnelle | Pas d'IP, UA ni cookie visiteur — seul un compteur agrégé par produit |
| **NFR-S9** CSP-friendly | Aucun `eval`, pas d'inline-script non-noncé |
| **NFR-S10** Dependencies | Audit npm + composer mensuel (pas de CVE critique non patchée > 30 jours) |

### Scalability

| NFR | Cible |
|---|---|
| **NFR-Sc1** Produits par site | Jusqu'à **2000 produits** sans dégradation perceptible |
| **NFR-Sc2** Profils plateformes | Jusqu'à **50 profils** (12 préinstallés + 38 custom) |
| **NFR-Sc3** Clics concurrents sur `/go/` | **100 clics/s** en pic sans impact sur les autres requêtes |
| **NFR-Sc4** Réutilisation d'un produit | Aucun impact perf si **100 articles référencent le même produit** (grâce au cache) |
| **NFR-Sc5** Croissance DB | Pas de table custom, tout via `wp_posts`/`wp_postmeta` (scaling naturel WP) |

### Accessibility

| NFR | Exigence |
|---|---|
| **NFR-A1** Conformité | WCAG 2.1 niveau **AA** validé via Lighthouse + axe-core sur les 6 templates |
| **NFR-A2** Contraste texte/fond | Ratio ≥ 4.5:1 validé au build (lint CSS) |
| **NFR-A3** Navigation clavier | Tous les éléments interactifs focusables, `focus-visible` stylé |
| **NFR-A4** Lecteurs d'écran | `alt` sur images, rôles ARIA sur widgets custom |
| **NFR-A5** Zoom 200% | Aucune perte de contenu ni overflow horizontal |
| **NFR-A6** Reduced motion | `prefers-reduced-motion` respecté |
| **NFR-A7** Tailles tactiles | Éléments tactiles ≥ 44x44 px |

### Integration

| NFR | Exigence |
|---|---|
| **NFR-I1** WordPress | Compatible ≥ 6.0 (current + 2 dernières majeures) |
| **NFR-I2** PHP | Compatible ≥ 8.0 |
| **NFR-I3** Gutenberg | Bloc natif compatible FSE et thèmes Block |
| **NFR-I4** Media Library | Utilisation exclusive de la Media Library WP (pas de dossier externe) |
| **NFR-I5** REST API | Endpoints sous `/wp-json/aff/v1/*`, auto-documentés via WP REST schema |
| **NFR-I6** Updater | Compatible avec le système `updater.php` existant + manifest `update.json` respecté |
| **NFR-I7** Pas de dépendance plugin tierce | Fonctionne sans ACF, Pretty Links, plugin cache, plugin analytics |
| **NFR-I8** Pas de dépendance API tierce | Fonctionne sans accès Amazon PA-API, Awin API, ou toute autre API d'affiliation |
| **NFR-I9** Pas de conflit thème Tailwind | Toutes les classes CSS générées préfixées `aff-*` |
| **NFR-I10** Multisite WordPress | Fonctionne en WP multisite (une installation = un site indépendant) |

### Reliability & Maintainability

| NFR | Exigence |
|---|---|
| **NFR-R1** Cache invalidation | Cache invalidé en moins de 1 seconde après édition d'un produit |
| **NFR-R2** Uptime proxy | Le proxy `/go/` ne doit jamais 500 — fallback 302 vers URL brute du profil en cas d'erreur |
| **NFR-R3** Graceful degradation JS | Le front fonctionne correctement même si le micro-JS d'hydration est bloqué |
| **NFR-R4** Tests unitaires backend | Couverture ≥ **70 %** du code PHP (PHPUnit) |
| **NFR-R5** Tests unitaires frontend | Couverture ≥ **50 %** des composants React critiques (Jest + Testing Library) |
| **NFR-R6** Tests E2E | Au moins 1 test E2E par journey (6 journeys) via Playwright |
| **NFR-R7** Logs | Erreurs PHP fatales loguées via `error_log()` WP, pas de silence |
| **NFR-R8** Code style | Respect WordPress Coding Standards (PHPCS + ESLint + Prettier) |
| **NFR-R9** Documentation | PHPDoc obligatoire sur les fonctions publiques ; JSDoc sur l'API de l'admin React |
| **NFR-R10** Code review | Avant chaque merge vers `main`, auto-review ou assistance Claude Code avec checklist de qualité |
