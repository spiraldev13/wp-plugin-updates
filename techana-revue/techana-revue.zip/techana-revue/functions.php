<?php
/**
 * TechAna Revue — plomberie du block theme.
 *
 * Rien de ce qui s'édite ne vit ici : les templates, parties et patterns sont
 * du markup de blocs (Éditeur de site). Ce fichier ne porte que ce que les
 * blocs ne savent pas faire seuls, découpé en modules sous inc/.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'TECHANA_REVUE_VERSION', wp_get_theme()->get( 'Version' ) );

add_action( 'after_setup_theme', 'techanaRevueSetup' );
add_action( 'wp_enqueue_scripts', 'techanaRevueAssets' );
add_action( 'wp_enqueue_scripts', 'techanaRevueSansFeuilleShanks', 100 );
add_action( 'init', 'techanaRevuePatternCategory' );
add_filter( 'render_block_core/group', 'techanaRevueMainLandmark', 10, 2 );
add_filter( 'wp_preload_resources', 'techanaRevuePreloadPolices' );

/**
 * Supports du thème et tailles d'images du design (integration-wordpress.md).
 */
function techanaRevueSetup() {
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/techana.css' );

    add_image_size( 'techana-3-2', 720, 480, true );
    add_image_size( 'techana-1-1', 176, 176, true );
    add_image_size( 'techana-side', 128, 128, true );
    add_image_size( 'techana-lead', 1200, 800, true );
    add_image_size( 'techana-avatar', 144, 144, true );
}

/**
 * Feuille unique + script unique différé — vigilances n°4 et scripts defer.
 */
function techanaRevueAssets() {
    wp_enqueue_style(
        'techana-revue',
        get_theme_file_uri( 'assets/css/techana.css' ),
        array(),
        TECHANA_REVUE_VERSION
    );
    wp_enqueue_script(
        'techana-revue',
        get_theme_file_uri( 'assets/js/techana.js' ),
        array(),
        TECHANA_REVUE_VERSION,
        array(
            'strategy'  => 'defer',
            'in_footer' => true,
        )
    );
}

/**
 * Les styles éditoriaux vivent dans theme.json (décision du 2026-09-04) : la
 * feuille générée par Ultimate Shanks, vide depuis, n'a plus rien à servir —
 * elle est retirée de la file (le plugin la met en file à la priorité 99).
 */
function techanaRevueSansFeuilleShanks() {
    wp_dequeue_style( 'ultimate-shanks-generated-styles' );
    wp_deregister_style( 'ultimate-shanks-generated-styles' );
}

/**
 * Les deux fontes du premier écran — corps et titres — sont déclarées dans
 * theme.json, donc découvertes par le navigateur seulement après l'analyse de
 * la feuille de styles. Les précharger évite le rendu en police de repli puis
 * la bascule. Deux fichiers au maximum : au-delà, le préchargement concurrence
 * l'image LCP au lieu de l'aider.
 */
function techanaRevuePreloadPolices( array $ressources ): array {
    $polices = array(
        'assets/fonts/ibm-plex-sans-variable.woff2',
        'assets/fonts/barlow-semi-condensed-700.woff2',
    );
    foreach ( $polices as $police ) {
        $ressources[] = array(
            'href'        => get_theme_file_uri( $police ),
            'as'          => 'font',
            'type'        => 'font/woff2',
            'crossorigin' => 'anonymous',
        );
    }
    return $ressources;
}

/**
 * Catégorie d'insertion des patterns TechAna.
 */
function techanaRevuePatternCategory() {
    register_block_pattern_category(
        'techana',
        array( 'label' => 'TechAna' )
    );
}

/**
 * Cible du lien d'évitement : le groupe `site-main` reçoit id + tabindex au
 * rendu. Injecté côté serveur car le save() de core/group ne peut pas les
 * émettre sans invalider le markup.
 */
function techanaRevueMainLandmark( $html, $block ) {
    $classes = $block['attrs']['className'] ?? '';
    if ( ! str_contains( $classes, 'site-main' ) ) {
        return $html;
    }
    return preg_replace(
        '/<main class="/',
        '<main id="contenu" tabindex="-1" class="',
        $html,
        1
    );
}

// Modules — chacun documente son rôle en tête de fichier.
$techanaRevueModules = array(
    'inc/metas.php',        // métas _techana_* + calcul des mots
    'inc/champ-image.php',  // contrôle « choisir une image » des écrans d'admin
    'inc/encarts.php',      // contenus « Encart » : ciblage rubrique + emplacement
    'inc/publicite.php',    // diffusion des encarts (Apparence → Publicité)
    'inc/encarts-aide.php', // aide en ligne des encarts (panneau, onglets « Aide »)
    'inc/une-reglages.php', // volumes de l'accueil (Apparence → Une de l'accueil)
    'inc/une-liste.php',    // colonne « À la une » de la liste des articles
    'inc/redacteurs.php',   // portrait des rédacteurs (médiathèque, repli initiales)
    'inc/bindings.php',     // sources de block bindings (lecture, dates, compteurs)
    'inc/blocs.php',        // blocs dynamiques maison (rubriques, ticker, populaires…)
    'inc/article.php',      // blocs de l'article (byline, en-bref, faq, sommaire…)
    'inc/corps-article.php', // habillage du corps (tableaux, code, en-bref détecté)
    'inc/accueil.php',      // variations de Query Loop de l'accueil + déduplication
    'inc/sponsorise.php',   // blocs dynamiques et rel des articles sponsorisés
    'inc/formulaire-reglages.php', // réglages du formulaire (Apparence → Formulaire de contact)
    'inc/formulaire.php',   // formulaire de contact (bloc, code court + traitement)
    'inc/seo-head.php',     // head complet : description, canonical, OG, JSON-LD
);
foreach ( $techanaRevueModules as $techanaRevueModule ) {
    $techanaRevuePath = get_theme_file_path( $techanaRevueModule );
    if ( file_exists( $techanaRevuePath ) ) {
        require $techanaRevuePath;
    }
}
unset( $techanaRevueModules, $techanaRevueModule, $techanaRevuePath );
