<?php
/**
 * Réglages du formulaire de contact — écran « Apparence → Formulaire de contact ».
 *
 * Destinataire, adresse affichée, garde-fous anti-robot et messages vivaient en
 * constantes dans inc/formulaire.php, sans aucune interface. Ils forment
 * désormais une option unique, lue par techanaRevueReglagesContact(). Le schéma
 * ci-dessous est la seule source des défauts, des bornes et des libellés :
 * ajouter un réglage = une entrée.
 *
 * L'écran documente aussi les deux façons de poser le formulaire : le bloc
 * « TechAna — formulaire de contact » de l'inserter et le code court
 * [techana_contact] — même rendu, même traitement, mêmes réglages.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_CONTACT_OPTION = 'techana_contact';
const TECHANA_CONTACT_PAGE   = 'techana-contact';

add_action( 'admin_init', 'techanaRevueContactSettings' );
add_action( 'admin_menu', 'techanaRevueContactMenu' );
add_action( 'current_screen', 'techanaRevueContactAide' );

/**
 * Schéma des réglages : type, défaut, bornes, libellé et aide de chacun.
 *
 * @return array<string, array>
 */
function techanaRevueContactSchema(): array {
    return array(
        'destinataire' => array(
            'type'   => 'email',
            'defaut' => 'site@evolutionr.fr',
            'label'  => 'Adresse qui reçoit les messages',
            'aide'   => 'Jamais affichée sur le site : elle ne figure que dans le courrier envoyé.',
        ),
        'affichee'     => array(
            'type'   => 'texte',
            'defaut' => 'support[@]techana.fr',
            'label'  => 'Adresse affichée au lecteur',
            'aide'   => 'Proposée quand l’envoi échoue (jeton %adresse% du message d’échec). Écrite avec des crochets pour ne pas être moissonnée par les robots. Vide : valeur d’origine.',
        ),
        'delai_min'    => array(
            'type'   => 'entier',
            'defaut' => 3,
            'min'    => 0,
            'max'    => 60,
            'label'  => 'Délai minimal avant envoi (secondes)',
            'aide'   => 'Un envoi plus rapide que ce délai après l’affichage du formulaire est refusé : un lecteur met plusieurs secondes à écrire, un robot non. 0 désactive ce garde-fou.',
        ),
        'repos'        => array(
            'type'   => 'entier',
            'defaut' => 120,
            'min'    => 0,
            'max'    => 3600,
            'label'  => 'Repos entre deux envois (secondes)',
            'aide'   => 'Durée pendant laquelle une même connexion ne peut pas renvoyer de message. 0 désactive ce garde-fou.',
        ),
        'succes'       => array(
            'type'   => 'texte',
            'defaut' => 'Merci, votre message est parti. Nous répondons sous 48 heures ouvrées.',
            'label'  => 'Message de succès',
            'aide'   => 'Affiché à la place du formulaire une fois le message envoyé. Vide : valeur d’origine.',
        ),
        'echec'        => array(
            'type'   => 'texte',
            'defaut' => 'L’envoi a échoué. Écrivez-nous directement à %adresse%.',
            'label'  => 'Message d’échec d’envoi',
            'aide'   => 'Affiché quand le serveur n’a pas pu expédier le courrier. %adresse% est remplacé par l’adresse affichée. Vide : valeur d’origine.',
        ),
    );
}

/**
 * Réglages effectifs — défauts fusionnés avec l'option, chaque valeur bornée
 * ou validée à la lecture (double filet avec la sanitisation à l'écriture).
 *
 * @return array<string, string|int>
 */
function techanaRevueReglagesContact(): array {
    $stockes  = get_option( TECHANA_CONTACT_OPTION, array() );
    $stockes  = is_array( $stockes ) ? $stockes : array();
    $reglages = array();
    foreach ( techanaRevueContactSchema() as $cle => $def ) {
        $reglages[ $cle ] = techanaRevueContactValeur( $def, $stockes[ $cle ] ?? null );
    }
    return $reglages;
}

/**
 * Valeur acceptable d'un réglage : la valeur donnée si elle respecte son type,
 * le défaut du schéma sinon.
 *
 * @param array $def    Entrée du schéma.
 * @param mixed $valeur Valeur stockée ou postée, null si absente.
 * @return string|int
 */
function techanaRevueContactValeur( array $def, $valeur ) {
    if ( null === $valeur ) {
        return $def['defaut'];
    }
    if ( 'entier' === $def['type'] ) {
        return max( $def['min'], min( $def['max'], (int) $valeur ) );
    }
    $texte = trim( (string) $valeur );
    if ( 'email' === $def['type'] ) {
        return is_email( $texte ) ? $texte : $def['defaut'];
    }
    return '' !== $texte ? $texte : $def['defaut'];
}

/**
 * Sanitisation à l'enregistrement. Une adresse de destination invalide n'est
 * pas remplacée en silence par le défaut : le réglage précédent est conservé
 * et l'écran le signale.
 *
 * @param mixed $entree Valeurs postées.
 * @return array<string, string|int>
 */
function techanaRevueContactSanitize( $entree ): array {
    $entree = is_array( $entree ) ? $entree : array();
    $actuel = techanaRevueReglagesContact();
    $propre = array();
    foreach ( techanaRevueContactSchema() as $cle => $def ) {
        if ( ! isset( $entree[ $cle ] ) ) {
            continue;
        }
        $brut = 'entier' === $def['type']
            ? (int) $entree[ $cle ]
            : techanaRevueContactTexte( (string) $entree[ $cle ] );
        if ( 'email' === $def['type'] && ! is_email( sanitize_email( $brut ) ) ) {
            add_settings_error(
                TECHANA_CONTACT_OPTION,
                'techana-contact-' . $cle,
                'L’adresse qui reçoit les messages n’est pas valide : le réglage précédent est conservé.'
            );
            $brut = $actuel[ $cle ];
        }
        $propre[ $cle ] = techanaRevueContactValeur( $def, $brut );
    }
    return $propre;
}

/**
 * Texte d'un réglage : balises retirées, blancs normalisés. Pas de
 * sanitize_text_field() ici : elle efface tout `%` suivi de deux caractères
 * hexadécimaux, et le jeton %adresse% y perdrait son « %ad ».
 */
function techanaRevueContactTexte( string $valeur ): string {
    return trim( (string) preg_replace( '/\s+/', ' ', wp_kses( $valeur, array() ) ) );
}

function techanaRevueContactSettings() {
    register_setting( TECHANA_CONTACT_OPTION, TECHANA_CONTACT_OPTION, array(
        'type'              => 'array',
        'sanitize_callback' => 'techanaRevueContactSanitize',
        'default'           => array(),
    ) );

    add_settings_section(
        'techana-contact-reglages',
        'Réception et garde-fous',
        'techanaRevueContactIntro',
        TECHANA_CONTACT_PAGE
    );
    foreach ( techanaRevueContactSchema() as $cle => $def ) {
        add_settings_field(
            'techana-contact-' . $cle,
            esc_html( $def['label'] ),
            'techanaRevueContactChamp',
            TECHANA_CONTACT_PAGE,
            'techana-contact-reglages',
            array( 'cle' => $cle, 'label_for' => 'techana-contact-' . $cle )
        );
    }
}

function techanaRevueContactIntro() {
    echo '<p>Le formulaire se pose dans n’importe quelle page de deux façons, au choix : '
        . 'le bloc <strong>TechAna — formulaire de contact</strong> depuis l’inserteur, ou le '
        . 'code court <code>[techana_contact]</code> dans un bloc « Code court ». Les deux '
        . 'rendent le même formulaire et suivent ces réglages. Aucun service tiers : la '
        . 'protection contre les robots tient au champ leurre invisible, au délai minimal et '
        . 'au repos entre deux envois réglés ci-dessous.</p>';
}

/**
 * Champ d'un réglage, selon son type.
 *
 * @param array $args Contient la clé du schéma.
 */
function techanaRevueContactChamp( array $args ) {
    $cle    = $args['cle'];
    $def    = techanaRevueContactSchema()[ $cle ];
    $valeur = techanaRevueReglagesContact()[ $cle ];
    $id     = 'techana-contact-' . $cle;
    $nom    = TECHANA_CONTACT_OPTION . '[' . $cle . ']';

    if ( 'entier' === $def['type'] ) {
        printf(
            '<input type="number" id="%s" name="%s" value="%d" min="%d" max="%d" step="1" class="small-text" />',
            esc_attr( $id ),
            esc_attr( $nom ),
            (int) $valeur,
            (int) $def['min'],
            (int) $def['max']
        );
    } else {
        printf(
            '<input type="%s" id="%s" name="%s" value="%s" class="%s" />',
            'email' === $def['type'] ? 'email' : 'text',
            esc_attr( $id ),
            esc_attr( $nom ),
            esc_attr( (string) $valeur ),
            in_array( $cle, array( 'succes', 'echec' ), true ) ? 'large-text' : 'regular-text'
        );
    }
    printf( '<p class="description">%s</p>', esc_html( $def['aide'] ) );
}

function techanaRevueContactMenu() {
    add_theme_page(
        'Formulaire de contact',
        'Formulaire de contact',
        'edit_theme_options',
        TECHANA_CONTACT_PAGE,
        'techanaRevueContactPage'
    );
}

function techanaRevueContactPage() {
    if ( ! current_user_can( 'edit_theme_options' ) ) {
        wp_die( 'Accès refusé.' );
    }
    echo '<div class="wrap"><h1>Formulaire de contact</h1>';
    settings_errors( TECHANA_CONTACT_OPTION );
    echo '<form action="options.php" method="post">';
    settings_fields( TECHANA_CONTACT_OPTION );
    do_settings_sections( TECHANA_CONTACT_PAGE );
    submit_button();
    echo '</form></div>';
}

/** Onglets « Aide » de l'écran : poser le formulaire, comprendre les refus. */
function techanaRevueContactAide() {
    $ecran = get_current_screen();
    if ( ! $ecran || 'appearance_page_' . TECHANA_CONTACT_PAGE !== $ecran->id ) {
        return;
    }
    $ecran->add_help_tab( array(
        'id'      => 'techana-contact-poser',
        'title'   => 'Poser le formulaire',
        'content' => '<p><strong>Dans l’éditeur</strong> : ajoutez le bloc « TechAna — formulaire '
            . 'de contact » (catégorie Thème de l’inserteur). Il s’affiche comme un aperçu '
            . 'nominal dans l’éditeur et prend sa forme sur le site.</p>'
            . '<p><strong>Par code court</strong> : ajoutez un bloc « Code court » contenant '
            . '<code>[techana_contact]</code>. Utile dans un contenu qui n’est pas en blocs, ou '
            . 'pour un gabarit d’extension. Ne le placez pas dans un paragraphe : le formulaire '
            . 'y serait imbriqué dans un <code>&lt;p&gt;</code>.</p>'
            . '<p>Les deux rendent exactement le même formulaire ; un seul par page suffit, le '
            . 'traitement d’un envoi vaut pour la page entière.</p>',
    ) );
    $ecran->add_help_tab( array(
        'id'      => 'techana-contact-refus',
        'title'   => 'Pourquoi un envoi est refusé',
        'content' => '<p>Six cas, tous signalés au lecteur sauf le premier : le <strong>champ '
            . 'leurre</strong> rempli (un robot qui remplit tout — il voit un faux succès), '
            . 'l’<strong>envoi trop rapide</strong> après l’affichage, un <strong>second envoi'
            . '</strong> pendant le repos, une <strong>adresse e-mail</strong> invalide, un '
            . '<strong>message</strong> de moins de dix caractères, le <strong>consentement</strong> '
            . 'décoché. La saisie est conservée après une erreur.</p>'
            . '<p>Le courrier part de <code>no-reply@</code> votre domaine, avec l’adresse du '
            . 'lecteur en réponse : mettre la sienne en expéditeur ferait rejeter le message par '
            . 'SPF et DMARC. En production, un SMTP authentifié reste nécessaire.</p>',
    ) );
}
