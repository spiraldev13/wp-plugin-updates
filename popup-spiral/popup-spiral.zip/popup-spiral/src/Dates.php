<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Helpers de dates dans le fuseau horaire du site.
 *
 * Le suivi et la planification raisonnent en heure locale du site (option
 * WordPress) et jamais en UTC brut, pour que « aujourd'hui » corresponde à la
 * journée telle que l'administrateur la voit.
 */
final class Dates
{
    /** Format d'une journée d'agrégat statistique. */
    public const DAY = 'Y-m-d';

    /**
     * Date du jour (site), au format `Y-m-d`.
     */
    public static function today(): string
    {
        return self::now()->format(self::DAY);
    }

    /**
     * Instant courant dans le fuseau du site.
     */
    public static function now(): \DateTimeImmutable
    {
        return new \DateTimeImmutable('now', wp_timezone());
    }

    /**
     * Valide une date `Y-m-d` ; renvoie null si le format ne correspond pas.
     */
    public static function sanitizeDay(string $value): ?string
    {
        $value = trim($value);

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return null;
        }

        $date = \DateTimeImmutable::createFromFormat('!' . self::DAY, $value, wp_timezone());

        return $date instanceof \DateTimeImmutable && $date->format(self::DAY) === $value
            ? $value
            : null;
    }

    /**
     * Liste ordonnée des jours `Y-m-d` de `$from` à `$to` inclus.
     * Renvoie un tableau vide si la plage est inversée ou invalide.
     *
     * @return string[]
     */
    public static function range(string $from, string $to): array
    {
        $start = self::sanitizeDay($from);
        $end = self::sanitizeDay($to);

        if ($start === null || $end === null || $start > $end) {
            return [];
        }

        $days = [];
        $cursor = \DateTimeImmutable::createFromFormat('!' . self::DAY, $start, wp_timezone());
        $last = \DateTimeImmutable::createFromFormat('!' . self::DAY, $end, wp_timezone());
        $oneDay = new \DateInterval('P1D');

        while ($cursor <= $last) {
            $days[] = $cursor->format(self::DAY);
            $cursor = $cursor->add($oneDay);
        }

        return $days;
    }
}
