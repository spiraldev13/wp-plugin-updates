<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\TexteRiche;

/**
 * Rendu serveur du bloc `spiralbase/menu-plat` — nom, prix, description.
 *
 * Le prix est du TEXTE, jamais un nombre : « 12,50 € », « 12 € / 18 € »,
 * « selon arrivage », « 9,80 € / 100 g » sont tous légitimes sur une carte.
 * Aucune tentative d'en extraire une monnaie : la moitié des cas réels
 * deviendrait insaisissable, et un prix mal reformaté sur un site de client
 * est une faute commerciale, pas un détail d'affichage.
 *
 * Ordre du document : nom, prix, description. Le prix suit immédiatement le
 * nom — c'est l'ordre de lecture d'une carte, et celui qu'entend un lecteur
 * d'écran. Les variantes ne réordonnent rien : elles n'agissent que par le
 * CSS (AC 2 — voir `RenduMenu`).
 */
final class RenduPlat extends RenduBloc
{
    protected function nomDuBloc(): string
    {
        return 'spiralbase/menu-plat';
    }

    protected function composer(array $attributs, string $contenu, mixed $bloc): string
    {
        $variante = Variantes::depuisContexte($bloc);

        $champs = [
            'nom'         => ['<span class="spiralbase-menu-plat__nom">', '</span>'],
            'prix'        => ['<span class="spiralbase-menu-plat__prix">', '</span>'],
            'description' => ['<p class="spiralbase-menu-plat__description">', '</p>'],
        ];

        $morceaux = [];

        foreach ($champs as $champ => [$ouvrant, $fermant]) {
            $valeur = TexteRiche::filtrer($attributs[$champ] ?? null);

            /* Un champ laissé vide n'ouvre aucun conteneur : ni ligne fantôme
               dans la page, ni séparateur orphelin dessiné par le CSS. */
            if (TexteRiche::estVide($valeur)) {
                continue;
            }

            $morceaux[] = $ouvrant . $valeur . $fermant;
        }

        if ($morceaux === []) {
            return '';
        }

        /* Séparés par une espace : sans effet à l'écran (les éléments sont
           disposés en flex ou en grille, qui l'absorbent), mais décisif
           partout où le balisage disparaît — extrait automatique, flux RSS,
           copier-coller, lecture linéarisée. Collés, ils donnaient
           « Tartare de daurade18,50 € ». */
        $corps = implode(' ', $morceaux);

        $classes = 'spiralbase-menu-plat spiralbase-menu-plat--' . $variante;

        return '<div ' . $this->conteneur($classes) . '>' . $corps . '</div>';
    }
}
