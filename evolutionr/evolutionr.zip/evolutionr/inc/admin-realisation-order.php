<?php
/**
 * Réordonnancement des réalisations par glisser-déposer dans l'admin.
 *
 * Le CPT `realisation` alimente la section portfolio de l'accueil, triée par
 * `menu_order` croissant. Ce module rend la liste d'admin du CPT triable à la
 * souris et persiste le nouvel ordre dans `menu_order` (AJAX). L'ordre reste
 * aussi modifiable manuellement via la « Modification rapide » (champ Ordre
 * natif, le CPT supportant `page-attributes`).
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Liste d'admin du CPT triée par menu_order croissant, sur un seul écran
 * (le glisser-déposer n'a de sens que sans pagination).
 */
add_action('pre_get_posts', 'evolutionr_realisation_admin_order');
function evolutionr_realisation_admin_order(WP_Query $query): void
{
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    if ($query->get('post_type') !== 'realisation') {
        return;
    }
    // Respecte un tri explicite demandé par l'utilisateur (clic sur une colonne).
    if (!$query->get('orderby')) {
        $query->set('orderby', 'menu_order');
        $query->set('order', 'ASC');
    }
    $query->set('posts_per_page', 200);
}

/**
 * Scripts du glisser-déposer, uniquement sur l'écran de liste du CPT.
 */
add_action('admin_enqueue_scripts', 'evolutionr_realisation_order_assets');
function evolutionr_realisation_order_assets(string $hook): void
{
    if ($hook !== 'edit.php') {
        return;
    }
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'realisation') {
        return;
    }

    $rel  = '/assets/admin/realisation-order.js';
    $path = get_template_directory() . $rel;

    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script(
        'evolutionr-realisation-order',
        get_template_directory_uri() . $rel,
        ['jquery', 'jquery-ui-sortable'],
        file_exists($path) ? (string) filemtime($path) : '1.0.0',
        true
    );
    wp_localize_script('evolutionr-realisation-order', 'EvorRealOrder', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('evolutionr_reorder_realisation'),
    ]);
    wp_add_inline_style(
        'common',
        '.post-type-realisation #the-list tr { cursor: move; }'
        . '.post-type-realisation #the-list tr.evor-sorting { opacity: .6; }'
    );
}

/**
 * Persistance AJAX du nouvel ordre : la position de chaque ID dans la liste
 * reçue devient son `menu_order`.
 */
add_action('wp_ajax_evolutionr_reorder_realisation', 'evolutionr_realisation_reorder_save');
function evolutionr_realisation_reorder_save(): void
{
    check_ajax_referer('evolutionr_reorder_realisation', 'nonce');

    $ids = isset($_POST['order']) ? array_map('intval', (array) $_POST['order']) : [];
    if (empty($ids)) {
        wp_send_json_error('empty', 400);
    }

    global $wpdb;
    foreach ($ids as $position => $id) {
        if ($id <= 0 || get_post_type($id) !== 'realisation') {
            continue;
        }
        if (!current_user_can('edit_post', $id)) {
            continue;
        }
        // Écriture directe de menu_order : léger, sans re-déclencher les hooks
        // de save (ACF, révisions) sur un simple réordonnancement.
        $wpdb->update($wpdb->posts, ['menu_order' => $position], ['ID' => $id]);
        clean_post_cache($id);
    }

    wp_send_json_success();
}
