<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * L'unique juge des recettes (AD-8) : tout canal d'entrée (API interne,
 * WP-CLI, plus tard REST/admin) passe ici. Frontière → WP_Error explicite,
 * jamais d'exception pour un échec de validation.
 */
final class RecipeValidator
{
    public const CODE_INVALIDE = 'spiralbase_recette_invalide';

    /** @return true|\WP_Error */
    public function validate(array $recette, array $archetype): bool|\WP_Error
    {
        $version = $recette['schema_version'] ?? null;

        if ($version !== RecipeStore::SCHEMA_VERSION) {
            return $this->refus(sprintf(
                'schema_version « %s » non supportée (version courante : %d).',
                is_scalar($version) ? (string) $version : get_debug_type($version),
                RecipeStore::SCHEMA_VERSION
            ));
        }

        if (($recette['archetype'] ?? null) !== ($archetype['slug'] ?? null)) {
            return $this->refus(sprintf(
                'la recette vise l\'archétype « %s », l\'archétype fourni est « %s ».',
                $this->libelle($recette['archetype'] ?? null),
                $this->libelle($archetype['slug'] ?? null)
            ));
        }

        $inconnues = array_diff(array_keys($recette), ['schema_version', 'archetype', 'choix']);

        if ($inconnues !== []) {
            return $this->refus(sprintf(
                'clés inconnues à la racine : %s — la porte canonique ne persiste jamais de données arbitraires.',
                implode(', ', array_map('strval', $inconnues))
            ));
        }

        $choix = $recette['choix'] ?? null;

        if (!is_array($choix)) {
            return $this->refus('« choix » absent ou invalide (map slot → pattern attendue).');
        }

        /* L'archétype vient d'un fichier du parent : le juge ne lui fait pas
           confiance pour autant — malformé, il est refusé proprement, jamais
           d'erreur PHP brute (contrat d'erreurs des frontières). */
        $slots = [];

        foreach ((array) ($archetype['slots'] ?? []) as $slot) {
            $nom = is_array($slot) ? ($slot['nom'] ?? null) : null;

            if (!is_string($nom) || $nom === '') {
                return $this->refusArchetype('slot sans nom valide');
            }

            if (isset($slots[$nom])) {
                return $this->refusArchetype(sprintf('slot « %s » dupliqué', $nom));
            }

            if (!is_array($slot['patterns'] ?? null)) {
                return $this->refusArchetype(sprintf('patterns du slot « %s » absents ou non-liste', $nom));
            }

            $slots[$nom] = $slot;
        }

        foreach ($slots as $nom => $slot) {
            $requis = (bool) ($slot['requis'] ?? false);
            $choisi = $choix[$nom] ?? null;

            if ($choisi === null) {
                if ($requis) {
                    return $this->refus(sprintf('slot requis « %s » sans pattern choisi.', $nom));
                }

                continue;
            }

            if (!in_array($choisi, $slot['patterns'], true)) {
                return $this->refus(sprintf(
                    'pattern inconnu « %s » pour le slot « %s » (autorisés : %s).',
                    $this->libelle($choisi),
                    $nom,
                    implode(', ', array_map('strval', $slot['patterns']))
                ));
            }
        }

        foreach (array_keys($choix) as $nom) {
            if (!isset($slots[$nom])) {
                return $this->refus(sprintf('slot inconnu « %s » — absent de l\'archétype.', (string) $nom));
            }
        }

        return true;
    }

    private function refus(string $detail): \WP_Error
    {
        return new \WP_Error(self::CODE_INVALIDE, 'Recette invalide : ' . $detail);
    }

    private function refusArchetype(string $detail): \WP_Error
    {
        return new \WP_Error(
            'spiralbase_archetype_invalide',
            'Archétype malformé : ' . $detail . ' — corriger le fichier JSON du parent.'
        );
    }

    private function libelle(mixed $valeur): string
    {
        return is_scalar($valeur) ? (string) $valeur : get_debug_type($valeur);
    }
}
