<?php
/**
 * 05 — Méthode : frise des 4 étapes.
 *
 * Visuel : en-tête (eyebrow + titre + lede) puis frise horizontale de 4 étapes
 * reliées par un filet cyan en gradient. Chaque étape : pastille numérotée
 * (l'étape active est en cyan plein) + titre + description + timing en mono.
 *
 * Pilotage ACF (front-page) :
 *   - method_eyebrow, method_title, method_lede.
 *   - method_active_index (n° de l'étape mise en avant, 1 = première).
 *   - method_steps (repeater de { num, title, desc, meta }).
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow = get_field('method_eyebrow') ?: __('Notre méthode', 'evolutionr');
$title   = get_field('method_title') ?: __('Un parcours en 4 étapes, livré en 4 à 6 semaines.', 'evolutionr');
$lede    = get_field('method_lede');

if (!have_rows('method_steps')) {
    return;
}

$activeIndex = (int) (get_field('method_active_index') ?: 2);
?>
<section class="section" aria-labelledby="method-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <h2 class="section-title" id="method-title"><?php echo esc_html($title); ?></h2>
            </div>
            <?php if ($lede): ?>
                <p class="section-lede"><?php echo esc_html($lede); ?></p>
            <?php endif; ?>
        </header>

        <div class="method-track">
            <?php $i = 1; while (have_rows('method_steps')): the_row();
                $num     = get_sub_field('num') ?: str_pad((string) $i, 2, '0', STR_PAD_LEFT);
                $stepTitle = get_sub_field('title');
                $desc    = get_sub_field('desc');
                $meta    = get_sub_field('meta');
                $classes = 'method-step' . ($i === $activeIndex ? ' is-active' : '');
                ?>
                <div class="<?php echo esc_attr($classes); ?>">
                    <div class="method-num"><?php echo esc_html($num); ?></div>
                    <div class="method-step-title"><?php echo esc_html($stepTitle); ?></div>
                    <?php if ($desc): ?>
                        <div class="method-step-desc"><?php echo esc_html($desc); ?></div>
                    <?php endif; ?>
                    <?php if ($meta): ?>
                        <div class="method-step-meta"><?php echo esc_html($meta); ?></div>
                    <?php endif; ?>
                </div>
                <?php $i++;
            endwhile; ?>
        </div>
    </div>
</section>
