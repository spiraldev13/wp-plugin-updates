<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocRdv;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;
use SpiralBase\Core\TexteRiche;

/**
 * Rendu serveur du bloc `spiralbase/rdv` (story 3.4) — un appel à l'action
 * vers la solution de réservation du client.
 *
 * Un LIEN, jamais une iframe : la story 2.5 a établi que les iframes sont
 * hors du périmètre du bandeau de consentement du parent (il ne sait bloquer
 * que les scripts enfilés). Une intégration Calendly ou Doctolib déposerait
 * donc des traceurs tiers avant tout consentement, sur chaque page portant le
 * bloc. Un lien ne dépose rien tant que le visiteur n'a pas cliqué.
 *
 * Sans URL exploitable, le bloc ne rend RIEN (AD-3) : un bouton mort sur une
 * page de réservation coûte plus cher que pas de bouton du tout — et
 * l'opérateur en est averti (NFR13).
 */
final class RenduRdv
{
    public const DEFAUT = 'bouton';

    /** @var list<string> vocabulaire fermé : la valeur finit dans une classe CSS */
    public const VARIANTES = ['bouton', 'bandeau', 'carte'];

    public function __construct(private readonly Options $options)
    {
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs): string
    {
        try {
            return $this->composer($attributs);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_bloc_rdv_echec', 'rendu interrompu : ' . $e->getMessage(), 'bloc rdv');

            return '';
        }
    }

    /** @param array<string, mixed> $attributs */
    private function composer(array $attributs): string
    {
        /* Le signalement appartient à `url()`, seul endroit qui sache
           POURQUOI il n'y a pas d'adresse : deux émissions pour un même
           incident donneraient deux journaux et deux diagnostics. */
        $url = $this->url($attributs);

        if ($url === '') {
            return '';
        }

        $variante = $this->variante($attributs);
        $libelle  = TexteRiche::filtrer($attributs['libelle'] ?? null);

        if (TexteRiche::estVide($libelle)) {
            $libelle = esc_html__('Prendre rendez-vous', 'spiralbase');
        }

        /* L'accroche appartient aux variantes qui l'affichent : l'éditeur ne
           la propose pas en « bouton », le rendu ne doit pas la publier. Sans
           ce juge partagé, une accroche saisie en « carte » restait en ligne
           après bascule en « bouton », invisible dans l'écran d'édition
           (revue 3.4). */
        $accroche = $variante === self::DEFAUT ? '' : TexteRiche::filtrer($attributs['accroche'] ?? null);
        $externe  = $this->estExterne($url);

        $lien = '<a class="spiralbase-rdv__lien wp-element-button" href="' . esc_url($url) . '"'
            /* Nouvel onglet pour un service TIERS seulement : quitter le site
               du client au milieu d'un parcours lui coûte la visite. Pas de
               `nofollow` — c'est l'outil du client, pas un lien subi. */
            . ($externe ? ' target="_blank" rel="noopener"' : '')
            . '>' . $libelle
            /* Un changement de contexte s'annonce (RGAA 13.1 / WCAG 3.2.5) :
               le cas est ici le plus fréquent, une solution de réservation
               étant tierce par nature. */
            . ($externe ? '<span class="screen-reader-text"> ' . esc_html__('(nouvelle fenêtre)', 'spiralbase') . '</span>' : '')
            . '</a>';

        $corps = TexteRiche::estVide($accroche)
            ? $lien
            : '<p class="spiralbase-rdv__accroche">' . $accroche . '</p>' . $lien;

        $classes = 'spiralbase-rdv spiralbase-rdv--' . $variante;

        return '<div ' . EnveloppeBloc::attributs($classes) . '>' . $corps . '</div>';
    }

    /**
     * URL du bloc si elle est renseignée, sinon celle du site.
     *
     * Un site a UNE solution de réservation : la saisir une fois évite qu'un
     * changement de prestataire oblige à rouvrir chaque page. L'attribut
     * n'existe que pour l'exception (« prendre rendez-vous avec le service X »).
     *
     * @param array<string, mixed> $attributs
     */
    private function url(array $attributs): string
    {
        $brut = $attributs['url'] ?? null;

        /* Une surcharge PRÉSENTE mais refusée n'est pas une surcharge absente :
           retomber en silence sur l'adresse du site enverrait les visiteurs
           vers la mauvaise page de réservation, sans que l'opérateur qui s'est
           trompé n'apprenne jamais rien (revue 3.4, NFR13). */
        if (is_string($brut) && trim($brut) !== '') {
            $duBloc = self::urlAcceptable($brut);

            if ($duBloc === '') {
                $this->signalerSansUrl('adresse propre à ce bloc refusée — bouton non affiché plutôt que redirigé vers l\'adresse du site');
            }

            return $duBloc;
        }

        $reglages = $this->options->get(BlocRdvModule::OPTION, []);
        $duSite   = self::urlAcceptable(is_array($reglages) ? ($reglages['url'] ?? null) : null);

        if ($duSite === '') {
            $this->signalerSansUrl('aucune adresse de réservation enregistrée pour ce site : le bouton n\'est pas affiché');
        }

        return $duSite;
    }

    private function signalerSansUrl(string $message): void
    {
        Signal::emettre('spiralbase_bloc_rdv_sans_url', $message, 'bloc rdv');
    }

    /**
     * Seules les adresses http(s) DOTÉES D'UN HÔTE traversent.
     *
     * Le schéma seul ne suffit pas : `https:` et `https:/hote/x` le passaient
     * alors que le premier est un lien mort et que le second, normalisé par
     * les navigateurs en `https://hote/x`, sortait du site sans être reconnu
     * comme externe (revue 3.4). Le contrôle `esc_url_raw` qui suivait était
     * structurellement mort — il ne rejette que les schémas, déjà jugés.
     *
     * La valeur RENDUE est celle qu'`esc_url_raw` a assainie, pas la saisie :
     * contrôler une chaîne et publier l'autre laissait la destination
     * diverger en silence.
     */
    public static function urlAcceptable(mixed $url): string
    {
        if (!is_string($url)) {
            return '';
        }

        $url     = trim($url);
        $parties = parse_url($url);

        if (!is_array($parties)) {
            return '';
        }

        $schema = strtolower((string) ($parties['scheme'] ?? ''));
        $hote   = (string) ($parties['host'] ?? '');

        if (!in_array($schema, ['http', 'https'], true) || $hote === '') {
            return '';
        }

        /* Identifiants dans l'URL : vecteur d'usurpation classique
           (`https://votre-banque.fr@evil.test`), et un mot de passe n'a rien
           à faire dans le HTML public d'un site client. */
        if (isset($parties['user']) || isset($parties['pass'])) {
            return '';
        }

        return (string) esc_url_raw($url);
    }

    /**
     * Interne = MÊME ORIGINE, hôte et port compris. Un `www.` de tête est
     * neutralisé des deux côtés : `www.client.test` et `client.test` sont le
     * même site pour un visiteur, et ouvrir un nouvel onglet vers sa propre
     * page de contact n'a aucun sens.
     */
    private function estExterne(string $url): bool
    {
        return $this->origine($url) !== $this->origine((string) home_url());
    }

    private function origine(string $url): string
    {
        $parties = parse_url($url);

        if (!is_array($parties)) {
            /* Origine illisible : traité comme EXTERNE. Se tromper dans ce
               sens ouvre un onglet de trop ; dans l'autre, on ferait quitter
               le site du client sans retour. */
            return uniqid('illisible', true);
        }

        /* `client.test.` (point final, forme FQDN absolue) et `client.test`
           sont le même hôte pour un navigateur — comme `www.` de tête. */
        $hote = rtrim(strtolower((string) ($parties['host'] ?? '')), '.');

        return preg_replace('/^www\./', '', $hote) . ':' . ($parties['port'] ?? '');
    }

    /** @param array<string, mixed> $attributs */
    private function variante(array $attributs): string
    {
        $valeur = $attributs['variante'] ?? null;

        if (is_string($valeur) && in_array($valeur, self::VARIANTES, true)) {
            return $valeur;
        }

        /* Une valeur PRÉSENTE mais inconnue est une anomalie : sans signal,
           l'opérateur ne verrait qu'une mise en forme « qui ne change pas »
           (même règle qu'en 3.2). */
        if ($valeur !== null && $valeur !== '') {
            Signal::emettre(
                'spiralbase_bloc_rdv_variante_inconnue',
                sprintf(
                    'mise en forme « %s » inconnue, « %s » appliquée',
                    is_scalar($valeur) ? (string) $valeur : get_debug_type($valeur),
                    self::DEFAUT
                ),
                'bloc rdv'
            );
        }

        return self::DEFAUT;
    }
}
