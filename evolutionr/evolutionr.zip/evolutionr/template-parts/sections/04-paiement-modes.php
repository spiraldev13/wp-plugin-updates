<?php
/**
 * 04 — Section Paiement (modes commerciaux : one-shot vs abonnement).
 *
 * Visuel : en-tête (eyebrow + titre + lede) puis grille 2 colonnes des
 * 2 modes (paiement unique / abonnement mensuel), chacun avec argument,
 * points forts et CTA vers /tarifs/. Variante visuelle du mood-quantum :
 * cards $bg-2 sur fond $bg-1, bordure hairline, accent cyan au hover.
 *
 * Pilotage ACF (front-page) : paiement_eyebrow, paiement_title,
 * paiement_lede, paiement_modes (repeater de 2 lignes).
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow = get_field('paiement_eyebrow');
$title   = get_field('paiement_title');
$lede    = get_field('paiement_lede');

if (!have_rows('paiement_modes')) {
    return;
}
?>
<section class="section section-paiement" id="paiement" aria-labelledby="paiement-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <?php if ($eyebrow): ?>
                    <div class="section-eyebrow-wrap">
                        <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($title): ?>
                    <h2 class="section-title" id="paiement-title"><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
            </div>
            <?php if ($lede): ?>
                <p class="section-lede"><?php echo esc_html($lede); ?></p>
            <?php endif; ?>
        </header>

        <div class="paiement-modes">
            <?php while (have_rows('paiement_modes')): the_row();
                $label    = (string) get_sub_field('label');
                $argument = (string) get_sub_field('argument');
                $ctaLabel = (string) get_sub_field('cta_label') ?: __('Voir les tarifs', 'evolutionr');
                $ctaUrl   = (string) get_sub_field('cta_url') ?: '/tarifs/';
                ?>
                <article class="paiement-card">
                    <header class="paiement-card-head">
                        <h3 class="paiement-card-title"><?php echo esc_html($label); ?></h3>
                        <?php if ($argument): ?>
                            <p class="paiement-card-argument"><?php echo esc_html($argument); ?></p>
                        <?php endif; ?>
                    </header>

                    <?php if (have_rows('bullets')): ?>
                        <ul class="paiement-card-list">
                            <?php while (have_rows('bullets')): the_row();
                                $text = (string) get_sub_field('text');
                                if (!$text) continue;
                                ?>
                                <li>
                                    <?php evolutionr_icon('check', 14); ?>
                                    <span><?php echo esc_html($text); ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php endif; ?>

                    <a class="paiement-card-cta btn btn-ghost" href="<?php echo esc_url($ctaUrl); ?>">
                        <span class="btn-inner">
                            <?php echo esc_html($ctaLabel); ?>
                            <?php evolutionr_icon('arrow-right', 14); ?>
                        </span>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</section>
