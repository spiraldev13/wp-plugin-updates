<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enregistre le type de contenu « popup ».
 */
final class PostTypes
{
    public const POPUP = 'spiral_popup';

    public static function register(): void
    {
        add_action('init', [self::class, 'registerPostType']);

        // Priorité haute : passe après un thème ou une extension qui imposerait
        // l'éditeur de blocs.
        add_filter('use_block_editor_for_post_type', [self::class, 'useClassicEditor'], 100, 2);
    }

    /**
     * Éditeur classique pour les popups seulement : quelques lignes de texte
     * s'y éditent plus simplement. Les autres types de contenu sont intacts.
     *
     * @param bool   $useBlockEditor
     * @param string $postType
     * @return bool
     */
    public static function useClassicEditor($useBlockEditor, $postType)
    {
        return $postType === self::POPUP ? false : $useBlockEditor;
    }

    public static function registerPostType(): void
    {
        register_post_type(self::POPUP, [
            'labels' => [
                'name' => __('Popups', 'popup-spiral'),
                'singular_name' => __('Popup', 'popup-spiral'),
                'add_new' => __('Ajouter un popup', 'popup-spiral'),
                'add_new_item' => __('Ajouter un popup', 'popup-spiral'),
                'edit_item' => __('Modifier le popup', 'popup-spiral'),
                'new_item' => __('Nouveau popup', 'popup-spiral'),
                'view_item' => __('Voir le popup', 'popup-spiral'),
                'search_items' => __('Rechercher des popups', 'popup-spiral'),
                'not_found' => __('Aucun popup trouvé', 'popup-spiral'),
                'not_found_in_trash' => __('Aucun popup dans la corbeille', 'popup-spiral'),
                'all_items' => __('Tous les popups', 'popup-spiral'),
                'menu_name' => __('Popups', 'popup-spiral'),
            ],
            'description' => __('Popups affichés sur le site par Popup Spiral.', 'popup-spiral'),
            'public' => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_rest' => true,
            'menu_icon' => self::menuIcon(),
            'hierarchical' => false,
            'has_archive' => false,
            'rewrite' => false,
            'supports' => ['title', 'editor', 'revisions', 'thumbnail'],
            'capability_type' => 'post',
        ]);
    }

    /**
     * Icône du menu en data URI : SVG monochrome que WordPress recolore selon
     * le thème de l'admin et au survol.
     */
    private static function menuIcon(): string
    {
        $path = SPIRAL_POPUP_DIR . 'assets/img/menu-icon.svg';

        if (!is_readable($path)) {
            return 'dashicons-external';
        }

        return 'data:image/svg+xml;base64,' . base64_encode((string) file_get_contents($path));
    }
}
