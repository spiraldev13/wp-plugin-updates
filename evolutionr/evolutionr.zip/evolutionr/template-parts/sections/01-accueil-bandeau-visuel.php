<?php
/**
 * 01b — Visuel SVG du bandeau d'accueil.
 *
 * Visuel : graphe de nœuds connectés (root domain + pillars + pages) avec
 * 3 pulses animés sur les arêtes principales. Représente l'architecture SEO.
 * Inclus depuis sections/01-accueil-bandeau.php — pas appelé directement.
 *
 * Aucun champ ACF : décor fixe.
 */

if (!defined('ABSPATH')) {
    exit;
}

$nodes = [
    ['id' => 'root', 'x' => 50, 'y' => 18, 'r' => 5.4, 'label' => 'Domain'],
    ['id' => 'a',    'x' => 22, 'y' => 40, 'r' => 3.6, 'label' => 'Page'],
    ['id' => 'b',    'x' => 50, 'y' => 42, 'r' => 4.2, 'label' => 'Page'],
    ['id' => 'c',    'x' => 78, 'y' => 40, 'r' => 3.6, 'label' => 'Page'],
    ['id' => 'd',    'x' => 14, 'y' => 66, 'r' => 2.8],
    ['id' => 'e',    'x' => 32, 'y' => 70, 'r' => 2.4],
    ['id' => 'f',    'x' => 44, 'y' => 72, 'r' => 2.6],
    ['id' => 'g',    'x' => 56, 'y' => 72, 'r' => 2.6],
    ['id' => 'h',    'x' => 68, 'y' => 70, 'r' => 2.4],
    ['id' => 'i',    'x' => 86, 'y' => 66, 'r' => 2.8],
    ['id' => 'j',    'x' => 26, 'y' => 88, 'r' => 2.0],
    ['id' => 'k',    'x' => 50, 'y' => 90, 'r' => 2.0],
    ['id' => 'l',    'x' => 74, 'y' => 88, 'r' => 2.0],
];

$edges = [
    ['root', 'a'], ['root', 'b'], ['root', 'c'],
    ['a', 'd'],    ['a', 'e'],
    ['b', 'f'],    ['b', 'g'],
    ['c', 'h'],    ['c', 'i'],
    ['e', 'j'],    ['f', 'k'],    ['h', 'l'],
];

$findNode = function (string $id) use ($nodes) {
    foreach ($nodes as $n) {
        if ($n['id'] === $id) {
            return $n;
        }
    }
    return null;
};
?>
<svg class="hero-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
    <defs>
        <radialGradient id="evolutionr-node-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#22D3EE" stop-opacity="1"/>
            <stop offset="100%" stop-color="#22D3EE" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="evolutionr-edge-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#22D3EE" stop-opacity="0.6"/>
            <stop offset="100%" stop-color="#3B82F6" stop-opacity="0.3"/>
        </linearGradient>
    </defs>

    <?php foreach ($edges as $edge):
        $a = $findNode($edge[0]);
        $b = $findNode($edge[1]);
        if (!$a || !$b) continue;
        ?>
        <line x1="<?php echo esc_attr((string) $a['x']); ?>" y1="<?php echo esc_attr((string) $a['y']); ?>" x2="<?php echo esc_attr((string) $b['x']); ?>" y2="<?php echo esc_attr((string) $b['y']); ?>" stroke="url(#evolutionr-edge-grad)" stroke-width="0.18"/>
    <?php endforeach; ?>

    <?php foreach (array_slice($edges, 0, 3) as $i => $edge):
        $a = $findNode($edge[0]);
        $b = $findNode($edge[1]);
        if (!$a || !$b) continue;
        $begin = ($i * 0.6) . 's';
        ?>
        <circle r="0.6" fill="#22D3EE">
            <animate attributeName="cx" values="<?php echo esc_attr($a['x'] . ';' . $b['x']); ?>" dur="3s" begin="<?php echo esc_attr($begin); ?>" repeatCount="indefinite"/>
            <animate attributeName="cy" values="<?php echo esc_attr($a['y'] . ';' . $b['y']); ?>" dur="3s" begin="<?php echo esc_attr($begin); ?>" repeatCount="indefinite"/>
            <animate attributeName="opacity" values="0;1;0" dur="3s" begin="<?php echo esc_attr($begin); ?>" repeatCount="indefinite"/>
        </circle>
    <?php endforeach; ?>

    <?php foreach ($nodes as $n):
        $isRoot = $n['id'] === 'root';
        ?>
        <g>
            <?php if ($isRoot): ?>
                <circle cx="<?php echo esc_attr((string) $n['x']); ?>" cy="<?php echo esc_attr((string) $n['y']); ?>" r="<?php echo esc_attr((string) ($n['r'] * 2.2)); ?>" fill="url(#evolutionr-node-grad)" opacity="0.5">
                    <animate attributeName="r" values="<?php echo esc_attr(($n['r'] * 1.8) . ';' . ($n['r'] * 2.6) . ';' . ($n['r'] * 1.8)); ?>" dur="3.6s" repeatCount="indefinite"/>
                </circle>
            <?php endif; ?>
            <circle cx="<?php echo esc_attr((string) $n['x']); ?>" cy="<?php echo esc_attr((string) $n['y']); ?>" r="<?php echo esc_attr((string) ($n['r'] * 0.5)); ?>" fill="<?php echo $isRoot ? '#22D3EE' : '#0F1F35'; ?>" stroke="#22D3EE" stroke-width="<?php echo $isRoot ? '0.4' : '0.25'; ?>"/>
            <?php if (!empty($n['label'])): ?>
                <text x="<?php echo esc_attr((string) $n['x']); ?>" y="<?php echo esc_attr((string) ($n['y'] - $n['r'] - 1.5)); ?>" font-size="2" font-family="'JetBrains Mono', ui-monospace, monospace" text-anchor="middle" fill="#94A3B8" letter-spacing="0.18em"><?php echo esc_html(strtoupper($n['label'])); ?></text>
            <?php endif; ?>
        </g>
    <?php endforeach; ?>
</svg>
