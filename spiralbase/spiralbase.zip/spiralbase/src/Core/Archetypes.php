<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Dépôt des archétypes (étage 1 du modèle) : fichiers JSON versionnés du
 * parent, `archetypes/{slug}.json`. Les schémas détaillés arrivent en 4.1 —
 * ici, seul le chargement fiable compte. Aucun échec n'est fatal ni muet :
 * introuvable → null, présent mais illisible → WP_Error précis.
 */
final class Archetypes
{
    public function __construct(private readonly string $repertoire)
    {
    }

    /**
     * @return array|\WP_Error|null null = slug inconnu ; WP_Error = fichier
     *                              présent mais illisible (I/O ou JSON)
     */
    public function get(string $slug): array|\WP_Error|null
    {
        /* Le slug vient potentiellement d'une entrée externe (CLI) : aucun chemin relatif. */
        if (!preg_match('/^[a-z0-9][a-z0-9_-]*$/D', $slug)) {
            return null;
        }

        /* Vérifié à chaque appel : un répertoire disparu après le boot ne
           doit pas se déguiser en « tous les slugs sont inconnus ». */
        if (!is_dir($this->repertoire)) {
            return $this->illisible($slug, sprintf('répertoire d\'archétypes absent (%s)', $this->repertoire));
        }

        $fichier = $this->repertoire . '/' . $slug . '.json';

        if (!is_file($fichier)) {
            return null;
        }

        if (!is_readable($fichier)) {
            return $this->illisible($slug, 'fichier présent mais non lisible (permissions)');
        }

        $brut = file_get_contents($fichier);

        if ($brut === false) {
            return $this->illisible($slug, 'échec de lecture du fichier (I/O)');
        }

        $donnees = json_decode($brut, true);

        if (!is_array($donnees)) {
            return $this->illisible($slug, 'JSON invalide');
        }

        return $donnees;
    }

    private function illisible(string $slug, string $detail): \WP_Error
    {
        do_action('spiralbase_archetype_illisible', $slug, $detail);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf('[spiralbase] archétype « %s » : %s.', $slug, $detail));
        }

        return new \WP_Error(
            'spiralbase_archetype_illisible',
            sprintf('Archétype « %s » présent mais illisible : %s.', $slug, $detail)
        );
    }
}
