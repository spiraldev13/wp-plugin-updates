<?php
/**
 * Hero des pages internes (prestations + Tarifs).
 *
 * Bloc commun : breadcrumb + colonne texte (eyebrow + H1 + sous-titre + CTAs
 * optionnels) + `.page-hero-aside` (carte visuelle `hero-visuel` + mini-stats
 * `hero_stats`). Lit les champs `hero_*` du post courant. Factorisé depuis les
 * 4 pages prestation + `page-tarifs.php`.
 *
 * @param array $args {
 *     @type string $visual_label Libellé mono de la carte visuelle.
 *     @type string $visual_type  Slug du motif (creation|seo|identite|maintenance|configurateur).
 *     @type bool   $show_ctas    Affiche les 2 CTAs hero. Défaut true ; false pour Tarifs.
 *     @type string $extra_class  Classe additionnelle sur la `<section>` (ex. 'page-hero--tarifs').
 * }
 */

if (!defined('ABSPATH')) {
    exit;
}

$visualLabel = isset($args['visual_label']) ? (string) $args['visual_label'] : '';
$visualType  = isset($args['visual_type']) ? (string) $args['visual_type'] : '';
$showCtas    = !isset($args['show_ctas']) || (bool) $args['show_ctas'];
$extraClass  = isset($args['extra_class']) ? (string) $args['extra_class'] : '';

$heroEyebrow = (string) get_field('hero_eyebrow');
$heroTitle   = (string) get_field('hero_title') ?: get_the_title();
$heroSub     = (string) get_field('hero_sub');
$heroCta1Lbl = $showCtas ? (string) get_field('hero_cta1_label') : '';
$heroCta1Url = (string) get_field('hero_cta1_url') ?: '/contact/';
$heroCta2Lbl = $showCtas ? (string) get_field('hero_cta2_label') : '';
$heroCta2Url = (string) get_field('hero_cta2_url');

$sectionClass = 'page-hero page-hero--prestation' . ($extraClass !== '' ? ' ' . $extraClass : '');
?>
<section class="<?php echo esc_attr($sectionClass); ?>" aria-labelledby="page-hero-title">
    <div class="container">

        <?php evolutionr_breadcrumb(); ?>

        <div class="page-hero-grid">
            <div>
                <?php if ($heroEyebrow): ?>
                    <div class="section-eyebrow-wrap" style="margin-bottom: 20px;">
                        <span class="eyebrow"><?php echo esc_html($heroEyebrow); ?></span>
                    </div>
                <?php endif; ?>

                <h1 class="page-hero-title" id="page-hero-title"><?php echo esc_html($heroTitle); ?></h1>

                <?php if ($heroSub): ?>
                    <p class="page-hero-sub"><?php echo esc_html($heroSub); ?></p>
                <?php endif; ?>

                <?php if ($heroCta1Lbl || $heroCta2Lbl): ?>
                    <div class="page-hero-actions">
                        <?php if ($heroCta1Lbl): ?>
                            <a class="btn btn-primary" href="<?php echo esc_url($heroCta1Url); ?>">
                                <?php echo esc_html($heroCta1Lbl); ?>
                                <?php evolutionr_icon('arrow-right', 16); ?>
                            </a>
                        <?php endif; ?>
                        <?php if ($heroCta2Lbl): ?>
                            <a class="btn btn-ghost" href="<?php echo esc_url($heroCta2Url); ?>">
                                <span class="btn-inner">
                                    <?php echo esc_html($heroCta2Lbl); ?>
                                </span>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="page-hero-aside">
                <?php get_template_part('template-parts/cards/hero-visuel', null, [
                    'label'  => $visualLabel,
                    'visual' => $visualType,
                ]); ?>

                <?php if (have_rows('hero_stats')): ?>
                    <div class="page-hero-stats">
                        <?php while (have_rows('hero_stats')): the_row();
                            $sLabel = (string) get_sub_field('label');
                            $sValue = (string) get_sub_field('value');
                            if (!$sValue) continue;
                            ?>
                            <div class="mini-stat">
                                <?php if ($sLabel): ?><div class="label"><?php echo esc_html($sLabel); ?></div><?php endif; ?>
                                <div class="value"><?php echo esc_html($sValue); ?></div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
