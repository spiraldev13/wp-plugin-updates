<?php
/**
 * Motif hero « À propos » — timeline de jalons.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Une ligne verticale ponctuée de jalons (année + intitulé). Unités relatives
 * → responsive 320px → desktop.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Jalons décoratifs (année + intitulé court).
$milestones = [
    ['year' => '2023', 'label' => 'Fondation du projet'],
    ['year' => '2024', 'label' => 'Cap des 20 sites livrés'],
    ['year' => '2025', 'label' => 'Pôle SEO actif'],
    ['year' => 'now',  'label' => 'Sites mesurables, durables'],
];
?>
<div class="hvt">
    <?php foreach ($milestones as $i => $m): ?>
        <div class="hvt-item<?php echo $m['year'] === 'now' ? ' is-now' : ''; ?>" style="--i: <?php echo (int) $i; ?>;">
            <span class="hvt-dot"></span>
            <span class="hvt-year"><?php echo esc_html($m['year']); ?></span>
            <span class="hvt-label"><?php echo esc_html($m['label']); ?></span>
        </div>
    <?php endforeach; ?>
</div>
