<?php

namespace Spiral\Admin;

use Spiral\Compat\Elementor;
use Spiral\Designs\Repository;
use Spiral\Frontend;
use Spiral\PostTypes;
use Spiral\Presets\Repository as PresetRepository;
use Spiral\Preview;
use Spiral\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Metabox à onglets de l'éditeur de popup : Affichage / Déclencheurs /
 * Ciblage / Planification. Tout se règle en cliquant sur ce qu'on obtient.
 */
final class Metabox
{
    private const NONCE_ACTION = 'spiral_popup_settings';
    private const NONCE_FIELD = '_spiral_nonce';

    /** Libellés des 9 positions + 2 barres, dans l'ordre de la grille. */
    private const POSITION_LABELS = [
        'top-left' => 'En haut à gauche',
        'top-center' => 'En haut au centre',
        'top-right' => 'En haut à droite',
        'center-left' => 'Au centre à gauche',
        'center' => 'Au centre',
        'center-right' => 'Au centre à droite',
        'bottom-left' => 'En bas à gauche',
        'bottom-center' => 'En bas au centre',
        'bottom-right' => 'En bas à droite',
    ];

    public static function register(): void
    {
        add_action('add_meta_boxes_' . PostTypes::POPUP, [self::class, 'addMetabox']);
        add_action('save_post_' . PostTypes::POPUP, [self::class, 'save'], 10, 2);
        add_action('admin_notices', [self::class, 'presetAppliedNotice']);
    }

    /**
     * Confirmation après application d'un preset (retour à l'éditeur).
     */
    public static function presetAppliedNotice(): void
    {
        if (empty($_GET['spiral_preset_applied']) || get_current_screen() === null) {
            return;
        }

        if (get_current_screen()->id !== PostTypes::POPUP) {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>'
            . esc_html__('Preset appliqué. Vérifiez les réglages puis mettez à jour le popup.', 'popup-spiral')
            . '</p></div>';
    }

    public static function addMetabox(): void
    {
        add_meta_box(
            'spiral-popup-settings',
            __('Réglages du popup', 'popup-spiral'),
            [self::class, 'render'],
            PostTypes::POPUP,
            'normal',
            'high'
        );
    }

    public static function render(\WP_Post $post): void
    {
        $settings = Settings::get($post->ID);

        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);
        ?>
        <div class="spiral-admin spiral-metabox">
            <?php self::renderHeaderBar($post); ?>
            <nav class="spiral-tabs" role="tablist">
                <button type="button" class="spiral-tab is-active" data-tab="affichage"><?php esc_html_e('Affichage', 'popup-spiral'); ?></button>
                <button type="button" class="spiral-tab" data-tab="declencheurs"><?php esc_html_e('Déclencheurs', 'popup-spiral'); ?></button>
                <button type="button" class="spiral-tab" data-tab="ciblage"><?php esc_html_e('Ciblage', 'popup-spiral'); ?></button>
                <button type="button" class="spiral-tab" data-tab="planification"><?php esc_html_e('Planification', 'popup-spiral'); ?></button>
            </nav>

            <div class="spiral-tab-panel is-active" data-panel="affichage">
                <?php self::renderDisplayTab($post, $settings); ?>
            </div>
            <div class="spiral-tab-panel" data-panel="declencheurs">
                <?php self::renderTriggersTab($post, $settings); ?>
            </div>
            <div class="spiral-tab-panel" data-panel="ciblage">
                <?php self::renderTargetingTab($settings); ?>
            </div>
            <div class="spiral-tab-panel" data-panel="planification">
                <?php self::renderScheduleTab($settings); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Bandeau d'en-tête : statut d'affichage calculé + bouton de prévisualisation
     * sécurisée. Clarifie « autorisation manuelle (toggle) » vs « état calculé ».
     */
    private static function renderHeaderBar(\WP_Post $post): void
    {
        $status = Frontend::displayStatus((int) $post->ID);
        $badgeClass = $status['can'] ? 'spiral-badge-active' : 'spiral-badge-off';
        $prefix = $status['can'] ? '' : __('Masqué : ', 'popup-spiral');
        ?>
        <div class="spiral-headerbar">
            <span class="spiral-headerbar-status">
                <?php esc_html_e('Statut actuel :', 'popup-spiral'); ?>
                <span class="spiral-badge <?php echo esc_attr($badgeClass); ?>"><?php echo esc_html($prefix . $status['label']); ?></span>
            </span>
            <a class="button" href="<?php echo esc_url(Preview::url((int) $post->ID)); ?>" target="_blank" rel="noopener">
                <?php esc_html_e('Prévisualiser', 'popup-spiral'); ?>
            </a>
        </div>
        <p class="spiral-headerbar-help description">
            <?php esc_html_e('« Actif » (liste des popups) est une autorisation manuelle : sur OFF, le popup ne s\'affiche jamais, même planifié. L\'état ci-dessus est calculé à partir de toutes les conditions (publication, activation, ciblage, planification, contenu). La prévisualisation fonctionne même pour un brouillon ou un popup désactivé, sans compter de statistique.', 'popup-spiral'); ?>
        </p>
        <?php
    }

    /**
     * Contrôles de presets dans l'onglet Affichage : appliquer un preset
     * existant (sections au choix) et enregistrer les réglages actuels en preset.
     *
     * Les actions passent par des formulaires détachés soumis en JS : la metabox
     * est déjà dans le formulaire d'édition du post, on ne peut pas y imbriquer
     * d'autres <form>.
     */
    private static function renderPresetControls(\WP_Post $post): void
    {
        $presets = PresetRepository::all();
        $sectionLabels = [
            'display' => __('Affichage', 'popup-spiral'),
            'button' => __('Bouton', 'popup-spiral'),
            'triggers' => __('Déclencheurs', 'popup-spiral'),
            'frequency' => __('Fréquence', 'popup-spiral'),
        ];
        ?>
        <div class="spiral-preset-controls"
             data-popup="<?php echo (int) $post->ID; ?>"
             data-apply-nonce="<?php echo esc_attr(wp_create_nonce('spiral_preset_apply_' . $post->ID)); ?>"
             data-create-nonce="<?php echo esc_attr(wp_create_nonce('spiral_preset_create')); ?>"
             data-action-url="<?php echo esc_url(admin_url('admin-post.php')); ?>"
             data-return-url="<?php echo esc_url(get_edit_post_link($post->ID, 'url')); ?>"
             data-confirm="<?php esc_attr_e('Appliquer ce preset remplacera les réglages choisis et rechargera l\'éditeur. Les modifications non enregistrées seront perdues. Continuer ?', 'popup-spiral'); ?>"
             data-alert-sections="<?php esc_attr_e('Cochez au moins une catégorie de réglages à appliquer.', 'popup-spiral'); ?>"
             data-alert-name="<?php esc_attr_e('Donnez un nom au preset.', 'popup-spiral'); ?>">

            <?php if ($presets !== []) : ?>
                <div class="spiral-preset-apply">
                    <strong><?php esc_html_e('Appliquer un preset', 'popup-spiral'); ?></strong>
                    <select class="spiral-preset-select">
                        <?php foreach ($presets as $slug => $preset) : ?>
                            <option value="<?php echo esc_attr($slug); ?>" data-targeting="<?php echo !empty($preset['includes_targeting']) ? '1' : '0'; ?>">
                                <?php echo esc_html($preset['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="spiral-preset-sections">
                        <?php foreach ($sectionLabels as $key => $label) : ?>
                            <label><input type="checkbox" class="spiral-preset-section" value="<?php echo esc_attr($key); ?>" checked> <?php echo esc_html($label); ?></label>
                        <?php endforeach; ?>
                        <label class="spiral-preset-section-targeting"><input type="checkbox" class="spiral-preset-section" value="targeting" disabled> <?php esc_html_e('Ciblage', 'popup-spiral'); ?></label>
                    </span>
                    <button type="button" class="button spiral-preset-apply-btn"><?php esc_html_e('Appliquer', 'popup-spiral'); ?></button>
                </div>
            <?php endif; ?>

            <div class="spiral-preset-save">
                <strong><?php esc_html_e('Enregistrer ces réglages comme preset', 'popup-spiral'); ?></strong>
                <input type="text" class="spiral-preset-name" placeholder="<?php esc_attr_e('Nom du preset', 'popup-spiral'); ?>">
                <label><input type="checkbox" class="spiral-preset-include-targeting"> <?php esc_html_e('Inclure le ciblage', 'popup-spiral'); ?></label>
                <button type="button" class="button spiral-preset-save-btn"><?php esc_html_e('Enregistrer en preset', 'popup-spiral'); ?></button>
                <span class="description"><?php esc_html_e('Basé sur les réglages enregistrés — pensez à mettre à jour le popup d\'abord.', 'popup-spiral'); ?></span>
            </div>

            <p class="description">
                <a href="<?php echo esc_url(PresetsPage::pageUrl()); ?>"><?php esc_html_e('Gérer les presets →', 'popup-spiral'); ?></a>
            </p>
        </div>
        <?php
    }

    /**
     * @param int      $postId
     * @param \WP_Post $post
     */
    public static function save($postId, $post): void
    {
        if (!isset($_POST[self::NONCE_FIELD])
            || !wp_verify_nonce((string) $_POST[self::NONCE_FIELD], self::NONCE_ACTION)
        ) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (wp_is_post_revision($postId) || !current_user_can('edit_post', $postId)) {
            return;
        }

        $raw = isset($_POST['spiral']) && is_array($_POST['spiral'])
            ? wp_unslash($_POST['spiral'])
            : [];

        $raw = self::syncImage((int) $postId, $raw);

        Settings::save((int) $postId, $raw);
    }

    /**
     * Une seule image, deux points d'entrée : si le champ du panneau a changé
     * depuis le rendu du formulaire, il gagne (répercuté sur l'image mise en
     * avant) ; sinon l'image mise en avant fait référence.
     */
    private static function syncImage(int $postId, array $raw): array
    {
        $panelId = isset($raw['display']['image']['id']) ? max(0, (int) $raw['display']['image']['id']) : 0;
        // Champ témoin posé au rendu : insensible à l'ordre des hooks WP
        // (le cœur enregistre _thumbnail_id avant save_post).
        $prevId = isset($_POST['spiral_image_prev']) ? max(0, (int) $_POST['spiral_image_prev']) : $panelId;

        if ($panelId !== $prevId) {
            \Spiral\ImageSync::applyPanelChoice($postId, $panelId);

            return $raw;
        }

        // Éditeur classique : _thumbnail_id arrive dans le même POST (-1 = retirée) ;
        // éditeur de blocs : la requête REST a déjà enregistré le thumbnail.
        $thumbId = isset($_POST['_thumbnail_id'])
            ? max(0, (int) $_POST['_thumbnail_id'])
            : (int) get_post_thumbnail_id($postId);

        if ($thumbId !== $panelId) {
            $raw['display']['image']['id'] = $thumbId;
        }

        return $raw;
    }

    /* ---------- Onglet Affichage ---------- */

    private static function renderDisplayTab(\WP_Post $post, array $settings): void
    {
        $display = $settings['display'];
        self::renderPresetControls($post);
        ?>
        <h3><?php esc_html_e('Quel design ?', 'popup-spiral'); ?></h3>
        <div class="spiral-design-gallery">
            <?php foreach (Repository::all() as $slug => $design) : ?>
                <label class="spiral-design-card">
                    <input type="radio" name="spiral[display][design]" value="<?php echo esc_attr($slug); ?>" <?php checked($display['design'], $slug); ?> />
                    <span class="spiral-design-thumb" style="<?php echo esc_attr(self::thumbStyle($design['settings'])); ?>">
                        <span class="spiral-design-thumb-bar" style="background: <?php echo esc_attr($design['settings']['accent']); ?>;"></span>
                    </span>
                    <span class="spiral-design-name">
                        <?php echo esc_html($design['name']); ?>
                        <?php if ($design['builtin']) : ?>
                            <em><?php esc_html_e('Fourni', 'popup-spiral'); ?></em>
                        <?php endif; ?>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>
        <p class="description">
            <a href="<?php echo esc_url(admin_url('edit.php?post_type=' . PostTypes::POPUP . '&page=spiral-designs')); ?>">
                <?php esc_html_e('Créer ou modifier un design →', 'popup-spiral'); ?>
            </a>
        </p>

        <h3><?php esc_html_e('Où sur l\'écran ?', 'popup-spiral'); ?></h3>
        <div class="spiral-position-wrap">
            <div class="spiral-pos-grid" role="radiogroup" aria-label="<?php esc_attr_e('Position du popup', 'popup-spiral'); ?>">
                <?php foreach (self::POSITION_LABELS as $value => $label) : ?>
                    <label class="spiral-pos-cell" title="<?php echo esc_attr($label); ?>">
                        <input type="radio" name="spiral[display][position]" value="<?php echo esc_attr($value); ?>" <?php checked($display['position'], $value); ?> />
                        <span></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="spiral-pos-bars">
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][position]" value="bar-top" <?php checked($display['position'], 'bar-top'); ?> />
                    <span><?php esc_html_e('Barre flottante en haut', 'popup-spiral'); ?></span>
                </label>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][position]" value="bar-bottom" <?php checked($display['position'], 'bar-bottom'); ?> />
                    <span><?php esc_html_e('Barre flottante en bas', 'popup-spiral'); ?></span>
                </label>
            </div>
        </div>

        <h3><?php esc_html_e('Quelle taille ?', 'popup-spiral'); ?></h3>
        <?php
        $sizes = Settings::sizeChoices();
        $currentSize = $display['size'];

        // Taille réutilisable supprimée depuis les Réglages : repli visible.
        if (!isset($sizes[$currentSize])) {
            $currentSize = Settings::defaultSize();
            ?>
            <p class="description spiral-size-fallback">
                <?php esc_html_e('La taille personnalisée utilisée par ce popup a été supprimée — repli sur la taille par défaut.', 'popup-spiral'); ?>
            </p>
            <?php
        }
        ?>
        <div class="spiral-choice-row">
            <?php foreach ($sizes as $value => $label) : ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][size]" value="<?php echo esc_attr($value); ?>" <?php checked($currentSize, $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <p class="description">
            <a href="<?php echo esc_url(admin_url('edit.php?post_type=' . PostTypes::POPUP . '&page=spiral-settings')); ?>">
                <?php esc_html_e('Créer des tailles réutilisables dans les Réglages →', 'popup-spiral'); ?>
            </a>
        </p>
        <p class="spiral-custom-size">
            <?php esc_html_e('Largeur :', 'popup-spiral'); ?>
            <input type="number" name="spiral[display][custom_width]" value="<?php echo esc_attr($display['custom_width']); ?>" min="200" max="2000" step="10" class="spiral-input-small" />
            <?php esc_html_e('pixels (bornée à la largeur de l\'écran)', 'popup-spiral'); ?>
        </p>

        <p><strong><?php esc_html_e('Hauteur', 'popup-spiral'); ?></strong></p>
        <div class="spiral-choice-row">
            <label class="spiral-choice-card">
                <input type="radio" name="spiral[display][height]" value="auto" <?php checked($display['height'], 'auto'); ?> />
                <span><?php esc_html_e('Automatique (selon le contenu)', 'popup-spiral'); ?></span>
            </label>
            <label class="spiral-choice-card">
                <input type="radio" name="spiral[display][height]" value="custom" <?php checked($display['height'], 'custom'); ?> />
                <span><?php esc_html_e('Personnalisée', 'popup-spiral'); ?></span>
            </label>
        </div>
        <p class="spiral-custom-height">
            <?php esc_html_e('Hauteur :', 'popup-spiral'); ?>
            <input type="number" name="spiral[display][custom_height]" value="<?php echo esc_attr($display['custom_height']); ?>" min="100" max="2000" step="10" class="spiral-input-small" />
            <?php esc_html_e('pixels', 'popup-spiral'); ?>
        </p>

        <p><strong><?php esc_html_e('Taille du texte', 'popup-spiral'); ?></strong></p>
        <p>
            <input type="number" name="spiral[display][text_size]" value="<?php echo (int) $display['text_size']; ?>" min="10" max="40" class="spiral-input-small" />
            <?php esc_html_e('pixels (les titres s\'adaptent proportionnellement)', 'popup-spiral'); ?>
        </p>

        <p><strong><?php esc_html_e('Position du texte', 'popup-spiral'); ?></strong></p>
        <div class="spiral-choice-row">
            <?php
            $valigns = [
                'top' => __('En haut', 'popup-spiral'),
                'center' => __('Au centre', 'popup-spiral'),
                'bottom' => __('En bas', 'popup-spiral'),
            ];
            foreach ($valigns as $value => $label) :
                ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][content_valign]" value="<?php echo esc_attr($value); ?>" <?php checked($display['content_valign'], $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <p class="description"><?php esc_html_e('Visible quand le cadre est plus haut que le texte (hauteur personnalisée).', 'popup-spiral'); ?></p>

        <?php self::renderImageSection($display['image']); ?>
        <?php self::renderButtonSection($settings['button']); ?>
        <?php self::renderContentSource($settings); ?>

        <details class="spiral-advanced">
            <summary><?php esc_html_e('Avancé', 'popup-spiral'); ?></summary>
            <label>
                <?php esc_html_e('Z-index (superposition)', 'popup-spiral'); ?>
                <input type="number" name="spiral[display][zindex]" value="<?php echo esc_attr($display['zindex']); ?>" min="1" />
            </label>
            <p class="description"><?php esc_html_e('Ne modifier que si le popup passe sous un élément du site.', 'popup-spiral'); ?></p>
        </details>
        <?php
    }

    /**
     * Image du popup : disposition, choix en médiathèque et taille d'affichage.
     */
    private static function renderImageSection(array $image): void
    {
        $imageUrl = $image['id'] > 0 ? wp_get_attachment_image_url((int) $image['id'], 'medium') : '';
        ?>
        <h3><?php esc_html_e('Une image ?', 'popup-spiral'); ?></h3>
        <div class="spiral-choice-row">
            <?php
            $layouts = [
                'none' => __('Aucune', 'popup-spiral'),
                'banner' => __('Bannière en haut', 'popup-spiral'),
                'left' => __('À gauche', 'popup-spiral'),
                'right' => __('À droite', 'popup-spiral'),
                'background' => __('En fond', 'popup-spiral'),
            ];
            foreach ($layouts as $value => $label) :
                ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][image][layout]" value="<?php echo esc_attr($value); ?>" <?php checked($image['layout'], $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>

        <div class="spiral-media-field spiral-image-field">
            <input type="hidden" name="spiral[display][image][id]" value="<?php echo (int) $image['id']; ?>" class="spiral-media-id" />
            <input type="hidden" name="spiral_image_prev" value="<?php echo (int) $image['id']; ?>" />
            <button type="button" class="button spiral-media-pick"><?php esc_html_e('Choisir dans la médiathèque', 'popup-spiral'); ?></button>
            <button type="button" class="button spiral-media-remove" <?php echo $imageUrl === '' ? 'hidden' : ''; ?>><?php esc_html_e('Retirer l\'image', 'popup-spiral'); ?></button>
            <div class="spiral-image-thumb">
                <img class="spiral-media-preview" src="<?php echo esc_url($imageUrl); ?>" alt="" <?php echo $imageUrl === '' ? 'hidden' : ''; ?> />
            </div>
        </div>
        <p class="description"><?php esc_html_e('L\'image choisie ici est aussi l\'image mise en avant du popup, et réciproquement — la retirer la retire des deux côtés.', 'popup-spiral'); ?></p>

        <p><strong><?php esc_html_e('Largeur de l\'image', 'popup-spiral'); ?></strong></p>
        <div class="spiral-choice-row">
            <?php
            $imageWidths = [
                100 => __('Pleine (100 %)', 'popup-spiral'),
                75 => __('Grande (75 %)', 'popup-spiral'),
                50 => __('Moitié (50 %)', 'popup-spiral'),
                25 => __('Petite (25 %)', 'popup-spiral'),
            ];

            // Largeurs personnalisées ajoutées dans les Réglages.
            foreach (Settings::sizePresets()['image_widths'] as $customWidth) {
                /* translators: %d : largeur en pourcentage */
                $imageWidths[$customWidth] = sprintf(__('%d %%', 'popup-spiral'), $customWidth);
            }

            krsort($imageWidths);
            foreach ($imageWidths as $value => $label) :
                ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][image][width]" value="<?php echo (int) $value; ?>" <?php checked((int) $image['width'], $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <p class="description"><?php esc_html_e('Pour une image à gauche ou à droite, la largeur est plafonnée à la moitié du popup.', 'popup-spiral'); ?></p>

        <p><strong><?php esc_html_e('Espacement autour de l\'image', 'popup-spiral'); ?></strong></p>
        <div class="spiral-choice-row">
            <?php
            $paddings = [
                'none' => __('Aucun', 'popup-spiral'),
                'small' => __('Petit (12px)', 'popup-spiral'),
                'medium' => __('Moyen (24px)', 'popup-spiral'),
                'custom' => __('Personnalisé', 'popup-spiral'),
            ];
            foreach ($paddings as $value => $label) :
                ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][image][padding]" value="<?php echo esc_attr($value); ?>" <?php checked($image['padding'], $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <p class="spiral-custom-imgpad">
            <?php esc_html_e('Espacement :', 'popup-spiral'); ?>
            <input type="number" name="spiral[display][image][custom_padding]" value="<?php echo esc_attr($image['custom_padding']); ?>" min="0" max="100" class="spiral-input-small" />
            <?php esc_html_e('pixels', 'popup-spiral'); ?>
        </p>

        <p><strong><?php esc_html_e('Bordure autour de l\'image', 'popup-spiral'); ?></strong></p>
        <div class="spiral-choice-row">
            <?php
            $borders = [
                'none' => __('Aucune', 'popup-spiral'),
                'thin' => __('Fine (1px)', 'popup-spiral'),
                'thick' => __('Épaisse (3px)', 'popup-spiral'),
                'custom' => __('Personnalisée', 'popup-spiral'),
            ];
            foreach ($borders as $value => $label) :
                ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[display][image][border]" value="<?php echo esc_attr($value); ?>" <?php checked($image['border'], $value); ?> />
                    <span><?php echo esc_html($label); ?></span>
                </label>
            <?php endforeach; ?>
            <label class="spiral-border-color">
                <?php esc_html_e('Couleur :', 'popup-spiral'); ?>
                <input type="color" name="spiral[display][image][border_color]" value="<?php echo esc_attr($image['border_color']); ?>" class="spiral-color-input" />
            </label>
        </div>
        <p class="spiral-conditional" data-when="spiral[display][image][border]" data-value="custom">
            <?php esc_html_e('Épaisseur :', 'popup-spiral'); ?>
            <input type="number" name="spiral[display][image][border_width]" value="<?php echo (int) $image['border_width']; ?>" min="1" max="20" class="spiral-input-small" />
            <?php esc_html_e('pixels', 'popup-spiral'); ?>
        </p>
        <?php
    }

    /**
     * Bouton d'action optionnel : libellé + destination (page du site ou URL).
     */
    private static function renderButtonSection(array $button): void
    {
        ?>
        <h3><?php esc_html_e('Un bouton d\'action ?', 'popup-spiral'); ?></h3>
        <div class="spiral-card">
            <label class="spiral-card-head">
                <input type="checkbox" name="spiral[button][enabled]" value="1" <?php checked($button['enabled']); ?> />
                <strong><?php esc_html_e('Ajouter un bouton qui redirige le visiteur', 'popup-spiral'); ?></strong>
            </label>

            <p>
                <label>
                    <?php esc_html_e('Texte du bouton', 'popup-spiral'); ?><br />
                    <input type="text" name="spiral[button][label]" value="<?php echo esc_attr($button['label']); ?>" placeholder="<?php esc_attr_e('Ex. Découvrir l\'offre', 'popup-spiral'); ?>" class="regular-text" />
                </label>
            </p>

            <div class="spiral-choice-row">
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[button][target]" value="page" <?php checked($button['target'], 'page'); ?> />
                    <span><?php esc_html_e('Vers une page du site', 'popup-spiral'); ?></span>
                </label>
                <label class="spiral-choice-card">
                    <input type="radio" name="spiral[button][target]" value="url" <?php checked($button['target'], 'url'); ?> />
                    <span><?php esc_html_e('Vers une adresse web (URL)', 'popup-spiral'); ?></span>
                </label>
            </div>

            <p class="spiral-button-page" data-show-target="page">
                <select name="spiral[button][page]">
                    <option value="0"><?php esc_html_e('— Choisir une page —', 'popup-spiral'); ?></option>
                    <option value="-1" <?php selected((int) $button['page'], -1); ?>><?php esc_html_e('Page d\'accueil', 'popup-spiral'); ?></option>
                    <?php foreach (get_pages(['sort_column' => 'post_title']) as $page) : ?>
                        <option value="<?php echo (int) $page->ID; ?>" <?php selected((int) $button['page'], $page->ID); ?>>
                            <?php echo esc_html($page->post_title !== '' ? $page->post_title : ('#' . $page->ID)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>
            <p class="spiral-button-url" data-show-target="url">
                <input type="url" name="spiral[button][url]" value="<?php echo esc_attr($button['url']); ?>" placeholder="https://…" class="regular-text" />
            </p>

            <p><strong><?php esc_html_e('Position du bouton', 'popup-spiral'); ?></strong></p>
            <div class="spiral-choice-row">
                <?php
                $aligns = [
                    'left' => __('À gauche', 'popup-spiral'),
                    'center' => __('Au milieu', 'popup-spiral'),
                    'right' => __('À droite', 'popup-spiral'),
                ];
                foreach ($aligns as $value => $label) :
                    ?>
                    <label class="spiral-choice-card">
                        <input type="radio" name="spiral[button][align]" value="<?php echo esc_attr($value); ?>" <?php checked($button['align'], $value); ?> />
                        <span><?php echo esc_html($label); ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <p>
                <strong><?php esc_html_e('Taille du texte du bouton', 'popup-spiral'); ?></strong><br />
                <input type="number" name="spiral[button][text_size]" value="<?php echo (int) $button['text_size']; ?>" min="10" max="40" class="spiral-input-small" />
                <?php esc_html_e('pixels', 'popup-spiral'); ?>
            </p>

            <label>
                <input type="checkbox" name="spiral[button][new_tab]" value="1" <?php checked($button['new_tab']); ?> />
                <?php esc_html_e('Ouvrir dans un nouvel onglet', 'popup-spiral'); ?>
            </label>
        </div>
        <?php
    }

    private static function renderContentSource(array $settings): void
    {
        if (!Elementor::isActive()) {
            return;
        }

        $source = $settings['content_source'];
        $templates = Elementor::templatesList();
        ?>
        <h3><?php esc_html_e('Quel contenu ?', 'popup-spiral'); ?></h3>
        <div class="spiral-choice-row">
            <label class="spiral-choice-card">
                <input type="radio" name="spiral[content_source][type]" value="editor" <?php checked($source['type'], 'editor'); ?> />
                <span><?php esc_html_e('L\'éditeur ci-dessus', 'popup-spiral'); ?></span>
            </label>
            <label class="spiral-choice-card">
                <input type="radio" name="spiral[content_source][type]" value="elementor_template" <?php checked($source['type'], 'elementor_template'); ?> />
                <span><?php esc_html_e('Un template Elementor', 'popup-spiral'); ?></span>
            </label>
        </div>
        <div class="spiral-elementor-picker" data-show-if="elementor_template">
            <select name="spiral[content_source][elementor_template]">
                <option value="0"><?php esc_html_e('— Choisir un template —', 'popup-spiral'); ?></option>
                <?php foreach ($templates as $id => $title) : ?>
                    <option value="<?php echo (int) $id; ?>" <?php selected($source['elementor_template'], $id); ?>>
                        <?php echo esc_html($title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php
    }

    /* ---------- Onglet Déclencheurs ---------- */

    private static function renderTriggersTab(\WP_Post $post, array $settings): void
    {
        $triggers = $settings['triggers'];
        $frequency = $settings['frequency'];
        ?>
        <h3><?php esc_html_e('Quand l\'afficher ?', 'popup-spiral'); ?></h3>

        <div class="spiral-card">
            <label class="spiral-card-head">
                <input type="checkbox" name="spiral[triggers][delay_enabled]" value="1" <?php checked($triggers['delay_enabled']); ?> />
                <strong><?php esc_html_e('Automatiquement, après un délai', 'popup-spiral'); ?></strong>
            </label>
            <p>
                <?php esc_html_e('Afficher après', 'popup-spiral'); ?>
                <input type="number" name="spiral[triggers][delay]" value="<?php echo esc_attr($triggers['delay']); ?>" min="0" max="600" class="spiral-input-small" />
                <?php esc_html_e('secondes', 'popup-spiral'); ?>
            </p>
        </div>

        <div class="spiral-card">
            <label class="spiral-card-head">
                <input type="checkbox" name="spiral[triggers][click_enabled]" value="1" <?php checked($triggers['click_enabled']); ?> />
                <strong><?php esc_html_e('Au clic sur un bouton ou un lien', 'popup-spiral'); ?></strong>
            </label>
            <p class="description">
                <?php esc_html_e('Ajoutez cette classe CSS à n\'importe quel bouton (Divi, Elementor, menu…) :', 'popup-spiral'); ?>
            </p>
            <p>
                <code>spiral-<?php echo (int) $post->ID; ?></code>
                <button type="button" class="button button-small spiral-copy" data-copy="spiral-<?php echo (int) $post->ID; ?>"><?php esc_html_e('Copier', 'popup-spiral'); ?></button>
                &nbsp;<?php esc_html_e('ou un lien vers', 'popup-spiral'); ?>&nbsp;
                <code>#spiral-<?php echo (int) $post->ID; ?></code>
                <button type="button" class="button button-small spiral-copy" data-copy="#spiral-<?php echo (int) $post->ID; ?>"><?php esc_html_e('Copier', 'popup-spiral'); ?></button>
            </p>
            <details class="spiral-advanced">
                <summary><?php esc_html_e('Avancé', 'popup-spiral'); ?></summary>
                <label>
                    <?php esc_html_e('Sélecteur CSS libre (optionnel)', 'popup-spiral'); ?>
                    <input type="text" name="spiral[triggers][click_selector]" value="<?php echo esc_attr($triggers['click_selector']); ?>" placeholder=".ma-classe, #mon-bouton" />
                </label>
            </details>
        </div>

        <div class="spiral-card">
            <label class="spiral-card-head">
                <input type="checkbox" name="spiral[triggers][exit_intent]" value="1" <?php checked($triggers['exit_intent']); ?> />
                <strong><?php esc_html_e('Quand le visiteur s\'apprête à quitter la page', 'popup-spiral'); ?></strong>
            </label>
            <p class="description">
                <?php esc_html_e('Détection du curseur qui sort par le haut de la fenêtre (ordinateur uniquement — sur mobile, le délai ci-dessus prend le relais).', 'popup-spiral'); ?>
            </p>
        </div>

        <h3><?php esc_html_e('Fermeture', 'popup-spiral'); ?></h3>
        <div class="spiral-card">
            <label class="spiral-card-head">
                <input type="checkbox" name="spiral[triggers][no_overlay_close]" value="1" <?php checked($triggers['no_overlay_close']); ?> />
                <strong><?php esc_html_e('Ne pas fermer en cliquant à l\'extérieur', 'popup-spiral'); ?></strong>
            </label>
            <p class="description">
                <?php esc_html_e('Par défaut, cliquer sur le fond ferme le popup. Cochez pour n\'autoriser la fermeture que via la croix ou la touche Échap — utile pour une action importante. Sans effet si le fond est réglé sur « Aucun ».', 'popup-spiral'); ?>
            </p>
        </div>

        <h3><?php esc_html_e('À quelle fréquence ?', 'popup-spiral'); ?></h3>
        <div class="spiral-card">
            <select name="spiral[frequency][mode]" class="spiral-frequency-mode">
                <option value="always" <?php selected($frequency['mode'], 'always'); ?>><?php esc_html_e('À chaque visite', 'popup-spiral'); ?></option>
                <option value="session" <?php selected($frequency['mode'], 'session'); ?>><?php esc_html_e('Une fois par session de navigation', 'popup-spiral'); ?></option>
                <option value="days" <?php selected($frequency['mode'], 'days'); ?>><?php esc_html_e('Une fois tous les N jours', 'popup-spiral'); ?></option>
                <option value="forever" <?php selected($frequency['mode'], 'forever'); ?>><?php esc_html_e('Une seule fois (ne plus jamais montrer)', 'popup-spiral'); ?></option>
            </select>
            <span class="spiral-frequency-days">
                <input type="number" name="spiral[frequency][days]" value="<?php echo esc_attr($frequency['days']); ?>" min="1" max="<?php echo (int) Settings::MAX_FREQUENCY_DAYS; ?>" class="spiral-input-small" />
                <?php esc_html_e('jours', 'popup-spiral'); ?>
            </span>
            <p class="description">
                <?php esc_html_e('Géré par un cookie fonctionnel anonyme, conforme RGPD — rien à configurer.', 'popup-spiral'); ?>
            </p>
            <p class="description">
                <strong><?php esc_html_e('Pour tester :', 'popup-spiral'); ?></strong>
                <?php esc_html_e('une fois le popup fermé, votre navigateur ne le remontre plus selon cette règle. Ajoutez « ?spiral-test » à l\'adresse de la page pour l\'ignorer, ou utilisez une fenêtre de navigation privée.', 'popup-spiral'); ?>
                <?php $spiralTestUrl = TestLink::urlFor((int) get_the_ID()); ?>
                <?php if ($spiralTestUrl !== '') : ?>
                    <a href="<?php echo esc_url($spiralTestUrl); ?>" target="_blank" rel="noopener"><?php esc_html_e('Ouvrir une page ciblée en mode test →', 'popup-spiral'); ?></a>
                <?php endif; ?>
            </p>
        </div>
        <?php
    }

    /* ---------- Onglet Ciblage ---------- */

    private static function renderTargetingTab(array $settings): void
    {
        $targeting = $settings['targeting'];
        ?>
        <h3><?php esc_html_e('Où l\'afficher ?', 'popup-spiral'); ?></h3>
        <p class="description"><?php esc_html_e('Cochez une ou plusieurs cibles — le popup s\'affiche dès qu\'une cible correspond. Aucune case cochée = popup inactif.', 'popup-spiral'); ?></p>

        <div class="spiral-choice-row">
            <label class="spiral-choice-card">
                <input type="checkbox" name="spiral[targeting][whole_site]" value="1" <?php checked($targeting['whole_site']); ?> />
                <span><?php esc_html_e('Tout le site', 'popup-spiral'); ?></span>
            </label>
            <label class="spiral-choice-card">
                <input type="checkbox" name="spiral[targeting][front_page]" value="1" <?php checked($targeting['front_page']); ?> />
                <span><?php esc_html_e('Page d\'accueil', 'popup-spiral'); ?></span>
            </label>
        </div>

        <h4><?php esc_html_e('Pages spécifiques', 'popup-spiral'); ?></h4>
        <div class="spiral-checklist spiral-checklist-scroll">
            <?php foreach (get_pages(['sort_column' => 'post_title']) as $page) : ?>
                <label>
                    <input type="checkbox" name="spiral[targeting][pages][]" value="<?php echo (int) $page->ID; ?>" <?php checked(in_array($page->ID, $targeting['pages'], true)); ?> />
                    <?php echo esc_html($page->post_title !== '' ? $page->post_title : ('#' . $page->ID)); ?>
                </label>
            <?php endforeach; ?>
        </div>

        <h4><?php esc_html_e('Articles spécifiques', 'popup-spiral'); ?></h4>
        <?php self::renderSearchSelect('post', 'spiral[targeting][posts][]', $targeting['posts']); ?>

        <h4><?php esc_html_e('Catégories', 'popup-spiral'); ?></h4>
        <div class="spiral-checklist">
            <?php foreach (get_categories(['hide_empty' => false]) as $category) : ?>
                <label>
                    <input type="checkbox" name="spiral[targeting][categories][]" value="<?php echo (int) $category->term_id; ?>" <?php checked(in_array($category->term_id, $targeting['categories'], true)); ?> />
                    <?php echo esc_html($category->name); ?>
                </label>
            <?php endforeach; ?>
        </div>
        <?php
    }

    /**
     * Composant de multi-sélection avec recherche AJAX (pages / articles).
     *
     * @param int[] $selected
     */
    private static function renderSearchSelect(string $type, string $name, array $selected): void
    {
        ?>
        <div class="spiral-search" data-type="<?php echo esc_attr($type); ?>" data-name="<?php echo esc_attr($name); ?>">
            <div class="spiral-search-chips">
                <?php foreach ($selected as $id) : ?>
                    <span class="spiral-chip" data-id="<?php echo (int) $id; ?>">
                        <?php echo esc_html(get_the_title($id) ?: ('#' . $id)); ?>
                        <button type="button" class="spiral-chip-remove" aria-label="<?php esc_attr_e('Retirer', 'popup-spiral'); ?>">&times;</button>
                        <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo (int) $id; ?>" />
                    </span>
                <?php endforeach; ?>
            </div>
            <input type="text" class="spiral-search-input" placeholder="<?php esc_attr_e('Rechercher par titre…', 'popup-spiral'); ?>" autocomplete="off" />
            <ul class="spiral-search-results" hidden></ul>
        </div>
        <?php
    }

    /* ---------- Onglet Planification ---------- */

    private static function renderScheduleTab(array $settings): void
    {
        $schedule = $settings['schedule'];
        ?>
        <h3><?php esc_html_e('Quand le popup doit-il être actif ?', 'popup-spiral'); ?></h3>
        <p class="description">
            <?php esc_html_e('Les deux champs sont optionnels. Laissez « Afficher à partir de » vide pour démarrer immédiatement, et renseignez seulement « Arrêter le » pour programmer une fin. Sans aucune date, le popup est actif en permanence.', 'popup-spiral'); ?>
        </p>
        <p class="description">
            <?php
            printf(
                /* translators: 1 : fuseau horaire du site, 2 : date et heure actuelles du site */
                esc_html__('Fuseau horaire du site : %1$s — il est actuellement %2$s pour le site. Si cette heure ne correspond pas à la vôtre, ajustez le fuseau dans Réglages → Général, sinon vos dates seront décalées.', 'popup-spiral'),
                esc_html(wp_timezone_string()),
                esc_html(wp_date('d/m/Y H:i'))
            );
            ?>
        </p>

        <?php
        $start = \Spiral\Schedule::parse($schedule['start']);
        $end = \Spiral\Schedule::parse($schedule['end']);
        $inverted = $start !== null && $end !== null && $start > $end;
        $weekdays = [
            __('L', 'popup-spiral'), __('M', 'popup-spiral'), __('M', 'popup-spiral'),
            __('J', 'popup-spiral'), __('V', 'popup-spiral'), __('S', 'popup-spiral'),
            __('D', 'popup-spiral'),
        ];
        ?>
        <div class="spiral-daterange">
            <input type="hidden" class="spiral-dr-start" name="spiral[schedule][start]" value="<?php echo esc_attr($schedule['start']); ?>" />
            <input type="hidden" class="spiral-dr-end" name="spiral[schedule][end]" value="<?php echo esc_attr($schedule['end']); ?>" />

            <button type="button" class="spiral-dr-trigger" aria-haspopup="dialog" aria-expanded="false">
                <span class="spiral-dr-trigger-icon" aria-hidden="true"></span>
                <span class="spiral-dr-trigger-label"><?php echo esc_html(self::scheduleSummary($start, $end)); ?></span>
                <span class="spiral-dr-trigger-caret" aria-hidden="true"></span>
            </button>

            <p class="spiral-schedule-warning"<?php echo $inverted ? '' : ' hidden'; ?>>
                <?php esc_html_e('⚠ La date de fin précède la date de début : le popup ne s\'affichera jamais. Corrigez les dates.', 'popup-spiral'); ?>
            </p>

            <div class="spiral-dr-overlay" hidden>
                <div class="spiral-dr-modal" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Choisir la plage de planification', 'popup-spiral'); ?>">
                    <div class="spiral-dr-modal-head">
                        <span class="spiral-dr-modal-title"><?php esc_html_e('Planification', 'popup-spiral'); ?></span>
                        <button type="button" class="spiral-dr-x" aria-label="<?php esc_attr_e('Fermer', 'popup-spiral'); ?>">&times;</button>
                    </div>

                    <div class="spiral-dr-cals">
                        <?php for ($cal = 0; $cal < 2; $cal++) : ?>
                            <div class="spiral-dr-cal" data-cal="<?php echo (int) $cal; ?>">
                                <div class="spiral-dr-head">
                                    <?php if ($cal === 0) : ?>
                                        <button type="button" class="spiral-dr-nav spiral-dr-prev" aria-label="<?php esc_attr_e('Mois précédent', 'popup-spiral'); ?>">&lsaquo;</button>
                                    <?php else : ?>
                                        <span class="spiral-dr-nav-spacer"></span>
                                    <?php endif; ?>
                                    <span class="spiral-dr-month" aria-live="polite"></span>
                                    <?php if ($cal === 1) : ?>
                                        <button type="button" class="spiral-dr-nav spiral-dr-next" aria-label="<?php esc_attr_e('Mois suivant', 'popup-spiral'); ?>">&rsaquo;</button>
                                    <?php else : ?>
                                        <span class="spiral-dr-nav-spacer"></span>
                                    <?php endif; ?>
                                </div>
                                <div class="spiral-dr-weekdays">
                                    <?php foreach ($weekdays as $day) : ?><span><?php echo esc_html($day); ?></span><?php endforeach; ?>
                                </div>
                                <div class="spiral-dr-grid" role="grid"></div>
                            </div>
                        <?php endfor; ?>
                    </div>

                    <div class="spiral-dr-fields">
                        <div class="spiral-dr-field spiral-dr-field-start">
                            <span class="spiral-dr-field-label"><?php esc_html_e('Début', 'popup-spiral'); ?></span>
                            <span class="spiral-dr-date spiral-dr-start-date">—</span>
                            <?php self::renderTimeControl('spiral-dr-start-time', $start ? $start->format('H:i') : '00:00', __('Heure de début', 'popup-spiral')); ?>
                            <button type="button" class="spiral-dr-clear spiral-dr-clear-start" aria-label="<?php esc_attr_e('Effacer le début', 'popup-spiral'); ?>">&times;</button>
                        </div>
                        <div class="spiral-dr-field spiral-dr-field-end">
                            <span class="spiral-dr-field-label"><?php esc_html_e('Fin', 'popup-spiral'); ?></span>
                            <span class="spiral-dr-date spiral-dr-end-date">—</span>
                            <?php self::renderTimeControl('spiral-dr-end-time', $end ? $end->format('H:i') : '23:59', __('Heure de fin', 'popup-spiral')); ?>
                            <button type="button" class="spiral-dr-clear spiral-dr-clear-end" aria-label="<?php esc_attr_e('Effacer la fin', 'popup-spiral'); ?>">&times;</button>
                        </div>
                    </div>

                    <div class="spiral-dr-foot">
                        <div class="spiral-dr-presets">
                            <button type="button" class="spiral-dr-preset" data-preset="today"><?php esc_html_e('Aujourd\'hui', 'popup-spiral'); ?></button>
                            <button type="button" class="spiral-dr-preset" data-preset="plus7"><?php esc_html_e('+7 j', 'popup-spiral'); ?></button>
                            <button type="button" class="spiral-dr-preset" data-preset="month"><?php esc_html_e('Ce mois', 'popup-spiral'); ?></button>
                            <button type="button" class="spiral-dr-preset spiral-dr-clear-all"><?php esc_html_e('Tout effacer', 'popup-spiral'); ?></button>
                        </div>
                        <button type="button" class="spiral-dr-validate"><?php esc_html_e('Valider', 'popup-spiral'); ?></button>
                    </div>
                </div>
            </div>

            <noscript>
                <div class="spiral-schedule-fields">
                    <label class="spiral-card">
                        <strong><?php esc_html_e('Afficher à partir de', 'popup-spiral'); ?></strong>
                        <input type="datetime-local" name="spiral[schedule][start]" value="<?php echo esc_attr($schedule['start']); ?>" />
                    </label>
                    <label class="spiral-card">
                        <strong><?php esc_html_e('Arrêter le', 'popup-spiral'); ?></strong>
                        <input type="datetime-local" name="spiral[schedule][end]" value="<?php echo esc_attr($schedule['end']); ?>" />
                    </label>
                </div>
            </noscript>
        </div>
        <?php
    }

    /**
     * Sélecteur d'heure 24 h maison : deux menus (heures 00–23, minutes 00–59).
     * Évite le format 12 h AM/PM du champ `time` natif, dépendant de la locale.
     *
     * @param string $class Classe du conteneur (repère JS : start-time / end-time).
     * @param string $value Heure « HH:MM ».
     * @param string $label Libellé accessible du groupe.
     */
    private static function renderTimeControl(string $class, string $value, string $label): void
    {
        ?>
        <span class="spiral-dr-time <?php echo esc_attr($class); ?>" role="group" aria-label="<?php echo esc_attr($label); ?>">
            <?php self::renderTimeUnit('spiral-dr-hh', substr($value, 0, 2), 24, __('Heures', 'popup-spiral')); ?>
            <span class="spiral-dr-colon" aria-hidden="true">:</span>
            <?php self::renderTimeUnit('spiral-dr-mm', substr($value, 3, 2), 60, __('Minutes', 'popup-spiral')); ?>
        </span>
        <?php
    }

    /**
     * Un menu de temps maison (bouton + liste stylable) : contrairement au
     * `<select>` natif, on maîtrise la liste déroulante — scrollbar aérée,
     * survol et sélection soignés.
     */
    private static function renderTimeUnit(string $class, string $value, int $count, string $label): void
    {
        ?>
        <span class="spiral-dr-unit <?php echo esc_attr($class); ?>" data-value="<?php echo esc_attr($value); ?>">
            <button type="button" class="spiral-dr-unit-btn" aria-haspopup="listbox" aria-expanded="false" aria-label="<?php echo esc_attr($label); ?>"><?php echo esc_html($value); ?></button>
            <ul class="spiral-dr-unit-list" role="listbox" hidden>
                <?php for ($i = 0; $i < $count; $i++) : $v = sprintf('%02d', $i); ?>
                    <li class="spiral-dr-unit-opt<?php echo $v === $value ? ' is-selected' : ''; ?>" role="option" data-value="<?php echo esc_attr($v); ?>" aria-selected="<?php echo $v === $value ? 'true' : 'false'; ?>"><?php echo esc_html($v); ?></li>
                <?php endfor; ?>
            </ul>
        </span>
        <?php
    }

    /**
     * Résumé lisible de la plage de planification pour le champ replié.
     */
    private static function scheduleSummary(?\DateTimeImmutable $start, ?\DateTimeImmutable $end): string
    {
        $format = 'd/m/Y H:i';

        if ($start === null && $end === null) {
            return __('Permanent (toujours actif)', 'popup-spiral');
        }

        if ($start !== null && $end === null) {
            /* translators: %s : date et heure de début */
            return sprintf(__('À partir du %s', 'popup-spiral'), $start->format($format));
        }

        if ($start === null && $end !== null) {
            /* translators: %s : date et heure de fin */
            return sprintf(__('Jusqu\'au %s', 'popup-spiral'), $end->format($format));
        }

        /* translators: 1 : date de début, 2 : date de fin */
        return sprintf(__('Du %1$s au %2$s', 'popup-spiral'), $start->format($format), $end->format($format));
    }

    /**
     * Style inline d'une vignette de design (mini-aperçu dans la galerie).
     */
    private static function thumbStyle(array $designSettings): string
    {
        $radius = ['square' => '2px', 'rounded' => '8px', 'pill' => '16px'][$designSettings['corners']] ?? '8px';
        $shadow = $designSettings['shadow'] === 'none' ? 'none' : '0 4px 12px rgba(0, 0, 0, 0.18)';
        $bg = !empty($designSettings['neutral']) ? 'repeating-conic-gradient(#f1f5f9 0% 25%, #ffffff 0% 50%) 50% / 12px 12px' : $designSettings['bg'];

        return 'background: ' . $bg . '; border-radius: ' . $radius . '; box-shadow: ' . $shadow . ';';
    }
}
