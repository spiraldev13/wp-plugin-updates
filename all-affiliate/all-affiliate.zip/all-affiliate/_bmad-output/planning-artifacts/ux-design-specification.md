---
stepsCompleted: ['step-01-init', 'step-02-discovery', 'step-03-core-experience', 'step-04-emotional-response', 'step-05-inspiration', 'step-06-design-system', 'step-07-defining-experience', 'step-08-visual-foundation', 'step-09-design-directions', 'step-10-user-journeys', 'step-11-component-strategy', 'step-12-ux-patterns', 'step-13-responsive-accessibility', 'step-14-complete']
workflowCompleted: true
completionDate: '2026-04-24'
lastStep: 14
inputDocuments:
  - "_bmad-output/planning-artifacts/prd.md"
  - "_bmad-output/brainstorming/brainstorming-session-2026-04-24-1044.md"
  - "_bmad-output/img/Box.png"
  - "_bmad-output/img/Classement.png"
  - "_bmad-output/img/Custom.png"
  - "_bmad-output/img/Grille.png"
  - "_bmad-output/img/comparatif horizontal.png"
  - "_bmad-output/img/comparatifs.png"
  - "_bmad-output/img/produit vertical.png"
  - "_bmad-output/img/test produit.png"
workflowType: 'ux-design'
projectName: 'All Affiliate'
documentCounts:
  prd: 1
  brief: 0
  brainstorming: 1
  visualRefs: 8
---

# UX Design Specification - All Affiliate

**Author:** Cyril
**Date:** 2026-04-24

> Spécification UX issue du PRD (`prd.md`) et des références visuelles (`_bmad-output/img/`). Contrainte forte : dépasser visuellement les exemples fournis.

---

## Executive Summary

### Project Vision

All Affiliate est un plugin WordPress d'affiliation pensé pour une seule personne : Cyril. L'objectif UX est de créer l'outil d'affiliation **le plus rapide et le plus beau** du marché WordPress, dans un cadre strictement personnel où **l'expérience de l'admin** est au moins aussi importante que le rendu côté visiteur.

**Tension UX fondamentale** : Cyril veut un outil pro-lite (rapidité, efficacité) qui ressemble à un outil haut-de-gamme (design polish, microinteractions, cohérence). Ambition de concurrencer visuellement **Notion, Linear, Stripe** plutôt qu'AAWP.

### Target Users

**Persona unique : Cyril (power user solo)**

| Axe | Valeur |
|---|---|
| Expertise | Intermédiaire-avancée WordPress, sait lire du code, utilise Claude Code |
| Devices admin | 100% desktop (MacBook ou PC), grand écran, session longue |
| Devices visiteurs | 70%+ mobile, 30% desktop |
| Contextes admin | **Sessions longues** (création de 10 produits d'affilée, rédaction article Top 5) + **sessions courtes** (check dashboard, bulk edit ponctuel) |
| Volume attendu | 100-500 produits par site, jusqu'à 2000 |
| État mental | Créateur de contenu monétisé — veut gagner du temps sans perdre en qualité visuelle |
| Tolérance friction | Très basse (abandonne un plugin moche ou lent en 5 minutes) |

### Key Design Challenges

**1. Dépasser visuellement les exemples fournis tout en étant thème-adaptatif**
Les exemples utilisent une palette violet/magenta imposée. Le plugin doit hériter du thème du site — donc **on ne peut pas imposer une palette signature**. Le design doit être identifiable par sa structure, ses espacements, ses microinteractions, pas par sa couleur.

**2. Densité vs respiration dans le split-view**
Le formulaire de gauche contient beaucoup de champs (nom, URL/ASIN, image, panneau avancé replié). La preview de droite doit être zoomable desktop/mobile et refléter fidèlement le rendu final. Risque : interface écrasée sur un écran 13".

**3. Cohérence des 6 templates**
Les templates (Card, Inline, CTA, Grille, Top 5, Pros/Cons) doivent donner une impression d'appartenance à la même famille tout en étant très différents structurellement. Pattern de design system nécessaire.

**4. Signalisation d'état "Inactif"**
Un produit sans tag doit être clairement identifié dans l'admin mais **ne pas alarmer**. Équilibre entre attention et sérénité — pas de gros rouge agressif.

**5. Onboarding ultra-dense en 1 écran**
Sélectionner 12 plateformes + saisir N tags en 1 seul écran sans intimider. Progressive disclosure possible mais dans un seul flux.

**6. Champs optionnels toggleables**
Chaque produit peut activer Score, Badges, Étoiles, Pros/Cons, % réduction. Le formulaire doit rester court pour 90% des cas (tout off) mais accessible rapidement pour activer un champ quand on le veut.

**7. Compatibilité multi-thème visuelle**
Thème clair / sombre / minimaliste / coloré / magazine / e-commerce. Le plugin doit se sentir à sa place partout sans paraître étranger.

### Design Opportunities

**1. Dernier cri vs concurrence**
AAWP et ThirstyAffiliates ont un admin qui date. All Affiliate peut capitaliser sur l'écart visuel immense avec un admin 2026 (Tailwind, micro-transitions, layout moderne). Avantage concurrentiel gratuit juste par la fraîcheur visuelle.

**2. Split-view live-preview comme signature**
La preview live pendant l'édition est rare dans le monde WP. Transformer un moment de création (souvent chiant) en un moment engageant et ludique. Pattern Notion/VS Code adapté au contexte affiliation.

**3. Dashboard "honnête" et actionnable**
Là où les plugins concurrents montrent des graphs complexes inutiles, All Affiliate se différencie par un dashboard minimaliste, clair, orienté décision. 4 graphs max, chacun répondant à une question concrète ("sur quoi écrire cette semaine ?").

**4. Galerie de templates avec preview**
Le choix de template via une galerie visuelle (cards cliquables avec preview réelle) transforme une interaction fade en un moment plaisant — feel de shopping vs feel d'admin.

**5. Microinteractions fluides**
Skeleton loaders, drag-drop élégant, animations de success subtiles, hover states signifiants. Premier impact émotionnel = "ça fait cher" même sans y mettre une fortune.

**6. Mode "sombre" natif des tokens**
Si le thème est en dark mode, le plugin suit automatiquement sans effort supplémentaire — impression de qualité inattendue.

---

## Core User Experience

### Defining Experience — les 2 actions critiques

**1. Créer un produit** (action la plus fréquente)
- Saisie en **< 30 secondes**
- Preview live en temps réel pendant la saisie
- Saisie multi-format intelligente (ASIN brut / URL nue / URL taggée → détection auto)
- Tag d'affiliation garanti (Cyril ne s'inquiète jamais de l'oubli)

**2. Insérer un produit dans un article** (action de conversion éditoriale)
- 3 chemins possibles (Rechercher / Créer rapide / Template-first)
- Autocomplétion immédiate de produits existants
- Galerie visuelle de templates avec preview

→ Si ces deux interactions sont parfaites, tout le reste peut être correct sans être exceptionnel. Si elles sont mauvaises, aucun dashboard sexy ne compense.

### Platform Strategy

**Admin (SPA React)** — 100% desktop-first
- Session typique : 15-60 minutes sur MacBook / grand écran
- Layout optimisé pour grandes surfaces (split-view, sidebar, preview grande)
- Responsive mobile mais dégradé (consultation possible, pas édition confortable)
- Interactions clavier prioritaires (`Cmd+S` sauvegarde, `Cmd+K` recherche, etc.)

**Front (templates visiteurs)** — 100% mobile-first
- 70%+ du traffic est mobile
- Breakpoints Tailwind standard (`sm: 640`, `md: 768`, `lg: 1024`, `xl: 1280`)
- Tailles tactiles 44x44 minimum pour CTAs

**Éditeur Gutenberg (bloc d'insertion)** — hybride, majoritairement desktop

**Pas d'offline, pas de PWA, pas de natif** — le plugin vit dans WordPress admin.

### Effortless Interactions

Interactions qui doivent être **magiques** (zero effort perçu) :

1. **Coller n'importe quel identifiant de produit** → le plugin extrait le bon ASIN/ID et construit l'URL avec tag. *"Je colle, ça marche."*
2. **Changer son tag Amazon** → toutes les URLs existantes se mettent à jour instantanément. *"Je n'édite aucun article."*
3. **Drag-drop d'image** → upload Media Library automatique, pas de dialogue de configuration
4. **Preview live** → modification visible en < 100ms, pas de clic "Preview"
5. **Activer un template pré-assemblé** (pack "Top 5 complet") → insertion en un clic
6. **Le plugin hérite du thème** → aucune config CSS, ça ressemble déjà au site
7. **Rechercher un produit existant** → autocomplétion au 2e caractère, choix en 1 touche

### Critical Success Moments

**Moment #1 — Le premier produit créé (< 2 minutes après install)**
Si ça marche : preview live s'anime pendant qu'il tape + "Tester le lien" ouvre Amazon avec son tag → *"Waow, c'est bien foutu"* → il continue.
Si ça rate : interface lente, preview qui ne suit pas, ou tag manquant → abandon en 5 min.

**Moment #2 — L'insertion dans son premier article (< 10 minutes après install)**
Si ça marche : bloc "affiliate" trouvé, template choisi en 3 clics, 5 produits remplis par autocomplétion, rendu propre instantané → *"Ça change ma vie"* → il configure le plugin sur ses autres sites.
Si ça rate : bloc lent, galerie confuse, rendu moche → retour aux plugins concurrents.

**Moment #3 — Le 20ème produit (semaine 2)**
Si ça marche : gestion de 20 produits en bulk (duplication, catégorie, désactivation saisonnière) rapidement → validation que l'outil scale avec lui.
Si ça rate : UX "1 produit à la fois" pénible → retour en arrière.

**Moment #4 — Le changement de tag (semaine 4 ou +)**
Si ça marche : change le tag en 1 endroit, 3 liens testés marchent tous → *"Cet outil est intelligent"*.
Si ça rate : scripts custom → frustration.

**Moment #5 — Le premier conflit de thème (jour X)**
Si ça marche : thème Tailpress (Tailwind natif), classes `aff-*` isolées, rendu propre → *"Il pense à tout"*.
Si ça rate : boutons cassés, layout pourri → désinstalle en 10 min.

### Experience Principles (UX-spécifiques)

Ces 5 principes complètent les 9 principes directeurs du PRD, spécifiquement pour guider les décisions UX :

**UX-1 — "Zero-thought path"**
Pour les 2 actions critiques (créer un produit, insérer dans un article), il doit y avoir un chemin évident sans réfléchir. Pas de choix multiples non hiérarchisés. Le débutant et le power-user suivent la même route.

**UX-2 — "Live everywhere"**
Tout ce qui peut être montré avant validation l'est. Preview live, validation inline (✓ ou ✗ au fil de la frappe), estimation du rendu final. Cyril ne clique jamais sur "Aperçu" pour voir.

**UX-3 — "Progressive disclosure"**
3 champs obligatoires par défaut. Panneau "Avancé" replié. Champs optionnels (Score, Étoiles, etc.) cachés jusqu'à activation. **90% des produits doivent se créer avec les 3 champs de base**.

**UX-4 — "Thème-first color, structure-first identity"**
La couleur appartient au thème. L'identité visuelle d'All Affiliate se joue dans **l'espacement, la typographie hiérarchique, les microinteractions et les motifs structurels** — pas dans la palette.

**UX-5 — "Never alarm, always guide"**
Les états d'erreur/warning sont informatifs et actionables (clic = solution), jamais punitifs. Le badge "Tag manquant" est discret et propose immédiatement la correction.

---

## Desired Emotional Response

### Primary Emotional Goals

**L'émotion #1 cible : CONTRÔLE**
Cyril doit se sentir maître de son outil, de ses données, de ses liens, de son revenu. Le plugin respecte son intelligence, ne cache rien d'important, ne surprend jamais.

**Les 3 émotions secondaires** :
- **CONFIANCE** — le plugin fait ce qu'il dit ("mon tag est passé", "le clic est compté", "le rendu est sauvé")
- **EFFICACITÉ** — sensation que chaque seconde est rentabilisée, aucun clic perdu
- **FIERTÉ** — ce que Cyril construit avec le plugin (articles, templates, site) a l'air pro et soigné

**Différenciateur émotionnel vs concurrence**
AAWP/ThirstyAffiliates laissent une impression de "vieux WP lourd, je m'en contente". All Affiliate doit laisser une impression de **"outil moderne et affiné"** — même sensation que d'ouvrir Linear après avoir utilisé Jira.

### Emotional Journey Mapping

**Phase 1 — Découverte (première installation)**
- Cible : *Curiosité tranquille*, pas d'excitation artificielle
- Éviter : onboarding exubérant, "Bienvenue 🎉", pop-ups de félicitations

**Phase 2 — Premier usage (premier produit, premier article)**
- Cible : *Surprise positive calme* ("tiens, ça marche vraiment bien")
- Moments magiques : preview live, saisie multi-format, thème respecté
- Éviter : ralentissements, confirmations excessives

**Phase 3 — Usage quotidien (semaines 2+)**
- Cible : *Flow invisible* — le plugin disparaît, Cyril se concentre sur son contenu
- Éviter : animations récurrentes, notifications non critiques, rappels

**Phase 4 — Moments critiques (changement de tag, nouveau site, conflit thème)**
- Cible : *Sérénité* ("je sais que ça va marcher, et si problème, le plugin me guide")
- Éviter : alertes rouges, pop-ups d'erreur techniques

**Phase 5 — Retour long terme (mois 6+)**
- Cible : *Gratitude discrète* ("je ne me vois plus sans")
- Signe de succès : Cyril oublie qu'il l'a installé

### Micro-Emotions

**À maximiser**

| Micro-émotion | Où la provoquer |
|---|---|
| Confiance | Preview live qui correspond pile au rendu final |
| Trust | "Tester le lien" qui ouvre exactement le bon URL avec tag |
| Accomplishment | Un produit créé et enregistré en 20-30s |
| Flow | Autocomplétion qui comprend ce qu'on cherche |
| Pride | Rendu du Top 5 qui s'intègre parfaitement dans l'article |
| Sérénité | État "Inactif" signalé sans alarmer |

**À éviter absolument**

| Micro-émotion négative | Comment l'éviter |
|---|---|
| Infantilisation | Pas de "Bravo 🎉", pas de tooltips de l'évidence |
| Anxiété | Pas d'alertes rouges inutiles, confirmations minimales |
| Suspicion | Transparence totale sur ce qui se passe ("Tag Amazon : `cyril-21` appliqué") |
| Frustration | Pas d'attente > 1s, pas de chargement cache MISS perceptible |
| Condescendance | Pas d'onboarding "Étape 1 sur 12 : bienvenue" |
| Surprise négative | Jamais de "l'IA a décidé pour toi", toujours explicit |

### Design Implications

**Tone éditorial**
- **Sobre, direct, respectueux** (décision confirmée par Cyril)
- *"Produit sauvegardé."* (pas "Génial ! Ton produit a été sauvegardé avec succès ! 🎉")
- *"Tag Amazon appliqué : cyril-21"* (pas "Votre tag d'affiliation est parfaitement configuré !")
- *"Format non reconnu. Colle un ASIN (10 caractères) ou une URL Amazon."* (pas "Erreur 422")
- **Pas d'emojis dans l'UI native du plugin** (les emojis appartiennent au contenu de Cyril, pas à l'admin)

**Animations et transitions**
- **Subtiles** : fade 150ms, slide 200ms, skeleton 1s. Jamais de rebond, pas de spring.
- **Utilitaires** : signaler un état, pas décorer
- **Respect strict de `prefers-reduced-motion`**

**Loading states**
- **Skeleton** qui reflète la structure réelle (pas un spinner générique)
- Pas de texte "Chargement..."
- Cache HIT = apparition instantanée, pas d'animation

**Error / warning states**
- Badge "Tag manquant" en **orange doux** (validé par Cyril), pas rouge vif
- Icône informative (⚠ ou ℹ️), pas de gros panneau STOP
- **Solution immédiatement proposée** (clic = deep-link vers la config)

**Success states**
- **Discrets** : petit ✓ vert à côté du bouton, pas de toast géant
- Disparaissent en 2s
- **Pas de confetti, pas de son, pas de célébration**

**Dashboard**
- Data **sobrement présentée** — chiffres, graphs, rien de plus
- Pas de "🔥 Record battu !" ou autres gamifications
- Contexte utile (ex: "+12% vs 30j précédents") sans dramatiser

### Emotional Design Principles

**ED-1 — "Respect the user's intelligence"**
Le plugin parle à un power-user, pas à un débutant. Pas de pédagogie forcée, pas de tooltip de l'évidence, pas de wizard infantilisant.

**ED-2 — "Calm by default"**
Aucune stimulation émotionnelle gratuite. Les moments d'accomplissement sont signalés discrètement. La surprise doit être positive ET subtile.

**ED-3 — "Explicit, always"**
Le plugin ne décide jamais silencieusement. Toute transformation de donnée (ex: extraction d'ASIN depuis une URL) est visible et explicitée.

**ED-4 — "Trust through transparency"**
"Tester le lien" ouvre l'URL réelle. Le dashboard montre les vrais chiffres. Les settings montrent ce qui est appliqué. Aucune boîte noire.

**ED-5 — "Get out of the way"**
L'objectif ultime : que Cyril oublie le plugin. Le plugin s'efface au profit du travail de Cyril (ses articles, ses produits, son site).

---

## UX Pattern Analysis & Inspiration

### Inspiring Products Analysis

Quatre produits sélectionnés pour leur pertinence UX vs All Affiliate :

#### 1. Linear (gestion de projet SaaS)

Même promesse que All Affiliate pour son domaine — remplacer un outil lourd par un outil moderne et rapide.

**Forces UX** : Keyboard-first (`Cmd+K` ouvre tout), minimalisme fonctionnel, transitions subtiles 150-200ms, settings bien organisés, dark mode de qualité, status pills sobres.

**Applicable All Affiliate** : raccourcis clavier admin (`Cmd+S`, `Cmd+K`, `Cmd+N`), style visuel des settings, status pills pour l'état des produits.

#### 2. Notion (éditeur de contenu tout-en-un)

Référence sur le split-view live-preview et l'édition fluide.

**Forces UX** : bloc unique polymorphe (`/` ouvre un menu), drag-drop natif, autocomplétion instantanée (`@`, `[[`), hover reveal (actions cachées au hover), indicateurs discrets.

**Applicable All Affiliate** : pattern du bloc Gutenberg unique (FR26-27), hover reveal pour actions secondaires, autocomplétion produit, drag handle pour réorganiser un Top 5.

#### 3. Stripe Dashboard (finance/paiement SaaS)

Référence sur le dashboard sobre et actionnable avec data monétaire — parallèle direct avec le revenu de Cyril.

**Forces UX** : graphs réduits à l'essentiel, pas de vanity metrics, skeleton loaders de qualité, onboarding progressif, empty states utiles, copy précis.

**Applicable All Affiliate** : dashboard 4-graphs, skeleton loaders pendant cache MISS, empty state à l'install, microcopy précis.

#### 4. Raycast (command palette / launcher)

Référence sur `Cmd+K` global et l'efficacité power-user.

**Forces UX** : palette universelle, recherche fuzzy indulgente, aliases personnalisables, résultats contextuels, icônes reconnaissables.

**Applicable All Affiliate** : `Cmd+K` qui ouvre une palette pour produit/profil/template/réglage, recherche fuzzy, quick actions.

### Transferable UX Patterns

**Navigation Patterns**

| Pattern | Source | Application |
|---|---|---|
| Sidebar gauche minimaliste avec sections | Linear | Menu admin : Produits / Plateformes / Templates / Design / Dashboard / Settings |
| Breadcrumb discret en haut | Notion | *All Affiliate > Produits > Tente MSR Hubba Hubba NX* |
| Command palette `Cmd+K` | Linear / Raycast | Recherche globale produit/profil/réglage |
| Tabs horizontaux pour sous-sections | Stripe | Design Settings : Tokens / Composants / Preview |

**Interaction Patterns**

| Pattern | Source | Application |
|---|---|---|
| Hover reveal (actions cachées) | Notion | Boutons "Éditer / Dupliquer / Supprimer" apparaissent au hover dans la liste produits |
| Autocomplétion inline | Notion | Recherche produit dans Gutenberg, dans `Cmd+K` |
| Drag handle discret | Notion | Réorganiser produits d'un Top 5 |
| Inline validation | Stripe | ✓ à droite du champ quand l'ASIN extrait est valide |
| Sticky save button | Stripe | Barre de sauvegarde fixée en bas pendant l'édition |

**Visual Patterns**

| Pattern | Source | Application |
|---|---|---|
| Status pills (Actif/Inactif/Programmé) | Linear | Badges discrets dans la liste des produits |
| Skeleton loaders structurés | Stripe | Pendant le cache MISS ou première requête |
| Typographie hiérarchique forte | Linear | Titre / sous-titre / body / caption avec ratios clairs |
| Spacing système strict (8/12/16/24/32) | Linear | Grille spacing dans Design Tokens |
| Icônes minimalistes monochrome | Linear | Lucide Icons ou Heroicons (sobres, cohérents) |

### Anti-Patterns to Avoid

**1. AAWP / ThirstyAffiliates** (concurrents directs)
- Interface admin WP "native" non-stylée → on ne copie pas, c'est l'écart à creuser
- Multiples écrans de config sans hiérarchie claire
- Shortcodes complexes à mémoriser
- Pas de preview live, tout en "coup dans le noir"

**2. HubSpot / Marketo** (outils marketing lourds)
- Wizards en 12 étapes, tutoriels vidéo obligatoires
- Success 🎉 / confettis / gamification forcée
- Dashboards surchargés (30 graphs dont 28 inutiles)
- Microcopy "ton marketing" ("Félicitations ! Vous venez de débloquer...")

**3. WordPress admin classique**
- Tables de données denses sans hiérarchie
- Icônes Dashicons datées → on utilise Lucide/Heroicons
- Styles par défaut WP Admin → on construit notre propre UI (sauf composants `@wordpress/components` réellement utiles comme `Modal`, `Button` de base)

**4. Apps type TurboTax / CRM legacy**
- Pop-ups modales qui bloquent le flux
- Validation reportée à la fin du formulaire (erreurs en masse)
- "Enregistrement en cours..." qui dure 5 secondes

### Design Inspiration Strategy

**What to Adopt (intégrer tel quel)**
- Sidebar minimaliste style Linear
- Skeleton loaders style Stripe
- Hover reveal style Notion
- Command palette `Cmd+K` style Raycast
- Status pills style Linear
- Inline validation style Stripe

**What to Adapt (modifier pour notre contexte)**
- Split-view Notion → plus petit (WP admin dans un frame), optimisé formulaire + preview template
- Dashboard Stripe → simplifié à 4 graphs max (pas de sub-pages)
- Bloc polymorphe Notion → adapté à la logique Gutenberg WordPress (FR26-27)
- Empty states Stripe → personnalisés pour nos contextes (aucun produit, aucun profil actif, pas de clic)

**What to Avoid (explicite)**
- Tout le look "WordPress admin natif" (dashicons, tables grises, boutons carrés)
- Les cérémonies d'accomplissement (confetti, toasts XL, notifications sonores)
- Les wizards en plusieurs étapes pour des tâches de 30 secondes
- Le marketing dans les copy ("Découvrez comment booster vos commissions !")
- Les dashboards en "mur de chiffres" sans hiérarchie

---

## Design System Foundation

### Design System Choice

**Approche retenue : "Tailwind-based hybrid system"**

Combinaison de 3 couches :

**Couche 1 — Base technique : Tailwind CSS + prefix `aff-*`**
- Utility classes pour layout, spacing, couleurs, typo
- Prefix `aff-*` obligatoire (décision ferme PRD, anti-conflit thèmes Tailwind)
- CSS variables pour les Design Tokens (héritage du thème actif)
- Build via `@wordpress/scripts`

**Couche 2 — Primitives accessibles : Radix UI**
- Pour les composants interactifs complexes : modales, popovers, tabs, combobox, listbox, dropdown
- A11y garantie par défaut (focus, keyboard, screen readers)
- Zéro style imposé — stylisation via Tailwind
- Préféré à Headless UI pour sa gamme plus large et son A11y de pointe

**Couche 3 — Composants WordPress natifs : `@wordpress/components` (usage limité)**

Utilisé **uniquement** pour ce qui doit s'intégrer à WP :
- `MediaUpload` / `MediaPlaceholder` (Media Library native)
- `BlockControls`, `InspectorControls` (éditeur Gutenberg)

**Pas utilisé** pour : buttons, inputs, cards, modals simples — UI Tailwind custom pour le contrôle visuel total.

### Rationale for Selection

**Pourquoi PAS un design system complet (MUI, Ant Design, Chakra)** :
- Ils imposent leur propre look qui lutte avec le thème WP
- Bundle size élevé (> 100KB, contre cible < 50KB NFR-P4)
- Incompatible avec le principe "héritage du thème"

**Pourquoi PAS du custom from scratch** :
- Coût initial trop élevé pour un projet solo
- Risque d'accessibilité (réimplémenter focus traps, keyboard nav, etc.)
- Pas de bénéfice vs Radix

**Pourquoi cette approche hybride est optimale** :
- Tailwind donne la flexibilité visuelle totale (palette adaptative au thème)
- Radix donne l'accessibilité gratuite sur les composants complexes
- `@wordpress/components` assure l'intégration WP sans réinventer les écrans natifs
- Bundle raisonnable (~30-40 KB pour l'admin)

### Implementation Approach

**Architecture des composants**

```
packages/all-affiliate/
├── admin-react/
│   ├── primitives/          ← Radix UI wrapped + Tailwind
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Dialog.tsx
│   │   ├── Popover.tsx
│   │   ├── Tabs.tsx
│   │   └── ComboBox.tsx
│   ├── composites/          ← Composants métier complexes
│   │   ├── ProductForm.tsx
│   │   ├── PlatformProfileCard.tsx
│   │   ├── TemplateGallery.tsx
│   │   └── DashboardWidget.tsx
│   ├── layout/              ← Layout app
│   │   ├── Sidebar.tsx
│   │   ├── TopBar.tsx
│   │   └── SplitView.tsx
│   └── routes/              ← React Router pages
└── blocks/gutenberg/
    └── affiliate-block/     ← @wordpress/components + primitives custom
```

**Icônes** : **Lucide React** — moderne, cohérent, monochrome, tree-shakeable. Tailles 16/20/24 px.

**Typographie**
- Héritée du thème via CSS variable `--aff-font-family`
- Fallback : `system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`
- Tailles : `aff-text-xs` (12) / `sm` (14) / `base` (16) / `lg` (18) / `xl` (20) / `2xl` (24) / `3xl` (30)
- Poids : `aff-font-normal` (400) / `medium` (500) / `semibold` (600) / `bold` (700)

### Customization Strategy

**Personnalisable (via Design Tokens)**
- Palette (primary, secondary, accent, background, surface, text, border)
- Typographie (font-family, ratios)
- Espacements (échelle 4/8/12/16/24/32/48/64)
- Radius (`aff-rounded-sm`, `md`, `lg`, `xl`, `full`)
- Shadow (`aff-shadow-sm`, `md`, `lg`)
- Motion (durations, easings)

**PAS personnalisable (fixé)**
- Structure HTML des composants (pas de modification de la hiérarchie)
- Accessibilité (rôles ARIA, keyboard nav)
- Comportements Radix (focus trap, dismiss, etc.)

**Stratégie de thème adaptatif**
1. À l'activation, détection des couleurs/typo via `wp_get_global_styles()` (FSE) ou heuristique CSS (thèmes classiques)
2. Pré-remplissage des Design Tokens
3. Admin peut tout surcharger via Settings > Design
4. Bouton "Réinitialiser depuis le thème" pour revenir aux valeurs détectées

**Dark mode (MVP)**
- Détection auto via `prefers-color-scheme` ou classe `dark` sur `<html>`
- Tokens dark définis en parallèle des tokens light
- Front : suit le thème automatiquement
- Admin : suit aussi par défaut, togglable dans Settings (override utilisateur)

### Anti-choices (rejetés explicitement)

- **Bootstrap** : trop lourd, esthétique datée, conflits
- **Material UI (MUI)** : style "Google" trop marqué, bundle > 100KB
- **Ant Design** : style "Alibaba" trop marqué
- **Chakra UI** : redondant avec Tailwind
- **`@wordpress/components` utilisé largement** : UI datée, incompatible avec l'ambition visuelle

---

## Defining Core Experience

### Defining Experience

**En une phrase :**
> **"Coller un lien, voir le produit stylé apparaître dans le thème du site en 30 secondes"**

C'est le moment "aha" d'All Affiliate — l'interaction que Cyril va montrer à un pote en disant *"tiens, regarde ça"*. Si on rate cette interaction, tout le reste est secondaire. Si on la réussit, le plugin a gagné.

Pattern équivalent aux iconiques : Tinder = swipe to match / Spotify = tap to play / Notion = `/` to create / **All Affiliate = paste to create-and-see**.

### User Mental Model

**Comment Cyril pense aujourd'hui** (avec AAWP/ThirstyAffiliates ou saisie manuelle) :
1. Je trouve un produit sur Amazon
2. Je copie l'URL
3. J'ouvre mon plugin, je cherche le formulaire
4. Je colle, je remplis 10 champs (3-5 min)
5. Je sauvegarde sans savoir à quoi ça ressemble
6. J'édite l'article, j'insère le shortcode, je prévisualise
7. Parfois je corrige le CSS à la main

**Frustrations actuelles**
- Saisie redondante (titre déjà dans l'URL source)
- Pas de preview → "je colle dans le noir"
- Rendu moche par défaut
- Cycle long pour modifier un détail

**Modèle mental cible** (avec All Affiliate)
1. Je colle ce que j'ai
2. Ça marche tout seul
3. Je vois le résultat en live
4. Je publie

**Changement de paradigme** : passer de **"configurer puis valider"** (linéaire, froid) à **"montrer puis ajuster"** (interactif, chaud).

### Success Criteria for the Core Experience

| Critère | Cible | Ressenti |
|---|---|---|
| Time-to-first-preview | < 3 secondes après le paste | "Déjà ?" |
| Extraction réussie (ASIN/ID parsé) | > 95% des URLs Amazon/plateformes courantes | "Même ma copie sale, ça passe" |
| Preview fidèle | Rendu preview = rendu final à 99% | "C'est exactement ce que je vais publier" |
| Temps total pour un produit complet | < 30 secondes | "C'était trop rapide" |
| Cas "je teste" rassurant | Bouton "Tester le lien" ouvre Amazon avec le bon tag | "OK, c'est bien mon tag" |

**Indicateurs émotionnels (qualitatifs)**
- Cyril sourit la première fois qu'il voit la preview s'animer
- Cyril dit à voix haute "pas mal" (seul devant l'écran)
- Cyril teste 2-3 produits de plus juste pour le plaisir avant de "vraiment" commencer son travail

### Novel vs. Established Patterns

L'interaction combine 3 patterns établis en un enchaînement inédit dans le monde WP :

| Pattern | Source | Innovation ici |
|---|---|---|
| Paste-to-populate | Browsers (paste → preview), Slack (paste URL → unfurl) | Appliqué à un formulaire de création structuré |
| Live preview split-view | Notion, Obsidian, VS Code markdown | Appliqué à un plugin d'affiliation WP (premier du genre) |
| Smart format detection | Raycast, Alfred | Appliqué à l'extraction multi-format d'identifiants d'affiliation |

**Conclusion** : pas d'innovation pure, mais **combinaison inédite dans l'écosystème WP d'affiliation**. Pas besoin d'onboarding pour cette interaction — elle doit être intuitive dès la première fois.

### Experience Mechanics — le flow pas à pas

**1. Initiation**

Deux chemins d'entrée possibles :
- Depuis la liste "Produits" → bouton `+ Nouveau produit` en haut à droite
- Depuis Gutenberg → bloc "All Affiliate" → "Créer un produit rapide"

Dans les 2 cas, on arrive sur le même écran : **Split-view Form / Preview**.

```
┌────────────────────────────────────────────────────────────┐
│ ← Produits / Nouveau produit              [Enregistrer]    │
├──────────────────────────┬─────────────────────────────────┤
│ 1/2 — Plateforme         │                                 │
│                          │                                 │
│ [Choisis la plateforme]  │        PREVIEW LIVE             │
│ ○ Amazon FR              │                                 │
│ ○ Awin                   │      (vide au départ,           │
│ ○ Rakuten                │       se remplit au fur         │
│ ○ Custom                 │       et à mesure)              │
│ …                        │                                 │
│ [Continuer →]            │                                 │
└──────────────────────────┴─────────────────────────────────┘
```

**2. Interaction — saisie et extraction**

Après choix de plateforme, le formulaire révèle le champ clé :

```
[ASIN, URL ou URL taggée] [ __________________ ] [validate]
   ↑ placeholder : "ASIN, URL Amazon, ou URL déjà avec tag"
```

**Dès que Cyril colle** :
1. 0-50ms : détection du format (ASIN / URL / URL taggée) via regex du profil
2. 50-100ms : extraction de l'ID, normalisation
3. 100-200ms : badge de confirmation vert à droite : `✓ ASIN B08N5WRWNW extrait`
4. 200-300ms : skeleton placeholder côté preview
5. 300-800ms (OpenGraph activé) : scraping image et titre
6. 800ms-1s : preview finale affichée

Si format non reconnu :
- Message inline orange doux : *"Format non reconnu pour Amazon. Colle un ASIN (10 caractères) ou une URL produit Amazon."*
- Pas de popup, pas d'alerte bloquante

**3. Feedback en temps réel**

Chaque frappe dans les champs (nom, description, prix, score...) met à jour la preview en < 100ms (debounce 50ms). Pas de bouton "Preview".

Pendant l'interaction, une barre d'état en bas indique silencieusement :
- `Dernière modification il y a X secondes`
- Icône sauvegarde auto : `✓ Sauvegardé` (fade après 2s) OU `○ En cours…`

**4. Completion**

Après tout, trois actions au choix :
- **Enregistrer et fermer** → retour à la liste des produits
- **Enregistrer et dupliquer** → nouveau produit vide, profil présélectionné (gain de temps pour produits d'affilée)
- **Enregistrer et insérer dans un article** → propose la liste des articles en cours d'édition

Le bouton **"Tester le lien"** reste accessible en permanence en haut de l'écran.

### Frictions éliminées

| Friction classique | Solution All Affiliate |
|---|---|
| Saisir un titre déjà disponible | OpenGraph scraping peuple le titre automatiquement |
| Chercher l'image du produit | Drag-drop direct ou OpenGraph |
| Se demander si le tag est bien là | Construction auto via proxy + bouton "Tester" visible |
| Attendre un "Aperçu" pour voir | Preview live, pas de clic |
| Pas savoir à quoi ressemblera le rendu final | Preview = rendu final (99% fidélité) |
| Refaire le cycle si on veut changer un détail | Tout se met à jour en temps réel |

### Key-moment design rules

**Règle 1 — "The paste is sacred"**
Le moment du paste est le moment magique. Tout doit être instantané, visuel, rassurant. Pas de confirmation, pas de dialogue.

**Règle 2 — "No friction before first success"**
Entre le paste et la première preview réussie, **aucun clic obligatoire**. La preview apparaît d'elle-même.

**Règle 3 — "Failure is quiet, actionable, immediate"**
Si l'extraction rate, l'erreur est discrète, propose une solution, n'interrompt pas le flow.

**Règle 4 — "Save is invisible by default"**
Sauvegarde automatique (debounce). Le bouton "Enregistrer" est une confirmation de fin de session.

### Decisions actées (validées par Cyril)

- **Sauvegarde auto (debounce)** → MVP
- **OpenGraph scraping au paste** → MVP (impact UX fort, coût dev modéré)

---

## Visual Design Foundation

### Color System

**Principe fondamental : "Theme-first, sensible-fallback"**

Le plugin n'impose aucune couleur signature — il hérite toujours du thème WordPress actif. Les fallbacks n'interviennent que si la détection échoue ou pour des couleurs sémantiques universelles (success/warning/danger).

Chaque token est une CSS variable `--aff-color-<nom>` avec valeur **(1)** détectée depuis le thème, sinon **(2)** valeur de fallback.

#### Tokens hérités du thème

| Token | Rôle | Source de détection |
|---|---|---|
| `--aff-color-primary` | Couleur d'accent (boutons, liens, focus) | `wp_get_global_styles()` : `color.primary` (FSE) ou heuristique sur `<a>` |
| `--aff-color-primary-foreground` | Texte sur fond primary | Calculé : blanc ou noir selon luminance |
| `--aff-color-background` | Background global | `body` background |
| `--aff-color-surface` | Cards, panels, conteneurs | Background légèrement décalé de `background` |
| `--aff-color-surface-elevated` | Modales, popovers, dropdowns | Surface + shadow |
| `--aff-color-text-primary` | Texte principal | `body` color |
| `--aff-color-text-secondary` | Texte secondaire | Dérivé : opacity 0.7 |
| `--aff-color-text-muted` | Texte tertiaire | Dérivé : opacity 0.5 |
| `--aff-color-border` | Bordures fines | `text-primary` à 10% |
| `--aff-color-border-strong` | Bordures visibles | `text-primary` à 20% |

#### Tokens sémantiques universels (fixes, non hérités)

| Token | Rôle | Valeur fixe |
|---|---|---|
| `--aff-color-success` | États succès (✓) | `#22c55e` (green-500) |
| `--aff-color-success-bg` | Background success léger | `#dcfce7` (green-100) |
| `--aff-color-warning` | États warning (⚠ "Tag manquant") | `#f59e0b` (amber-500) — **orange doux validé** |
| `--aff-color-warning-bg` | Background warning léger | `#fef3c7` (amber-100) |
| `--aff-color-danger` | États erreur critique | `#ef4444` (red-500) |
| `--aff-color-danger-bg` | Background danger léger | `#fee2e2` (red-100) |
| `--aff-color-info` | États informatifs | `#3b82f6` (blue-500) |
| `--aff-color-info-bg` | Background info léger | `#dbeafe` (blue-100) |

#### Palette de fallback (si détection impossible)

**Mode Light** — neutre élégant, volontairement sobre :
- Primary : `#0f172a` (slate-900)
- Background : `#ffffff`
- Surface : `#f8fafc` (slate-50)
- Text primary : `#0f172a`

**Mode Dark** :
- Primary : `#f8fafc` (slate-50)
- Background : `#0f172a` (slate-900)
- Surface : `#1e293b` (slate-800)
- Text primary : `#f8fafc`

Justification : si le thème ne donne rien, on ne devine pas une couleur de marque — on reste **presque invisible**, laissant la couleur au contenu de Cyril.

#### Accessibilité des couleurs

- Contraste minimum 4.5:1 entre `text-primary` et `background` (WCAG AA)
- Si détection donne un contraste < 4.5:1, le token est ajusté automatiquement (darken/lighten)
- `primary-foreground` toujours calculé dynamiquement pour garantir le contraste
- Tokens sémantiques respectent le contraste par construction

### Typography System

**Principe : "Inherit from theme, structural hierarchy stays"**

La font-family est héritée. La hiérarchie des tailles et poids est fixe.

**Font Family**
- `--aff-font-family-body` : détectée depuis `<body>`, fallback système
- `--aff-font-family-heading` : détectée depuis `h1-h6`, fallback système
- `--aff-font-family-mono` : fixe — `Menlo, Monaco, Consolas, "Courier New", monospace` (pour ASIN/IDs)

Fallback stack : `system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", sans-serif`

**Échelle typographique**

| Token | Taille | Usage |
|---|---|---|
| `aff-text-xs` | 12px | Captions, labels discrets, metadata |
| `aff-text-sm` | 14px | Small body, tooltips, badges |
| `aff-text-base` | 16px | Body par défaut |
| `aff-text-lg` | 18px | Body important, lead |
| `aff-text-xl` | 20px | Titre de carte, H4 |
| `aff-text-2xl` | 24px | Titre de section, H3 |
| `aff-text-3xl` | 30px | Titre de page, H2 |
| `aff-text-4xl` | 36px | Grand titre (dashboard KPI), H1 |

**Poids** : `aff-font-normal` (400) / `medium` (500) / `semibold` (600) / `bold` (700)

**Line height** : body `leading-relaxed` (1.625) / headings `leading-tight` (1.25) / small `leading-normal` (1.5)

### Spacing & Layout Foundation

**Principe : "Airy mais dense productivement"**

Admin utilisé en sessions longues → pas trop dense (fatigue) mais pas gaspillé (scroll).

**Spacing scale** (base 4px)

| Token | Valeur | Usage |
|---|---|---|
| `aff-space-1` | 4px | Micro-gaps |
| `aff-space-2` | 8px | Gaps serrés (icon + text) |
| `aff-space-3` | 12px | Gaps standards |
| `aff-space-4` | 16px | Gaps confortables |
| `aff-space-6` | 24px | Séparation entre éléments liés |
| `aff-space-8` | 32px | Séparation entre sections |
| `aff-space-12` | 48px | Padding large |
| `aff-space-16` | 64px | Padding hero |

**Radius**

| Token | Valeur | Usage |
|---|---|---|
| `aff-rounded-sm` | 4px | Petits badges, inputs denses |
| `aff-rounded-md` | 6px | **Par défaut** : boutons, cards, inputs |
| `aff-rounded-lg` | 8px | Cards importantes, modales |
| `aff-rounded-xl` | 12px | Grandes cards, panels |
| `aff-rounded-2xl` | 16px | Hero cards, images |
| `aff-rounded-full` | 9999px | Pills, avatars |

**Shadow**

| Token | Valeur |
|---|---|
| `aff-shadow-sm` | `0 1px 2px rgba(0,0,0,0.05)` |
| `aff-shadow-md` | `0 4px 6px rgba(0,0,0,0.05), 0 1px 3px rgba(0,0,0,0.1)` |
| `aff-shadow-lg` | `0 10px 15px rgba(0,0,0,0.1)` |
| `aff-shadow-xl` | `0 20px 25px rgba(0,0,0,0.1)` |

**Motion**

| Token | Durée | Usage |
|---|---|---|
| `aff-duration-fast` | 100ms | Hover simples |
| `aff-duration-normal` | 150ms | Transitions par défaut |
| `aff-duration-slow` | 300ms | Page change |
| `aff-duration-skeleton` | 1000ms | Pulsation skeleton |

Easing par défaut : `ease-out`. Pas de spring/bounce.

**Layout Grid (admin desktop)**
- Container max-width : `1440px`
- Sidebar fixe : 240px
- Content area : restant, padding 32px

**Split-view (édition produit)**
- Form pane : 40-45% gauche
- Preview pane : 55-60% droite
- Séparateur draggable (V1.5), fixe 50/50 au MVP

**Mobile (front templates)**
- Gouttière : 16px
- Container fluide full-width

### Accessibility Considerations

**Couleurs**
- Contraste WCAG 2.1 AA (≥ 4.5:1 body, ≥ 3:1 large text)
- Validation Lighthouse + axe-core au build
- Pas de couleur comme seule indication (icônes + labels toujours)

**Typographie**
- Taille minimale 12px
- Body 16px par défaut
- Line-height ≥ 1.5 sur body
- Pas de font hairline (poids < 400)

**Espacement tactile**
- Éléments tactiles ≥ 44x44px côté front (NFR-A7)
- Boutons admin : 40x40 minimum
- Espacement entre éléments cliquables ≥ 8px

**Reduced motion**
- Respect strict de `prefers-reduced-motion`
- Skeleton statique si motion reduced
- Transitions à 0ms si motion reduced (sauf focus qui garde 100ms)

---

## Design Direction Decision

### Design Directions Explored

Trois directions distinctes ont été évaluées, avec wireframes ASCII et analyse comparative sur 7 critères (modernité, confort session longue, feel créatif, feel data, hiérarchie power-user, neutralité visuelle, cohérence principes UX) :

- **Direction A — "Linear-like : structure & clarté"** : admin data-focused, sidebar fine, beaucoup de respiration, actions hover reveal, status pills discrètes
- **Direction B — "Notion-like : éditorial & fluide"** : contenu-first, sidebar dépliable, drag handles inline, métadonnées en body
- **Direction C — "Stripe-like : data & dashboard-first"** : admin business tool, cards KPIs proéminentes, table structurée

### Chosen Direction

**Direction A (Linear-like) + élément emprunté à B**

**Inspiration base** : Linear / Vercel Dashboard
**Élément emprunté à B** : breadcrumb fin en haut (au lieu d'une top bar de navigation lourde) pour signaler "admin léger, pas chrome dominant"

### Design Rationale

**Pourquoi A domine**
- Plus aligné avec les principes UX (calme, power-user, respect intelligence, clarté)
- Moins daté à 3-5 ans (Linear est la référence contemporaine 2024-2026)
- Meilleure compatibilité avec la neutralité visuelle imposée par l'héritage thème
- Supporte mieux les sessions longues de Cyril (airy, pas de charge cognitive)

**Pourquoi pas B pur**
- Manque de structure pour les actions power-user (bulk, filtres, tri)
- Sensation "app de création" pas alignée avec l'efficacité recherchée

**Pourquoi pas C**
- Trop "business tool" pour un plugin perso
- Cards KPIs proéminentes mangent l'espace utile au contenu
- Moins neutre visuellement

**Pourquoi emprunter le breadcrumb à B**
- Le breadcrumb `All Affiliate > Produits > Nouveau produit` informe la navigation sans occuper une top bar entière
- Libère la zone haute pour les actions contextuelles (ex: `+ Nouveau produit`)

### Implementation Approach

**Structure globale**
- Sidebar fine (60px) avec icônes Lucide + tooltips au hover, dépliable en 240px au toggle
- Breadcrumb fin en haut à gauche (14px, text-muted)
- Content area centrée, max-width 1440px
- Padding content : `aff-space-8` (32px) autour

**Hiérarchie des pages principales (sidebar)**
1. **Produits** (icône `Package`) — liste + création
2. **Plateformes** (icône `Globe`) — profils d'affiliation
3. **Templates** (icône `LayoutGrid`) — galerie des 6 templates
4. **Design** (icône `Palette`) — tokens, composants, preview
5. **Dashboard** (icône `BarChart3`) — stats
6. **Settings** (icône `Settings`) — config globale, disclosure, cache

**Listes (ex: Produits)**
- Liste verticale dense mais airy (padding 16px vertical, 24px horizontal)
- Status pills discrètes à droite (icône + label, couleur sémantique)
- Actions cachées au hover (⋮ menu → Éditer / Dupliquer / Supprimer)
- Checkbox à gauche pour sélection multiple (actions bulk)
- Barre de filtres flottante au-dessus : recherche, plateforme, tri, filtres avancés

**Formulaires (ex: création produit)**
- Layout split-view (40/60) — form gauche, preview live droite
- Progressive disclosure : 3 champs de base + panneau "Avancé" replié
- Sauvegarde auto en bas (discrète), bouton Enregistrer en haut à droite (explicite)
- Bouton "Tester le lien" permanent en haut

**Dashboard**
- 4 cards KPI (petites, sobres) en haut
- 2 graphs côte à côte au centre (tendance 30j, taux clic par template)
- Liste "Top 5 produits" en dessous
- **Pas** de cards KPIs XL façon C — on reste sobre

**Command Palette (⌘K)**
- Overlay modal sombre, centre écran
- Input de recherche + résultats listés
- Quick actions (Créer produit, Voir dashboard...) en tête si input vide
- Navigation clavier pure (↑↓ + Enter)

---

## User Journey Flows

### Flow 1 — Premier déploiement (J1)

Flow le plus long : onboarding + création du premier produit. Cible **< 3 minutes** du plugin activé au premier produit publié.

```mermaid
flowchart TD
    Start([Plugin activé]) --> Notice[Notice WP discrète :<br/>'👋 Configure tes plateformes']
    Notice --> ClickNotice{Cyril clique ?}
    ClickNotice -- Oui --> Platforms[Écran : Mes plateformes<br/>12 profils préinstallés listés]
    ClickNotice -- Non / Plus tard --> Dashboard[Dashboard vide<br/>avec CTA 'Commencer ici']
    Dashboard --> Platforms

    Platforms --> SelectPlatforms[Coche les plateformes utilisées<br/>Ex: Amazon FR, Awin]
    SelectPlatforms --> InputTags[Saisit tag Amazon + affid Awin<br/>dans des champs inline]
    InputTags --> ValidateTags[Validation inline ✓ par champ]
    ValidateTags --> SavePlatforms[Bouton 'Valider']

    SavePlatforms --> ProductsEmpty[Page Produits vide<br/>Empty state + CTA '+ Nouveau produit']
    ProductsEmpty --> ClickNew[Clic '+ Nouveau produit']

    ClickNew --> SelectProfile[Étape 1/2 : choix plateforme]
    SelectProfile --> FormPreview[Étape 2/2 : split-view<br/>Formulaire gauche + Preview droite vide]

    FormPreview --> Paste{Cyril colle un ID/URL}
    Paste -- ASIN valide --> Extract[Extraction ID en 50ms<br/>Badge vert '✓ ASIN extrait']
    Paste -- URL valide --> ExtractURL[Extraction via regex profil<br/>Badge vert]
    Paste -- Format invalide --> ErrorInline[Erreur inline orange<br/>Proposition de format]
    ErrorInline --> Paste

    Extract --> OGFetch[Fetch OpenGraph en arrière-plan]
    ExtractURL --> OGFetch
    OGFetch --> AutoFill[Titre + image auto-remplis<br/>Preview commence à se remplir]

    AutoFill --> RefineType[Cyril affine titre/description<br/>Ajoute image drag-drop si besoin]
    RefineType --> LivePreview[Preview live se met à jour<br/>à chaque frappe < 100ms]

    LivePreview --> TestLink{Cyril teste le lien ?}
    TestLink -- Oui --> OpenAmazon[Nouvel onglet : URL finale<br/>avec tag global appliqué ✓]
    TestLink -- Non --> SaveAuto

    OpenAmazon --> Confirmed[Cyril confirme le tag]
    Confirmed --> SaveAuto[Sauvegarde auto<br/>✓ Sauvegardé en bas]

    SaveAuto --> Done{Cyril veut...}
    Done -- Fermer --> ProductsList[Retour liste produits]
    Done -- Autre produit --> FormPreview
    Done -- Insérer dans article --> GutenbergList[Liste articles en cours]

    ProductsList --> End([Première utilisation réussie])
    GutenbergList --> End
```

### Flow 2 — Routine article : insertion dans Gutenberg (J2)

Flow quotidien. Cible **< 10s** entre ouvrir Gutenberg et voir un bloc Affiliate rendu.

```mermaid
flowchart TD
    Start([Cyril édite un article Gutenberg]) --> AddBlock[Clique '+' pour ajouter bloc]
    AddBlock --> Search[Tape 'affiliate' dans la recherche]
    Search --> SelectBlock[Clique bloc 'All Affiliate']

    SelectBlock --> InitialState[Bloc ouvert avec 3 actions :<br/>Rechercher · Créer · Template]

    InitialState --> ChoosePath{Quel chemin ?}

    ChoosePath -- Rechercher existant --> SearchProduct[Input de recherche<br/>Autocomplétion dès 2 caractères]
    SearchProduct --> SelectProduct[Sélectionne produit]

    ChoosePath -- Créer rapide --> QuickForm[Modal de création rapide<br/>Plateforme + ID + image]
    QuickForm --> QuickSave[Sauvegarde + insertion]

    ChoosePath -- Template-first --> TemplateGallery[Galerie 6 templates<br/>preview live par template]
    TemplateGallery --> SelectTemplate[Clique un template]
    SelectTemplate --> FillSlots[Remplit N slots produits<br/>via autocomplétion ou création]

    SelectProduct --> SelectTemplate2[Choix du template]
    SelectTemplate2 --> InlinePreview[Preview inline dans Gutenberg]
    FillSlots --> InlinePreview
    QuickSave --> InlinePreview

    InlinePreview --> Customize{Personnaliser ?}
    Customize -- Oui --> Inspector[Inspector Gutenberg :<br/>options template + champs optionnels toggles]
    Customize -- Non --> Publish
    Inspector --> Publish[Article publié ou sauvegardé]

    Publish --> Live([Article en ligne avec produits trackés])
```

### Flow 3 — Edge case recovery : produit inactif (J6)

Récupération quand un tag manque. Cible **< 30s** de "alerte" à "produit actif".

```mermaid
flowchart TD
    Start([Cyril publie article avec produit Awin]) --> ProductCreated[Produit créé sans tag Awin]
    ProductCreated --> FrontCheck{Tag Awin configuré ?}

    FrontCheck -- Non --> InactiveState[Produit marqué 'Inactif'<br/>Badge orange dans admin]
    FrontCheck -- Non --> NotRendered[Côté front : rien ne s'affiche<br/>Pas de lien cassé]

    InactiveState --> CyrilSeesList[Cyril consulte liste Produits]
    NotRendered --> CyrilSeesArticle[Ou Cyril ouvre l'article publié]

    CyrilSeesList --> ClickBadge[Clic sur badge 'Tag manquant']
    CyrilSeesArticle --> ClickBadge

    ClickBadge --> DeepLink[Navigation auto vers :<br/>Mes plateformes > Awin<br/>Curseur focus champ affid]
    DeepLink --> FillTag[Cyril saisit affid]
    FillTag --> ValidateInline[Validation inline ✓]
    ValidateInline --> AutoSave[Sauvegarde auto]

    AutoSave --> CacheInvalidate[Cache produits Awin invalidé]
    CacheInvalidate --> ProductActive[Tous les produits Awin<br/>passent en 'Actif']

    ProductActive --> FrontReady[Front : produits affichent maintenant<br/>avec liens construits]
    FrontReady --> End([Récupération < 30s])
```

### Flows secondaires (résumés)

**J3 — Migration de tag**
`Mes plateformes → Amazon FR → Change le tag → Sauvegarde auto → Cache invalidé → Tous les proxies /go/ utilisent le nouveau tag immédiatement`
→ 1 écran, 1 champ édité, 0 article touché.

**J4 — Analyse stratégique**
`Sidebar → Dashboard → 4 graphs visibles → Cyril lit les stats → Décision éditoriale prise → Ferme le plugin`
→ Pas d'interaction complexe, le dashboard fait tout le travail.

**J5 — Nouvelle plateforme custom**
`Mes plateformes → "+ Créer une plateforme" → Modal formulaire (Nom, Template URL, Regex, Icône, Tag) → Sauvegarde → Profil dispo`
→ 1 modal, ~10 champs, ~2 min.

### Journey Patterns (transversaux)

**Pattern 1 — "Split-view with preview"**
J1 (création produit), J2 (template-first). Layout 40/60, preview temps réel, sauvegarde auto en bas.

**Pattern 2 — "Deep-link to the missing config"**
J6 (tag manquant), J3 (migration de tag). Quand un champ manque ou doit être modifié, clic sur le badge → navigation directe + focus automatique sur le champ concerné.

**Pattern 3 — "Paste-to-populate"**
J1 (ASIN/URL), J5 (test de regex). Saisie universelle qui accepte plusieurs formats, détection automatique, feedback inline immédiat.

**Pattern 4 — "Inline validation with colored state"**
Tous les formulaires. ✓ vert si valide, ⚠ orange si warning, ✗ rouge si erreur bloquante. Jamais de popup pour ça.

**Pattern 5 — "Empty state → CTA direct"**
Liste Produits vide (J1), Dashboard vide, filtres sans résultat. Jamais juste "Aucun élément" — toujours un CTA ou explication actionnable.

**Pattern 6 — "Gutenberg block with 3 actions"**
Propre à J2. Un bloc unique qui s'ouvre sur 3 choix mutuellement exclusifs (Rechercher / Créer / Template).

### Flow Optimization Principles

**FOP-1 — "Entry points convergent"**
Plusieurs façons d'entrer dans un flow arrivent au même écran. Réduit l'entropie d'apprentissage.

**FOP-2 — "Progress is visible, but not verbose"**
Pas d'étapes numérotées "Étape 3 sur 12". Mais indications discrètes : "1/2 Plateforme" → "2/2 Produit".

**FOP-3 — "Failures are silent until they need action"**
Une erreur réseau ne produit pas un toast si l'action peut être re-tentée automatiquement. Elle ne parle que si Cyril doit agir.

**FOP-4 — "Recovery > Prevention (pour les edge cases)"**
Plutôt que d'empêcher Cyril de créer un produit sans tag, on permet, on signale, on guide vers la récup.

**FOP-5 — "Autosave over confirm"**
Les modifications sont sauvées en continu (debounce). Le bouton "Enregistrer" marque la fin d'une session.

**FOP-6 — "One critical action per screen"**
Chaque écran a un bouton primary. Les autres actions sont secondary/tertiary.

---

## Component Strategy

### Design System Components (couverture existante)

**Depuis Radix UI (primitives headless)** : `Dialog`, `AlertDialog`, `Popover`, `Tooltip`, `DropdownMenu`, `ContextMenu`, `Select`, `Combobox`, `Checkbox`, `Switch`, `RadioGroup`, `Slider`, `Tabs`, `Accordion`, `Collapsible`, `Toast`, `NavigationMenu`, `ScrollArea`.

**Depuis `@wordpress/components` (limité)** : `MediaUpload`, `MediaPlaceholder`, `BlockControls`, `InspectorControls`.

**Depuis Tailwind préfixé `aff-*`** : layout, spacing, typography, colors via utility classes.

### Custom Components (à construire)

Organisé en **5 niveaux d'abstraction**.

#### Niveau 1 — Primitives stylées

| Composant | Description |
|---|---|
| `Button` | Primary / Secondary / Ghost / Danger / Link, tailles xs/sm/md/lg, états loading, disabled |
| `Input` | Text, number, url avec validation inline visuelle, icon slot |
| `Textarea` | Avec compteur de caractères optionnel |
| `Label` | Avec mention "required" et tooltip info |
| `FormField` | Wrapper Label + Input + HelperText + ErrorMessage |
| `IconButton` | Button icon-only, square, tailles |
| `Badge` | Pill discret, variants neutral/success/warning/danger/info |
| `StatusPill` | Badge spécialisé "Actif/Inactif/Programmé" avec icône + label |
| `Skeleton` | Placeholder animé |
| `Spinner` | Indéterminé, tailles xs/sm/md |
| `Avatar` | Image ronde avec fallback initiales |
| `Card` | Conteneur élevé, variants default/elevated/outlined |
| `Separator` | Ligne horizontale/verticale |

#### Niveau 2 — Composites (UI réutilisables)

| Composant | Description |
|---|---|
| `SearchCombobox` | Input + Popover + résultats + keyboard nav (recherche produit, profil) |
| `EmptyState` | Illustration + titre + description + CTA |
| `BulkActionsBar` | Barre fixée en haut quand N éléments sélectionnés |
| `ConfirmDialog` | AlertDialog préfabriqué avec variants destructif |
| `DeepLinkBadge` | Badge cliquable qui navigue vers la config manquante avec focus auto |
| `InfoTooltip` | Icône `?` + tooltip explicatif (FR50) |
| `CopyButton` | Bouton copie avec feedback "✓ Copié" 2s |
| `TestLinkButton` | Bouton qui ouvre l'URL finale construite dans un nouvel onglet |
| `PageHeader` | Title + breadcrumb + actions slot |
| `FiltersBar` | Recherche + filtres dropdown + tri |
| `TagInput` | Input pour tag global (validation format par plateforme) |

#### Niveau 3 — Métier (spécifiques All Affiliate)

| Composant | Description |
|---|---|
| `ProductForm` | Formulaire complet création/édition produit (3 champs + panneau avancé) |
| `ProductFormSplitView` | ProductForm à gauche + PreviewPane à droite, 40/60 |
| `PreviewPane` | Rendu temps réel d'un template avec le produit en cours |
| `PasteInput` | Input spécial "ASIN ou URL" avec extraction auto + badge feedback |
| `PlatformSelector` | Grid de cards pour choisir un profil plateforme |
| `PlatformProfileCard` | Card d'un profil (nom, icône, status, tag masqué, toggle actif) |
| `PlatformProfileEditor` | Modal de création/édition profil custom |
| `ProductListRow` | Row dans la liste produits avec hover reveal actions |
| `TemplateGallery` | Galerie cliquable des 6 templates avec preview live |
| `TemplateCard` | Card d'un template dans la galerie |
| `TemplatePreview` | Aperçu d'un template avec un produit réel |
| `DashboardKPI` | Petit card chiffre + libellé + variation % |
| `DashboardGraph` | Wrapper graph avec titre et sélecteur de période |
| `TopProductsList` | Liste Top 5 produits triés par clics |
| `DesignTokensEditor` | Formulaire d'édition des Design Tokens |
| `ButtonLibraryEditor` | Création/édition de variantes boutons sauvegardés (DT#3-lite) |
| `PreviewAllTemplatesPanel` | Page "Preview" des 6 templates desktop+mobile live |
| `OptionalFieldsToggleGroup` | Toggle switches pour champs optionnels par produit |
| `CacheManager` | Bouton "Purger le cache" + dernière invalidation |
| `DisclosureEditor` | Texte de disclosure + toggle activation global |

#### Niveau 4 — Layout & shell

| Composant | Description |
|---|---|
| `AppShell` | Layout global : Sidebar + TopBar + Content area |
| `Sidebar` | 60px collapsée, 240px étendue, icônes Lucide + labels |
| `TopBar` | Breadcrumb + Command Palette trigger + user avatar |
| `CommandPalette` | ⌘K overlay avec recherche fuzzy + quick actions |
| `SaveBar` | Barre fixe en bas pendant édition (autosave status + bouton Enregistrer) |
| `Breadcrumb` | Navigation hiérarchique fine |

#### Niveau 5 — Templates front (rendus côté visiteur)

Implémentés en **PHP** (render_callback Gutenberg) + CSS Tailwind :

| Template | Description |
|---|---|
| `TemplateCardStandard` | Image, nom, description, bouton CTA, optionnels étoiles/score/badge réduction |
| `TemplateCardInline` | Card compacte dans le flux (image petite à gauche, texte + CTA à droite) |
| `TemplateCTA` | Bouton proéminent seul, optionnellement prix et logo plateforme |
| `TemplateGrid` | Grille 2-3-4 colonnes de cards avec images uniformes |
| `TemplateTopN` | Liste numérotée 1-10 avec images, descriptions, CTAs, optionnels pros/cons |
| `TemplateProsCons` | Card large avec image + nom + tableau Pros/Cons + CTA |

Chaque template expose un `render_callback` PHP qui charge le produit depuis le CPT, applique les Design Tokens via CSS variables, rend en HTML serveur avec classes `aff-*`.

#### Composants Gutenberg (éditeur)

| Composant | Description |
|---|---|
| `AffiliateBlockInitial` | État initial du bloc : 3 boutons "Rechercher / Créer / Template" |
| `AffiliateBlockFilled` | État après sélection : preview inline du template rendu |
| `AffiliateBlockInspector` | Sidebar Gutenberg : options template + toggles champs optionnels |
| `QuickCreateModal` | Modal minimaliste de création rapide de produit depuis l'éditeur |

### Component Implementation Strategy

**Principes**
1. **Accessibilité par Radix** — on wrap Radix plutôt que de réimplémenter (focus trap, keyboard nav, ARIA)
2. **Tokens-only styling** — aucun `className` sans préfixe `aff-`, aucune valeur en dur
3. **Composables** — chaque composant métier = assemblage de primitives + composites, pas de monolithe
4. **Testable** — chaque primitive testée unitairement (Jest + Testing Library), chaque composant métier testé avec des fixtures
5. **Stories (optionnel V2)** — Storybook possible pour la bibliothèque mais pas obligatoire en MVP

**Structure de fichiers**

```
admin-react/
├── primitives/          ← Niveau 1
├── composites/          ← Niveau 2
├── business/            ← Niveau 3
│   ├── products/
│   ├── platforms/
│   ├── templates/
│   ├── dashboard/
│   └── design/
├── layout/              ← Niveau 4
└── routes/              ← Pages

blocks/gutenberg/
└── affiliate-block/
    ├── edit.tsx
    ├── save.tsx
    └── render.php

front/
└── templates/
    ├── card-standard.php
    ├── card-inline.php
    ├── cta.php
    ├── grid.php
    ├── top-n.php
    └── pros-cons.php
```

### Implementation Roadmap

Aligné avec les 7 phases d'implémentation du PRD.

**Phase 1 — Fondations (Sprint 1-2)**
- Niveau 1 : Button, Input, Label, FormField, Badge, StatusPill, Card
- Niveau 4 : AppShell, Sidebar, TopBar, Breadcrumb
- Niveau 2 : EmptyState, ConfirmDialog, PageHeader, InfoTooltip

**Phase 2 — Core liens & tracking (Sprint 3)**
- Niveau 3 : TagInput, TestLinkButton, PlatformProfileCard, PlatformProfileEditor
- Niveau 2 : CopyButton, DeepLinkBadge

**Phase 3 — UX création (Sprint 4)**
- Niveau 3 : ProductForm, ProductFormSplitView, PreviewPane, PasteInput, PlatformSelector, ProductListRow, OptionalFieldsToggleGroup
- Niveau 2 : SearchCombobox, BulkActionsBar, FiltersBar, SaveBar
- Niveau 1 : Skeleton, Spinner, Textarea, IconButton

**Phase 4 — Système de design (Sprint 5)**
- Niveau 3 : DesignTokensEditor, ButtonLibraryEditor, PreviewAllTemplatesPanel

**Phase 5 — Templates (Sprint 6-7)**
- Niveau 5 : Tous les templates (PHP + CSS Tailwind)
- Niveau 3 : TemplateGallery, TemplateCard, TemplatePreview

**Phase 6 — Bloc Gutenberg (Sprint 8)**
- Gutenberg : AffiliateBlockInitial, AffiliateBlockFilled, AffiliateBlockInspector, QuickCreateModal

**Phase 7 — Data & polish (Sprint 9)**
- Niveau 3 : DashboardKPI, DashboardGraph, TopProductsList, CacheManager, DisclosureEditor
- Niveau 4 : CommandPalette
- Niveau 1 : Avatar, Separator

---

## UX Consistency Patterns

### Button Hierarchy

Hiérarchie visuelle fixe — **1 seule action primary par écran**.

| Variant | Usage | Style |
|---|---|---|
| **Primary** | Action principale (Enregistrer, Créer, Valider) | Fond `--aff-color-primary`, texte `--aff-color-primary-foreground`, radius `md`, ombrage `sm` |
| **Secondary** | Action secondaire (Annuler, Fermer) | Fond transparent, bordure `--aff-color-border-strong`, texte `--aff-color-text-primary` |
| **Ghost** | Actions tertiaires (Dupliquer, ⋮ menu) | Fond transparent, texte `--aff-color-text-secondary`, hover : surface légère |
| **Danger** | Actions destructives (Supprimer) | Fond `--aff-color-danger`, texte blanc, confirmation requise |
| **Link** | Navigation inline (Voir détails) | Texte `--aff-color-primary`, underline au hover |

**Règles**
- Un seul bouton Primary par écran visible
- Les boutons Danger requièrent toujours une confirmation (`ConfirmDialog`)
- Taille par défaut : `md` (40px hauteur). `sm` pour les inline actions, `lg` pour les CTAs héros
- Icônes Lucide à gauche du label si utile
- États : default / hover / focus-visible / active / disabled / loading (avec Spinner inline)
- Mobile : taille minimum 44px (tactile), gap 8px entre boutons adjacents

### Feedback Patterns

4 niveaux sémantiques couvrant tous les cas :

| Niveau | Usage | Visuel | Durée |
|---|---|---|---|
| **Success** | Confirmation d'action réussie | Icône ✓ + texte, couleur `--aff-color-success` | Toast 2s ou inline permanent |
| **Warning** | Attention non-bloquante (ex: tag manquant) | Icône ⚠ + texte, couleur `--aff-color-warning` | Inline permanent + deep-link |
| **Danger** | Erreur bloquante | Icône ✗ + texte, couleur `--aff-color-danger` | Inline + explicit dismiss |
| **Info** | Information contextuelle | Icône ℹ + texte, couleur `--aff-color-info` | Au hover ou on-demand |

**Règles**
- Success : **jamais de toast bloquant**, jamais de confetti, disparition auto en 2s
- Warning : **badges inline toujours**, jamais de popup. Toujours accompagnés d'un CTA (FR20)
- Danger : **explicite et dismissable manuellement**, jamais auto-dismiss
- Info : tooltips ou petites cards, **jamais modaux**
- Saving auto : indicateur discret en bas de l'écran (`✓ Sauvegardé` fade 2s)

**Anti-patterns**
- Toast "Succès ! Votre produit a été enregistré" après chaque save (trop bruyant)
- Popup bloquant pour une erreur non-critique
- Message rouge agressif pour un tag manquant (c'est orange, pas rouge)

### Form Patterns

**Structure universelle**
```
[Label *]                       ← Label clair, * si obligatoire
[Input                       ]  ← Input avec placeholder explicite
Texte d'aide discret en gris    ← Helper text (InfoTooltip si long)
✓ Valid ou ⚠ Invalid            ← Validation inline à la frappe
```

**Règles**
- Validation inline : au blur du champ OU au changement (formats connus comme ASIN, email, URL)
- Messages d'erreur : en dessous du champ, `--aff-color-danger`, disparition dès correction
- Champs optionnels : pas de mention "(optionnel)" bruyante — utiliser l'absence du `*`
- Grouping : 3 champs obligatoires (FR12) toujours visibles, reste dans un `Accordion` replié par défaut
- Sauvegarde : autosave par défaut (debounce 500ms), bouton "Enregistrer" = confirmation explicite pour fermer
- Submit : bouton Primary en bas à droite OU dans le `SaveBar` sticky
- Cancel : bouton Secondary à gauche de Submit

**Mobile** : champs full-width, boutons empilés verticalement, clavier approprié (`inputmode="url"`, `inputmode="numeric"`).

### Navigation Patterns

**Global (AppShell)**
- Sidebar gauche : navigation principale, 6 sections (Produits, Plateformes, Templates, Design, Dashboard, Settings)
- Breadcrumb top : contexte de navigation
- Command Palette ⌘K : raccourci universel pour naviguer ET agir
- **Aucun top-menu horizontal** : sidebar = navigation unique

**Contextuelle**
- Tabs : pour les sous-sections d'une page (ex: Settings > Design > Tokens / Composants / Preview)
- Back button : implicite via breadcrumb, pas de flèche "Retour" redondante

**Mobile**
- Sidebar collapsée par défaut (hamburger pour ouvrir)
- Tabs restent horizontales (scroll si débordement)

### Modal / Overlay Patterns

**Règles**
- Modal (`Dialog`) : réservé aux actions qui bloquent le flux global (création rapide produit, édition profil plateforme)
- AlertDialog : uniquement pour confirmations d'actions irréversibles
- Popover : pour des contrôles contextuels (sélecteurs, date pickers)
- Drawer / Sheet : pas au MVP (V2 si besoin)

**Comportement**
- ESC ferme toujours (sauf AlertDialog bloquant)
- Clic sur overlay ferme (sauf AlertDialog bloquant)
- Focus trap obligatoire (géré par Radix)
- Focus retour à l'élément qui a ouvert à la fermeture

### Empty States

**Structure universelle**
```
[Illustration ou icône centrale, 64x64px, grayscale]
[Titre court : "Aucun produit pour l'instant"]
[Description : "Commence par en créer un."]
[Bouton Primary CTA]
```

**Cas à traiter**
- Liste Produits vide → CTA "+ Nouveau produit"
- Aucun profil activé → CTA "Configurer mes plateformes"
- Dashboard sans data → CTA "Créer ton premier produit"
- Recherche sans résultat → texte + "Essaie une autre requête"

**Règles** : jamais juste "Aucun élément" sans action. Illustration discrète (icône Lucide).

### Loading States

| Situation | Stratégie |
|---|---|
| Transition de page | Rien (transitions instantanées, data prefetch) |
| Chargement de liste (cache MISS) | Skeleton loaders reproduisant la structure (5-10 lignes fantômes) |
| Action utilisateur en cours (save, delete) | Spinner inline dans le bouton |
| Chargement d'image | Placeholder gris puis fade-in 150ms |
| Preview live pendant frappe | Debounce 50ms + fade subtil |

**Anti-patterns** : spinner plein écran, message "Chargement..." sous skeleton, skeleton qui ne correspond pas à la structure finale.

### Search & Filtering

```
┌──────────────────────────────────────────────────────────┐
│ Q Rechercher...   [Plateforme ▾] [Tri ▾] [Plus filtres] │
└──────────────────────────────────────────────────────────┘
```

**Règles**
- Recherche : input avec icône loupe, debounce 200ms, fuzzy match
- Filtres : dropdown `Select` avec multi-sélection si pertinent
- Tri : dropdown avec options "Nom A-Z", "Plus récent", "Plus de clics", etc.
- Persistence : filtres actifs reflétés dans l'URL (queryparams)
- Reset : bouton "Effacer les filtres" visible quand ≥ 1 filtre est actif
- Résultats : compteur `"42 produits"` ou `"3 sur 42 produits"` si filtré

**Command Palette `⌘K`** : recherche et action globales.

### Table & List Patterns

- Densité par défaut : 64px par row, texte 16px (airy)
- Densité dense (option) : 48px par row, texte 14px
- Hover reveal : actions à droite apparaissent au hover (Notion style)
- Sélection multiple : checkbox à gauche + checkbox header + `BulkActionsBar` en haut
- Responsive : sur mobile, tables deviennent des stacks de cards
- Sort : clic sur header trie, icône arrow pour indiquer le sens
- Pagination : `Load more` (< 50 items) ou pagination numérotée (> 50 items)

### Tooltip & Help Patterns

- Icône `?` à côté d'un label → tooltip au hover avec explication
- Microcopy dense, 1-2 phrases max
- Délai d'apparition : 300ms
- Touch devices : tap long pour afficher, tap ailleurs pour fermer
- Shortcuts : si un élément a un raccourci clavier, tooltip l'indique (`Enregistrer ⌘S`)

### Keyboard Shortcuts (MVP)

**Globaux**
- `⌘K` / `Ctrl+K` : Command Palette
- `⌘S` / `Ctrl+S` : Enregistrer (sur formulaires)
- `⌘N` / `Ctrl+N` : Nouveau produit (depuis liste Produits)
- `Esc` : Ferme modal/overlay
- `/` : Focus sur la recherche (si présente)

**Liste**
- `↑↓` : navigation entre rows
- `Enter` : ouvrir/éditer row focus
- `Space` : toggle checkbox
- `Delete` : supprimer row (avec confirmation)

**Formulaires**
- `Tab` / `Shift+Tab` : navigation logique
- `Enter` dans un champ : soumet le formulaire (sauf textarea)

### Visual Feedback Summary

**Micro-interactions obligatoires**
- Hover sur interactif : `--aff-duration-fast` (100ms), luminosité +5% ou opacity +10%
- Focus visible : outline 2px `--aff-color-primary`, offset 2px
- Click/Tap : scale 0.98 pendant 100ms (sauf reduced motion)
- Toast entrée : slide-up 150ms + fade-in
- Toast sortie : fade-out 150ms

**Règles reduced motion**
- Toutes les animations désactivées ou à 0ms
- Transitions essentielles (focus) gardent 100ms minimum pour être perceptibles

---

## Responsive Design & Accessibility

### Responsive Strategy

Principe global : **asymétrie assumée** entre admin et front.

| Contexte | Approche | Priorité |
|---|---|---|
| Admin React | **Desktop-first** optimisé pour grand écran | 100% desktop |
| Front (templates visiteurs) | **Mobile-first** strict | 70%+ mobile |
| Éditeur Gutenberg | Majoritairement desktop | Responsive mais non-optimisé mobile |

**Admin desktop (principal)**
- Optimisé pour 1280px+ (MacBook 13", écrans pro)
- Layout split-view 40/60 exploite l'espace latéral
- Sidebar fixe 60/240px toujours visible
- Au-dessus de 1440px : container centré avec marges (pas d'étirement infini)

**Admin tablet (768-1023px)**
- Sidebar collapse en icons-only (60px)
- Split-view se reconfigure en stack vertical (form dessus, preview dessous)
- Tables deviennent des cards compactes

**Admin mobile (< 768px)**
- Sidebar cachée par défaut (hamburger menu)
- Admin utilisable pour consultation (listes, dashboard), **non optimisé pour édition**
- Tables deviennent des stacks de cards
- SplitView devient pure preview (édition limitée sur mobile)

**Front — Mobile-first strict**
- Design à partir du plus petit écran supporté (320px)
- Chaque template pensé mobile d'abord puis étendu desktop
- Breakpoint critique : 640px (sm) où les grilles multi-colonnes prennent effet
- Tailles tactiles 44x44px minimum pour tous les CTAs

### Breakpoint Strategy

Breakpoints Tailwind standard (pas de custom) :

| Breakpoint | Taille min | Contexte | Usage All Affiliate |
|---|---|---|---|
| (default) | 0 | Mobile portrait | Templates front mobile, admin consultation |
| `sm` | 640px | Mobile landscape / petite tablette | Grilles 2-col front, admin hamburger → visible |
| `md` | 768px | Tablette | Sidebar admin icons-only, grilles 3-col front |
| `lg` | 1024px | Desktop | Sidebar admin étendue, split-view, grilles 4-col front |
| `xl` | 1280px | Desktop confort | Admin optimal, max-width container |
| `2xl` | 1536px | Grand écran | Admin plein layout, pas d'étirement supplémentaire |

**Règles**
- Mobile-first CSS : styles de base sans media query, puis overrides `sm:`, `md:`, `lg:`
- Jamais de `hidden lg:block` pour simuler du responsive via cache/affiche — préférer des variants de composants
- Container max-width : `aff-max-w-screen-2xl` (1536px) par défaut pour l'admin

### Accessibility Strategy

**Cible : WCAG 2.1 niveau AA** (NFR-A1)

| Critère WCAG | Respect | Comment |
|---|---|---|
| 1.1.1 Contenu non textuel (AA) | ✅ | `alt` sur images, `aria-label` sur icon-buttons |
| 1.3.1 Information et relations (AA) | ✅ | Semantic HTML, landmarks `<main>`, `<nav>`, `<aside>`, rôles ARIA |
| 1.4.3 Contraste (AA) | ✅ | ≥ 4.5:1 body, ≥ 3:1 large text, axe-core au build |
| 1.4.4 Redimensionnement du texte (AA) | ✅ | Tailles en `rem`, zoom 200% sans perte |
| 1.4.11 Contraste non-textuel (AA) | ✅ | Contraste ≥ 3:1 pour boutons, inputs |
| 2.1.1 Clavier (A) | ✅ | Tous les éléments focusables (Radix gère) |
| 2.1.2 Pas de piège clavier (A) | ✅ | Focus trap Radix avec échappement `Esc` |
| 2.4.3 Ordre de focus (A) | ✅ | Ordre logique |
| 2.4.7 Focus visible (AA) | ✅ | Outline 2px `--aff-color-primary` avec offset 2px |
| 2.5.5 Taille des cibles (AAA appliqué) | ✅ | 44x44px côté front, 40x40 admin |
| 3.1.1 Langue (A) | ✅ | `lang="fr"` sur le container admin |
| 3.3.1 Identification des erreurs (A) | ✅ | Messages inline, `aria-invalid="true"` |
| 3.3.2 Étiquettes ou instructions (A) | ✅ | Labels + placeholders + helper texts |
| 4.1.2 Nom, rôle, valeur (A) | ✅ | Via Radix UI pour composants complexes |
| 4.1.3 Messages d'état (AA) | ✅ | `aria-live="polite"` sur toasts, feedbacks |

**Au-delà de WCAG AA**
- Support `prefers-reduced-motion` strict
- Support `prefers-color-scheme` (dark mode natif)
- Touch targets ≥ 44x44 côté front (critère AAA)
- Focus visible toujours présent

**Non-objectifs**
- WCAG AAA complet (trop strict, coût démesuré)
- Audits accessibilité externes payants
- Support technologies très spécifiques (commande vocale...)

### Testing Strategy

**Tests automatisés (MVP)**

| Outil | Usage | Fréquence |
|---|---|---|
| Lighthouse | Perf, A11y, SEO, Best Practices | À chaque build, cible ≥ 90 |
| axe-core | A11y détaillée, WCAG 2.1 AA | CI à chaque PR |
| Jest + Testing Library | Tests unitaires React | Tests comportementaux (focus, keyboard, ARIA) |
| Playwright | E2E sur les 6 journeys | CI principal avant merge |
| Tailwind linting | Détection de classes non-préfixées | Pre-commit hook |

**Tests manuels (Cyril lui-même)**

| Test | Périodicité | Checklist |
|---|---|---|
| Navigation clavier pure | Release mineure | Tab/Shift+Tab/Enter/Esc/flèches fonctionnent partout |
| Screen reader (VoiceOver macOS) | Release majeure | Lire Produits + formulaire avec fermeture des yeux |
| Zoom 200% | Release majeure | Toutes les pages restent utilisables |
| Reduced motion | Release majeure | Toggle System Preferences et vérifier |
| Dark mode | Release majeure | Passage auto fonctionne sur 2-3 thèmes testés |
| Mobile réel | Release majeure | Site réel avec plugin sur iPhone + Android |
| Thèmes conflits | Release majeure | 2 thèmes Tailwind (Tailpress, Oxygen) + 2 thèmes classiques (Astra, TT4) |

**Tests utilisateur**
- Cyril = utilisateur unique, donc il est lui-même le test user
- Pas besoin de user testing externe (cadre personnel)
- Feedback recueilli via dogfooding sur ses propres sites

### Implementation Guidelines

**Responsive — mobile-first avec Tailwind**
```tsx
// ✅ Bon
<div className="aff-grid aff-grid-cols-1 sm:aff-grid-cols-2 lg:aff-grid-cols-3 aff-gap-4">
  {products.map(p => <ProductCard key={p.id} product={p} />)}
</div>

// ❌ Mauvais : desktop-first
<div className="aff-grid aff-grid-cols-3 max-sm:aff-grid-cols-1">
```

**Accessibilité — semantic HTML**
```tsx
// ✅ Bon
<main>
  <header>
    <h1>Produits</h1>
    <nav aria-label="Actions de la page"><button>+ Nouveau produit</button></nav>
  </header>
  <section aria-labelledby="filters-heading">
    <h2 id="filters-heading" className="aff-sr-only">Filtres</h2>
    ...
  </section>
</main>
```

**ARIA (quand semantic HTML ne suffit pas)**
```tsx
<div role="img" aria-label="Score 8 sur 10">
  <ScoreGauge value={8} />
</div>

<span role="status" aria-label="Produit actif">
  <StatusPill status="active" />
</span>

<div role="status" aria-live="polite">
  ✓ Sauvegardé
</div>
```

**Focus management**
```tsx
<Dialog.Content onOpenAutoFocus={(e) => {
  e.preventDefault();
  firstInputRef.current?.focus();
}}>
  ...
</Dialog.Content>
```

**Images responsive**
```tsx
<img
  src={product.image}
  srcSet={`${product.image}?w=320 320w, ${product.image}?w=640 640w, ${product.image}?w=1280 1280w`}
  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
  alt={product.name}
  loading="lazy"
  decoding="async"
/>
```

**Dark mode — tokens conditionnels**
```css
:root {
  --aff-color-background: #ffffff;
  --aff-color-text-primary: #0f172a;
}

@media (prefers-color-scheme: dark) {
  :root {
    --aff-color-background: #0f172a;
    --aff-color-text-primary: #f8fafc;
  }
}

[data-aff-theme="dark"] {
  --aff-color-background: #0f172a;
  --aff-color-text-primary: #f8fafc;
}
```
