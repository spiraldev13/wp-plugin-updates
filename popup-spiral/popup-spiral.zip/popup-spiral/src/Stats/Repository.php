<?php

namespace Spiral\Stats;

use Spiral\Dates;
use Spiral\Install;
use Spiral\PostTypes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Accès à la table de statistiques journalières.
 *
 * Écriture atomique (`INSERT … ON DUPLICATE KEY UPDATE count = count + 1`) et
 * lectures agrégées par période. Aucune donnée personnelle : uniquement des
 * compteurs par popup, par type d'événement et par jour.
 */
final class Repository
{
    /** Types d'événements suivis. */
    public const EVENTS = ['open', 'click'];

    /**
     * Incrémente de 1 le compteur du jour pour un popup et un événement.
     * L'opération est atomique côté base : deux requêtes concurrentes ne se
     * marchent pas dessus (pas de lecture-puis-écriture applicative).
     */
    public static function record(int $popupId, string $event, ?string $day = null): void
    {
        if (!in_array($event, self::EVENTS, true) || $popupId <= 0) {
            return;
        }

        global $wpdb;

        $table = Install::statsTable();
        $day = $day !== null ? (Dates::sanitizeDay($day) ?? Dates::today()) : Dates::today();

        $wpdb->query($wpdb->prepare(
            "INSERT INTO $table (popup_id, event_type, event_date, count)
             VALUES (%d, %s, %s, 1)
             ON DUPLICATE KEY UPDATE count = count + 1",
            $popupId,
            $event,
            $day
        ));
    }

    /**
     * Totaux vues/clics sur une période, éventuellement pour un seul popup.
     *
     * @return array{views: int, clicks: int}
     */
    public static function totals(?int $popupId, string $from, string $to): array
    {
        $rows = self::query(
            'event_type, SUM(count) AS c',
            'event_type',
            $popupId,
            $from,
            $to
        );

        $totals = ['views' => 0, 'clicks' => 0];

        foreach ($rows as $row) {
            if ($row['event_type'] === 'open') {
                $totals['views'] = (int) $row['c'];
            } elseif ($row['event_type'] === 'click') {
                $totals['clicks'] = (int) $row['c'];
            }
        }

        return $totals;
    }

    /**
     * Série journalière vues/clics, jours sans événement inclus à zéro.
     *
     * @return array<int, array{date: string, views: int, clicks: int}>
     */
    public static function dailySeries(?int $popupId, string $from, string $to): array
    {
        $rows = self::query(
            'event_date, event_type, SUM(count) AS c',
            'event_date, event_type',
            $popupId,
            $from,
            $to
        );

        $map = [];

        foreach ($rows as $row) {
            $date = (string) $row['event_date'];
            $map[$date] = $map[$date] ?? ['views' => 0, 'clicks' => 0];

            if ($row['event_type'] === 'open') {
                $map[$date]['views'] = (int) $row['c'];
            } elseif ($row['event_type'] === 'click') {
                $map[$date]['clicks'] = (int) $row['c'];
            }
        }

        $series = [];

        foreach (Dates::range($from, $to) as $day) {
            $series[] = [
                'date' => $day,
                'views' => $map[$day]['views'] ?? 0,
                'clicks' => $map[$day]['clicks'] ?? 0,
            ];
        }

        return $series;
    }

    /**
     * Totaux vues/clics par popup sur une période (popups sans donnée exclus).
     *
     * @return array<int, array{views: int, clicks: int}> indexé par popup_id
     */
    public static function perPopup(string $from, string $to): array
    {
        $rows = self::query(
            'popup_id, event_type, SUM(count) AS c',
            'popup_id, event_type',
            null,
            $from,
            $to
        );

        $result = [];

        foreach ($rows as $row) {
            $id = (int) $row['popup_id'];
            $result[$id] = $result[$id] ?? ['views' => 0, 'clicks' => 0];

            if ($row['event_type'] === 'open') {
                $result[$id]['views'] = (int) $row['c'];
            } elseif ($row['event_type'] === 'click') {
                $result[$id]['clicks'] = (int) $row['c'];
            }
        }

        return $result;
    }

    /**
     * Supprime les agrégats d'un popup supprimé (évite les lignes orphelines).
     * Branché sur `before_delete_post`.
     *
     * @param int $postId
     */
    public static function onPostDelete($postId): void
    {
        if (get_post_type($postId) === PostTypes::POPUP) {
            global $wpdb;
            $wpdb->delete(Install::statsTable(), ['popup_id' => (int) $postId], ['%d']);
        }
    }

    /**
     * Totaux cumulés « depuis toujours » lus dans les metas (compteurs hérités,
     * hors table journalière). Pour un popup, ou tous les popups si null.
     *
     * @return array{views: int, clicks: int}
     */
    public static function cumulativeTotals(?int $popupId): array
    {
        if ($popupId !== null) {
            return [
                'views' => (int) get_post_meta($popupId, 'spiral_open_count', true),
                'clicks' => (int) get_post_meta($popupId, 'spiral_click_count', true),
            ];
        }

        return [
            'views' => self::sumMeta('spiral_open_count'),
            'clicks' => self::sumMeta('spiral_click_count'),
        ];
    }

    /**
     * Somme d'une meta compteur sur tous les popups non supprimés.
     */
    private static function sumMeta(string $metaKey): int
    {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(pm.meta_value), 0)
             FROM $wpdb->postmeta pm
             INNER JOIN $wpdb->posts p ON p.ID = pm.post_id
             WHERE pm.meta_key = %s AND p.post_type = %s AND p.post_status != 'trash'",
            $metaKey,
            PostTypes::POPUP
        ));
    }

    /**
     * Première journée enregistrée (site), ou null si la table est vide.
     */
    public static function firstDay(): ?string
    {
        global $wpdb;

        $table = Install::statsTable();
        $value = $wpdb->get_var("SELECT MIN(event_date) FROM $table");

        return $value !== null ? (string) $value : null;
    }

    /**
     * Taux de clic (clics / vues × 100), arrondi à une décimale.
     */
    public static function ctr(int $views, int $clicks): float
    {
        if ($views <= 0) {
            return 0.0;
        }

        return round($clicks / $views * 100, 1);
    }

    /**
     * Requête agrégée générique, bornée par période et éventuellement par popup.
     * Toutes les valeurs passent par `prepare` (requêtes préparées).
     *
     * @return array<int, array<string, mixed>>
     */
    private static function query(string $select, string $groupBy, ?int $popupId, string $from, string $to): array
    {
        $from = Dates::sanitizeDay($from);
        $to = Dates::sanitizeDay($to);

        if ($from === null || $to === null || $from > $to) {
            return [];
        }

        global $wpdb;

        $table = Install::statsTable();

        if ($popupId !== null) {
            $sql = $wpdb->prepare(
                "SELECT $select FROM $table
                 WHERE event_date BETWEEN %s AND %s AND popup_id = %d
                 GROUP BY $groupBy",
                $from,
                $to,
                $popupId
            );
        } else {
            $sql = $wpdb->prepare(
                "SELECT $select FROM $table
                 WHERE event_date BETWEEN %s AND %s
                 GROUP BY $groupBy",
                $from,
                $to
            );
        }

        $rows = $wpdb->get_results($sql, ARRAY_A);

        return is_array($rows) ? $rows : [];
    }
}
