/**
 * TechAna Revue — script unique du thème, chargé en defer, sans dépendance.
 * Reprise du script des maquettes (design/), adaptée au rendu WordPress :
 * chaque comportement se désarme si son élément est absent de la page.
 */
( function () {
    'use strict';

    /* fil à la une — défilement manuel uniquement, jamais automatique */
    var tickerItem = document.getElementById( 'ticker-item' );
    var tickerData = document.getElementById( 'ticker-data' );
    if ( tickerItem && tickerData ) {
        var headlines = Array.prototype.map.call(
            tickerData.querySelectorAll( 'a' ),
            function ( a ) {
                return { titre: a.textContent, url: a.getAttribute( 'href' ) };
            }
        );
        var pos = document.getElementById( 'ticker-pos' );
        var index = 0;
        var renderHeadline = function ( step ) {
            index = ( index + step + headlines.length ) % headlines.length;
            tickerItem.textContent = headlines[ index ].titre;
            tickerItem.setAttribute( 'href', headlines[ index ].url );
            if ( pos ) {
                pos.textContent = ( index + 1 ) + ' / ' + headlines.length;
            }
        };
        var prev = document.getElementById( 'tk-prev' );
        var next = document.getElementById( 'tk-next' );
        if ( prev ) {
            prev.addEventListener( 'click', function () { renderHeadline( -1 ); } );
        }
        if ( next ) {
            next.addEventListener( 'click', function () { renderHeadline( 1 ); } );
        }
    }

    /* panneau « Plus » */
    var moreBtn = document.getElementById( 'more-btn' );
    var morePanel = document.getElementById( 'more-panel' );
    if ( moreBtn && morePanel ) {
        moreBtn.addEventListener( 'click', function () {
            var isOpen = morePanel.dataset.open === 'true';
            morePanel.dataset.open = String( ! isOpen );
            moreBtn.setAttribute( 'aria-expanded', String( ! isOpen ) );
        } );
    }

    /* menu mobile — le focus reste enfermé dans le panneau tant qu'il est ouvert */
    var burger = document.getElementById( 'burger' );
    var menu = document.getElementById( 'mobile-menu' );
    var closeBtn = document.getElementById( 'menu-close' );
    var FOCUSABLE = 'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])';

    function closeMenu() {
        if ( ! menu || menu.dataset.open !== 'true' ) {
            return;
        }
        menu.dataset.open = 'false';
        burger.setAttribute( 'aria-expanded', 'false' );
        document.body.style.overflow = '';
        burger.focus();
    }
    if ( burger && menu && closeBtn ) {
        burger.addEventListener( 'click', function () {
            menu.dataset.open = 'true';
            burger.setAttribute( 'aria-expanded', 'true' );
            document.body.style.overflow = 'hidden';
            closeBtn.focus();
        } );
        closeBtn.addEventListener( 'click', closeMenu );
        menu.addEventListener( 'keydown', function ( event ) {
            if ( event.key !== 'Tab' ) {
                return;
            }
            var items = Array.prototype.slice.call( menu.querySelectorAll( FOCUSABLE ) );
            if ( ! items.length ) {
                return;
            }
            var first = items[ 0 ];
            var last = items[ items.length - 1 ];
            if ( event.shiftKey && document.activeElement === first ) {
                event.preventDefault();
                last.focus();
            } else if ( ! event.shiftKey && document.activeElement === last ) {
                event.preventDefault();
                first.focus();
            }
        } );
    }

    /* Échap ferme le panneau « Plus » et le menu mobile */
    document.addEventListener( 'keydown', function ( event ) {
        if ( event.key !== 'Escape' ) {
            return;
        }
        if ( morePanel ) {
            morePanel.dataset.open = 'false';
            moreBtn.setAttribute( 'aria-expanded', 'false' );
        }
        closeMenu();
    } );

    /* en-tête réduit : apparaît une fois le haut de page dépassé */
    var stickybar = document.querySelector( '.stickybar' );
    if ( stickybar ) {
        stickybar.setAttribute( 'aria-hidden', 'true' );
        var ticking = false;
        window.addEventListener( 'scroll', function () {
            if ( ticking ) {
                return;
            }
            ticking = true;
            window.requestAnimationFrame( function () {
                document.body.classList.toggle( 'is-scrolled', window.scrollY > 420 );
                ticking = false;
            } );
        }, { passive: true } );
    }

    /* latérale collante : figée dès que sa fin atteint le bas de l'écran.
       Le CSS ne peut pas exprimer « 100vh moins la hauteur de la colonne »
       sans connaître cette hauteur — elle est mesurée ici et reposée à chaque
       changement de taille (fenêtre, images chargées après coup). */
    var laterale = document.querySelector( '.layout > aside' );
    if ( laterale && ! laterale.querySelector( '.sticky-toc' ) ) {
        var MARGE_HAUT = 70;  // sous l'en-tête réduit, comme le sommaire d'article
        var MARGE_BAS = 32;   // --g-lg
        var calerLaterale = function () {
            // Sous 1024 px la colonne repasse sous le contenu : le CSS ne la rend
            // plus collante, inutile de lui poser un décalage.
            if ( 'sticky' !== getComputedStyle( laterale ).position ) {
                laterale.style.top = '';
                return;
            }
            var barre = document.getElementById( 'wpadminbar' );
            var haut = MARGE_HAUT + (
                barre && 'fixed' === getComputedStyle( barre ).position ? barre.offsetHeight : 0
            );
            var reste = window.innerHeight - laterale.offsetHeight - MARGE_BAS;
            // Colonne plus haute que l'écran : `reste` est négatif, la colonne
            // s'arrête donc sur sa fin. Plus courte : elle se cale sous l'en-tête.
            laterale.style.top = Math.min( haut, reste ) + 'px';
        };
        calerLaterale();
        window.addEventListener( 'resize', calerLaterale, { passive: true } );
        if ( window.ResizeObserver ) {
            new ResizeObserver( calerLaterale ).observe( laterale );
        }
    }

    /* bouton de copie des blocs de code */
    document.querySelectorAll( '.codeblock .copy' ).forEach( function ( btn ) {
        btn.addEventListener( 'click', function () {
            var code = btn.closest( '.codeblock' ).querySelector( 'code' ).innerText;
            navigator.clipboard.writeText( code ).then( function () {
                btn.textContent = 'Copié';
                btn.dataset.done = 'true';
                setTimeout( function () {
                    btn.textContent = 'Copier';
                    btn.dataset.done = 'false';
                }, 1800 );
            }, function () {} );
        } );
    } );

    /* recherche : le bouton ✕ vide le champ sans soumettre */
    document.querySelectorAll( '.search-big .clear' ).forEach( function ( btn ) {
        btn.addEventListener( 'click', function () {
            var input = btn.closest( '.search-big' ).querySelector( 'input[type="search"]' );
            input.value = '';
            input.focus();
        } );
    } );

    /* sommaire : la section lue porte le filet accent */
    var tocLinks = document.querySelectorAll( '.toc a' );
    if ( tocLinks.length && 'IntersectionObserver' in window ) {
        var links = new Map();
        tocLinks.forEach( function ( a ) {
            var id = ( a.getAttribute( 'href' ) || '' ).slice( 1 );
            if ( ! id ) {
                return;
            }
            if ( ! links.has( id ) ) {
                links.set( id, [] );
            }
            links.get( id ).push( a );
        } );
        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry ) {
                if ( ! entry.isIntersecting ) {
                    return;
                }
                links.forEach( function ( group ) {
                    group.forEach( function ( a ) { a.classList.remove( 'on' ); } );
                } );
                ( links.get( entry.target.id ) || [] ).forEach( function ( a ) {
                    a.classList.add( 'on' );
                } );
            } );
        }, { rootMargin: '-76px 0px -70% 0px' } );
        document.querySelectorAll( '.prose h2[id]' ).forEach( function ( h ) {
            observer.observe( h );
        } );
    }
}() );
