<?php

namespace Spiral\Admin;

use Spiral\PostTypes;
use Spiral\Preview;
use Spiral\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Actions de ligne « Prévisualiser » et « Tester ».
 *
 * - « Prévisualiser » : aperçu sécurisé (nonce + capacité), toujours disponible,
 *   même pour un brouillon ou un popup désactivé — sans stat ni cookie.
 * - « Tester (page réelle) » : ouvre une page ciblée avec ?spiral-test, pour
 *   voir le popup live en conditions réelles (n'incrémente plus les stats).
 */
final class TestLink
{
    public static function register(): void
    {
        add_filter('post_row_actions', [self::class, 'addRowAction'], 10, 2);
    }

    /**
     * @param array    $actions
     * @param \WP_Post $post
     * @return array
     */
    public static function addRowAction($actions, $post)
    {
        if ($post->post_type !== PostTypes::POPUP) {
            return $actions;
        }

        // Prévisualisation sécurisée : disponible pour tous les popups.
        if (current_user_can('edit_post', $post->ID)) {
            $actions['spiral_preview'] = '<a href="' . esc_url(Preview::url((int) $post->ID)) . '" target="_blank" rel="noopener">'
                . esc_html__('Prévisualiser', 'popup-spiral') . '</a>';
        }

        // Test en conditions réelles : seulement si le popup cible une page.
        $url = self::urlFor((int) $post->ID);

        if ($url !== '') {
            $actions['spiral_test'] = '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">'
                . esc_html__('Tester (page réelle)', 'popup-spiral') . '</a>';
        }

        return $actions;
    }

    /**
     * URL d'une page ciblée par le popup, en mode test ; vide si aucune cible.
     */
    public static function urlFor(int $popupId): string
    {
        $targeting = Settings::get($popupId)['targeting'];

        if (!empty($targeting['whole_site']) || !empty($targeting['front_page'])) {
            return add_query_arg('spiral-test', '1', home_url('/'));
        }

        foreach (array_merge($targeting['pages'], $targeting['posts']) as $targetId) {
            $permalink = get_permalink((int) $targetId);

            if ($permalink) {
                return add_query_arg('spiral-test', '1', $permalink);
            }
        }

        if (!empty($targeting['categories'])) {
            $link = get_category_link((int) $targeting['categories'][0]);

            if (is_string($link) && $link !== '') {
                return add_query_arg('spiral-test', '1', $link);
            }
        }

        return '';
    }
}
