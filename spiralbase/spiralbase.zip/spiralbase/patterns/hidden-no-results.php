<?php
/**
 * Title: Aucun résultat
 * Slug: spiralbase/hidden-no-results
 * Inserter: no
 *
 * Chaîne UI traduisible du bloc « aucun résultat » de la boucle principale.
 */
?>
<!-- wp:paragraph -->
<p><?php echo esc_html__('Aucun contenu pour le moment.', 'spiralbase'); ?></p>
<!-- /wp:paragraph -->
