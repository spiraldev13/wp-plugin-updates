<?php
/**
 * Page de paramètres des styles pour Ultimate Shanks
 *
 * @package UltimateShanks\Style
 */

namespace UltimateShanks\Style;

class Settings
{
	/**
	 * Initialise les paramètres
	 */
	public static function init()
	{
		add_action('admin_init', [self::class, 'register_settings']);
	}

	/**
	 * Enregistre tous les paramètres
	 */
	public static function register_settings()
	{
		// === TITRES H1-H6 ===
		register_setting('ultimate_shanks_style', 'ultimate_shanks_headings_scope');

		for ($i = 1; $i <= 6; $i++) {
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_enabled");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_color");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_background");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_padding");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_margin");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_font_size");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_font_weight");
			register_setting('ultimate_shanks_style', "ultimate_shanks_h{$i}_border");
		}

		// === LISTES ===
		register_setting('ultimate_shanks_style', 'ultimate_shanks_lists_scope');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_background');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_padding');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_margin');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_border');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ul_list_style');

		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_background');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_padding');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_margin');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_border');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_ol_list_style');

		// === TABLEAUX ===
		register_setting('ultimate_shanks_style', 'ultimate_shanks_tables_scope');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_background');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_padding');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_border');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_th_font_weight');

		register_setting('ultimate_shanks_style', 'ultimate_shanks_td_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_td_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_td_background');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_td_padding');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_td_border');

		// === LIENS ===
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_scope');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_hover_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_decoration');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_font_weight');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_links_transition');

		// === CITATIONS ===
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_scope');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_enabled');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_background');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_padding');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_border_width');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_border_color');
		register_setting('ultimate_shanks_style', 'ultimate_shanks_blockquote_italic');
	}

	/**
	 * Affiche l'onglet Style
	 */
	public static function render_tab()
	{
		// Sauvegarder si formulaire soumis
		if (isset($_POST['ultimate_shanks_style_submit'])) {
			check_admin_referer('ultimate_shanks_style_action', 'ultimate_shanks_style_nonce');
			self::save_settings();

			// Horodater la sauvegarde : permet au front de détecter un fichier CSS
			// périmé si la régénération ci-dessous échoue (permissions).
			update_option('ultimate_shanks_style_updated_at', time());

			// Régénérer le CSS
			$css_generated = CSSGenerator::generate_css();

			if ($css_generated) {
				echo '<div class="notice notice-success"><p>Paramètres sauvegardés et CSS régénéré !</p></div>';
			} else {
				echo '<div class="notice notice-error"><p>Paramètres sauvegardés. Le fichier CSS n\'a pas pu être écrit dans <code>uploads/ultimate-shanks</code> : les styles seront injectés en inline sur le front (vérifiez les permissions du dossier <code>uploads</code>).</p></div>';
			}
		}

		// Récupérer les valeurs
		$headings_scope = get_option('ultimate_shanks_headings_scope', 'global');
		$lists_scope = get_option('ultimate_shanks_lists_scope', 'global');
		$tables_scope = get_option('ultimate_shanks_tables_scope', 'global');
		$links_scope = get_option('ultimate_shanks_links_scope', 'global');
		$blockquote_scope = get_option('ultimate_shanks_blockquote_scope', 'global');
		?>

		<!-- CSS chargé via /assets/css/admin-settings.css (enqueued dans style-manager.php) -->
		<!-- JavaScript chargé via /assets/js/style-manager-admin.js (enqueued dans style-manager.php) -->

		<!-- Contenu supprimé pour clarté du code - Voir fichiers externes ci-dessus -->

		<div class="ultimate-shanks-settings-box">
			<h2>Stylisation Automatique des Éléments HTML</h2>
			<p class="description">
				Configurez les styles CSS pour les éléments HTML du contenu. Les styles sont appliqués automatiquement via un fichier CSS généré.
			</p>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_style_action', 'ultimate_shanks_style_nonce'); ?>

				<!-- TITRES H1-H6 -->
				<?php self::render_headings_section($headings_scope); ?>

				<!-- LISTES UL/OL -->
				<?php self::render_lists_section($lists_scope); ?>

				<!-- TABLEAUX -->
				<?php self::render_tables_section($tables_scope); ?>

				<!-- LIENS -->
				<?php self::render_links_section($links_scope); ?>

				<!-- CITATIONS -->
				<?php self::render_blockquotes_section($blockquote_scope); ?>

				<?php submit_button('Enregistrer et Générer le CSS', 'primary', 'ultimate_shanks_style_submit'); ?>
			</form>
		</div>

		<?php
	}

	/**
	 * Section Titres H1-H6
	 */
	private static function render_headings_section($scope)
	{
		?>
		<div class="te-section">
			<h3>🎨 Styles des Titres (H1 → H6)</h3>

			<table class="form-table">
				<tr>
					<th>Application</th>
					<td>
						<select name="headings_scope">
							<option value="global" <?php selected($scope, 'global'); ?>>Global (partout)</option>
							<option value="posts" <?php selected($scope, 'posts'); ?>>Articles uniquement</option>
							<option value="pages" <?php selected($scope, 'pages'); ?>>Pages uniquement</option>
						</select>
					</td>
				</tr>
			</table>

			<?php for ($i = 1; $i <= 6; $i++):
				$enabled = get_option("ultimate_shanks_h{$i}_enabled", '0') === '1';
				$color = get_option("ultimate_shanks_h{$i}_color", '');
				$bg = get_option("ultimate_shanks_h{$i}_background", '');
				$bg_enabled = get_option("ultimate_shanks_h{$i}_background_enabled", '0') === '1';
				$bg_opacity = get_option("ultimate_shanks_h{$i}_background_opacity", '1');
				$padding = get_option("ultimate_shanks_h{$i}_padding", '');
				$margin = get_option("ultimate_shanks_h{$i}_margin", '');
				$font_size = get_option("ultimate_shanks_h{$i}_font_size", '');
				$font_weight = get_option("ultimate_shanks_h{$i}_font_weight", '');
				$border = get_option("ultimate_shanks_h{$i}_border", '');
				$border_radius = get_option("ultimate_shanks_h{$i}_border_radius", '');
			?>
			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="h<?php echo $i; ?>_enabled" value="1" <?php checked($enabled); ?>>
					H<?php echo $i; ?> - Titre niveau <?php echo $i; ?>
				</summary>

				<table class="form-table" style="margin-top: 15px;">
				<tr>
					<th>Couleur du texte</th>
					<td class="color-picker-wrapper">
						<input type="color" name="h<?php echo $i; ?>_color" value="<?php echo esc_attr($color ?: '#000000'); ?>">
						<input type="text" value="<?php echo esc_attr($color ?: '#000000'); ?>" placeholder="#000000" maxlength="7">
					</td>
				</tr>
				<tr>
					<th>Activer la couleur de fond</th>
					<td>
						<label>
							<input type="checkbox" name="h<?php echo $i; ?>_background_enabled" value="1" class="hn-bg-checkbox" <?php checked($bg_enabled); ?>>
							Activer (permet d'utiliser la couleur de fond et l'opacité)
						</label>
					</td>
				</tr>
				<tr class="hn-bg-row" style="display: <?php echo $bg_enabled ? 'table-row' : 'none'; ?>;">
					<th>Couleur de fond</th>
					<td class="color-picker-wrapper">
						<input type="color" name="h<?php echo $i; ?>_background" value="<?php echo esc_attr($bg ?: '#ffffff'); ?>">
						<input type="text" value="<?php echo esc_attr($bg ?: '#ffffff'); ?>" placeholder="#ffffff" maxlength="7">
					</td>
				</tr>
				<tr class="hn-opacity-row" style="display: <?php echo $bg_enabled ? 'table-row' : 'none'; ?>;">
					<th>Opacité du fond</th>
					<td class="opacity-control">
						<input type="range" name="h<?php echo $i; ?>_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr($bg_opacity); ?>" class="opacity-slider">
						<span class="opacity-value"><?php echo esc_attr($bg_opacity); ?></span>
						<p class="description">0 = transparent, 1 = opaque</p>
					</td>
				</tr>
				<tr>
					<th>Padding</th>
					<td>
						<input type="text" name="h<?php echo $i; ?>_padding" value="<?php echo esc_attr($padding); ?>" placeholder="10px 20px" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>10px</code>, <code>10px 20px</code>, <code>10px 20px 10px 15px</code></p>
					</td>
				</tr>
				<tr>
					<th>Margin</th>
					<td>
						<input type="text" name="h<?php echo $i; ?>_margin" value="<?php echo esc_attr($margin); ?>" placeholder="20px 0" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>20px 0</code>, <code>10px 5px 15px 5px</code></p>
					</td>
				</tr>
				<tr>
					<th>Angles arrondis</th>
					<td>
						<input type="text" name="h<?php echo $i; ?>_border_radius" value="<?php echo esc_attr($border_radius); ?>" placeholder="5px" class="regular-text">
						<p class="description">Ex: <code>5px</code> (tous), <code>10px 5px</code> ou <code>10px 5px 0 5px</code> (haut-gauche, haut-droite, bas-droite, bas-gauche)</p>
					</td>
				</tr>
					<tr>
						<th>Taille de police</th>
						<td><input type="text" name="h<?php echo $i; ?>_font_size" value="<?php echo esc_attr($font_size); ?>" placeholder="24px" class="small-text"></td>
					</tr>
					<tr>
						<th>Poids de la police</th>
						<td>
							<select name="h<?php echo $i; ?>_font_weight">
								<option value="">Par défaut</option>
								<option value="300" <?php selected($font_weight, '300'); ?>>Light (300)</option>
								<option value="400" <?php selected($font_weight, '400'); ?>>Normal (400)</option>
								<option value="600" <?php selected($font_weight, '600'); ?>>Semi-Bold (600)</option>
								<option value="700" <?php selected($font_weight, '700'); ?>>Bold (700)</option>
								<option value="900" <?php selected($font_weight, '900'); ?>>Black (900)</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>Bordure</th>
						<td><input type="text" name="h<?php echo $i; ?>_border" value="<?php echo esc_attr($border); ?>" placeholder="1px solid #000" class="regular-text"></td>
					</tr>
				</table>
			</details>
			<?php endfor; ?>
		</div>
		<?php
	}

	/**
	 * Section Listes UL/OL
	 */
	private static function render_lists_section($scope)
	{
		$ul_enabled = get_option('ultimate_shanks_ul_enabled', '0') === '1';
		$ol_enabled = get_option('ultimate_shanks_ol_enabled', '0') === '1';
		?>
		<div class="te-section">
			<h3>📋 Styles des Listes</h3>

			<table class="form-table">
				<tr>
					<th>Application</th>
					<td>
						<select name="lists_scope">
							<option value="global" <?php selected($scope, 'global'); ?>>Global (partout)</option>
							<option value="posts" <?php selected($scope, 'posts'); ?>>Articles uniquement</option>
							<option value="pages" <?php selected($scope, 'pages'); ?>>Pages uniquement</option>
						</select>
					</td>
				</tr>
			</table>

			<!-- UL -->
			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="ul_enabled" value="1" <?php checked($ul_enabled); ?>>
					Listes à puces (UL)
				</summary>

				<table class="form-table" style="margin-top: 15px;">

				<tr>
					<th>Couleur du texte</th>
					<td class="color-picker-wrapper">
						<input type="color" name="ul_color" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_color', '') ?: '#000000'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_color', '') ?: '#000000'); ?>" placeholder="#000000" maxlength="7">
					</td>
				</tr>
				<tr>
					<th>Activer la couleur de fond</th>
					<td>
						<label>
							<input type="checkbox" name="ul_background_enabled" value="1" class="hn-bg-checkbox" <?php checked(get_option('ultimate_shanks_ul_background_enabled', '0'), '1'); ?>>
							Activer (permet d'utiliser la couleur de fond et l'opacité)
						</label>
					</td>
				</tr>
				<tr class="hn-bg-row" style="display: <?php echo get_option('ultimate_shanks_ul_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Couleur de fond</th>
					<td class="color-picker-wrapper">
						<input type="color" name="ul_background" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_background', '') ?: '#ffffff'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_background', '') ?: '#ffffff'); ?>" placeholder="#ffffff" maxlength="7">
					</td>
				</tr>
				<tr class="hn-opacity-row" style="display: <?php echo get_option('ultimate_shanks_ul_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Opacité du fond</th>
					<td class="opacity-control">
						<input type="range" name="ul_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_background_opacity', '1')); ?>" class="opacity-slider">
						<span class="opacity-value"><?php echo esc_attr(get_option('ultimate_shanks_ul_background_opacity', '1')); ?></span>
						<p class="description">0 = transparent, 1 = opaque</p>
					</td>
				</tr>
				<tr>
					<th>Padding</th>
					<td>
						<input type="text" name="ul_padding" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_padding', '')); ?>" placeholder="10px 20px" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>10px</code>, <code>10px 20px</code>, <code>10px 20px 10px 15px</code></p>
					</td>
				</tr>
				<tr>
					<th>Margin</th>
					<td>
						<input type="text" name="ul_margin" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_margin', '')); ?>" placeholder="20px 0" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>20px 0</code>, <code>10px 5px 15px 5px</code></p>
					</td>
				</tr>
				<tr>
					<th>Angles arrondis</th>
					<td>
						<input type="text" name="ul_border_radius" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_border_radius', '')); ?>" placeholder="5px" class="regular-text">
						<p class="description">Ex: <code>5px</code> (tous), <code>10px 5px</code> ou <code>10px 5px 0 5px</code> (haut-gauche, haut-droite, bas-droite, bas-gauche)</p>
					</td>
				</tr>
				<tr>
					<th>Style des puces</th>
					<td>
						<select name="ul_list_style">
							<?php $ul_style = get_option('ultimate_shanks_ul_list_style', ''); ?>
							<option value="">Par défaut</option>
							<option value="disc" <?php selected($ul_style, 'disc'); ?>>Disque (●)</option>
							<option value="circle" <?php selected($ul_style, 'circle'); ?>>Cercle (○)</option>
							<option value="square" <?php selected($ul_style, 'square'); ?>>Carré (■)</option>
							<option value="none" <?php selected($ul_style, 'none'); ?>>Aucune puce</option>
						</select>
					</td>
				</tr>
				<tr>
					<th>Bordure</th>
					<td><input type="text" name="ul_border" value="<?php echo esc_attr(get_option('ultimate_shanks_ul_border', '')); ?>" placeholder="1px solid #ddd" class="regular-text"></td>
				</tr>
			</table>
		</details>

		<!-- OL -->
		<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
			<summary style="cursor: pointer; font-weight: bold;">
				<input type="checkbox" name="ol_enabled" value="1" <?php checked($ol_enabled); ?>>
				Listes numérotées (OL)
			</summary>

			<table class="form-table" style="margin-top: 15px;">
				<tr>
					<th>Couleur du texte</th>
					<td class="color-picker-wrapper">
						<input type="color" name="ol_color" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_color', '') ?: '#000000'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_color', '') ?: '#000000'); ?>" placeholder="#000000" maxlength="7">
					</td>
				</tr>
				<tr>
					<th>Activer la couleur de fond</th>
					<td>
						<label>
							<input type="checkbox" name="ol_background_enabled" value="1" class="hn-bg-checkbox" <?php checked(get_option('ultimate_shanks_ol_background_enabled', '0'), '1'); ?>>
							Activer (permet d'utiliser la couleur de fond et l'opacité)
						</label>
					</td>
				</tr>
				<tr class="hn-bg-row" style="display: <?php echo get_option('ultimate_shanks_ol_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Couleur de fond</th>
					<td class="color-picker-wrapper">
						<input type="color" name="ol_background" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_background', '') ?: '#ffffff'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_background', '') ?: '#ffffff'); ?>" placeholder="#ffffff" maxlength="7">
					</td>
				</tr>
				<tr class="hn-opacity-row" style="display: <?php echo get_option('ultimate_shanks_ol_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Opacité du fond</th>
					<td class="opacity-control">
						<input type="range" name="ol_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_background_opacity', '1')); ?>" class="opacity-slider">
						<span class="opacity-value"><?php echo esc_attr(get_option('ultimate_shanks_ol_background_opacity', '1')); ?></span>
						<p class="description">0 = transparent, 1 = opaque</p>
					</td>
				</tr>
				<tr>
					<th>Padding</th>
					<td>
						<input type="text" name="ol_padding" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_padding', '')); ?>" placeholder="10px 20px" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>10px</code>, <code>10px 20px</code>, <code>10px 20px 10px 15px</code></p>
					</td>
				</tr>
				<tr>
					<th>Margin</th>
					<td>
						<input type="text" name="ol_margin" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_margin', '')); ?>" placeholder="20px 0" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>20px 0</code>, <code>10px 5px 15px 5px</code></p>
					</td>
				</tr>
				<tr>
					<th>Angles arrondis</th>
					<td>
						<input type="text" name="ol_border_radius" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_border_radius', '')); ?>" placeholder="5px" class="regular-text">
						<p class="description">Ex: <code>5px</code> (tous), <code>10px 5px</code> ou <code>10px 5px 0 5px</code> (haut-gauche, haut-droite, bas-droite, bas-gauche)</p>
					</td>
				</tr>
				<tr>
					<th>Style des numéros</th>
					<td>
						<select name="ol_list_style">
							<?php $ol_style = get_option('ultimate_shanks_ol_list_style', ''); ?>
							<option value="">Par défaut</option>
							<option value="decimal" <?php selected($ol_style, 'decimal'); ?>>Décimal (1, 2, 3)</option>
							<option value="lower-roman" <?php selected($ol_style, 'lower-roman'); ?>>Romain minuscule (i, ii, iii)</option>
							<option value="upper-roman" <?php selected($ol_style, 'upper-roman'); ?>>Romain majuscule (I, II, III)</option>
							<option value="lower-alpha" <?php selected($ol_style, 'lower-alpha'); ?>>Alpha minuscule (a, b, c)</option>
							<option value="upper-alpha" <?php selected($ol_style, 'upper-alpha'); ?>>Alpha majuscule (A, B, C)</option>
						</select>
					</td>
				</tr>
				<tr>
					<th>Bordure</th>
					<td><input type="text" name="ol_border" value="<?php echo esc_attr(get_option('ultimate_shanks_ol_border', '')); ?>" placeholder="1px solid #ddd" class="regular-text"></td>
				</tr>
			</table>
		</details>
	</div>
	<?php
}

	/**
	 * Section Tableaux
	 */
	private static function render_tables_section($scope)
	{
		$th_enabled = get_option('ultimate_shanks_th_enabled', '0') === '1';
		$td_enabled = get_option('ultimate_shanks_td_enabled', '0') === '1';
		?>
		<div class="te-section">
			<h3>📊 Styles des Tableaux</h3>

			<table class="form-table">
				<tr>
					<th>Application</th>
					<td>
						<select name="tables_scope">
							<option value="global" <?php selected($scope, 'global'); ?>>Global (partout)</option>
							<option value="posts" <?php selected($scope, 'posts'); ?>>Articles uniquement</option>
							<option value="pages" <?php selected($scope, 'pages'); ?>>Pages uniquement</option>
						</select>
					</td>
				</tr>
			</table>

			<!-- TH -->
			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="th_enabled" value="1" <?php checked($th_enabled); ?>>
					En-têtes de tableau (TH)
				</summary>

				<table class="form-table" style="margin-top: 15px;">
									<tr>
					<th>Couleur du texte</th>
					<td class="color-picker-wrapper">
						<input type="color" name="th_color" value="<?php echo esc_attr(get_option('ultimate_shanks_th_color', '') ?: '#000000'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_th_color', '') ?: '#000000'); ?>" placeholder="#000000" maxlength="7">
					</td>
				</tr>
				<tr>
					<th>Activer la couleur de fond</th>
					<td>
						<label>
							<input type="checkbox" name="th_background_enabled" value="1" class="hn-bg-checkbox" <?php checked(get_option('ultimate_shanks_th_background_enabled', '0'), '1'); ?>>
							Activer (permet d'utiliser la couleur de fond et l'opacité)
						</label>
					</td>
				</tr>
				<tr class="hn-bg-row" style="display: <?php echo get_option('ultimate_shanks_th_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Couleur de fond</th>
					<td class="color-picker-wrapper">
						<input type="color" name="th_background" value="<?php echo esc_attr(get_option('ultimate_shanks_th_background', '') ?: '#f5f5f5'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_th_background', '') ?: '#f5f5f5'); ?>" placeholder="#f5f5f5" maxlength="7">
					</td>
				</tr>
				<tr class="hn-opacity-row" style="display: <?php echo get_option('ultimate_shanks_th_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Opacité du fond</th>
					<td class="opacity-control">
						<input type="range" name="th_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr(get_option('ultimate_shanks_th_background_opacity', '1')); ?>" class="opacity-slider">
						<span class="opacity-value"><?php echo esc_attr(get_option('ultimate_shanks_th_background_opacity', '1')); ?></span>
						<p class="description">0 = transparent, 1 = opaque</p>
					</td>
				</tr>
				<tr>
					<th>Padding</th>
					<td>
						<input type="text" name="th_padding" value="<?php echo esc_attr(get_option('ultimate_shanks_th_padding', '')); ?>" placeholder="10px 15px" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>10px</code>, <code>10px 15px</code>, <code>10px 15px 10px 15px</code></p>
					</td>
				</tr>
				<tr>
					<th>Bordure</th>
					<td><input type="text" name="th_border" value="<?php echo esc_attr(get_option('ultimate_shanks_th_border', '')); ?>" placeholder="1px solid #ddd" class="regular-text"></td>
				</tr>
					<tr>
						<th>Poids de la police</th>
						<td>
							<select name="th_font_weight">
								<?php $th_fw = get_option('ultimate_shanks_th_font_weight', ''); ?>
								<option value="">Par défaut</option>
								<option value="400" <?php selected($th_fw, '400'); ?>>Normal (400)</option>
								<option value="600" <?php selected($th_fw, '600'); ?>>Semi-Bold (600)</option>
								<option value="700" <?php selected($th_fw, '700'); ?>>Bold (700)</option>
								<option value="900" <?php selected($th_fw, '900'); ?>>Black (900)</option>
							</select>
						</td>
					</tr>
				</table>
			</details>

			<!-- TD -->
			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="td_enabled" value="1" <?php checked($td_enabled); ?>>
					Cellules de tableau (TD)
				</summary>

				<table class="form-table" style="margin-top: 15px;">
									<tr>
					<th>Couleur du texte</th>
					<td class="color-picker-wrapper">
						<input type="color" name="td_color" value="<?php echo esc_attr(get_option('ultimate_shanks_td_color', '') ?: '#000000'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_td_color', '') ?: '#000000'); ?>" placeholder="#000000" maxlength="7">
					</td>
				</tr>
				<tr>
					<th>Activer la couleur de fond</th>
					<td>
						<label>
							<input type="checkbox" name="td_background_enabled" value="1" class="hn-bg-checkbox" <?php checked(get_option('ultimate_shanks_td_background_enabled', '0'), '1'); ?>>
							Activer (permet d'utiliser la couleur de fond et l'opacité)
						</label>
					</td>
				</tr>
				<tr class="hn-bg-row" style="display: <?php echo get_option('ultimate_shanks_td_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Couleur de fond</th>
					<td class="color-picker-wrapper">
						<input type="color" name="td_background" value="<?php echo esc_attr(get_option('ultimate_shanks_td_background', '') ?: '#ffffff'); ?>">
						<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_td_background', '') ?: '#ffffff'); ?>" placeholder="#ffffff" maxlength="7">
					</td>
				</tr>
				<tr class="hn-opacity-row" style="display: <?php echo get_option('ultimate_shanks_td_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
					<th>Opacité du fond</th>
					<td class="opacity-control">
						<input type="range" name="td_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr(get_option('ultimate_shanks_td_background_opacity', '1')); ?>" class="opacity-slider">
						<span class="opacity-value"><?php echo esc_attr(get_option('ultimate_shanks_td_background_opacity', '1')); ?></span>
						<p class="description">0 = transparent, 1 = opaque</p>
					</td>
				</tr>
				<tr>
					<th>Padding</th>
					<td>
						<input type="text" name="td_padding" value="<?php echo esc_attr(get_option('ultimate_shanks_td_padding', '')); ?>" placeholder="8px 12px" class="regular-text">
						<p class="description">Format: haut droite bas gauche. Ex: <code>8px 12px</code>, <code>10px 15px 10px 15px</code></p>
					</td>
				</tr>
				<tr>
					<th>Bordure</th>
					<td><input type="text" name="td_border" value="<?php echo esc_attr(get_option('ultimate_shanks_td_border', '')); ?>" placeholder="1px solid #ddd" class="regular-text"></td>
				</tr>
				</table>
			</details>
		</div>
		<?php
	}

	/**
	 * Section Liens
	 */
		private static function render_links_section($scope)
	{
		$enabled = get_option('ultimate_shanks_links_enabled', '0') === '1';
		?>
		<div class="te-section">
			<h3>🔗 Styles des Liens</h3>

			<table class="form-table">
				<tr>
					<th>Application</th>
					<td>
						<select name="links_scope">
							<option value="global" <?php selected($scope, 'global'); ?>>Global (contenu uniquement)</option>
							<option value="posts" <?php selected($scope, 'posts'); ?>>Articles uniquement</option>
							<option value="pages" <?php selected($scope, 'pages'); ?>>Pages uniquement</option>
						</select>
					</td>
				</tr>
			</table>

			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="links_enabled" value="1" <?php checked($enabled); ?>>
					Liens (A)
				</summary>

				<table class="form-table" style="margin-top: 15px;">
					<tr>
						<th>Couleur par défaut</th>
						<td class="color-picker-wrapper">
							<input type="color" name="links_color" value="<?php echo esc_attr(get_option('ultimate_shanks_links_color', '') ?: '#0073aa'); ?>">
							<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_links_color', '') ?: '#0073aa'); ?>" placeholder="#0073aa" maxlength="7">
						</td>
					</tr>
					<tr>
						<th>Couleur au survol</th>
						<td class="color-picker-wrapper">
							<input type="color" name="links_hover_color" value="<?php echo esc_attr(get_option('ultimate_shanks_links_hover_color', '') ?: '#005177'); ?>">
							<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_links_hover_color', '') ?: '#005177'); ?>" placeholder="#005177" maxlength="7">
						</td>
					</tr>
					<tr>
						<th>Décoration</th>
						<td>
							<select name="links_decoration">
								<?php $decoration = get_option('ultimate_shanks_links_decoration', 'none'); ?>
								<option value="">Par défaut</option>
								<option value="none" <?php selected($decoration, 'none'); ?>>Aucune</option>
								<option value="underline" <?php selected($decoration, 'underline'); ?>>Souligné</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>Poids de la police</th>
						<td>
							<select name="links_font_weight">
								<?php $fw = get_option('ultimate_shanks_links_font_weight', ''); ?>
								<option value="">Par défaut</option>
								<option value="400" <?php selected($fw, '400'); ?>>Normal (400)</option>
								<option value="600" <?php selected($fw, '600'); ?>>Semi-Bold (600)</option>
								<option value="700" <?php selected($fw, '700'); ?>>Bold (700)</option>
							</select>
						</td>
					</tr>
					<tr>
						<th>Durée de transition (hover)</th>
						<td>
							<input type="number" name="links_transition" value="<?php echo esc_attr(get_option('ultimate_shanks_links_transition', '')); ?>" step="0.1" min="0" max="2" class="small-text"> secondes
						</td>
					</tr>
				</table>
			</details>
		</div>
		<?php
	}

	/**
	 * Section Citations
	 */
		private static function render_blockquotes_section($scope)
	{
		$enabled = get_option('ultimate_shanks_blockquote_enabled', '0') === '1';
		?>
		<div class="te-section">
			<h3>💬 Styles des Citations (Blockquote)</h3>

			<table class="form-table">
				<tr>
					<th>Application</th>
					<td>
						<select name="blockquote_scope">
							<option value="global" <?php selected($scope, 'global'); ?>>Global (partout)</option>
							<option value="posts" <?php selected($scope, 'posts'); ?>>Articles uniquement</option>
							<option value="pages" <?php selected($scope, 'pages'); ?>>Pages uniquement</option>
						</select>
					</td>
				</tr>
			</table>

			<details style="margin: 15px 0; border: 1px solid #ccc; padding: 10px;">
				<summary style="cursor: pointer; font-weight: bold;">
					<input type="checkbox" name="blockquote_enabled" value="1" <?php checked($enabled); ?>>
					Citations (Blockquote)
				</summary>

				<table class="form-table" style="margin-top: 15px;">
					<tr>
						<th>Couleur du texte</th>
						<td class="color-picker-wrapper">
							<input type="color" name="blockquote_color" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_color', '') ?: '#555555'); ?>">
							<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_color', '') ?: '#555555'); ?>" placeholder="#555555" maxlength="7">
						</td>
					</tr>
					<tr>
						<th>Activer la couleur de fond</th>
						<td>
							<label>
								<input type="checkbox" name="blockquote_background_enabled" value="1" class="hn-bg-checkbox" <?php checked(get_option('ultimate_shanks_blockquote_background_enabled', '0'), '1'); ?>>
								Activer (permet d'utiliser la couleur de fond et l'opacité)
							</label>
						</td>
					</tr>
					<tr class="hn-bg-row" style="display: <?php echo get_option('ultimate_shanks_blockquote_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
						<th>Couleur de fond</th>
						<td class="color-picker-wrapper">
							<input type="color" name="blockquote_background" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_background', '') ?: '#f9f9f9'); ?>">
							<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_background', '') ?: '#f9f9f9'); ?>" placeholder="#f9f9f9" maxlength="7">
						</td>
					</tr>
					<tr class="hn-opacity-row" style="display: <?php echo get_option('ultimate_shanks_blockquote_background_enabled', '0') === '1' ? 'table-row' : 'none'; ?>;">
						<th>Opacité du fond</th>
						<td class="opacity-control">
							<input type="range" name="blockquote_background_opacity" min="0" max="1" step="0.01" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_background_opacity', '1')); ?>" class="opacity-slider">
							<span class="opacity-value"><?php echo esc_attr(get_option('ultimate_shanks_blockquote_background_opacity', '1')); ?></span>
							<p class="description">0 = transparent, 1 = opaque</p>
						</td>
					</tr>
					<tr>
						<th>Padding</th>
						<td>
							<input type="text" name="blockquote_padding" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_padding', '')); ?>" placeholder="20px 30px" class="regular-text">
							<p class="description">Format: haut droite bas gauche. Ex: <code>20px 30px</code>, <code>15px 20px 15px 20px</code></p>
						</td>
					</tr>
					<tr>
						<th>Bordure gauche - Largeur</th>
						<td><input type="text" name="blockquote_border_width" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_border_width', '4px')); ?>" placeholder="4px" class="small-text"></td>
					</tr>
					<tr>
						<th>Bordure gauche - Couleur</th>
						<td class="color-picker-wrapper">
							<input type="color" name="blockquote_border_color" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_border_color', '') ?: '#cccccc'); ?>">
							<input type="text" value="<?php echo esc_attr(get_option('ultimate_shanks_blockquote_border_color', '') ?: '#cccccc'); ?>" placeholder="#cccccc" maxlength="7">
						</td>
					</tr>
				</table>
			</details>
		</div>
		<?php
	}

	/**
	 * Sauvegarde tous les paramètres
	 */
	private static function save_settings()
	{
		// TITRES
		update_option('ultimate_shanks_headings_scope', sanitize_text_field($_POST['headings_scope']));
		for ($i = 1; $i <= 6; $i++) {
			update_option("ultimate_shanks_h{$i}_enabled", isset($_POST["h{$i}_enabled"]) ? '1' : '0');
			update_option("ultimate_shanks_h{$i}_color", sanitize_hex_color($_POST["h{$i}_color"] ?? ''));
			update_option("ultimate_shanks_h{$i}_background", sanitize_hex_color($_POST["h{$i}_background"] ?? ''));
			update_option("ultimate_shanks_h{$i}_padding", sanitize_text_field($_POST["h{$i}_padding"] ?? ''));
			update_option("ultimate_shanks_h{$i}_margin", sanitize_text_field($_POST["h{$i}_margin"] ?? ''));
			update_option("ultimate_shanks_h{$i}_font_size", sanitize_text_field($_POST["h{$i}_font_size"] ?? ''));
			update_option("ultimate_shanks_h{$i}_font_weight", sanitize_text_field($_POST["h{$i}_font_weight"] ?? ''));
			update_option("ultimate_shanks_h{$i}_border", sanitize_text_field($_POST["h{$i}_border"] ?? ''));

			// Nouveaux champs pour tous les titres (background_enabled, opacity, border_radius)
			update_option("ultimate_shanks_h{$i}_background_enabled", isset($_POST["h{$i}_background_enabled"]) ? '1' : '0');
			update_option("ultimate_shanks_h{$i}_background_opacity", sanitize_text_field($_POST["h{$i}_background_opacity"] ?? '1'));
			update_option("ultimate_shanks_h{$i}_border_radius", sanitize_text_field($_POST["h{$i}_border_radius"] ?? ''));
		}

		// LISTES
		update_option('ultimate_shanks_lists_scope', sanitize_text_field($_POST['lists_scope']));
		update_option('ultimate_shanks_ul_enabled', isset($_POST['ul_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_ul_color', sanitize_hex_color($_POST['ul_color'] ?? ''));
		update_option('ultimate_shanks_ul_background', sanitize_hex_color($_POST['ul_background'] ?? ''));
		update_option('ultimate_shanks_ul_padding', sanitize_text_field($_POST['ul_padding'] ?? ''));
		update_option('ultimate_shanks_ul_margin', sanitize_text_field($_POST['ul_margin'] ?? ''));
		update_option('ultimate_shanks_ul_border', sanitize_text_field($_POST['ul_border'] ?? ''));
		update_option('ultimate_shanks_ul_list_style', sanitize_text_field($_POST['ul_list_style'] ?? ''));
		// Nouveaux champs pour UL (background_enabled, opacity, border_radius)
		update_option('ultimate_shanks_ul_background_enabled', isset($_POST['ul_background_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_ul_background_opacity', sanitize_text_field($_POST['ul_background_opacity'] ?? '1'));
		update_option('ultimate_shanks_ul_border_radius', sanitize_text_field($_POST['ul_border_radius'] ?? ''));


		update_option('ultimate_shanks_ol_enabled', isset($_POST['ol_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_ol_color', sanitize_hex_color($_POST['ol_color'] ?? ''));
		update_option('ultimate_shanks_ol_background', sanitize_hex_color($_POST['ol_background'] ?? ''));
		update_option('ultimate_shanks_ol_padding', sanitize_text_field($_POST['ol_padding'] ?? ''));
		update_option('ultimate_shanks_ol_margin', sanitize_text_field($_POST['ol_margin'] ?? ''));
		update_option('ultimate_shanks_ol_border', sanitize_text_field($_POST['ol_border'] ?? ''));
		update_option('ultimate_shanks_ol_list_style', sanitize_text_field($_POST['ol_list_style'] ?? ''));

		// Nouveaux champs pour OL (background_enabled, opacity, border_radius)
		update_option('ultimate_shanks_ol_background_enabled', isset($_POST['ol_background_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_ol_background_opacity', sanitize_text_field($_POST['ol_background_opacity'] ?? '1'));
		update_option('ultimate_shanks_ol_border_radius', sanitize_text_field($_POST['ol_border_radius'] ?? ''));

		// TABLEAUX
		update_option('ultimate_shanks_tables_scope', sanitize_text_field($_POST['tables_scope']));
		update_option('ultimate_shanks_th_enabled', isset($_POST['th_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_th_color', sanitize_hex_color($_POST['th_color'] ?? ''));
		update_option('ultimate_shanks_th_background', sanitize_hex_color($_POST['th_background'] ?? ''));
		update_option('ultimate_shanks_th_padding', sanitize_text_field($_POST['th_padding'] ?? ''));
		update_option('ultimate_shanks_th_border', sanitize_text_field($_POST['th_border'] ?? ''));
		update_option('ultimate_shanks_th_font_weight', sanitize_text_field($_POST['th_font_weight'] ?? ''));
		// Nouveaux champs pour TH (background_enabled, opacity, border_radius)
		update_option('ultimate_shanks_th_background_enabled', isset($_POST['th_background_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_th_background_opacity', sanitize_text_field($_POST['th_background_opacity'] ?? '1'));


		update_option('ultimate_shanks_td_enabled', isset($_POST['td_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_td_color', sanitize_hex_color($_POST['td_color'] ?? ''));
		update_option('ultimate_shanks_td_background', sanitize_hex_color($_POST['td_background'] ?? ''));
		update_option('ultimate_shanks_td_padding', sanitize_text_field($_POST['td_padding'] ?? ''));
		update_option('ultimate_shanks_td_border', sanitize_text_field($_POST['td_border'] ?? ''));

		// LIENS
		update_option('ultimate_shanks_links_scope', sanitize_text_field($_POST['links_scope']));
		update_option('ultimate_shanks_links_enabled', isset($_POST['links_enabled']) ? '1' : '0');
		// Nouveaux champs pour TD (background_enabled, opacity, border_radius)
		update_option('ultimate_shanks_td_background_enabled', isset($_POST['td_background_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_td_background_opacity', sanitize_text_field($_POST['td_background_opacity'] ?? '1'));

		update_option('ultimate_shanks_links_color', sanitize_hex_color($_POST['links_color'] ?? ''));
		update_option('ultimate_shanks_links_hover_color', sanitize_hex_color($_POST['links_hover_color'] ?? ''));
		update_option('ultimate_shanks_links_decoration', sanitize_text_field($_POST['links_decoration'] ?? ''));
		update_option('ultimate_shanks_links_font_weight', sanitize_text_field($_POST['links_font_weight'] ?? ''));
		update_option('ultimate_shanks_links_transition', sanitize_text_field($_POST['links_transition'] ?? ''));

		// CITATIONS
		update_option('ultimate_shanks_blockquote_scope', sanitize_text_field($_POST['blockquote_scope']));
		update_option('ultimate_shanks_blockquote_enabled', isset($_POST['blockquote_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_blockquote_color', sanitize_hex_color($_POST['blockquote_color'] ?? ''));
		update_option('ultimate_shanks_blockquote_background_enabled', isset($_POST['blockquote_background_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_blockquote_background', sanitize_hex_color($_POST['blockquote_background'] ?? ''));
		update_option('ultimate_shanks_blockquote_background_opacity', sanitize_text_field($_POST['blockquote_background_opacity'] ?? '1'));
		update_option('ultimate_shanks_blockquote_padding', sanitize_text_field($_POST['blockquote_padding'] ?? ''));
		update_option('ultimate_shanks_blockquote_border_width', sanitize_text_field($_POST['blockquote_border_width'] ?? ''));
		update_option('ultimate_shanks_blockquote_border_color', sanitize_hex_color($_POST['blockquote_border_color'] ?? ''));
	}
}
