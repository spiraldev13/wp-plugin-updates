<?php
if (!defined('ABSPATH')) {
    exit;
}

$footerTagline = get_field('footer_tagline', 'option');
$contactEmail  = get_field('contact_email', 'option');
$contactPhone  = get_field('contact_phone', 'option');
$contactCity   = get_field('contact_city', 'option');
$socials       = get_field('social_links', 'option');
$siteName      = get_bloginfo('name');

$logoUrl = evolutionr_logo_url();
$logoAlt = evolutionr_logo_alt();
$hasLogo = evolutionr_has_logo();
?>
    </main>

    <footer class="footer" role="contentinfo">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a class="logo-mark<?php echo $hasLogo ? ' logo-mark--image-only' : ''; ?>" href="<?php echo esc_url(home_url('/')); ?>">
                        <img src="<?php echo esc_url($logoUrl); ?>" alt="<?php echo esc_attr($logoAlt); ?>" width="32" height="32">
                        <?php if (!$hasLogo) : ?>
                            <span class="logo-text">EVOLUTION<span class="accent">'R</span></span>
                        <?php endif; ?>
                    </a>
                    <?php if ($footerTagline) : ?>
                        <p class="tagline"><?php echo esc_html($footerTagline); ?></p>
                    <?php endif; ?>
                </div>

                <?php if (has_nav_menu('footer_prestations')) : ?>
                    <div class="footer-col">
                        <h4><?php esc_html_e('Prestations', 'evolutionr'); ?></h4>
                        <?php
                        wp_nav_menu([
                            'theme_location' => 'footer_prestations',
                            'container'      => false,
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ]);
                        ?>
                    </div>
                <?php endif; ?>

                <?php if (has_nav_menu('footer_ressources')) : ?>
                    <div class="footer-col">
                        <h4><?php esc_html_e('Ressources', 'evolutionr'); ?></h4>
                        <?php
                        wp_nav_menu([
                            'theme_location' => 'footer_ressources',
                            'container'      => false,
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ]);
                        ?>
                    </div>
                <?php endif; ?>

                <div class="footer-col">
                    <h4><?php esc_html_e('Contact', 'evolutionr'); ?></h4>
                    <div class="footer-contact">
                        <?php if ($contactEmail) : ?>
                            <?php echo esc_html($contactEmail); ?>
                        <?php endif; ?>
                        <?php if ($contactPhone) : ?>
                            <a href="tel:<?php echo esc_attr(preg_replace('/\s+/', '', $contactPhone)); ?>"><?php echo esc_html($contactPhone); ?></a>
                        <?php endif; ?>
                        <?php if ($contactCity) : ?>
                            <span class="city"><?php echo esc_html($contactCity); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div>
                    <?php
                    /* translators: 1: année, 2: nom du site */
                    printf(esc_html__('© %1$s %2$s — Tous droits réservés', 'evolutionr'), esc_html(date('Y')), esc_html(strtoupper($siteName)));
                    ?>
                </div>

                <?php if (has_nav_menu('footer_legal')) : ?>
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'footer_legal',
                        'container'      => false,
                        'menu_class'     => 'footer-legal',
                        'depth'          => 1,
                        'fallback_cb'    => false,
                    ]);
                    ?>
                <?php endif; ?>

                <?php if (!empty($socials) && is_array($socials)) : ?>
                    <div class="footer-socials">
                        <?php foreach ($socials as $social) :
                            $network = $social['network'] ?? '';
                            $url     = $social['url'] ?? '';
                            if (!$network || !$url) {
                                continue;
                            }
                            $label = ucfirst($network);
                            ?>
                            <a href="<?php echo esc_url($url); ?>" aria-label="<?php echo esc_attr($label); ?>" rel="noopener noreferrer" target="_blank">
                                <?php evolutionr_social_icon($network); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </footer>
</div><!-- /.page -->

<button
    type="button"
    class="scroll-top"
    data-scroll-top
    aria-label="<?php esc_attr_e('Revenir en haut de la page', 'evolutionr'); ?>"
    aria-hidden="true"
    tabindex="-1"
    style="opacity:0"
>
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 19V5M5 12l7-7 7 7"/>
    </svg>
</button>

<?php wp_footer(); ?>
</body>
</html>
