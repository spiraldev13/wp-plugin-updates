<?php

declare(strict_types=1);

namespace SpiralBase\Modules\FormulaireContact;

use SpiralBase\Core\Signal;

/**
 * Les messages reçus (story 3.8) — un type de contenu qui ne sort JAMAIS du
 * site.
 *
 * L'AC 1 exige une copie en base pour que rien ne se perde si le courriel
 * n'arrive pas. Cette copie contient ce qu'un visiteur a écrit, parfois des
 * coordonnées : elle n'a donc ni URL publique, ni entrée de recherche, ni
 * exposition REST. Seul l'écran d'administration la montre.
 */
final class Messages
{
    public const TYPE = 'spiralbase_message';

    public const META_EMAIL = 'spiralbase_email';

    public const META_ECHEC = 'spiralbase_envoi_echoue';

    /** Bornes de stockage : au-delà, la donnée est tronquée plutôt que refusée. */
    private const LONGUEUR_NOM = 200;

    private const LONGUEUR_MESSAGE = 5000;

    public function declarer(): void
    {
        register_post_type(self::TYPE, [
            'labels' => [
                'name'          => __('Messages reçus', 'spiralbase'),
                'singular_name' => __('Message reçu', 'spiralbase'),
            ],
            /*
             * Tout est fermé par défaut, et chaque clé est posée
             * EXPLICITEMENT : les valeurs par défaut de `register_post_type`
             * dépendent les unes des autres (`public` en pilote plusieurs), et
             * une dépendance implicite est ce qui ouvre un jour une porte que
             * personne n'a voulu ouvrir.
             */
            'public'              => false,
            'publicly_queryable'  => false,
            'exclude_from_search' => true,
            'has_archive'         => false,
            'rewrite'             => false,
            'show_in_rest'        => false,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'menu_icon'           => 'dashicons-email-alt',
            /* `can_export` et `delete_with_user` étaient laissés au défaut du
               cœur, donc `true` et `null` : le type figurait dans Outils →
               Exporter, qui produisait un XML de tous les messages privés de
               visiteurs — pour un type dont le docbloc annonce qu'il ne sort
               jamais du site. */
            'can_export'          => false,
            'delete_with_user'    => false,
            'capability_type'     => 'post',
            'capabilities'        => ['create_posts' => 'do_not_allow'],
            'map_meta_cap'        => true,
            'supports'            => ['title', 'editor'],
        ]);

        /*
         * AD-11 : toute post-meta passe par `register_post_meta`. Fermées des
         * deux côtés — jamais dans la REST, écriture réservée à qui peut
         * gérer les contenus : ce sont des coordonnées de visiteurs.
         */
        foreach ([self::META_EMAIL, self::META_ECHEC] as $meta) {
            register_post_meta(self::TYPE, $meta, [
                'single'        => true,
                'type'          => 'string',
                'default'       => '',
                'show_in_rest'  => false,
                'auth_callback' => static fn (): bool => current_user_can('edit_others_posts'),
            ]);
        }
    }

    /**
     * Colonnes de la liste d'administration.
     *
     * Sans elles, la copie en base tenait sa promesse à moitié : le corps du
     * message survivait à un envoi manqué, mais l'ADRESSE pour y répondre
     * n'était affichée nulle part, et rien ne signalait à l'humain que le
     * courriel n'était pas parti. La copie ne sert à rien si l'opérateur ne
     * peut pas s'en servir.
     */
    public function brancherEcranAdmin(): void
    {
        add_filter('manage_' . self::TYPE . '_posts_columns', static function ($colonnes): array {
            $colonnes = is_array($colonnes) ? $colonnes : [];
            $date     = $colonnes['date'] ?? null;
            unset($colonnes['date']);

            $colonnes['spiralbase_expediteur'] = __('Expéditeur', 'spiralbase');
            $colonnes['spiralbase_envoi']      = __('Envoi', 'spiralbase');

            if ($date !== null) {
                $colonnes['date'] = $date;
            }

            return $colonnes;
        });

        add_action('manage_' . self::TYPE . '_posts_custom_column', static function ($colonne, $postId): void {
            if ($colonne === 'spiralbase_expediteur') {
                $email = sanitize_email((string) get_post_meta((int) $postId, self::META_EMAIL, true));

                echo $email === ''
                    ? '—'
                    : '<a href="' . esc_url('mailto:' . $email) . '">' . esc_html($email) . '</a>';

                return;
            }

            if ($colonne === 'spiralbase_envoi') {
                $echec = (string) get_post_meta((int) $postId, self::META_ECHEC, true);

                echo $echec === ''
                    ? esc_html__('Envoyé', 'spiralbase')
                    : '<strong>' . esc_html__('Échec', 'spiralbase') . '</strong> — ' . esc_html($echec);
            }
        }, 10, 2);
    }

    /**
     * Écrit la copie et rend son identifiant (0 en cas d'échec).
     *
     * @param array{nom: string, email: string, message: string} $donnees
     */
    public function enregistrer(array $donnees): int
    {
        $nom     = $this->borner(sanitize_text_field($donnees['nom'] ?? ''), self::LONGUEUR_NOM);
        $email   = sanitize_email($donnees['email'] ?? '');
        $message = $this->borner($this->nettoyer($donnees['message'] ?? ''), self::LONGUEUR_MESSAGE);

        /*
         * `wp_slash()` : `wp_insert_post()` applique `wp_unslash()` sur ce
         * qu'il reçoit (`post.php:4888`). Le contenu a DÉJÀ été déslashé à la
         * réception ; sans ce ré-échappement, un second passage mangeait les
         * antislashs — « C:\Users\Alice » devenait « C:UsersAlice » dans la
         * seule copie que le client conservera. Défaut prouvé, et déjà payé
         * une fois : la story 2.9 l'avait corrigé pour la duplication.
         */
        $id = wp_insert_post(wp_slash([
            'post_type'    => self::TYPE,
            'post_status'  => 'private',
            /* Le titre est ce que l'opérateur lit dans la liste : il doit
               nommer l'expéditeur, pas le contenu. */
            'post_title'   => $nom !== '' ? $nom : __('Message sans nom', 'spiralbase'),
            'post_content' => $message,
            'meta_input'   => [self::META_EMAIL => $email],
        ]));

        return is_int($id) && $id > 0 ? $id : 0;
    }

    /** Consigne l'échec d'envoi SUR la copie : elle est la seule trace qui reste. */
    public function marquerEchecEnvoi(int $id, string $raison): void
    {
        if ($id > 0) {
            update_post_meta($id, self::META_ECHEC, $this->borner($raison, 200));
        }
    }

    /**
     * Aperçu d'un message pour l'écran d'administration.
     *
     * Le contenu vient d'un TIERS — un visiteur quelconque : c'est du texte
     * brut échappé, jamais du texte riche (règle établie en 3.3, après qu'un
     * auteur d'avis Google a pu poser du gras sur la page d'un client).
     *
     * @param array{nom: string, email: string, message: string} $donnees
     */
    public function rendreExtrait(array $donnees): string
    {
        return '<p class="spiralbase-message__expediteur">'
            . esc_html($this->borner(sanitize_text_field($donnees['nom'] ?? ''), self::LONGUEUR_NOM))
            . ' &lt;' . esc_html(sanitize_email($donnees['email'] ?? '')) . '&gt;</p>'
            . '<p class="spiralbase-message__corps">'
            . nl2br(esc_html($this->borner($this->nettoyer((string) ($donnees['message'] ?? '')), self::LONGUEUR_MESSAGE)))
            . '</p>';
    }

    /**
     * Nettoie le message SANS le faire disparaître.
     *
     * `sanitize_textarea_field()` passe par `wp_check_invalid_utf8()` sans
     * l'option de nettoyage (`formatting.php:5640`, `:1144-1146`) : un seul
     * octet UTF-8 invalide rend une chaîne VIDE. Le message était alors perdu
     * en base ET dans le courriel, pendant que le visiteur lisait « bien
     * transmis » — l'inverse exact de ce que la copie en base est censée
     * garantir. On repasse donc par un nettoyage qui conserve le texte, et on
     * signale la perte plutôt que de la subir.
     */
    private function nettoyer(string $message): string
    {
        $valide = wp_check_invalid_utf8($message);

        if ($valide === '' && trim($message) !== '') {
            /* Un seul octet invalide vidait le message — en base ET dans le
               courriel — pendant que le visiteur lisait « bien transmis ». */
            $valide = (string) wp_check_invalid_utf8($message, true);

            Signal::emettre(
                'spiralbase_formulaire_message_altere',
                $valide === ''
                    ? 'message illisible après nettoyage — copie conservée vide'
                    : 'message nettoyé de caractères invalides avant enregistrement',
                'formulaire'
            );
        }

        /*
         * PAS `sanitize_textarea_field()` sur le corps : le cœur y boucle sur
         * les séquences percent-encodées et les SUPPRIME (`formatting.php`),
         * si bien qu'un « https://exemple.test/ma%20page%2Fdevis.pdf » arrivait
         * amputé — un lien mort dans la seule copie du message. Cette règle a
         * un sens pour une valeur d'attribut, aucun pour une phrase. On retire
         * donc les balises et les caractères de contrôle, rien de plus : le
         * texte ne ressort qu'échappé, par `esc_html`.
         */
        $sansBalise = wp_strip_all_tags($valide);

        return trim((string) preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $sansBalise));
    }

    private function borner(string $texte, int $longueur): string
    {
        return mb_substr($texte, 0, $longueur);
    }
}
