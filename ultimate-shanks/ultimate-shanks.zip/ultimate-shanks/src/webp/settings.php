<?php

/**
 * WebP - Onglet de réglages et point d'entrée du panneau
 *
 * Réglages : tableau CRUD des presets (format grisé si non supporté par le
 * serveur), choix du preset par défaut, conversion automatique des images IA.
 * Le panneau de conversion/validation (src/webp/panel.php) est rendu dans le
 * même onglet — décision D9 du design.
 *
 * Assets associés :
 * - JS : /assets/js/webp-panel.js
 *
 * Fichiers liés :
 * - src/webp/presets.php, src/webp/panel.php
 * - src/admin/settings.php (nav + switch de l'onglet)
 *
 * @package UltimateShanks\Webp
 */

namespace UltimateShanks\Webp;

if (!defined('ABSPATH')) {
	exit;
}

class Settings
{
	public static function init()
	{
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
	}

	/**
	 * Charge le JS du panneau sur la page Ultimate Shanks uniquement
	 */
	public static function enqueue_scripts($hook)
	{
		if ($hook !== 'toplevel_page_ultimate-shanks') {
			return;
		}

		wp_enqueue_script(
			'ultimate-shanks-webp-panel',
			MP_URL . 'assets/js/webp-panel.js',
			['jquery'],
			'1.0.0',
			true
		);

		wp_localize_script('ultimate-shanks-webp-panel', 'ultimateShanksWebp', [
			'ajaxurl'    => admin_url('admin-ajax.php'),
			'nonce'      => wp_create_nonce(Panel::NONCE_ACTION),
			'batchSizes' => ['webp' => 5, 'avif' => 2],
			'strings'    => [
				'converting'    => 'Conversion en cours…',
				'converted'     => '%d conversion(s) terminée(s), %d échec(s). Rechargement…',
				'deleting'      => 'Suppression en cours…',
				'confirmDelete' => 'Supprimer définitivement les fichiers originaux de %d conversion(s) ? Cette action est irréversible.',
				'confirmRestore' => 'Restaurer ce média à son état d\'origine ? Le fichier converti sera supprimé.',
				'nothing'       => 'Aucun média sélectionné.',
				'error'         => 'Erreur inattendue. Réessayez.',
			],
		]);
	}

	/**
	 * Affiche l'onglet WebP (traitement du POST, réglages, panneau)
	 */
	public static function render_tab()
	{
		if (isset($_POST['ultimate_shanks_webp_submit'])) {
			check_admin_referer('ultimate_shanks_webp_action', 'ultimate_shanks_webp_nonce');
			self::save_settings();
			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}
		?>
		<div class="ultimate-shanks-settings-box">
			<h2>WebP - Conversion des images de la médiathèque</h2>

			<?php if (!Capabilities::is_operational()) : ?>
				<div class="notice notice-error inline"><p>
					Le PHP de cet hébergement ne sait pas encoder le WebP (bibliothèque GD sans
					support WebP) : le module est inopérant. Contactez l'hébergeur ou activez
					l'extension Imagick.
				</p></div>
				<?php return; ?>
			<?php endif; ?>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_webp_action', 'ultimate_shanks_webp_nonce'); ?>

				<table class="form-table ultimate-shanks-form-table">
					<tbody>
						<tr>
							<th scope="row"><label for="us_webp_auto_ai">Images IA</label></th>
							<td>
								<label>
									<input type="checkbox" id="us_webp_auto_ai" name="us_webp_auto_ai" value="1"
										<?php checked(get_option(Converter::AUTO_AI_OPTION, '0'), '1'); ?>>
									Convertir automatiquement les images générées par IA (preset par défaut)
								</label>
								<p class="description">
									La conversion a lieu avant l'import en médiathèque : l'image n'existe
									qu'au format cible, rien à valider. En cas d'échec d'encodage, l'image
									est importée dans son format d'origine.
								</p>
							</td>
						</tr>
					</tbody>
				</table>

				<?php self::render_presets_table(); ?>

				<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_webp_submit'); ?>
			</form>

			<hr>

			<?php Panel::render(); ?>

			<div class="ultimate-shanks-info-box">
				<h3>Fonctionnement</h3>
				<p>
					La conversion remplace le fichier du média (même identifiant, miniatures
					régénérées, URL réécrites dans les contenus) mais conserve l'original sur le
					disque jusqu'à votre validation dans la liste « Conversions à valider » —
					restauration possible d'un clic tant que rien n'est validé. Échelles de
					qualité : WebP 80 ≈ AVIF 60 visuellement.
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Tableau CRUD des presets, avec radio « défaut »
	 */
	private static function render_presets_table()
	{
		$presets = Presets::get_all();
		$default = Presets::get_default();
		$avif_ok = Capabilities::supports('avif');
		$index = 0;
		?>
		<h3>Presets de conversion</h3>
		<table class="widefat striped" id="us_webp_presets_table" style="max-width:760px;">
			<thead>
				<tr>
					<th style="width:60px;">Défaut</th>
					<th>Libellé</th>
					<th style="width:120px;">Format</th>
					<th style="width:110px;">Qualité (%)</th>
					<th style="width:100px;"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($presets as $preset) : ?>
					<?php self::render_preset_row($index, $preset, $default && $default['id'] === $preset['id'], $avif_ok); ?>
					<?php $index++; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<button type="button" class="button" id="us_webp_add_preset">+ Ajouter un preset</button>
			<?php if (!$avif_ok) : ?>
				<span class="description">AVIF indisponible : le PHP de cet hébergement ne sait pas l'encoder.</span>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * Une ligne éditable de preset
	 *
	 * @param int   $index
	 * @param array $preset
	 * @param bool  $is_default
	 * @param bool  $avif_ok
	 */
	private static function render_preset_row($index, $preset, $is_default, $avif_ok)
	{
		?>
		<tr class="us-webp-preset-row">
			<td style="text-align:center;">
				<input type="radio" name="us_webp_default" value="<?php echo esc_attr($preset['id']); ?>"
					<?php checked($is_default); ?>>
				<input type="hidden" name="us_webp_presets[<?php echo esc_attr($index); ?>][id]"
					value="<?php echo esc_attr($preset['id']); ?>">
			</td>
			<td>
				<input type="text" style="width:100%;" name="us_webp_presets[<?php echo esc_attr($index); ?>][label]"
					value="<?php echo esc_attr($preset['label']); ?>">
			</td>
			<td>
				<select name="us_webp_presets[<?php echo esc_attr($index); ?>][format]">
					<option value="webp" <?php selected($preset['format'], 'webp'); ?>>WebP</option>
					<option value="avif" <?php selected($preset['format'], 'avif'); ?> <?php disabled(!$avif_ok); ?>>AVIF</option>
				</select>
			</td>
			<td>
				<input type="number" min="1" max="100" style="width:80px;"
					name="us_webp_presets[<?php echo esc_attr($index); ?>][quality]"
					value="<?php echo esc_attr($preset['quality']); ?>">
			</td>
			<td><button type="button" class="button button-small us-webp-remove-preset">Supprimer</button></td>
		</tr>
		<?php
	}

	/**
	 * Sauvegarde le toggle auto-IA et la liste des presets
	 */
	private static function save_settings()
	{
		update_option(Converter::AUTO_AI_OPTION, isset($_POST['us_webp_auto_ai']) ? '1' : '0');

		$rows = (array) (isset($_POST['us_webp_presets']) ? wp_unslash($_POST['us_webp_presets']) : []);
		$default_id = isset($_POST['us_webp_default']) ? sanitize_key($_POST['us_webp_default']) : '';

		// Les presets AVIF restent enregistrés même sans support serveur : ils
		// sont grisés à l'usage (panneau) et refusés par le Converter — jamais
		// supprimés silencieusement (utilisables si l'hébergement évolue)
		Presets::save_all($rows, $default_id);
	}
}
