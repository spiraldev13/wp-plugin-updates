<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<section class="section error-404">
    <div class="container">
        <div class="error-404__code">404</div>
        <p class="error-404__lede"><?php esc_html_e("Cette page n'existe pas ou n'existe plus. Vérifiez l'adresse ou revenez à l'accueil.", 'evolutionr'); ?></p>
        <a class="btn btn-primary" href="<?php echo esc_url(home_url('/')); ?>">
            <?php esc_html_e("Retour à l'accueil", 'evolutionr'); ?>
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
        </a>
    </div>
</section>

<?php get_footer(); ?>
