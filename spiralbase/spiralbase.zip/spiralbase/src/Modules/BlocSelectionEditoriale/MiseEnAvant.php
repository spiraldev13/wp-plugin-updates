<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocSelectionEditoriale;

use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;

/**
 * Marquage « mis en avant » (story 3.7) — porte unique de la meta de rang.
 *
 * UNE seule meta, qui porte le RANG : deux metas (marquage d'un côté, ordre de
 * l'autre) pourraient diverger — un article marqué sans rang, ou l'inverse —
 * alors que l'AC 1 exige les deux à la fois. Un entier ≥ 1 répond aux deux
 * questions par construction ; absent ou ≤ 0, l'article n'est pas mis en avant.
 *
 * La meta est une entrée NON FIABLE : la REST, WP-CLI, un import ou une
 * migration peuvent y écrire n'importe quoi. Ce qu'on ne sait pas lire ne met
 * pas un article en tête de l'accueil.
 */
final class MiseEnAvant
{
    public const META = 'spiralbase_mise_en_avant';

    /** Verrou du calcul de rang — option DÉCLARÉE par le module (AD-11). */
    public const VERROU = 'spiralbase_selection_verrou';

    public function __construct(private readonly ?Options $options = null)
    {
    }

    /** Garde-fou : au-delà, la liste n'est plus une sélection éditoriale. */
    public const RANG_MAX = 500;

    /** Déclare la meta au cœur — sans quoi elle reste invisible à la REST. */
    public function declarer(): void
    {
        register_post_meta('post', self::META, [
            'single'            => true,
            'type'              => 'integer',
            'default'           => 0,
            'show_in_rest'      => true,
            'sanitize_callback' => static fn (mixed $valeur): int => self::normaliser($valeur),
            /*
             * SANS `auth_callback`, le cœur autorise l'écriture à quiconque
             * peut éditer l'article : un contributeur reclasserait alors la
             * page d'accueil du site. La mise en avant est une décision
             * ÉDITORIALE de portée site, pas une propriété de l'article.
             *
             * Signature COMPLÈTE : le cœur passe l'utilisateur concerné en
               4e argument (`capabilities.php:497`) précisément parce que la
               question peut porter sur quelqu'un d'autre que la session en
               cours. L'ignorer répondait pour l'utilisateur courant — et
               répondait en ACCORDANT.
             */
            'auth_callback'     => static fn (bool $permis, string $cle, int $objet, int $utilisateur): bool
                => $utilisateur > 0 && user_can($utilisateur, 'edit_others_posts'),
        ]);
    }

    public function rang(int $postId): int
    {
        return self::normaliser(get_post_meta($postId, self::META, true));
    }

    public function estMisEnAvant(int $postId): bool
    {
        return $this->rang($postId) > 0;
    }

    /**
     * Rang suivant : le plus grand ATTRIBUÉ, plus un — 0 si le plafond est
     * atteint.
     *
     * Sur TOUS les statuts, pas seulement les publiés. Le rang est le registre
     * des places attribuées ; la publication ne décide que de l'affichage. Le
     * premier jet réutilisait la requête d'affichage (filtrée sur `publish`) :
     * un article mis en avant puis repassé en brouillon — ou mis à la
     * corbeille, deux gestes du quotidien éditorial — disparaissait du calcul,
     * son rang était réattribué, et les deux articles ressortaient ex æquo à
     * la republication. L'ordre voulu par l'opérateur était alors perdu sans
     * qu'aucune manipulation ne puisse le rétablir.
     *
     * Le second jet corrigeait le brouillon mais PAS la corbeille : `'any'`
     * a l'air de tout prendre et n'en fait rien (voir ci-dessous).
     */
    public function rangSuivant(): int
    {
        $rangs = [0];

        /* `fields => ids` : on ne veut que des rangs, pas 500 objets post
           complets avec leurs termes à chaque clic de bascule. */
        $ids = get_posts([
            'post_type'              => 'post',
            /*
             * TOUS les statuts, littéralement — `'any'` n'en est pas un : le
             * cœur le traduit en « tout SAUF `exclude_from_search` »
             * (`class-wp-query.php:2655-2660`), donc sans `trash` ni
             * `auto-draft` (`post.php:733-745`). Un article mis à la
             * CORBEILLE libérait alors sa place, le marquage suivant la
             * reprenait, et les deux ressortaient ex æquo dès la
             * restauration.
             */
            'post_status'            => array_values(get_post_stati()),
            'numberposts'            => self::RANG_MAX,
            'fields'                 => 'ids',
            'meta_key'               => self::META,
            'no_found_rows'          => true,
            'update_post_term_cache' => false,
        ]);

        foreach (is_array($ids) ? $ids : [] as $id) {
            $rangs[] = $this->rang(is_object($id) ? (int) ($id->ID ?? 0) : (int) $id);
        }

        $suivant = max($rangs) + 1;

        return $suivant > self::RANG_MAX ? 0 : $suivant;
    }

    /**
     * Marque l'article, sous VERROU.
     *
     * `rangSuivant()` puis `update_post_meta()` est une séquence lue-puis-
     * écrite : deux opérateurs qui cliquent en même temps obtenaient le même
     * rang. Le noyau porte déjà la primitive atomique qu'il faut
     * (`Options::acquerirVerrou()`, revue 3.3) — s'en passer ici aurait été
     * repayer la même leçon.
     */
    public function marquer(int $postId): void
    {
        $jeton = self::VERROU . '-' . bin2hex(random_bytes(8));

        if ($this->options === null || !$this->options->acquerirVerrou(self::VERROU, 10, $jeton)) {
            Signal::emettre(
                'spiralbase_bloc_selection_verrou',
                'un autre marquage est en cours, réessayer dans un instant',
                'bloc sélection'
            );

            return;
        }

        try {
            $rang = $this->rangSuivant();

            if ($rang === 0) {
                /* Au plafond, ne RIEN écrire : attribuer une place déjà prise
                   ferait deux articles ex æquo, donc un ordre décidé par la
                   date et non par l'opérateur. */
                Signal::emettre(
                    'spiralbase_bloc_selection_plafond',
                    sprintf('sélection pleine (%d articles) : retirer un article avant d\'en ajouter un', self::RANG_MAX),
                    'bloc sélection'
                );

                return;
            }

            update_post_meta($postId, self::META, $rang);
        } finally {
            $this->options->relacherVerrou(self::VERROU, $jeton);
        }
    }

    public function retirer(int $postId): void
    {
        /* Suppression, jamais un 0 stocké : une meta à 0 est un état qui ne
           veut rien dire, et qu'il faudrait interpréter partout. */
        delete_post_meta($postId, self::META);
    }

    /**
     * Articles marqués, du plus petit rang au plus grand.
     *
     * `get_posts()` et non la boucle principale : cette liste s'affiche DANS
     * une page, elle ne doit jamais toucher la requête qui l'a produite.
     *
     * @return list<object>
     */
    public function articlesMarques(int $limite): array
    {
        $limite = max(1, min($limite, self::RANG_MAX));

        $articles = get_posts([
            'post_type'          => 'post',
            'post_status'        => 'publish',
            /* Les articles protégés par mot de passe restent `publish` : les
               laisser passer proposerait en une un lien qui n'ouvre qu'un
               formulaire, sous un titre présenté comme librement lisible (le
               cœur, lui, le préfixe via `protected_title_format`). */
            'has_password'       => false,
            /*
             * On demande PLUS que la limite, et on tronque APRÈS le tri PHP.
             * Le `LIMIT` du SQL choisit le sous-ensemble avant tout re-tri :
             * si l'ordre SQL est faussé — un filtre tiers sur `posts_orderby`,
             * ce que `suppress_filters => false` autorise explicitement — le
             * re-tri rangeait parfaitement les MAUVAIS articles. Prouvé en
             * revue : avec un filtre d'ordre tiers, la sélection rendait le
             * 2e et le 3e article au lieu du 1er et du 2e.
             * La marge sert aussi les rangs illisibles, que le SQL accepte
             * (`CAST('3.7' AS SIGNED) = 3`) et que PHP écarte ensuite : sans
             * elle, chaque rejet raccourcissait la liste en silence.
             */
            'numberposts'        => min(self::RANG_MAX, max($limite * 2, $limite + 5)),
            'meta_key'           => self::META,
            'orderby'            => ['meta_value_num' => 'ASC', 'date' => 'DESC'],
            'meta_query'         => [[
                'key'     => self::META,
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ]],
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'suppress_filters'       => false,
            /* Le bloc n'affiche ni catégorie ni étiquette : deux requêtes de
               termes par rendu, sur la page d'accueil de toute la flotte. */
            'update_post_term_cache' => false,
        ]);

        $marques = array_values(array_filter(
            is_array($articles) ? $articles : [],
            fn (mixed $a): bool => is_object($a) && $this->estMisEnAvant((int) ($a->ID ?? 0))
        ));

        /* Départage par ID et non par date : les ex æquo doivent avoir un
           ordre STABLE et arbitraire, pas un ordre qui a l'air d'un choix
           éditorial alors qu'il n'en est pas un. */
        usort($marques, fn (object $a, object $b): int
            => [$this->rang((int) $a->ID), (int) $a->ID] <=> [$this->rang((int) $b->ID), (int) $b->ID]);

        return array_slice($marques, 0, $limite);
    }

    /** Un rang lisible, ou 0 — jamais un cast PHP silencieux. */
    private static function normaliser(mixed $valeur): int
    {
        if (is_bool($valeur) || is_array($valeur) || is_object($valeur) || $valeur === null) {
            return 0;
        }

        if (is_string($valeur) && preg_match('/^\s*\d+\s*$/', $valeur) !== 1) {
            return 0;
        }

        /* Un flottant non entier suivait un chemin différent de sa version
           texte : `'3.7'` était refusé, `3.7` devenait le rang 3. Une même
           valeur logique doit recevoir le même verdict quel que soit son
           type PHP. */
        if (is_float($valeur) && (!is_finite($valeur) || $valeur != (int) $valeur)) {
            return 0;
        }

        $rang = (int) $valeur;

        return $rang > 0 ? min($rang, self::RANG_MAX) : 0;
    }
}
