---
paths:
  - "src/api/**"
  - "src/auth/**"
  - "src/handlers/**"
  - "routes/**"
  - "controllers/**"
  - "app/Http/Controllers/**"
---

# Règles de sécurité

> Ces règles s'activent automatiquement sur les fichiers API/auth/contrôleurs.

## À ne jamais faire

- Ne jamais exposer les stack traces ou les détails d'erreurs internes aux consommateurs d'API
- Ne jamais logger les mots de passe, tokens ou données sensibles
- Ne jamais faire confiance aux entrées utilisateur — tout valider à la frontière
- Ne jamais hardcoder des identifiants, clés API ou secrets
- Ne jamais utiliser `eval()` ni la concaténation de chaînes SQL

## À toujours faire

- Valider toutes les entrées avec un schéma (Zod, Joi, class-validator, FormRequest…)
- Nettoyer les sorties — supprimer les champs que les utilisateurs ne doivent pas voir
- Utiliser des requêtes paramétrées pour toutes les opérations DB
- Vérifier l'autorisation sur chaque route — pas seulement l'authentification
- Limiter le débit des endpoints qui acceptent des entrées utilisateur

## Secrets

- Tous les secrets via des variables d'environnement
- Les fichiers `.env` ne sont jamais committés
- Rotation immédiate des secrets en cas d'exposition accidentelle

## Dépendances

- Examiner les nouvelles dépendances avant de les ajouter
- Préférer les packages bien maintenus avec une activité récente
- Lancer `npm audit` après l'ajout de dépendances
