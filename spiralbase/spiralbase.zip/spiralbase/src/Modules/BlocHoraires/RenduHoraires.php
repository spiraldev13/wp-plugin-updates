<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocHoraires;

use SpiralBase\Core\AttributsBloc;
use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\PlagesOuverture;
use SpiralBase\Core\Signal;

/**
 * Rendu serveur du bloc `spiralbase/horaires` (story 3.1).
 *
 * Source UNIQUE : la porte `DonneesMetier` (AD-2) — la même que lit le
 * module `schema_metier` pour son JSON-LD, d'où l'AC 2 (une modification
 * des horaires se voit au bloc ET dans schema.org, sans duplication).
 *
 * Rien n'est inventé : une entrée d'horaire illisible est ignorée et
 * SIGNALÉE (NFR13), jamais affichée telle quelle — la saisie de l'opérateur
 * ne traverse pas le rendu, seul le résultat normalisé du parseur sort.
 * Aucun chemin fatal : toute exception rend une chaîne vide.
 *
 * État d'ouverture : calculé au fuseau du SITE (l'horloge injectée vaut
 * `current_datetime()` — `wp-includes/functions.php:101-103`, qui délègue à
 * `wp_timezone()` :152-154). Comme un état ouvert/fermé se périme, le bloc
 * émet aussi ses segments et son fuseau en `data-` : le script de vue
 * recalcule à l'affichage, ce qui rend la sortie compatible avec un cache
 * pleine page (leçon de la story 2.5 — ce qui varie se décide côté client).
 */
final class RenduHoraires
{
    /** @var \Closure(): \DateTimeImmutable */
    private \Closure $maintenant;

    /** Fuseau du site, relevé sur l'horloge au calcul de l'état (lue une seule fois par rendu). */
    private string $fuseau = '';

    public function __construct(
        private readonly DonneesMetier $donnees,
        ?\Closure $maintenant = null,
    ) {
        $this->maintenant = $maintenant ?? static fn (): \DateTimeImmutable => current_datetime();
    }

    /** @param array<string, mixed> $attributs attributs du bloc */
    public function rendre(array $attributs): string
    {
        try {
            return $this->contenu($attributs);
        } catch (\Throwable $e) {
            $this->signaler('spiralbase_bloc_horaires_echec', 'rendu interrompu : ' . $e->getMessage());

            return '';
        }
    }

    /** @param array<string, mixed> $attributs */
    private function contenu(array $attributs): string
    {
        $donnees  = $this->donnees->get();
        $horaires = is_array($donnees['horaires'] ?? null) ? $donnees['horaires'] : [];
        $analyse  = [];

        foreach ($horaires as $entree) {
            if (!is_string($entree)) {
                continue;
            }

            $entreeAnalysee = PlagesOuverture::analyserEntree($entree);

            if ($entreeAnalysee === null) {
                $this->signaler('spiralbase_bloc_horaires_illisible', sprintf('entrée d\'horaire ignorée : « %s »', $entree));

                continue;
            }

            $analyse[] = $entreeAnalysee;
        }

        /* Rien d'exploitable : pas de squelette vide, pas de message d'erreur
           au visiteur — le bloc disparaît (AD-3, esprit des modules en retrait). */
        if ($analyse === []) {
            return '';
        }

        $lignes = '';

        foreach ($analyse as $entreeAnalysee) {
            $lignes .= $this->ligne($entreeAnalysee);
        }

        $segments = PlagesOuverture::segments($analyse);
        $etat     = AttributsBloc::booleen($attributs, 'etatOuverture', false) && $segments !== []
            ? $this->etat($segments)
            : '';
        $wrapper = [];

        if ($etat !== '') {
            $wrapper['data-spiralbase-horaires'] = (string) wp_json_encode($segments);
            $wrapper['data-spiralbase-fuseau']   = $this->fuseau;
        }

        return '<div ' . EnveloppeBloc::attributs('spiralbase-horaires', $wrapper) . '>'
            . '<ul class="spiralbase-horaires__liste">' . $lignes . '</ul>'
            . $etat
            . '</div>';
    }

    /** @param array{jours: list<int>, plages: list<array{0: int, 1: int}>} $entree */
    private function ligne(array $entree): string
    {
        return '<li class="spiralbase-horaires__ligne">'
            . '<span class="spiralbase-horaires__jours">' . esc_html($this->jours($entree['jours'])) . '</span> '
            . '<span class="spiralbase-horaires__plages">' . esc_html($this->plages($entree['plages'])) . '</span>'
            . '</li>';
    }

    /**
     * « Lundi – Vendredi » pour trois jours consécutifs ou plus, « Samedi,
     * Dimanche » en deçà : la forme longue reste lisible sur deux jours et
     * l'intervalle évite une énumération de cinq noms.
     *
     * @param list<int> $jours
     */
    private function jours(array $jours): string
    {
        $suites = [];
        $suite  = [];

        foreach ($jours as $jour) {
            /* `Fr-Mo` reste UNE suite : la semaine tourne (modulo 7). */
            if ($suite === [] || $jour === ((int) end($suite) + 1) % 7) {
                $suite[] = $jour;

                continue;
            }

            $suites[] = $suite;
            $suite    = [$jour];
        }

        if ($suite !== []) {
            $suites[] = $suite;
        }

        $noms    = self::noms();
        $rendues = [];

        foreach ($suites as $groupe) {
            $rendues[] = count($groupe) >= 3
                ? $noms[$groupe[0]] . ' – ' . $noms[(int) end($groupe)]
                : implode(', ', array_map(static fn (int $jour): string => $noms[$jour], $groupe));
        }

        return implode(', ', $rendues);
    }

    /** @param list<array{0: int, 1: int}> $plages */
    private function plages(array $plages): string
    {
        $rendues = [];

        foreach ($plages as [$debut, $fin]) {
            $rendues[] = $debut === 0 && $fin === PlagesOuverture::JOUR
                ? __('Ouvert 24 h/24', 'spiralbase')
                : $this->heure($debut) . ' – ' . $this->heure($fin);
        }

        return implode(', ', $rendues);
    }

    /** Une fin au-delà de minuit se lit en heure du jour suivant (22:00 – 02:00). */
    private function heure(int $minutes): string
    {
        $minutes %= PlagesOuverture::JOUR;

        return sprintf('%02d:%02d', intdiv($minutes, 60), $minutes % 60);
    }

    /** @param list<array{0: int, 1: int}> $segments */
    private function etat(array $segments): string
    {
        try {
            $maintenant = ($this->maintenant)();
        } catch (\Throwable $e) {
            /* La LISTE des horaires n'a besoin d'aucune horloge : une horloge
               en échec ne doit faire perdre que l'indicateur, pas le bloc
               entier (revue 3.1 — le try/catch global l'emportait). */
            $this->signaler('spiralbase_bloc_horaires_echec', 'horloge du site illisible : ' . $e->getMessage());

            return '';
        }

        $this->fuseau  = $maintenant->getTimezone()->getName();
        $minuteSemaine = ((int) $maintenant->format('N') - 1) * PlagesOuverture::JOUR
            + (int) $maintenant->format('G') * 60
            + (int) $maintenant->format('i');

        $ouvert  = PlagesOuverture::estOuvert($segments, $minuteSemaine);
        $libelle = ['ouvert' => __('Ouvert', 'spiralbase'), 'ferme' => __('Fermé', 'spiralbase')];

        /* Les deux libellés voyagent avec le bloc : le script de vue les
           réutilise tels quels, sans dupliquer la traduction en JS. */
        return '<p class="spiralbase-horaires__etat spiralbase-horaires__etat--' . ($ouvert ? 'ouvert' : 'ferme') . '"'
            . ' data-spiralbase-etat="1"'
            . ' data-spiralbase-libelle-ouvert="' . esc_attr($libelle['ouvert']) . '"'
            . ' data-spiralbase-libelle-ferme="' . esc_attr($libelle['ferme']) . '">'
            . esc_html($ouvert ? $libelle['ouvert'] : $libelle['ferme'])
            . '</p>';
    }

    /** @return array<int, string> */
    private static function noms(): array
    {
        return [
            0 => __('Lundi', 'spiralbase'),
            1 => __('Mardi', 'spiralbase'),
            2 => __('Mercredi', 'spiralbase'),
            3 => __('Jeudi', 'spiralbase'),
            4 => __('Vendredi', 'spiralbase'),
            5 => __('Samedi', 'spiralbase'),
            6 => __('Dimanche', 'spiralbase'),
        ];
    }

    /** Bornage et journalisation NFR13 mutualisés dans le noyau (story 3.2). */
    private function signaler(string $hook, string $message): void
    {
        Signal::emettre($hook, $message, 'bloc horaires');
    }
}
