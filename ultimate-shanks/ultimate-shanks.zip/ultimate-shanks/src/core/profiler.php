<?php
/**
 * Profiler interne ultra léger pour diagnostic de performance.
 *
 * Activation:
 * - définir ULTIMATE_SHANKS_PROFILE à true (ex: wp-config.php)
 *
 * @package UltimateShanks\Core
 */

namespace UltimateShanks\Core;

if (!defined('ABSPATH')) {
	exit;
}

class Profiler
{
	/**
	 * @var bool|null
	 */
	private static $enabled = null;

	/**
	 * @var array<string, array{count:int,total_ms:float,max_ms:float}>
	 */
	private static $stats = [];

	/**
	 * Initialise le profiler (hook shutdown si activé).
	 */
	public static function init()
	{
		if (!self::is_enabled()) {
			return;
		}

		add_action('shutdown', [self::class, 'log_request_summary'], PHP_INT_MAX);
	}

	/**
	 * Vérifie si le profiler est activé.
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		if (self::$enabled !== null) {
			return self::$enabled;
		}

		self::$enabled = defined('ULTIMATE_SHANKS_PROFILE') && (bool) ULTIMATE_SHANKS_PROFILE;
		return self::$enabled;
	}

	/**
	 * Démarre un chrono pour une section.
	 *
	 * @param string $name Nom section.
	 * @return float|null
	 */
	public static function start($name)
	{
		if (!self::is_enabled() || !is_string($name) || $name === '') {
			return null;
		}

		return microtime(true);
	}

	/**
	 * Arrête un chrono et agrège les stats.
	 *
	 * @param string $name Nom section.
	 * @param float|null $started_at Timestamp start.
	 * @param array<string, mixed> $context Contexte optionnel.
	 */
	public static function stop($name, $started_at, $context = [])
	{
		if (!self::is_enabled() || !is_string($name) || $name === '' || !is_float($started_at)) {
			return;
		}

		$elapsed_ms = max(0.0, (microtime(true) - $started_at) * 1000);

		if (!isset(self::$stats[$name])) {
			self::$stats[$name] = [
				'count' => 0,
				'total_ms' => 0.0,
				'max_ms' => 0.0,
			];
		}

		self::$stats[$name]['count']++;
		self::$stats[$name]['total_ms'] += $elapsed_ms;
		self::$stats[$name]['max_ms'] = max(self::$stats[$name]['max_ms'], $elapsed_ms);

		// Log détaillé uniquement pour sections lentes.
		if ($elapsed_ms >= 120.0) {
			$ctx = self::format_context($context);
			error_log(
				sprintf(
					'[Ultimate Shanks Profiler] slow section=%s time=%.2fms%s',
					$name,
					$elapsed_ms,
					$ctx === '' ? '' : ' ' . $ctx
				)
			);
		}
	}

	/**
	 * Log un résumé de la requête en fin d'exécution.
	 */
	public static function log_request_summary()
	{
		if (!self::is_enabled()) {
			return;
		}

		$start = isset($_SERVER['REQUEST_TIME_FLOAT']) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true);
		$total_ms = max(0.0, (microtime(true) - $start) * 1000);
		$peak_mb = memory_get_peak_usage(true) / 1048576;
		$uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : 'cli';

		$stats = self::$stats;
		uasort($stats, function($a, $b) {
			if ($a['total_ms'] === $b['total_ms']) {
				return 0;
			}

			return ($a['total_ms'] < $b['total_ms']) ? 1 : -1;
		});

		$top = [];
		foreach ($stats as $name => $stat) {
			$top[] = sprintf(
				'%s=%.2fms/%dx(max:%.2f)',
				$name,
				$stat['total_ms'],
				$stat['count'],
				$stat['max_ms']
			);

			if (count($top) >= 6) {
				break;
			}
		}

		$context = is_admin() ? 'admin' : 'front';
		if (wp_doing_ajax()) {
			$context = 'ajax';
		} elseif (wp_doing_cron()) {
			$context = 'cron';
		}

		error_log(
			sprintf(
				'[Ultimate Shanks Profiler] req=%s total=%.2fms peak=%.2fMB uri=%s%s',
				$context,
				$total_ms,
				$peak_mb,
				$uri,
				empty($top) ? '' : ' top=[' . implode('; ', $top) . ']'
			)
		);
	}

	/**
	 * Formate un contexte de log.
	 *
	 * @param array<string, mixed> $context
	 * @return string
	 */
	private static function format_context($context)
	{
		if (empty($context)) {
			return '';
		}

		$parts = [];
		foreach ($context as $key => $value) {
			if (is_scalar($value) || $value === null) {
				$parts[] = $key . '=' . (string) $value;
			}
		}

		return implode(' ', $parts);
	}
}
