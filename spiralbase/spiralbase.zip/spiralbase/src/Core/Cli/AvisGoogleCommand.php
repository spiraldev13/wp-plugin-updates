<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Modules\BlocAvisGoogle\AvisGoogle;

/**
 * `wp spiralbase avis` — coquille CLI : délègue TOUT au service (pattern
 * RecipeCommand/RgpdCommand). Messages CLI non traduits (convention WP-CLI).
 *
 * Elle existe pour deux besoins concrets : remplir le cache le jour de la
 * livraison sans attendre le premier passage du cron, et diagnostiquer une
 * configuration depuis le terminal — sans jamais afficher la clé d'API.
 */
final class AvisGoogleCommand
{
    public function __construct(private readonly AvisGoogle $service)
    {
    }

    /**
     * Rappelle Google et met à jour le cache.
     *
     * ## OPTIONS
     *
     * [--force]
     * : Rappelle même si le cache est encore frais.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase avis rafraichir
     *     wp spiralbase avis rafraichir --force
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function rafraichir(array $args, array $assocArgs): void
    {
        /*
         * QUATRE causes, quatre messages. La première version en déduisait
         * deux depuis `estFrais()` : après un vrai HTTP 400 sur un cache
         * encore frais, elle annonçait « aucun appel émis » — trois
         * affirmations fausses en une ligne, le jour même de la livraison où
         * l'opérateur diagnostique sa clé (revue 3.3). Un verrou tenu par un
         * cron produisait la même confusion en sens inverse.
         */
        $resultat = $this->service->rafraichirDetaille(isset($assocArgs['force']));

        if ($resultat === AvisGoogle::RESULTAT_NON_CONFIGURE) {
            \WP_CLI::error('Module non configuré : renseignez place_id et cle_api dans l\'option spiralbase_avis_google.');

            return;
        }

        if ($resultat === AvisGoogle::RESULTAT_OK) {
            $donnees = $this->service->donnees() ?? [];

            \WP_CLI::success(sprintf(
                'Avis rafraîchis : note %s sur %d avis, %d affichables.',
                $donnees['note'] === null ? 'aucune' : (string) $donnees['note'],
                (int) ($donnees['total'] ?? 0),
                count($donnees['avis'] ?? [])
            ));

            return;
        }

        if ($resultat === AvisGoogle::RESULTAT_FRAIS) {
            \WP_CLI::log('Cache encore frais : aucun appel émis (utilisez --force pour forcer).');

            return;
        }

        if ($resultat === AvisGoogle::RESULTAT_VERROUILLE) {
            \WP_CLI::warning('Un rafraîchissement est déjà en cours (verrou posé) : aucun appel émis.');

            return;
        }

        \WP_CLI::warning('Aucune réponse valide de Google — le dernier cache reste servi (voir le journal).');
    }

    /**
     * Affiche l'état du cache.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase avis etat
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function etat(array $args, array $assocArgs): void
    {
        $donnees = $this->service->donnees();

        \WP_CLI::log('Configuré : ' . ($this->service->estConfigure() ? 'oui' : 'non'));
        \WP_CLI::log('Cache frais : ' . ($this->service->estFrais() ? 'oui' : 'non'));

        if ($donnees === null) {
            \WP_CLI::log('Aucune donnée en cache.');

            return;
        }

        \WP_CLI::log(sprintf(
            'Note %s sur %d avis, %d affichables, récupérés le %s.',
            $donnees['note'] === null ? 'aucune' : (string) $donnees['note'],
            (int) ($donnees['total'] ?? 0),
            count($donnees['avis'] ?? []),
            gmdate('Y-m-d H:i', (int) ($donnees['recupere_le'] ?? 0)) . ' UTC'
        ));
    }
}
