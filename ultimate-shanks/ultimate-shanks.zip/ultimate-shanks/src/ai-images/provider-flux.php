<?php

/**
 * AI Images - Provider Flux (Black Forest Labs)
 *
 * Appelle l'API directe BFL : soumission POST {base}/{model} avec header
 * propriétaire `x-key`, puis polling de `polling_url` jusqu'au statut Ready.
 * La clé API vient en priorité de la constante ULTIMATE_SHANKS_BFL_API_KEY
 * (wp-config.php), sinon de l'option de réglages.
 *
 * Dimensions : la plupart des endpoints BFL attendent width/height (multiples
 * de 32, bornés 256-1440 pour FLUX.1) ; seul flux-pro-1.1-ultra attend
 * aspect_ratio. Le format choisi par l'utilisateur est converti en pixels
 * (~1 mégapixel) pour les modèles concernés — source : spec OpenAPI officiel
 * https://api.bfl.ai/openapi.json.
 *
 * Fichiers liés :
 * - src/ai-images/provider-interface.php
 * - src/ai-images/generator.php (sideload, hors provider)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class FluxProvider implements ProviderInterface
{
	const ID = 'flux-bfl';

	const DEFAULT_API_BASE = 'https://api.bfl.ai/v1';

	const DEFAULT_MODEL = '/flux-pro-1.1';

	/**
	 * Conversion format → pixels (~1 Mpx, multiples de 32, bornés 256-1440)
	 */
	const RATIO_DIMENSIONS = [
		'1:1'  => [1024, 1024],
		'3:2'  => [1248, 832],
		'4:3'  => [1152, 864],
		'16:9' => [1344, 768],
		'9:16' => [768, 1344],
		'3:4'  => [864, 1152],
	];

	public function get_id()
	{
		return self::ID;
	}

	public function get_label()
	{
		return 'Flux (Black Forest Labs)';
	}

	/**
	 * Modèles intégrés : endpoint, libellé, mode de dimensions et prix indicatif
	 * par image (USD, éditable dans les réglages). Prix « à partir de » pour les
	 * FLUX.2 (tarification au mégapixel). Sources : spec OpenAPI et
	 * docs.bfl.ai/quick_start/pricing (2026-08).
	 *
	 * @return array endpoint => ['label','dims'('width_height'|'aspect_ratio'),'price']
	 */
	public static function get_builtin_models()
	{
		return [
			'/flux-dev'           => ['label' => 'Flux Dev (économique)', 'dims' => 'width_height', 'price' => 0.025],
			'/flux-pro-1.1'       => ['label' => 'Flux Pro 1.1', 'dims' => 'width_height', 'price' => 0.04],
			'/flux-pro-1.1-ultra' => ['label' => 'Flux Pro 1.1 Ultra', 'dims' => 'aspect_ratio', 'price' => 0.06],
			'/flux-2-klein-4b'    => ['label' => 'FLUX.2 Klein 4B (le plus rapide)', 'dims' => 'width_height', 'price' => 0.014],
			'/flux-2-klein-9b'    => ['label' => 'FLUX.2 Klein 9B', 'dims' => 'width_height', 'price' => 0.015],
			'/flux-2-pro'         => ['label' => 'FLUX.2 Pro (recommandé)', 'dims' => 'width_height', 'price' => 0.03],
			'/flux-2-flex'        => ['label' => 'FLUX.2 Flex (typographie)', 'dims' => 'width_height', 'price' => 0.05],
			'/flux-2-max'         => ['label' => 'FLUX.2 Max (qualité maximale)', 'dims' => 'width_height', 'price' => 0.07],
		];
	}

	/**
	 * Catalogue complet : modèles intégrés (prix éventuellement surchargés par
	 * l'option `..._prices`) + modèles personnalisés ajoutés dans les réglages.
	 *
	 * @return array endpoint => ['label','dims','price','builtin' => bool]
	 */
	public function get_models()
	{
		$models = [];

		$overrides = (array) Providers::get_setting(self::ID, 'prices', []);
		foreach (self::get_builtin_models() as $endpoint => $model) {
			if (isset($overrides[$endpoint]) && is_numeric($overrides[$endpoint])) {
				$model['price'] = (float) $overrides[$endpoint];
			}
			$model['builtin'] = true;
			$models[$endpoint] = $model;
		}

		foreach ((array) Providers::get_setting(self::ID, 'custom_models', []) as $custom) {
			if (empty($custom['endpoint'])) {
				continue;
			}
			$models[$custom['endpoint']] = [
				'label'   => !empty($custom['label']) ? $custom['label'] : $custom['endpoint'],
				'dims'    => (!empty($custom['dims']) && $custom['dims'] === 'aspect_ratio') ? 'aspect_ratio' : 'width_height',
				'price'   => isset($custom['price']) ? (float) $custom['price'] : null,
				'builtin' => false,
			];
		}

		return $models;
	}

	/**
	 * Descripteur d'un modèle (repli : width/height, prix inconnu)
	 *
	 * @param string $endpoint
	 * @return array
	 */
	public function get_model_info($endpoint)
	{
		$models = $this->get_models();

		if (isset($models[$endpoint])) {
			return $models[$endpoint];
		}

		return ['label' => $endpoint, 'dims' => 'width_height', 'price' => null, 'builtin' => false];
	}

	public function get_settings_fields()
	{
		$model_options = [];
		foreach ($this->get_models() as $endpoint => $model) {
			$model_options[$endpoint] = $model['label'];
		}

		return [
			[
				'key'         => 'api_key',
				'label'       => 'Clé API',
				'type'        => 'secret',
				'default'     => '',
				'description' => 'Clé Black Forest Labs. La constante ULTIMATE_SHANKS_BFL_API_KEY '
					. 'dans wp-config.php est prioritaire sur ce champ.',
			],
			[
				'key'         => 'api_base',
				'label'       => 'URL de base de l\'API',
				'type'        => 'select',
				'options'     => [
					'https://api.bfl.ai/v1'    => 'Globale — api.bfl.ai',
					'https://api.eu.bfl.ai/v1' => 'Europe — api.eu.bfl.ai',
					'https://api.us.bfl.ai/v1' => 'États-Unis — api.us.bfl.ai',
				],
				'default'     => self::DEFAULT_API_BASE,
				'description' => 'Région de l\'API BFL.',
			],
			[
				'key'         => 'model',
				'label'       => 'Modèle par défaut',
				'type'        => 'select',
				'options'     => $model_options,
				'default'     => self::DEFAULT_MODEL,
				'description' => 'Modèle utilisé quand aucun n\'est choisi au moment de la génération.',
			],
		];
	}

	/**
	 * Indique si une clé API est disponible (constante ou option)
	 *
	 * @return bool
	 */
	public function has_api_key()
	{
		return $this->get_api_key() !== '';
	}

	/**
	 * Source de la clé API, pour les réglages et Site Health
	 *
	 * @return string 'constant'|'option'|'none'
	 */
	public function get_api_key_source()
	{
		if (defined('ULTIMATE_SHANKS_BFL_API_KEY') && ULTIMATE_SHANKS_BFL_API_KEY !== '') {
			return 'constant';
		}

		if (Providers::get_setting(self::ID, 'api_key', '') !== '') {
			return 'option';
		}

		return 'none';
	}

	public function generate($prompt, $args)
	{
		$aspect_ratio = !empty($args['aspect_ratio']) ? $args['aspect_ratio'] : '3:2';
		$model = !empty($args['model']) ? $args['model'] : $this->get_model();

		$polling_url = $this->submit($prompt, $aspect_ratio, $model);
		if (is_wp_error($polling_url)) {
			return $polling_url;
		}

		$deadline = time() + Generator::time_budget();
		$result = $this->poll($polling_url, $deadline);
		if (is_wp_error($result)) {
			return $result;
		}

		$url = $this->extract_image_url($result);
		if (is_wp_error($url)) {
			return $url;
		}

		$info = $this->get_model_info($model);

		return [
			'url'   => $url,
			'model' => $model,
			'cost'  => $info['price'],
		];
	}

	public function test_connection()
	{
		$api_key = $this->get_api_key();
		if ($api_key === '') {
			return new \WP_Error('ai_images_no_key', 'Aucune clé API configurée. Enregistrez d\'abord une clé.');
		}

		// Soumission volontairement invalide (body vide) : l'authentification
		// est vérifiée sans lancer de génération, donc sans consommer de crédit.
		$response = wp_remote_post($this->build_endpoint($this->get_model()), [
			'timeout' => 20,
			'headers' => $this->build_headers($api_key),
			'body'    => '{}',
		]);

		if (is_wp_error($response)) {
			return new \WP_Error('ai_images_network', 'Erreur réseau : ' . $response->get_error_message());
		}

		$code = (int) wp_remote_retrieve_response_code($response);
		$data = json_decode(wp_remote_retrieve_body($response), true);

		if ($code === 401 || $code === 403) {
			return new \WP_Error('ai_images_bad_key', 'Clé API invalide ou non autorisée.');
		}

		// L'API vérifie l'authentification avant la validation du body, mais une
		// clé au mauvais format renvoie aussi 422 : on discrimine par le détail.
		if ($code === 422) {
			$detail = isset($data['detail']) && is_string($data['detail']) ? $data['detail'] : '';
			if (stripos($detail, 'api key') !== false) {
				return new \WP_Error('ai_images_bad_key', 'Clé API invalide (format refusé par l\'API).');
			}

			// 422 de validation « prompt manquant » : preuve que la clé passe
			return ['message' => 'Connexion établie et clé API acceptée.'];
		}

		if ($code === 200 || $code === 202) {
			return ['message' => 'Connexion établie et clé API acceptée.'];
		}

		return new \WP_Error('ai_images_unexpected', sprintf('Réponse inattendue de l\'API (HTTP %d).', $code));
	}

	/**
	 * Clé API : constante wp-config.php prioritaire, sinon option
	 *
	 * @return string
	 */
	private function get_api_key()
	{
		if (defined('ULTIMATE_SHANKS_BFL_API_KEY') && ULTIMATE_SHANKS_BFL_API_KEY !== '') {
			return (string) ULTIMATE_SHANKS_BFL_API_KEY;
		}

		return (string) Providers::get_setting(self::ID, 'api_key', '');
	}

	/**
	 * Modèle par défaut configuré dans les réglages
	 *
	 * @return string
	 */
	private function get_model()
	{
		return (string) Providers::get_setting(self::ID, 'model', self::DEFAULT_MODEL);
	}

	/**
	 * URL complète d'un endpoint modèle
	 *
	 * @param string $model
	 * @return string
	 */
	private function build_endpoint($model)
	{
		$base = (string) Providers::get_setting(self::ID, 'api_base', self::DEFAULT_API_BASE);

		return trailingslashit($base) . ltrim($model, '/');
	}

	/**
	 * Headers communs aux appels BFL
	 *
	 * @param string $api_key
	 * @return array
	 */
	private function build_headers($api_key)
	{
		return [
			'accept'       => 'application/json',
			'content-type' => 'application/json',
			'x-key'        => $api_key,
		];
	}

	/**
	 * Construit le body de soumission selon le mode de dimensions du modèle
	 *
	 * @param string $prompt
	 * @param string $aspect_ratio
	 * @param string $model
	 * @return array
	 */
	private function build_body($prompt, $aspect_ratio, $model)
	{
		$info = $this->get_model_info($model);

		if ($info['dims'] === 'aspect_ratio') {
			return [
				'prompt'       => $prompt,
				'aspect_ratio' => $aspect_ratio,
			];
		}

		$dimensions = isset(self::RATIO_DIMENSIONS[$aspect_ratio])
			? self::RATIO_DIMENSIONS[$aspect_ratio]
			: self::RATIO_DIMENSIONS['3:2'];

		return [
			'prompt' => $prompt,
			'width'  => $dimensions[0],
			'height' => $dimensions[1],
		];
	}

	/**
	 * Soumet la génération et retourne l'URL de polling
	 *
	 * @param string $prompt
	 * @param string $aspect_ratio
	 * @param string $model
	 * @return string|\WP_Error
	 */
	private function submit($prompt, $aspect_ratio, $model)
	{
		$api_key = $this->get_api_key();
		if ($api_key === '') {
			return new \WP_Error(
				'ai_images_no_key',
				'Clé API Black Forest Labs non configurée (constante ULTIMATE_SHANKS_BFL_API_KEY ou réglages).'
			);
		}

		$response = wp_remote_post($this->build_endpoint($model), [
			'timeout' => 30,
			'headers' => $this->build_headers($api_key),
			'body'    => wp_json_encode($this->build_body($prompt, $aspect_ratio, $model)),
		]);

		if (is_wp_error($response)) {
			return new \WP_Error('ai_images_network', 'Erreur réseau lors de la soumission : ' . $response->get_error_message());
		}

		$code = (int) wp_remote_retrieve_response_code($response);
		$data = json_decode(wp_remote_retrieve_body($response), true);

		if ($code === 401 || $code === 403) {
			return new \WP_Error('ai_images_bad_key', 'Clé API invalide ou non autorisée.');
		}

		if ($code >= 400 || empty($data['polling_url'])) {
			$detail = isset($data['detail']) ? wp_json_encode($data['detail']) : '';

			return new \WP_Error(
				'ai_images_submit_failed',
				sprintf('Échec de la soumission à l\'API Flux (HTTP %d). %s', $code, $detail),
				['status' => $code]
			);
		}

		return (string) $data['polling_url'];
	}

	/**
	 * Interroge l'URL de polling jusqu'à Ready, échec ou épuisement du budget temps
	 *
	 * @param string $polling_url
	 * @param int    $deadline Timestamp limite
	 * @return array|\WP_Error Résultat BFL complet
	 */
	private function poll($polling_url, $deadline)
	{
		$api_key = $this->get_api_key();

		// L'API répond rarement en moins de 2 s : attente initiale avant le premier poll
		sleep(2);

		while (time() < $deadline) {
			$response = wp_remote_get($polling_url, [
				'timeout' => 15,
				'headers' => $this->build_headers($api_key),
			]);

			if (is_wp_error($response)) {
				return new \WP_Error('ai_images_network', 'Erreur réseau pendant le suivi : ' . $response->get_error_message());
			}

			$result = json_decode(wp_remote_retrieve_body($response), true);
			$status = isset($result['status']) ? (string) $result['status'] : '';

			if ($status === 'Ready') {
				return is_array($result) ? $result : [];
			}

			if ($status === 'Error' || $status === 'Failed') {
				return new \WP_Error('ai_images_failed', sprintf('La génération a échoué côté API (statut : %s).', $status));
			}

			if ($status === 'Content Moderated' || $status === 'Request Moderated') {
				return new \WP_Error(
					'ai_images_moderated',
					'Le prompt ou l\'image générée a été refusé par la modération de l\'API. Reformulez le prompt.'
				);
			}

			sleep(2);
		}

		return new \WP_Error(
			'ai_images_timeout',
			sprintf('Délai dépassé (%d s) en attendant l\'image. Réessayez.', Generator::time_budget())
		);
	}

	/**
	 * Extrait l'URL de l'image du résultat BFL
	 *
	 * @param array $result
	 * @return string|\WP_Error
	 */
	private function extract_image_url($result)
	{
		if (!empty($result['result']['sample'])) {
			return (string) $result['result']['sample'];
		}

		if (!empty($result['result']['url'])) {
			return (string) $result['result']['url'];
		}

		return new \WP_Error('ai_images_no_url', 'Aucune URL d\'image dans la réponse de l\'API.');
	}
}
