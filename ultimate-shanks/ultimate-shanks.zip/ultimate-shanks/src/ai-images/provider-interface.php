<?php

/**
 * AI Images - Interface des fournisseurs de génération d'images
 *
 * Contrat minimal qu'un fournisseur d'IA d'images (Flux/BFL, et à terme
 * fal.ai, Replicate, OpenAI…) doit implémenter pour être branché au module.
 * Les providers sont les seules classes instanciées du module : le
 * polymorphisme est nécessaire pour l'extensibilité multi-fournisseurs.
 *
 * Fichiers liés :
 * - src/ai-images/providers.php (registre)
 * - src/ai-images/provider-flux.php (implémentation BFL)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

interface ProviderInterface
{
	/**
	 * Identifiant unique du provider (slug, ex. 'flux-bfl')
	 *
	 * @return string
	 */
	public function get_id();

	/**
	 * Libellé lisible affiché dans les réglages
	 *
	 * @return string
	 */
	public function get_label();

	/**
	 * Modèles proposés par le provider (intégrés + personnalisés).
	 *
	 * @return array id/endpoint => ['label' => string, 'price' => float|null,
	 *               ...clés propres au provider]
	 */
	public function get_models();

	/**
	 * Descripteurs des champs de réglages propres au provider.
	 *
	 * Chaque descripteur : [
	 *   'key'         => (string) suffixe d'option,
	 *   'label'       => (string) libellé,
	 *   'type'        => 'secret'|'select'|'text',
	 *   'options'     => (array)  valeur => libellé, pour type select,
	 *   'default'     => (string) valeur par défaut,
	 *   'description' => (string) aide affichée sous le champ,
	 * ]
	 *
	 * @return array
	 */
	public function get_settings_fields();

	/**
	 * Génère une image et retourne son URL temporaire.
	 *
	 * @param string $prompt Prompt descriptif (peut être multi-lignes)
	 * @param array  $args   ['aspect_ratio' => string, 'model' => string|null]
	 * @return array|\WP_Error ['url' => string, 'model' => string,
	 *                          'cost' => float|null (USD, estimation)]
	 */
	public function generate($prompt, $args);

	/**
	 * Teste la connexion à l'API sans consommer de crédit.
	 *
	 * @return array|\WP_Error ['message' => string]
	 */
	public function test_connection();
}
