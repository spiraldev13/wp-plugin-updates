# Règles de tests

## Philosophie

- Écrire les tests avant de marquer une tâche comme terminée
- Les tests prouvent le comportement, pas juste la couverture de code
- Un test qui ne plante pas quand le code est cassé ne sert à rien

## Structure

- Tests unitaires : fonctions pures et logique isolée
- Tests d'intégration : interactions entre services et requêtes DB
- Tests E2E : uniquement les parcours utilisateur critiques

## Nommage

- `it('devrait [comportement attendu] quand [condition]')`
- Une assertion par test quand c'est possible
- Tester le contrat, pas l'implémentation

## Base de données

- [ex. Les tests utilisent une vraie DB locale — lancer `npm run db:test:reset` avant la suite]
- [ex. Chaque test nettoie après lui — pas d'état partagé entre tests]

## Ordre de priorité

1. Cas nominal (chemin heureux)
2. Cas limites (entrée vide, null, zéro, valeur max)
3. Cas d'erreur (entrée invalide, échec réseau)
4. Conditions aux bornes

## Ce qu'on ne teste PAS

- Les librairies tierces
- Les internals du framework
- Les détails d'implémentation privés
