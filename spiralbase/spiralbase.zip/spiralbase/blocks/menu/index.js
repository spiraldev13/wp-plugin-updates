/**
 * Bloc spiralbase/menu — JS éditeur écrit à la main, SANS build (AD-12 :
 * l'artefact livré EST ce fichier).
 *
 * Deux points non négociables :
 *
 *  1. `save()` retourne `InnerBlocks.Content`, JAMAIS null. Un bloc à
 *     InnerBlocks dont le save rend null ne sérialise pas ses enfants : les
 *     sections et les plats disparaîtraient du contenu de l'article à
 *     l'enregistrement. Le bloc reste 100 % dynamique pour autant — son save
 *     ne produit aucun HTML propre, seulement les délimiteurs de ses enfants,
 *     et tout le rendu se fait côté serveur (`render_callback`).
 *
 *  2. Pas d'aperçu ServerSideRender ici : l'API de rendu de bloc reçoit les
 *     attributs, pas les blocs enfants — la carte s'y afficherait vide. Ce
 *     que voit l'opérateur est l'édition native (InnerBlocks + RichText),
 *     habillée par la MÊME feuille de style que le front (`style` du
 *     block.json est chargé des deux côtés) : ce qu'il voit est ce qu'il aura.
 *     C'est pour cela que le conteneur des enfants passe par
 *     `useInnerBlocksProps` et non par le composant `InnerBlocks` : ce
 *     dernier interpose deux `<div>` intermédiaires, et toute règle de mise
 *     en page posée sur le conteneur (la grille de la variante « cartes »)
 *     ne s'appliquait alors qu'à eux — l'aperçu mentait (revue 3.2).
 */
( function ( blocks, element, blockEditor, components, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    var VARIANTES = [
        { value: 'liste', label: __( 'Liste — prix aligné à droite', 'spiralbase' ) },
        { value: 'cartes', label: __( 'Cartes — chaque plat dans un bloc', 'spiralbase' ) },
        { value: 'compact', label: __( 'Compact — menu du jour', 'spiralbase' ) },
    ];

    blocks.registerBlockType( 'spiralbase/menu', {
        edit: function ( props ) {
            /* Le vocabulaire est fermé côté serveur aussi (Variantes::juger) :
               ce repli n'est qu'un confort d'affichage. */
            var variante = props.attributes.variante || 'liste';

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-menu spiralbase-menu--' + variante,
            } );

            /* Le wrapper du bloc EST le conteneur des sections — même
               structure qu'au rendu serveur, aucun div intercalaire. */
            var innerProps = blockEditor.useInnerBlocksProps( blockProps, {
                allowedBlocks: [ 'spiralbase/menu-section' ],
                template: [ [ 'spiralbase/menu-section' ] ],
            } );

            /* Le panneau est un FRÈRE du conteneur : passer des enfants
               explicites à l'élément écraserait les `children` que
               useInnerBlocksProps y a placés — les sections disparaîtraient
               de l'écran d'édition. */
            return e(
                element.Fragment,
                null,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Mise en forme de la carte', 'spiralbase' ) },
                        e( components.SelectControl, {
                            label: __( 'Présentation', 'spiralbase' ),
                            value: variante,
                            options: VARIANTES,
                            help: __(
                                'Change la présentation seule : les sections, les plats et les prix sont conservés.',
                                'spiralbase'
                            ),
                            onChange: function ( valeur ) {
                                props.setAttributes( { variante: valeur } );
                            },
                        } )
                    )
                ),
                e( 'div', innerProps )
            );
        },
        save: function () {
            return e( blockEditor.InnerBlocks.Content );
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n
);
