<?php
/**
 * Ligne unitaire — Article de blog (type natif `post`).
 *
 * Inclue depuis sections/07-journal.php. Affichée en grille 4 colonnes
 * (numéro / titre+cat / date / flèche) sur desktop, en stack sur mobile
 * (numéro et flèche masqués).
 *
 * Argument attendu : ['index' => n] (numérotation auto via la boucle).
 * Catégorie affichée : la première `category` rattachée au post.
 */

if (!defined('ABSPATH')) {
    exit;
}

$index      = isset($args['index']) ? (int) $args['index'] : 1;
$categories = get_the_category();
$cat        = !empty($categories) ? $categories[0]->name : '';
?>
<a class="blog-row" href="<?php the_permalink(); ?>">
    <div class="num">— <?php echo esc_html(str_pad((string) $index, 3, '0', STR_PAD_LEFT)); ?></div>
    <div>
        <?php if ($cat): ?>
            <span class="cat"><?php echo esc_html($cat); ?></span>
        <?php endif; ?>
        <h3><?php the_title(); ?></h3>
    </div>
    <div class="date"><?php echo esc_html(get_the_date()); ?></div>
    <div class="arrow" aria-hidden="true">
        <?php evolutionr_icon('arrow-right', 14); ?>
    </div>
</a>
