<?php

/*
 * Manifeste du script de VUE (front) — écrit à la main, aucune dépendance :
 * vue.js est du JavaScript nu, chargé par WordPress uniquement sur les pages
 * qui contiennent réellement le bloc (mécanique `viewScript` du block.json).
 *
 * La version suit celle du THÈME, jamais un numéro figé : le cœur en fait le
 * `?ver=` du script (`wp-includes/blocks.php` — `$script_asset['version']`
 * l'emporte sur la version du bloc). Gelée à « 1.0.0 », une correction du
 * calcul ouvert/fermé livrée par une release de la flotte aurait continué
 * d'être servie depuis le cache des navigateurs et des CDN — les sites
 * clients auraient affiché une information d'ouverture fausse (revue 3.1).
 */
return [
    'dependencies' => [],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
