<?php

/**
 * AI Images - Endpoint REST de génération pilotable à distance
 *
 * Expose POST /wp-json/cmd/v1/ai-image pour WP Command Center : génère une
 * image pour un contenu (article ou page) et applique la cible demandée.
 * Route non enregistrée (404) quand le module est désactivé, comme les
 * autres intégrations cmd/v1.
 *
 * Fichiers liés :
 * - src/ai-images/generator.php
 * - src/integration/rankmath-integration.php (pattern suivi)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class Rest
{
	public static function init()
	{
		add_action('rest_api_init', [self::class, 'register_rest_routes']);
	}

	/**
	 * Enregistre la route uniquement si le module est activé
	 */
	public static function register_rest_routes()
	{
		if (!AiImages::is_enabled()) {
			return;
		}

		register_rest_route('cmd/v1', '/ai-image', [
			'methods'             => 'POST',
			'callback'            => [self::class, 'generate_for_cmd'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);
	}

	/**
	 * Génère une image pour un contenu.
	 * Paramètres : post_id (requis), prompt, target, aspect_ratio, provider,
	 * model (optionnels — les défauts viennent des réglages).
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function generate_for_cmd($request)
	{
		$post_id = (int) $request->get_param('post_id');
		$post = $post_id > 0 ? get_post($post_id) : null;

		if (!$post || !in_array($post->post_type, AiImages::POST_TYPES, true)) {
			return new \WP_REST_Response([
				'success' => false,
				'code'    => 'ai_images_no_post',
				'message' => 'Contenu introuvable ou type non pris en charge (post, page).',
			], 400);
		}

		$result = Generator::generate_for_post($post_id, [
			'prompt'       => (string) $request->get_param('prompt'),
			'target'       => (string) $request->get_param('target'),
			'aspect_ratio' => (string) $request->get_param('aspect_ratio'),
			'provider'     => (string) $request->get_param('provider'),
			'model'        => (string) $request->get_param('model'),
		]);

		if (is_wp_error($result)) {
			$status = $result->get_error_code() === 'ai_images_no_provider' ? 400 : 502;

			return new \WP_REST_Response([
				'success' => false,
				'code'    => $result->get_error_code(),
				'message' => $result->get_error_message(),
			], $status);
		}

		return new \WP_REST_Response([
			'success'       => true,
			'post_id'       => $post_id,
			'attachment_id' => $result['attachment_id'],
			'url'           => $result['url'],
			'target'        => $result['target'],
			'provider'      => $result['provider'],
			'model'         => $result['model'],
		], 200);
	}

	/**
	 * Vérifie les permissions pour l'API REST
	 *
	 * @param \WP_REST_Request $request
	 * @return bool
	 */
	public static function check_permissions($request)
	{
		// Génération facturée à l'appel : réservé aux administrateurs
		// (WP Command Center s'authentifie via Application Password admin).
		return current_user_can('manage_options');
	}
}
