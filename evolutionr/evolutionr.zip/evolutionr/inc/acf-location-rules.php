<?php
/**
 * Règles de localisation ACF custom.
 *
 * Ajoute la règle `page_slug` qui permet de cibler une page WordPress
 * par son slug (post_name) plutôt que par son ID. Plus robuste pour les
 * pages créées par seeder où l'ID dépend de l'ordre d'insertion.
 *
 * Utilisation dans une déclaration de groupe :
 *
 *     'location' => [[
 *         ['param' => 'page_slug', 'operator' => '==', 'value' => 'creation-site-internet'],
 *     ]],
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('evolutionr_acf_is_active') || !evolutionr_acf_is_active()) {
    return;
}

/**
 * Ajoute « Page slug » au groupe « Page » dans la liste des règles de location.
 */
add_filter('acf/location/rule_types', function ($rules) {
    $rules['Page']['page_slug'] = __('Page slug', 'evolutionr');
    return $rules;
});

/**
 * Liste les valeurs disponibles pour le sélecteur ACF (admin).
 * En déclaration code via acf_add_local_field_group(), on peut utiliser
 * n'importe quel slug — ce filtre sert au cas où on déclare le groupe
 * en GUI.
 */
add_filter('acf/location/rule_values/page_slug', function ($choices) {
    $pages = get_posts([
        'post_type'      => 'page',
        'post_status'    => ['publish', 'draft', 'private'],
        'posts_per_page' => -1,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ]);

    $choices = [];
    foreach ($pages as $page) {
        $choices[$page->post_name] = $page->post_title . ' (' . $page->post_name . ')';
    }

    return $choices;
});

/**
 * Détermine si le groupe doit s'afficher pour le post courant.
 *
 * @param bool  $match   Résultat actuel.
 * @param array $rule    ['param' => 'page_slug', 'operator' => '==', 'value' => '<slug>']
 * @param array $options Contexte (post_id, post_type, etc.).
 * @return bool
 */
add_filter('acf/location/rule_match/page_slug', function ($match, $rule, $options) {
    $post_id = $options['post_id'] ?? 0;
    if (!$post_id) {
        return false;
    }

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'page') {
        return false;
    }

    $match = ($post->post_name === $rule['value']);

    if (($rule['operator'] ?? '==') === '!=') {
        $match = !$match;
    }

    return $match;
}, 10, 3);
