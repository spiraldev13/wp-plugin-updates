<?php

declare(strict_types=1);

namespace SpiralBase\Modules\PageSitemapHtml;

use SpiralBase\Core\Options;

/**
 * Rendu du plan de site HTML (story 2.9) : arborescence des CONTENUS
 * PUBLICS — pages publiées en hiérarchie, articles groupés par catégorie,
 * CPT publics non natifs. Les contenus protégés par mot de passe ne sont
 * JAMAIS listés. Échappement au point de sortie, aucun chemin fatal
 * (toute exception → chaîne vide + signal NFR13).
 */
final class PlanDeSite
{
    /** Un plan de site n'est pas un annuaire infini : borne dure par type. */
    private const LIMITE_PAR_TYPE = 200;

    public function __construct(private readonly Options $options)
    {
    }

    public function rendre(): string
    {
        try {
            return $this->arborescence();
        } catch (\Throwable $e) {
            do_action('spiralbase_plan_site_echec', $e->getMessage());

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[spiralbase] plan de site : ' . $e->getMessage());
            }

            return '';
        }
    }

    private function arborescence(): string
    {
        $exclus   = $this->typesExclus();
        $sections = '';

        if (!in_array('page', $exclus, true)) {
            $sections .= $this->section(__('Pages', 'spiralbase'), $this->listePagesHierarchique());
        }

        if (!in_array('post', $exclus, true)) {
            $sections .= $this->section(__('Articles', 'spiralbase'), $this->listeArticlesParCategorie());
        }

        foreach (get_post_types(['public' => true, '_builtin' => false], 'names') as $type) {
            $type = (string) $type;

            if (in_array($type, $exclus, true)) {
                continue;
            }

            /* Le libellé ENREGISTRÉ du type prime (revue 2.9 : ucfirst sur
               un slug n'est ni traduit ni sûr en multioctet). */
            $objetType = get_post_type_object($type);
            $libelle   = trim((string) ($objetType->labels->name ?? '')) !== '' ? (string) $objetType->labels->name : ucfirst($type);

            $sections .= $this->section($libelle, $this->listePlate($type));
        }

        if ($sections === '') {
            return '';
        }

        return '<div class="spiralbase-plan-site">' . $sections . '</div>';
    }

    private function section(string $titre, string $items): string
    {
        if ($items === '') {
            return '';
        }

        return '<section class="spiralbase-plan-site__section">'
            . '<h2 class="spiralbase-plan-site__titre">' . esc_html($titre) . '</h2>'
            . '<ul class="spiralbase-plan-site__liste">' . $items . '</ul>'
            . '</section>';
    }

    private function listePagesHierarchique(): string
    {
        $pages   = $this->publies('page');
        $ids     = array_map(static fn (object $p): int => (int) ($p->ID ?? 0), $pages);
        $enfants = [];

        foreach ($pages as $page) {
            $parent = (int) ($page->post_parent ?? 0);

            /* Revue 2.9 : un parent EXCLU (protégé, hors limite, non publié)
               escamotait tout son sous-arbre — l'orphelin public est
               rattaché à la racine au lieu de disparaître. */
            $enfants[in_array($parent, $ids, true) ? $parent : 0][] = $page;
        }

        return $this->branche($enfants, 0, 1, $this->profondeurPages());
    }

    /** @param array<int, list<object>> $enfants */
    private function branche(array $enfants, int $parent, int $niveau, int $profondeurMax): string
    {
        if ($profondeurMax > 0 && $niveau > $profondeurMax) {
            return '';
        }

        $items = '';

        foreach ($enfants[$parent] ?? [] as $page) {
            $lien      = $this->lien($page);
            $sousArbre = $this->branche($enfants, (int) ($page->ID ?? 0), $niveau + 1, $profondeurMax);

            /* Page sans lien rendable (titre vide…) : ses ENFANTS remontent
               à ce niveau au lieu d'être escamotés avec elle (revue 2.9). */
            if ($lien === '') {
                $items .= $sousArbre;

                continue;
            }

            $items .= '<li class="spiralbase-plan-site__item">' . $lien
                . ($sousArbre !== '' ? '<ul class="spiralbase-plan-site__sous-liste">' . $sousArbre . '</ul>' : '')
                . '</li>';
        }

        return $items;
    }

    private function listeArticlesParCategorie(): string
    {
        /* Clé = term_id (revue 2.9 : le nom fusionnait des catégories
           homonymes, et un nom numérique casté en int fatalisait esc_html). */
        $parCategorie  = [];
        $sansCategorie = '';

        foreach ($this->publies('post') as $article) {
            $lien = $this->lien($article);

            if ($lien === '') {
                continue;
            }

            $item       = '<li class="spiralbase-plan-site__item">' . $lien . '</li>';
            $categories = (array) get_the_category((int) ($article->ID ?? 0));

            if ($categories === []) {
                $sansCategorie .= $item;

                continue;
            }

            foreach ($categories as $categorie) {
                if (!is_object($categorie) || trim((string) ($categorie->name ?? '')) === '') {
                    continue;
                }

                $id = (int) ($categorie->term_id ?? 0);
                $parCategorie[$id] ??= ['nom' => (string) $categorie->name, 'items' => ''];
                $parCategorie[$id]['items'] .= $item;
            }
        }

        $items = '';

        foreach ($parCategorie as $groupe) {
            $items .= '<li class="spiralbase-plan-site__categorie"><strong>' . esc_html($groupe['nom']) . '</strong>'
                . '<ul class="spiralbase-plan-site__sous-liste">' . $groupe['items'] . '</ul></li>';
        }

        return $items . $sansCategorie;
    }

    private function listePlate(string $type): string
    {
        $items = '';

        foreach ($this->publies($type) as $contenu) {
            $lien = $this->lien($contenu);

            if ($lien !== '') {
                $items .= '<li class="spiralbase-plan-site__item">' . $lien . '</li>';
            }
        }

        return $items;
    }

    /** @return list<object> publiés, jamais protégés par mot de passe */
    private function publies(string $type): array
    {
        $contenus = get_posts([
            'post_type'              => $type,
            'post_status'            => 'publish',
            'numberposts'            => self::LIMITE_PAR_TYPE,
            'no_found_rows'          => true,
            'orderby'                => $type === 'page' ? 'menu_order' : 'date',
            'order'                  => $type === 'page' ? 'ASC' : 'DESC',
            /* Les filtres SQL des tiers (multilingue…) doivent s'appliquer (leçon 2.7). */
            'suppress_filters'       => false,
            'update_post_meta_cache' => false,
            /* Les articles lisent leurs catégories juste après : le cache de
               termes se prime en UNE requête (revue 2.9 : N+1 sinon). */
            'update_post_term_cache' => $type === 'post',
        ]);

        return array_values(array_filter(
            is_array($contenus) ? $contenus : [],
            static fn ($c): bool => is_object($c) && trim((string) ($c->post_password ?? '')) === ''
        ));
    }

    private function lien(object $contenu): string
    {
        $permalien = get_permalink((int) ($contenu->ID ?? 0));
        $titre     = trim((string) ($contenu->post_title ?? ''));

        if (!is_string($permalien) || $permalien === '' || $titre === '') {
            return '';
        }

        return '<a href="' . esc_url($permalien) . '">' . esc_html($titre) . '</a>';
    }

    private function profondeurPages(): int
    {
        $reglages   = $this->options->get(PageSitemapHtmlModule::OPTION, []);
        $profondeur = is_array($reglages) && is_numeric($reglages['profondeur_pages'] ?? null) ? (int) $reglages['profondeur_pages'] : 0;

        return max(0, $profondeur);
    }

    /** @return list<string> */
    private function typesExclus(): array
    {
        $reglages = $this->options->get(PageSitemapHtmlModule::OPTION, []);
        $exclus   = is_array($reglages) && is_array($reglages['types_exclus'] ?? null) ? $reglages['types_exclus'] : [];

        return array_values(array_filter($exclus, 'is_string'));
    }
}
