<?php

/*
 * Manifeste d'asset ÉCRIT À LA MAIN (pas de build — AD-12, pattern 2.9/3.1).
 * Sans lui, WordPress chargerait le script sans ses dépendances et
 * window.wp.blocks serait indéfini dans l'éditeur.
 *
 * La version suit celle du THÈME, jamais un numéro figé : le cœur en fait le
 * `?ver=` du script (`wp-includes/blocks.php` — `$script_asset['version']`
 * l'emporte sur la version du bloc). Gelée, une correction livrée par une
 * release de la flotte continuerait d'être servie depuis le cache des
 * navigateurs et des CDN (revue 3.1, garde-fou testé : AssetsBlocsTest).
 *
 * `wp-server-side-render` est absent volontairement : l'aperçu de la carte
 * est l'édition native, pas un rendu serveur — l'API de rendu de bloc ne
 * reçoit pas les blocs enfants et afficherait une carte vide.
 */
return [
    'dependencies' => ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n'],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
