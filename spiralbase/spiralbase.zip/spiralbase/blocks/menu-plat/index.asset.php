<?php

/*
 * Manifeste d'asset ÉCRIT À LA MAIN (pas de build — AD-12, pattern 2.9/3.1).
 * Sans lui, WordPress chargerait le script sans ses dépendances et
 * window.wp.blocks serait indéfini dans l'éditeur.
 *
 * La version suit celle du THÈME, jamais un numéro figé : le cœur en fait le
 * `?ver=` du script (`wp-includes/blocks.php` — `$script_asset['version']`
 * l'emporte sur la version du bloc). Gelée, une correction livrée par une
 * release de la flotte continuerait d'être servie depuis le cache des
 * navigateurs et des CDN (revue 3.1, garde-fou testé : AssetsBlocsTest).
 *
 * Ni `wp-components` ni `wp-server-side-render` : ce bloc n'a aucun réglage
 * d'inspecteur (sa mise en forme vient du contexte du parent) et son aperçu
 * est l'édition native. Une dépendance déclarée pour rien serait un paquet
 * chargé pour rien sur chaque écran d'édition de la flotte.
 */
return [
    'dependencies' => ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-i18n'],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
