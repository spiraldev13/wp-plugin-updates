<?php

declare(strict_types=1);

namespace SpiralBase\Modules\PerfFontsLocales;

use SpiralBase\Core\FlyingPress;
use SpiralBase\Core\Module;
use SpiralBase\Core\SondeCession;

/**
 * Garant « aucun appel Google Fonts » (CAP-15, AC 3 story 2.4) : les
 * polices theme.json d'un block theme sont locales PAR CONSTRUCTION
 * (fichiers du thème, AD-5) — le levier du module bloque les feuilles
 * `fonts.googleapis.com`/`fonts.gstatic.com` enfilées par des tiers au
 * FRONT, resource hints compris. Les écrans d'admin ne sont pas touchés
 * (des plugins en dépendent) mais les fragments front servis par
 * admin-ajax.php le sont (revue 2.4 : `is_admin()` mesure le point
 * d'entrée, pas la destination).
 *
 * Effet de bord assumé du cœur (`WP_Styles::do_item` : href vide = balise
 * ET inline sautés) : un `wp_add_inline_style` attaché à un handle Google
 * bloqué disparaît avec lui.
 */
final class PerfFontsLocalesModule implements Module
{
    private const HOTES_BLOQUES = ['fonts.googleapis.com', 'fonts.gstatic.com'];

    private bool $logEmis = false;

    /** @param \Closure():bool|null $faitFontsFlyingPress fait injectable pour les tests */
    public function __construct(private readonly ?\Closure $faitFontsFlyingPress = null)
    {
    }

    public function slug(): string
    {
        return 'perf_fonts_locales';
    }

    public function boot(): void
    {
        if (!is_admin() || wp_doing_ajax()) {
            add_filter('style_loader_src', [$this, 'filtrerSrc'], 100, 2);
            /* Vérifié sur le WP réel : le cœur émet un dns-prefetch pour les
               feuilles ENREGISTRÉES même supprimées du rendu — « aucun
               appel » couvre aussi les resource hints. */
            add_filter('wp_resource_hints', [$this, 'filtrerIndices'], 100);
        }
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitFontsFlyingPress ?? static fn (): bool => FlyingPress::levierActif('optimize_google_fonts'),
            static fn (): string => __('Polices réellement optimisées par FlyingPress.', 'spiralbase')
        );
    }

    /**
     * Frontière de filtre public : TOUT paramètre en `mixed` (un tiers qui
     * ré-applique le filtre avec un handle null/array fatalerait sinon —
     * prouvé en revue 2.4).
     *
     * @return mixed false = feuille supprimée ; sinon src inchangé
     */
    public function filtrerSrc(mixed $src, mixed $handle = ''): mixed
    {
        if (!is_string($src) || trim($src) === '' || !$this->estHoteBloque($src)) {
            return $src;
        }

        $handle = is_string($handle) ? $handle : '(handle hors contrat)';

        /* Le tableau de bord (6.x) a besoin de CHAQUE handle bloqué : hook
           par blocage ; seul le log est borné par requête (NFR13). */
        do_action('spiralbase_fonts_google_bloquees', $handle);

        if (!$this->logEmis && defined('WP_DEBUG') && WP_DEBUG) {
            $this->logEmis = true;
            error_log(sprintf('[spiralbase] perf_fonts_locales : feuille(s) Google Fonts bloquée(s) au front (première : « %s »).', $handle));
        }

        return false;
    }

    /**
     * @param mixed $urls indices de préchargement (filtre public)
     *
     * @return mixed les indices sans les hôtes bloqués — clés des tiers
     *               préservées (un garant retire SES hôtes, ne reformate pas)
     */
    public function filtrerIndices(mixed $urls): mixed
    {
        if (!is_array($urls)) {
            return $urls;
        }

        return array_filter($urls, function (mixed $url): bool {
            $brut = is_array($url) ? ($url['href'] ?? null) : $url;

            if (!is_string($brut)) {
                /* href non-string : le cœur fatalerait dessus (esc_url sur
                   un tableau) — on retire l'indice malformé, par protection. */
                return !is_array($url);
            }

            return !$this->estHoteBloque($brut);
        });
    }

    /**
     * Extraction d'hôte robuste aux formes réelles (revue 2.4, prouvées) :
     * URL sans schéma avec chemin, espaces parasites, FQDN à point final,
     * hôtes nus des dns-prefetch.
     */
    private function estHoteBloque(string $brut): bool
    {
        $brut = trim($brut);
        $hote = (string) parse_url($brut, PHP_URL_HOST);

        if ($hote === '') {
            $hote = (string) parse_url('https://' . ltrim($brut, '/'), PHP_URL_HOST);
        }

        return in_array(rtrim(strtolower($hote), '.'), self::HOTES_BLOQUES, true);
    }
}
