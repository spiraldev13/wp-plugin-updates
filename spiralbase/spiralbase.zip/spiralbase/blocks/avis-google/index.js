/**
 * Bloc spiralbase/avis-google — JS éditeur écrit à la main, SANS build
 * (AD-12 : l'artefact livré EST ce fichier).
 *
 * Bloc 100 % dynamique sans enfants : `save()` rend null, tout le HTML vient
 * du serveur, qui lit le cache et jamais l'API.
 *
 * L'aperçu passe par ServerSideRender : l'opérateur voit ses VRAIS avis dans
 * l'éditeur — et voit donc immédiatement si le cache est vide, ce qu'un
 * aperçu inventé lui cacherait jusqu'à la mise en ligne. Repli statique si le
 * paquet manque : jamais d'éditeur cassé pour une dépendance absente.
 */
( function ( blocks, element, blockEditor, components, i18n, serverSideRender ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    function apercu( props ) {
        var Rendu = serverSideRender && ( serverSideRender.default || serverSideRender );

        if ( typeof Rendu === 'function' ) {
            return e( Rendu, {
                block: 'spiralbase/avis-google',
                attributes: props.attributes,
                EmptyResponsePlaceholder: function () {
                    return e(
                        'p',
                        { style: { margin: 0, opacity: 0.8 } },
                        __(
                            'Aucun avis en cache. Renseignez l’identifiant de l’établissement et la clé d’API, puis lancez « wp spiralbase avis rafraichir ».',
                            'spiralbase'
                        )
                    );
                },
            } );
        }

        return e(
            'p',
            { style: { margin: 0, opacity: 0.8 } },
            __( 'Les avis Google sont rendus sur le front.', 'spiralbase' )
        );
    }

    blocks.registerBlockType( 'spiralbase/avis-google', {
        edit: function ( props ) {
            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-avis-google-apercu',
                style: {
                    border: '1px dashed currentColor',
                    borderRadius: '4px',
                    opacity: 0.9,
                    padding: '1em',
                },
            } );

            return e(
                'div',
                blockProps,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages des avis', 'spiralbase' ) },
                        e( components.RangeControl, {
                            label: __( 'Nombre d’avis affichés', 'spiralbase' ),
                            min: 1,
                            max: 5,
                            value: props.attributes.nombre,
                            onChange: function ( valeur ) {
                                props.setAttributes( { nombre: parseInt( valeur, 10 ) || 1 } );
                            },
                        } ),
                        e( components.RangeControl, {
                            label: __( 'Note minimale affichée', 'spiralbase' ),
                            help: __(
                                'La note globale et le nombre total d’avis restent ceux de Google : ce filtre ne change que les témoignages montrés.',
                                'spiralbase'
                            ),
                            min: 0,
                            max: 5,
                            value: props.attributes.noteMinimale,
                            onChange: function ( valeur ) {
                                props.setAttributes( { noteMinimale: parseInt( valeur, 10 ) || 0 } );
                            },
                        } ),
                        e( components.ToggleControl, {
                            label: __( 'Afficher la note globale', 'spiralbase' ),
                            checked: !! props.attributes.afficherNote,
                            onChange: function ( valeur ) {
                                props.setAttributes( { afficherNote: !! valeur } );
                            },
                        } )
                    )
                ),
                e( 'strong', null, __( 'Avis Google', 'spiralbase' ) ),
                e( 'div', { style: { marginTop: '0.5em' } }, apercu( props ) )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n,
    window.wp.serverSideRender
);
