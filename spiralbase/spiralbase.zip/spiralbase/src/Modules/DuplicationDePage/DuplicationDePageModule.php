<?php

declare(strict_types=1);

namespace SpiralBase\Modules\DuplicationDePage;

use SpiralBase\Core\Module;
use SpiralBase\Core\SondeCession;

/**
 * Duplication de contenus (CAP-9, story 2.9) — action « Dupliquer » dans
 * les listes d'admin (articles et pages) : un clic crée un BROUILLON copie
 * conforme (contenu, réglages, taxonomies, metas hors liste noire). Statut
 * `draft` TOUJOURS — le plugin absorbé en fait une option
 * (`duplicate_page_options[duplicate_post_status]`, duplicatepage.php:61),
 * divergence assumée : un duplicata publié d'un clic est un risque, pas
 * une feature. Interrupteur OFF ⇒ boot() jamais appelé ⇒ action ABSENTE.
 *
 * Sonde (faits LUS dans le plugin réel duplicate-page) : cède quand le
 * plugin est réellement actif — classe unique `duplicate_page`
 * (duplicatepage.php:19, instanciée :438, hooks row_actions :32-33).
 */
final class DuplicationDePageModule implements Module
{
    private const TYPES = ['post', 'page'];

    /**
     * Verrous d'édition (aucun sens sur une copie neuve) et slugs
     * historiques (revue 2.9 : `_wp_old_slug` copié rendait les
     * redirections d'anciens permaliens non déterministes).
     */
    private const META_LISTE_NOIRE = ['_edit_lock', '_edit_last', '_wp_old_slug', '_wp_desired_post_slug'];

    /** @return list<string> */
    private function metasNonDuplicables(): array
    {
        $metas = apply_filters('spiralbase_metas_non_duplicables', self::META_LISTE_NOIRE);

        return array_values(array_filter(is_array($metas) ? $metas : self::META_LISTE_NOIRE, 'is_string'));
    }

    /** @param \Closure():bool|null $faitDuplicatePage fait injectable pour les tests */
    public function __construct(private readonly ?\Closure $faitDuplicatePage = null)
    {
    }

    public function slug(): string
    {
        return 'duplication_de_page';
    }

    public function boot(): void
    {
        $ajouter = fn (array $actions, object $post): array => $this->ajouterAction($actions, $post);

        add_filter('post_row_actions', $ajouter, 10, 2);
        add_filter('page_row_actions', $ajouter, 10, 2);

        add_action('admin_action_spiralbase_dupliquer', function (): void {
            $type = (string) (get_post($this->idRequete())?->post_type ?? 'post');
            $this->dupliquer();

            wp_safe_redirect(admin_url('edit.php' . ($type === 'page' ? '?post_type=page' : '')));
            exit;
        });
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitDuplicatePage ?? static fn (): bool => class_exists('duplicate_page', false),
            static fn (): string => __('Duplication réellement assurée par Duplicate Page.', 'spiralbase')
        );
    }

    /**
     * Crée le brouillon copie conforme depuis la requête d'admin courante.
     * Tout refus passe par wp_die (le cœur interrompt) — nonce PAR post,
     * capacité vérifiée, type borné, jamais de création partielle signalée
     * comme succès.
     */
    public function dupliquer(): int
    {
        $id = $this->idRequete();

        if (wp_verify_nonce((string) ($_GET['_wpnonce'] ?? ''), 'spiralbase_dupliquer_' . $id) === false) {
            wp_die(__('Vérification de sécurité échouée.', 'spiralbase'));
        }

        if ($id === 0 || !current_user_can('edit_post', $id)) {
            wp_die(__('Droits insuffisants pour dupliquer ce contenu.', 'spiralbase'));
        }

        $post = get_post($id);

        if (!is_object($post) || !in_array((string) ($post->post_type ?? ''), self::TYPES, true)) {
            wp_die(__('Contenu introuvable ou non duplicable.', 'spiralbase'));
        }

        /* wp_slash OBLIGATOIRE (revue 2.9, prouvé sur le cœur : wp_insert_post
           wp_unslash inconditionnellement — sans lui, tout antislash du
           contenu original disparaît de la copie). */
        $nouveau = wp_insert_post(wp_slash([
            'post_title'     => (string) ($post->post_title ?? ''),
            'post_content'   => (string) ($post->post_content ?? ''),
            'post_excerpt'   => (string) ($post->post_excerpt ?? ''),
            'post_type'      => (string) $post->post_type,
            'post_status'    => 'draft',
            'post_author'    => get_current_user_id(),
            'comment_status' => (string) ($post->comment_status ?? ''),
            'ping_status'    => (string) ($post->ping_status ?? ''),
            'post_parent'    => (int) ($post->post_parent ?? 0),
            'menu_order'     => (int) ($post->menu_order ?? 0),
            'post_password'  => (string) ($post->post_password ?? ''),
        ]), true);

        if (is_wp_error($nouveau) || (int) $nouveau === 0) {
            wp_die(__('La duplication a échoué.', 'spiralbase'));
        }

        $nouveau = (int) $nouveau;
        $this->copierTaxonomies($id, $nouveau, (string) $post->post_type);
        $this->copierMetas($id, $nouveau);

        return $nouveau;
    }

    private function copierTaxonomies(int $source, int $copie, string $type): void
    {
        foreach (get_object_taxonomies($type) as $taxonomie) {
            $termes = wp_get_object_terms($source, (string) $taxonomie, ['fields' => 'ids']);

            /* Une taxonomie en erreur ne fatalise pas la copie, mais la
               perte est SIGNALÉE (NFR13) — jamais muette. */
            if (is_wp_error($termes)) {
                $this->signaler(sprintf('taxonomie « %s » non copiée : %s', (string) $taxonomie, $termes->get_error_message()));

                continue;
            }

            if (is_array($termes) && $termes !== []) {
                wp_set_object_terms($copie, $termes, (string) $taxonomie);
            }
        }
    }

    private function copierMetas(int $source, int $copie): void
    {
        foreach (get_post_meta($source) as $cle => $valeurs) {
            $cle = (string) $cle;

            /*
             * La liste noire est OUVERTE : un marqueur de portée SITE ne se
             * duplique pas avec un article. Sans ce filtre, dupliquer un
             * article mis en avant (3.7) créait un second article mis en
             * avant, au même rang, dès la publication du brouillon — une une
             * réordonnée sans que personne n'ait cliqué. Le prochain module
             * qui posera un marqueur de ce genre n'aura pas à repayer.
             */
            if (in_array($cle, $this->metasNonDuplicables(), true)) {
                continue;
            }

            foreach ((array) $valeurs as $brut) {
                /* Un objet sérialisé n'est JAMAIS copié (object injection,
                   même défense que le plugin absorbé duplicatepage.php:214-228),
                   y compris IMBRIQUÉ dans un tableau sérialisé. Un texte brut
                   contenant « O:8: » n'est PAS du sérialisé : il passe
                   (revue 2.9). Le `\+?` couvre la variante `O:+8:` tolérée
                   par unserialize. */
                if ($this->porteUnObjetSerialise($brut)) {
                    continue;
                }

                add_post_meta($copie, $cle, maybe_unserialize($brut));
            }
        }
    }

    private function porteUnObjetSerialise(mixed $brut): bool
    {
        if (!is_string($brut)) {
            return false;
        }

        $valeur = trim($brut);

        return preg_match('/^(?:[aOsC]|N;)[:;]?/', $valeur) === 1
            && str_contains($valeur, ':')
            && preg_match('/(?:^|[;{])[OC]:\+?\d+:"/', $valeur) === 1;
    }

    /** L'id de la requête d'admin courante — jamais un tableau casté en 1. */
    private function idRequete(): int
    {
        $brut = $_GET['post'] ?? 0;

        return is_scalar($brut) ? (int) $brut : 0;
    }

    /** NFR13 : signal systématique + trace sous WP_DEBUG, jamais de fatal. */
    private function signaler(string $detail): void
    {
        do_action('spiralbase_duplication_ignore', $detail);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] duplication : ' . $detail);
        }
    }

    /** @param array<string, string> $actions */
    private function ajouterAction(array $actions, object $post): array
    {
        $id = (int) ($post->ID ?? 0);

        if ($id === 0
            || !in_array((string) ($post->post_type ?? ''), self::TYPES, true)
            || !current_user_can('edit_post', $id)
        ) {
            return $actions;
        }

        $url = admin_url(
            'admin.php?action=spiralbase_dupliquer&post=' . $id
            . '&_wpnonce=' . wp_create_nonce('spiralbase_dupliquer_' . $id)
        );

        $actions['spiralbase_dupliquer'] = '<a href="' . esc_url($url) . '">'
            . esc_html__('Dupliquer', 'spiralbase') . '</a>';

        return $actions;
    }
}
