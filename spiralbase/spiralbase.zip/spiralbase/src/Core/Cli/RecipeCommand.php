<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\RecipeStore;

/**
 * `wp spiralbase recipe` — coquille CLI : parse l'entrée, délègue TOUT au
 * RecipeStore (porte unique, juge unique). Aucune logique de validation
 * ici. Messages CLI non traduits (convention WP-CLI), en français simple.
 */
final class RecipeCommand
{
    public function __construct(private readonly RecipeStore $store)
    {
    }

    /**
     * Applique une recette depuis un fichier JSON.
     *
     * ## OPTIONS
     *
     * --file=<chemin>
     * : Fichier JSON de la recette.
     *
     * @param array<int, string> $args
     * @param array<string, string> $assocArgs
     */
    public function apply(array $args, array $assocArgs): void
    {
        $fichier = (string) ($assocArgs['file'] ?? '');

        if ($fichier === '' || !is_file($fichier)) {
            \WP_CLI::error(sprintf('Fichier de recette introuvable : « %s ».', $fichier));

            return;
        }

        if (!is_readable($fichier)) {
            \WP_CLI::error(sprintf('Fichier non lisible (permissions) : « %s ».', $fichier));

            return;
        }

        $brut = file_get_contents($fichier);

        if ($brut === false) {
            \WP_CLI::error(sprintf('Échec de lecture (I/O) : « %s ».', $fichier));

            return;
        }

        $recette = json_decode($brut, true);

        if (!is_array($recette)) {
            \WP_CLI::error(sprintf('JSON illisible : « %s ».', $fichier));

            return;
        }

        $verdict = $this->store->apply($recette);

        if ($verdict !== true) {
            \WP_CLI::error($verdict->get_error_message());

            return;
        }

        \WP_CLI::success('Recette appliquée et persistée.');
    }

    /**
     * Affiche la recette courante (migrée vers la version courante).
     *
     * @param array<int, string> $args
     * @param array<string, string> $assocArgs
     */
    public function get(array $args, array $assocArgs): void
    {
        $recette = $this->store->get();

        if ($recette === null) {
            if ($this->store->existe()) {
                \WP_CLI::error('Une recette existe mais est illisible (version future ou données corrompues) — voir les signaux spiralbase_recette_*.');

                return;
            }

            \WP_CLI::log('Aucune recette appliquée sur ce site.');

            return;
        }

        $json = json_encode($recette, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($json === false) {
            \WP_CLI::error('Recette non sérialisable en JSON : ' . json_last_error_msg());

            return;
        }

        \WP_CLI::log($json);
    }
}
