<?php

declare(strict_types=1);

namespace SpiralBase\Modules\RgpdConsentement;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;

/**
 * Bandeau de consentement natif (CAP-15, AC 1-2 story 2.5), ARCHITECTURE
 * CACHE-SAFE (revue 2.5) : la page servie est IDENTIQUE pour tous — les
 * traceurs déclarés sont neutralisés côté serveur sans condition, le
 * bandeau est toujours émis masqué, et c'est le JS côté client qui décide
 * (cookie accepte → réactive les traceurs ; refuse → rien ; absent →
 * affiche le bandeau). Un cache pleine page ne peut donc ni servir des
 * traceurs actifs à un visiteur sans accord, ni perdre un accord donné.
 *
 * PÉRIMÈTRE DOCUMENTÉ : seuls les scripts ENFILÉS (wp_enqueue_script)
 * déclarés dans `handles_traceurs` sont bloqués — leurs inline
 * before/after et translations compris. Les scripts imprimés en dur, les
 * iframes et les pixels sont HORS périmètre : pour ces besoins, CookieYes
 * (auquel ce module cède) est la voie riche.
 *
 * Aucun cookie n'est déposé avant le choix. Retrait du consentement
 * (art. 7.3 RGPD) : tout élément portant `data-spiralbase-rouvrir`
 * (lien « Gérer mes cookies » posé par l'opérateur) efface le choix et
 * ré-affiche le bandeau.
 */
final class RgpdConsentementModule implements Module
{
    public const OPTION = 'spiralbase_rgpd';

    public const COOKIE = 'spiralbase_consentement';

    /** Durée de conservation du choix — la politique générée (2.5) l'annonce en clair. */
    public const DUREE_JOURS = 182;

    /** @param \Closure():bool|null $faitCookieYes fait injectable pour les tests */
    public function __construct(
        private readonly Options $options,
        private readonly ?\Closure $faitCookieYes = null,
    ) {
    }

    public function slug(): string
    {
        return 'rgpd_consentement';
    }

    public function boot(): void
    {
        if (is_admin() && !wp_doing_ajax()) {
            return;
        }

        add_action('wp_footer', [$this, 'emettreBandeau'], 50);
        add_filter('script_loader_tag', [$this, 'filtrerScript'], 100, 3);
    }

    public function defaultSettings(): array
    {
        return ['handles_traceurs' => []];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        /* Fait COMPOSÉ (revue 2.5) : deux constantes CookieYes — un préfixe
           générique seul (CLI_) pouvait entrer en collision, et une cession
           à tort priverait le site de tout bandeau. */
        return SondeCession::surFait(
            $this->slug(),
            $this->faitCookieYes ?? static fn (): bool => defined('CLI_VERSION') && defined('CLI_PLUGIN_BASENAME'),
            static fn (): string => __('Bandeau de consentement réellement fourni par CookieYes.', 'spiralbase')
        );
    }

    public function emettreBandeau(): void
    {
        /* Un bandeau sans finalité est un mensonge : rien à consentir tant
           qu'aucun traceur n'est déclaré. */
        if ($this->traceurs() === []) {
            return;
        }

        try {
            echo $this->bandeau();
        } catch (\Throwable $e) {
            $this->signaler('bandeau abandonné — ' . $e->getMessage());
        }
    }

    /**
     * Neutralise TOUTES les balises script du tag (le cœur concatène
     * translations + inline before + script + inline after AVANT le filtre
     * — `WP_Scripts::do_item`, vérifié en revue 2.5) — sans condition de
     * cookie : c'est le client qui réactive (cache-safe).
     * Frontière de filtre public : tout en `mixed`.
     *
     * @return mixed le tag, neutralisé ou intact
     */
    public function filtrerScript(mixed $tag, mixed $handle = null, mixed $src = null): mixed
    {
        if (!is_string($tag) || !is_string($handle) || !in_array($handle, $this->traceurs(), true)) {
            return $tag;
        }

        $neutralise = preg_replace_callback(
            '/<script\b([^>]*)>/i',
            static function (array $m): string {
                /* Préserver un éventuel type d'origine (module…) pour la
                   réactivation — puis le retirer : la PREMIÈRE occurrence
                   d'un attribut gagne en HTML, text/plain doit être seule. */
                $attributs = $m[1];
                $typeOrigine = '';

                if (preg_match('/\stype\s*=\s*(["\']?)([^"\'\s>]*)\1/i', $attributs, $t)) {
                    $typeOrigine = $t[2];
                    $attributs   = (string) preg_replace('/\stype\s*=\s*(["\']?)[^"\'\s>]*\1/i', '', $attributs);
                }

                return '<script type="text/plain" data-spiralbase-consent="1"'
                    . ($typeOrigine !== '' && strtolower($typeOrigine) !== 'text/javascript' ? ' data-spiralbase-type="' . esc_attr($typeOrigine) . '"' : '')
                    . $attributs . '>';
            },
            $tag
        );

        if (!is_string($neutralise)) {
            /* Échec PCRE : fail-CLOSED côté vie privée (balise supprimée),
               jamais en silence. */
            $this->signaler(sprintf('neutralisation impossible pour « %s » — script retiré par prudence', $handle));

            return '';
        }

        return $neutralise;
    }

    /** @return list<string> handles déclarés — réglage corrompu = signal, jamais un fail-open muet */
    private function traceurs(): array
    {
        $reglages = $this->options->get(self::OPTION, []);

        if (!is_array($reglages)) {
            $this->signaler('réglage spiralbase_rgpd corrompu — aucun traceur bloqué');

            return [];
        }

        $traceurs = $reglages['handles_traceurs'] ?? [];

        return is_array($traceurs) ? array_values(array_filter($traceurs, 'is_string')) : [];
    }

    private function signaler(string $message): void
    {
        do_action('spiralbase_rgpd_echec', $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] rgpd_consentement : ' . $message . '.');
        }
    }

    /**
     * Bandeau autonome, ÉMIS MASQUÉ (cache-safe) : le JS l'affiche si aucun
     * choix, réactive les traceurs si accord — au chargement, pas seulement
     * au clic. Styles en bloc <style> à classes : un thème enfant surcharge
     * sans !important. Le JS n'interpole que des constantes du module.
     */
    private function bandeau(): string
    {
        $texte    = esc_html__('Ce site utilise des cookies de mesure d\'audience. Vous pouvez accepter ou refuser leur dépôt.', 'spiralbase');
        $accepter = esc_html__('Accepter', 'spiralbase');
        $refuser  = esc_html__('Refuser', 'spiralbase');
        $libelle  = esc_attr__('Consentement aux cookies', 'spiralbase');
        $cookie   = self::COOKIE;
        $maxAge   = self::DUREE_JOURS * 86400;
        $chemin   = defined('COOKIEPATH') && is_string(COOKIEPATH) && COOKIEPATH !== '' ? COOKIEPATH : '/';
        $secure   = function_exists('is_ssl') && is_ssl() ? ';Secure' : '';

        return <<<HTML
<style id="spiralbase-consentement-style">
.spiralbase-consentement{position:fixed;inset-inline:0;bottom:0;z-index:99999;background:#1e1e1e;color:#fff;padding:1rem;display:flex;flex-wrap:wrap;gap:.75rem;align-items:center;justify-content:center;font-size:.9375rem}
.spiralbase-consentement[hidden]{display:none}
.spiralbase-consentement p{margin:0}
.spiralbase-consentement button{cursor:pointer;padding:.5rem 1rem}
</style>
<div id="spiralbase-consentement" class="spiralbase-consentement" role="dialog" aria-label="{$libelle}" hidden>
  <p>{$texte}</p>
  <button type="button" data-spiralbase-choix="accepte">{$accepter}</button>
  <button type="button" data-spiralbase-choix="refuse">{$refuser}</button>
</div>
<script id="spiralbase-consentement-js">
(function () {
  var COOKIE = "{$cookie}", MAX_AGE = {$maxAge}, CHEMIN = "{$chemin}", SECURE = "{$secure}";
  var bandeau = document.getElementById("spiralbase-consentement");
  function choix() {
    var m = document.cookie.match(new RegExp("(?:^|; )" + COOKIE + "=(accepte|refuse)(?:;|$)"));
    return m ? m[1] : "";
  }
  function reactiver() {
    document.querySelectorAll('script[type="text/plain"][data-spiralbase-consent]').forEach(function (inerte) {
      var actif = document.createElement("script");
      for (var i = 0; i < inerte.attributes.length; i++) {
        var attr = inerte.attributes[i];
        if (attr.name === "type" || attr.name === "data-spiralbase-consent") { continue; }
        if (attr.name === "data-spiralbase-type") { actif.type = attr.value; continue; }
        actif.setAttribute(attr.name, attr.value);
      }
      if (actif.src) { actif.async = false; }
      actif.text = inerte.text;
      inerte.replaceWith(actif);
    });
  }
  function poser(valeur) {
    document.cookie = COOKIE + "=" + valeur + ";max-age=" + MAX_AGE + ";path=" + CHEMIN + ";SameSite=Lax" + SECURE;
  }
  if (bandeau) {
    var actuel = choix();
    if (actuel === "accepte") { reactiver(); }
    if (actuel === "") { bandeau.hidden = false; }
    bandeau.addEventListener("click", function (e) {
      var v = e.target && e.target.getAttribute("data-spiralbase-choix");
      if (!v) { return; }
      poser(v);
      bandeau.hidden = true;
      if (v === "accepte") { reactiver(); }
    });
  }
  document.addEventListener("click", function (e) {
    var cible = e.target && e.target.closest && e.target.closest("[data-spiralbase-rouvrir]");
    if (!cible || !bandeau) { return; }
    e.preventDefault();
    poser("");
    bandeau.hidden = false;
  });
})();
</script>
HTML;
    }
}
