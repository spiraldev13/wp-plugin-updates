/**
 * Bloc spiralbase/menu-plat — JS éditeur écrit à la main, SANS build.
 *
 * Trois champs de texte riche, aucun champ calculé : le prix reste du TEXTE
 * (« 12,50 € », « 12 € / 18 € », « selon arrivage »). Bloc dynamique sans
 * enfants : `save()` rend null, tout le HTML vient du serveur.
 */
( function ( blocks, element, blockEditor, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    /* Miroir de Core\TexteRiche::AUTORISE — ce que l'éditeur propose est
       exactement ce que le front affichera, sans surprise à la publication :
       gras (`strong`), italique (`em`), barré (`s`), indice, exposant. Ni
       lien ni couleur : le serveur ne les laisserait pas passer, et la barre
       d'outils ne doit pas promettre ce qui sera retiré à la publication. */
    var FORMATS = [
        'core/bold',
        'core/italic',
        'core/strikethrough',
        'core/subscript',
        'core/superscript',
    ];

    function champ( props, attribut, options ) {
        return e( blockEditor.RichText, {
            tagName: options.tagName,
            className: 'spiralbase-menu-plat__' + attribut,
            allowedFormats: FORMATS,
            value: props.attributes[ attribut ],
            placeholder: options.placeholder,
            onChange: function ( valeur ) {
                var maj = {};
                maj[ attribut ] = valeur;
                props.setAttributes( maj );
            },
        } );
    }

    blocks.registerBlockType( 'spiralbase/menu-plat', {
        edit: function ( props ) {
            var variante = ( props.context && props.context[ 'spiralbase/variante' ] ) || 'liste';

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-menu-plat spiralbase-menu-plat--' + variante,
            } );

            /* Même ordre que le rendu serveur : nom, prix, description. */
            return e(
                'div',
                blockProps,
                champ( props, 'nom', {
                    tagName: 'span',
                    placeholder: __( 'Nom du plat', 'spiralbase' ),
                } ),
                champ( props, 'prix', {
                    tagName: 'span',
                    placeholder: __( 'Prix', 'spiralbase' ),
                } ),
                champ( props, 'description', {
                    tagName: 'p',
                    placeholder: __( 'Description (facultative)', 'spiralbase' ),
                } )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.i18n
);
