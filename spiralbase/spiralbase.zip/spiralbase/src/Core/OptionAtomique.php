<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Écriture d'option réellement INDIVISIBLE — la primitive sur laquelle tout
 * verrou du parent repose.
 *
 * Rectification d'une prémisse fausse posée en story 3.3 et répétée depuis :
 * `add_option()` N'EST PAS atomique. Le cœur contrôle l'existence par une
 * LECTURE (`wp-includes/option.php:1117-1124`, court-circuitable par le cache
 * `notoptions`) puis écrit un `INSERT … ON DUPLICATE KEY UPDATE` (`:1140`) qui
 * ÉCRASE au lieu d'échouer. C'est exactement le motif lire-puis-écrire que ce
 * projet condamne depuis la revue 3.3 — avec une fenêtre plus courte, pas
 * absente. Prouvé en revue 3.9 : deux processus revendiquant le même marqueur
 * se voyaient tous deux répondre « succès ».
 *
 * Ce que le cœur ne fournit pas, le moteur de base de données le fournit :
 * `option_name` porte un index UNIQUE (schéma WordPress), donc un `INSERT`
 * NU — sans `ON DUPLICATE KEY UPDATE` — échoue pour le second concurrent, en
 * une seule instruction. `$wpdb->insert()` produit exactement cet INSERT nu.
 *
 * Aucun repli sur `add_option()` : un repli non atomique rendrait la garantie
 * dépendante de l'environnement, ce qui est pire qu'un refus franc. Sans base
 * de données, la revendication échoue (fail-closed).
 */
final class OptionAtomique
{
    /**
     * Insère l'option si — et seulement si — elle n'existe pas encore.
     *
     * @param bool|null $autoload passé au juge du cœur (`wp_determine_option_autoload_value`)
     *
     * @return bool true = c'est NOUS qui l'avons créée
     */
    public static function insererSiAbsent(string $nom, mixed $valeur, ?bool $autoload = false): bool
    {
        global $wpdb;

        if (!isset($wpdb) || !is_object($wpdb) || !method_exists($wpdb, 'insert')) {
            return false;
        }

        $serialise = maybe_serialize($valeur);
        $colonne   = function_exists('wp_determine_option_autoload_value')
            ? wp_determine_option_autoload_value($nom, $valeur, $serialise, $autoload)
            : ($autoload === true ? 'on' : 'off');

        /* Le doublon est un résultat ATTENDU, pas un incident à afficher. */
        $silencePrecedent = $wpdb->suppress_errors(true);
        $lignes           = $wpdb->insert(
            $wpdb->options,
            ['option_name' => $nom, 'option_value' => $serialise, 'autoload' => $colonne],
            ['%s', '%s', '%s']
        );
        $wpdb->suppress_errors($silencePrecedent);

        if (!$lignes) {
            return false;
        }

        self::rafraichirCache($nom, (string) $colonne);

        return true;
    }

    /**
     * Prend un verrou, ou rend false s'il est déjà tenu. Le verrou porte son
     * échéance ET son propriétaire : un processus tué laisse un verrou qui se
     * périme, et un retardataire ne peut pas relâcher celui d'un autre.
     */
    public static function prendreVerrou(string $nom, int $secondes, string $jeton): bool
    {
        $existant = get_option($nom, null);

        /* Verrou périmé (processus interrompu) : on le retire pour laisser
           l'INSERT suivant trancher — la course est reportée sur l'insertion,
           qui, elle, est indivisible. */
        if (is_array($existant) && (int) ($existant['expire'] ?? 0) <= time()) {
            delete_option($nom);
            $existant = null;
        }

        if ($existant !== null && $existant !== false) {
            return false;
        }

        return self::insererSiAbsent($nom, ['jeton' => $jeton, 'expire' => time() + $secondes], false);
    }

    /** Ne relâche que SON verrou : un retardataire ne libère pas celui d'un autre. */
    public static function relacherVerrou(string $nom, string $jeton): void
    {
        $existant = get_option($nom, null);

        if (is_array($existant) && ($existant['jeton'] ?? null) === $jeton) {
            delete_option($nom);
        }
    }

    /**
     * L'INSERT court-circuite les caches du cœur : sans cette remise à plat,
     * un `get_option()` ultérieur de LA MÊME requête servirait encore
     * « inexistante » depuis `notoptions` ou depuis `alloptions`.
     */
    private static function rafraichirCache(string $nom, string $colonne): void
    {
        if (!function_exists('wp_cache_delete')) {
            return;
        }

        wp_cache_delete($nom, 'options');

        $notoptions = wp_cache_get('notoptions', 'options');

        if (is_array($notoptions) && isset($notoptions[$nom])) {
            unset($notoptions[$nom]);
            wp_cache_set('notoptions', $notoptions, 'options');
        }

        $autoloades = function_exists('wp_autoload_values_to_autoload') ? wp_autoload_values_to_autoload() : ['on', 'yes', 'auto', 'auto-on'];

        if (in_array($colonne, $autoloades, true)) {
            wp_cache_delete('alloptions', 'options');
        }
    }
}
