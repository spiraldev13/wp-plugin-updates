<?php
/**
 * Formulaire de contact — bloc `techana/formulaire-contact` et traitement.
 *
 * L'adresse de destination ne figure jamais dans le HTML servi : elle vit côté
 * serveur, dans les réglages (Apparence → Formulaire de contact,
 * inc/formulaire-reglages.php) avec l'adresse affichée au lecteur — écrite avec
 * des crochets pour ne pas être moissonnée —, les délais et les messages.
 *
 * Aucun service tiers : la protection anti-robot tient en trois mesures
 * locales — champ leurre, délai minimal, limitation par adresse IP. Un captcha
 * externe ajouterait un traceur à déclarer dans le bandeau de cookies.
 *
 * Le formulaire se pose par le bloc `techana/formulaire-contact` ou par le code
 * court `[techana_contact]` : même rendu, même traitement.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'techanaRevueRegisterBlocFormulaire' );
add_action( 'template_redirect', 'techanaRevueTraiterFormulaire' );

function techanaRevueRegisterBlocFormulaire() {
    register_block_type( 'techana/formulaire-contact', array(
        'api_version'     => 3,
        'render_callback' => 'techanaRevueBlocFormulaire',
    ) );
    // Même rendu que le bloc, pour un contenu qui n'est pas en blocs.
    add_shortcode( 'techana_contact', 'techanaRevueBlocFormulaire' );
}

/**
 * État du dernier envoi, partagé entre le traitement (sur `template_redirect`)
 * et le rendu du bloc, qui vient après dans la même requête.
 *
 * @return array{etat: string, message: string, saisie: array<string, string>}
 */
function &techanaRevueEtatFormulaire(): array {
    static $etat = array( 'etat' => '', 'message' => '', 'saisie' => array() );
    return $etat;
}

/** Enregistre le résultat du traitement pour le rendu qui suit. */
function techanaRevuePoserEtatFormulaire( string $etat, string $message, array $saisie = array() ) {
    $courant = &techanaRevueEtatFormulaire();
    $courant = array( 'etat' => $etat, 'message' => $message, 'saisie' => $saisie );
}

/** Clé de limitation : une empreinte d'IP, jamais l'IP elle-même. */
function techanaRevueCleReposContact(): string {
    $ip = (string) ( $_SERVER['REMOTE_ADDR'] ?? '' );
    return 'techana_contact_' . md5( $ip . wp_salt() );
}

/**
 * Traite l'envoi avant tout rendu : un `wp_mail()` déclenché en plein rendu de
 * bloc empêcherait toute redirection et brouillerait les en-têtes.
 */
function techanaRevueTraiterFormulaire() {
    if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['techana_contact'] ) ) {
        return;
    }

    $nonce = sanitize_text_field( wp_unslash( $_POST['techana_contact_nonce'] ?? '' ) );
    if ( ! wp_verify_nonce( $nonce, 'techana-contact' ) ) {
        techanaRevuePoserEtatFormulaire( 'erreur', 'Votre session a expiré. Merci de renvoyer le message.' );
        return;
    }

    $reglages = techanaRevueReglagesContact();
    $refus    = techanaRevueRefusAntiRobot( $reglages );
    if ( $refus ) {
        techanaRevuePoserEtatFormulaire( $refus[0], $refus[1] );
        return;
    }

    $saisie = array(
        'nom'     => sanitize_text_field( wp_unslash( $_POST['techana_nom'] ?? '' ) ),
        'email'   => sanitize_email( wp_unslash( $_POST['techana_email'] ?? '' ) ),
        'sujet'   => sanitize_text_field( wp_unslash( $_POST['techana_sujet'] ?? '' ) ),
        'message' => sanitize_textarea_field( wp_unslash( $_POST['techana_message'] ?? '' ) ),
    );
    $consent = ! empty( $_POST['techana_consentement'] );

    $manques = array();
    if ( '' === $saisie['nom'] ) {
        $manques[] = 'votre nom';
    }
    if ( ! is_email( $saisie['email'] ) ) {
        $manques[] = 'une adresse e-mail valide';
    }
    if ( mb_strlen( $saisie['message'] ) < 10 ) {
        $manques[] = 'un message d’au moins dix caractères';
    }
    if ( ! $consent ) {
        $manques[] = 'votre accord sur le traitement de vos données';
    }
    if ( $manques ) {
        techanaRevuePoserEtatFormulaire(
            'erreur',
            'Il manque ' . implode( ', ', $manques ) . '.',
            $saisie
        );
        return;
    }

    // L'expéditeur reste le domaine du site : poser l'adresse du visiteur en
    // From ferait rejeter le message par SPF/DMARC. Il est joignable en réponse.
    $site    = wp_parse_url( home_url(), PHP_URL_HOST );
    $sujet   = '' !== $saisie['sujet'] ? $saisie['sujet'] : 'Message depuis le site';
    $entetes = array(
        'From: TechAna <no-reply@' . $site . '>',
        'Reply-To: ' . $saisie['nom'] . ' <' . $saisie['email'] . '>',
        'Content-Type: text/plain; charset=UTF-8',
    );
    $corps = sprintf(
        "Message envoyé depuis %s\n\nNom : %s\nE-mail : %s\nSujet : %s\n\n%s\n",
        home_url( '/contact/' ),
        $saisie['nom'],
        $saisie['email'],
        $sujet,
        $saisie['message']
    );

    // wp_mail() encode lui-même le sujet ; les retours à la ligne sont déjà
    // écartés par sanitize_text_field, ce qui ferme l'injection d'en-têtes.
    $envoye = wp_mail( $reglages['destinataire'], '[TechAna] ' . $sujet, $corps, $entetes );

    if ( ! $envoye ) {
        techanaRevuePoserEtatFormulaire(
            'erreur',
            str_replace( '%adresse%', $reglages['affichee'], $reglages['echec'] ),
            $saisie
        );
        return;
    }

    if ( $reglages['repos'] > 0 ) {
        set_transient( techanaRevueCleReposContact(), 1, $reglages['repos'] );
    }
    techanaRevuePoserEtatFormulaire( 'succes', $reglages['succes'] );
}

/**
 * Les trois garde-fous anti-robot, dans l'ordre. Un délai ou un repos réglé
 * à 0 désactive la mesure correspondante.
 *
 * @param array $reglages Réglages effectifs du formulaire.
 * @return array{0: string, 1: string}|null État et message du refus, null si l'envoi passe.
 */
function techanaRevueRefusAntiRobot( array $reglages ): ?array {
    // Champ leurre : invisible pour un lecteur, rempli par un robot qui remplit
    // tout. Refus silencieux — annoncer l'échec apprendrait au robot à l'éviter,
    // et le faux succès est le vrai message pour qu'il ne se distingue pas.
    if ( '' !== trim( (string) wp_unslash( $_POST['techana_site'] ?? '' ) ) ) {
        return array( 'succes', $reglages['succes'] );
    }

    $ouverture = (int) ( $_POST['techana_ouverture'] ?? 0 );
    if ( $reglages['delai_min'] > 0 && $ouverture && ( time() - $ouverture ) < $reglages['delai_min'] ) {
        return array( 'erreur', 'Message envoyé trop vite pour être lu : merci de réessayer.' );
    }

    if ( $reglages['repos'] > 0 && get_transient( techanaRevueCleReposContact() ) ) {
        return array( 'erreur', 'Un message vient d’être envoyé depuis cette connexion. Merci de patienter quelques minutes.' );
    }

    return null;
}

/** Champ de saisie du formulaire. */
function techanaRevueChampContact( string $nom, string $label, string $type, array $saisie, bool $requis = true ): string {
    $id     = 'techana-' . $nom;
    $valeur = $saisie[ $nom ] ?? '';
    $marque = $requis ? ' <span aria-hidden="true">*</span>' : '';

    if ( 'textarea' === $type ) {
        $champ = sprintf(
            '<textarea id="%s" name="techana_%s" rows="7"%s>%s</textarea>',
            esc_attr( $id ),
            esc_attr( $nom ),
            $requis ? ' required' : '',
            esc_textarea( $valeur )
        );
    } else {
        $champ = sprintf(
            '<input type="%s" id="%s" name="techana_%s" value="%s"%s />',
            esc_attr( $type ),
            esc_attr( $id ),
            esc_attr( $nom ),
            esc_attr( $valeur ),
            $requis ? ' required' : ''
        );
    }

    return sprintf(
        '<p class="champ"><label for="%s">%s%s</label>%s</p>',
        esc_attr( $id ),
        esc_html( $label ),
        $marque,
        $champ
    );
}

/** Formulaire complet, avec le résultat du dernier envoi s'il y en a un. */
function techanaRevueBlocFormulaire(): string {
    $etat   = techanaRevueEtatFormulaire();
    $saisie = $etat['saisie'];

    $retour = '';
    if ( '' !== $etat['etat'] ) {
        $retour = sprintf(
            '<p class="form-retour form-%s" role="status">%s</p>',
            esc_attr( $etat['etat'] ),
            esc_html( $etat['message'] )
        );
    }
    // Envoi réussi : le formulaire n'a plus lieu d'être réaffiché.
    if ( 'succes' === $etat['etat'] ) {
        return '<div class="contact-form">' . $retour . '</div>';
    }

    $confidentialite = get_page_by_path( 'politique-de-confidentialite' );
    $lienConfid      = $confidentialite
        ? sprintf(
            ' Vos données servent uniquement à traiter votre demande — voir la <a href="%s">politique de confidentialité</a>.',
            esc_url( get_permalink( $confidentialite ) )
        )
        : '';

    return '<form class="contact-form" method="post" action="' . esc_url( get_permalink() ) . '#formulaire">'
        . '<div id="formulaire"></div>'
        . $retour
        . techanaRevueChampContact( 'nom', 'Votre nom', 'text', $saisie )
        . techanaRevueChampContact( 'email', 'Votre adresse e-mail', 'email', $saisie )
        . techanaRevueChampContact( 'sujet', 'Sujet', 'text', $saisie, false )
        . techanaRevueChampContact( 'message', 'Votre message', 'textarea', $saisie )
        // Le texte est enveloppé : sans lui, le lien deviendrait un troisième
        // élément de la boîte flexible et sortirait du fil de la phrase.
        . '<p class="champ champ-case"><label><input type="checkbox" name="techana_consentement" value="1" required />'
        . '<span>J’accepte que mon message et mon adresse soient utilisés pour me répondre.'
        . $lienConfid . '</span></label></p>'
        // Champ leurre : caché à l'écran et retiré de l'ordre de tabulation.
        . '<p class="champ-leurre" aria-hidden="true"><label>Ne pas remplir'
        . '<input type="text" name="techana_site" tabindex="-1" autocomplete="off" /></label></p>'
        . '<input type="hidden" name="techana_ouverture" value="' . esc_attr( (string) time() ) . '" />'
        . '<input type="hidden" name="techana_contact" value="1" />'
        . wp_nonce_field( 'techana-contact', 'techana_contact_nonce', true, false )
        . '<p><button type="submit" class="btn">Envoyer le message</button></p>'
        . '</form>';
}
