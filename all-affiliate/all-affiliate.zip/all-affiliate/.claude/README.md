# Template projet générique

Ce dossier est un template à copier dans tout nouveau projet.

---

## Utilisation
```bash
# Depuis la racine de ton nouveau projet
cp -r ~/claude-config/claude-code-projet/. .

# Vérifier ce qui a été copié
ls -la
```

---

## Étapes après la copie

### 1 — Remplir CLAUDE.md
```bash
# Repérer les placeholders
grep -n "PLACEHOLDER\|\[ex\.\]\|\[NOM\]" CLAUDE.md
```

Remplir obligatoirement :
- `[NOM_DU_PROJET]`
- Section `## Stack & Commandes`
- Section `## Architecture`
- Section `## Conventions`
- Section `## Points d'attention`

### 2 — Remplir les docs
```bash
.claude/docs/CONTEXT.md     # ce que fait le projet, pour qui, pourquoi
.claude/docs/STRUCTURE.md   # arborescence et modules
.claude/docs/ROADMAP.md     # ce qui est prévu
```

### 3 — Adapter settings.json

Ouvrir `.claude/settings.json` et décommenter les commandes de ton stack.

### 4 — Installer le hook pre-commit
```bash
cp .claude/docs/hooks/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

### 5 — Vérifier
```bash
claude
/user:recap
```

### 6 — BMAD Method - Planification agile et l'implémentation guidée par IA.

Installation
Prérequis : Node.js 20+

```bash
npx bmad-method install
```

Sélectionner : **Claude Code** comme outil IA, **BMad Method (BMM)** comme module.

Les dossiers `_bmad/` et `.claude/skills/` sont déjà commités — l'installation n'est nécessaire que pour initialiser un nouvel environnement ou mettre à jour le framework.

### Utilisation

Ouvrir le projet dans **Claude Code**, puis invoquer les skills :

bmad-help               → guide intelligent, point de départ
bmad-agent-pm           → agent Product Manager (PRD, specs)
bmad-agent-architect    → agent Architecte (architecture, tech decisions)
bmad-agent-dev          → agent Développeur (implémentation des stories)

---

Toujours démarrer un nouveau chat pour chaque workflow

## Ce que contient ce template
```
(racine du projet)
├── CLAUDE.md                        ← à remplir
├── CLAUDE.local.md                  ← overrides perso (gitignored)
├── .gitignore
├── tasks/
│   ├── todo.md                      ← plans Claude (géré par Claude)
│   └── lessons.md                   ← erreurs apprises (géré par Claude)
└── .claude/
    ├── settings.json                ← permissions stack
    ├── rules/
    │   ├── style-de-code.md
    │   ├── javascript.md
    │   ├── conventions-git.md
    │   └── securite.md
    └── docs/
        ├── CONTEXT.md               ← à remplir
        ├── STRUCTURE.md             ← à remplir
        ├── ROADMAP.md               ← à remplir
        └── hooks/
            └── pre-commit
```

---

## Commandes disponibles dès le départ

| Commande                   | Usage                                  |
| -------------------------- | -------------------------------------- |
| `/user:recap`              | Recharger le contexte après `/compact` |
| `/user:planifier [tâche]`  | Plan avant de coder                    |
| `/user:committer`          | Commit conventionnel                   |
| `/user:corriger-bug [bug]` | Debug autonome                         |
| `/user:revue [branche]`    | Revue avant merge                      |
| `/user:lecons`             | Consulter les leçons apprises          |