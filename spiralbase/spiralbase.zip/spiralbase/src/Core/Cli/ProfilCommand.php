<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\Profils;
use SpiralBase\Core\Registry;

/**
 * `wp spiralbase profil` — appliquer un profil métier en un geste (AD-14).
 *
 * Coquille CLI : le juge est `Profils`, l'état appartient au registre. La
 * commande n'ajoute qu'une chose au dépôt — le croisement des slugs de
 * modules du fichier avec ceux que le thème connaît RÉELLEMENT. C'est le
 * régime strict de la porte : une faute de frappe dans un fichier de données
 * allumerait un module fantôme sans que personne ne le sache.
 *
 * Messages CLI non traduits (convention WP-CLI).
 */
final class ProfilCommand
{
    public function __construct(
        private readonly Profils $profils,
        private readonly Registry $registre,
    ) {
    }

    /**
     * Liste les profils métier livrés par le thème.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase profil lister
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function lister(array $args, array $assocArgs): void
    {
        $disponibles = $this->profils->disponibles();

        if ($disponibles === []) {
            \WP_CLI::log('Aucun profil livré dans profiles/.');

            return;
        }

        $applique = $this->profils->slugApplique();

        foreach ($disponibles as $slug) {
            $profil = $this->profils->get($slug);

            if (!is_array($profil)) {
                /* Un profil abîmé se voit : l'escamoter donnerait une liste
                   rassurante et une application qui échoue sans prévenir. */
                \WP_CLI::log(sprintf('%-14s ILLISIBLE — %s', $slug, $profil instanceof \WP_Error ? $profil->get_error_message() : 'fichier introuvable'));

                continue;
            }

            $actifs = count(array_filter($profil['modules']));

            \WP_CLI::log(sprintf(
                '%-14s %s (%d module(s) ON, %d OFF)%s%s',
                $slug,
                $profil['libelle'],
                $actifs,
                count($profil['modules']) - $actifs,
                /* Un profil dont des entrées ont été écartées s'affichait
                   comme sain : seul `appliquer` révélait le problème. */
                $profil['rejets'] === [] ? '' : sprintf('  [%d entrée(s) écartée(s)]', count($profil['rejets'])),
                $slug === $applique ? '  [appliqué]' : ''
            ));
        }
    }

    /**
     * Applique un profil métier à cette installation.
     *
     * ## OPTIONS
     *
     * <slug>
     * : Slug du profil (voir `wp spiralbase profil lister`).
     *
     * [--force]
     * : Re-sélectionner alors qu'un profil est déjà appliqué. Les choix
     * manuels d'interrupteurs ne sont jamais écrasés, avec ou sans ce drapeau.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase profil appliquer restaurant
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function appliquer(array $args, array $assocArgs): void
    {
        $slug = trim((string) ($args[0] ?? ''));

        if ($slug === '') {
            \WP_CLI::error('Slug de profil attendu : wp spiralbase profil appliquer <slug>.');

            return;
        }

        $profil = $this->profils->get($slug);

        if (is_array($profil)) {
            $inconnus = array_values(array_diff(array_keys($profil['modules']), $this->registre->slugs()));

            if ($inconnus !== []) {
                \WP_CLI::error(sprintf(
                    'Profil « %s » : module(s) inconnu(s) du thème — %s. Le profil n\'a pas été appliqué.',
                    $slug,
                    implode(', ', $inconnus)
                ));

                return;
            }
        }

        /*
         * WP-CLI passe `true` (booléen) pour `--force`, `false` pour
         * `--no-force`, et la CHAÎNE pour `--force=x`. Avec `!empty()`,
         * `--force=false` et `--force=no` forçaient — l'idiome shell le plus
         * ordinaire (`--force=$VARIABLE`) re-sélectionnait donc le profil du
         * site à l'insu de son auteur. Le drapeau ne prend pas de valeur.
         */
        $force = $assocArgs['force'] ?? false;

        if (!is_bool($force)) {
            \WP_CLI::error('Le drapeau --force ne prend pas de valeur : écrire --force (ou l\'omettre).');

            return;
        }

        $verdict = $this->profils->appliquer($slug, $force);

        if ($verdict !== true) {
            \WP_CLI::error($verdict->get_error_message());

            return;
        }

        \WP_CLI::success(sprintf('Profil « %s » appliqué.', $slug));

        foreach (EtatModules::lignes($this->registre) as $ligne) {
            \WP_CLI::log($ligne);
        }
    }

    /**
     * Affiche le profil appliqué sur cette installation.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase profil etat
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function etat(array $args, array $assocArgs): void
    {
        $marqueur = $this->profils->marqueur();

        if ($marqueur === null) {
            \WP_CLI::log('Aucun profil appliqué sur ce site — chaque module suit son défaut.');

            return;
        }

        $profil  = $this->profils->get($marqueur['slug']);
        $libelle = is_array($profil) ? $profil['libelle'] : 'profil introuvable dans ce thème';

        \WP_CLI::log(sprintf(
            'Profil appliqué : %s (%s), le %s.',
            $marqueur['slug'],
            $libelle,
            $marqueur['applique_le'] > 0 ? gmdate('Y-m-d H:i:s', $marqueur['applique_le']) . ' UTC' : 'date inconnue'
        ));

        if (is_array($profil) && $profil['description'] !== '') {
            \WP_CLI::log($profil['description']);
        }
    }

    /**
     * Retire le profil appliqué : chaque module non tranché par un humain
     * revient au défaut déclaré par le thème.
     *
     * Sans cette porte, l'état « aucun profil » n'était atteignable qu'une
     * fois dans la vie d'un site — à l'installation. Un opérateur qui se
     * trompe de profil ne pouvait que basculer vers un autre, ou contourner
     * l'écrivain unique par un `wp option delete` (revue 3.9).
     *
     * ## EXAMPLES
     *
     *     wp spiralbase profil retirer
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function retirer(array $args, array $assocArgs): void
    {
        $slug = $this->profils->slugApplique();

        if (!$this->profils->retirer()) {
            \WP_CLI::log('Aucun profil appliqué : rien à retirer.');

            return;
        }

        \WP_CLI::success(sprintf(
            'Profil « %s » retiré — les choix manuels sont conservés, les autres modules reviennent au défaut du thème.',
            $slug ?? 'illisible'
        ));

        foreach (EtatModules::lignes($this->registre) as $ligne) {
            \WP_CLI::log($ligne);
        }
    }
}
