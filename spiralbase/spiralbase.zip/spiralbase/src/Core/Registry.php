<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Registre de modules — cœur du microkernel.
 *
 * Unique propriétaire de l'état d'activation (AD-1) : rien d'autre n'écrit
 * l'option canonique, qui ne contient QUE des décisions humaines. Le profil
 * métier (AD-14) n'y écrit rien : il fournit le défaut des modules qu'aucun
 * humain n'a tranchés (story 3.9, `isActive()`), au même titre que
 * `enabledByDefault()`. Les sondes de cession (AD-3) sont évaluées à chaque requête
 * au moment du boot — contrainte assumée : le boot court à
 * `after_setup_theme`, une sonde s'appuie donc sur des faits déjà établis
 * (options, constantes, classes du tiers), jamais sur des hooks enregistrés
 * plus tard (`init`).
 */
final class Registry
{
    public const OPTION_ETAT = 'spiralbase_modules_etat';

    /** Verrou de bascule — préfixe réservé au registre (AD-1), aucun module ne peut le revendiquer. */
    public const OPTION_VERROU = 'spiralbase_modules_verrou';

    private const TTL_VERROU = 10;

    public const ETAT_ACTIF = 'actif';
    public const ETAT_DESACTIVE = 'desactive';
    /** Réservé : émis à partir de la story 1.3 (sondes de cession, AD-3). */
    public const ETAT_CEDE = 'cede';

    /** D'où vient l'état d'un module — rend l'invariant AD-14 observable. */
    public const ORIGINE_HUMAIN = 'humain';
    public const ORIGINE_PROFIL = 'profil';
    public const ORIGINE_DEFAUT = 'defaut';

    /** @var array<string, Module> */
    private array $modules = [];

    /**
     * Cessions par slug, réévaluées à CHAQUE requête (AD-3) — jamais
     * persistées : l'interrupteur humain et la cession mécanique sont deux
     * dimensions indépendantes (AD-1). La raison est stockée brute et
     * composée/traduite À LA LECTURE (cessionReason) : la locale du lecteur
     * admin peut différer de celle de la requête qui a booté.
     *
     * @var array<string, array{type: 'module'|'generique'|'echec'|'echec_boot', detail: string}>
     */
    private array $cessions = [];

    private bool $booted = false;

    /**
     * Interrupteurs tels qu'ils étaient AU BOOT.
     *
     * Une bascule (ou une application de profil) faite APRÈS `bootActive()`
     * ne prend son plein effet qu'à la requête suivante : le module n'a pas
     * démarré, et surtout sa sonde de cession n'a pas été évaluée. Sans cette
     * photo, toute surface d'affichage annonce « actif » un module qui cédera
     * — c'est ce que la commande d'application montrait à l'opérateur juste
     * après lui avoir dit « succès » (revue 3.9).
     *
     * @var array<string, bool>
     */
    private array $actifsAuBoot = [];

    /**
     * @param Profils|null $profils fournisseur de défauts (AD-14) : il ne
     *        possède ni n'écrit aucun état — le registre reste seul
     *        propriétaire de l'option canonique (AD-1). Facultatif : le noyau
     *        démarre sans profil comme il l'a toujours fait.
     */
    public function __construct(private readonly Options $options, private readonly ?Profils $profils = null)
    {
    }

    public function register(Module $module): void
    {
        $slug = $module->slug();

        if ($this->booted) {
            throw new RegistryException(sprintf(
                'Module « %s » enregistré après bootActive() : il ne démarrerait jamais — enregistrer avant le boot.',
                $slug
            ));
        }

        if (!preg_match('/^[a-z][a-z0-9_]*$/', $slug)) {
            throw new RegistryException(sprintf(
                'Slug de module invalide : « %s » (attendu : snake_case ASCII minuscule, frontière WordPress).',
                $slug
            ));
        }

        if (isset($this->modules[$slug])) {
            throw new RegistryException(sprintf('Slug de module en doublon : « %s ».', $slug));
        }

        /*
         * Déclarer AVANT de stocker : si une déclaration d'option échoue, le
         * module n'existe pas du tout — jamais d'enregistrement à moitié fait.
         */
        $this->options->declare($slug, $module->options());
        $this->modules[$slug] = $module;
    }

    /**
     * Trois étages, dans cet ordre : décision HUMAINE persistée, puis défaut
     * du profil métier appliqué (AD-14), puis défaut déclaré par le module.
     * L'option canonique ne contient que le premier étage — c'est ce qui rend
     * « un choix manuel n'est jamais écrasé » vrai par construction.
     */
    public function isActive(string $slug): bool
    {
        $module        = $this->moduleOuEchec($slug);
        $interrupteurs = $this->interrupteursPersistes();

        if (array_key_exists($slug, $interrupteurs)) {
            return $interrupteurs[$slug];
        }

        return $this->defautDuProfil($slug) ?? $module->enabledByDefault();
    }

    /** @return self::ORIGINE_* d'où vient l'état effectif de ce module */
    public function origine(string $slug): string
    {
        $this->moduleOuEchec($slug);

        if (array_key_exists($slug, $this->interrupteursPersistes())) {
            return self::ORIGINE_HUMAIN;
        }

        return $this->defautDuProfil($slug) === null ? self::ORIGINE_DEFAUT : self::ORIGINE_PROFIL;
    }

    /** @return list<string> slugs enregistrés, dans l'ordre d'enregistrement */
    public function slugs(): array
    {
        return array_keys($this->modules);
    }

    /**
     * L'interrupteur tel qu'il était au boot — null avant `bootActive()`.
     * Un état qui en diffère ne vaudra qu'à la requête suivante.
     */
    public function actifAuBoot(string $slug): ?bool
    {
        $this->moduleOuEchec($slug);

        return $this->actifsAuBoot[$slug] ?? null;
    }

    /**
     * Fail-safe intégral : le profil est une DONNÉE livrée par une release et
     * lue à chaque requête depuis `after_setup_theme`. Un fichier abîmé ne
     * peut pas écrouler le site — le module retombe sur son propre défaut.
     */
    private function defautDuProfil(string $slug): ?bool
    {
        if ($this->profils === null) {
            return null;
        }

        try {
            return $this->profils->defautModule($slug);
        } catch (\Throwable $e) {
            error_log(sprintf('[spiralbase] profil illisible pour « %s », défaut du module appliqué — %s', $slug, $e->getMessage()));

            return null;
        }
    }

    /**
     * Bascule un interrupteur et persiste — seul point d'écriture de
     * l'option canonique dans tout le parent.
     *
     * Sérialisé sous verrou, et la relecture est FORCÉE hors cache. Les deux
     * sont nécessaires : l'état vit dans une option-tableau unique, donc
     * toute bascule est un lire-modifier-écrire ; et l'option étant
     * autoloadée, `get_option()` sert l'instantané pris au démarrage de la
     * requête (`wp_load_alloptions`) — la fenêtre de perte n'est pas de
     * quelques microsecondes mais de TOUTE la requête. Prouvé en revue 3.9 :
     * 8 bascules concurrentes, 8 « Success », 1 seul choix conservé — et,
     * plus insidieux, les 7 choix perdus retombaient sur le défaut du PROFIL,
     * c'est-à-dire exactement ce que l'AC 2 interdit.
     */
    public function setEnabled(string $slug, bool $enabled): void
    {
        $this->moduleOuEchec($slug);

        $jeton = uniqid('bascule-', true);

        if (!OptionAtomique::prendreVerrou(self::OPTION_VERROU, self::TTL_VERROU, $jeton)) {
            throw new RegistryException(
                'Une autre bascule d\'interrupteur est en cours — aucun changement n\'a été enregistré, réessayer dans un instant.'
            );
        }

        try {
            $interrupteurs = $this->interrupteursFrais();

            /* Bascule sans changement : rien à écrire (update_option répondrait false). */
            if (($interrupteurs[$slug] ?? null) === $enabled) {
                return;
            }

            $interrupteurs[$slug] = $enabled;

            if (!update_option(self::OPTION_ETAT, $interrupteurs, true)) {
                throw new RegistryException(sprintf(
                    'Échec de persistance de l\'interrupteur « %s » — l\'état n\'a pas été enregistré.',
                    $slug
                ));
            }
        } finally {
            OptionAtomique::relacherVerrou(self::OPTION_VERROU, $jeton);
        }
    }

    /**
     * États des modules — garde mécanique : illisible avant `bootActive()`
     * (les cessions n'existent qu'après l'évaluation des sondes). Sémantique
     * hybride assumée : l'interrupteur est lu en direct, la cession est
     * figée au boot — un interrupteur basculé après le boot prend son plein
     * effet (boot/sonde) à la requête suivante.
     *
     * @return array<string, string> slug => actif | desactive | cede
     */
    public function states(): array
    {
        $this->exigerBootFait();

        $etats = [];

        foreach (array_keys($this->modules) as $slug) {
            if (!$this->isActive($slug)) {
                $etats[$slug] = self::ETAT_DESACTIVE;
            } elseif (isset($this->cessions[$slug])) {
                $etats[$slug] = self::ETAT_CEDE;
            } else {
                $etats[$slug] = self::ETAT_ACTIF;
            }
        }

        return $etats;
    }

    /**
     * Raison de la cession, exposée au tableau de bord (AD-3) — null si le
     * module n'a pas cédé. Composée et traduite à la lecture (locale du
     * lecteur). Illisible avant `bootActive()`, comme states().
     */
    public function cessionReason(string $slug): ?string
    {
        $this->exigerBootFait();
        $this->moduleOuEchec($slug);

        $cession = $this->cessions[$slug] ?? null;

        if ($cession === null) {
            return null;
        }

        return match ($cession['type']) {
            'generique'  => __('Fonctionnalité couverte par une extension tierce.', 'spiralbase'),
            /* Un boot qui jette n'est PAS une sonde en échec : les confondre
               envoie chercher un plugin tiers là où le code du module est en
               cause. Le tableau de bord (6.4) est le premier écran à montrer
               ce libellé à un humain. */
            'echec_boot' => sprintf(
                /* translators: %s : message de l'erreur survenue au démarrage du module. */
                __('Démarrage du module en échec — mis en retrait pour ne pas écrouler le site : %s', 'spiralbase'),
                $cession['detail']
            ),
            'echec'     => sprintf(
                /* translators: %s : détail technique de l'échec de la sonde. */
                __('Sonde de cession en échec — module mis en retrait par prudence : %s', 'spiralbase'),
                $cession['detail']
            ),
            default     => $cession['detail'],
        };
    }

    /**
     * Démarre les seuls modules actifs, après évaluation de leur sonde de
     * cession (règle d'or mécanique) — personne d'autre n'appelle boot().
     */
    public function bootActive(): void
    {
        if ($this->booted) {
            throw new RegistryException('bootActive() déjà exécuté — un module ne démarre qu\'une seule fois par requête.');
        }

        $this->booted = true;
        $chrono       = Profiler::start('registre.boot');

        foreach ($this->modules as $slug => $module) {
            $this->actifsAuBoot[$slug] = $this->isActive($slug);

            /* Interrupteur OFF : la sonde n'est pas même évaluée. */
            if (!$this->actifsAuBoot[$slug]) {
                $this->purgerTachesPlanifiees($slug);

                continue;
            }

            $cession = $this->evaluerSonde($module);

            if ($cession !== null) {
                $this->cessions[$slug] = $cession;

                continue;
            }

            $chronoModule = Profiler::start('module.' . $slug);

            try {
                $module->boot();
            } catch (\Throwable $e) {
                /* Isolation des boot fautifs (différé 1.2, résolu ici) : UN
                   module cassé est mis en retrait avec raison visible —
                   jamais de fatal sur tout le front depuis after_setup_theme. */
                $this->cessions[$slug] = ['type' => 'echec_boot', 'detail' => $e->getMessage()];
                error_log(sprintf('[spiralbase] module « %s » : boot en échec, mis en retrait — %s', $slug, $e->getMessage()));
            }

            Profiler::stop('module.' . $slug, $chronoModule, ['slug' => $slug]);
        }

        Profiler::stop('registre.boot', $chrono, ['modules' => count($this->modules)]);
    }

    /**
     * Retire les tâches planifiées d'un module éteint.
     *
     * Un module OFF ne boote pas : il ne peut donc pas nettoyer lui-même ce
     * qu'il avait planifié, et le cœur REPLANIFIE tout événement récurrent
     * sans se soucier de l'existence d'un écouteur (`wp-cron.php:126-129`).
     * Un `wp_schedule_event` posé une fois survivait ainsi à la désactivation
     * du module — et au changement de thème (revue 3.3, prouvé : l'événement
     * se replanifiait toutes les 12 h, module éteint).
     *
     * Convention rendue exécutoire ici : les tâches d'un module portent le
     * préfixe `spiralbase_<slug>_`. Le registre est le seul point du noyau
     * qui connaisse à la fois la liste des modules et leur état.
     */
    private function purgerTachesPlanifiees(string $slug): void
    {
        if (!function_exists('_get_cron_array') || !function_exists('wp_clear_scheduled_hook')) {
            return;
        }

        $prefixe = 'spiralbase_' . $slug . '_';

        foreach (_get_cron_array() ?: [] as $evenements) {
            if (!is_array($evenements)) {
                continue;
            }

            foreach (array_keys($evenements) as $hook) {
                if (is_string($hook) && str_starts_with($hook, $prefixe)) {
                    wp_clear_scheduled_hook($hook);
                }
            }
        }
    }

    /**
     * Évalue la sonde du module. Fail-safe (NFR13, sans écrouler le site) :
     * une sonde qui jette ou rend un verdict hors contrat met le module en
     * retrait avec une raison d'échec visible au tableau de bord — jamais
     * de fatal sur tout le front pour la sonde d'UN module, jamais de
     * doublon silencieux.
     *
     * @return array{type: 'module'|'generique'|'echec', detail: string}|null
     */
    private function evaluerSonde(Module $module): ?array
    {
        $sonde = $module->cessionProbe();

        if ($sonde === null) {
            return null;
        }

        try {
            $verdict = $sonde();
        } catch (\Throwable $e) {
            return ['type' => 'echec', 'detail' => $e->getMessage()];
        }

        if (!is_bool($verdict) && !is_string($verdict)) {
            return [
                'type'   => 'echec',
                'detail' => sprintf('verdict hors contrat (%s reçu, bool|string attendu)', get_debug_type($verdict)),
            ];
        }

        if ($verdict === true) {
            return ['type' => 'generique', 'detail' => ''];
        }

        if (is_string($verdict) && trim($verdict) !== '') {
            return ['type' => 'module', 'detail' => trim($verdict)];
        }

        return null;
    }

    private function exigerBootFait(): void
    {
        if (!$this->booted) {
            throw new RegistryException(
                'États illisibles avant bootActive() — les sondes de cession n\'ont pas encore été évaluées.'
            );
        }
    }

    private function moduleOuEchec(string $slug): Module
    {
        return $this->modules[$slug]
            ?? throw new RegistryException(sprintf('Module inconnu : « %s ».', $slug));
    }

    /**
     * Interrupteurs persistés, assainis : une valeur non booléenne (option
     * bricolée à la main) n'est jamais interprétée — l'entrée est ignorée et
     * l'interrupteur retombe sur le défaut du module, de façon déterministe.
     *
     * @return array<string, bool>
     */
    private function interrupteursPersistes(): array
    {
        $valeur = get_option(self::OPTION_ETAT, []);

        if (!is_array($valeur)) {
            return [];
        }

        return array_filter($valeur, 'is_bool');
    }

    /**
     * Relecture NON CACHÉE, réservée à la bascule : l'option est autoloadée,
     * donc `get_option()` sert l'instantané `alloptions` chargé au démarrage
     * de la requête — un choix enregistré par un autre processus depuis lors
     * y est invisible, et serait écrasé à la fusion.
     *
     * @return array<string, bool>
     */
    private function interrupteursFrais(): array
    {
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete(self::OPTION_ETAT, 'options');
            wp_cache_delete('alloptions', 'options');
        }

        return $this->interrupteursPersistes();
    }
}
