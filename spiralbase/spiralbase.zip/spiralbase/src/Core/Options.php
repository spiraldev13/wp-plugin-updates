<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Registre d'options du noyau (AD-11) : chaque module déclare ses options à
 * l'enregistrement, et toute lecture/écriture d'option de module passe ici.
 * Aucune option sauvage, désinstallation propre possible plus tard.
 */
final class Options
{
    private const PREFIXE = 'spiralbase_';

    /** Réservé au registre (AD-1) : aucun module ne peut le revendiquer. */
    private const PREFIXE_RESERVE_REGISTRE = 'spiralbase_modules_';

    /**
     * Options canoniques du noyau — SOURCE UNIQUE (la garde ci-dessous et
     * l'invariant de test `SpiralBaseTestCase` la consomment tous deux :
     * ajouter ici, jamais ailleurs).
     */
    public const CANONIQUES = [RecipeStore::OPTION, ContentRules::OPTION, DonneesMetier::OPTION, Profils::OPTION];

    /** @var array<string, string> nom d'option => slug du module déclarant */
    private array $declared = [];

    /**
     * @param list<string> $options
     */
    public function declare(string $moduleSlug, array $options): void
    {
        foreach ($options as $name) {
            if (!is_string($name)) {
                throw new RegistryException(sprintf(
                    'Module « %s » : chaque déclaration d\'option doit être une chaîne (%s reçu).',
                    $moduleSlug,
                    get_debug_type($name)
                ));
            }

            if (!str_starts_with($name, self::PREFIXE) || strlen($name) <= strlen(self::PREFIXE)) {
                throw new RegistryException(sprintf(
                    'Option « %s » (module %s) : nom significatif préfixé spiralbase_ obligatoire.',
                    $name,
                    $moduleSlug
                ));
            }

            if (str_starts_with($name, self::PREFIXE_RESERVE_REGISTRE)) {
                throw new RegistryException(sprintf(
                    'Option « %s » (module %s) : le préfixe spiralbase_modules_ est réservé au registre (AD-1) — un module ne peut pas revendiquer l\'état d\'activation.',
                    $name,
                    $moduleSlug
                ));
            }

            if (in_array($name, self::CANONIQUES, true)) {
                throw new RegistryException(sprintf(
                    'Option « %s » (module %s) : option canonique du noyau, aucun module ne peut la revendiquer (AD-7/AD-10).',
                    $name,
                    $moduleSlug
                ));
            }

            if (isset($this->declared[$name])) {
                throw new RegistryException(sprintf(
                    'Option « %s » : collision de déclaration — déjà revendiquée par le module « %s », refusée à « %s ».',
                    $name,
                    $this->declared[$name],
                    $moduleSlug
                ));
            }

            $this->declared[$name] = $moduleSlug;
        }
    }

    /** @return list<string> */
    public function declared(): array
    {
        return array_keys($this->declared);
    }

    public function get(string $name, mixed $default = null): mixed
    {
        $this->assertDeclared($name);

        return get_option($name, $default);
    }

    /**
     * Sémantique WordPress conservée : false quand la valeur est inchangée
     * OU en échec d'écriture — les appelants qui doivent distinguer relisent.
     *
     * @param bool|null $autoload `false` pour tout ce qui n'est pas lu à
     *        chaque requête. Sans cet argument, le cœur crée l'option en
     *        « auto » (`option.php:3257-3258`) : elle est alors désérialisée
     *        sur CHAQUE page du site, y compris celles qui l'ignorent. Un
     *        cache de plusieurs dizaines de kilo-octets ou un secret n'ont
     *        rien à faire dans `alloptions` (revue 3.3 : 24 Ko d'avis et une
     *        clé d'API y résidaient sur toute la flotte).
     */
    public function set(string $name, mixed $value, ?bool $autoload = null): bool
    {
        $this->assertDeclared($name);

        return update_option($name, $value, $autoload);
    }

    /**
     * Prend un verrou, ou rend `false` s'il est déjà tenu.
     *
     * `get_transient()` puis `set_transient()` ne forment pas une opération
     * atomique : deux processus concurrents (le cron et une commande WP-CLI,
     * scénario ordinaire le jour d'une livraison) lisent tous les deux
     * « libre » et partent tous les deux. Prouvé en revue 3.3 — deux appels
     * à une API facturée, à la même milliseconde.
     *
     * La correction posée alors s'appuyait sur `add_option()`, réputé
     * atomique. Il ne l'est pas (revue 3.9, cœur lu : `option.php:1117-1124`
     * contrôle par lecture puis `:1140` ÉCRASE) : la porte de déclaration
     * AD-11 reste ici, l'indivisibilité est déléguée à `OptionAtomique`.
     *
     * @param string $jeton identité du preneur, à repasser au relâchement
     */
    public function acquerirVerrou(string $name, int $secondes, string $jeton): bool
    {
        $this->assertDeclared($name);

        return OptionAtomique::prendreVerrou($name, $secondes, $jeton);
    }

    /** Ne relâche que SON verrou : un retardataire ne libère pas celui d'un autre. */
    public function relacherVerrou(string $name, string $jeton): void
    {
        $this->assertDeclared($name);

        OptionAtomique::relacherVerrou($name, $jeton);
    }

    private function assertDeclared(string $name): void
    {
        if (!isset($this->declared[$name])) {
            throw new RegistryException(sprintf(
                'Option « %s » non déclarée au registre — déclaration obligatoire (AD-11).',
                $name
            ));
        }
    }
}
