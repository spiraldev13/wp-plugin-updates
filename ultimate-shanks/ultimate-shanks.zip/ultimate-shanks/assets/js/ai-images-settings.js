/**
 * Ultimate Shanks - Images IA (page de réglages)
 *
 * Test de connexion au fournisseur actif (clé enregistrée uniquement) et
 * affichage du champ de remplacement de clé API.
 */
(function ($) {
	'use strict';

	var config = window.ultimateShanksAiImagesSettings || {};

	$(document).on('click', '.us-ai-replace-key', function () {
		$('#' + $(this).data('target')).show().focus();
	});

	// --- Modèles personnalisés : ajout et suppression de lignes ---
	var customModelIndex = 1000;

	$(document).on('click', '#us_ai_add_model', function () {
		var i = customModelIndex++;
		var row = '<tr class="us-ai-custom-model">'
			+ '<td><input type="text" style="width:100%;" placeholder="/flux-nouveau-modele" name="us_ai_custom[' + i + '][endpoint]" value=""></td>'
			+ '<td><input type="text" style="width:100%;" placeholder="Libellé" name="us_ai_custom[' + i + '][label]" value=""></td>'
			+ '<td><select name="us_ai_custom[' + i + '][dims]">'
			+ '<option value="width_height">width/height (conversion auto)</option>'
			+ '<option value="aspect_ratio">aspect_ratio</option>'
			+ '</select></td>'
			+ '<td><input type="number" step="0.001" min="0" style="width:90px;" name="us_ai_custom[' + i + '][price]" value=""></td>'
			+ '<td><button type="button" class="button button-small us-ai-remove-model">Supprimer</button></td>'
			+ '</tr>';
		$('#us_ai_models_table tbody').append(row);
	});

	$(document).on('click', '.us-ai-remove-model', function () {
		$(this).closest('tr').remove();
	});

	$(document).on('click', '#us_ai_images_test_btn', function () {
		var $button = $(this);
		var $result = $('#us_ai_images_test_result');

		$button.prop('disabled', true);
		$result.text(config.strings.testing).css('color', '');

		$.post(config.ajaxurl, {
			action: 'ultimate_shanks_ai_images_test',
			nonce: config.nonce
		}).done(function (response) {
			var ok = response.success;
			var message = (response.data && response.data.message) || config.strings.error;
			$result.text(message).css('color', ok ? '#00753e' : '#b32d2e');
		}).fail(function () {
			$result.text(config.strings.error).css('color', '#b32d2e');
		}).always(function () {
			$button.prop('disabled', false);
		});
	});
})(jQuery);
