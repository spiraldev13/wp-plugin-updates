<?php

/**
 * Auto-login Integration
 *
 * Permet à WP Command Center d'ouvrir wp-admin déjà connecté, sans que
 * l'utilisateur saisisse d'identifiants. Le SaaS (authentifié par Application
 * Password admin) demande une URL à jeton à usage unique ; l'ouverture de cette
 * URL pose le cookie de session WordPress et redirige vers la destination admin
 * demandée (nouvel article, nouvelle page, tableau de bord).
 *
 * Sécurité : le jeton est aléatoire, à usage unique, de courte durée (90 s) et
 * lié à l'utilisateur authentifié. Aucun mot de passe n'est stocké ni transmis.
 * La consommation passe par la RACINE du site (pas par wp-login.php) : elle est
 * donc insensible au masquage de la page de connexion (All In One Security…).
 *
 * @package UltimateShanks\Integration
 */

namespace UltimateShanks\Integration;

if (!defined('ABSPATH')) {
	exit;
}

class AutoLoginIntegration
{
	/**
	 * Nom de l'option pour activer/désactiver l'intégration.
	 */
	const OPTION_NAME = 'ultimate_shanks_autologin_enabled';

	/**
	 * Préfixe des transients de jetons.
	 */
	const TRANSIENT_PREFIX = 'cmd_al_';

	/**
	 * Durée de vie d'un jeton (secondes).
	 */
	const TTL_SECONDS = 90;

	/**
	 * Paramètre de requête portant le jeton sur l'URL de consommation.
	 */
	const QUERY_VAR = 'cmd_al';

	/**
	 * Initialise l'intégration.
	 */
	public static function init()
	{
		add_action('rest_api_init', [self::class, 'register_rest_routes']);
		// Priorité 1 : consommer le jeton avant toute sortie éventuelle (le
		// cookie de session doit être posé avant l'envoi des en-têtes).
		add_action('init', [self::class, 'maybe_consume_token'], 1);
	}

	/**
	 * Vérifie si l'intégration est activée.
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		return get_option(self::OPTION_NAME, '1') === '1';
	}

	/**
	 * Enregistre les routes REST API.
	 */
	public static function register_rest_routes()
	{
		if (!self::is_enabled()) {
			return;
		}

		// POST /wp-json/cmd/v1/autologin — body { dest: admin|new-post|new-page }
		register_rest_route('cmd/v1', '/autologin', [
			'methods'             => 'POST',
			'callback'            => [self::class, 'create_link'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);
	}

	/**
	 * Destinations admin autorisées (liste blanche — jamais de redirection
	 * arbitraire). Retourne un chemin relatif à wp-admin/.
	 *
	 * @param string $dest
	 * @return string
	 */
	private static function resolve_dest($dest)
	{
		switch ($dest) {
			case 'new-post':
				return 'post-new.php';
			case 'new-page':
				return 'post-new.php?post_type=page';
			case 'otomatic':
				return 'admin.php?page=otomatic-ai';
			case 'admin':
			default:
				return '';
		}
	}

	/**
	 * Crée une URL de connexion à usage unique pour WP Command Center.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function create_link($request)
	{
		if (!self::is_enabled()) {
			return new \WP_REST_Response([
				'success' => false,
				'message' => 'Auto-login désactivé sur ce site.',
			], 400);
		}

		$user_id = get_current_user_id();
		if ($user_id <= 0) {
			return new \WP_REST_Response([
				'success' => false,
				'message' => 'Non authentifié.',
			], 401);
		}

		$dest = sanitize_key((string) $request->get_param('dest'));
		if (!in_array($dest, ['new-post', 'new-page', 'otomatic', 'admin'], true)) {
			$dest = 'admin';
		}

		// Jeton alphanumérique (URL-safe), stocké haché : seule l'URL le porte.
		$token = wp_generate_password(48, false, false);
		$key = self::TRANSIENT_PREFIX . hash('sha256', $token);

		set_transient($key, [
			'user_id' => $user_id,
			'dest'    => $dest,
		], self::TTL_SECONDS);

		$url = add_query_arg(self::QUERY_VAR, $token, home_url('/'));

		return new \WP_REST_Response([
			'success'    => true,
			'url'        => $url,
			'expires_in' => self::TTL_SECONDS,
		], 200);
	}

	/**
	 * Consomme le jeton présent sur l'URL : pose le cookie de session puis
	 * redirige vers la destination admin. Usage unique (jeton détruit).
	 */
	public static function maybe_consume_token()
	{
		if (empty($_GET[self::QUERY_VAR])) {
			return;
		}

		$token = sanitize_text_field(wp_unslash($_GET[self::QUERY_VAR]));
		if ($token === '') {
			return;
		}

		$key = self::TRANSIENT_PREFIX . hash('sha256', $token);
		$data = get_transient($key);

		// Usage unique : détruire le jeton quel que soit le résultat.
		delete_transient($key);

		if (!is_array($data) || empty($data['user_id'])) {
			wp_safe_redirect(wp_login_url());
			exit;
		}

		$user = get_user_by('id', (int) $data['user_id']);
		if (!$user || !user_can($user, 'edit_posts')) {
			wp_safe_redirect(wp_login_url());
			exit;
		}

		wp_set_current_user($user->ID);
		wp_set_auth_cookie($user->ID, false, is_ssl());

		$path = self::resolve_dest(isset($data['dest']) ? $data['dest'] : 'admin');
		wp_safe_redirect(admin_url($path));
		exit;
	}

	/**
	 * Vérifie les permissions pour l'API REST : réservé aux administrateurs
	 * (WP Command Center s'authentifie via Application Password admin).
	 *
	 * @param \WP_REST_Request $request
	 * @return bool
	 */
	public static function check_permissions($request)
	{
		return current_user_can('manage_options');
	}
}
