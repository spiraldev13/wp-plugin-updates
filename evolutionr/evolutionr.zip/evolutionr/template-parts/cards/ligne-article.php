<?php
/**
 * Carte unitaire — Article de blog (ligne).
 *
 * Inclue depuis `home.php`, `category.php` et `index.php` pour chaque article
 * de la loop courante. Visuel : ligne pleine largeur, numéro à gauche
 * (— 001, 002, …), catégorie + titre au centre, date à droite, flèche à
 * l'extrême droite. S'appuie sur le style `.blog-row` du SCSS existant.
 *
 * Index passé via `get_template_part('template-parts/cards/ligne-article',
 * null, ['index' => $i])`. Lu via `$args['index']` (variable WP injectée à
 * partir de WordPress 5.5).
 */

if (!defined('ABSPATH')) {
    exit;
}

$index = isset($args['index']) ? (int) $args['index'] : 0;
$categories = get_the_category();
$cat = !empty($categories) ? $categories[0]->name : '';
?>
<a class="blog-row" href="<?php the_permalink(); ?>">
    <div class="num">— <?php echo esc_html(str_pad((string) $index, 3, '0', STR_PAD_LEFT)); ?></div>
    <div>
        <?php if ($cat): ?>
            <span class="cat"><?php echo esc_html($cat); ?></span>
        <?php endif; ?>
        <h3><?php the_title(); ?></h3>
    </div>
    <div class="date"><?php echo esc_html(get_the_date()); ?></div>
    <div class="arrow">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
    </div>
</a>
