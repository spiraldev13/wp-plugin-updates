<?php
/**
 * Blocs dynamiques de l'article (single.html) : signature, figure de tête,
 * « En bref », FAQ, sommaire, boîte auteur, précédent/suivant, même rubrique.
 * Tous rendent une chaîne vide quand leur donnée est absente — un article
 * antérieur au thème s'affiche sans erreur ni bloc creux.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'techanaRevueRegisterBlocsArticle' );
add_filter( 'the_content', 'techanaRevueAncresH2', 8 );

function techanaRevueRegisterBlocsArticle() {
    $blocs = array(
        'byline'         => 'techanaRevueBlocByline',
        'figure-article' => 'techanaRevueBlocFigureArticle',
        'en-bref'        => 'techanaRevueBlocEnBref',
        'faq'            => 'techanaRevueBlocFaq',
        'sommaire'       => 'techanaRevueBlocSommaire',
        'auteur-boite'   => 'techanaRevueBlocAuteurBoite',
        'prevnext'       => 'techanaRevueBlocPrevNext',
        'meme-rubrique'  => 'techanaRevueBlocMemeRubrique',
        'tampon-page'    => 'techanaRevueBlocTamponPage',
        'pages-liees'    => 'techanaRevueBlocPagesLiees',
    );
    foreach ( $blocs as $nom => $callback ) {
        register_block_type( 'techana/' . $nom, array(
            'api_version'     => 3,
            'render_callback' => $callback,
            'uses_context'    => array( 'postId' ),
            'attributes'      => array(
                'format' => array( 'type' => 'string', 'default' => '' ),
                'nombre' => array( 'type' => 'number', 'default' => 0 ),
            ),
        ) );
    }
}

/**
 * Résumé d'un contenu, par ordre de préférence : description SEO saisie
 * (Rank Math), puis extrait rédigé à la main.
 *
 * L'extrait **automatique** de WordPress est volontairement exclu : il recopie
 * les premiers mots du contenu — et en aspire les intertitres au passage — ce
 * qui affichait le début de l'article deux fois de suite sous le titre. Le
 * chapô visible n'a donc pas de repli ; la balise meta description en garde un
 * (`$repliAuto`), Google préférant une description imparfaite à rien.
 *
 * @param int  $postId    Contenu à résumer.
 * @param bool $repliAuto Autoriser l'extrait automatique en dernier recours.
 */
function techanaRevueResume( int $postId, bool $repliAuto = false ): string {
    if ( ! $postId ) {
        return '';
    }
    $seo = (string) get_post_meta( $postId, 'rank_math_description', true );
    // Les variables Rank Math (%title%…) ne sont pas résolues hors du plugin.
    $seo = trim( preg_replace( '/%[a-z_]+(\([^)]*\))?%/i', '', $seo ) );
    if ( '' !== $seo ) {
        return wp_strip_all_tags( $seo );
    }

    $manuel = trim( (string) get_post_field( 'post_excerpt', $postId ) );
    if ( '' !== $manuel ) {
        return wp_strip_all_tags( $manuel );
    }

    return $repliAuto ? wp_strip_all_tags( get_the_excerpt( $postId ) ) : '';
}

/** Identifiant de l'article courant, contexte de bloc d'abord. */
function techanaRevueArticleCourant( $block ): int {
    return (int) ( $block->context['postId'] ?? get_the_ID() );
}

/**
 * Chaque h2 du contenu reçoit une ancre stable (slug du titre) — la matière
 * première du sommaire, des liens profonds et du tampon des pages légales.
 * Priorité 8 : avant les filtres qui réécrivent le HTML.
 */
function techanaRevueAncresH2( string $contenu ): string {
    return preg_replace_callback(
        '/<h2(?![^>]*\bid=)([^>]*)>(.*?)<\/h2>/s',
        static function ( array $m ): string {
            $ancre = sanitize_title( wp_strip_all_tags( $m[2] ) );
            return '<h2 id="' . esc_attr( $ancre ) . '"' . $m[1] . '>' . $m[2] . '</h2>';
        },
        $contenu
    );
}

/**
 * Signature de l'article : auteur · publié · mis à jour · lecture · mots.
 * Sur un article sponsorisé, le pavé « Article sponsorisé » ouvre la
 * signature — au même niveau visuel que l'auteur, comme l'exige le design.
 */
function techanaRevueBlocByline( array $attrs, string $inner, WP_Block $block ): string {
    $postId = techanaRevueArticleCourant( $block );
    if ( ! $postId ) {
        return '';
    }
    $spans = array();
    if ( get_post_meta( $postId, '_techana_sponsorise', true ) ) {
        $spans[] = '<span class="sponsored">Article sponsorisé</span>';
    }
    $auteur  = get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $postId ) );
    $spans[] = '<span class="who">' . esc_html( $auteur ) . '</span>';
    $spans[] = '<span>Publié le ' . esc_html( get_the_date( 'j F Y', $postId ) ) . '</span>';
    if ( get_the_date( 'Y-m-d', $postId ) !== get_the_modified_date( 'Y-m-d', $postId ) ) {
        $spans[] = '<span>Mis à jour le ' . esc_html( get_the_modified_date( 'j F Y', $postId ) ) . '</span>';
    }
    $spans[] = '<span>' . techanaRevueTempsLecture( $postId ) . ' min de lecture</span>';
    $mots    = (int) get_post_meta( $postId, '_techana_mots', true );
    if ( $mots > 0 ) {
        $spans[] = '<span>' . number_format_i18n( $mots ) . ' mots</span>';
    }
    return '<div class="byline">' . implode( '<span class="dot">·</span>', $spans ) . '</div>';
}

/**
 * Figure de tête : image à la une en techana-lead avec sa légende de
 * médiathèque — la réserve .ph-img si l'article n'a pas d'image.
 */
function techanaRevueBlocFigureArticle( array $attrs, string $inner, WP_Block $block ): string {
    $postId = techanaRevueArticleCourant( $block );
    $visuel = get_the_post_thumbnail( $postId, 'techana-lead' );
    if ( ! $visuel ) {
        return '<figure class="art-figure"><span class="ph-img"></span></figure>';
    }
    $legende = wp_get_attachment_caption( get_post_thumbnail_id( $postId ) );
    $caption = $legende ? '<figcaption>' . esc_html( $legende ) . '</figcaption>' : '';
    return '<figure class="art-figure">' . $visuel . $caption . '</figure>';
}

/**
 * « En bref » — les 5 points de la méta _techana_en_bref.
 */
function techanaRevueBlocEnBref( array $attrs, string $inner, WP_Block $block ): string {
    $points = get_post_meta( techanaRevueArticleCourant( $block ), '_techana_en_bref', true );
    if ( ! is_array( $points ) || ! array_filter( $points ) ) {
        return '';
    }
    $items = implode( '', array_map(
        static fn( $p ) => '<li>' . esc_html( $p ) . '</li>',
        array_filter( $points )
    ) );
    return '<section class="tldr"><h2>En bref</h2><ul>' . $items . '</ul></section>';
}

/**
 * FAQ — dl question/réponse depuis _techana_faq. Le JSON-LD FAQPage se
 * construit sur la même méta : le visible et le machine ne divergent jamais.
 */
function techanaRevueBlocFaq( array $attrs, string $inner, WP_Block $block ): string {
    $faq = techanaRevueFaqAffichee( techanaRevueArticleCourant( $block ) );
    if ( ! $faq ) {
        return '';
    }
    $items = '';
    foreach ( $faq as $paire ) {
        $items .= '<dt>' . esc_html( $paire['question'] ) . '</dt><dd>' . esc_html( $paire['reponse'] ) . '</dd>';
    }
    return '<section class="faq prose"><h2>Questions fréquentes</h2><dl>' . $items . '</dl></section>';
}

/**
 * FAQ affichable d'un article — source partagée bloc visible / JSON-LD.
 *
 * @return array<int, array{question: string, reponse: string}>
 */
function techanaRevueFaqAffichee( int $postId ): array {
    $faq = get_post_meta( $postId, '_techana_faq', true );
    if ( ! is_array( $faq ) ) {
        return array();
    }
    return array_values( array_filter( array_map( static function ( $paire ) {
        if ( ! is_array( $paire ) || empty( $paire['question'] ) || empty( $paire['reponse'] ) ) {
            return null;
        }
        return array(
            'question' => (string) $paire['question'],
            'reponse'  => (string) $paire['reponse'],
        );
    }, $faq ) ) );
}

/**
 * Sommaire généré des h2 du contenu rendu. Formats : mobile (accordéon
 * <details>) et lateral (bloc latéral collant). Rien sous deux sections.
 */
function techanaRevueBlocSommaire( array $attrs, string $inner, WP_Block $block ): string {
    $postId  = techanaRevueArticleCourant( $block );
    $contenu = apply_filters( 'the_content', get_post_field( 'post_content', $postId ) );
    preg_match_all( '/<h2[^>]*\bid="([^"]+)"[^>]*>(.*?)<\/h2>/s', $contenu, $m, PREG_SET_ORDER );
    if ( count( $m ) < 2 ) {
        return '';
    }
    $items = implode( '', array_map( static function ( array $h ): string {
        return '<li><a href="#' . esc_attr( $h[1] ) . '">' . esc_html( wp_strip_all_tags( $h[2] ) ) . '</a></li>';
    }, $m ) );
    // Clé de rubrique portée par le sommaire : ses liens en prennent la couleur.
    $cats = get_the_category( $postId );
    $cle  = $cats ? techanaRevueCleRubrique( $cats[0] ) : '';
    $k    = '' !== $cle ? ' k-' . esc_attr( $cle ) : '';

    if ( 'lateral' === ( $attrs['format'] ?? '' ) ) {
        return '<section class="aside-block aside-toc' . $k . '">'
            . '<div class="sec-head on-ink"><span class="sec-tag">Sommaire</span><span class="line"></span></div>'
            . '<nav class="toc sticky-toc" id="toc-desktop" aria-label="Sommaire de l\'article"><ul>' . $items . '</ul></nav>'
            . '</section>';
    }
    if ( 'legal' === ( $attrs['format'] ?? '' ) ) {
        return '<nav class="legal-toc" aria-label="Sommaire de la page"><h2>Sur cette page</h2><ol>'
            . $items . '</ol></nav>';
    }
    return '<details class="toc-mobile' . $k . '"><summary>Sommaire</summary>'
        . '<nav class="toc"><ul>' . $items . '</ul></nav></details>';
}

/**
 * Tampon de version des pages institutionnelles : date de révision, méta
 * _techana_version, nombre de sections — sur une page légale, la version
 * compte autant que la date.
 */
function techanaRevueBlocTamponPage( array $attrs, string $inner, WP_Block $block ): string {
    $postId = techanaRevueArticleCourant( $block );
    if ( ! $postId ) {
        return '';
    }
    $spans   = array();
    $spans[] = '<span>Dernière mise à jour le <b>' . esc_html( get_the_modified_date( 'j F Y', $postId ) ) . '</b></span>';
    $version = get_post_meta( $postId, '_techana_version', true );
    if ( $version ) {
        $spans[] = '<span>Version <b>' . esc_html( $version ) . '</b></span>';
    }
    $contenu = apply_filters( 'the_content', get_post_field( 'post_content', $postId ) );
    $nb      = preg_match_all( '/<h2[^>]*>/', $contenu );
    if ( $nb ) {
        $spans[] = '<span>' . number_format_i18n( $nb ) . ' sections</span>';
    }
    return '<div class="stamp">' . implode( '<span class="dot">·</span>', $spans ) . '</div>';
}

/**
 * Pages liées : jusqu'à trois autres pages publiées — la navigation de fin
 * des pages institutionnelles s'entretient toute seule.
 */
function techanaRevueBlocPagesLiees( array $attrs, string $inner, WP_Block $block ): string {
    $postId = techanaRevueArticleCourant( $block );
    // L'accueil et la page des articles sont des gabarits, pas des pages
    // institutionnelles : les proposer en « page liée » afficherait « Home ».
    $exclus = array_filter( array(
        $postId,
        (int) get_option( 'page_on_front' ),
        (int) get_option( 'page_for_posts' ),
    ) );
    $pages  = get_posts( array(
        'post_type'   => 'page',
        'numberposts' => 3,
        'exclude'     => $exclus,
        'orderby'     => 'menu_order title',
        'order'       => 'ASC',
    ) );
    if ( ! $pages ) {
        return '';
    }
    $liens = '';
    foreach ( $pages as $page ) {
        $liens .= '<a href="' . esc_url( get_permalink( $page ) ) . '"><span class="k">Page liée</span><h3>'
            . esc_html( get_the_title( $page ) ) . '</h3></a>';
    }
    return '<nav class="legal-nav" aria-label="Autres pages">' . $liens . '</nav>';
}

/**
 * Boîte auteur : portrait, bio, compteur d'articles — la preuve d'humanité
 * que l'audit réclamait (E-E-A-T).
 */
function techanaRevueBlocAuteurBoite( array $attrs, string $inner, WP_Block $block ): string {
    $postId   = techanaRevueArticleCourant( $block );
    $auteurId = (int) get_post_field( 'post_author', $postId );
    if ( ! $auteurId ) {
        return '';
    }
    $nom      = get_the_author_meta( 'display_name', $auteurId );
    $bio      = get_the_author_meta( 'description', $auteurId );
    $portrait = techanaRevuePortrait( $auteurId, 144, $nom );
    $total    = count_user_posts( $auteurId, 'post', true );
    return '<section class="authorbox">'
        . $portrait
        . '<div><h3>' . esc_html( $nom ) . '</h3>'
        . ( $bio ? '<p>' . esc_html( $bio ) . '</p>' : '' )
        . '<a class="more" href="' . esc_url( get_author_posts_url( $auteurId ) ) . '">'
        . number_format_i18n( $total ) . ' articles de cet auteur →</a>'
        . '</div></section>';
}

/**
 * Article précédent / suivant — markup exact de la maquette (nav.prevnext).
 */
function techanaRevueBlocPrevNext(): string {
    $prev = get_previous_post();
    $next = get_next_post();
    if ( ! $prev && ! $next ) {
        return '';
    }
    $sortie = '';
    if ( $prev instanceof WP_Post ) {
        $sortie .= '<a href="' . esc_url( get_permalink( $prev ) ) . '"><span class="dir">← Précédent</span><h3>'
            . esc_html( get_the_title( $prev ) ) . '</h3></a>';
    }
    if ( $next instanceof WP_Post ) {
        $sortie .= '<a class="next" href="' . esc_url( get_permalink( $next ) ) . '"><span class="dir">Suivant →</span><h3>'
            . esc_html( get_the_title( $next ) ) . '</h3></a>';
    }
    return '<nav class="prevnext" aria-label="Article précédent et suivant">' . $sortie . '</nav>';
}

/**
 * « Même rubrique » de la latérale d'article : 4 unités latérales de la
 * rubrique principale, article courant exclu.
 */
function techanaRevueBlocMemeRubrique( array $attrs, string $inner, WP_Block $block ): string {
    $postId = techanaRevueArticleCourant( $block );
    $cats   = get_the_category( $postId );
    if ( ! $cats ) {
        return '';
    }
    $articles = get_posts( array(
        'numberposts' => $attrs['nombre'] > 0 ? (int) $attrs['nombre'] : 4,
        'category'    => $cats[0]->term_id,
        'exclude'     => array( $postId ),
    ) );
    if ( ! $articles ) {
        return '';
    }
    $cle    = techanaRevueCleRubrique( $cats[0] );
    $items  = '';
    foreach ( $articles as $p ) {
        $vignette = get_the_post_thumbnail( $p, 'techana-side' );
        if ( ! $vignette ) {
            $vignette = '<span class="ph-img square"></span>';
        }
        $items .= '<a class="u-side" href="' . esc_url( get_permalink( $p ) ) . '">' . $vignette
            . '<div><h3>' . esc_html( get_the_title( $p ) ) . '</h3>'
            . '<span class="meta">' . esc_html( get_the_date( 'j M Y', $p ) ) . '</span></div></a>';
    }
    return '<section class="aside-block' . ( $cle ? ' k-' . esc_attr( $cle ) : '' ) . '">'
        . '<div class="sec-head on-ink"><span class="sec-tag">Même rubrique</span><span class="line"></span></div>'
        . $items . '</section>';
}
