<?php

namespace Spiral\Admin;

use Spiral\PostTypes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Assets des écrans d'administration du plugin.
 */
final class Assets
{
    public static function register(): void
    {
        add_action('admin_enqueue_scripts', [self::class, 'enqueue']);
    }

    public static function enqueue(): void
    {
        if (!self::isPluginScreen()) {
            return;
        }

        wp_enqueue_style(
            'spiral-admin',
            SPIRAL_POPUP_URL . 'assets/admin.css',
            [],
            self::assetVersion('admin.css')
        );

        // Dépendance media-editor : garantit que wp.media est chargé avant
        // notre script (bouton « Choisir dans la médiathèque »).
        wp_enqueue_script(
            'spiral-admin',
            SPIRAL_POPUP_URL . 'assets/admin.js',
            ['media-editor'],
            self::assetVersion('admin.js'),
            true
        );

        wp_localize_script('spiral-admin', 'spiralAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('spiral_admin'),
            'i18n' => [
                'noResult' => __('Aucun résultat', 'popup-spiral'),
                'copied' => __('Copié !', 'popup-spiral'),
                'chooseImage' => __('Choisir une image', 'popup-spiral'),
                'useImage' => __('Utiliser cette image', 'popup-spiral'),
                'close' => __('Fermer', 'popup-spiral'),
                'presetInUse' => __('Cette taille est utilisée par des popups : ils reprendront la taille par défaut. Supprimer ?', 'popup-spiral'),
            ],
        ]);

        // Médiathèque nécessaire partout : image du popup (metabox) et designs.
        wp_enqueue_media();

        if (self::isDesignsScreen()) {
            // La feuille front sert de base à l'aperçu live : ce que l'admin
            // voit est exactement ce que le visiteur verra.
            wp_enqueue_style(
                'spiral-popup',
                SPIRAL_POPUP_URL . 'assets/spiral.css',
                [],
                self::assetVersion('spiral.css')
            );
        }
    }

    /**
     * Version basée sur la date du fichier : le cache navigateur est
     * invalidé automatiquement à chaque modification d'un asset.
     */
    public static function assetVersion(string $file): string
    {
        $path = SPIRAL_POPUP_DIR . 'assets/' . $file;
        $mtime = is_readable($path) ? (string) filemtime($path) : '';

        return SPIRAL_POPUP_VERSION . ($mtime !== '' ? '-' . $mtime : '');
    }

    private static function isPluginScreen(): bool
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;

        if ($screen === null) {
            return false;
        }

        return $screen->post_type === PostTypes::POPUP;
    }

    private static function isDesignsScreen(): bool
    {
        $screen = get_current_screen();

        return $screen !== null && strpos((string) $screen->id, 'spiral-designs') !== false;
    }
}
