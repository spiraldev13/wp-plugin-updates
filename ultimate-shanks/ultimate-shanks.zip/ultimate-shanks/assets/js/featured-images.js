/**
 * Script JavaScript pour la fonctionnalité d'ajout rapide d'images à la une
 *
 * @package UltimateShanks
 * @subpackage Features/FeaturedImages
 */

(function($) {
	'use strict';

	/**
	 * Initialisation du script au chargement du DOM
	 */
	$(document).ready(function() {
		initAddImageButton();
	});

	/**
	 * Initialise le bouton "Ajouter une image"
	 */
	function initAddImageButton() {
		// Gestion du clic sur le bouton "Ajouter une image"
		$(document).on('click', '.us-add-image-btn', function(e) {
			e.preventDefault();

			var postId = $(this).data('post-id');
			var button = $(this);

			// Ouvre la médiathèque WordPress
			openMediaLibrary(postId, button);
		});
	}

	/**
	 * Ouvre la médiathèque WordPress
	 *
	 * @param {number} postId - ID de l'article
	 * @param {jQuery} button - Bouton cliqué
	 */
	function openMediaLibrary(postId, button) {
		// Création du frame de la médiathèque
		var frame = wp.media({
			title: 'Sélectionner une image',
			button: {
				text: 'Utiliser cette image'
			},
			multiple: false
		});

		// Quand une image est sélectionnée
		frame.on('select', function() {
			var attachment = frame.state().get('selection').first().toJSON();

			// Envoie la requête AJAX pour définir l'image à la une
			setFeaturedImage(postId, attachment.id, button);
		});

		// Ouvre la médiathèque
		frame.open();
	}

	/**
	 * Définit l'image à la une via AJAX
	 *
	 * @param {number} postId - ID de l'article
	 * @param {number} imageId - ID de l'image
	 * @param {jQuery} button - Bouton cliqué
	 */
	function setFeaturedImage(postId, imageId, button) {
		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {
				action: 'ultimate_shanks_set_featured_image',
				post_id: postId,
				image_id: imageId,
				nonce: ultimateShanksData.nonce
			},
			beforeSend: function() {
				// Change le texte du bouton pendant le traitement
				button.text('Ajout en cours...');
				button.prop('disabled', true);
			},
			success: function(response) {
				if (response.success) {
					// Recharge la page pour afficher la nouvelle image
					location.reload();
				} else {
					// Affiche l'erreur
					showError(response.data, button);
				}
			},
			error: function() {
				// Affiche une erreur générique
				showError('Erreur lors de l\'ajout de l\'image', button);
			}
		});
	}

	/**
	 * Affiche un message d'erreur
	 *
	 * @param {string} message - Message d'erreur
	 * @param {jQuery} button - Bouton à réinitialiser
	 */
	function showError(message, button) {
		alert('Erreur : ' + message);
		button.text('+ Ajouter une image');
		button.prop('disabled', false);
	}

})(jQuery);
