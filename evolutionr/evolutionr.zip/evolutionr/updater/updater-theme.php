<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * makedev — Updater pour themes WordPress (mises a jour via GitHub)
 *
 * Ce fichier verifie les nouvelles versions depuis le repo wp-plugin-updates
 * et propose la mise a jour dans le Tableau de bord WordPress.
 *
 * Hooks utilises :
 *   - pre_set_site_transient_update_themes (detection des mises a jour)
 *   - delete_site_transient_update_themes  (purge du cache)
 *
 * Difference avec updater.php (plugins) :
 *   - La version est lue depuis style.css (header Theme)
 *   - Le transient utilise update_themes au lieu de update_plugins
 *   - La reponse utilise la cle 'theme' au lieu de 'plugin'
 */

// === Configuration ===

function makedev_theme_updater_get_config()
{
	static $config = null;

	if ($config !== null) {
		return $config;
	}

	$config_file = dirname(__DIR__) . '/plugin-config.json';

	if (!file_exists($config_file)) {
		return [];
	}

	$json = file_get_contents($config_file);
	$config = json_decode($json, true);

	return is_array($config) ? $config : [];
}

function makedev_theme_updater_get_config_value($path, $default = '')
{
	$config = makedev_theme_updater_get_config();
	$keys = explode('.', $path);

	$value = $config;
	foreach ($keys as $key) {
		if (!isset($value[$key])) {
			return $default;
		}
		$value = $value[$key];
	}

	return $value;
}

// === Version du theme ===

function makedev_theme_updater_get_slug()
{
	return makedev_theme_updater_get_config_value('slug', basename(dirname(__DIR__)));
}

function makedev_theme_updater_get_current_version()
{
	$slug = makedev_theme_updater_get_slug();
	$theme = wp_get_theme($slug);

	if ($theme->exists()) {
		return $theme->get('Version');
	}

	return '';
}

// === Manifest URL ===

function makedev_theme_updater_get_manifest_url()
{
	$slug = makedev_theme_updater_get_slug();
	$constant_name = strtoupper(str_replace('-', '_', $slug)) . '_UPDATE_MANIFEST_URL';

	if (defined($constant_name) && constant($constant_name)) {
		return esc_url_raw((string) constant($constant_name));
	}

	$github_user = makedev_theme_updater_get_config_value('github.user', 'spiraldev13');
	$updates_repo = makedev_theme_updater_get_config_value('github.updates_repo', 'wp-plugin-updates');

	$default_url = sprintf(
		'https://api.github.com/repos/%s/%s/contents/%s/update.json?ref=main',
		$github_user,
		$updates_repo,
		$slug
	);

	return esc_url_raw($default_url);
}

// === HTTP avec retry ===

function makedev_theme_updater_http_request($url, $args = [], $max_attempts = 3)
{
	$is_background = wp_doing_cron() || (defined('WP_CLI') && WP_CLI);

	if (!$is_background) {
		$max_attempts = 1;
		if (empty($args['timeout']) || (int) $args['timeout'] > 8) {
			$args['timeout'] = 8;
		}
	}

	$attempt = 0;
	$response = null;

	while ($attempt < $max_attempts) {
		$attempt++;
		$response = wp_remote_get($url, $args);

		if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
			return $response;
		}

		if ($is_background && $attempt < $max_attempts) {
			sleep(2);
		}
	}

	return is_wp_error($response) ? $response : new WP_Error('http_request_failed', 'Echec apres ' . $max_attempts . ' tentatives');
}

// === Manifest avec cache ===

function makedev_theme_updater_get_manifest($force_refresh = false)
{
	$slug = makedev_theme_updater_get_slug();
	$cache_key = $slug . '_theme_update_manifest';

	if (!$force_refresh) {
		$cached = get_site_transient($cache_key);
		if (is_array($cached) && !empty($cached['version']) && !empty($cached['download_url'])) {
			return $cached;
		}
	}

	$manifest_url = makedev_theme_updater_get_manifest_url();
	if (empty($manifest_url) || strpos($manifest_url, 'https://') !== 0) {
		return null;
	}

	$response = makedev_theme_updater_http_request($manifest_url, [
		'timeout' => 15,
		'sslverify' => true,
		'headers' => [
			'Accept'     => 'application/vnd.github.raw',
			'User-Agent' => 'WordPress-Theme-Updater',
		],
	]);

	if (is_wp_error($response)) {
		return null;
	}

	$raw_data = json_decode(wp_remote_retrieve_body($response), true);
	if (!is_array($raw_data) || empty($raw_data['version']) || empty($raw_data['download_url'])) {
		return null;
	}

	if (strpos($raw_data['download_url'], 'https://') !== 0) {
		return null;
	}

	$manifest = [
		'version'      => sanitize_text_field((string) $raw_data['version']),
		'download_url' => esc_url_raw((string) $raw_data['download_url']),
		'details_url'  => !empty($raw_data['details_url']) ? esc_url_raw((string) $raw_data['details_url']) : '',
		'tested'       => !empty($raw_data['tested']) ? sanitize_text_field((string) $raw_data['tested']) : '',
		'requires'     => !empty($raw_data['requires']) ? sanitize_text_field((string) $raw_data['requires']) : '',
		'requires_php' => !empty($raw_data['requires_php']) ? sanitize_text_field((string) $raw_data['requires_php']) : '',
		'sha256'       => !empty($raw_data['sha256']) ? strtolower(trim((string) $raw_data['sha256'])) : '',
	];

	set_site_transient($cache_key, $manifest, HOUR_IN_SECONDS);

	return $manifest;
}

// === Hook principal : detection des mises a jour themes ===

function makedev_theme_updater_register($transient)
{
	if (!is_object($transient)) {
		return $transient;
	}

	$slug = makedev_theme_updater_get_slug();
	$current_version = makedev_theme_updater_get_current_version();

	if (empty($current_version)) {
		return $transient;
	}

	$manifest = makedev_theme_updater_get_manifest();

	if (empty($manifest)) {
		return $transient;
	}

	if (version_compare($current_version, $manifest['version'], '<')) {
		$github_user = makedev_theme_updater_get_config_value('github.user', 'spiraldev13');
		$github_repo = makedev_theme_updater_get_config_value('github.repo', $slug);
		$fallback_url = "https://github.com/$github_user/$github_repo";

		$transient->response[$slug] = [
			'theme'        => $slug,
			'new_version'  => $manifest['version'],
			'package'      => $manifest['download_url'],
			'url'          => !empty($manifest['details_url']) ? $manifest['details_url'] : $fallback_url,
			'requires'     => $manifest['requires'],
			'requires_php' => $manifest['requires_php'],
		];
	}

	return $transient;
}

add_filter('pre_set_site_transient_update_themes', 'makedev_theme_updater_register');

// === Purge du cache quand WordPress relance une verification ===

function makedev_theme_updater_clear_cache()
{
	$slug = makedev_theme_updater_get_slug();
	delete_site_transient($slug . '_theme_update_manifest');
}

add_action('delete_site_transient_update_themes', 'makedev_theme_updater_clear_cache');
