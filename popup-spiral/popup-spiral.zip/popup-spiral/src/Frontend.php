<?php

namespace Spiral;

use Spiral\Designs\Repository;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rendu front : sélection des popups chargeables, assets conditionnels,
 * injection en pied de page et filtre de contenu dédié.
 */
final class Frontend
{
    /** @var \WP_Post[]|null Popups chargeables sur la page courante (mémoïsé). */
    private static $loadable = null;

    public static function register(): void
    {
        // Priorité 11 impérative : les page builders initialisent leur
        // isolation CSS à 10 — plus tôt, leur CSS fuit dans la page.
        add_action('wp_enqueue_scripts', [self::class, 'enqueueAssets'], 11);
        add_action('wp_footer', [self::class, 'renderPopups']);

        // Chaîne de formatage dédiée : jamais `the_content` (conflits builders).
        add_filter('spiral_popup_content', [self::class, 'renderBlocks'], 9);
        add_filter('spiral_popup_content', 'wpautop', 10);
        add_filter('spiral_popup_content', 'do_shortcode', 11);
    }

    /**
     * Un popup est chargeable : publié + ciblage OK + planification OK.
     */
    public static function isLoadable(int $popupId): bool
    {
        $popup = get_post($popupId);

        if (!$popup instanceof \WP_Post
            || $popup->post_type !== PostTypes::POPUP
            || $popup->post_status !== 'publish'
        ) {
            return false;
        }

        // Toggle rapide de la liste admin : « 0 » = désactivé sans dépublier.
        if (get_post_meta($popupId, 'spiral_enabled', true) === '0') {
            return false;
        }

        $settings = Settings::get($popupId);

        return Targeting::matches($settings['targeting'])
            && Schedule::isActive($settings['schedule']);
    }

    /**
     * État d'affichage *calculé* d'un popup, indépendamment de la page courante :
     * peut-il s'afficher, et sinon pourquoi. Distinct du toggle « Actif » (une
     * décision manuelle) : ici on agrège toutes les conditions de configuration.
     *
     * @return array{can: bool, code: string, label: string}
     */
    public static function displayStatus(int $popupId): array
    {
        $popup = get_post($popupId);

        if (!$popup instanceof \WP_Post || $popup->post_type !== PostTypes::POPUP) {
            return ['can' => false, 'code' => 'missing', 'label' => __('Introuvable', 'popup-spiral')];
        }

        if ($popup->post_status !== 'publish') {
            return ['can' => false, 'code' => 'unpublished', 'label' => __('Non publié', 'popup-spiral')];
        }

        if (get_post_meta($popupId, 'spiral_enabled', true) === '0') {
            return ['can' => false, 'code' => 'disabled', 'label' => __('Désactivé', 'popup-spiral')];
        }

        $settings = Settings::get($popupId);

        if (!Targeting::hasAnyTarget($settings['targeting'])) {
            return ['can' => false, 'code' => 'no-target', 'label' => __('Aucune cible', 'popup-spiral')];
        }

        if (!self::hasContent($popup)) {
            return ['can' => false, 'code' => 'empty', 'label' => __('Sans contenu', 'popup-spiral')];
        }

        $start = Schedule::parse($settings['schedule']['start'] ?? '');
        $end = Schedule::parse($settings['schedule']['end'] ?? '');

        if ($start !== null && $end !== null && $start > $end) {
            return ['can' => false, 'code' => 'invalid-dates', 'label' => __('Dates incohérentes', 'popup-spiral')];
        }

        if (!Schedule::isActive($settings['schedule'])) {
            if ($start !== null && Dates::now() < $start) {
                return ['can' => false, 'code' => 'scheduled', 'label' => __('Programmé', 'popup-spiral')];
            }

            return ['can' => false, 'code' => 'expired', 'label' => __('Expiré', 'popup-spiral')];
        }

        return ['can' => true, 'code' => 'visible', 'label' => __('Visible', 'popup-spiral')];
    }

    public static function enqueueAssets(): void
    {
        $popups = self::loadablePopups();

        if ($popups === []) {
            return;
        }

        wp_enqueue_style(
            'spiral-popup',
            SPIRAL_POPUP_URL . 'assets/spiral.css',
            [],
            Admin\Assets::assetVersion('spiral.css')
        );

        wp_enqueue_script(
            'spiral-popup',
            SPIRAL_POPUP_URL . 'assets/spiral.js',
            [],
            Admin\Assets::assetVersion('spiral.js'),
            true
        );

        wp_add_inline_script(
            'spiral-popup',
            'window.spiralPopups = ' . wp_json_encode(self::jsConfig($popups)) . ';',
            'before'
        );
    }

    public static function renderPopups(): void
    {
        $popups = self::loadablePopups();

        if ($popups === []) {
            return;
        }

        echo self::designsCssTag($popups);

        foreach ($popups as $popup) {
            self::renderPopup($popup);
        }
    }

    /**
     * Markup complet d'un popup, en chaîne (réutilisé par la prévisualisation).
     */
    public static function renderPopupHtml(\WP_Post $popup): string
    {
        ob_start();
        self::renderPopup($popup);

        return (string) ob_get_clean();
    }

    /**
     * Configuration JS pour la prévisualisation d'un seul popup : le drapeau
     * `preview` force l'ouverture immédiate, sans cookie, sans comptage.
     */
    public static function previewConfig(\WP_Post $popup): array
    {
        $config = self::jsConfig([$popup]);
        $config['preview'] = true;

        return $config;
    }

    /**
     * Équivalent de `do_blocks()` pour notre filtre : le cœur de WP ne sait
     * retirer `wpautop` que sur `the_content`, on le fait ici nous-mêmes.
     *
     * @param string $content
     * @return string
     */
    public static function renderBlocks($content)
    {
        if (!has_blocks($content)) {
            return $content;
        }

        $priority = has_filter('spiral_popup_content', 'wpautop');

        if ($priority !== false) {
            remove_filter('spiral_popup_content', 'wpautop', $priority);
            add_filter('spiral_popup_content', [self::class, 'restoreWpautop'], $priority + 1);
        }

        return do_blocks($content);
    }

    /**
     * Repose `wpautop` pour le popup suivant, une fois le contenu à blocs passé.
     *
     * @param string $content
     * @return string
     */
    public static function restoreWpautop($content)
    {
        $priority = has_filter('spiral_popup_content', [self::class, 'restoreWpautop']);

        if ($priority !== false) {
            remove_filter('spiral_popup_content', [self::class, 'restoreWpautop'], $priority);
            add_filter('spiral_popup_content', 'wpautop', $priority - 1);
        }

        return $content;
    }

    /**
     * Contenu final d'un popup selon sa source (éditeur ou template Elementor).
     */
    public static function contentFor(\WP_Post $popup, array $settings): string
    {
        $source = $settings['content_source'];

        if ($source['type'] === 'elementor_template' && $source['elementor_template'] > 0) {
            $rendered = Compat\Elementor::renderTemplate((int) $source['elementor_template']);

            if ($rendered !== '') {
                return $rendered;
            }
            // Template supprimé ou Elementor absent : repli sur l'éditeur.
        }

        return (string) apply_filters('spiral_popup_content', $popup->post_content, $popup->ID);
    }

    /**
     * @return \WP_Post[]
     */
    private static function loadablePopups(): array
    {
        if (self::$loadable !== null) {
            return self::$loadable;
        }

        self::$loadable = [];

        if (is_admin() || is_feed() || is_embed()) {
            return self::$loadable;
        }

        $popups = get_posts([
            'post_type' => PostTypes::POPUP,
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);

        foreach ($popups as $popup) {
            if (!self::isLoadable($popup->ID)) {
                continue;
            }

            if (!self::hasContent($popup)) {
                continue;
            }

            self::$loadable[] = $popup;
        }

        return self::$loadable;
    }

    /**
     * Un popup sans rien à afficher (ni texte, ni image, ni bouton) n'est pas chargé.
     */
    private static function hasContent(\WP_Post $popup): bool
    {
        $settings = Settings::get($popup->ID);
        $source = $settings['content_source'];

        if ($source['type'] === 'elementor_template'
            && $source['elementor_template'] > 0
            && Compat\Elementor::templateExists((int) $source['elementor_template'])
        ) {
            return true;
        }

        if ($settings['display']['image']['layout'] !== 'none'
            && ($settings['display']['image']['id'] > 0 || has_post_thumbnail($popup))
        ) {
            return true;
        }

        if ($settings['button']['enabled'] && $settings['button']['label'] !== '') {
            return true;
        }

        return trim($popup->post_content) !== '';
    }

    /**
     * Réglages publics passés au JavaScript front.
     */
    private static function jsConfig(array $popups): array
    {
        $config = [
            'restUrl' => esc_url_raw(rest_url('spiral/v1/track')),
            'popups' => [],
        ];

        foreach ($popups as $popup) {
            $settings = Settings::get($popup->ID);
            $design = Repository::get($settings['display']['design']);
            $overlay = $design !== null ? $design['settings']['overlay'] : 'dim';

            $config['popups'][] = [
                'id' => $popup->ID,
                'overlay' => $overlay,
                'triggers' => [
                    'delayEnabled' => $settings['triggers']['delay_enabled'],
                    'delay' => $settings['triggers']['delay'],
                    'clickEnabled' => $settings['triggers']['click_enabled'],
                    'clickSelector' => $settings['triggers']['click_selector'],
                    'exitIntent' => $settings['triggers']['exit_intent'],
                ],
                'frequency' => $settings['frequency'],
                'schedule' => Schedule::boundsMs($settings['schedule']),
            ];
        }

        return $config;
    }

    /**
     * Balise <style> des designs réellement utilisés par les popups fournis,
     * ou chaîne vide si aucun CSS. Réutilisée par le rendu front et l'aperçu.
     */
    public static function designsCssTag(array $popups): string
    {
        $slugs = [];

        foreach ($popups as $popup) {
            $settings = Settings::get($popup->ID);
            $slugs[$settings['display']['design']] = true;
        }

        $css = '';

        foreach (array_keys($slugs) as $slug) {
            $css .= Repository::css($slug) . "\n";
        }

        if (trim($css) === '') {
            return '';
        }

        return '<style id="spiral-designs-css">' . "\n" . $css . '</style>' . "\n";
    }

    private static function renderPopup(\WP_Post $popup): void
    {
        $settings = Settings::get($popup->ID);
        $designSlug = $settings['display']['design'];
        $design = Repository::get($designSlug);

        if ($design === null) {
            $designSlug = 'annonce';
            $design = Repository::get($designSlug);
        }

        // Variables consommées par le template.
        $spiralPopup = $popup;
        $spiralSettings = $settings;
        $spiralDesignSlug = $designSlug;
        $spiralDesign = $design['settings'];
        $spiralContent = self::contentFor($popup, $settings);
        $spiralPosition = $settings['display']['position'];
        $spiralZindex = (int) apply_filters('spiral_popup_zindex', $settings['display']['zindex'], $popup->ID);

        $template = locate_template('popup-spiral/popup.php');

        if ($template === '') {
            $template = SPIRAL_POPUP_DIR . 'views/popup.php';
        }

        include $template;
    }
}
