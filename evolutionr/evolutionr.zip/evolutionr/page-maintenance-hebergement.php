<?php
/**
 * Template — Page « Maintenance & hébergement » (slug `maintenance-hebergement`).
 *
 * Tous les contenus sont controlables depuis le metabox ACF
 * `group_evor_page_maintenance` (inc/acf-fields.php). Hardcodes interdits.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal" id="content">

    <?php /* ─── Hero ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-hero', null, [
        'visual_label' => 'uptime.monitor',
        'visual_type'  => 'maintenance',
    ]); ?>

    <?php
    // Petite fonction helper interne pour rendre une grille de "formules" (packs ou offres hébergement)
    $render_formules = function (string $eyebrow, string $title, string $lede, string $repeaterField, string $sectionId, bool $noPadTop = false) {
        if (!have_rows($repeaterField)) return;
        ?>
        <section class="section section--prestation<?php echo $noPadTop ? ' section--no-pad-top' : ''; ?>" id="<?php echo esc_attr($sectionId); ?>" aria-labelledby="<?php echo esc_attr($sectionId); ?>-title">
            <div class="container">
                <?php if ($eyebrow || $title || $lede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($eyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($title): ?>
                                <h2 class="section-title" id="<?php echo esc_attr($sectionId); ?>-title"><?php echo esc_html($title); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($lede): ?>
                            <p class="section-lede"><?php echo esc_html($lede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="formules-grid">
                    <?php $i = 0; while (have_rows($repeaterField)): the_row();
                        $offer = evolutionr_offer_resolve((string) get_sub_field('offre_ref'));
                        if (!$offer['visible']) {
                            continue; // offre « actif = non » ou non liée → carte masquée
                        }
                        get_template_part('template-parts/cards/formule-card', null, [
                            'offer'       => $offer,
                            'index'       => $i,
                            'cta_default' => __('Choisir cette offre', 'evolutionr'),
                        ]);
                        $i++;
                    endwhile; ?>
                </div>
            </div>
        </section>
        <?php
    };
    ?>

    <?php /* ─── Bénéfices (partial factorisé, partagé avec Création & SEO) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-benefices'); ?>

    <?php /* ─── Packs maintenance ─── */ ?>
    <?php if (get_field('packs_enabled') && evolutionr_category_has_offers('maintenance_hebergee')):
        $render_formules(
            (string) get_field('packs_eyebrow'),
            (string) get_field('packs_title'),
            (string) get_field('packs_lede'),
            'packs',
            'maintenance'
        );
    endif; ?>

    <?php /* ─── Hébergement ─── */ ?>
    <?php if (get_field('hosting_enabled') && evolutionr_category_has_offers('maintenance_seule')):
        $render_formules(
            (string) get_field('hosting_eyebrow'),
            (string) get_field('hosting_title'),
            (string) get_field('hosting_lede'),
            'hosting_offers',
            'hebergement',
            true
        );
    endif; ?>

    <?php /* ─── Méthode (partial factorisé, partagé avec Création & SEO) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-methode'); ?>

    <?php /* ─── Mid-CTA (entre hosting et distinction) ─── */ ?>
    <?php evolutionr_render_mid_cta(true); ?>

    <?php /* ─── Distinction (callout) ─── */ ?>
    <?php if (get_field('distinction_enabled')):
        $distEyebrow = (string) get_field('distinction_eyebrow');
        $distTitle   = (string) get_field('distinction_title');
        $distText    = (string) get_field('distinction_text');
        if ($distTitle || $distText): ?>
            <section class="section section--prestation section--no-pad-top" aria-labelledby="distinction-title">
                <div class="container">
                    <?php if ($distEyebrow || $distTitle): ?>
                        <div class="section-head">
                            <div class="section-head-left">
                                <?php if ($distEyebrow): ?>
                                    <div class="section-eyebrow-wrap">
                                        <span class="eyebrow"><?php echo esc_html($distEyebrow); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if ($distTitle): ?>
                                    <h2 class="section-title" id="distinction-title"><?php echo esc_html($distTitle); ?></h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($distText): ?>
                        <div class="page-callout">
                            <p><?php echo esc_html($distText); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif;
    endif; ?>

    <?php /* ─── Non inclus ─── */ ?>
    <?php if (get_field('excluded_enabled') && have_rows('excluded')):
        $excEyebrow  = (string) get_field('excluded_eyebrow');
        $excTitle    = (string) get_field('excluded_title');
        $excLede     = (string) get_field('excluded_lede');
        $excColTitle = (string) get_field('excluded_col_title') ?: __('Hors forfait standard', 'evolutionr');
        $excColSub   = (string) get_field('excluded_col_sub');
        ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="excluded-title">
            <div class="container">

                <?php if ($excEyebrow || $excTitle || $excLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($excEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($excEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($excTitle): ?>
                                <h2 class="section-title" id="excluded-title"><?php echo esc_html($excTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($excLede): ?>
                            <p class="section-lede"><?php echo esc_html($excLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="included-grid">
                    <div class="included-col excluded" style="grid-column: 1 / -1;">
                        <h3>
                            <span class="head-badge no"><?php evolutionr_icon('x', 14); ?></span>
                            <?php echo esc_html($excColTitle); ?>
                        </h3>
                        <?php if ($excColSub): ?><p class="sub"><?php echo esc_html($excColSub); ?></p><?php endif; ?>
                        <ul>
                            <?php while (have_rows('excluded')): the_row();
                                $text = (string) get_sub_field('text');
                                if (!$text) continue;
                                ?>
                                <li><?php evolutionr_icon('x', 16); ?><span><?php echo esc_html($text); ?></span></li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>

            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── FAQ ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-faq'); ?>

    <?php /* ─── CTA final ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-cta-final'); ?>

</main>

<?php get_footer(); ?>
