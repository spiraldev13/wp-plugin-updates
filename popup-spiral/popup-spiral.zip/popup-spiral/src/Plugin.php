<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Point d'entrée du plugin : enregistre chaque composant.
 *
 * Pas de conteneur d'injection ni de couche de services — des classes
 * concrètes hookées directement suffisent à ce périmètre.
 */
final class Plugin
{
    /** @var self|null */
    private static $instance = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
    }

    /**
     * Enregistre tous les composants du plugin.
     */
    public function boot(): void
    {
        PostTypes::register();
        ImageSync::register();
        Frontend::register();
        Rest\TrackController::register();
        Compat\Divi::register();
        Compat\Elementor::register();

        Preview::register();
        AutoExpire::register();

        // Nettoyage des statistiques d'un popup supprimé.
        add_action('before_delete_post', ['\Spiral\Stats\Repository', 'onPostDelete']);

        if (is_admin()) {
            // Filet de sécurité : migre le schéma après une mise à jour sans réactivation.
            add_action('admin_init', ['\Spiral\Install', 'maybeUpgrade']);

            Admin\Assets::register();
            Admin\Metabox::register();
            Admin\Columns::register();
            Admin\Duplicate::register();
            Admin\TestLink::register();
            Admin\DesignsPage::register();
            Admin\SettingsPage::register();
            Admin\ContentSearch::register();
            Admin\StatsPage::register();
            Admin\PresetsPage::register();
        }
    }
}
