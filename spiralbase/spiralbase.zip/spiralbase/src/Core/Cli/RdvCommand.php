<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\Options;
use SpiralBase\Modules\BlocRdv\BlocRdvModule;
use SpiralBase\Modules\BlocRdv\RenduRdv;

/**
 * `wp spiralbase rdv` — la porte qui manquait.
 *
 * L'AC 1 s'ouvre sur « l'URL de la solution de RDV du client **configuré** » :
 * sans écran (Epic 6) ni seed de profil (story 3.9), l'option n'était
 * atteignable que par un `update_option` direct, c'est-à-dire hors de la
 * porte AD-11 que le service `Options` est censé être seul à franchir
 * (revue 3.4). Même besoin, même forme qu'en 2.5 et 3.3.
 *
 * Messages CLI non traduits (convention WP-CLI).
 */
final class RdvCommand
{
    public function __construct(private readonly Options $options)
    {
    }

    /**
     * Enregistre l'adresse de réservation du site.
     *
     * ## OPTIONS
     *
     * <url>
     * : Adresse http(s) de la solution de rendez-vous.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase rdv definir https://rdv.exemple.fr/atelier
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function definir(array $args, array $assocArgs): void
    {
        $url = trim((string) ($args[0] ?? ''));

        /* Le MÊME juge que le rendu : une adresse acceptée ici doit produire
           un bouton, sinon la commande mentirait à l'opérateur. */
        if (RenduRdv::urlAcceptable($url) === '') {
            \WP_CLI::error('Adresse refusée : une URL http(s) complète est attendue (ni javascript:, ni data:, ni adresse relative).');

            return;
        }

        $reglages = $this->options->get(BlocRdvModule::OPTION, []);
        $reglages = is_array($reglages) ? $reglages : [];

        $this->options->set(BlocRdvModule::OPTION, array_merge($reglages, ['url' => $url]), false);

        \WP_CLI::success(sprintf('Adresse de réservation enregistrée : %s', $url));
    }

    /**
     * Affiche l'adresse enregistrée.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase rdv etat
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function etat(array $args, array $assocArgs): void
    {
        $reglages = $this->options->get(BlocRdvModule::OPTION, []);
        $url      = is_array($reglages) ? trim((string) ($reglages['url'] ?? '')) : '';

        \WP_CLI::log($url === ''
            ? 'Aucune adresse de réservation enregistrée : le bloc ne rendra rien.'
            : sprintf('Adresse de réservation : %s', $url));
    }
}
