<?php

declare(strict_types=1);

namespace SpiralBase\Modules\RgpdPagesLegales;

use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\Module;

/**
 * Génération des pages légales (CAP-15, AC 3 story 2.5) : mentions
 * légales (structure LCEN reprise du legacy) et politique de
 * confidentialité, créées en BROUILLON (revue humaine obligatoire),
 * pré-remplies depuis les données métier du noyau, marquées
 * `[À COMPLÉTER : …]` pour tout champ inconnu. Une page existante au
 * même slug n'est JAMAIS écrasée.
 *
 * Sonde `null` : personne ne génère NOS pages légales. L'« activation de
 * la génération » de l'AC = la commande `wp spiralbase rgpd` (aucune UI
 * avant l'epic 6).
 */
final class RgpdPagesLegalesModule implements Module
{
    public function __construct(private readonly DonneesMetier $donnees)
    {
    }

    public function slug(): string
    {
        return 'rgpd_pages_legales';
    }

    public function boot(): void
    {
        if (defined('WP_CLI') && WP_CLI) {
            \WP_CLI::add_command('spiralbase rgpd', new \SpiralBase\Core\Cli\RgpdCommand($this));
        }
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }

    /**
     * @return array{creees: list<string>, sautees: list<string>}|\WP_Error
     */
    public function genererPages(): array|\WP_Error
    {
        $donnees  = $this->donnees->get() ?? [];
        $resultat = ['creees' => [], 'sautees' => []];

        $pages = [
            'mentions-legales'            => [__('Mentions légales', 'spiralbase'), $this->contenuMentions($donnees)],
            'politique-confidentialite'    => [__('Politique de confidentialité', 'spiralbase'), $this->contenuConfidentialite($donnees)],
        ];

        foreach ($pages as $slug => [$titre, $contenu]) {
            /* Slug distinct du natif fr (WP crée « politique-de-confidentialite »
               en brouillon sur toute install française — revue 2.5) ; et seul
               un post_type PAGE compte : get_page_by_path inclut d'office les
               attachments, un PDF au même slug ne doit pas bloquer. */
            $existante = get_page_by_path($slug, OBJECT, 'page');

            if (is_object($existante) && (($existante->post_type ?? '') === 'page')) {
                $resultat['sautees'][] = $slug;

                continue;
            }

            $id = wp_insert_post([
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_name'    => $slug,
                'post_title'   => $titre,
                'post_content' => $contenu,
            ], true);

            if (is_wp_error($id)) {
                /* État partiel restitué : l'opérateur doit savoir ce qui a
                   DÉJÀ été créé avant l'échec (revue 2.5). */
                return new \WP_Error(
                    $id->get_error_code(),
                    $id->get_error_message(),
                    ['creees' => $resultat['creees'], 'sautees' => $resultat['sautees']]
                );
            }

            $resultat['creees'][] = $slug;
        }

        return $resultat;
    }

    /** URL publique du site — WordPress la connaît, autant pré-remplir. */
    private function adresseDuSite(): string
    {
        $url = home_url('/');

        return is_string($url) && trim($url) !== '' ? trim($url) : '[À COMPLÉTER : adresse du site]';
    }

    /** E-mail de contact : celui de l'admin WP par défaut, à ajuster à la revue. */
    private function emailContact(): string
    {
        $email = get_option('admin_email', '');

        return is_string($email) && trim($email) !== '' ? trim($email) : '[À COMPLÉTER : e-mail de contact]';
    }

    /** Valeur métier, ou marqueur explicite — jamais un vide silencieux. */
    private function champ(array $donnees, string $cle, string $libelle): string
    {
        $valeur = $donnees[$cle] ?? '';

        return is_string($valeur) && trim($valeur) !== '' ? trim($valeur) : '[À COMPLÉTER : ' . $libelle . ']';
    }

    private function adresse(array $donnees): string
    {
        $adresse = is_array($donnees['adresse'] ?? null) ? $donnees['adresse'] : [];
        $morceaux = array_filter([
            is_string($adresse['rue'] ?? null) ? trim($adresse['rue']) : '',
            trim((is_string($adresse['code_postal'] ?? null) ? $adresse['code_postal'] : '') . ' ' . (is_string($adresse['ville'] ?? null) ? $adresse['ville'] : '')),
        ], static fn (string $m): bool => $m !== '');

        return $morceaux === [] ? '[À COMPLÉTER : adresse]' : implode(', ', $morceaux);
    }

    private function p(string $texte): string
    {
        return '<!-- wp:paragraph --><p>' . $texte . '</p><!-- /wp:paragraph -->';
    }

    private function h2(string $texte): string
    {
        return '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">' . $texte . '</h2><!-- /wp:heading -->';
    }

    /** Structure LCEN du legacy (docs/brownfield-legacy), données du client remplacées. */
    private function contenuMentions(array $d): string
    {
        $nom       = esc_html($this->champ($d, 'nom', 'nom de la structure'));
        $adresse   = esc_html($this->adresse($d));
        $telephone = esc_html($this->champ($d, 'telephone', 'téléphone'));

        return implode('', [
            $this->p(sprintf(__('Conformément aux articles 6-III et 19 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l\'économie numérique (L.C.E.N.), les informations suivantes sont portées à la connaissance des utilisateurs du site %s.', 'spiralbase'), esc_html($this->adresseDuSite()))),
            $this->h2(__('Informations légales', 'spiralbase')),
            $this->p(sprintf(__('Nom de la structure : %s', 'spiralbase'), $nom)),
            $this->p(sprintf(__('Forme juridique : %s', 'spiralbase'), '[À COMPLÉTER : forme juridique]')),
            $this->p(sprintf(__('Adresse : %s', 'spiralbase'), $adresse)),
            $this->p(sprintf(__('Téléphone : %s', 'spiralbase'), $telephone)),
            $this->p(sprintf(__('SIRET : %s', 'spiralbase'), '[À COMPLÉTER : SIRET]')),
            $this->p(sprintf(__('Adresse de courrier électronique : %s', 'spiralbase'), esc_html($this->emailContact()))),
            $this->p(sprintf(__('Directeur de la publication : %s', 'spiralbase'), '[À COMPLÉTER : directeur de la publication]')),
            $this->h2(__('Hébergeur', 'spiralbase')),
            $this->p('[À COMPLÉTER : nom, raison sociale et adresse de l\'hébergeur]'),
            $this->h2(__('Propriété intellectuelle', 'spiralbase')),
            $this->p(sprintf(__('L\'ensemble de ce site (structure, textes, images) constitue une œuvre protégée par la législation en vigueur sur la propriété intellectuelle. Toute reproduction, même partielle, est soumise à l\'autorisation préalable de %s.', 'spiralbase'), $nom)),
            $this->h2(__('Données personnelles et cookies', 'spiralbase')),
            $this->p(__('Les traitements de données personnelles et l\'usage des cookies sont détaillés dans la politique de confidentialité du site.', 'spiralbase')),
        ]);
    }

    private function contenuConfidentialite(array $d): string
    {
        $nom = esc_html($this->champ($d, 'nom', 'nom de la structure'));

        return implode('', [
            $this->p(sprintf(__('La présente politique décrit comment %s collecte et traite les données personnelles des visiteurs de ce site, conformément au Règlement général sur la protection des données (RGPD).', 'spiralbase'), $nom)),
            $this->h2(__('Responsable du traitement', 'spiralbase')),
            $this->p(sprintf(__('%1$s — %2$s. Contact : %3$s', 'spiralbase'), $nom, esc_html($this->adresse($d)), '[À COMPLÉTER : e-mail de contact]')),
            $this->h2(__('Données collectées et finalités', 'spiralbase')),
            $this->p('[À COMPLÉTER : lister les données collectées (formulaire de contact, mesure d\'audience…) et leurs finalités]'),
            $this->h2(__('Durées de conservation', 'spiralbase')),
            $this->p('[À COMPLÉTER : durées de conservation par type de donnée]'),
            $this->h2(__('Cookies', 'spiralbase')),
            $this->p(__('Lorsque des traceurs soumis à consentement sont utilisés, un bandeau permet d\'accepter ou de refuser leur dépôt avant tout chargement. Le choix est enregistré dans le cookie « spiralbase_consentement » (exempté de consentement) pour une durée de six mois (182 jours), et peut être retiré à tout moment via le lien « Gérer mes cookies » du site.', 'spiralbase')),
            $this->h2(__('Vos droits', 'spiralbase')),
            $this->p(__('Vous disposez d\'un droit d\'accès, de rectification, d\'effacement, de limitation et d\'opposition sur vos données. Vous pouvez l\'exercer auprès du responsable du traitement, et introduire une réclamation auprès de la CNIL.', 'spiralbase')),
        ]);
    }
}
