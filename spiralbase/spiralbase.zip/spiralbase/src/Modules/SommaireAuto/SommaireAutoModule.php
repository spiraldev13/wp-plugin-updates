<?php

declare(strict_types=1);

namespace SpiralBase\Modules\SommaireAuto;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;
use SpiralBase\Core\Walker;

/**
 * Sommaire automatique (CAP-9, story 2.7) : une TRANSFORMATION pose les
 * `id` manquants sur les h2/h3 (les id existants font foi — l'ancre du
 * contexte), une INSERTION rend le nav cliquable AVANT le premier heading
 * (AD-10 : tout passe par le walker).
 *
 * Sonde (faits LUS dans le plugin réel Easy Table of Contents) : ETOC
 * insère AUTOMATIQUEMENT sur les types de `auto_insert_post_types` — les
 * DÉFAUTS réels sont `['post','page']` (`class-eztoc-option.php:1889`,
 * corrigé en revue 2.7 : l'option n'est semée qu'à `admin_init`, un ETOC
 * activé en CLI n'a PAS l'option en base et applique ses défauts → option
 * absente = cession, double sommaire reproduit sinon). Limite documentée :
 * l'insertion MANUELLE (shortcode/bloc ETOC posé dans un article) est
 * invisible à la sonde — l'AC vise l'insertion automatique.
 */
final class SommaireAutoModule implements Module
{
    public const OPTION = 'spiralbase_sommaire';

    public function __construct(
        private readonly Walker $walker,
        private readonly Options $options,
        private readonly ?\Closure $faitEtoc = null,
        private readonly Sommaire $sommaire = new Sommaire(),
    ) {
    }

    public function slug(): string
    {
        return 'sommaire_auto';
    }

    public function boot(): void
    {
        $this->walker->addTransformation(
            'sommaire_ancres',
            fn (string $contenu, array $contexte): string => $this->poserAncres($contenu, $contexte)
        );

        $this->walker->addInsertion(
            'sommaire',
            Walker::POINT_AVANT_HEADING,
            fn (array $contexte): string => $this->rendre($contexte)
        );
    }

    public function defaultSettings(): array
    {
        return ['minimum_headings' => 3];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitEtoc ?? static function (): bool {
                if (!defined('EZ_TOC_PATH')) {
                    return false;
                }

                $reglages = get_option('ez-toc-settings', null);

                /* Option absente (activation CLI, admin jamais visité) :
                   ETOC applique ses DÉFAUTS, qui couvrent `post`. */
                if (!is_array($reglages)) {
                    return true;
                }

                $types = is_array($reglages['auto_insert_post_types'] ?? null) ? $reglages['auto_insert_post_types'] : [];

                return in_array('post', $types, true);
            },
            static fn (): string => __('Sommaire réellement inséré par Easy Table of Contents.', 'spiralbase')
        );
    }

    /**
     * Pose les id MANQUANTS sur les h2/h3, dans l'ordre du contexte.
     * ALIGNEMENT GARANTI (revue 2.7, désalignement prouvé sinon) : les
     * ouvreurs sont repérés sur le contenu MASQUÉ (zones inertes ignorées,
     * comme l'analyse), seuls les éléments COMPLETS comptent (un heading
     * jamais fermé est exclu du contexte), et si les séquences divergent
     * quand même, RIEN n'est posé (le nav ne se rend pas non plus) — une
     * exception signale via le walker.
     */
    private function poserAncres(string $contenu, array $contexte): string
    {
        $this->ancresPosees = false;
        $headings = $this->headingsEligibles($contexte);

        if (count($headings) < $this->minimum()) {
            return $contenu;
        }

        $ouvreurs = $this->ouvreursAlignes($contenu, count($headings));

        if ($ouvreurs === null) {
            throw new \RuntimeException('sommaire : séquence de headings désalignée du contexte — ancres non posées');
        }

        $resolus = $this->resolus($contexte);
        $sortie  = $contenu;

        /* Du dernier au premier : les offsets restent valides pendant l'édition. */
        foreach (array_reverse($ouvreurs, true) as $rang => $ouvreur) {
            [$offset, $longueur, $niveau, $attrs] = $ouvreur;
            $resolu = $resolus[$rang] ?? null;

            if ($resolu === null || $this->porteUnId($attrs)) {
                continue;
            }

            $remplacement = '<h' . $niveau . $attrs . ' id="' . esc_attr($resolu['ancre']) . '">';
            $sortie       = substr($sortie, 0, $offset) . $remplacement . substr($sortie, $offset + $longueur);
        }

        $this->ancresPosees = true;

        return $sortie;
    }

    /**
     * Ouvreurs h2/h3 d'ÉLÉMENTS COMPLETS repérés sur le contenu masqué —
     * null si leur nombre diverge du contexte (alignement invérifiable).
     *
     * @return list<array{0: int, 1: int, 2: string, 3: string}>|null
     */
    private function ouvreursAlignes(string $contenu, int $attendus): ?array
    {
        $masque = $this->walker->masquerZonesInertes($contenu);

        if (preg_match_all('/<h([23])\b((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>.*?<\/h\1\s*>/is', $masque, $m, PREG_OFFSET_CAPTURE) === false) {
            return null;
        }

        if (count($m[0]) !== $attendus) {
            return null;
        }

        $ouvreurs = [];

        foreach ($m[0] as $i => $element) {
            $niveau   = $m[1][$i][0];
            $attrs    = $m[2][$i][0];
            $longueur = strlen('<h' . $niveau . $attrs . '>');
            $ouvreurs[] = [(int) $element[1], $longueur, $niveau, $attrs];
        }

        return $ouvreurs;
    }

    /** Un attribut id réel — les valeurs entre guillemets sont d'abord retirées (`title="mon id = 1"` ne compte pas). */
    private function porteUnId(string $attrs): bool
    {
        $sansValeurs = (string) preg_replace('/"[^"]*"|\'[^\']*\'/', '', $attrs);

        return (bool) preg_match('/(^|\s)id\b/i', $sansValeurs);
    }

    /**
     * Nav du sommaire depuis le CONTEXTE — rien sous le seuil. Si la pose
     * des ancres a échoué (désalignement signalé), le nav ne se rend pas
     * non plus : le walker saute l'opération fautive et l'insertion lit le
     * même contexte — cohérence garantie par le référentiel partagé.
     */
    private function rendre(array $contexte): string
    {
        /* La pose a échoué (désalignement signalé par le walker) : un nav
           aux liens morts serait pire que pas de sommaire. */
        if (!$this->ancresPosees) {
            return '';
        }

        $headings = $this->headingsEligibles($contexte);

        if (count($headings) < $this->minimum()) {
            return '';
        }

        $items = '';

        foreach ($this->resolus($contexte) as $heading) {
            /* Un heading sans texte (image seule) ne produit jamais un lien vide. */
            if (trim($heading['texte']) === '') {
                continue;
            }

            $items .= '<li class="spiralbase-sommaire__n' . (int) $heading['niveau'] . '">'
                . '<a href="#' . esc_attr($heading['ancre']) . '">' . esc_html($heading['texte']) . '</a></li>';
        }

        if ($items === '') {
            return '';
        }

        return '<nav class="spiralbase-sommaire" aria-label="' . esc_attr__('Sommaire', 'spiralbase') . '"><ol>' . $items . '</ol></nav>';
    }

    /** @var list<array{niveau: int, texte: string, ancre: string}>|null mémo par requête */
    private ?array $resolusMemo = null;

    /** La transformation a-t-elle abouti ? (transformations AVANT insertions, même instance) */
    private bool $ancresPosees = false;

    /** Résolution UNIQUE par requête : pose et nav lisent le même résultat. */
    private function resolus(array $contexte): array
    {
        return $this->resolusMemo ??= $this->sommaire->resoudreAncres($this->headingsEligibles($contexte));
    }

    /** @return list<array{niveau: int, texte: string, ancre: ?string}> */
    private function headingsEligibles(array $contexte): array
    {
        $headings = is_array($contexte['headings'] ?? null) ? $contexte['headings'] : [];

        return array_values(array_filter($headings, static fn ($h): bool => is_array($h) && in_array((int) ($h['niveau'] ?? 0), [2, 3], true)));
    }

    private function minimum(): int
    {
        $reglages = $this->options->get(self::OPTION, []);
        $minimum  = is_array($reglages) && is_numeric($reglages['minimum_headings'] ?? null) ? (int) $reglages['minimum_headings'] : 0;

        return $minimum > 0 ? $minimum : (int) $this->defaultSettings()['minimum_headings'];
    }
}
