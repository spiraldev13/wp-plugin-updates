<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('evolutionr_register_taxonomies')) {
    function evolutionr_register_taxonomies(): void
    {
        register_taxonomy('secteur', ['realisation'], [
            'labels' => [
                'name'              => __('Secteurs', 'evolutionr'),
                'singular_name'     => __('Secteur', 'evolutionr'),
                'search_items'      => __('Chercher un secteur', 'evolutionr'),
                'all_items'         => __('Tous les secteurs', 'evolutionr'),
                'edit_item'         => __('Modifier le secteur', 'evolutionr'),
                'update_item'       => __('Mettre à jour', 'evolutionr'),
                'add_new_item'      => __('Ajouter un secteur', 'evolutionr'),
                'new_item_name'     => __('Nouveau secteur', 'evolutionr'),
                'menu_name'         => __('Secteurs', 'evolutionr'),
            ],
            'public'            => true,
            'hierarchical'      => true,
            'show_admin_column' => true,
            'show_in_rest'      => true,
            'rewrite'           => ['slug' => 'secteur', 'with_front' => false],
        ]);
    }
}

add_action('init', 'evolutionr_register_taxonomies');
