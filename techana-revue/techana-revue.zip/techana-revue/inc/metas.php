<?php
/**
 * Métas éditoriales _techana_* — enregistrement REST + calculs à l'enregistrement.
 *
 * Les clés préfixées « _ » sont protégées par WordPress : l'`auth_callback`
 * est obligatoire pour les rendre éditables (éditeur, API REST, bindings).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'techanaRevueRegisterMetas' );
add_action( 'save_post_post', 'techanaRevueComputeMots', 10, 2 );
add_action( 'enqueue_block_editor_assets', 'techanaRevueMetasEditeur' );

/**
 * Panneau « TechAna » de la barre latérale d'article (case « Afficher à la
 * une »). Restreint à l'écran d'édition d'article : le hook se déclenche aussi
 * dans l'éditeur de site, où le panneau n'a rien à faire.
 */
function techanaRevueMetasEditeur() {
    $ecran = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( ! $ecran || 'post' !== $ecran->post_type ) {
        return;
    }
    wp_enqueue_script(
        'techana-revue-editeur-une',
        get_theme_file_uri( 'assets/js/editeur-une.js' ),
        array( 'wp-plugins', 'wp-editor', 'wp-edit-post', 'wp-components', 'wp-data', 'wp-element' ),
        TECHANA_REVUE_VERSION,
        true
    );
    // La liste des encarts est passée au script plutôt qu'ouverte à l'API REST :
    // `techana_encart` est volontairement fermé (aucun encart n'a d'URL), et
    // peupler une liste déroulante ne justifie pas d'élargir sa surface.
    wp_add_inline_script(
        'techana-revue-editeur-une',
        'window.techanaRevueEncarts = ' . wp_json_encode( techanaRevueEncartsPublies() ) . ';',
        'before'
    );
}

/**
 * Compte les mots d'un contenu rendu. preg plutôt que str_word_count :
 * ce dernier ampute les mots accentués français sans charlist exhaustive.
 */
function techanaRevueWordCount( string $content ): int {
    $texte = wp_strip_all_tags( strip_shortcodes( $content ) );
    return (int) preg_match_all( '/\S+/u', $texte );
}

/**
 * Temps de lecture en minutes — mots / 200, minimum 1 (integration-wordpress.md).
 */
function techanaRevueTempsLecture( int $postId ): int {
    $mots = (int) get_post_meta( $postId, '_techana_mots', true );
    if ( $mots < 1 ) {
        $mots = techanaRevueWordCount( get_post_field( 'post_content', $postId ) );
    }
    return max( 1, (int) round( $mots / 200 ) );
}

function techanaRevueRegisterMetas() {
    $peutEditer = static function () {
        return current_user_can( 'edit_posts' );
    };

    $simples = array(
        '_techana_une'             => array( 'type' => 'boolean', 'default' => false ),
        '_techana_mots'            => array( 'type' => 'integer', 'default' => 0 ),
        '_techana_vues'            => array( 'type' => 'integer', 'default' => 0 ),
        '_techana_sponsorise'      => array( 'type' => 'boolean', 'default' => false ),
        '_techana_annonceur_nom'   => array( 'type' => 'string', 'default' => '' ),
        '_techana_annonceur_texte' => array( 'type' => 'string', 'default' => '' ),
        '_techana_annonceur_url'   => array( 'type' => 'string', 'default' => '' ),
    );
    foreach ( $simples as $cle => $def ) {
        register_post_meta( 'post', $cle, array(
            'show_in_rest'  => true,
            'single'        => true,
            'type'          => $def['type'],
            'default'       => $def['default'],
            'auth_callback' => $peutEditer,
        ) );
    }

    // Encart épinglé sur cet article : il l'emporte sur le ciblage par rubrique,
    // pour son seul emplacement (cf. inc/publicite.php).
    register_post_meta( 'post', '_techana_encart_epingle', array(
        'show_in_rest'      => true,
        'single'            => true,
        'type'              => 'integer',
        'default'           => 0,
        'auth_callback'     => $peutEditer,
        'sanitize_callback' => 'techanaRevueEncartEpingleValide',
    ) );
    register_post_meta( 'post', '_techana_encart_epingle_position', array(
        'show_in_rest'      => true,
        'single'            => true,
        'type'              => 'string',
        'default'           => 'corps',
        'auth_callback'     => $peutEditer,
        'sanitize_callback' => 'techanaRevueEncartEpinglePositionValide',
    ) );

    // « En bref » : 5 entrées libres affichées en tête d'article.
    register_post_meta( 'post', '_techana_en_bref', array(
        'single'        => true,
        'type'          => 'array',
        'default'       => array(),
        'auth_callback' => $peutEditer,
        'show_in_rest'  => array(
            'schema' => array(
                'type'     => 'array',
                'items'    => array( 'type' => 'string' ),
                'maxItems' => 5,
            ),
        ),
    ) );

    // FAQ : paires question / réponse, source du bloc techana/faq ET du JSON-LD.
    register_post_meta( 'post', '_techana_faq', array(
        'single'        => true,
        'type'          => 'array',
        'default'       => array(),
        'auth_callback' => $peutEditer,
        'show_in_rest'  => array(
            'schema' => array(
                'type'  => 'array',
                'items' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'question' => array( 'type' => 'string' ),
                        'reponse'  => array( 'type' => 'string' ),
                    ),
                ),
            ),
        ),
    ) );

    // Tampon de version des pages légales — incrémenté à la main à chaque révision.
    register_post_meta( 'page', '_techana_version', array(
        'show_in_rest'  => true,
        'single'        => true,
        'type'          => 'string',
        'default'       => '',
        'auth_callback' => $peutEditer,
    ) );

    // Clé de rubrique : slug court porté par la classe k-* (couleur par rubrique).
    register_term_meta( 'category', '_techana_cle', array(
        'show_in_rest'  => true,
        'single'        => true,
        'type'          => 'string',
        'default'       => '',
        'auth_callback' => $peutEditer,
    ) );
}

/**
 * Identifiant d'encart épinglé, ou 0.
 *
 * Un identifiant qui ne désigne pas un encart (article, pièce jointe, contenu
 * supprimé) est refusé plutôt que stocké : la sélection n'aurait rien à rendre
 * et l'article garderait une référence morte.
 *
 * @param mixed $valeur Valeur postée.
 */
function techanaRevueEncartEpingleValide( $valeur ): int {
    $id = absint( $valeur );
    if ( ! $id || TECHANA_ENCART_TYPE !== get_post_type( $id ) ) {
        return 0;
    }
    return $id;
}

/**
 * Emplacement de l'encart épinglé : le corps de l'article ou son pied.
 *
 * @param mixed $valeur Valeur postée.
 */
function techanaRevueEncartEpinglePositionValide( $valeur ): string {
    return in_array( $valeur, array( 'corps', 'pied' ), true ) ? (string) $valeur : 'corps';
}

/**
 * _techana_mots recalculé à chaque enregistrement — jamais saisi à la main.
 */
function techanaRevueComputeMots( int $postId, WP_Post $post ) {
    if ( wp_is_post_revision( $postId ) || wp_is_post_autosave( $postId ) ) {
        return;
    }
    update_post_meta( $postId, '_techana_mots', techanaRevueWordCount( $post->post_content ) );
}
