# Tâches

> Ce fichier est géré par Claude Code.
> Claude rédige les plans ici avant d'implémenter, et coche les items au fur et à mesure.

---

## Plan actif

<!-- Claude écrit le plan courant ici avant de démarrer le travail -->

_Aucun plan actif. Utilise `/project:planifier [description de la tâche]` pour en créer un._

---

## Tâches terminées

<!-- Les plans terminés sont déplacés ici avec un résumé de ce qui a été fait -->

---

## Modèle de plan

```markdown
# Plan : [Nom de la tâche]
Date : YYYY-MM-DD

## Objectif
[Une phrase : à quoi ressemble le succès]

## Étapes
- [ ] 1. ...
- [ ] 2. ...
- [ ] 3. ...

## Vérification
- [ ] Tests passent
- [ ] Lint passe
- [ ] Vérification manuelle : [décrire]

## Bilan
[Ajouté après la complétion : ce qui a été fait, ce qui était plus difficile que prévu]
```
