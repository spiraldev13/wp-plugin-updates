<?php
/**
 * Archive de catégorie — `/category/<slug>/`.
 *
 * Même structure visuelle que `home.php` (eyebrow constant + H1 + pills +
 * grille). Le H1 reflète la catégorie courante et le lede reprend sa
 * description si elle est renseignée en BO (Articles → Catégories).
 * Délègue le rendu de la grille au partial commun.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$description = category_description();
?>

<section class="section">
    <div class="container">
        <?php evolutionr_breadcrumb(); ?>

        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php esc_html_e('Journal & conseils', 'evolutionr'); ?></span>
                </div>
                <h1 class="section-title"><?php echo esc_html(single_cat_title('', false)); ?></h1>
            </div>
            <?php if ($description): ?>
                <div class="section-lede"><?php echo wp_kses_post($description); ?></div>
            <?php endif; ?>
        </header>

        <?php get_template_part('template-parts/blog/pills-filters'); ?>

        <?php get_template_part('template-parts/blog/articles-grid'); ?>
    </div>
</section>

<?php get_footer(); ?>
