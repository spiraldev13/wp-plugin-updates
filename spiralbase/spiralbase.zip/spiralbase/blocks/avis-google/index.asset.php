<?php

/*
 * Manifeste d'asset ÉCRIT À LA MAIN (pas de build — AD-12, pattern 2.9/3.1).
 * Sans lui, WordPress chargerait le script sans ses dépendances et
 * window.wp.blocks serait indéfini dans l'éditeur.
 *
 * La version suit celle du THÈME, jamais un numéro figé : le cœur en fait le
 * `?ver=` du script (`wp-includes/blocks.php` — `$script_asset['version']`
 * l'emporte sur la version du bloc). Gelée, une correction livrée par une
 * release de la flotte continuerait d'être servie depuis les caches
 * (garde-fou testé : AssetsBlocsTest).
 */
return [
    'dependencies' => ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render'],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
