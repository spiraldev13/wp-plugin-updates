<?php

namespace Spiral\Designs;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Transforme les réglages d'un design en CSS scopé `.spiral-design-{slug}`.
 *
 * Le design n'émet que des variables CSS (+ image de fond éventuelle) :
 * toute la structure vit dans assets/spiral.css, qui consomme ces variables.
 */
final class CssGenerator
{
    private const RADII = ['square' => '0', 'rounded' => '12px', 'pill' => '28px'];

    private const SHADOWS = [
        'none' => 'none',
        'soft' => '0 8px 30px rgba(0, 0, 0, 0.15)',
        'strong' => '0 16px 55px rgba(0, 0, 0, 0.35)',
    ];

    private const MODERN_FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";

    public static function generate(string $slug, array $settings, string $customCss = ''): string
    {
        $scope = '.spiral-design-' . sanitize_html_class($slug);
        $vars = [];

        if ($settings['corners'] === 'custom') {
            $vars[] = '--spiral-radius: ' . max(0, (int) ($settings['corners_radius'] ?? 16)) . 'px';
        } else {
            $vars[] = '--spiral-radius: ' . (self::RADII[$settings['corners']] ?? '12px');
        }

        if ($settings['shadow'] === 'custom') {
            $blur = max(0, (int) ($settings['shadow_blur'] ?? 40));
            $opacity = max(0, min(100, (int) ($settings['shadow_opacity'] ?? 25))) / 100;
            $vars[] = '--spiral-shadow: 0 12px ' . $blur . 'px rgba(0, 0, 0, ' . $opacity . ')';
        } else {
            $vars[] = '--spiral-shadow: ' . (self::SHADOWS[$settings['shadow']] ?? 'none');
        }

        $vars[] = '--spiral-accent: ' . $settings['accent'];

        if (!empty($settings['neutral'])) {
            // Design neutre : le contenu (builder) impose son propre style,
            // le design ne fournit que le cadre.
            $vars[] = '--spiral-bg: transparent';
            $vars[] = '--spiral-text: inherit';
            $vars[] = '--spiral-font: inherit';
            $vars[] = '--spiral-padding: 0';
        } else {
            $textColor = !empty($settings['text'])
                ? $settings['text']
                : self::readableTextColor($settings['bg']);

            $vars[] = '--spiral-bg: ' . $settings['bg'];
            $vars[] = '--spiral-text: ' . $textColor;
            $vars[] = '--spiral-font: ' . ($settings['font'] === 'modern' ? self::MODERN_FONT : 'inherit');
            $vars[] = '--spiral-padding: 28px';
        }

        if (!empty($settings['btn_text'])) {
            $vars[] = '--spiral-btn-text: ' . $settings['btn_text'];
        }

        if (!empty($settings['close_color'])) {
            $vars[] = '--spiral-close-color: ' . $settings['close_color'];
        }

        if (!empty($settings['close_bg'])) {
            $vars[] = '--spiral-close-bg: ' . $settings['close_bg'];
        }

        if (!empty($settings['close_hover_color'])) {
            $vars[] = '--spiral-close-hover-color: ' . $settings['close_hover_color'];
        }

        if (!empty($settings['close_hover_bg'])) {
            $vars[] = '--spiral-close-hover-bg: ' . $settings['close_hover_bg'];
        }

        $border = (string) ($settings['border'] ?? 'none');

        if ($border !== 'none') {
            $borderColor = !empty($settings['border_color']) ? $settings['border_color'] : $settings['accent'];
            $borderWidths = ['thin' => '1px', 'thick' => '3px'];
            $borderWidth = $border === 'custom'
                ? max(1, (int) ($settings['border_width'] ?? 2)) . 'px'
                : ($borderWidths[$border] ?? '1px');
            $vars[] = '--spiral-border: ' . $borderWidth . ' solid ' . $borderColor;
        }

        $css = $scope . ' { ' . implode('; ', $vars) . '; }';

        if (!empty($settings['close_underline'])) {
            $css .= "\n" . $scope . ' .spiral-close, ' . $scope . ' .spiral-close:hover { text-decoration: underline; }';
        }

        if ($customCss !== '') {
            // Le nesting CSS natif scope tout le bloc, y compris les @media.
            $css .= "\n" . $scope . " {\n" . $customCss . "\n}";
        }

        return $css;
    }

    /**
     * Texte sombre sur fond clair, texte clair sur fond sombre.
     * Publique : sert aussi à préremplir le créateur de designs.
     */
    public static function readableTextColor(string $hex): string
    {
        $hex = ltrim($hex, '#');

        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        if (strlen($hex) !== 6 || !ctype_xdigit($hex)) {
            return '#1e293b';
        }

        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        $luminance = (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255;

        return $luminance > 0.55 ? '#1e293b' : '#f8fafc';
    }
}
