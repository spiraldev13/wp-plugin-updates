<?php

declare(strict_types=1);

namespace SpiralBase\Modules\SiteHealth;

use SpiralBase\Core\Module;
use SpiralBase\Core\Registry;
use SpiralBase\Core\Updater;
use SpiralBase\Core\Walker;

/**
 * Diagnostics spiralbase dans l'écran natif Outils → Santé du site —
 * structure reprise d'ultimate-shanks (register_tests + fabrique de
 * résultat), tests adaptés au parent : manifeste, version, registre.
 *
 * Premier module de production du parent : il ne dépend que du noyau, par
 * injection (AD-4), et se désactive comme n'importe quel autre (AD-1).
 *
 * Un outil de diagnostic ne doit jamais tomber avant le sujet qu'il
 * observe : chaque test attrape ses propres erreurs et rend un verdict
 * plutôt qu'une exception. Les deux tests qui interrogent le réseau sont
 * déclarés `async` — un test `direct` bloquerait le rendu de l'écran
 * jusqu'au timeout HTTP.
 */
final class SiteHealthModule implements Module
{
    public const TEST_MANIFESTE = 'spiralbase_manifeste';
    public const TEST_VERSION = 'spiralbase_version';
    public const TEST_REGISTRE = 'spiralbase_registre';

    private const STATUT_BON = 'good';
    private const STATUT_CONSEILLE = 'recommended';
    private const STATUT_CRITIQUE = 'critical';

    public function __construct(
        private readonly Registry $registre,
        private readonly Updater $updater,
        private readonly ?Walker $walker = null,
    ) {
    }

    public function slug(): string
    {
        return 'site_health';
    }

    public function boot(): void
    {
        add_filter('site_status_tests', [$this, 'enregistrerTests']);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        /* Un diagnostic propre au thème ne cède devant aucun tiers. */
        return null;
    }

    /**
     * @param mixed $tests tableau de tests WordPress (filtre public : le
     *                     type n'est pas garanti par un tiers en amont)
     *
     * @return array<string, mixed>
     */
    public function enregistrerTests(mixed $tests): array
    {
        if (!is_array($tests)) {
            error_log('[spiralbase] site_status_tests corrompu par un filtre amont — repartir d\'une liste vide.');
            $tests = [];
        }

        foreach (['direct', 'async'] as $groupe) {
            if (!isset($tests[$groupe]) || !is_array($tests[$groupe])) {
                $tests[$groupe] = [];
            }
        }

        /* Réseau : async — un test direct fige l'écran jusqu'au timeout. */
        $tests['async'][self::TEST_MANIFESTE] = [
            'label'             => __('spiralbase : manifeste de mise à jour', 'spiralbase'),
            'test'              => self::TEST_MANIFESTE,
            'has_rest'          => false,
            'async_direct_test' => [$this, 'testerManifeste'],
        ];
        $tests['async'][self::TEST_VERSION] = [
            'label'             => __('spiralbase : version du thème parent', 'spiralbase'),
            'test'              => self::TEST_VERSION,
            'has_rest'          => false,
            'async_direct_test' => [$this, 'testerVersion'],
        ];

        /* Purement local : aucun appel distant, donc direct. */
        $tests['direct'][self::TEST_REGISTRE] = [
            'label' => __('spiralbase : modules du thème', 'spiralbase'),
            'test'  => [$this, 'testerRegistre'],
        ];

        return $tests;
    }

    /** @return array<string, mixed> */
    public function testerManifeste(): array
    {
        $manifeste = $this->manifeste();

        if ($manifeste === null) {
            return $this->resultat(
                self::TEST_MANIFESTE,
                self::STATUT_CONSEILLE,
                __('Le manifeste de mise à jour est indisponible', 'spiralbase'),
                __('Tant que le manifeste reste injoignable, aucune mise à jour du thème parent ne sera détectée sur ce site.', 'spiralbase'),
                __('Sécurité', 'spiralbase')
            );
        }

        return $this->resultat(
            self::TEST_MANIFESTE,
            self::STATUT_BON,
            __('Le manifeste de mise à jour est accessible', 'spiralbase'),
            sprintf(
                /* translators: %s : version publiée au manifeste. */
                __('Version publiée : %s.', 'spiralbase'),
                $this->versionPubliee($manifeste)
            ),
            __('Sécurité', 'spiralbase')
        );
    }

    /** @return array<string, mixed> */
    public function testerVersion(): array
    {
        $installee = trim($this->updater->versionInstallee());
        $manifeste = $this->manifeste();
        $publiee   = $manifeste === null ? '' : $this->versionPubliee($manifeste);

        if ($installee === '') {
            return $this->resultat(
                self::TEST_VERSION,
                self::STATUT_CRITIQUE,
                __('La version installée est illisible', 'spiralbase'),
                __('L\'en-tête « Version » du style.css du thème parent est absent ou vide : aucune mise à jour ne peut être proposée.', 'spiralbase'),
                __('Performance', 'spiralbase')
            );
        }

        if ($publiee === '') {
            return $this->resultat(
                self::TEST_VERSION,
                self::STATUT_CONSEILLE,
                __('La version publiée est inconnue', 'spiralbase'),
                sprintf(
                    /* translators: %s : version installée. */
                    __('Version installée : %s. Le manifeste étant injoignable, impossible de dire si elle est à jour.', 'spiralbase'),
                    $installee
                ),
                __('Performance', 'spiralbase')
            );
        }

        $comparaison = version_compare($this->normaliser($installee), $this->normaliser($publiee));

        if ($comparaison === 0) {
            return $this->resultat(
                self::TEST_VERSION,
                self::STATUT_BON,
                __('Le thème parent est à jour', 'spiralbase'),
                sprintf(
                    /* translators: %s : version installée. */
                    __('Version installée et publiée : %s.', 'spiralbase'),
                    $installee
                ),
                __('Performance', 'spiralbase')
            );
        }

        if ($comparaison > 0) {
            return $this->resultat(
                self::TEST_VERSION,
                self::STATUT_CONSEILLE,
                __('Ce site est en avance sur le manifeste', 'spiralbase'),
                sprintf(
                    /* translators: 1: version installée, 2: version publiée. */
                    __('Version installée %1$s, publiée %2$s — aucune mise à jour ne sera proposée tant que le manifeste n\'aura pas dépassé la version installée. Une mise à jour ne fait jamais reculer un site ; un retour arrière est une opération manuelle.', 'spiralbase'),
                    $installee,
                    $publiee
                ),
                __('Performance', 'spiralbase')
            );
        }

        return $this->resultat(
            self::TEST_VERSION,
            self::STATUT_CONSEILLE,
            __('Une mise à jour du thème parent est disponible', 'spiralbase'),
            sprintf(
                /* translators: 1: version installée, 2: version publiée. */
                __('Version installée %1$s, publiée %2$s.', 'spiralbase'),
                $installee,
                $publiee
            ),
            __('Performance', 'spiralbase')
        );
    }

    /** @return array<string, mixed> */
    public function testerRegistre(): array
    {
        try {
            $etats = $this->registre->states();
        } catch (\Throwable $e) {
            /* Le noyau n'a pas fini de démarrer : c'est LA panne à diagnostiquer. */
            return $this->resultat(
                self::TEST_REGISTRE,
                self::STATUT_CRITIQUE,
                __('L\'état des modules est illisible', 'spiralbase'),
                sprintf(
                    /* translators: %s : message d'erreur technique. */
                    __('Le noyau du thème n\'a pas démarré normalement : %s', 'spiralbase'),
                    $e->getMessage()
                ),
                __('Performance', 'spiralbase')
            );
        }

        $actifs     = count(array_filter($etats, static fn (string $e): bool => $e === Registry::ETAT_ACTIF));
        $cedes      = count(array_filter($etats, static fn (string $e): bool => $e === Registry::ETAT_CEDE));
        $desactives = count(array_filter($etats, static fn (string $e): bool => $e === Registry::ETAT_DESACTIVE));

        $description = sprintf(
            /* translators: 1: nombre de modules actifs, 2: cédés, 3: désactivés. */
            __('Modules actifs : %1$d. Cédés à une extension tierce : %2$d. Désactivés : %3$d.', 'spiralbase'),
            $actifs,
            $cedes,
            $desactives
        );

        $raisons = [];

        foreach ($etats as $slug => $etat) {
            if ($etat === Registry::ETAT_CEDE) {
                $raisons[] = sprintf('%s (%s)', (string) $slug, (string) $this->registre->cessionReason((string) $slug));
            }
        }

        if ($raisons !== []) {
            $description .= ' ' . sprintf(
                /* translators: %s : liste des modules cédés avec leur raison. */
                __('Détail des cessions : %s.', 'spiralbase'),
                implode(', ', $raisons)
            );
        }

        $echecsWalker = $this->walker === null ? [] : $this->walker->derniersEchecs();

        if ($echecsWalker !== []) {
            $description .= ' ' . sprintf(
                /* translators: %s : liste des opérations de contenu en échec. */
                __('Opérations de contenu en échec : %s.', 'spiralbase'),
                implode(', ', array_keys($echecsWalker))
            );
        }

        /*
         * Une cession peut être une mise en retrait sur sonde en échec
         * (Registry) : ne jamais annoncer « sous contrôle » dans ce cas.
         */
        $aSignaler = $cedes > 0 || $echecsWalker !== [];

        return $this->resultat(
            self::TEST_REGISTRE,
            $aSignaler ? self::STATUT_CONSEILLE : self::STATUT_BON,
            $aSignaler
                ? __('Des modules du thème demandent votre attention', 'spiralbase')
                : __('Les modules du thème sont sous contrôle', 'spiralbase'),
            $description,
            __('Performance', 'spiralbase')
        );
    }

    /** Manifeste, sans jamais laisser une panne réseau fataliser l'écran. */
    private function manifeste(): ?array
    {
        try {
            return $this->updater->manifeste();
        } catch (\Throwable $e) {
            error_log('[spiralbase] site health : manifeste illisible — ' . $e->getMessage());

            return null;
        }
    }

    /** @param array<string, mixed> $manifeste */
    private function versionPubliee(array $manifeste): string
    {
        $version = $manifeste['version'] ?? null;

        return is_scalar($version) ? trim((string) $version) : '';
    }

    /** `1.0.0.0` et `1.0.0` désignent la même version — ne pas crier au rollback. */
    private function normaliser(string $version): string
    {
        $morceaux = array_slice(array_pad(explode('.', $version), 3, '0'), 0, 3);

        return implode('.', $morceaux);
    }

    /**
     * Échappement UNE fois, au point de sortie — jamais dans les fragments
     * assemblés en amont (c'est le précédent que copiera l'Epic 2).
     *
     * @return array<string, mixed>
     */
    private function resultat(string $test, string $statut, string $label, string $description, string $badge): array
    {
        return [
            'status'      => $statut,
            'label'       => esc_html($label),
            'description' => '<p>' . esc_html($description) . '</p>',
            'badge'       => ['label' => $badge, 'color' => 'blue'],
            'test'        => $test,
        ];
    }
}
