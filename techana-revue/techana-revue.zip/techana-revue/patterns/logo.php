<?php
/**
 * Title: Logo TechAna
 * Slug: techana-revue/logo
 * Inserter: no
 * Description: Logo du masthead et de la barre collante — lien vers l'accueil
 * résolu côté serveur pour rester valable en local (sous-dossier) comme en
 * production. Sans baseline (décision utilisateur 2026-08-13).
 */
?>
<!-- wp:html -->
<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="mark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><rect width="24" height="24" fill="currentColor"/><path d="M6.5 8.5L10 12l-3.5 3.5" stroke="var(--mark-ink)" stroke-width="2.1" stroke-linecap="square"/><path d="M12.5 15.6h5.5" stroke="var(--mark-ink)" stroke-width="2.1" stroke-linecap="square"/></svg></span><span class="logo-txt">Tech<span>Ana</span></span></a>
<!-- /wp:html -->
