/**
 * Bloc spiralbase/selection-editoriale — JS éditeur écrit à la main, SANS
 * build (AD-12).
 *
 * `save()` rend `null` : tout le contenu vient du serveur, qui seul connaît
 * les articles marqués. Le bloc n'a aucun enfant, donc rien à sérialiser.
 *
 * L'éditeur n'affiche pas la liste réelle : elle dépend d'un marquage fait
 * ailleurs (la liste des articles) et changerait sous les yeux de l'opérateur
 * sans qu'il ait touché à la page. Un texte d'attente honnête vaut mieux
 * qu'un aperçu qui ment.
 */
( function ( blocks, element, blockEditor, components, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    var PLAFOND = 12;

    blocks.registerBlockType( 'spiralbase/selection-editoriale', {
        edit: function ( props ) {
            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-selection-edition',
            } );

            return e(
                element.Fragment,
                null,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages de la sélection', 'spiralbase' ) },
                        e( components.RangeControl, {
                            label: __( 'Nombre d’articles', 'spiralbase' ),
                            value: props.attributes.nombre,
                            min: 1,
                            max: PLAFOND,
                            onChange: function ( valeur ) {
                                props.setAttributes( { nombre: valeur } );
                            },
                        } )
                    )
                ),
                e(
                    'div',
                    blockProps,
                    e(
                        components.Placeholder,
                        {
                            icon: 'star-filled',
                            label: __( 'Sélection éditoriale', 'spiralbase' ),
                        },
                        __(
                            'Les articles marqués « Mettre en avant » depuis la liste des articles s’afficheront ici, dans l’ordre de marquage.',
                            'spiralbase'
                        )
                    )
                )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n
);
