<?php
/**
 * Blocs dynamiques du thème — fragments dont le markup exact du design ne peut
 * pas sortir de blocs core : listes de rubriques (classes k-*, compteurs),
 * fil à la une, articles populaires, dernières mises à jour, menu mobile.
 *
 * Tout est rendu côté serveur depuis les vraies données ; dans l'éditeur, un
 * stub (assets/js/editeur-blocs.js) affiche un aperçu nominal.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'render_block', 'techanaRevueJetonAnnee' );

/**
 * Jeton `%annee%` remplacé par l'année courante au rendu.
 *
 * Le bas de pied portait « © 2026 » en dur : faux au 1er janvier, et invisible
 * jusqu'à ce que quelqu'un le remarque. Un bloc dynamique aurait réglé la date
 * mais rendu le texte non modifiable au clic dans l'éditeur de site ; le jeton
 * garde les deux — texte libre, année juste. Utilisable dans n'importe quel
 * contenu, pas seulement le pied.
 */
function techanaRevueJetonAnnee( string $html ): string {
    if ( ! str_contains( $html, '%annee%' ) ) {
        return $html;
    }
    return str_replace( '%annee%', wp_date( 'Y' ), $html );
}

add_action( 'init', 'techanaRevueRegisterBlocs' );
add_action( 'enqueue_block_editor_assets', 'techanaRevueBlocsEditeur' );

function techanaRevueRegisterBlocs() {
    $blocs = array(
        'rubriques'      => 'techanaRevueBlocRubriques',
        'ticker'         => 'techanaRevueBlocTicker',
        'plus-lus'       => 'techanaRevueBlocPlusLus',
        'dernieres-maj'  => 'techanaRevueBlocDernieresMaj',
        'menu-mobile'    => 'techanaRevueBlocMenuMobile',
        'pave-rubrique'  => 'techanaRevueBlocPaveRubrique',
        'hub-facts'      => 'techanaRevueBlocHubFacts',
        'fil-ariane'     => 'techanaRevueBlocFilAriane',
        'auteur-tete'    => 'techanaRevueBlocAuteurTete',
        'recherche-entete' => 'techanaRevueBlocRechercheEntete',
        'haut-page'      => 'techanaRevueBlocHautPage',
    );
    foreach ( $blocs as $nom => $callback ) {
        register_block_type( 'techana/' . $nom, array(
            'api_version'     => 3,
            'render_callback' => $callback,
            'attributes'      => array(
                'format'   => array( 'type' => 'string', 'default' => '' ),
                'nombre'   => array( 'type' => 'number', 'default' => 0 ),
                'position' => array( 'type' => 'number', 'default' => 0 ),
                // Menu wp_navigation à refléter — même valeur que le `ref` du
                // bloc core/navigation du header (voir techanaRevueRubriquesMenu).
                'ref'      => array( 'type' => 'number', 'default' => 0 ),
            ),
        ) );
    }
}

/**
 * Pavé de section d'un bloc de rubrique de l'accueil : nom, compteur et lien
 * de la rubrique en position N — la même source que les requêtes 40+N/50+N
 * (inc/accueil.php), donc toujours cohérent avec les articles affichés.
 */
function techanaRevueBlocPaveRubrique( array $attrs ): string {
    $rubrique = techanaRevueRubriquePosition( (int) ( $attrs['position'] ?? 0 ) );
    if ( ! $rubrique ) {
        return '';
    }
    $k = '' === $rubrique->cle ? '' : ' k-' . esc_attr( $rubrique->cle );
    return '<div class="sec-head' . $k . '">'
        . '<span class="sec-tag">' . esc_html( $rubrique->term->name ) . '</span>'
        . '<span class="line"></span>'
        . '<span class="sec-count">' . number_format_i18n( $rubrique->term->count ) . ' articles</span>'
        . '<a class="sec-more" href="' . esc_url( get_term_link( $rubrique->term ) ) . '">Voir la rubrique →</a>'
        . '</div>';
}

function techanaRevueBlocsEditeur() {
    wp_enqueue_script(
        'techana-revue-editeur-blocs',
        get_theme_file_uri( 'assets/js/editeur-blocs.js' ),
        array( 'wp-blocks', 'wp-element' ),
        TECHANA_REVUE_VERSION,
        true
    );
}

/**
 * Rubriques triées par volume, avec clé de couleur — la donnée commune à tous
 * les formats de liste.
 *
 * @return array<int, object{term: WP_Term, cle: string}>
 */
function techanaRevueRubriques( int $limite = 10 ): array {
    $termes = get_terms( array(
        'taxonomy'   => 'category',
        'orderby'    => 'count',
        'order'      => 'DESC',
        'hide_empty' => true,
        'number'     => $limite,
    ) );
    if ( is_wp_error( $termes ) ) {
        return array();
    }
    return array_map( static function ( WP_Term $term ) {
        return (object) array(
            'term' => $term,
            'cle'  => techanaRevueCleRubrique( $term ),
        );
    }, $termes );
}

/**
 * Rubriques dans l'ordre du menu de navigation `$ref` — celui que le bloc
 * core/navigation du header affiche déjà. Les blocs qui doublent ce menu
 * (barre réduite, menu mobile) doivent montrer les mêmes rubriques dans le même
 * ordre : un ordre par volume d'articles y contredirait la navigation
 * principale. Les listes éditoriales (thèmes, latérale, pied de page) gardent
 * leur tri par volume, ce ne sont pas des menus.
 *
 * @param int $ref      Post wp_navigation référencé par le markup.
 * @param int $repliMax Taille du repli si le menu est introuvable ou vide.
 * @return array Objets {term, cle}, même forme que techanaRevueRubriques().
 */
function techanaRevueRubriquesMenu( int $ref, int $repliMax ): array {
    $menu = $ref > 0 ? get_post( $ref ) : null;
    if ( ! $menu instanceof WP_Post || 'wp_navigation' !== $menu->post_type ) {
        return techanaRevueRubriques( $repliMax );
    }

    $rubriques = array();
    foreach ( parse_blocks( $menu->post_content ) as $bloc ) {
        if ( 'core/navigation-link' !== ( $bloc['blockName'] ?? '' ) ) {
            continue;
        }
        $attrs = $bloc['attrs'] ?? array();
        if ( 'category' !== ( $attrs['type'] ?? '' ) || empty( $attrs['id'] ) ) {
            continue;
        }
        $term = get_term( (int) $attrs['id'], 'category' );
        if ( $term instanceof WP_Term ) {
            $rubriques[] = (object) array(
                'term' => $term,
                'cle'  => techanaRevueCleRubrique( $term ),
            );
        }
    }

    return $rubriques ? $rubriques : techanaRevueRubriques( $repliMax );
}

/** Attribut class="k-…" ou chaîne vide si le terme n'a pas de clé. */
function techanaRevueKAttr( string $cle ): string {
    return '' === $cle ? '' : ' class="k-' . esc_attr( $cle ) . '"';
}

/**
 * Listes de rubriques du design. Formats : morepanel, stickynav, catlist,
 * themes, footcats — markup identique aux maquettes, données réelles.
 */
function techanaRevueBlocRubriques( array $attrs ): string {
    $format = $attrs['format'] ?? '';
    $rubs   = 'stickynav' === $format
        ? techanaRevueRubriquesMenu( (int) ( $attrs['ref'] ?? 0 ), 6 )
        : techanaRevueRubriques( 10 );
    if ( ! $rubs ) {
        return '';
    }
    $li = static function ( $r, string $classeCompte ): string {
        return sprintf(
            '<li%s><a href="%s">%s <span class="%s">%s</span></a></li>',
            techanaRevueKAttr( $r->cle ),
            esc_url( get_term_link( $r->term ) ),
            esc_html( $r->term->name ),
            esc_attr( $classeCompte ),
            number_format_i18n( $r->term->count )
        );
    };
    switch ( $format ) {
        case 'morepanel':
            $items = implode( '', array_map( static fn( $r ) => $li( $r, 'meta' ), $rubs ) );
            return '<div class="morepanel" id="more-panel" data-open="false"><div class="container"><ul>'
                . $items . '</ul></div></div>';
        case 'stickynav':
            $items = implode( '', array_map( static function ( $r ) {
                return sprintf(
                    '<a href="%s">%s</a>',
                    esc_url( get_term_link( $r->term ) ),
                    esc_html( $r->term->name )
                );
            }, $rubs ) );
            return '<nav>' . $items . '</nav>';
        case 'catlist':
            $items = implode( '', array_map( static fn( $r ) => $li( $r, 'c' ), $rubs ) );
            return '<ul class="catlist">' . $items . '</ul>';
        case 'themes':
            $items = implode( '', array_map( static function ( $r ) {
                return sprintf(
                    '<a class="theme%s" href="%s"><h3>%s</h3><span class="c">%s articles</span></a>',
                    '' === $r->cle ? '' : ' k-' . esc_attr( $r->cle ),
                    esc_url( get_term_link( $r->term ) ),
                    esc_html( $r->term->name ),
                    number_format_i18n( $r->term->count )
                );
            }, $rubs ) );
            return '<div class="themes">' . $items . '</div>';
        case 'footcats':
            $items = implode( '', array_map( static function ( $r ) {
                return sprintf(
                    '<li><a href="%s">%s</a></li>',
                    esc_url( get_term_link( $r->term ) ),
                    esc_html( $r->term->name )
                );
            }, $rubs ) );
            return '<ul class="foot-cats">' . $items . '</ul>';
    }
    return '';
}

/**
 * Retour en haut de page : ancre `#top`, que les navigateurs résolvent en haut
 * du document sans qu'aucun élément ne porte cet identifiant — le bouton
 * fonctionne donc sans JavaScript. Son apparition suit la classe `is-scrolled`
 * déjà posée par techana.js pour l'en-tête réduit.
 */
function techanaRevueBlocHautPage(): string {
    return '<a class="tothetop" href="#top" aria-label="Revenir en haut de la page">'
        . '<span aria-hidden="true">↑</span></a>';
}

/**
 * Fil à la une : articles cochés _techana_une complétés par les plus récents
 * (volume réglable, Apparence → Une de l'accueil ; 0 retire le bandeau).
 * Défilement au clic uniquement — techana.js lit les items du conteneur caché.
 */
function techanaRevueBlocTicker(): string {
    $ids      = techanaRevueArticlesUne( techanaRevueReglagesUne()['ticker'] );
    $articles = array_filter( array_map( 'get_post', $ids ) );
    if ( ! $articles ) {
        return '';
    }
    $articles = array_values( $articles );
    $liens = implode( '', array_map( static function ( WP_Post $p ) {
        return sprintf(
            '<a class="ticker-item" href="%s" hidden>%s</a>',
            esc_url( get_permalink( $p ) ),
            esc_html( get_the_title( $p ) )
        );
    }, $articles ) );
    return '<div class="ticker"><div class="container ticker-in">'
        . '<span class="ticker-label">À la une</span>'
        . sprintf(
            '<a class="ticker-item" id="ticker-item" href="%s">%s</a>',
            esc_url( get_permalink( $articles[0] ) ),
            esc_html( get_the_title( $articles[0] ) )
        )
        . '<div class="ticker-ctrl"><span class="ticker-pos" id="ticker-pos">1 / ' . count( $articles ) . '</span>'
        . '<button id="tk-prev" aria-label="Titre précédent">←</button>'
        . '<button id="tk-next" aria-label="Titre suivant">→</button></div>'
        . '<div id="ticker-data" hidden>' . $liens . '</div>'
        . '</div></div>';
}

/**
 * Populaires de la latérale : tri par vues, repli chronologique tant qu'aucune
 * vue n'existe (décision « compteur maison » du design).
 */
function techanaRevueBlocPlusLus( array $attrs ): string {
    $nombre = $attrs['nombre'] > 0 ? (int) $attrs['nombre'] : 5;
    $args   = array( 'numberposts' => $nombre );
    if ( get_option( 'techana_a_des_vues' ) ) {
        $args['meta_key'] = '_techana_vues';
        $args['orderby']  = 'meta_value_num';
        $args['order']    = 'DESC';
    }
    $articles = get_posts( $args );
    $sortie   = '';
    foreach ( $articles as $i => $p ) {
        $cats   = get_the_category( $p->ID );
        $meta   = ( $cats ? esc_html( $cats[0]->name ) . ' · ' : '' ) . esc_html( get_the_date( 'j M', $p ) );
        $sortie .= sprintf(
            '<a class="pop" href="%s"><span class="rank num">%d</span><div><h3>%s</h3><span class="meta">%s</span></div></a>',
            esc_url( get_permalink( $p ) ),
            $i + 1,
            esc_html( get_the_title( $p ) ),
            $meta
        );
    }
    return $sortie;
}

/**
 * Dernières mises à jour : 3 unités latérales triées par date de modification.
 */
function techanaRevueBlocDernieresMaj( array $attrs ): string {
    $nombre   = $attrs['nombre'] > 0 ? (int) $attrs['nombre'] : 3;
    $articles = get_posts( array(
        'numberposts' => $nombre,
        'orderby'     => 'modified',
        'order'       => 'DESC',
    ) );
    $sortie = '';
    foreach ( $articles as $p ) {
        $vignette = get_the_post_thumbnail( $p, 'techana-side' );
        if ( ! $vignette ) {
            $vignette = '<span class="ph-img square"></span>';
        }
        $sortie .= sprintf(
            '<a class="u-side" href="%s">%s<div><h3>%s</h3><span class="meta">Mis à jour le %s</span></div></a>',
            esc_url( get_permalink( $p ) ),
            $vignette,
            esc_html( get_the_title( $p ) ),
            esc_html( get_the_modified_date( 'j M', $p ) )
        );
    }
    return $sortie;
}

/**
 * Formulaire de recherche du design (search-big), valeur pré-remplie.
 */
function techanaRevueFormulaireRecherche(): string {
    return '<form class="search-big" role="search" action="' . esc_url( home_url( '/' ) ) . '" method="get">'
        . '<input type="search" name="s" value="' . esc_attr( get_search_query() ) . '"'
        . ' placeholder="Rechercher un tutoriel, une commande, un logiciel…" aria-label="Rechercher sur TechAna" />'
        . '<button type="button" class="clear" aria-label="Effacer la recherche">✕</button>'
        . '<button type="submit">Rechercher</button></form>';
}

/**
 * En-tête de la page de recherche : bascule entre l'état nominal (compteur de
 * résultats) et l'état vide (recherche-aucun-resultat.html).
 */
function techanaRevueBlocRechercheEntete(): string {
    global $wp_query;
    $total   = (int) ( $wp_query->found_posts ?? 0 );
    $requete = get_search_query();
    if ( $total > 0 ) {
        $compte = '<p class="search-count"><strong>' . number_format_i18n( $total )
            . ( $total > 1 ? ' résultats' : ' résultat' ) . '</strong> pour « ' . esc_html( $requete )
            . ' » · classés par pertinence, puis par date de publication</p>';
        return '<section class="searchpage"><h1>Rechercher sur TechAna</h1>'
            . techanaRevueFormulaireRecherche() . $compte . '</section>';
    }
    return '<section class="void">'
        . '<div class="sec-head"><span class="sec-tag">Recherche</span><span class="line"></span></div>'
        . '<h1>Aucun article ne correspond à <em>« ' . esc_html( $requete ) . ' »</em></h1>'
        . '<p class="lead">La recherche porte sur les titres, les chapôs et le corps des articles publiés. '
        . 'Essayez avec moins de termes, ou vérifiez l\'orthographe des noms de commandes.</p>'
        . techanaRevueFormulaireRecherche()
        . '</section>';
}

/**
 * En-tête de la page auteur : portrait, bio, rubriques d'écriture avec
 * compteurs, repères de publication — la page d'expertise voulue par l'audit.
 */
function techanaRevueBlocAuteurTete(): string {
    $auteur = get_queried_object();
    if ( ! $auteur instanceof WP_User ) {
        return '';
    }
    $articles = get_posts( array(
        'numberposts' => 500,
        'fields'      => 'ids',
        'author'      => $auteur->ID,
        'order'       => 'ASC',
    ) );
    $parCat = array();
    foreach ( $articles as $id ) {
        foreach ( get_the_category( $id ) as $cat ) {
            if ( ! isset( $parCat[ $cat->term_id ] ) ) {
                $parCat[ $cat->term_id ] = array( 'term' => $cat, 'n' => 0 );
            }
            $parCat[ $cat->term_id ]['n']++;
        }
    }
    usort( $parCat, static fn( $a, $b ) => $b['n'] <=> $a['n'] );
    $chips = '';
    foreach ( array_slice( $parCat, 0, 3 ) as $c ) {
        $cle    = techanaRevueCleRubrique( $c['term'] );
        $chips .= '<a class="author-cat' . ( $cle ? ' k-' . esc_attr( $cle ) : '' ) . '" href="'
            . esc_url( get_term_link( $c['term'] ) ) . '">' . esc_html( $c['term']->name )
            . ' <span class="n">' . number_format_i18n( $c['n'] ) . '</span></a>';
    }
    $reperes = '';
    if ( $articles ) {
        $reperes = '<div class="author-links">'
            . '<span>Premier article publié en ' . esc_html( get_the_date( 'F Y', $articles[0] ) ) . '</span>'
            . '<span>Dernière publication le ' . esc_html( get_the_date( 'j F Y', end( $articles ) ) ) . '</span>'
            . '</div>';
    }
    $bio = get_the_author_meta( 'description', $auteur->ID );
    return '<header class="authorhead">'
        . techanaRevuePortrait( $auteur->ID, 144, $auteur->display_name )
        . '<div>'
        . '<div class="sec-head"><span class="sec-tag">Auteur</span><span class="line"></span></div>'
        . '<h1>' . esc_html( $auteur->display_name ) . '</h1>'
        . ( $bio ? '<p class="bio">' . esc_html( $bio ) . '</p>' : '' )
        . ( $chips ? '<div class="author-cats">' . $chips . '</div>' : '' )
        . $reperes
        . '</div></header>';
}

/**
 * Chemin du fil d'Ariane de la vue courante — partagé entre le bloc visible
 * et le JSON-LD BreadcrumbList (règle absolue : les deux doivent correspondre).
 *
 * @return array<int, array{0: string, 1: string}> [libellé, url] — url vide = niveau courant.
 */
function techanaRevueFilAriane(): array {
    $chemin = array( array( 'Accueil', home_url( '/' ) ) );
    if ( is_category() || is_author() ) {
        $objet    = get_queried_object();
        $chemin[] = array(
            $objet instanceof WP_User ? $objet->display_name : $objet->name,
            '',
        );
    } elseif ( is_singular( 'post' ) ) {
        $cats = get_the_category();
        if ( $cats ) {
            $chemin[] = array( $cats[0]->name, get_term_link( $cats[0] ) );
        }
        $chemin[] = array( get_the_title(), '' );
    } elseif ( is_home() ) {
        $chemin[] = array( get_the_title( (int) get_option( 'page_for_posts' ) ), '' );
    } elseif ( is_page() ) {
        $chemin[] = array( get_the_title(), '' );
    } elseif ( is_search() ) {
        $chemin[] = array( 'Recherche', '' );
    } else {
        return array();
    }
    return $chemin;
}

/**
 * Fil d'Ariane visible — markup exact de la maquette (nav.crumb).
 */
function techanaRevueBlocFilAriane(): string {
    $chemin = techanaRevueFilAriane();
    if ( count( $chemin ) < 2 ) {
        return '';
    }
    $morceaux = array();
    foreach ( $chemin as $etape ) {
        if ( '' === $etape[1] ) {
            $morceaux[] = '<span aria-current="page">' . esc_html( $etape[0] ) . '</span>';
        } else {
            $morceaux[] = '<a href="' . esc_url( $etape[1] ) . '">' . esc_html( $etape[0] ) . '</a>';
        }
    }
    return '<nav class="crumb" aria-label="Fil d\'Ariane">'
        . implode( '<span class="sep">›</span>', $morceaux )
        . '</nav>';
}

/**
 * Bandeau de faits du hub : volume, dernière publication, nombre d'auteurs —
 * la préfiguration lisible du sérieux de la rubrique (hub-facts du design).
 * Fonctionne sur les archives de rubrique et d'auteur.
 */
function techanaRevueBlocHubFacts(): string {
    $objet = get_queried_object();
    $faits = array();
    if ( $objet instanceof WP_Term ) {
        $derniers = get_posts( array(
            'numberposts' => 1,
            'fields'      => 'ids',
            'category'    => $objet->term_id,
        ) );
        $auteurs  = get_posts( array(
            'numberposts' => 100,
            'fields'      => 'ids',
            'category'    => $objet->term_id,
        ) );
        $nbAuteurs = count( array_unique( array_map(
            static fn( $id ) => (int) get_post_field( 'post_author', $id ),
            $auteurs
        ) ) );
        $faits[] = array( 'Articles', number_format_i18n( $objet->count ) );
        if ( $derniers ) {
            $faits[] = array( 'Dernière publication', get_the_date( 'j M Y', $derniers[0] ) );
        }
        $faits[] = array( 'Auteurs de la rubrique', number_format_i18n( $nbAuteurs ) );
    } elseif ( $objet instanceof WP_User ) {
        $total    = count_user_posts( $objet->ID, 'post', true );
        $derniers = get_posts( array(
            'numberposts' => 1,
            'fields'      => 'ids',
            'author'      => $objet->ID,
        ) );
        $faits[] = array( 'Articles', number_format_i18n( $total ) );
        if ( $derniers ) {
            $faits[] = array( 'Dernière publication', get_the_date( 'j M Y', $derniers[0] ) );
        }
    } elseif ( is_home() ) {
        $total    = (int) wp_count_posts()->publish;
        $derniers = get_posts( array(
            'numberposts' => 1,
            'fields'      => 'ids',
        ) );
        $auteurs  = count( array_filter( count_many_users_posts(
            get_users( array( 'fields' => 'ID' ) ),
            'post',
            true
        ) ) );
        $faits[] = array( 'Articles', number_format_i18n( $total ) );
        if ( $derniers ) {
            $faits[] = array( 'Dernière publication', get_the_date( 'j M Y', $derniers[0] ) );
        }
        $faits[] = array( 'Auteurs', number_format_i18n( $auteurs ) );
    }
    if ( ! $faits ) {
        return '';
    }
    $sortie = '';
    foreach ( $faits as $f ) {
        $sortie .= '<div><dt>' . esc_html( $f[0] ) . '</dt><dd class="num">' . esc_html( $f[1] ) . '</dd></div>';
    }
    return '<dl class="hub-facts">' . $sortie . '</dl>';
}

/**
 * Menu mobile plein écran : recherche, rubriques k-*, liens de la rédaction.
 * Les liens institutionnels pointent les pages par slug — une page absente est
 * simplement omise (elle apparaîtra dès sa création).
 */
function techanaRevueBlocMenuMobile( array $attrs = array() ): string {
    $recherche = '<form class="search" role="search" style="margin-top:52px" action="'
        . esc_url( home_url( '/' ) ) . '" method="get">'
        . '<input type="search" name="s" placeholder="Rechercher un tutoriel…" aria-label="Rechercher" />'
        . '<button type="submit" aria-label="Lancer la recherche">↵</button></form>';

    $rubriques = implode( '', array_map( static function ( $r ) {
        return sprintf(
            '<a%s href="%s">%s <span class="meta">%s</span></a>',
            techanaRevueKAttr( $r->cle ),
            esc_url( get_term_link( $r->term ) ),
            esc_html( $r->term->name ),
            number_format_i18n( $r->term->count )
        );
    }, techanaRevueRubriquesMenu( (int) ( $attrs['ref'] ?? 0 ), 10 ) ) );

    $redaction = '';
    $pages     = array( 'a-propos', 'contact', 'publier-chez-nous', 'politique-editoriale' );
    foreach ( $pages as $slug ) {
        $page = get_page_by_path( $slug );
        if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
            $redaction .= sprintf(
                '<a href="%s">%s</a>',
                esc_url( get_permalink( $page ) ),
                esc_html( get_the_title( $page ) )
            );
        }
    }
    if ( '' !== $redaction ) {
        $redaction = '<h4>La rédaction</h4>' . $redaction;
    }

    return '<div class="mobilemenu" id="mobile-menu" data-open="false" role="dialog" aria-modal="true" aria-label="Menu principal">'
        . '<button class="close" id="menu-close" aria-label="Fermer le menu">✕</button>'
        . $recherche
        . '<h4>Rubriques</h4>' . $rubriques
        . $redaction
        . '</div>';
}
