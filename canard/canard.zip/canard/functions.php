<?php
/**
 * Enqueue assets for Divi child theme + Best Western
 */

// Preloader maison (réglages : Apparence → Personnaliser → Preloader)
if (file_exists(get_stylesheet_directory() . '/includes/preloader.php')) {
    require_once get_stylesheet_directory() . '/includes/preloader.php';
}

add_action('wp_enqueue_scripts', 'divi_child_enqueue_assets', 20);

function divi_child_enqueue_assets() {

    /* =========================
     * CSS
     * ========================= */

    // Parent Divi
    wp_enqueue_style(
        'divi-parent-style',
        get_template_directory_uri() . '/style.css',
        [],
        null
    );

    // Child theme
    if (file_exists(get_stylesheet_directory() . '/style.css')) {
        wp_enqueue_style(
            'divi-child-style',
            get_stylesheet_directory_uri() . '/style.css',
            ['divi-parent-style'],
            filemtime(get_stylesheet_directory() . '/style.css')
        );
    }

    // Font Awesome
    wp_enqueue_style(
        'font-awesome-free',
        'https://use.fontawesome.com/releases/v5.2.0/css/all.css',
        [],
        '5.2.0'
    );

    // Best Western CSS
    wp_enqueue_style(
        'bw-responsive-style',
        'https://www.bestwestern.fr/public/css/css-reponsive/style_responsive_moteur.css?v=20000',
        [],
        null
    );

    /* =========================
     * JS
     * ========================= */

    // jQuery (WordPress core)
    wp_enqueue_script('jquery');

    // Best Western JS : seulement sur la page Réservez, la seule à porter le formulaire de
    // réservation ; ailleurs son initialisation cherche #DateRangeStart et lève une erreur JS.
    if (!is_page(2768)) {
        return;
    }

    // Variables globales requises par Best Western
    wp_add_inline_script(
        'jquery',
        "var base_url_bwfr='https://www.bestwestern.fr/'; var languageCode='fr';",
        'after'
    );

    // Best Western JS (DOIT être dans le head)
    wp_enqueue_script(
        'bw-responsive',
        'https://www.bestwestern.fr/public/javascript/js-responsive/script_responsive.js?v=20010',
        ['jquery'],
        null,
        false // head
    );

}

/**
 * Affiche le logo spécifique Best Western sur les pages concernées (rendu serveur).
 *
 * Rendu côté serveur via le filtre Divi `et_html_logo_container` : le bon logo est présent
 * dans le HTML dès le chargement, sans masquage CSS ni dépendance au JS. Évite le bug du
 * logo invisible (l'ancien système app.js/siteData échouait et laissait #logo masqué).
 *
 * @param string $logo_container HTML du conteneur logo généré par Divi.
 * @return string
 */
function divi_child_special_logo($logo_container) {
    $special_pages = [2768, 2787, 4561, 4555, 4567, 4518, 4572];

    if (!is_page($special_pages)) {
        return $logo_container;
    }

    $uploads      = wp_upload_dir();
    $special_logo = $uploads['baseurl'] . '/2024/06/BW_logo_canardsurletoi8MINI.jpg';

    // Remplace uniquement le src de l'image #logo, sans dépendre de l'ordre des attributs.
    return preg_replace_callback(
        '/<img\b[^>]*\bid="logo"[^>]*>/',
        function ($img) use ($special_logo) {
            return preg_replace('/\bsrc="[^"]*"/', 'src="' . esc_url($special_logo) . '"', $img[0]);
        },
        $logo_container
    );
}
add_filter('et_html_logo_container', 'divi_child_special_logo');
