<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\TexteRiche;

/**
 * Rendu serveur du bloc `spiralbase/menu-section` — « Entrées », « Plats »,
 * « Desserts »… : un titre, et les plats reçus déjà rendus.
 *
 * Le titre sort en `<h3>` : une carte s'insère dans une page qui a déjà son
 * `<h1>` et le plus souvent un `<h2>` de section — le niveau 3 garde la
 * hiérarchie du document lisible pour un lecteur d'écran comme pour un moteur.
 */
final class RenduSection extends RenduBloc
{
    protected function nomDuBloc(): string
    {
        return 'spiralbase/menu-section';
    }

    protected function composer(array $attributs, string $contenu, mixed $bloc): string
    {
        $variante = Variantes::depuisContexte($bloc);

        /* Une section sans plat n'a rien à annoncer : afficher « Desserts »
           au-dessus du vide vaut moins que ne rien afficher du tout. */
        if (trim($contenu) === '') {
            return '';
        }

        $titre  = TexteRiche::filtrer($attributs['titre'] ?? null);
        $entete = TexteRiche::estVide($titre)
            ? ''
            : '<h3 class="spiralbase-menu-section__titre">' . $titre . '</h3>';

        $classes = 'spiralbase-menu-section spiralbase-menu-section--' . $variante;

        return '<section ' . $this->conteneur($classes) . '>'
            . $entete
            . '<div class="spiralbase-menu-section__plats">' . $contenu . '</div>'
            . '</section>';
    }
}
