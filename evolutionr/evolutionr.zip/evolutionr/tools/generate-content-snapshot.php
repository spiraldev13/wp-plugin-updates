<?php
/**
 * Outil de maintenance (dev) — régénère la fonction evolutionr_seed_content_snapshot()
 * dans inc/seed-content.php à partir du contenu LIVE actuel.
 *
 * À lancer après avoir peaufiné des textes en back-office, pour que le seed (donc une
 * future réinstallation) reparte sur la version finale :
 *
 *     wp eval-file wp-content/themes/evolutionr/tools/generate-content-snapshot.php
 *
 * Puis committer inc/seed-content.php.
 *
 * Ce que fait le script : lit tout le texte des pages (scalaires + repeaters, via
 * get_field_objects), EXCLUT les médias (IDs propres à l'environnement), normalise les
 * URLs absolues en relatif, capture les métas Rank Math, et réécrit la fonction.
 * Ce n'est PAS du code exécuté par le site : juste un utilitaire, lancé à la main.
 */

if (!function_exists('get_field_objects')) {
    fwrite(STDERR, "ACF requis (get_field_objects introuvable).\n");
    return;
}

$SEED = __DIR__ . '/../inc/seed-content.php';
$HOME = home_url();
$SKIP = ['image', 'file', 'gallery', 'post_object', 'relationship', 'taxonomy', 'user',
         'google_map', 'oembed', 'link', 'page_link', 'clone'];

$norm_url = static function ($v) use ($HOME) {
    if (is_string($v) && strpos($v, $HOME) === 0) {
        $r = substr($v, strlen($HOME));
        return $r === '' ? '/' : $r;
    }
    return $v;
};

$php_scalar = static function ($v) use ($norm_url) {
    if (is_bool($v))  return $v ? 'true' : 'false';
    if (is_int($v))   return (string) $v;
    if (is_float($v)) return (string) $v;
    if ($v === null)  return "''";
    $v = (string) $norm_url((string) $v);
    $v = str_replace(["\r\n", "\r"], "\n", $v);
    if (strpos($v, "\n") !== false) {
        return '"' . str_replace(['\\', '"', '$', "\n"], ['\\\\', '\\"', '\\$', '\\n'], $v) . '"';
    }
    return "'" . str_replace(['\\', "'"], ['\\\\', "\\'"], $v) . "'";
};

$emit = static function ($fieldObj, $value) use (&$emit, $SKIP, $php_scalar) {
    $type = $fieldObj['type'] ?? 'text';
    if (in_array($type, $SKIP, true)) return null;

    if ($type === 'repeater') {
        if (!is_array($value) || !$value) return '[]';
        $subDefs = [];
        foreach (($fieldObj['sub_fields'] ?? []) as $sf) $subDefs[$sf['name']] = $sf;
        $rows = [];
        foreach ($value as $row) {
            if (!is_array($row)) continue;
            $cells = [];
            foreach ($subDefs as $name => $sf) {
                if (!array_key_exists($name, $row)) continue;
                $lit = $emit($sf, $row[$name]);
                if ($lit === null) continue;
                $cells[] = "'" . $name . "' => " . $lit;
            }
            $rows[] = "            [" . implode(", ", $cells) . "],";
        }
        return "[\n" . implode("\n", $rows) . "\n        ]";
    }

    if ($type === 'group') {
        if (!is_array($value)) return '[]';
        $subDefs = [];
        foreach (($fieldObj['sub_fields'] ?? []) as $sf) $subDefs[$sf['name']] = $sf;
        $cells = [];
        foreach ($subDefs as $name => $sf) {
            if (!array_key_exists($name, $value)) continue;
            $lit = $emit($sf, $value[$name]);
            if ($lit === null) continue;
            $cells[] = "'" . $name . "' => " . $lit;
        }
        return "[" . implode(", ", $cells) . "]";
    }

    if (is_array($value)) {   // checkbox multi
        return "[" . implode(", ", array_map($php_scalar, $value)) . "]";
    }
    return $php_scalar($value);
};

// Pages ciblées : accueil + 7 pages éditoriales (slug -> lookup ; médias/CPT exclus).
$slugs = ['front', 'creation-site-internet', 'consultant-seo', 'maintenance-hebergement',
          'tarifs', 'contact', 'a-propos', 'identite-visuelle'];

$L = [];
$L[] = "/**";
$L[] = " * SNAPSHOT DE CONTENU (généré) — applique le texte live actuel (héros, sections,";
$L[] = " * repeaters) de chaque page. Couche appliquée EN DERNIER pour qu'une réinstallation";
$L[] = " * reparte sur le contenu peaufiné. Médias exclus (IDs propres à l'environnement),";
$L[] = " * URLs normalisées en relatif. Régénérable : tools/generate-content-snapshot.php.";
$L[] = " */";
$L[] = "function evolutionr_seed_content_snapshot(): void";
$L[] = "{";
$L[] = "    if (!evolutionr_acf_is_active()) return;";
$L[] = "";

$fieldCount = 0;
foreach ($slugs as $slug) {
    if ($slug === 'front') {
        $id = (int) get_option('page_on_front');
    } else {
        $p  = get_page_by_path($slug) ?: get_page_by_path("prestations/$slug");
        $id = $p ? (int) $p->ID : 0;
    }
    if (!$id) continue;

    if ($slug === 'front') {
        $L[] = "    // ── Accueil ──";
        $L[] = "    if (\$id = (int) get_option('page_on_front')) {";
    } else {
        $L[] = "    // ── " . $slug . " ──";
        $L[] = "    if (\$id = evolutionr_seed_get_page_id('" . $slug . "')) {";
    }
    foreach ((get_field_objects($id) ?: []) as $name => $obj) {
        $val = $obj['value'] ?? null;
        if ($val === null || $val === '' || $val === []) continue;
        $lit = $emit($obj, $val);
        if ($lit === null || $lit === "''" || $lit === '[]') continue;
        $L[] = "        update_field('" . $name . "', " . $lit . ", \$id);";
        $fieldCount++;
    }
    foreach (['rank_math_title', 'rank_math_description', 'rank_math_focus_keyword'] as $mk) {
        $mv = get_post_meta($id, $mk, true);
        if ($mv === '' || $mv === false || $mv === null) continue;
        $L[] = "        update_post_meta(\$id, '" . $mk . "', " . $php_scalar($mv) . ");";
    }
    $L[] = "    }";
    $L[] = "";
}
$L[] = "}";
$newFn = implode("\n", $L);

// Remplacement en place dans seed-content.php.
$src = file_get_contents($SEED);
$startMarker = "/**\n * SNAPSHOT DE CONTENU (généré)";
$start = strpos($src, $startMarker);
if ($start === false) {
    fwrite(STDERR, "Fonction snapshot introuvable dans seed-content.php (marqueur absent).\n");
    return;
}
$sigPos   = strpos($src, "function evolutionr_seed_content_snapshot(): void", $start);
$bracePos = strpos($src, "\n}\n", $sigPos);           // } en colonne 0 = fin de fonction
if ($bracePos === false) {
    fwrite(STDERR, "Accolade de fin introuvable.\n");
    return;
}
$end = $bracePos + 2;                                   // inclut "\n}"
$out = substr($src, 0, $start) . $newFn . substr($src, $end);
file_put_contents($SEED, $out);

echo "Snapshot régénéré : {$fieldCount} champs (+ Rank Math). inc/seed-content.php mis à jour.\n";
echo "→ Vérifiez (php -l) puis committez inc/seed-content.php.\n";
