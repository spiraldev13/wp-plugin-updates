# Conventions Git

## Messages de commit

Format : `type(scope): description courte en français`

Types :
- `feat` — nouvelle fonctionnalité
- `fix` — correction de bug
- `refactor` — changement de code sans feature ni fix
- `test` — ajout ou mise à jour de tests
- `docs` — documentation uniquement
- `chore` — build, dépendances, config
- `perf` — amélioration de la performance
- `style` — changements de formatage, espaces, points-virgules, etc.

Exemples :
- `feat(auth): ajouter la connexion OAuth2 Google`
- `fix(api): gérer la réponse null de la passerelle de paiement`
- `refactor(panier): extraire le calcul de remise dans un service`

### Exemples de Bons Messages

```
feat: Add user authentication with JWT

Implémente un système d'authentification complet avec JWT tokens.
Les tokens expirent après 24h et sont stockés dans localStorage.
Ajoute également un système de refresh tokens pour maintenir la session.

```

```
fix: Correct calculation error in shopping cart total

Le total ne prenait pas en compte les réductions appliquées.
Corrige le calcul pour soustraire les réductions avant d'ajouter les taxes.
Ajoute des tests unitaires pour éviter une régression.

```

## Règles

- Toujours travailler sur la branche `dev` — vérifier avec `git branch --show-current` avant tout commit
- Ne JAMAIS committer sur `main` ou `master` — ces branches sont réservées à la production
- Committer dès qu'une tâche est terminée — ne pas regrouper des changements sans rapport
- Nommage des branches features : `feat/description-courte` ou `fix/description-courte`

## Avant de committer

### Checklist

- ✅ Le code fonctionne et a été testé
- ✅ Les tests passent (si disponibles)
- ✅ Pas de `console.log()` ou code de debug
- ✅ Pas de fichiers temporaires ou générés
- ✅ Pas de secrets ou credentials
- ✅ Le code respecte les standards du projet

- Vérifier la branche courante : `git branch --show-current` → doit être `dev` ou une branche feature
- Vérifier le diff : `git diff --staged` — pas de logs de debug, pas de fichiers .env
- Lancer le lint si disponible
- Lancer les tests si disponibles
- Jamais de : Co-Authored-By: Claude* dans les messages de commit — je suis l'auteur de tous les commits, même ceux suggérés par Claude

### Fichiers à Ne Jamais Committer

- `.env` et fichiers de configuration locaux
- `node_modules/`, `vendor/`, dossiers de dépendances
- Fichiers de build (`dist/`, `build/`)
- Fichiers IDE (`.vscode/`, `.idea/`) sauf config partagée
- Logs et fichiers temporaires
- Credentials, tokens, clés API

## Commandes Interdites Sans Autorisation Explicite

- ❌ `git push --force` sur `main` ou `master`
- ❌ `git reset --hard` sur des commits partagés
- ❌ `git rebase` sur des branches publiques
- ❌ Modification de l'historique partagé