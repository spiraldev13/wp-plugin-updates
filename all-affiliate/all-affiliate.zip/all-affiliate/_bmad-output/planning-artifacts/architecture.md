---
stepsCompleted: ['step-01-init', 'step-02-context', 'step-03-starter', 'step-04-decisions', 'step-05-patterns', 'step-06-structure', 'step-07-validation', 'step-08-complete']
lastStep: 8
status: 'complete'
completedAt: '2026-04-24'
inputDocuments:
  - "_bmad-output/planning-artifacts/prd.md"
  - "_bmad-output/planning-artifacts/ux-design-specification.md"
  - "_bmad-output/brainstorming/brainstorming-session-2026-04-24-1044.md"
  - "docs/visibility-impact.md"
workflowType: 'architecture'
project_name: 'All Affiliate'
user_name: 'Cyril'
date: '2026-04-24'
documentCounts:
  prd: 1
  ux: 1
  brainstorming: 1
  projectDocs: 1
---

# Architecture Decision Document — All Affiliate

**Author:** Cyril
**Date:** 2026-04-24

_Ce document est construit collaborativement par étapes de découverte. Les sections sont ajoutées au fur et à mesure._

---

> Architecture basée sur :
> - **PRD** (52 FR, 43 NFR, 7 phases) — source principale des exigences
> - **UX Design Spec** (60 composants, design tokens, 3 user flows) — source principale des contraintes d'interface
> - **Brainstorming** — contexte des décisions produit
> - **visibility-impact.md** — contraintes du système de mise à jour existant

---

## Project Context Analysis

### Requirements Overview

**Functional Requirements — 52 FRs en 8 capability areas**

| Capability Area | Nb FRs | Implication architecturale principale |
|---|---|---|
| A. Platform Management | 7 | Modèle de données extensible (Platform Profile = entité first-class avec regex + template URL) |
| B. Product Management | 13 | CPT `aff_product` + meta riche + bulk operations performantes |
| C. Link & Tracking System | 5 | Rewrite rule WP + route custom `/go/{slug}` + compteur atomic en postmeta |
| D. Content Authoring (Gutenberg) | 6 | Block Gutenberg unique avec `render_callback` PHP + React pour l'edit |
| E. Visual Design System | 6 | Design Tokens en CSS variables + détection thème via PHP + React admin pour l'édition |
| F. Performance Monitoring | 2 | Agrégations SQL simples (GROUP BY postmeta), pas d'analytics externe |
| G. Security & Compliance | 6 | Nonces, capabilities, validation URL allowlist, Schema.org JSON-LD |
| H. System Configuration | 7 | Settings API WP, transients cache avec invalidation par hooks, updater.php compatible |

**Non-Functional Requirements — 43 NFRs**

| Catégorie | NFRs clés | Impact archi |
|---|---|---|
| Performance | LCP < 1.5s, JS < 50KB, cache HIT < 20ms | Rendu serveur + cache transient + lazy-load + code-splitting |
| Security | Anti-fraude volatile, 0 data personnelle, validation URL allowlist | Pas de stockage persistant de click data, rate-limit memory, regex strict |
| Scalability | 2000 produits/site, 50 profils, 100 clics/s | CPT scaling natif WP, cache transients agressif, pas de table custom |
| Accessibility | WCAG 2.1 AA, Lighthouse A11y ≥ 90 | Radix UI primitives, semantic HTML, ARIA, focus management |
| Integration | WP ≥ 6.0, PHP ≥ 8.0, prefix `aff-*`, FSE/Gutenberg, updater.php | Build moderne, namespace PHP propre, hooks exhaustifs |
| Reliability & Maintainability | Cache invalidation < 1s, tests 70% PHP / 50% React + 6 E2E | Hooks exhaustifs, architecture testable, couches claires |

### Scale & Complexity Assessment

**Complexité architecturale : MEDIUM**

| Indicateur | Valeur | Commentaire |
|---|---|---|
| Composants UI | ~60 (5 niveaux) | Nombreux mais cadrés par design system Radix |
| Endpoints REST | ~15-20 | CRUD produits/profils/tokens + dashboard + actions |
| Tables/CPT | 1 CPT + postmeta WP natif | Pas de table custom = scaling WP natif |
| Features real-time | 0 (preview = debounce client) | Pas de WebSocket, pas de live collab |
| Multi-tenancy | Multi-sites indépendants | Pas de data partagée entre sites |
| Compliance | RGPD basique + Schema.org | Faible charge |
| Integrations externes | 0 au MVP (APIs V2+) | Pas de dépendance externe |
| Patterns techniques avancés | Cache invalidation, détection thème, build Tailwind isolé | Quelques sujets pointus, rien d'enterprise |

**Domaine technique primaire** : full-stack WordPress plugin (PHP 8 + React 18 + Tailwind)
**Complexity level** : medium

### Technical Constraints & Dependencies

**Contraintes externes (non-négociables)**

1. **Écosystème WordPress** — plateforme imposée (Plugin API, hooks/filters/actions, WP ≥ 6.0, PHP ≥ 8.0, utilisation des composants natifs Gutenberg, Media Library, REST API)
2. **Pas d'accès API officielles d'affiliation au MVP** — Amazon PA-API, Awin API, etc. inaccessibles. Fallback : OpenGraph scraping léger + saisie manuelle.
3. **Infrastructure updater existante** (`updater.php` + GitHub releases) — exposition d'un `update.json` conforme, ne pas réinventer le système de mise à jour.
4. **Thèmes peuvent utiliser Tailwind** (Tailpress, Oxygen, etc.) — Prefix `aff-*` obligatoire (non-négociable), scope CSS strict.
5. **RGPD** — aucune donnée personnelle visiteur (IP, UA, cookie). Tracking = simple incrémentation de compteur agrégé. Rate-limit en mémoire volatile (transients TTL 60s).

**Dépendances techniques identifiées**

| Dépendance | Criticité | Source |
|---|---|---|
| WordPress 6.0+ | Bloquante | Plateforme |
| PHP 8.0+ | Bloquante | Environnement |
| `@wordpress/scripts` | Haute | Build officiel WP |
| React 18 | Haute | Admin UI |
| Tailwind CSS | Haute | Styling |
| Radix UI | Haute | Primitives accessibles |
| Lucide Icons | Moyenne | Iconographie |
| Jest + Testing Library | Moyenne | Tests React |
| PHPUnit | Haute | Tests PHP |
| Playwright | Moyenne | Tests E2E |
| GitHub Actions (optionnel) | Basse | CI release |

### Cross-Cutting Concerns Identified

**1. Cache & Invalidation**
- Concerne : rendu templates (front), liste produits (admin), dashboard, preview
- Stratégie : transients WP + hooks d'invalidation (`save_post_aff_product`, `updated_post_meta`, `deleted_post`, édition de profil)
- Pattern : Cache-Aside avec dépendances explicites (à détailler en Step 5)

**2. Sécurité (traverse tout)**
- Nonces WP sur toutes actions admin
- Capabilities `edit_posts` minimum
- Sanitization entrées / Escaping sorties
- Validation URL allowlist par profil (NFR-S6)
- Rate-limiting volatil anti click-fraud (NFR-S7)

**3. Détection & Application du thème**
- Mécanisme : `wp_get_global_styles()` (FSE) ou heuristique CSS (thèmes classiques)
- Stockage : CSS variables partagées admin React + front PHP (source de vérité unique)

**4. Build & Assets**
- Tailwind avec prefix `aff-*`
- Purge agressif (< 10KB CSS critique inliné)
- Code-splitting admin React (< 2MB initial)
- Enqueue WP propre (`wp_enqueue_scripts` / `enqueue_block_editor_assets`)

**5. Internationalisation**
- Text domain `all-affiliate`
- `__()`, `_e()`, `esc_html__()` côté PHP
- `@wordpress/i18n` côté React
- FR seul au MVP, pattern respecté pour V2 facile

**6. Accessibility (WCAG 2.1 AA)**
- Radix UI primitives + semantic HTML + ARIA custom
- Validation axe-core + Lighthouse en CI

**7. Performance budget**
- JS < 50KB gzipped front, < 2MB admin
- CSS < 10KB critique inline
- Lighthouse Mobile ≥ 90
- Architecture orientée cache, pas de requêtes lourdes en temps réel

**8. Testing strategy**
- Backend PHP : PHPUnit avec fixtures DB
- Frontend React : Jest + Testing Library (comportement)
- E2E : Playwright sur les 6 journeys
- Coverage : ≥ 70% PHP, ≥ 50% React critiques

### Architectural Implications Summary

Ce projet nécessite une architecture qui :

1. Sépare proprement stockage (CPT WP) et interface (SPA React) — Option C validée
2. Expose une API REST claire et versionnée (`/wp-json/aff/v1/*`) comme contrat front/back
3. Cache agressivement avec invalidation par hooks WP stricte
4. Isole le CSS du plugin via prefix Tailwind `aff-*` obligatoire
5. Respecte l'écosystème WP : pas de tables custom, pas de dépendances plugins, pas d'API externes au MVP
6. Est testable à tous les niveaux : unit PHP, unit React, E2E Playwright
7. Respecte les performances dès la conception (bundle, cache, lazy-load)
8. Est packageable pour l'updater.php existant sans modification

---

## Starter Template Evaluation

### Primary Technology Domain

**Plugin WordPress hybride** (PHP + React admin + Gutenberg block + CSS Tailwind).

Les starters classiques de développement web (Next.js, Vite, Remix) ne sont **pas applicables** — on ne fait pas une SPA standalone. On construit un plugin WP dont l'admin est React embedded et le front est PHP server-rendered.

### Starter Options Considered

1. **`@wordpress/create-block` (officiel WP)** — Génère un bloc Gutenberg isolé. Trop limité pour nos besoins (bloc + admin React complet + templates PHP + design system).
2. **`wp-cli plugin create`** — Génère un squelette PHP minimaliste, pas de config React/Webpack/Tailwind. Trop basique.
3. **Boilerplates communautaires** (ex: `react-wp-scripts`, `wp-reactivate`) — Souvent datés (2020-2022), pas maintenus, patterns obsolètes.
4. **"WordPress Plugin Boilerplate" (DevinVinson)** — Structure PHP OOP rigide, pas de support React moderne.
5. 🏆 **Minimal custom scaffolding avec `@wordpress/scripts`** — Recommandé.

### Selected "Starter" : Minimal custom scaffolding avec `@wordpress/scripts`

**Rationale for Selection**
- ✅ `@wordpress/scripts` est le build standard officiel WP (webpack préconfiguré, support TS, sass, CSS, hot-reload)
- ✅ `@wordpress/create-block` nous donne un point de départ propre pour le bloc Gutenberg
- ✅ Pas de code mort à supprimer (vs starter communautaire)
- ✅ On contrôle à 100% la structure (alignée avec la spec UX)
- ✅ Compatible avec l'infra updater existante

### Initialization Commands

```bash
# 1. Créer le squelette de bloc Gutenberg via create-block
npx @wordpress/create-block@latest all-affiliate --variant=dynamic --template-type=block-only

# 2. Renommer en plugin complet (on élargit le scope au-delà du bloc seul)
# (migration manuelle du dossier blocks/ vers structure finale)

# 3. Installer les dépendances supplémentaires
cd all-affiliate
npm install --save-dev \
  tailwindcss postcss autoprefixer \
  @radix-ui/react-dialog @radix-ui/react-popover @radix-ui/react-dropdown-menu \
  @radix-ui/react-tabs @radix-ui/react-tooltip @radix-ui/react-select \
  @radix-ui/react-checkbox @radix-ui/react-switch @radix-ui/react-slider \
  @radix-ui/react-accordion @radix-ui/react-scroll-area @radix-ui/react-toast \
  lucide-react \
  react-router-dom \
  @tanstack/react-query

npm install --save-dev \
  @testing-library/react @testing-library/jest-dom \
  @types/wordpress__blocks @types/wordpress__components \
  @playwright/test \
  typescript

# 4. Initialiser Tailwind avec prefix
npx tailwindcss init -p
# Puis éditer tailwind.config.js → prefix: 'aff-'
```

### Architectural Decisions Provided by this Setup

**Language & Runtime**
- PHP 8.0+ avec types stricts (`declare(strict_types=1)`)
- TypeScript 5+ pour l'admin React (pas de JS pur)
- Node 18+ requis pour le build

**Styling Solution**
- Tailwind CSS v3 avec prefix `aff-*`
- PostCSS + Autoprefixer
- CSS variables pour les Design Tokens
- Purge agressive au build (classes `aff-*` utilisées uniquement)

**Build Tooling**
- `@wordpress/scripts` (webpack préconfiguré WP) — standard officiel
- Entry points multiples : admin React / bloc Gutenberg / front JS micro
- Code-splitting automatique admin (chunks par route React)
- Tree-shaking Radix UI + Lucide

**Testing Framework**
- PHPUnit 10+ pour le backend PHP
- Jest inclus via `@wordpress/scripts` pour React
- Testing Library pour tests comportementaux
- Playwright pour E2E (scénarios des 6 journeys)

**Structure de code** (détaillée en Step 6)

```
all-affiliate/
├── all-affiliate.php              ← Plugin entry (header WP + bootstrap)
├── composer.json                  ← Autoload PSR-4 "AllAffiliate\\"
├── package.json                   ← Deps npm
├── tailwind.config.js             ← prefix: 'aff-'
├── src/                           ← Code PHP (namespace AllAffiliate)
│   ├── Plugin.php
│   ├── CPT/                       ← Custom Post Type + meta schemas
│   ├── REST/                      ← Endpoints /wp-json/aff/v1/*
│   ├── Proxy/                     ← /go/{slug} rewrite
│   ├── Platforms/                 ← Platform Profiles engine
│   ├── Templates/                 ← 6 templates PHP (render_callback)
│   ├── Cache/                     ← Transients + invalidation hooks
│   ├── Security/                  ← Nonces, capabilities, validation URL
│   ├── Admin/                     ← Menu admin, React mount point
│   └── Front/                     ← Enqueue front, hydration
├── assets/
│   ├── admin-react/               ← App React (TypeScript)
│   │   ├── primitives/            ← Niveau 1
│   │   ├── composites/            ← Niveau 2
│   │   ├── business/              ← Niveau 3 (products/platforms/...)
│   │   ├── layout/                ← Niveau 4 (AppShell, Sidebar)
│   │   ├── routes/                ← Pages React Router
│   │   ├── hooks/
│   │   ├── api/                   ← Client REST
│   │   ├── store/                 ← State management
│   │   ├── styles/                ← Tailwind + tokens
│   │   ├── index.tsx
│   │   └── tsconfig.json
│   ├── gutenberg-block/
│   │   ├── edit.tsx
│   │   ├── save.tsx
│   │   ├── block.json
│   │   └── index.tsx
│   └── front/                     ← Micro JS < 50KB
│       ├── tracking.ts
│       └── hydration.ts
├── build/                         ← Output Webpack
├── tests/
│   ├── php/                       ← PHPUnit
│   ├── js/                        ← Jest
│   └── e2e/                       ← Playwright
├── languages/                     ← i18n
├── update.json                    ← Manifest updater.php
├── readme.txt                     ← WP Plugin format
└── .github/workflows/
```

**Development Experience**
- Hot reload via `wp-scripts start`
- TypeScript strict mode
- ESLint + Prettier (présets `@wordpress/eslint-plugin`)
- PHPCS avec WordPress Coding Standards (via composer)
- Pre-commit hooks via husky + lint-staged (optionnel)

**Note** : L'initialisation du projet avec cette commande et structure sera la **première story du sprint 1** (Phase 1 Fondations).

---

## Core Architectural Decisions

### Decision Priority Analysis

**Already Decided** (par PRD, UX Spec ou Step 3 — ne pas rouvrir) :
- Stockage : CPT WP natif (`aff_product` + postmeta + options) — pas de table SQL custom
- Styling : Tailwind v3 préfixé `aff-*`
- Build : `@wordpress/scripts` (webpack préconfiguré WP)
- Tests : PHPUnit (PHP) + Jest/Testing Library (React) + Playwright (E2E)
- Sécurité de base : nonces WP, capabilities, sanitization/escaping, validation URL allowlist, anti-fraude transients volatiles
- API : REST WP sous `/wp-json/aff/v1/*`
- Cache : transients WP + hooks d'invalidation
- Distribution : updater.php existant + GitHub releases + `update.json`
- Language : PHP 8.0+ avec `declare(strict_types=1)` + TypeScript 5+ strict
- Design System : Tailwind + Radix UI + Lucide icons + `@wordpress/components` limité

**Critical & Important Decisions** : résolues ci-dessous.

**Deferred (Post-MVP)** : observability externe (Sentry), multi-sites management centralisé, analytics avancée.

### Data Architecture

#### Custom Post Type `aff_product`

```php
register_post_type('aff_product', [
    'public' => false,
    'publicly_queryable' => false,
    'show_ui' => false,
    'show_in_menu' => false,
    'show_in_rest' => true,
    'rest_base' => 'products',
    'rest_namespace' => 'aff/v1',
    'supports' => ['title', 'thumbnail', 'custom-fields'],
    'capability_type' => 'post',
    'map_meta_cap' => true,
]);
```

#### Postmeta schema (préfixe `_aff_`, underscore = hidden dans admin WP natif)

| Meta key | Type | Usage |
|---|---|---|
| `_aff_platform_id` | string | ID du profil plateforme (ex: `amazon_fr`, `custom_trekpartner`) |
| `_aff_product_id` | string | ASIN ou ID produit spécifique |
| `_aff_url_raw` | string (url) | URL cible brute (avant proxy) — debug/audit |
| `_aff_slug` | string | Slug unique pour `/go/{slug}` |
| `_aff_click_count` | integer | Compteur total de clics (atomique) |
| `_aff_enabled_fields` | array (JSON) | Champs optionnels activés : `["score", "stars", "pros_cons"]` |
| `_aff_score` | integer (0-10) | Score jauge |
| `_aff_stars` | float (0-5) | Note étoiles |
| `_aff_price` | float | Prix saisi manuellement |
| `_aff_price_currency` | string (ISO 4217) | Devise (défaut EUR) |
| `_aff_price_discount_percent` | integer | % réduction |
| `_aff_pros` | array (JSON strings) | Liste des pour |
| `_aff_cons` | array (JSON strings) | Liste des contre |
| `_aff_badge_type` | enum | "none"/"favorite"/"best"/"cheapest"/"custom" |
| `_aff_badge_custom_label` | string | Label si badge type="custom" |
| `_aff_schedule_start` | datetime | Date début affichage (FR18) |
| `_aff_schedule_end` | datetime | Date fin affichage |
| `_aff_is_active` | boolean | Cache du calcul "actif" (tag présent + date valide) |

#### Options WP (préfixe `aff_`)

| Option key | Type | Usage |
|---|---|---|
| `aff_platforms` | array (JSON) | Définition des profils (préinstallés + custom) |
| `aff_platform_tags` | array (JSON) | Map `platform_id => tag` (tags globaux) |
| `aff_design_tokens` | array (JSON) | Design Tokens globaux (palette, typo, spacing, ...) |
| `aff_button_library` | array (JSON) | Variantes boutons sauvegardés (DT#3-lite) |
| `aff_disclosure_enabled` | boolean | Activation globale de la disclosure |
| `aff_disclosure_text` | string | Texte de disclosure |
| `aff_settings` | array (JSON) | Autres settings (cache TTL, version, ...) |
| `aff_version` | string | Version installée (pour migrations futures) |

#### Exemple de profil plateforme (dans `aff_platforms`)

```json
{
  "amazon_fr": {
    "id": "amazon_fr",
    "name": "Amazon France",
    "icon_url": "/wp-content/plugins/all-affiliate/assets/icons/amazon.svg",
    "enabled": true,
    "builtin": true,
    "url_template": "https://www.amazon.fr/dp/{PRODUCT_ID}?tag={MY_TAG}&linkCode=ll1",
    "url_domains": ["amazon.fr", "www.amazon.fr"],
    "extraction_regex": [
      "/\\/dp\\/([A-Z0-9]{10})/i",
      "/\\/gp\\/product\\/([A-Z0-9]{10})/i",
      "/^([A-Z0-9]{10})$/"
    ],
    "fields": [
      { "id": "PRODUCT_ID", "label": "ASIN", "required": true, "placeholder": "B08N5WRWNW" }
    ]
  }
}
```

#### Validation Strategy

**Double validation : client + serveur**

- **Côté client (React)** : validation immédiate pour UX via **`zod`** (< 8KB gzipped, typé). Validation par blur + par changement pour formats connus.
- **Côté serveur (PHP)** : validation autoritative — sanitization WP (`sanitize_text_field`, `esc_url_raw`, `absint`), validation métier (regex d'extraction, allowlist domaine, format d'ID), rejet avec WP_Error + HTTP 400.

**Jamais faire confiance au client** — client pour UX, serveur pour sécurité.

#### Migration / Activation / Désactivation

- **`register_activation_hook`** :
  - Créer le CPT (déjà registered on `init`, mais flush rewrite rules)
  - Insérer les 12 profils plateformes préinstallés si absents
  - Détecter les Design Tokens initiaux depuis le thème actif
  - Définir `aff_version`
- **`register_deactivation_hook`** :
  - **Ne supprime PAS les données**
  - Flush rewrite rules
- **`register_uninstall_hook`** (dans `uninstall.php`) :
  - Demande préalable (option) si suppression des données
  - Si oui : delete all `aff_product` posts + postmeta + options `aff_*` + transients `aff_*`
  - Si non : rien toucher

**Migration future (Post-MVP)** : classe `AllAffiliate\Migrations\Manager` qui compare `aff_version` → applique migrations séquentielles (`Migration_0_2_0_RenameField`, etc.).

### Authentication & Security

#### Pattern unifié pour l'accès REST

Tous les endpoints `aff/v1/*` :
- `permission_callback` = vérification de capability + nonce WP pour actions (write)
- Lecture seule : capability `edit_posts`
- Écriture : capability `edit_posts` + nonce (`X-WP-Nonce` header)

```php
register_rest_route('aff/v1', '/products/(?P<id>\d+)', [
    'methods' => 'POST',
    'callback' => [ProductController::class, 'update'],
    'permission_callback' => function ($request) {
        return current_user_can('edit_posts')
            && wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
    },
]);
```

**Niveau de capability par action**
- Lecture produits / profils / tokens : `edit_posts`
- Création / modification produits : `edit_posts`
- Suppression produits : `delete_posts`
- Modification settings globaux (tokens, disclosure, platforms) : `manage_options`
- Accès dashboard / stats : `edit_posts`

#### Rate-limiting anti click-fraud (proxy `/go/`)

Algorithme : fenêtre glissante en transients volatiles, **sans persistance** d'IP/UA en clair.

```php
$hash = hash('sha256', $_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT'] . $slug);
$key = 'aff_rl_' . substr($hash, 0, 24);
$count = (int) get_transient($key);

if ($count >= 5) {
    wp_redirect($target_url, 302);  // Redirect OK mais sans incrémenter
    exit;
}

set_transient($key, $count + 1, 60);
increment_click_count($product_id);
wp_redirect($target_url, 302);
exit;
```

**Propriétés** : jamais de persistance d'IP/UA (hash détruit en 60s), 5 clics max par combinaison IP+UA+produit en 60s.

#### Validation URL allowlist

Chaque profil expose `url_domains: [...]`. L'URL finale construite doit matcher un de ces domaines avant redirect. Sinon → HTTP 400 + log d'erreur WP.

### API & Communication

#### Pagination

**Offset-based** (standard REST WP) :
```
GET /wp-json/aff/v1/products?page=2&per_page=20&search=...&orderby=click_count&order=desc
```

Headers de réponse : `X-WP-Total`, `X-WP-TotalPages`.

#### Error Handling Standard

**Format unifié pour toutes les erreurs REST**

```json
{
  "code": "aff_platform_tag_missing",
  "message": "Le tag d'affiliation pour Amazon FR n'est pas configuré.",
  "data": {
    "status": 400,
    "platform_id": "amazon_fr",
    "action": {
      "label": "Configurer le tag",
      "deep_link": "/wp-admin/admin.php?page=all-affiliate&view=platforms&profile=amazon_fr"
    }
  }
}
```

**Convention de codes** : `aff_{domain}_{issue}` (ex: `aff_platform_tag_missing`, `aff_product_url_invalid`, `aff_cache_clear_failed`).

**HTTP status** : 400 (validation), 403 (capability), 404 (not found), 409 (conflict), 500 (serveur).

Côté React : hook `useApiError(error)` qui affiche un toast avec `action.label` en deep-link.

### Frontend Architecture

#### Routing React

**Choix : `react-router-dom` v6 en HashRouter**

- Routes principales : `/`, `/products`, `/products/new`, `/products/:id`, `/platforms`, `/platforms/:id`, `/templates`, `/design`, `/settings`
- **HashRouter** : simpler dans le contexte WP admin, pas de conflit avec les query params de `admin.php`
- `basename` pas nécessaire avec HashRouter

**Alternatives rejetées** : TanStack Router (trop lourd pour 10 routes), `@wordpress/router` (trop léger).

#### State Management

**Choix : `TanStack Query` + `zustand`**

- **TanStack Query** (`@tanstack/react-query`) pour **toute donnée serveur** (produits, profils, tokens, stats)
  - Cache automatique + invalidation mutual
  - Loading/error states gérés
  - Refetch on focus/reconnect
  - Optimistic updates pour UX fluide
- **Zustand** pour l'**état UI local** (modales ouvertes, sélection multiple, filtres actifs)
  - API ultra-simple, < 2KB
  - Supports middleware (persist pour filtres via localStorage)
- **Pas de `@wordpress/data`** — plus verbeux que Zustand, moins bon DX

#### Fetching / REST client

**TanStack Query** comme wrapper. **`fetch` natif** en dessous (pas Axios). Helper `apiFetch` qui :
- Ajoute `X-WP-Nonce` header automatiquement
- Gère le préfixe `/wp-json/aff/v1/`
- Parse les erreurs au format standard
- Throw `ApiError` typé

#### Component architecture

Respecte les 5 niveaux définis dans UX Spec Step 11 : primitives / composites / business / layout / templates front (PHP).

#### Performance optimizations

- Code-splitting par route (React Router v6 native)
- Lazy-loading : `const ProductEditPage = lazy(() => import('./ProductEditPage'))`
- Memo sur composants recevant props complexes
- Skeleton loaders pendant queries (état `isLoading`)
- Zustand avec selectors pour éviter re-renders inutiles

### Infrastructure & Deployment

#### CI/CD — Intégration avec le Makefile existant

**Décision Cyril : le Makefile existant gère déjà GitHub Actions.** Le plugin All Affiliate s'intègre à cette infra sans la reproduire.

**Ce que le plugin doit exposer pour compatibilité** :
- **Targets Makefile standards** attendus par l'infra existante (à confirmer selon Makefile) — typiquement `make build`, `make test`, `make lint`, `make release`
- **Scripts npm / composer conformes** aux targets Make (ex: `npm run build` appelé par `make build`)
- **Format `update.json` à la racine** attendu par `updater.php`
- **Tag Git + GitHub Release** produit automatiquement par le workflow release existant

**Scripts npm suggérés** (à câbler dans le Makefile) :
```json
{
  "scripts": {
    "build": "wp-scripts build",
    "start": "wp-scripts start",
    "lint:js": "wp-scripts lint-js",
    "lint:css": "wp-scripts lint-style",
    "test": "wp-scripts test-unit-js",
    "test:e2e": "playwright test",
    "packages-update": "wp-scripts packages-update"
  }
}
```

**Scripts composer suggérés** :
```json
{
  "scripts": {
    "test": "phpunit",
    "phpcs": "phpcs --standard=WordPress src/",
    "phpcbf": "phpcbf --standard=WordPress src/"
  }
}
```

**Action immédiate** : lors de l'initialisation du projet (première story Sprint 1), inspecter le Makefile de Cyril pour aligner les targets et les noms de scripts avec ses conventions existantes.

#### Monitoring / Logging

**Au MVP : local uniquement.**

- Erreurs PHP : `error_log('[All Affiliate] ' . $msg)` → `wp-content/debug.log` si `WP_DEBUG_LOG=true`
- Erreurs React : `console.error()` + (optionnel) capture en mémoire admin via Zustand → visible dans Settings > Debug
- **Pas de Sentry / DataDog / Rollbar** au MVP (usage perso, overhead inutile)

**V2 possible** : wrapper pluggable pour pousser vers un service externe si Cyril lance une V2 publique.

#### Environment Configuration

- Pas de fichier `.env` (plugin WP, tout vit dans `wp-config.php` de l'hôte)
- Variables d'env pertinentes via `defined('WP_DEBUG')`, etc.
- Feature flags : stockés dans `aff_settings` (option WP), pas en `.env`

### Decision Impact Analysis

**Implementation Sequence** (ordre d'implémentation des décisions pour dérisquer)

1. Structure PHP (PSR-4 autoload) + CPT registration → base
2. REST endpoints squelette avec permission_callback + validation → contrat API
3. Data schema (postmeta + options) → modèle de données
4. Proxy `/go/` avec rate-limit → cœur métier
5. Platform Profiles engine (extraction, construction URL) → cœur métier
6. Cache + invalidation → performance
7. Admin React shell (AppShell, routing, TanStack Query) → interface
8. Forms (Products, Platforms) avec zod + Radix → UX création
9. Templates PHP (6 rendus) → côté visiteur
10. Bloc Gutenberg (edit.tsx + render.php) → insertion éditorial
11. Dashboard (stats queries + graphs) → data
12. Design Tokens + détection thème → polish visuel
13. Tests E2E (6 journeys Playwright) → assurance qualité
14. Alignement Makefile + build/release via infra existante → distribution

**Cross-Component Dependencies**

- Platform Profiles engine → nécessaire pour Proxy et Forms
- Cache → nécessaire pour Templates et Dashboard
- Design Tokens → nécessaire pour Admin React ET Templates PHP
- REST endpoints → nécessaires pour Admin React (sans, rien ne marche)
- Bloc Gutenberg → dépend des Templates PHP (renderCallback)

---

## Implementation Patterns & Consistency Rules

### Critical Conflict Points

~15 zones de nommage/structure/format où des choix divergents entre devs/agents pourraient créer des conflits : nommage PHP (classes, méthodes, meta keys), nommage TypeScript (composants, hooks, types), structure de fichiers, format des réponses REST, gestion d'erreurs, loading states, patterns de test, style CSS, hooks WordPress.

### Naming Patterns

#### PHP (namespace `AllAffiliate`)

| Item | Pattern | Exemple |
|---|---|---|
| Namespace racine | `AllAffiliate\` | `AllAffiliate\REST\Controllers\ProductController` |
| Classes | `PascalCase` | `ProductController`, `CacheInvalidator`, `PlatformProfile` |
| Interfaces | `PascalCase`, suffix `Interface` | `CacheableInterface`, `PlatformProfileInterface` |
| Traits | `PascalCase`, suffix `Trait` | `LoggerTrait`, `ValidatableTrait` |
| Méthodes | `camelCase` | `getProductById()`, `invalidateCache()` |
| Propriétés | `camelCase` | `$productId`, `$platformTag` |
| Constantes de classe | `UPPER_SNAKE_CASE` | `CACHE_TTL`, `MAX_CLICKS_PER_MINUTE` |
| Fonctions globales (évitées) | `aff_snake_case()` | `aff_get_version()`, `aff_build_url()` |
| Hooks (actions/filters) | `all_affiliate_snake_case` | `all_affiliate_before_render_template`, `all_affiliate_product_saved` |
| Fichiers | `PascalCase.php` pour classes | `ProductController.php`, `PlatformProfile.php` |

**Meta keys & options — convention stricte**
- Postmeta privées : **préfixe `_aff_`** (underscore pour cacher de l'admin WP natif) → `_aff_platform_id`, `_aff_click_count`
- Postmeta publiques : préfixe `aff_` (rare)
- Options WP : préfixe `aff_` → `aff_platforms`, `aff_design_tokens`, `aff_version`
- Transients : préfixe `aff_` → `aff_rl_{hash}`, `aff_cache_template_{id}`, `aff_stats_{period}`

#### TypeScript / React

| Item | Pattern | Exemple |
|---|---|---|
| Composants React | `PascalCase` | `ProductForm`, `TemplateGallery`, `DashboardKPI` |
| Hooks custom | `camelCase`, prefix `use` | `useProducts()`, `useDesignTokens()`, `useDebouncedValue()` |
| Fonctions utilitaires | `camelCase` | `formatPrice()`, `buildUrl()`, `sanitizeInput()` |
| Variables | `camelCase` | `productId`, `isLoading`, `filteredProducts` |
| Constantes | `UPPER_SNAKE_CASE` | `API_BASE_URL`, `CACHE_TTL_SECONDS` |
| Types & interfaces | `PascalCase` | `Product`, `PlatformProfile`, `DesignTokens` |
| Enums (préférer const assertions) | `PascalCase` | `const BadgeType = { Favorite: 'favorite', ... } as const` |
| Types de props | `PascalCase`, suffix `Props` | `ProductFormProps`, `TemplateGalleryProps` |

**Fichiers TypeScript**
- Composants : `PascalCase.tsx`
- Hooks : `camelCase.ts` avec prefix use
- Types : `camelCase.types.ts` ou regroupés dans `types/index.ts`
- Utils : `camelCase.ts`
- Tests : `*.test.tsx` ou `*.test.ts` (co-located)

#### CSS / Tailwind

| Item | Pattern | Exemple |
|---|---|---|
| Classes Tailwind | Toujours `aff-` prefix | `aff-p-4`, `aff-flex`, `aff-bg-primary` |
| CSS variables | `--aff-{category}-{name}` | `--aff-color-primary`, `--aff-space-4` |
| Classes custom (rares) | `aff-{kebab-case}` | `aff-product-card`, `aff-template-preview` |
| `data-*` attributes | `data-aff-{kebab}` | `data-aff-theme="dark"`, `data-aff-state="loading"` |

#### REST API

| Item | Pattern | Exemple |
|---|---|---|
| Namespace | `aff/v{major}` | `aff/v1` |
| Endpoints (ressources) | Pluriel, kebab-case | `/products`, `/platforms`, `/design-tokens` |
| Path params | `/{id}` (numeric) ou `/{slug}` (string) | `/products/42`, `/platforms/amazon_fr` |
| Query params | `snake_case` (standard REST WP) | `?per_page=20&orderby=click_count` |
| Headers custom | `X-WP-*` pour WP standard, `X-Aff-*` pour custom | `X-WP-Nonce`, `X-WP-Total` |

### Structure Patterns

**Tests**
- Co-located pour tests unitaires React : `Button.test.tsx` à côté de `Button.tsx`
- Centralisé pour PHP : `tests/php/unit/`, `tests/php/integration/`
- Centralisé pour E2E : `tests/e2e/` (Playwright)

**Component organization (React)** — par niveau d'abstraction, pas par feature :
- `primitives/` (Button, Input, Badge — réutilisables partout)
- `composites/` (SearchCombobox, EmptyState)
- `business/` (ProductForm, TemplateGallery — spécifiques All Affiliate)
- `layout/` (AppShell, Sidebar, TopBar)
- `routes/` (pages = assemblages)

**PHP classes organization** — par domaine (DDD léger) :
- `src/CPT/`, `src/REST/`, `src/Platforms/`, `src/Proxy/`, `src/Templates/`, `src/Cache/`, `src/Security/`, `src/Admin/`, `src/Front/`

**Utilities**
- PHP : `src/{Domain}/` si domaine-spécifique ; `src/Support/` si cross-domain
- TypeScript : `admin-react/lib/` (utilitaires) et `admin-react/hooks/` (hooks React) — pas de mixage
- Pas de "god module" (`helpers.ts`, `utils.ts` géants) — découper par domaine

### Format Patterns

#### API Response Format

**Succès** : réponse directe (pas de wrapper `{data: ..., meta: ...}` inutile)

```json
// GET /wp-json/aff/v1/products/42 → 200 OK
{
  "id": 42,
  "title": "Tente MSR Hubba Hubba NX",
  "platform_id": "amazon_fr",
  "product_id": "B08N5WRWNW"
}
```

**Liste paginée** : array direct + headers `X-WP-Total`, `X-WP-TotalPages`.

**Erreur** : format unifié (défini en Step 4) avec `code` `aff_*` + `message` + `data.status` + optionnel `data.action`.

#### JSON Field Naming

**`snake_case` dans les payloads** (convention REST WP) : `platform_id`, `click_count`, `created_at`.

**Côté React / TypeScript** : conversion auto en `camelCase` via helper `camelizeKeys(response)` au parsing. Types TS en `camelCase`.

```tsx
interface Product {
  id: number;
  platformId: string;
  clickCount: number;
  createdAt: string;
}

const product = await apiFetch<Product>('/products/42');
```

#### Date / Time Format

- ISO 8601 strings en UTC (`2026-04-24T14:30:00Z`)
- Pas de timestamps Unix
- Conversion locale dans le frontend via `Intl.DateTimeFormat`

#### Booléens

- Vrais booléens JSON (`true`/`false`), pas `1`/`0`
- Exceptions : meta values numériques WP → conversion côté PHP dans le controller

### Communication Patterns

#### Hooks WordPress

Convention : `all_affiliate_{verb}_{noun}` (snake_case)

| Hook | Type | Usage |
|---|---|---|
| `all_affiliate_product_saved` | action | Après sauvegarde d'un produit |
| `all_affiliate_product_deleted` | action | Après suppression |
| `all_affiliate_before_render_template` | filter | Modifier les data avant rendu template |
| `all_affiliate_after_render_template` | filter | Modifier le HTML rendu |
| `all_affiliate_platform_tag_missing` | action | Tag manquant détecté |
| `all_affiliate_click_recorded` | action | Clic compté |
| `all_affiliate_extraction_failed` | action | Extraction ID ratée (debug) |

**Règle** : toute action métier significative expose un hook pour extensibilité.

#### Events côté React (internes)

- Pas de EventEmitter custom — utiliser mécaniques React/Zustand
- TanStack Query invalidations comme source de vérité pour les "events" métier
- Zustand pour les actions UI pures

#### State update patterns

**Immutabilité stricte côté React** :
- Zustand : `set(state => ({ ...state, ... }))` ou immer-middleware
- Pas de mutation directe

**PHP** : privilégier les value objects immutables pour les DTOs (`readonly` properties PHP 8.1+).

### Process Patterns

#### Error Handling

**Côté PHP / REST**

```php
public function update(WP_REST_Request $request): WP_REST_Response|WP_Error
{
    try {
        $product = $this->productService->update($request->get_params());
        return rest_ensure_response($product);
    } catch (ValidationException $e) {
        return new WP_Error('aff_product_validation_failed', $e->getMessage(),
            ['status' => 400, 'errors' => $e->getErrors()]);
    } catch (\Throwable $e) {
        error_log('[All Affiliate] Product update failed: ' . $e->getMessage());
        return new WP_Error('aff_internal_error',
            __('Une erreur est survenue. Réessaie.', 'all-affiliate'),
            ['status' => 500]);
    }
}
```

Règles :
- Toujours retourner `WP_Error` avec code `aff_*` pour les erreurs attendues
- `error_log()` pour toute exception inattendue
- Messages user-friendly via `__()` (traduits)
- Pas de stack trace exposée à l'utilisateur

**Côté React**

```tsx
const { data, error, isLoading } = useQuery({
  queryKey: ['products'],
  queryFn: fetchProducts,
});

if (isLoading) return <Skeleton />;
if (error) return <ErrorState error={error} />;
return <ProductList products={data} />;
```

Le composant `ErrorState` lit `error.data.action` et propose le deep-link si disponible.

#### Loading States

Naming : toujours `isLoading`, `isFetching`, `isPending` (pas `loading`/`pending` sans prefix).

Règles :
- Jamais spinner plein écran (sauf cas explicite)
- Skeleton pour la structure
- Spinner inline dans les boutons (via `isLoading` prop)
- Skeleton shape = final shape (évite CLS)

#### Retry Patterns

- TanStack Query : retry auto 3× sur network errors, pas de retry sur 4xx
- PHP : pas de retry auto au MVP

#### Validation Timing

- À la frappe (debounce 200ms) : validation de format (regex ASIN, URL)
- Au blur : validation de champ complet
- À la soumission : validation serveur complète (autoritative)
- Pas de "validate all on submit" — erreurs visibles au plus tôt

### Enforcement Guidelines

**Tous les agents / développeurs MUST** :

1. Utiliser strict typing : `declare(strict_types=1)` PHP, `"strict": true` TS
2. Préfixer toutes les classes CSS avec `aff-`
3. Respecter PSR-4 autoload côté PHP (namespace = path)
4. Utiliser `WP_*` helpers pour la DB (jamais de SQL direct sans `$wpdb->prepare()`)
5. Passer par Radix UI pour toute composite interactive (dialog, popover, menu, tabs)
6. Convertir snake_case → camelCase au parsing REST côté React
7. Ajouter des hooks WP sur toute action métier significative
8. Respecter le budget perf : JS < 50KB front, LCP < 1.5s
9. Tester tout nouveau composant : unit pour primitives, integration pour business
10. Ne jamais faire confiance au client — validation serveur toujours autoritative

**Automatisation**
- PHPCS (WordPress Coding Standards) : bloque les PR non-conformes
- ESLint + Prettier : auto-fix au save + CI check
- Tailwind linting : scripts qui détectent les classes non-préfixées
- TypeScript strict : compile errors = blocage build
- Tests minimum coverage : CI échoue si < seuil (PHP 70%, React critiques 50%)

**Process de mise à jour des patterns**
- Toute modification des patterns doit être actée dans ce document avant implémentation
- Un PR modifiant les patterns doit inclure une migration des zones existantes

### Pattern Examples

**Good — PHP Controller**

```php
<?php
declare(strict_types=1);

namespace AllAffiliate\REST\Controllers;

use AllAffiliate\Platforms\PlatformProfile;
use AllAffiliate\Support\Sanitizer;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class PlatformController
{
    public function __construct(
        private readonly PlatformRepository $repository,
        private readonly Sanitizer $sanitizer
    ) {}

    public function update(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $profileId = $this->sanitizer->sanitizeKey($request->get_param('id'));
        $data = $this->sanitizer->sanitizeProfileData($request->get_json_params());

        try {
            $profile = $this->repository->update($profileId, $data);
            do_action('all_affiliate_platform_updated', $profile);
            return rest_ensure_response($profile->toArray());
        } catch (\InvalidArgumentException $e) {
            return new WP_Error('aff_platform_invalid', $e->getMessage(), ['status' => 400]);
        }
    }
}
```

**Good — React Composant**

```tsx
// admin-react/business/platforms/PlatformProfileCard.tsx
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, StatusPill } from '~/primitives';
import type { PlatformProfile } from '~/types';

interface PlatformProfileCardProps {
  profile: PlatformProfile;
  onEdit: (id: string) => void;
}

export function PlatformProfileCard({ profile, onEdit }: PlatformProfileCardProps) {
  const queryClient = useQueryClient();

  const toggleEnabled = useMutation({
    mutationFn: () => apiFetch(`/platforms/${profile.id}/toggle`, { method: 'POST' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['platforms'] }),
  });

  return (
    <article className="aff-p-4 aff-rounded-md aff-border aff-border-border aff-bg-surface">
      <header className="aff-flex aff-items-center aff-gap-3">
        <img src={profile.iconUrl} alt="" className="aff-w-8 aff-h-8" />
        <h3 className="aff-text-base aff-font-semibold">{profile.name}</h3>
        <StatusPill status={profile.enabled ? 'active' : 'inactive'} />
      </header>
      <footer className="aff-mt-4 aff-flex aff-gap-2">
        <Button variant="secondary" size="sm" onClick={() => onEdit(profile.id)}>
          Éditer
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => toggleEnabled.mutate()}
          isLoading={toggleEnabled.isPending}
        >
          {profile.enabled ? 'Désactiver' : 'Activer'}
        </Button>
      </footer>
    </article>
  );
}
```

**Anti-patterns à éviter**

- `$result = $wpdb->query("SELECT ... WHERE id = $id")` → SQL injection, utiliser `$wpdb->prepare()`
- `<div className="p-4 bg-blue-500">` → prefix manquant, utiliser `aff-p-4 aff-bg-primary`
- `useState(null)` puis `setLoading(true)` → utiliser `useQuery` qui gère ça
- `function getProductData()` en globale → créer une classe de service
- `console.log()` laissé en prod → utiliser `error_log()` côté PHP, supprimer en React
- `alert('Erreur!')` → utiliser le Toast + ErrorState components

---

## Project Structure & Boundaries

### Complete Project Directory Structure

```
all-affiliate/
│
├── all-affiliate.php                      # Plugin entry (header WP + bootstrap)
├── uninstall.php                          # Hook désinstallation (cleanup conditionnel)
├── composer.json                          # Autoload PSR-4 "AllAffiliate\\"
├── composer.lock
├── package.json                           # Deps npm
├── package-lock.json
├── tsconfig.json                          # TS strict
├── tailwind.config.js                     # prefix: 'aff-'
├── postcss.config.js
├── phpcs.xml.dist                         # WordPress Coding Standards
├── phpunit.xml.dist
├── playwright.config.ts
├── jest.config.js
├── .editorconfig
├── .gitignore
├── .gitattributes                         # Export-ignore pour ZIP release
├── Makefile                               # Intégration au Makefile existant Cyril
├── update.json                            # Manifest updater.php
├── readme.txt                             # WP Plugin format
├── README.md                              # Doc développeur
├── CHANGELOG.md
│
├── src/                                   # Code PHP namespace AllAffiliate
│   ├── Plugin.php                         #   Classe principale (bootstrap, register hooks)
│   ├── Container.php                      #   DI container léger (optionnel)
│   │
│   ├── CPT/                               #   Custom Post Type aff_product
│   │   ├── ProductPostType.php
│   │   ├── ProductMetaSchema.php
│   │   └── ProductRepository.php
│   │
│   ├── Platforms/                         #   Platform Profiles engine
│   │   ├── Profile.php                    #     Value object (readonly)
│   │   ├── ProfileRepository.php
│   │   ├── ProfileValidator.php
│   │   ├── UrlBuilder.php                 #     Construction URL depuis template + ID + tag
│   │   ├── IdExtractor.php                #     Extraction ID via regex (multi-format)
│   │   ├── DomainValidator.php
│   │   └── BuiltinProfiles.php            #     Les 12 profils préinstallés
│   │
│   ├── REST/                              #   Endpoints REST /wp-json/aff/v1/*
│   │   ├── RestManager.php
│   │   ├── Controllers/
│   │   │   ├── ProductController.php
│   │   │   ├── PlatformController.php
│   │   │   ├── DesignTokensController.php
│   │   │   ├── ButtonLibraryController.php
│   │   │   ├── DashboardController.php
│   │   │   ├── CacheController.php
│   │   │   └── SettingsController.php
│   │   ├── Middleware/
│   │   │   ├── PermissionCallback.php
│   │   │   └── ErrorResponseFactory.php
│   │   └── Schemas/
│   │       ├── ProductSchema.php
│   │       ├── PlatformSchema.php
│   │       └── DesignTokensSchema.php
│   │
│   ├── Proxy/                             #   /go/{slug} endpoint
│   │   ├── ProxyRouter.php                #     Rewrite rule + template_redirect
│   │   ├── ClickCounter.php
│   │   ├── RateLimiter.php                #     Anti-fraude transients volatiles
│   │   └── SlugGenerator.php
│   │
│   ├── Templates/                         #   Rendu serveur des 6 templates
│   │   ├── TemplateRegistry.php
│   │   ├── TemplateRenderer.php
│   │   ├── TemplateContext.php            #     DTO passé au template
│   │   ├── CardStandard.php
│   │   ├── CardInline.php
│   │   ├── CTA.php
│   │   ├── Grid.php
│   │   ├── TopN.php
│   │   └── ProsCons.php
│   │
│   ├── DesignTokens/                      #   Design Tokens + détection thème
│   │   ├── TokenRepository.php
│   │   ├── ThemeDetector.php              #     Détection thème actif (FSE + heuristique)
│   │   ├── TokenCssGenerator.php          #     Génération CSS variables (:root {...})
│   │   └── ButtonLibraryRepository.php
│   │
│   ├── Cache/                             #   Transients cache + invalidation
│   │   ├── CacheManager.php
│   │   ├── CacheKey.php
│   │   ├── CacheInvalidator.php           #     Hooks WP d'invalidation
│   │   └── CacheTag.php
│   │
│   ├── Security/                          #   Sécurité transversale
│   │   ├── NonceVerifier.php
│   │   ├── CapabilityChecker.php
│   │   ├── InputSanitizer.php
│   │   ├── OutputEscaper.php
│   │   └── UrlAllowlistValidator.php
│   │
│   ├── Admin/                             #   Admin UI (mount point React)
│   │   ├── AdminMenu.php
│   │   ├── ReactMountPoint.php
│   │   ├── AssetEnqueuer.php
│   │   └── ReactConfig.php                #     Config passée à React (nonce, user, routes, locale)
│   │
│   ├── Front/                             #   Enqueue + hydration front
│   │   ├── FrontAssetEnqueuer.php
│   │   ├── SchemaOrgRenderer.php          #     Injection JSON-LD Product
│   │   └── DisclosureRenderer.php
│   │
│   ├── Gutenberg/                         #   Bloc Gutenberg (serveur)
│   │   ├── BlockRegistrar.php
│   │   ├── BlockRenderer.php              #     render_callback → délègue TemplateRenderer
│   │   └── BlockAssetEnqueuer.php
│   │
│   ├── Updates/                           #   Compatibilité updater.php
│   │   ├── UpdateManifest.php
│   │   └── VersionChecker.php
│   │
│   ├── Migrations/                        #   Migrations (post-MVP, prépare structure)
│   │   └── MigrationManager.php
│   │
│   └── Support/                           #   Utilitaires cross-domain
│       ├── Arr.php
│       ├── Str.php
│       ├── Logger.php
│       └── Uuid.php
│
├── assets/                                # Sources front (compilées vers build/)
│   │
│   ├── admin-react/                       #   App React admin (TypeScript)
│   │   ├── index.tsx
│   │   ├── App.tsx
│   │   ├── styles/
│   │   │   ├── tailwind.css
│   │   │   └── tokens.css
│   │   │
│   │   ├── primitives/                    #     Niveau 1 (Button, Input, Badge, ...)
│   │   │   ├── Button.tsx + Button.test.tsx
│   │   │   ├── Input.tsx, Label.tsx, FormField.tsx, Textarea.tsx
│   │   │   ├── Badge.tsx, StatusPill.tsx, Skeleton.tsx, Spinner.tsx
│   │   │   ├── Avatar.tsx, Card.tsx, Separator.tsx, IconButton.tsx
│   │   │   └── index.ts
│   │   │
│   │   ├── composites/                    #     Niveau 2
│   │   │   ├── SearchCombobox.tsx, EmptyState.tsx, BulkActionsBar.tsx
│   │   │   ├── ConfirmDialog.tsx, DeepLinkBadge.tsx, InfoTooltip.tsx
│   │   │   ├── CopyButton.tsx, TestLinkButton.tsx, PageHeader.tsx
│   │   │   ├── FiltersBar.tsx, TagInput.tsx
│   │   │   └── index.ts
│   │   │
│   │   ├── business/                      #     Niveau 3 (organisé par domaine)
│   │   │   ├── products/
│   │   │   │   ├── ProductForm.tsx, ProductFormSplitView.tsx
│   │   │   │   ├── PreviewPane.tsx, PasteInput.tsx
│   │   │   │   ├── ProductListRow.tsx, OptionalFieldsToggleGroup.tsx
│   │   │   │   └── *.test.tsx
│   │   │   ├── platforms/
│   │   │   │   ├── PlatformSelector.tsx, PlatformProfileCard.tsx
│   │   │   │   ├── PlatformProfileEditor.tsx
│   │   │   │   └── *.test.tsx
│   │   │   ├── templates/
│   │   │   │   ├── TemplateGallery.tsx, TemplateCard.tsx, TemplatePreview.tsx
│   │   │   │   └── *.test.tsx
│   │   │   ├── dashboard/
│   │   │   │   ├── DashboardKPI.tsx, DashboardGraph.tsx, TopProductsList.tsx
│   │   │   │   └── *.test.tsx
│   │   │   └── design/
│   │   │       ├── DesignTokensEditor.tsx, ButtonLibraryEditor.tsx
│   │   │       ├── PreviewAllTemplatesPanel.tsx
│   │   │       └── *.test.tsx
│   │   │
│   │   ├── layout/                        #     Niveau 4
│   │   │   ├── AppShell.tsx, Sidebar.tsx, TopBar.tsx
│   │   │   ├── Breadcrumb.tsx, CommandPalette.tsx, SaveBar.tsx
│   │   │   └── *.test.tsx
│   │   │
│   │   ├── routes/                        #     Pages (assemblages)
│   │   │   ├── DashboardPage.tsx
│   │   │   ├── ProductListPage.tsx, ProductEditPage.tsx
│   │   │   ├── PlatformListPage.tsx, PlatformEditPage.tsx
│   │   │   ├── TemplateGalleryPage.tsx, DesignPage.tsx
│   │   │   └── SettingsPage.tsx
│   │   │
│   │   ├── api/                           #     Client REST
│   │   │   ├── client.ts                  #       apiFetch wrapper
│   │   │   ├── products.ts, platforms.ts, designTokens.ts
│   │   │   ├── buttonLibrary.ts, dashboard.ts, cache.ts, settings.ts
│   │   │   └── index.ts
│   │   │
│   │   ├── hooks/                         #     Hooks React custom
│   │   │   ├── useDebouncedValue.ts, useKeyboardShortcut.ts
│   │   │   ├── useApiError.ts, useAutosave.ts, useLocalStorage.ts
│   │   │   └── *.test.ts
│   │   │
│   │   ├── lib/                           #     Utilitaires
│   │   │   ├── camelize.ts, formatPrice.ts, buildUrl.ts
│   │   │   ├── sanitize.ts, focus.ts
│   │   │   └── *.test.ts
│   │   │
│   │   ├── store/                         #     Zustand stores
│   │   │   ├── uiStore.ts, filtersStore.ts
│   │   │   └── *.test.ts
│   │   │
│   │   ├── types/                         #     Types TypeScript
│   │   │   ├── product.ts, platform.ts, designTokens.ts, api.ts
│   │   │   └── index.ts
│   │   │
│   │   ├── schemas/                       #     Validation zod
│   │   │   ├── product.schema.ts, platform.schema.ts, designTokens.schema.ts
│   │   │
│   │   └── providers/                     #     React providers
│   │       ├── QueryProvider.tsx, ToastProvider.tsx, I18nProvider.tsx
│   │
│   ├── gutenberg-block/                   #   Bloc Gutenberg (React admin)
│   │   ├── index.tsx                      #     registerBlockType
│   │   ├── edit.tsx, save.tsx, block.json
│   │   ├── states/
│   │   │   ├── AffiliateBlockInitial.tsx, AffiliateBlockFilled.tsx
│   │   │   └── QuickCreateModal.tsx
│   │   ├── inspector/
│   │   │   └── AffiliateBlockInspector.tsx
│   │   └── style.css
│   │
│   └── front/                             #   Micro JS front (< 50KB)
│       ├── index.ts
│       ├── hydration.ts, tracking.ts, lazy-images.ts
│
├── templates/                             # Templates PHP front (partial files)
│   ├── card-standard.php, card-inline.php, cta.php
│   ├── grid.php, top-n.php, pros-cons.php
│   └── partials/
│       ├── score-gauge.php, stars-rating.php, pros-cons-table.php
│       ├── badge.php, cta-button.php
│
├── icons/                                 # SVG icônes plateformes préinstallées
│   ├── amazon.svg, awin.svg, rakuten.svg, cj.svg
│   ├── affilae.svg, effinity.svg, viator.svg, tiqets.svg
│   ├── musement.svg, getyourguide.svg, headout.svg, custom.svg
│
├── languages/                             # i18n
│   ├── all-affiliate.pot
│   ├── all-affiliate-fr_FR.po, all-affiliate-fr_FR.mo
│
├── build/                                 # Output Webpack (généré, .gitignore)
│   ├── admin-react/, gutenberg-block/, front/
│
├── vendor/                                # composer (.gitignore)
├── node_modules/                          # npm (.gitignore)
│
├── tests/                                 # Tests
│   │
│   ├── php/                               #   PHPUnit
│   │   ├── bootstrap.php
│   │   ├── fixtures/
│   │   │   ├── products.php, platforms.php, themes.php
│   │   ├── unit/
│   │   │   ├── Platforms/
│   │   │   │   ├── UrlBuilderTest.php, IdExtractorTest.php, ProfileValidatorTest.php
│   │   │   ├── Proxy/
│   │   │   │   ├── ClickCounterTest.php, RateLimiterTest.php, SlugGeneratorTest.php
│   │   │   ├── Templates/
│   │   │   │   └── TemplateRendererTest.php
│   │   │   ├── Cache/
│   │   │   │   ├── CacheManagerTest.php, CacheInvalidatorTest.php
│   │   │   ├── Security/
│   │   │   │   └── UrlAllowlistValidatorTest.php
│   │   │   └── DesignTokens/
│   │   │       └── ThemeDetectorTest.php
│   │   └── integration/
│   │       ├── REST/
│   │       │   ├── ProductControllerTest.php, PlatformControllerTest.php
│   │       │   └── DashboardControllerTest.php
│   │       ├── CPT/
│   │       │   └── ProductRepositoryTest.php
│   │       └── Proxy/
│   │           └── ProxyRouterTest.php
│   │
│   ├── js/                                #   Jest + Testing Library
│   │   ├── setup.ts
│   │   ├── primitives/, hooks/, lib/
│   │
│   └── e2e/                               #   Playwright
│       ├── fixtures/wp-setup.ts
│       ├── j1-first-deploy.spec.ts
│       ├── j2-article-routine.spec.ts
│       ├── j3-tag-migration.spec.ts
│       ├── j4-analytics-check.spec.ts
│       ├── j5-custom-platform.spec.ts
│       └── j6-recovery.spec.ts
│
└── .github/
    └── workflows/
        └── (délégué au Makefile existant de Cyril)
```

### Architectural Boundaries

#### API Boundaries (endpoints REST `aff/v1`)

| Endpoint | Methods | Capability | Usage |
|---|---|---|---|
| `/products` | GET, POST | `edit_posts` | Liste / crée produit |
| `/products/{id}` | GET, POST, DELETE | `edit_posts` / `delete_posts` | CRUD produit |
| `/products/{id}/duplicate` | POST | `edit_posts` | Duplication |
| `/products/bulk` | POST | `edit_posts` | Actions groupées |
| `/platforms` | GET, POST | `edit_posts` / `manage_options` | Liste / crée profil custom |
| `/platforms/{id}` | GET, PUT, DELETE | `manage_options` | CRUD profil |
| `/platforms/{id}/toggle` | POST | `manage_options` | Activer/désactiver |
| `/platforms/{id}/test` | POST | `edit_posts` | Tester URL construite |
| `/design-tokens` | GET, PUT | `manage_options` | Lecture/mise à jour |
| `/design-tokens/reset` | POST | `manage_options` | Reset depuis thème |
| `/button-library` | GET, POST | `manage_options` | Liste / crée variante |
| `/button-library/{id}` | PUT, DELETE | `manage_options` | Modif / supp |
| `/dashboard/stats` | GET | `edit_posts` | KPIs dashboard |
| `/dashboard/top-products` | GET | `edit_posts` | Top 5 produits |
| `/cache/purge` | POST | `manage_options` | Vider cache |
| `/settings` | GET, PUT | `manage_options` | Disclosure, misc |

**Endpoint public (non-REST)** : `/go/{slug}` — redirection 301/302, accessible anonyme.

#### Component Boundaries (React) — Règle de composition

Un composant ne peut importer que des composants de **niveau égal ou inférieur** :

```
Routes (pages)
    ↓
Layout (AppShell, Sidebar, ...)
    ↓
Business (ProductForm, TemplateGallery, ...)
    ↓
Composites (SearchCombobox, EmptyState, ...)
    ↓
Primitives (Button, Input, Badge, ...)
    ↓
Radix UI primitives + Tailwind
```

**Anti-pattern** : un Primitive qui importe un Business component (cycle).

#### Service Boundaries (PHP)

Chaque domaine `src/{Domain}/` est **autonome** — expose ses services via ses classes publiques, mais n'accède pas aux internals des autres domaines.

```
Admin → REST → Platforms, CPT, Cache, DesignTokens
Front → Templates → DesignTokens, Cache
Proxy → Platforms, CPT, Cache, Security
Gutenberg → Templates, CPT
```

**Dépendances autorisées** : tous les domaines peuvent importer `Support/`. `Security/` est importable partout. `Cache/` est importable par les domaines qui ont besoin de cache.

**Cycles à éviter** :
- `CPT` ne dépend PAS de `Templates` (modèle vs vue)
- `Platforms` ne dépend PAS de `REST` (modèle vs transport)
- `Plugin` ne dépend PAS de `Admin/`/`Front/` spécifiquement — injection via `Plugin::boot()`

#### Data Boundaries

Accès aux données WP natives centralisé via repositories :
- `ProductRepository` — seul point d'accès à `get_post()`, `WP_Query`, `get_post_meta()`, `update_post_meta()` pour les produits
- `ProfileRepository` — seul point d'accès à `get_option('aff_platforms')` / `update_option()`
- `TokenRepository` — seul point d'accès à `get_option('aff_design_tokens')`

**Règle** : aucun controller ou composant métier ne fait d'appel direct à `get_post_meta()` / `get_option()`. Toujours via le repository.

### Requirements to Structure Mapping

| FR Category | Dossiers principaux | Points d'entrée |
|---|---|---|
| **A. Platform Management** (FR1-7) | `src/Platforms/`, `src/REST/Controllers/PlatformController.php`, `assets/admin-react/business/platforms/`, routes Platform | `PlatformController::*`, `PlatformRepository::*` |
| **B. Product Management** (FR8-20) | `src/CPT/`, `src/REST/Controllers/ProductController.php`, `assets/admin-react/business/products/`, routes Product | `ProductController::*`, `ProductRepository::*` |
| **C. Link & Tracking** (FR21-25) | `src/Proxy/`, `src/Platforms/UrlBuilder.php`, `src/Security/UrlAllowlistValidator.php` | `ProxyRouter::handle()`, `UrlBuilder::build()` |
| **D. Content Authoring** (FR26-31) | `src/Gutenberg/`, `assets/gutenberg-block/` | `BlockRegistrar::register()`, `edit.tsx` |
| **E. Visual Design System** (FR32-37) | `src/DesignTokens/`, controllers DesignTokens, `assets/admin-react/business/design/` | `TokenRepository::*`, `ThemeDetector::detect()`, `DesignTokensEditor.tsx` |
| **F. Performance Monitoring** (FR38-39) | `src/REST/Controllers/DashboardController.php`, `assets/admin-react/business/dashboard/`, routes Dashboard | `DashboardController::stats()` |
| **G. Security & Compliance** (FR40-45) | `src/Security/`, `src/Front/DisclosureRenderer.php`, `src/Front/SchemaOrgRenderer.php` | `NonceVerifier::*`, `UrlAllowlistValidator::*` |
| **H. System Configuration** (FR46-52) | `src/Cache/`, `src/Admin/`, `src/Updates/`, routes Settings, `uninstall.php` | `CacheManager::*`, `UpdateManifest::generate()` |

### Integration Points

#### Internal Communication

**PHP → React au chargement** (via `wp_localize_script`) :
```js
window.AllAffiliateConfig = {
  apiRoot: '/wp-json/aff/v1',
  nonce: 'xyz...',
  currentUser: { id: 1, capabilities: [...] },
  locale: 'fr_FR',
  assetsUrl: '/wp-content/plugins/all-affiliate/build/',
  platforms: [...],       // Préchargés pour éviter round-trip initial
  designTokens: {...},
};
```

**React → PHP (REST)** : `apiFetch()` avec `window.AllAffiliateConfig.apiRoot` + `nonce`. TanStack Query gère cache et invalidations.

**PHP → PHP (hooks)** : les domaines communiquent via les hooks `all_affiliate_*`. Ex: CPT → `all_affiliate_product_saved` → Cache écoute pour invalider.

**Gutenberg Block → Template renderer** : `edit.tsx` appelle les endpoints REST pour prévisualiser. `save.tsx` retourne `null` (bloc dynamique), le `render_callback` PHP génère le HTML via `TemplateRenderer`.

#### External Integrations

**MVP** : WordPress core, thème actif (lecture seule), `updater.php` existant (lecture `update.json`).

**Post-MVP** : Amazon PA-API, Awin API, CJ API, OpenAI / Vision IA.

#### Data Flow — Création d'un produit

```
[Cyril admin UI] User remplit formulaire
    ↓ (debounce 500ms)
[React] zod validation client
    ↓ (passes)
[React] apiFetch POST /wp-json/aff/v1/products
    ↓
[PHP REST] permission_callback : nonce + capability
    ↓ (passes)
[PHP REST] ProductController::create → InputSanitizer → ProductSchema validation
    ↓ (passes)
[PHP REST] PlatformRepository::get → UrlBuilder::build → UrlAllowlistValidator::validate
    ↓ (passes)
[PHP REST] ProductRepository::create → wp_insert_post + update_post_meta
    ↓
[PHP Hooks] save_post_aff_product fired
    ↓
[PHP Cache] CacheInvalidator écoute → invalide transients
    ↓
[PHP Hooks] do_action('all_affiliate_product_saved')
    ↓
[PHP REST] Response 200 avec product JSON
    ↓
[React] onSuccess: queryClient.invalidateQueries(['products'])
    ↓
[React] UI se met à jour, toast "Produit créé" (2s fade)
```

#### Data Flow — Clic front sur un lien affilié

```
[Visiteur] Clic sur /go/tente-msr-hubba-hubba-nx
    ↓
[WP] Rewrite rule match → template_redirect hook
    ↓
[PHP Proxy] ProxyRouter::handle()
    ↓
[PHP Proxy] RateLimiter::check(ip+ua+slug) → OK ou bypass
    ↓
[PHP Proxy] ProductRepository::getBySlug() → load product
    ↓
[PHP Proxy] PlatformRepository::get() → profile
    ↓
[PHP Proxy] UrlBuilder::build() → URL finale
    ↓
[PHP Proxy] UrlAllowlistValidator::validate(URL, profile) → OK
    ↓
[PHP Proxy] ClickCounter::increment(product_id)
    ↓
[PHP Proxy] do_action('all_affiliate_click_recorded', product)
    ↓
[PHP] wp_redirect(URL, 302) + exit
    ↓
[Visiteur] Navigateur redirigé avec tag
```

### File Organization Patterns

**Configuration Files** à la racine : `composer.json`, `package.json`, `tsconfig.json`, `tailwind.config.js`, `postcss.config.js`, `phpcs.xml.dist`, `phpunit.xml.dist`, `jest.config.js`, `playwright.config.ts`, `.editorconfig`, `.gitignore`, `.gitattributes`, `update.json`, `readme.txt`, `CHANGELOG.md`.

**Source PHP** : exclusivement dans `src/` (PSR-4 autoload `AllAffiliate\\`).

**Source Frontend** : exclusivement dans `assets/` (structure par type : `admin-react/`, `gutenberg-block/`, `front/`).

**Templates PHP** : dans `templates/` (simples includes, pas de logique métier).

**Assets statiques** (SVG icons) : dans `icons/` (icônes plateformes).

**Tests** : dans `tests/` (PHP + JS + E2E centralisés).

**Build output** : dans `build/` (git-ignored, régénéré par `@wordpress/scripts`).

**Languages** : dans `languages/` (conventions WP natives).

### Development Workflow Integration

**Development server**
- `npm run start` → `@wordpress/scripts start` → watch mode avec HMR React
- Les sources sont dans `assets/`, le watch écrit dans `build/`
- Plugin activé dans l'instance WP locale de Cyril

**Build process**
- `npm run build` → production build avec minification + purge Tailwind
- Output dans `build/` avec hash de fichiers (`admin-react.xxx.js`)
- PHP n'a pas besoin de build

**Deployment (via Makefile + updater.php existant)**
- Cyril tague une version (`git tag v0.1.0`)
- Makefile + GitHub Actions existants : build + ZIP packaging + release + `update.json`
- Le plugin expose un header conforme (`Version:`, `Update URI:`)
- Le plugin lui-même ne sait rien du processus de release — il fournit juste les bons fichiers à la racine

---

## Architecture Validation Results

### Coherence Validation ✅

**Decision Compatibility**

| Check | Statut | Notes |
|---|---|---|
| React 18 + `@wordpress/scripts` + WP 6.0+ | ✅ | Stack officielle WP, versions compatibles |
| PHP 8.0+ + WP 6.0+ | ✅ | WP 6.0 supporte PHP 8.0+ |
| Tailwind préfixé + Radix UI + `@wordpress/components` (limité) | ✅ | Pas de conflits — chacun joue un rôle distinct |
| TypeScript strict + `@wordpress/scripts` webpack | ✅ | Support TS natif |
| TanStack Query + Zustand | ✅ | Complémentaires (serveur/UI), pas de recouvrement |
| React Router v6 + HashRouter + WP admin | ✅ | HashRouter évite conflits avec `admin.php?page=` |
| PSR-4 autoload + composer + WP | ✅ | Standard PHP moderne |
| CPT + postmeta + transients | ✅ | Pattern WP natif éprouvé |

**Pattern Consistency** : nommages PHP/TS/CSS/REST cohérents, format REST uniformisé, error handling centralisé.

**Structure Alignment** : 5 niveaux React alignés avec UX Spec, découplage PHP par domaine, tests co-located/centralisés selon écosystème.

**Verdict** : ✅ EXCELLENT — aucun conflit détecté entre les décisions.

### Requirements Coverage Validation ✅

**Functional Requirements (52 FRs)**

| Categorie | Nb FRs | Couverture archi | Gap |
|---|---|---|---|
| A. Platform Management | 7 | ✅ `src/Platforms/`, `PlatformController`, `business/platforms/` | Aucun |
| B. Product Management | 13 | ✅ `src/CPT/`, `ProductController`, `business/products/`, `ProductFormSplitView` | Aucun |
| C. Link & Tracking | 5 | ✅ `src/Proxy/`, `UrlBuilder`, `RateLimiter`, `ClickCounter` | Aucun |
| D. Content Authoring | 6 | ✅ `src/Gutenberg/`, `assets/gutenberg-block/` | Mineur : structure packs de page (FR30) à préciser en implémentation |
| E. Visual Design System | 6 | ✅ `src/DesignTokens/`, `ThemeDetector`, `business/design/` | Mineur : heuristique CSS thèmes classiques à définir en implémentation |
| F. Performance Monitoring | 2 | ✅ `DashboardController`, `business/dashboard/` | Aucun |
| G. Security & Compliance | 6 | ✅ `src/Security/`, `SchemaOrgRenderer`, `DisclosureRenderer` | Aucun |
| H. System Configuration | 7 | ✅ `src/Cache/`, `src/Admin/`, `src/Updates/`, `uninstall.php` | Mineur : mécanisme visite guidée (FR49) à designer |

**Non-Functional Requirements (43 NFRs)** : tous adressés — Performance (cache + code-split + purge), Security (nonces + capabilities + URL allowlist + rate-limit volatile + no-PII), Scalability (CPT WP natif + cache agressif), Accessibility (Radix + WCAG AA + axe-core), Integration (WP 6.0+ + PHP 8.0+ + FSE + prefix + multisite), Reliability (cache invalidation + fallback + tests + PHPCS/ESLint).

**Verdict** : ✅ EXCELLENT — tous FRs ont une implémentation architecturale, tous NFRs adressés.

### Implementation Readiness Validation ✅

**Decision Completeness** : toutes les décisions critiques prises avec versions, rationale documenté, alternatives évaluées.

**Structure Completeness** : ~250 fichiers identifiés, chaque FR mappé à un dossier/controller/composant, boundaries définies, integration points documentés.

**Pattern Completeness** : naming exhaustif (PHP/TS/CSS/REST/hooks), structure patterns définis, format patterns complets, communication patterns clairs, process patterns documentés, 10 règles MUST, automatisation enforcement, good/bad examples.

**Verdict** : ✅ READY FOR IMPLEMENTATION — un dev peut ouvrir ce doc et démarrer la Phase 1.

### Gap Analysis Results

**Critical Gaps : AUCUN**

**Important Gaps (à affiner en implémentation, non-bloquants)**

1. **Heuristique CSS pour détection thème classique (non-FSE)** — à définir Phase 4 (quels sélecteurs scanner, quelles couleurs extraire, fallback)
2. **Structure concrète des "packs de page" (FR30)** — à définir Phase 7 (JSON de blocs Gutenberg ? Template ? Séquence d'inserts ?)
3. **Mécanisme visite guidée (FR49)** — à définir Phase 7 (`driver.js` ? `react-joyride` ? custom ?)
4. **Upload d'icône custom pour profils plateformes (FR4)** — à définir Phase 2 (Media Library WP ? format ? tailles ?)
5. **Persistance du dark mode toggle admin** — à définir Phase 4 (user meta recommandé)
6. **Structure des stores Zustand précise** — à définir Phase 3 (liste exacte + shape)

**Nice-to-Have Gaps (V2+)** : Storybook, bundle analysis en CI, visual regression testing, monitoring prod externe.

### Validation Issues Addressed (pendant le workflow)

1. **Makefile existant gère GitHub Actions** (Cyril Step 4) → intégration au lieu de reproduction
2. **Saisie multi-format d'URL** (Cyril PRD Journey 1) → FR9/FR10 + `IdExtractor` avec regex list
3. **Thèmes peuvent utiliser Tailwind** (Cyril PRD) → prefix `aff-*` non-négociable

### Architecture Completeness Checklist

**Requirements Analysis**
- [x] Project context thoroughly analyzed
- [x] Scale and complexity assessed (medium)
- [x] Technical constraints identified (5 contraintes non-négociables)
- [x] Cross-cutting concerns mapped (8 concerns)

**Architectural Decisions**
- [x] Critical decisions documented avec versions
- [x] Technology stack fully specified
- [x] Integration patterns defined
- [x] Performance considerations addressed (NFR-P1-11)

**Implementation Patterns**
- [x] Naming conventions established (PHP, TS, CSS, REST)
- [x] Structure patterns defined
- [x] Communication patterns specified
- [x] Process patterns documented

**Project Structure**
- [x] Complete directory structure defined (~250 fichiers/dossiers)
- [x] Component boundaries established
- [x] Integration points mapped (2 data flows détaillés)
- [x] Requirements to structure mapping complete (52 FRs mappés)

### Architecture Readiness Assessment

**Overall Status : READY FOR IMPLEMENTATION** ✅
**Confidence Level : HIGH**

**Key Strengths**
1. **Cohérence verticale PRD → UX → Architecture** : traçabilité claire (un FR → un dossier → un composant)
2. **Pragmatisme** : pas de sur-ingénierie, dimensionnée pour plugin solo
3. **Alignement WP** : respecte les conventions (nonces, capabilities, hooks, CPT, REST)
4. **Isolation stricte CSS/JS** : prefix `aff-*` + scope modules = compatible avec tout thème
5. **Testabilité par design** : repositories mockables, composants purs, E2E couvrant les 6 journeys

**Areas for Future Enhancement**
- Observability (Sentry + OpenTelemetry) si V2 publique
- Multi-sites management centralisé (V2)
- Plugin extensibility API documentée (V2 publique)
- Storybook pour catalogue visuel

### Implementation Handoff

**AI Agent / Dev Guidelines**
1. **Lire ce document avant tout commit** — source de vérité pour questions d'architecture
2. **Respecter les 10 règles MUST** (Section "Enforcement Guidelines")
3. **Respecter les boundaries** : niveau React ≤ niveau, pas de cycles PHP entre domaines
4. **Utiliser les repositories** pour tout accès aux données WP
5. **Respecter le budget perf** — bundle analyser au build
6. **Tester avant de merger** — coverage cibles NFR-R4/R5/R6

**First Implementation Priority — Story 1 (Phase 1)**

```bash
# 1. Initialiser le projet
cd /var/www/html/claude_dev/wp-content/plugins/
mv all-affiliate all-affiliate.backup
npx @wordpress/create-block@latest all-affiliate --variant=dynamic --template-type=block-only

# 2. Installer les dépendances additionnelles
cd all-affiliate
npm install --save-dev [dépendances listées en Step 3]
composer init && composer require --dev phpunit/phpunit phpcompatibility/phpcompatibility-wp

# 3. Configurer tailwind.config.js avec prefix: 'aff-'
# 4. Aligner le Makefile local avec le Makefile existant de Cyril
# 5. Créer src/Plugin.php minimaliste qui charge juste le CPT
# 6. Premier test : activer le plugin dans WP local, vérifier le CPT visible en REST API
```
