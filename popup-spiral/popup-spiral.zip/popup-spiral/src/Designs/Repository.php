<?php

namespace Spiral\Designs;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Accès unifié aux designs : presets en code + « Mes designs » en option.
 */
final class Repository
{
    public const OPTION = 'spiral_saved_designs';

    public const CORNERS = ['square', 'rounded', 'pill', 'custom'];
    public const SHADOWS = ['none', 'soft', 'strong', 'custom'];
    public const CLOSE_STYLES = ['cross', 'text'];
    public const CLOSE_POSITIONS = ['inside', 'outside'];
    public const OVERLAYS = ['dim', 'blur', 'none'];
    public const FONTS = ['theme', 'modern'];
    public const BORDERS = ['none', 'thin', 'thick', 'custom'];

    /**
     * Tous les designs disponibles, presets d'abord.
     *
     * @return array<string, array{name: string, settings: array, custom_css: string, builtin: bool}>
     */
    public static function all(): array
    {
        $designs = [];

        foreach (Presets::all() as $slug => $preset) {
            $designs[$slug] = [
                'name' => $preset['name'],
                'settings' => $preset['settings'],
                'custom_css' => '',
                'builtin' => true,
            ];
        }

        foreach (self::userDesigns() as $slug => $design) {
            if (isset($designs[$slug])) {
                continue;
            }

            $designs[$slug] = [
                'name' => (string) ($design['name'] ?? $slug),
                'settings' => self::sanitizeSettings(is_array($design['settings'] ?? null) ? $design['settings'] : []),
                'custom_css' => (string) ($design['custom_css'] ?? ''),
                'builtin' => false,
            ];
        }

        return $designs;
    }

    /**
     * @return array{name: string, settings: array, custom_css: string, builtin: bool}|null
     */
    public static function get(string $slug): ?array
    {
        $all = self::all();

        return $all[$slug] ?? null;
    }

    public static function isPreset(string $slug): bool
    {
        $presets = Presets::all();

        return isset($presets[$slug]);
    }

    /**
     * Enregistre un design utilisateur. Un slug de preset ou inconnu produit
     * une copie : les designs fournis restent intacts.
     *
     * @return string Le slug effectivement enregistré.
     */
    public static function save(string $slug, string $name, array $settings, string $customCss): string
    {
        $userDesigns = self::userDesigns();

        if ($slug === '' || self::isPreset($slug) || !isset($userDesigns[$slug])) {
            $slug = self::uniqueSlug($name);
        }

        $userDesigns[$slug] = [
            'name' => sanitize_text_field($name) !== '' ? sanitize_text_field($name) : $slug,
            'settings' => self::sanitizeSettings($settings),
            'custom_css' => self::sanitizeCss($customCss),
            // CSS pré-généré à l'enregistrement — le front ne fait que le lire.
            'css' => '',
        ];
        $userDesigns[$slug]['css'] = CssGenerator::generate(
            $slug,
            $userDesigns[$slug]['settings'],
            $userDesigns[$slug]['custom_css']
        );

        update_option(self::OPTION, $userDesigns, false);

        return $slug;
    }

    public static function delete(string $slug): void
    {
        if (self::isPreset($slug)) {
            return;
        }

        $userDesigns = self::userDesigns();
        unset($userDesigns[$slug]);
        update_option(self::OPTION, $userDesigns, false);
    }

    /**
     * CSS prêt à servir pour un design (pré-généré pour les designs
     * utilisateur, généré à la volée pour les presets, stables en code).
     */
    public static function css(string $slug): string
    {
        $userDesigns = self::userDesigns();

        if (isset($userDesigns[$slug]['css']) && $userDesigns[$slug]['css'] !== '') {
            return (string) $userDesigns[$slug]['css'];
        }

        $design = self::get($slug);

        if ($design === null) {
            return '';
        }

        return CssGenerator::generate($slug, $design['settings'], $design['custom_css']);
    }

    /**
     * Complète et borne les réglages d'un design aux choix fermés autorisés.
     */
    public static function sanitizeSettings(array $raw): array
    {
        $defaults = Presets::all()['annonce']['settings'];

        return [
            'bg' => sanitize_hex_color((string) ($raw['bg'] ?? '')) ?: $defaults['bg'],
            'accent' => sanitize_hex_color((string) ($raw['accent'] ?? '')) ?: $defaults['accent'],
            // Couleurs optionnelles : vide = automatique / valeur par défaut.
            'text' => sanitize_hex_color((string) ($raw['text'] ?? '')) ?: '',
            'btn_text' => sanitize_hex_color((string) ($raw['btn_text'] ?? '')) ?: '',
            'close_color' => sanitize_hex_color((string) ($raw['close_color'] ?? '')) ?: '',
            'close_bg' => sanitize_hex_color((string) ($raw['close_bg'] ?? '')) ?: '',
            'close_hover_color' => sanitize_hex_color((string) ($raw['close_hover_color'] ?? '')) ?: '',
            'close_hover_bg' => sanitize_hex_color((string) ($raw['close_hover_bg'] ?? '')) ?: '',
            'close_underline' => (string) ($raw['close_underline'] ?? '0') === '1',
            'border' => in_array((string) ($raw['border'] ?? ''), self::BORDERS, true) ? (string) $raw['border'] : 'none',
            'border_color' => sanitize_hex_color((string) ($raw['border_color'] ?? '')) ?: '',
            // Mesures personnalisées (utilisées quand le choix correspondant = custom).
            'border_width' => max(1, min(20, (int) ($raw['border_width'] ?? 2))),
            'corners_radius' => max(0, min(60, (int) ($raw['corners_radius'] ?? 16))),
            'shadow_blur' => max(0, min(120, (int) ($raw['shadow_blur'] ?? 40))),
            'shadow_opacity' => max(0, min(100, (int) ($raw['shadow_opacity'] ?? 25))),
            'corners' => self::pick($raw, 'corners', self::CORNERS, $defaults),
            'shadow' => self::pick($raw, 'shadow', self::SHADOWS, $defaults),
            'close_style' => self::pick($raw, 'close_style', self::CLOSE_STYLES, $defaults),
            'close_position' => self::pick($raw, 'close_position', self::CLOSE_POSITIONS, $defaults),
            'overlay' => self::pick($raw, 'overlay', self::OVERLAYS, $defaults),
            'font' => self::pick($raw, 'font', self::FONTS, $defaults),
            'neutral' => !empty($raw['neutral']),
        ];
    }

    /**
     * Neutralise tout ce qui permettrait de sortir du contexte CSS.
     *
     * Le retrait de « < » est le garde anti-XSS : sans lui, un « </style><script> »
     * pourrait s'échapper de la balise <style> où ce CSS est imprimé — NE JAMAIS le retirer.
     * « @import » est bloqué pour empêcher le chargement de feuilles externes (défense en profondeur).
     */
    public static function sanitizeCss(string $css): string
    {
        $css = wp_strip_all_tags($css);
        $css = str_ireplace(['</style', '<', 'javascript:', 'expression(', '@import'], '', $css);

        return trim($css);
    }

    private static function userDesigns(): array
    {
        $designs = get_option(self::OPTION, []);

        return is_array($designs) ? $designs : [];
    }

    private static function uniqueSlug(string $name): string
    {
        $base = sanitize_key(sanitize_title($name));

        if ($base === '') {
            $base = 'design';
        }

        $slug = $base;
        $existing = self::all();
        $i = 2;

        while (isset($existing[$slug])) {
            $slug = $base . '-' . $i;
            $i++;
        }

        return $slug;
    }

    private static function pick(array $raw, string $key, array $allowed, array $defaults): string
    {
        $value = (string) ($raw[$key] ?? '');

        return in_array($value, $allowed, true) ? $value : $defaults[$key];
    }
}
