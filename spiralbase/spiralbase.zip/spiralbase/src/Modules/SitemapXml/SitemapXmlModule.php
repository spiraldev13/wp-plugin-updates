<?php

declare(strict_types=1);

namespace SpiralBase\Modules\SitemapXml;

use SpiralBase\Core\Module;
use SpiralBase\Core\SondeCession;

/**
 * Sitemap XML natif à cession indépendante (CAP-15, AD-2) — le module ne
 * réimplémente rien : le cœur WordPress (≥ 5.5) sert `/wp-sitemap.xml`
 * avec les contenus publics ; le module en est le GARANT (le filtre ne
 * peut plus être éteint par un tiers) et l'unité de cession.
 *
 * Fait de cession vérifié sur le plugin réel : quand le module `sitemap`
 * de Rank Math est actif (option `rank_math_modules`), RM désactive
 * lui-même le sitemap du cœur (`class-redirect-core-sitemaps.php` :
 * `wp_sitemaps_enabled → false`) et sert le sien — céder est alors la
 * seule issue sans doublon ni collision d'URL.
 */
final class SitemapXmlModule implements Module
{
    /**
     * @param \Closure():bool|null $faitSitemapRankMath fait injectable pour
     *                                                  les tests ; null =
     *                                                  faits réels
     */
    public function __construct(private readonly ?\Closure $faitSitemapRankMath = null)
    {
    }

    public function slug(): string
    {
        return 'sitemap_xml';
    }

    public function boot(): void
    {
        /* Priorité tardive (100) : le garant s'exprime APRÈS les tiers
           usuels (prio 10) — sans prétendre au dernier mot absolu, qu'aucune
           priorité ne garantit. La cession reste la voie normale (AD-3). */
        add_filter('wp_sitemaps_enabled', '__return_true', 100);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitSitemapRankMath ?? \Closure::fromCallable([self::class, 'rankMathSertLeSitemap']),
            static fn (): string => __('Sitemap XML réellement fourni par Rank Math.', 'spiralbase')
        );
    }

    /** Mêmes deux premiers faits que la sonde OpenGraph (2.1), plus le module RM. */
    private static function rankMathSertLeSitemap(): bool
    {
        if (!class_exists('RankMath', false) || !class_exists('\\RankMath\\Helper')) {
            return false;
        }

        if (\RankMath\Helper::is_invalid_registration()) {
            return false;
        }

        $modules = get_option('rank_math_modules', []);

        return is_array($modules) && in_array('sitemap', $modules, true);
    }
}
