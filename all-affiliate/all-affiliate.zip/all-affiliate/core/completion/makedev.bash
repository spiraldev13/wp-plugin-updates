# makedev — Completion bash/zsh pour les commandes make
#
# Installation :
#   cp .make/core/completion/makedev.bash ~/.bash_completion.d/makedev
#   # ou
#   echo 'source .make/core/completion/makedev.bash' >> ~/.bashrc
#
# Pour zsh, ajoutez dans ~/.zshrc :
#   autoload -U +X bashcompinit && bashcompinit
#   source .make/core/completion/makedev.bash

_makedev_completions() {
  local targets="init git merge feature feature-merge branch-dev self-update repo-public repo-private droits help"
  COMPREPLY=($(compgen -W "$targets" -- "${COMP_WORDS[COMP_CWORD]}"))
}

complete -F _makedev_completions make
