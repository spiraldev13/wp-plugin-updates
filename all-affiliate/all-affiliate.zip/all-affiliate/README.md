# makedev

Outil CLI basé sur GNU Make et Bash qui standardise le workflow Git, le versioning sémantique et l'initialisation de projets.

## Ce que fait makedev

- **Workflow Git standardisé** : commit, push, merge dev → main, feature branches — tout via `make`
- **Versioning sémantique interactif** : menu patch/minor/major à chaque commit, multi-format (texte, PHP return, PHP array)
- **Types de projets** : `basic`, `laravel`, `wordpress` — chaque type configure le format de version et les hooks
- **Self-update** : mise à jour atomique depuis GitHub avec rollback automatique
- **Migration** : détection et nettoyage des anciens systèmes (makefile_project)

## Comment ça marche

makedev s'installe dans un dossier `.make/` à la racine de chaque projet. Ce dossier contient tous les scripts et templates de makedev, **sans `.git`** — il n'y a donc aucun conflit avec le dépôt Git de votre projet.

```
mon-projet/
├── .make/           ← makedev (scripts, types, templates)
├── .claude/         ← config Claude Code (rules, docs, settings)
├── .git/            ← votre dépôt Git
├── .TREE.md         ← description de chaque fichier/dossier racine
├── CLAUDE.md        ← instructions projet pour Claude Code
├── Makefile         ← include .make/core/makefile
├── README.md        ← documentation du projet
├── STATUS.md        ← tableau de bord et suivi du projet
├── project.conf     ← configuration du projet (type, slug)
├── tasks/           ← tâches et notes
├── version.txt      ← fichier de version (format dépend du type)
└── votre-code/
```

`.make/` est dans le `.gitignore` — il n'est pas versionné. Chaque développeur l'installe localement. Pour le mettre à jour : `make self-update`.

## Prérequis

- **Git** (toute version récente)
- **GNU Make**
- **Bash 4+**
- **Python 3** (optionnel — requis uniquement pour le type `laravel` et les projets WordPress)
- **GitHub CLI** (optionnel — requis pour `make repo-public` / `make repo-private`) — voir [Installation GitHub CLI](#installation-github-cli-linuxwsl) si non installé

## Installation

### Installation rapide (recommandée)

Depuis le dossier de votre projet :

```bash
cd mon-projet
curl -sL https://raw.githubusercontent.com/spiraldev13/makedev/main/install.sh | bash
```

Le script fait tout automatiquement :
1. Clone makedev dans `.make/`
2. Crée le `Makefile` (ou détecte l'existant)
3. Lance `make init` (prompts interactifs)

### Installation manuelle

```bash
cd mon-projet

# 1. Cloner makedev dans .make/
git clone --depth 1 git@github.com:spiraldev13/makedev.git .make
rm -rf .make/.git .make/Makefile .make/project.conf .make/version.txt .make/.gitignore
rm -rf .make/_bmad .make/_bmad-output .make/.claude .make/docs .make/README.md

# 2. Créer le Makefile
cat > Makefile << 'EOF'
SHELL := /bin/bash
.DEFAULT_GOAL := help
.PHONY: help init git merge feature feature-merge self-update

include .make/core/makefile
EOF

# 3. Initialiser le projet
make init
```

## make init — Initialisation

`make init` configure votre projet avec des prompts interactifs :

### 1. Type de projet

```
Types de projet disponibles :
  1) basic            — Versioning semver simple dans un fichier texte
  2) laravel          — Versioning PHP array dans config/version.php (number, date)
  3) wordpress-plugin — Plugin WordPress avec release automatique
  4) wordpress-theme  — Theme WordPress avec release automatique

Choix [1] :
```

Tapez le numéro correspondant. Par défaut : `1` (basic).

Chaque type définit le format du fichier de version et les hooks spécifiques (ex: release automatique pour WordPress).

### 2. Slug du projet

```
Slug du projet (identifiant unique, ex: mon-plugin) ? [nom-du-dossier] :
```

Le slug est l'identifiant de votre projet. Il est utilisé dans `project.conf`, le fichier de version et les configurations. Par défaut, c'est le nom du dossier courant.

### 3. Config Claude Code

```
Installer la config Claude Code ? (o/n) [o] :
```

Installe la configuration Claude Code partagée (repo `spiraldev13/claude-config`) dans `.claude/`. Optionnel.

### Ce que make init génère

- **`project.conf`** — configuration du projet (type, slug, repos)
- **Fichier de version** — `version.txt`, `version.php` ou `config/version.php` selon le type
- **`README.md`** — README vierge du projet (si absent)
- **`.TREE.md`** — description de chaque fichier/dossier à la racine (adapté au type de projet)
- **`STATUS.md`** — tableau de bord et suivi du projet
- **`.gitignore`** — ajoute `.make/` si absent
- **Branches Git** — crée `main` et `dev` si elles n'existent pas
- **Backup Makefile** — si un Makefile existe déjà, il est sauvegardé en `Makefile.bak.TIMESTAMP`

Pour le type **wordpress**, `make init` configure aussi automatiquement : `plugin-config.json`, `updater.php`, workflow GitHub Actions, et clone le repo `wp-plugin-updates`.

## Commandes

| Commande | Description |
|---|---|
| `make help` | Afficher l'aide |
| `make init` | Initialiser un nouveau projet |
| `make git` | Commit + push (sur dev ou feature/*) |
| `make merge` | Merge dev → main |
| `make feature` | Créer une branche feature |
| `make feature-merge` | Merger la feature dans dev |
| `make self-update` | Mettre à jour makedev et la config Claude |
| `make droits` | Appliquer les permissions WordPress (WordPress uniquement) |
| `make repo-public` | Passer le repo updates en public (WordPress uniquement) |
| `make repo-private` | Passer le repo updates en privé (WordPress uniquement) |

### Workflow quotidien

```bash
# Développer sur dev
git checkout dev

# Travailler, puis commiter
make git
# → Menu versioning : patch / minor / major / custom / skip
# → git add -A → commit → push

# Quand c'est prêt pour la production
make merge
# → Commit dev → push dev → checkout main → merge --no-ff → push main → retour sur dev
```

### Feature branches

```bash
# Créer une feature
make feature
# → Prompt : nom de la feature
# → Crée feature/<nom> depuis dev

# Travailler sur la feature, commiter
make git

# Merger dans dev quand c'est fini
make feature-merge
# → Auto-commit si fichiers non commités → merge --no-ff dans dev
```

## Types de projets

### basic (défaut)

- Version dans `version.txt` (format semver : `1.0.0`)
- Aucun hook supplémentaire

### laravel

- Version dans `config/version.php` (format php-array : `['number' => '1.0.0', 'date' => '2026-01-01']`)
- Requiert Python 3 pour le parsing

### wordpress-plugin

- Pour les **plugins** WordPress
- Version dans `version.php` (format php-return : `return '1.0.0';`)
- `make init` configure tout automatiquement : plugin-config.json, updater.php, GitHub Actions, repo updates
- Hook post-merge : sync version → header plugin, tag, ZIP, update.json, push vers wp-plugin-updates
- Visibilité repo : `make repo-public` / `make repo-private`
- Permissions : `make droits` (détecte auto l'utilisateur et le groupe web)

### wordpress-theme

- Pour les **thèmes** WordPress
- Version dans `style.css` (header CSS : `Version: 1.0.0`)
- Même système de release que wordpress-plugin (ZIP, update.json, tags, push vers wp-plugin-updates)
- Updater adapté aux thèmes (`pre_set_site_transient_update_themes`)
- Permissions : `make droits` (détecte auto l'utilisateur et le groupe web)

## Self-update

```bash
make self-update
```

Met à jour makedev (`.make/`) et la config Claude (`.claude/`, `CLAUDE.md`, `tasks/`) sans toucher à votre code. La mise à jour de `.claude/` ne se fait que si le dossier existe déjà dans le projet.

Le dossier `.make/` est une copie locale de makedev **sans `.git`** — il n'y a donc pas de conflit possible avec le dépôt Git de votre projet. La mise à jour est une copie atomique :

1. Clone le repo `spiraldev13/makedev` dans un dossier temporaire
2. Supprime le `.git` du clone (seuls les fichiers sont conservés)
3. Sauvegarde le `.make/` actuel en backup
4. Remplace `.make/` par la nouvelle version
5. Supprime le backup si tout s'est bien passé
6. En cas d'erreur : rollback automatique vers la version précédente

**Ce qui est mis à jour** : tous les scripts makedev (core, types, templates).

**Ce qui n'est jamais touché** : `project.conf`, `Makefile`, `version.php`, `plugin-config.json`, votre code, votre dépôt Git — ces fichiers sont à la racine de votre projet, en dehors de `.make/`.

## Visibilité du repo updates (WordPress)

Pour les projets WordPress, les mises à jour sont distribuées via le repo `wp-plugin-updates` sur GitHub. Ce repo doit être public pour que les sites WordPress puissent télécharger les mises à jour.

Pour limiter l'exposition, vous pouvez basculer la visibilité à la demande :

```bash
# Après un make merge, ouvrir l'accès
make repo-public

# Mettre à jour les sites WordPress, puis refermer
make repo-private
```

**Prérequis** : [GitHub CLI](https://cli.github.com/) installé et authentifié (`gh auth login`). Si `gh` n'est pas installé, suivez les instructions d'[Installation GitHub CLI](#installation-github-cli-linuxwsl) plus bas.

Quand le repo est privé, les plugins déjà installés continuent de fonctionner — seules les nouvelles mises à jour sont bloquées.

Voir [docs/visibility-impact.md](docs/visibility-impact.md) pour les détails techniques.

## Installation GitHub CLI (Linux/WSL)

Si `gh` n'est pas installé sur votre système, voici comment l'installer :

### Installation en 1 commande

```bash
(type -p wget >/dev/null || (sudo apt update && sudo apt install wget -y)) \
    && sudo mkdir -p -m 755 /etc/apt/keyrings \
    && out=$(mktemp) && wget -nv -O$out https://cli.github.com/packages/githubcli-archive-keyring.gpg \
    && cat $out | sudo tee /etc/apt/keyrings/githubcli-archive-keyring.gpg > /dev/null \
    && sudo chmod go+r /etc/apt/keyrings/githubcli-archive-keyring.gpg \
    && sudo mkdir -p -m 755 /etc/apt/sources.list.d \
    && echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null \
    && sudo apt update \
    && sudo apt install gh -y
```
### Vérification

```bash
gh --version
gh auth status
```

### Authentification

```bash
gh auth login
```

Cela ouvre votre navigateur pour connecter votre compte GitHub.

### Mise à jour future

```bash
sudo apt update
sudo apt upgrade gh
```

# TUTO GH Auth Login - WSL (SSH + Token)

## 🎯 Contexte
Installation et authentification **GitHub CLI (`gh`)** sur **WSL** avec **SSH** pour automatiser les changements de visibilité repo (public/privé).

## 📋 Prérequis (1 seule fois)

```bash
# Fix navigateur WSL + dépendances
sudo apt update && sudo apt install -y wslu wget gnupg
```

## 🔐 Étape 1 : Token GitHub (Classic)

1. https://github.com/settings/tokens
2. **"Generate new token (classic)"**
3. **Scopes à cocher** :
   ```
   ☑ repo                 # Contrôle repos
   ☑ read:org             # Lecture orgs  
   ☑ admin:public_key     # Ajout clé SSH
   ☑ gist                 # GitHub CLI
   ```
4. **Copie le token** : `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

## 🚀 Étape 2 : Login GH CLI

```bash
gh auth login
```

**Réponses EXACTES** :
```
? Where do you use GitHub? → GitHub.com
? Git protocol → SSH
? Upload SSH public key? → /home/dev/.ssh/wsl_shanks.pub (Entrée)
? Title SSH key → GitHub CLI (Entrée) 
? Auth method → Paste an authentication token
? Paste token → ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**Résultat attendu** :
```
✓ Configured git protocol
! Authentication credentials saved in plain text  ← Normal WSL
✓ SSH key already existed: /home/dev/.ssh/wsl_shanks.pub
✓ Logged in as spiraldev13
```

## ✅ Étape 3 : Test

```bash
gh auth status    # ✓ Logged in to github.com as spiraldev13
gh repo list      # Liste tes repos
gh repo view      # Infos repo courant
```


## 🎯 Usage

```bash
# Public (release)
make repo-public REPO=spiraldev13/amazon-affiliate-hub

# Privé (dev)
make repo-private REPO=spiraldev13/amazon-affiliate-hub

```

## 🔄 Logout (optionnel)

```bash
gh auth logout
```

## ⚠️ Notes importantes

- **"plain text"** = normal WSL, safe laptop perso
- **Token persiste** → plus jamais de login
- **WSL dbus errors** = ignorables (GUI manquant)
- **Clé SSH réutilisée** = parfait, pas de doublon

🎉


## Auto-complétion

### Bash

```bash
# Copier le script
cp .make/core/completion/makedev.bash ~/.bash_completion.d/makedev

# Ou ajouter au .bashrc
echo 'source .make/core/completion/makedev.bash' >> ~/.bashrc
```

### Zsh

```bash
# Ajouter au .zshrc
cat >> ~/.zshrc << 'EOF'
autoload -U +X bashcompinit && bashcompinit
source .make/core/completion/makedev.bash
EOF
```

## Structure du repo

```
makedev/
├── install.sh                   # Script d'installation one-liner
├── core/
│   ├── makefile                 # Cibles Make (dispatch vers les scripts)
│   ├── completion/
│   │   └── makedev.bash         # Auto-complétion bash/zsh
│   └── scripts/
│       ├── utils.sh             # Fonctions utilitaires partagées
│       ├── load-config.sh       # Chargement project.conf + type.conf
│       ├── init.sh              # Initialisation interactive
│       ├── git.sh               # Commit, merge, feature branches
│       ├── self-update.sh       # Mise à jour atomique
│       ├── repo-visibility.sh   # Visibilité repo GitHub (public/privé)
│       └── help.sh              # Affichage de l'aide
└── types/
    ├── basic/                   # Type par défaut (semver texte)
    ├── laravel/                 # PHP array versioning
    ├── wordpress-plugin/        # Plugin WordPress + release automatique
    │   ├── scripts/
    │   │   ├── init-wordpress.sh # Setup auto (plugin-config, updater, workflow)
    │   │   ├── release.sh        # Hook post-merge (ZIP, update.json, tag)
    │   │   └── setup-release.sh  # Déprécié → appelle init-wordpress.sh
    │   └── templates/           # Templates GitHub Actions, updater PHP
    └── wordpress-theme/         # Thème WordPress + release automatique
        └── scripts/
            └── init-wordpress-theme.sh # Setup auto thème
```

## Configuration

Le fichier `project.conf` (généré par `make init`) contient la configuration de votre projet :

```bash
# project.conf — genere par makedev init
PROJECT_TYPE=basic
PROJECT_SLUG=mon-projet
MAKEDEV_REPO=git@github.com:spiraldev13/makedev.git
CLAUDE_REPO=git@github.com:spiraldev13/claude-config.git
UPDATES_REPO=wp-plugin-updates    # WordPress uniquement
```

### Variables

| Variable | Description | Valeurs / Défaut |
|---|---|---|
| `PROJECT_TYPE` | Type de projet | `basic`, `laravel`, `wordpress-plugin`, `wordpress-theme` |
| `PROJECT_SLUG` | Identifiant unique du projet (utilisé dans les configs et le versioning) | Nom du dossier par défaut |
| `MAKEDEV_REPO` | URL du repo makedev pour `make self-update` | `git@github.com:spiraldev13/makedev.git` |
| `CLAUDE_REPO` | URL du repo claude-config pour `make init` et `make self-update` | `git@github.com:spiraldev13/claude-config.git` |
| `UPDATES_REPO` | Nom du repo GitHub pour distribuer les mises à jour WordPress (`make repo-public` / `make repo-private`) | `wp-plugin-updates` — ajouté uniquement pour les types `wordpress-plugin` et `wordpress-theme` |

## Licence

MIT
