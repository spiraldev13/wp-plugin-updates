<?php
/**
 * Grille d'articles — boucle des articles courants de la query principale.
 *
 * Réutilisée par `home.php`, `category.php` et `index.php` (fallback).
 * Délègue le rendu d'un article au partial `template-parts/cards/ligne-article`,
 * en passant l'index de position dans la grille.
 *
 * Pagination native WP via `the_posts_pagination()`.
 * Si aucun article, affiche un message vide.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (have_posts()) : ?>
    <div class="blog-list">
        <?php
        $index = 1;
        while (have_posts()) :
            the_post();
            get_template_part('template-parts/cards/ligne-article', null, ['index' => $index]);
            $index++;
        endwhile;
        ?>
    </div>

    <?php the_posts_pagination([
        'mid_size'  => 2,
        'prev_text' => __('Précédent', 'evolutionr'),
        'next_text' => __('Suivant', 'evolutionr'),
    ]); ?>
<?php else : ?>
    <p class="section-lede"><?php esc_html_e('Aucun article publié dans cette catégorie pour le moment.', 'evolutionr'); ?></p>
<?php endif; ?>
