<?php
/**
 * Template — Page « À propos » (slug `a-propos`).
 *
 * Structure Valeurs/Approche (cf. change `add-about-page`, design D2) :
 *   1. Hero prestation (eyebrow + h1 + sub + mini-stats)
 *   2. Notre approche (lede + bullets)
 *   3. Nos engagements (grille de cards icônées)
 *   4. Notre méthode (étapes numérotées, markup `.methode-steps`)
 *   5. Nos valeurs (grille de cards icônées, même pattern qu'engagements)
 *   6. CTA final
 *
 * Pleinement éditable depuis le métabox ACF « Détails À propos » lié au
 * slug `a-propos` (groupe `group_evor_page_about` dans `inc/acf-fields.php`).
 * Contenu seedé par `evolutionr_seed_about_page()` (`inc/seed-content.php`).
 *
 * Réutilise strictement les composants visuels existants : `.page-hero`,
 * `.page-hero-grid`, `.page-hero-stats`, `.section`, `.eyebrow`,
 * `.section-head`, `.service-card`, `.methode-steps`, `.btn`. Aucun
 * nouveau pattern SCSS introduit.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal" id="content">

    <section class="page-hero page-hero--prestation" aria-labelledby="page-hero-title">
        <div class="container">

            <?php evolutionr_breadcrumb(); ?>

            <?php
            $heroEyebrow = (string) get_field('hero_eyebrow') ?: __('À propos', 'evolutionr');
            $heroTitle   = (string) get_field('hero_title') ?: get_the_title();
            $heroSub     = (string) get_field('hero_sub');
            ?>
            <div class="page-hero-grid">
                <div>
                    <div class="section-eyebrow-wrap" style="margin-bottom: 20px;">
                        <span class="eyebrow"><?php echo esc_html($heroEyebrow); ?></span>
                    </div>

                    <h1 class="page-hero-title" id="page-hero-title"><?php echo esc_html($heroTitle); ?></h1>

                    <?php if ($heroSub): ?>
                        <p class="page-hero-sub"><?php echo esc_html($heroSub); ?></p>
                    <?php endif; ?>
                </div>

                <div class="page-hero-aside">
                    <?php get_template_part('template-parts/cards/hero-visuel', null, [
                        'label'  => 'studio.timeline',
                        'visual' => 'apropos',
                    ]); ?>

                    <?php if (have_rows('hero_stats')): ?>
                        <div class="page-hero-stats">
                            <?php while (have_rows('hero_stats')): the_row();
                                $sLabel = (string) get_sub_field('label');
                                $sValue = (string) get_sub_field('value');
                                if (!$sValue) continue;
                                ?>
                                <div class="mini-stat">
                                    <?php if ($sLabel): ?><div class="label"><?php echo esc_html($sLabel); ?></div><?php endif; ?>
                                    <div class="value"><?php echo esc_html($sValue); ?></div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div><?php /* .page-hero-aside */ ?>
            </div>
        </div>
    </section>

    <?php
    /* ─── 1. Notre approche ─── */
    $appEyebrow = (string) get_field('app_eyebrow');
    $appTitle   = (string) get_field('app_title');
    $appLede    = (string) get_field('app_lede');
    if ($appTitle || $appLede || have_rows('app_bullets')):
    ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="about-approche-title">
            <div class="container">
                <header class="section-head">
                    <div class="section-head-left">
                        <?php if ($appEyebrow): ?>
                            <div class="section-eyebrow-wrap">
                                <span class="eyebrow"><?php echo esc_html($appEyebrow); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($appTitle): ?>
                            <h2 class="section-title" id="about-approche-title"><?php echo esc_html($appTitle); ?></h2>
                        <?php endif; ?>
                    </div>
                    <?php if ($appLede): ?>
                        <p class="section-lede"><?php echo esc_html($appLede); ?></p>
                    <?php endif; ?>
                </header>

                <?php if (have_rows('app_bullets')): ?>
                    <ul class="service-list">
                        <?php while (have_rows('app_bullets')): the_row();
                            $bText = (string) get_sub_field('text');
                            if (!$bText) continue;
                            ?>
                            <li>
                                <?php evolutionr_icon('check', 14); ?>
                                <span><?php echo esc_html($bText); ?></span>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    /* ─── 2. Nos engagements ─── */
    $engEyebrow = (string) get_field('eng_eyebrow');
    $engTitle   = (string) get_field('eng_title');
    $engLede    = (string) get_field('eng_lede');
    if ($engTitle || have_rows('engagements')):
    ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="about-engagements-title">
            <div class="container">
                <header class="section-head">
                    <div class="section-head-left">
                        <?php if ($engEyebrow): ?>
                            <div class="section-eyebrow-wrap">
                                <span class="eyebrow"><?php echo esc_html($engEyebrow); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($engTitle): ?>
                            <h2 class="section-title" id="about-engagements-title"><?php echo esc_html($engTitle); ?></h2>
                        <?php endif; ?>
                    </div>
                    <?php if ($engLede): ?>
                        <p class="section-lede"><?php echo esc_html($engLede); ?></p>
                    <?php endif; ?>
                </header>

                <?php if (have_rows('engagements')): ?>
                    <div class="benefices-grid">
                        <?php while (have_rows('engagements')): the_row();
                            $icon  = (string) get_sub_field('icon') ?: 'compass';
                            $title = (string) get_sub_field('title');
                            $desc  = (string) get_sub_field('desc');
                            if (!$title) continue;
                            ?>
                            <article class="benefice-card">
                                <span class="benefice-icon"><?php evolutionr_icon($icon, 22); ?></span>
                                <h3 class="benefice-title"><?php echo esc_html($title); ?></h3>
                                <?php if ($desc): ?>
                                    <p class="benefice-desc"><?php echo esc_html($desc); ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    /* ─── 3. Notre méthode ─── (markup .methode-steps des pages prestation, rendu inline car le partial presta-methode check meth_enabled propre aux pages prestation) */
    $methEyebrow = (string) get_field('meth_eyebrow');
    $methTitle   = (string) get_field('meth_title');
    $methLede    = (string) get_field('meth_lede');
    if ($methTitle || have_rows('meth_steps')):
    ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="about-methode-title">
            <div class="container">
                <header class="section-head">
                    <div class="section-head-left">
                        <?php if ($methEyebrow): ?>
                            <div class="section-eyebrow-wrap">
                                <span class="eyebrow"><?php echo esc_html($methEyebrow); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($methTitle): ?>
                            <h2 class="section-title" id="about-methode-title"><?php echo esc_html($methTitle); ?></h2>
                        <?php endif; ?>
                    </div>
                    <?php if ($methLede): ?>
                        <p class="section-lede"><?php echo esc_html($methLede); ?></p>
                    <?php endif; ?>
                </header>

                <?php if (have_rows('meth_steps')): ?>
                    <ol class="methode-steps">
                        <?php $mi = 0; while (have_rows('meth_steps')): the_row();
                            $mNum    = (string) get_sub_field('num');
                            $mTitle  = (string) get_sub_field('title');
                            $mDesc   = (string) get_sub_field('desc');
                            $mTiming = (string) get_sub_field('timing');
                            if (!$mTitle) continue;
                            $mShow = $mNum ?: sprintf('%02d', $mi + 1);
                            ?>
                            <li class="methode-step">
                                <span class="methode-step-num"><?php echo esc_html($mShow); ?></span>
                                <div class="methode-step-body">
                                    <h3 class="methode-step-title"><?php echo esc_html($mTitle); ?></h3>
                                    <?php if ($mTiming): ?>
                                        <div class="section-eyebrow-wrap" style="margin: 0 0 6px;">
                                            <span class="eyebrow no-rule"><?php echo esc_html($mTiming); ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($mDesc): ?><p><?php echo esc_html($mDesc); ?></p><?php endif; ?>
                                </div>
                            </li>
                            <?php $mi++;
                        endwhile; ?>
                    </ol>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    /* ─── 4. Nos valeurs ─── (même grille que les engagements) */
    $valEyebrow = (string) get_field('val_eyebrow');
    $valTitle   = (string) get_field('val_title');
    if ($valTitle || have_rows('values')):
    ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="about-valeurs-title">
            <div class="container">
                <header class="section-head">
                    <div class="section-head-left">
                        <?php if ($valEyebrow): ?>
                            <div class="section-eyebrow-wrap">
                                <span class="eyebrow"><?php echo esc_html($valEyebrow); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($valTitle): ?>
                            <h2 class="section-title" id="about-valeurs-title"><?php echo esc_html($valTitle); ?></h2>
                        <?php endif; ?>
                    </div>
                </header>

                <?php if (have_rows('values')): ?>
                    <div class="benefices-grid">
                        <?php while (have_rows('values')): the_row();
                            $icon  = (string) get_sub_field('icon') ?: 'shield';
                            $title = (string) get_sub_field('title');
                            $desc  = (string) get_sub_field('desc');
                            if (!$title) continue;
                            ?>
                            <article class="benefice-card">
                                <span class="benefice-icon"><?php evolutionr_icon($icon, 22); ?></span>
                                <h3 class="benefice-title"><?php echo esc_html($title); ?></h3>
                                <?php if ($desc): ?>
                                    <p class="benefice-desc"><?php echo esc_html($desc); ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    /* ─── 5. CTA final ─── */
    $ctaTitle  = (string) get_field('cta_title');
    $ctaPara   = (string) get_field('cta_paragraph');
    $ctaLabel  = (string) get_field('cta_primary_label');
    $ctaUrl    = (string) get_field('cta_primary_url') ?: '/contact/';
    if ($ctaTitle):
    ?>
        <section class="final-cta" aria-labelledby="about-cta-title">
            <div class="container">
                <div class="final-cta-inner">
                    <h2 id="about-cta-title"><?php echo esc_html($ctaTitle); ?></h2>
                    <?php if ($ctaPara): ?>
                        <p><?php echo esc_html($ctaPara); ?></p>
                    <?php endif; ?>
                    <?php if ($ctaLabel): ?>
                        <div class="actions">
                            <a class="btn btn-primary" href="<?php echo esc_url($ctaUrl); ?>">
                                <?php echo esc_html($ctaLabel); ?>
                                <?php evolutionr_icon('arrow-right', 16); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php get_footer(); ?>
