<?php

declare(strict_types=1);

namespace SpiralBase\Modules\Breadcrumbs;

use SpiralBase\Core\Module;
use SpiralBase\Core\SondeCession;
use SpiralBase\Core\Walker;

/**
 * Fil d'Ariane natif à cession indépendante (CAP-15, AD-2), balisé
 * schema.org BreadcrumbList en microdonnées — inséré au début du contenu
 * par le walker (AD-10 : jamais de `add_filter('the_content')` ici ; le
 * walker borne l'affichage à la boucle principale singulière et attrape
 * tout Throwable du rendu — fail-safe hérité de la 1.4).
 *
 * Fait de cession vérifié sur le plugin réel : Rank Math ne rend ses
 * breadcrumbs que si `is_breadcrumbs_enabled()` — theme-support
 * `rank-math-breadcrumbs` (que spiralbase ne déclare pas) OU réglage
 * `general.breadcrumbs`. Indépendant du sitemap RM (AD-2).
 */
final class BreadcrumbsModule implements Module
{
    /**
     * @param \Closure():bool|null $faitBreadcrumbsRankMath fait injectable
     *                                                      pour les tests ;
     *                                                      null = faits réels
     */
    public function __construct(
        private readonly Walker $walker,
        private readonly ?\Closure $faitBreadcrumbsRankMath = null,
    ) {
    }

    public function slug(): string
    {
        return 'breadcrumbs';
    }

    public function boot(): void
    {
        $this->walker->addInsertion(
            'breadcrumbs',
            Walker::POINT_DEBUT,
            fn (array $contexte): string => $this->rendre()
        );
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitBreadcrumbsRankMath ?? \Closure::fromCallable([self::class, 'rankMathFournitLesBreadcrumbs']),
            static fn (): string => __('Fil d\'Ariane réellement fourni par Rank Math.', 'spiralbase')
        );
    }

    /**
     * Déclencheur de cession = la LETTRE de l'AC 2 (« tant que les
     * breadcrumbs Rank Math ne sont pas activés ») : activer ce réglage est
     * un acte volontaire d'opérateur, qui déploie alors le rendu RM (bloc,
     * shortcode) — la raison reste visible au tableau de bord si ce n'est
     * pas le cas.
     */
    private static function rankMathFournitLesBreadcrumbs(): bool
    {
        if (!class_exists('RankMath', false) || !class_exists('\\RankMath\\Helper')) {
            return false;
        }

        if (\RankMath\Helper::is_invalid_registration()) {
            return false;
        }

        return (bool) \RankMath\Helper::is_breadcrumbs_enabled();
    }

    /**
     * Fragment BreadcrumbList — chaîne : Accueil → ancêtres (pages) ou
     * première catégorie (articles) → élément courant sans lien. Vide si
     * l'objet courant est inidentifiable ou sans titre, et sur la page
     * d'accueil (fil auto-référent — RM l'exclut aussi) : aucune balise
     * plutôt qu'un fil mensonger.
     *
     * Public pour le walker et les tests UNIQUEMENT — pas un service :
     * aucun autre module ni template ne doit l'appeler (AD-4, AD-10).
     */
    public function rendre(): string
    {
        $post = get_queried_object();

        if (!is_object($post) || !isset($post->ID) || is_front_page()) {
            return '';
        }

        $elements = $this->chaine($post);

        /* Accueil seul (courant sans titre, ancêtres filtrés…) : pas de fil. */
        if (count($elements) < 2) {
            return '';
        }

        $items = '';

        foreach ($elements as $i => $element) {
            $nom = '<span itemprop="name">' . esc_html($element['titre']) . '</span>';

            $items .= '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">'
                . ($element['url'] === null ? $nom : '<a itemprop="item" href="' . esc_url($element['url']) . '">' . $nom . '</a>')
                . '<meta itemprop="position" content="' . ($i + 1) . '">'
                . '</li>';
        }

        return '<nav class="spiralbase-breadcrumbs" aria-label="' . esc_attr__('Fil d\'Ariane', 'spiralbase') . '">'
            . '<ol itemscope itemtype="https://schema.org/BreadcrumbList">' . $items . '</ol>'
            . '</nav>';
    }

    /** @return list<array{titre: string, url: ?string}> */
    private function chaine(object $post): array
    {
        $titreCourant = (string) get_the_title($post);

        /* Courant sans titre : un fil qui se termine sur un nom vide est un
           balisage mensonger — aucun fil. */
        if (trim($titreCourant) === '') {
            return [];
        }

        $elements = [['titre' => __('Accueil', 'spiralbase'), 'url' => home_url('/')]];

        /* get_post_ancestors rend la lignée du plus proche au plus lointain :
           inversée pour lire racine → feuille. Les ancêtres non publiés sont
           tus — leur titre (« Privé : … ») et leur lien mort divulgueraient
           une structure que le visiteur ne peut pas voir. */
        foreach (array_reverse((array) get_post_ancestors($post)) as $ancetre) {
            $objet = get_post($ancetre);

            if (!is_object($objet) || (($objet->post_status ?? '') !== 'publish')) {
                continue;
            }

            $titre = (string) get_the_title($ancetre);
            $lien  = get_permalink($ancetre);

            if ($titre !== '' && is_string($lien) && $lien !== '') {
                $elements[] = ['titre' => $titre, 'url' => $lien];
            }
        }

        if (($post->post_type ?? '') === 'post') {
            $categorie = ((array) get_the_category((int) $post->ID))[0] ?? null;
            $lien      = is_object($categorie) ? get_category_link($categorie) : null;

            /* La catégorie par défaut (« Non classé ») n'est pas une
               hiérarchie choisie : elle n'entre pas dans le fil. */
            $parDefaut = (int) get_option('default_category', 0);

            if (is_object($categorie) && is_string($lien) && $lien !== '' && (int) ($categorie->term_id ?? 0) !== $parDefaut) {
                $elements[] = ['titre' => (string) $categorie->name, 'url' => $lien];
            }
        }

        $elements[] = ['titre' => $titreCourant, 'url' => null];

        return $elements;
    }
}
