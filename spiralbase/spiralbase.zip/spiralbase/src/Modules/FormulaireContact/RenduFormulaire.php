<?php

declare(strict_types=1);

namespace SpiralBase\Modules\FormulaireContact;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;

/**
 * Rendu du formulaire natif (story 3.8).
 *
 * Aucune couche anti-spam n'est visible : le champ leurre est masqué et retiré
 * du parcours (clavier comme lecteur d'écran), le jeton et le nonce sont des
 * champs cachés. Un visiteur ne voit que trois champs et un bouton.
 */
final class RenduFormulaire
{
    public function __construct(
        private readonly AntiSpam $antiSpam,
        private readonly ?Turnstile $turnstile = null,
    ) {
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs, string $contenu = '', mixed $bloc = null): string
    {
        try {
            return $this->composer();
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_formulaire_echec', 'rendu interrompu : ' . $e->getMessage(), 'formulaire');

            return '';
        }
    }

    private function composer(): string
    {
        /*
         * Le formulaire porte un nonce et un jeton DATÉS : servi depuis un
         * cache pleine page, il continue d'afficher un nonce périmé, et
         * chaque soumission part alors en rejet silencieux — le visiteur est
         * remercié, sa demande jetée, l'opérateur ne voit rien. La flotte est
         * conçue pour tourner derrière un cache (`Core\FlyingPress`, modules
         * `perf_*`) : la page qui porte ce bloc s'exclut donc du cache, par
         * la constante que tous les plugins du domaine respectent.
         */
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }

        $accuse = '';

        /* Accusé de réception : le MÊME quel que soit le sort réel de la
           soumission (AC 2). C'est aussi ce qui rend la page compatible avec
           un cache pleine page — le paramètre d'URL suffit à le déclencher. */
        if (($_GET['spiralbase_message'] ?? '') === 'envoye') {
            $accuse = '<p class="spiralbase-formulaire__accuse" role="status">'
                . esc_html__('Merci, votre message a bien été transmis.', 'spiralbase')
                . '</p>';
        }

        return '<div ' . EnveloppeBloc::attributs('spiralbase-formulaire') . '>'
            . $accuse
            . '<form class="spiralbase-formulaire__form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'
            . '<input type="hidden" name="action" value="' . esc_attr(FormulaireContactModule::ACTION) . '"/>'
            . '<input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce(FormulaireContactModule::ACTION)) . '"/>'
            /* `_wp_http_referer` : `wp_get_referer()` retombe sinon sur
               l'en-tête `Referer`, absent chez tout visiteur qui le supprime
               (extension de vie privée, proxy, `Referrer-Policy` posée par un
               plugin de sécurité) — il était alors renvoyé sur l'accueil, où
               aucun bloc ne rend l'accusé : aucun retour du tout. */
            . '<input type="hidden" name="_wp_http_referer" value="'
            . esc_attr(esc_url_raw((string) ($_SERVER['REQUEST_URI'] ?? '/'))) . '"/>'
            . '<input type="hidden" name="' . esc_attr(AntiSpam::CHAMP_JETON) . '" value="' . esc_attr($this->antiSpam->jeton()) . '"/>'
            . $this->leurre()
            . $this->champ('spiralbase_nom', __('Votre nom', 'spiralbase'), 'text')
            . $this->champ('spiralbase_email', __('Votre adresse e-mail', 'spiralbase'), 'email')
            . $this->zoneDeTexte('spiralbase_message', __('Votre message', 'spiralbase'))
            . ($this->turnstile?->rendreWidget() ?? '')
            . '<button type="submit" class="spiralbase-formulaire__envoi">'
            . esc_html__('Envoyer', 'spiralbase')
            . '</button>'
            . '</form></div>';
    }

    /**
     * Champ leurre — invisible pour un humain, ET pour les technologies
     * d'assistance.
     *
     * Le masquer en CSS ne suffit pas : un lecteur d'écran l'annoncerait, un
     * gestionnaire de mots de passe le remplirait, et le visiteur le plus
     * fragile serait le seul à être rejeté. D'où `aria-hidden`,
     * `tabindex="-1"` et `autocomplete="off"` en plus de la mise à l'écart
     * visuelle.
     */
    private function leurre(): string
    {
        /* Le style EN LIGNE double la feuille : si elle n'est pas servie
           (thème enfant, chargement différé par un module `perf_*`, bloc rendu
           hors de sa carte), le champ apparaissait au milieu du formulaire — et
           le visiteur qui le remplissait était rejeté sans le savoir. */
        return '<div class="spiralbase-formulaire__leurre" aria-hidden="true"'
            . ' style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden">'
            . '<label for="' . esc_attr(AntiSpam::CHAMP_LEURRE) . '">'
            . esc_html__('Ne remplissez pas ce champ', 'spiralbase')
            . '</label>'
            . '<input type="text" id="' . esc_attr(AntiSpam::CHAMP_LEURRE) . '"'
            . ' name="' . esc_attr(AntiSpam::CHAMP_LEURRE) . '"'
            . ' tabindex="-1" autocomplete="off" value=""/>'
            . '</div>';
    }

    private function champ(string $nom, string $libelle, string $type): string
    {
        return '<p class="spiralbase-formulaire__champ">'
            . '<label for="' . esc_attr($nom) . '">' . esc_html($libelle) . '</label>'
            . '<input type="' . esc_attr($type) . '" id="' . esc_attr($nom) . '" name="' . esc_attr($nom) . '"'
            . ' autocomplete="' . ($type === 'email' ? 'email' : 'name') . '" required/>'
            . '</p>';
    }

    private function zoneDeTexte(string $nom, string $libelle): string
    {
        return '<p class="spiralbase-formulaire__champ">'
            . '<label for="' . esc_attr($nom) . '">' . esc_html($libelle) . '</label>'
            . '<textarea id="' . esc_attr($nom) . '" name="' . esc_attr($nom) . '" rows="6" required></textarea>'
            . '</p>';
    }
}
