#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Fonctions utilitaires partagees
# Ce fichier est source par tous les scripts makedev.
# Ne contient PAS de logique metier (versioning, init, merge, feature).
# =============================================================================

# === Detection TTY et couleurs ===

if [ -t 1 ]; then
  C_RESET='\033[0m'
  C_BOLD='\033[1m'
  C_RED='\033[31m'
  C_GREEN='\033[32m'
  C_YELLOW='\033[33m'
  C_CYAN='\033[36m'
  C_BLUE='\033[34m'
else
  C_RESET=''
  C_BOLD=''
  C_RED=''
  C_GREEN=''
  C_YELLOW=''
  C_CYAN=''
  C_BLUE=''
fi

# === Fonctions d'affichage ===

error() {
  printf "%bERROR:%b %s\n" "$C_RED" "$C_RESET" "$*" >&2
}

info() {
  printf "%bINFO:%b %s\n" "$C_CYAN" "$C_RESET" "$*"
}

ok() {
  printf "%bOK:%b %s\n" "$C_GREEN" "$C_RESET" "$*"
}

warn() {
  printf "%bWARN:%b %s\n" "$C_YELLOW" "$C_RESET" "$*"
}

# === Fonctions de validation Git ===

is_repo() {
  git rev-parse --is-inside-work-tree >/dev/null 2>&1
}

has_commits() {
  git rev-parse --verify HEAD >/dev/null 2>&1
}

ensure_repo() {
  if ! is_repo; then
    error "Ce dossier n est pas un depot Git. Lance d abord: make init"
    exit 1
  fi
}

ensure_branch() {
  local expected="$1"
  local current
  current="$(git branch --show-current)"

  if [ "$current" != "$expected" ]; then
    error "Cette commande doit etre executee sur la branche $expected. Lancez : git checkout $expected"
    exit 1
  fi
}

ensure_branch_in() {
  local current
  current="$(git branch --show-current)"
  for allowed in "$@"; do
    case "$current" in
      $allowed) return 0 ;;
    esac
  done
  error "Cette commande n est pas autorisee sur la branche $current."
  error "Branches autorisees : $*"
  exit 1
}

ensure_branch_pattern() {
  local pattern="$1"
  local current
  current="$(git branch --show-current)"
  case "$current" in
    $pattern) return 0 ;;
  esac
  error "Cette commande doit etre executee sur une branche $pattern."
  exit 1
}

# === Fonctions utilitaires Git ===

resolve_remote() {
  local preferred="${1:-}"

  if [ -n "$preferred" ]; then
    if git remote get-url "$preferred" >/dev/null 2>&1; then
      echo "$preferred"
      return 0
    fi
    error "Remote $preferred introuvable."
    return 1
  fi

  local upstream_remote
  upstream_remote="$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2>/dev/null | cut -d/ -f1 || true)"
  if [ -n "$upstream_remote" ]; then
    echo "$upstream_remote"
    return 0
  fi

  local first_remote
  first_remote="$(git remote | head -n1)"
  if [ -n "$first_remote" ]; then
    echo "$first_remote"
    return 0
  fi

  error "Aucun remote configure."
  return 1
}

push_branch() {
  local remote="$1"
  local branch="$2"

  local upstream
  upstream="$(git for-each-ref --format='%(upstream:short)' "refs/heads/$branch")"
  if [ -z "$upstream" ]; then
    info "Aucun upstream pour $branch: push initial avec suivi (-u)."
    git push -u "$remote" "$branch"
    return 0
  fi

  git push "$remote" "$branch"
}

# === Verification des prerequis ===

check_python3() {
  if ! command -v python3 &>/dev/null; then
    error "Python3 requis mais non installe. Installez-le puis relancez."
    exit 1
  fi
}
