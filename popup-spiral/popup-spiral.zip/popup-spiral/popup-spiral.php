<?php
/**
 * Plugin Name: Popup Spiral
 * Description: Popups simples et élégants : ciblage en 1 clic, planification par dates, designs préconfigurés, compteurs anonymes, compatible Divi et Elementor.
 * Version: 1.13.2
 * Author: spiraldev13
 * Text Domain: popup-spiral
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SPIRAL_POPUP_VERSION', '1.0.0');
define('SPIRAL_POPUP_FILE', __FILE__);
define('SPIRAL_POPUP_DIR', plugin_dir_path(__FILE__));
define('SPIRAL_POPUP_URL', plugin_dir_url(__FILE__));

// Mises a jour automatiques depuis wp-plugin-updates (updater makedev).
// Sans ce require, le hook pre_set_site_transient_update_plugins n'est jamais
// pose et WordPress ne detecte aucune mise a jour du plugin.
require_once SPIRAL_POPUP_DIR . 'uploader/updater.php';

spl_autoload_register(static function ($class) {
    if (strpos($class, 'Spiral\\') !== 0) {
        return;
    }

    $relative = substr($class, strlen('Spiral\\'));
    $path = SPIRAL_POPUP_DIR . 'src/' . str_replace('\\', '/', $relative) . '.php';

    if (is_readable($path)) {
        require $path;
    }
});

/**
 * Un popup est « chargeable » s'il est publié, ciblé sur la page courante
 * et dans sa plage de planification.
 *
 * @param int $popupId ID du popup.
 * @return bool
 */
function spiral_popup_is_loadable($popupId)
{
    return \Spiral\Frontend::isLoadable((int) $popupId);
}

// Création de la table de statistiques et pose des options de suivi.
register_activation_hook(__FILE__, ['\Spiral\Install', 'activate']);

// Nettoyage de la tâche planifiée d'auto-désactivation à la désactivation.
register_deactivation_hook(__FILE__, ['\Spiral\AutoExpire', 'clearSchedule']);

add_action('plugins_loaded', static function () {
    \Spiral\Plugin::instance()->boot();
});
