/**
 * Choix d'une image de la médiathèque, pour tous les champs du thème qui en
 * demandent une (portrait de rédacteur, visuel publicitaire).
 *
 * Le contrôle se décrit entièrement en HTML : tout élément portant
 * `data-techana-image` est pris en charge, sans identifiant en dur ici.
 * wp.media est fourni par wp_enqueue_media() — aucun chargement externe.
 */
( function () {
    'use strict';

    if ( ! window.wp || ! window.wp.media ) {
        return;
    }

    function activer( bloc ) {
        var champ   = bloc.querySelector( '[data-role="valeur"]' );
        var apercu  = bloc.querySelector( '[data-role="apercu"]' );
        var choisir = bloc.querySelector( '[data-role="choisir"]' );
        var retirer = bloc.querySelector( '[data-role="retirer"]' );
        var cote    = bloc.dataset.cote || '96';
        var cadre   = null;

        if ( ! champ || ! apercu || ! choisir ) {
            return;
        }

        function afficher( url ) {
            apercu.innerHTML = '';
            if ( ! url ) {
                var vide = document.createElement( 'em' );
                vide.textContent = bloc.dataset.vide || '';
                apercu.appendChild( vide );
                return;
            }
            var img = document.createElement( 'img' );
            img.src = url;
            img.alt = '';
            img.style.cssText = 'max-width:' + cote + 'px;height:auto;display:block';
            apercu.appendChild( img );
        }

        choisir.addEventListener( 'click', function () {
            if ( ! cadre ) {
                cadre = window.wp.media( {
                    title: bloc.dataset.titre || 'Choisir une image',
                    button: { text: 'Utiliser cette image' },
                    library: { type: 'image' },
                    multiple: false
                } );
                cadre.on( 'select', function () {
                    var piece = cadre.state().get( 'selection' ).first().toJSON();
                    champ.value = piece.id;
                    // `medium` et `thumbnail` manquent sur les images plus
                    // petites que la taille demandée : on retombe sur l'original.
                    var tailles = piece.sizes || {};
                    var choix = tailles.medium || tailles.thumbnail || tailles.full;
                    afficher( choix ? choix.url : piece.url );
                    if ( retirer ) {
                        retirer.hidden = false;
                    }
                } );
            }
            cadre.open();
        } );

        if ( retirer ) {
            retirer.addEventListener( 'click', function () {
                champ.value = '';
                afficher( '' );
                retirer.hidden = true;
            } );
        }
    }

    document.querySelectorAll( '[data-techana-image]' ).forEach( activer );
}() );
