<?php

/**
 * Rank Math Integration
 *
 * Expose les métadonnées SEO Rank Math (focus keywords, titre et description
 * SEO) des contenus publiés et planifiés via l'API REST, pour consommation
 * par WP Command Center.
 *
 * @package UltimateShanks\Integration
 */

namespace UltimateShanks\Integration;

if (!defined('ABSPATH')) {
	exit;
}

class RankMathIntegration
{
	/**
	 * Nom de l'option pour activer/désactiver l'intégration
	 */
	const OPTION_NAME = 'ultimate_shanks_rankmath_enabled';

	/**
	 * Taille de page par défaut et maximum (protection mémoire/payload).
	 * L'endpoint est paginé : le consommateur boucle tant que has_more est vrai.
	 */
	const DEFAULT_PER_PAGE = 100;

	const MAX_PER_PAGE = 200;

	/**
	 * Initialise l'intégration
	 */
	public static function init()
	{
		add_action('rest_api_init', [self::class, 'register_rest_routes']);
	}

	/**
	 * Vérifie si l'intégration est activée
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		return get_option(self::OPTION_NAME, '1') === '1';
	}

	/**
	 * Vérifie si Rank Math est actif sur le site
	 *
	 * @return bool
	 */
	public static function is_rankmath_active()
	{
		return defined('RANK_MATH_VERSION') || class_exists('RankMath');
	}

	/**
	 * Enregistre les routes REST API
	 */
	public static function register_rest_routes()
	{
		if (!self::is_enabled()) {
			return;
		}

		register_rest_route('cmd/v1', '/rankmath-keywords', [
			'methods'             => 'GET',
			'callback'            => [self::class, 'get_keywords_for_cmd'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);

		// Écriture : POST /wp-json/cmd/v1/rankmath-keyword — ajoute un focus
		// keyword Rank Math à un article (sync inverse depuis WP Command Center).
		register_rest_route('cmd/v1', '/rankmath-keyword', [
			'methods'             => 'POST',
			'callback'            => [self::class, 'set_keyword_for_cmd'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);
	}

	/**
	 * Ajoute un focus keyword Rank Math à un article (POST id + focus_keyword).
	 * Insensible à la casse pour le doublon ; principal si la liste était vide,
	 * sinon ajouté en secondaire. Renvoie la liste résultante.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function set_keyword_for_cmd($request)
	{
		if (!self::is_enabled() || !self::is_rankmath_active()) {
			return new \WP_REST_Response([
				'success' => false,
				'message' => 'Rank Math est indisponible sur ce site.',
			], 400);
		}

		$id = (int) $request->get_param('id');
		$keyword = trim((string) $request->get_param('focus_keyword'));
		$post = $id > 0 ? get_post($id) : null;

		if (!$post || $keyword === '') {
			return new \WP_REST_Response([
				'success' => false,
				'message' => 'Article introuvable ou mot-clé vide.',
			], 400);
		}

		$focus_raw = (string) get_post_meta($id, 'rank_math_focus_keyword', true);
		$keywords = array_values(array_filter(array_map('trim', explode(',', $focus_raw))));

		$exists = false;
		foreach ($keywords as $existing) {
			if (mb_strtolower($existing) === mb_strtolower($keyword)) {
				$exists = true;
				break;
			}
		}

		if (!$exists) {
			$keywords[] = $keyword;
			update_post_meta($id, 'rank_math_focus_keyword', implode(', ', $keywords));
		}

		return new \WP_REST_Response([
			'success'        => true,
			'id'             => $id,
			'focus_keywords' => $keywords,
			'added'          => !$exists,
		], 200);
	}

	/**
	 * Callback pour WP Command Center
	 * Endpoint dédié : GET /wp-json/cmd/v1/rankmath-keywords?page=1&per_page=100
	 *
	 * Retourne les contenus publiés/planifiés (articles + pages) avec leurs
	 * métadonnées Rank Math, paginés (aucune limite totale : le consommateur
	 * boucle tant que has_more est vrai). Les contenus sans focus keyword sont
	 * inclus (liste vide) pour permettre leur détection côté Command Center.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function get_keywords_for_cmd($request)
	{
		if (!self::is_enabled() || !self::is_rankmath_active()) {
			return new \WP_REST_Response([
				'success'         => true,
				'enabled'         => self::is_enabled(),
				'rankmath_active' => self::is_rankmath_active(),
				'contents'        => [],
				'has_more'        => false,
			], 200);
		}

		$page = max(1, (int) ($request ? $request->get_param('page') : 1));
		$per_page = (int) ($request ? $request->get_param('per_page') : 0);
		if ($per_page < 1) {
			$per_page = self::DEFAULT_PER_PAGE;
		}
		$per_page = min($per_page, self::MAX_PER_PAGE);

		$query = new \WP_Query([
			'post_type'        => ['post', 'page'],
			'post_status'      => ['publish', 'future'],
			'posts_per_page'   => $per_page,
			'paged'            => $page,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'suppress_filters' => false,
		]);
		$posts = $query->posts;

		$contents = [];
		foreach ($posts as $post) {
			$focus_raw = (string) get_post_meta($post->ID, 'rank_math_focus_keyword', true);

			// Rank Math stocke les focus keywords en chaîne séparée par des virgules :
			// le premier est le principal, les suivants sont les secondaires.
			$focus_keywords = array_values(array_filter(array_map('trim', explode(',', $focus_raw))));

			$contents[] = [
				'id'              => (int) $post->ID,
				'type'            => $post->post_type,
				'status'          => $post->post_status,
				'title'           => get_the_title($post),
				'url'             => get_permalink($post),
				'date'            => $post->post_date,
				'focus_keywords'  => $focus_keywords,
				'seo_title'       => (string) get_post_meta($post->ID, 'rank_math_title', true),
				'seo_description' => (string) get_post_meta($post->ID, 'rank_math_description', true),
			];
		}

		return new \WP_REST_Response([
			'success'         => true,
			'enabled'         => true,
			'rankmath_active' => true,
			'contents'        => $contents,
			'page'            => $page,
			'has_more'        => $page < (int) $query->max_num_pages,
		], 200);
	}

	/**
	 * Vérifie les permissions pour l'API REST
	 *
	 * @param \WP_REST_Request $request
	 * @return bool
	 */
	public static function check_permissions($request)
	{
		// Métadonnées SEO = donnée business : réservé aux administrateurs
		// (WP Command Center s'authentifie via Application Password admin).
		return current_user_can('manage_options');
	}
}
