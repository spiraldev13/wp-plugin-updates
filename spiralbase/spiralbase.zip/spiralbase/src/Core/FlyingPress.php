<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Faits FlyingPress — SOURCE UNIQUE pour toutes les sondes perf (un renvoi
 * plutôt qu'une copie : le jour où les faits changent, UN fichier).
 *
 * STATUT DOCUMENTAIRE : FlyingPress est absent de l'environnement de dev —
 * la constante `FLYING_PRESS_VERSION` et les clés de l'option
 * `flying_press_config` viennent des docs publiques FP, pas d'une lecture
 * du code (différé de la story 2.4 : à VÉRIFIER sur le plugin réel à la
 * première installation de la flotte). Fail-safe : un fait faux ne peut
 * produire qu'un MAINTIEN, jamais une cession fantôme.
 */
final class FlyingPress
{
    /** Un levier FlyingPress est-il réellement actif (plugin + réglage) ? */
    public static function levierActif(string $cle): bool
    {
        if (!defined('FLYING_PRESS_VERSION')) {
            return false;
        }

        $config = get_option('flying_press_config', []);

        return is_array($config) && !empty($config[$cle]);
    }
}
