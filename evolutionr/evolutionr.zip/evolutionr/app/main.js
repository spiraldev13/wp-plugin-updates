import './stylesheets/main.scss';

const SELECTORS = {
    faqItem: '.faq-item',
    faqQuestion: '.faq-q',
    pageFaqItem: '.page-faq-item',
    pageFaqSummary: '.page-faq-summary',
    navToggle: '[data-nav-toggle]',
    nav: '[data-nav]',
    submenuToggle: '[data-submenu-toggle]',
    scrollTop: '[data-scroll-top]',
};

const SCROLL_TOP_THRESHOLD = 200;

function initFaqAccordion() {
    document.querySelectorAll(SELECTORS.faqItem).forEach((item) => {
        const button = item.querySelector(SELECTORS.faqQuestion);
        if (!button) return;
        button.addEventListener('click', () => {
            const wasOpen = item.classList.contains('open');
            item.parentElement.querySelectorAll(`${SELECTORS.faqItem}.open`).forEach((el) => el.classList.remove('open'));
            if (!wasOpen) item.classList.add('open');
            button.setAttribute('aria-expanded', !wasOpen);
        });
    });
}

/**
 * Anime le toggle des accordéons FAQ des pages prestation
 * (`.page-faq-item`). Même pattern que la FAQ de la home : un simple
 * toggle de classe `.open`. L'animation est ENTIÈREMENT en CSS via
 * `grid-template-rows: 0fr → 1fr` → aucune saccade possible, aucun
 * problème de mesure JS.
 */
function initPageFaqAccordion() {
    document.querySelectorAll(SELECTORS.pageFaqItem).forEach((item) => {
        const button = item.querySelector(SELECTORS.pageFaqSummary);
        if (!button) return;
        button.addEventListener('click', () => {
            const wasOpen = item.classList.toggle('open');
            button.setAttribute('aria-expanded', wasOpen ? 'true' : 'false');
        });
    });
}

function initMobileNav() {
    const toggle = document.querySelector(SELECTORS.navToggle);
    const nav = document.querySelector(SELECTORS.nav);
    if (!toggle || !nav) return;

    const closeOnEscape = (event) => {
        if (event.key === 'Escape') closeNav();
    };

    const closeNav = () => {
        toggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
        document.body.classList.remove('nav-open');
        document.removeEventListener('keydown', closeOnEscape);
    };

    const openNav = () => {
        toggle.setAttribute('aria-expanded', 'true');
        nav.classList.add('is-open');
        document.body.classList.add('nav-open');
        document.addEventListener('keydown', closeOnEscape);
    };

    toggle.addEventListener('click', () => {
        const isOpen = toggle.getAttribute('aria-expanded') === 'true';
        if (isOpen) closeNav();
        else openNav();
    });

    nav.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', closeNav);
    });
}

/**
 * Toggle des sous-menus du menu principal (ex. « Prestations ▾ »).
 *
 * Le parent d'un sous-menu est un `<button data-submenu-toggle aria-expanded>`
 * (cf. Walker_Nav_Header). Sur mobile, c'est le seul moyen d'ouvrir le sous-menu
 * (pas de hover). Sur desktop, hover ET click fonctionnent ; l'état
 * `aria-expanded` reflète l'état explicite (click), pas l'état dérivé du hover.
 *
 * Comportements :
 *  - Click / Espace / Entrée → bascule aria-expanded
 *  - Un seul sous-menu ouvert à la fois (ferme les autres avant d'ouvrir)
 *  - Escape → ferme tous + focus retour au dernier toggle ouvert
 *  - Click hors d'un .nav-item → ferme tous
 */
function initSubmenuToggle() {
    const toggles = Array.from(document.querySelectorAll(SELECTORS.submenuToggle));
    if (toggles.length === 0) return;

    const closeAll = (except = null) => {
        toggles.forEach((btn) => {
            if (btn !== except) btn.setAttribute('aria-expanded', 'false');
        });
    };

    toggles.forEach((toggle) => {
        toggle.addEventListener('click', (event) => {
            event.preventDefault();
            const isOpen = toggle.getAttribute('aria-expanded') === 'true';
            closeAll(toggle);
            toggle.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
        });
    });

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        const opened = toggles.find((btn) => btn.getAttribute('aria-expanded') === 'true');
        if (opened) {
            opened.setAttribute('aria-expanded', 'false');
            opened.focus();
        }
    });

    document.addEventListener('click', (event) => {
        const inside = event.target.closest('.nav-item');
        if (inside) return;
        closeAll();
    });
}

/**
 * Bouton « Retour en haut » fixé en bas à droite (cf. footer.php +
 * components/_scroll-top.scss).
 *
 *  - Apparition / disparition : entièrement gouvernée par la classe
 *    `.is-visible` côté CSS (transition opacity + visibility + transform,
 *    cubic-bezier expo-out). On synchronise aussi `aria-hidden` et
 *    `tabindex` pour ne pas exposer aux lecteurs d'écran / clavier un
 *    bouton invisible.
 *
 *  - Scroll vers le haut : on évite le double smooth (CSS global +
 *    `behavior: smooth` JS) qui peut produire un snap à l'arrivée. On
 *    désactive temporairement `scroll-behavior` du <html>, puis on
 *    anime nous-mêmes avec requestAnimationFrame + easeOutQuint pour
 *    une décélération douce et continue jusqu'à scrollY = 0.
 *
 *  - Respect de `prefers-reduced-motion` : retour instantané.
 *
 *  - Si l'utilisateur scrolle manuellement (wheel / touchstart /
 *    keydown) pendant l'animation, on annule pour ne pas se battre
 *    contre lui.
 */
function initScrollToTop() {
    const button = document.querySelector(SELECTORS.scrollTop);
    if (!button) return;

    // Adopte le pattern jQuery : on manipule `opacity` directement en
    // inline style. La transition CSS (`transition: opacity 1s
    // ease-in-out`) s'applique au passage 0 ↔ 1. C'est plus robuste
    // qu'un toggle de classe face à certains modes HMR / cas limites.
    const setVisible = (visible) => {
        button.style.opacity = visible ? '1' : '0';
        button.style.pointerEvents = visible ? 'auto' : 'none';
        button.setAttribute('aria-hidden', visible ? 'false' : 'true');
        if (visible) {
            button.removeAttribute('tabindex');
        } else {
            button.setAttribute('tabindex', '-1');
        }
    };

    const update = () => {
        setVisible((window.scrollY || window.pageYOffset) > SCROLL_TOP_THRESHOLD);
    };

    // Évite le FOUC : au mount (et au retour bfcache), on applique
    // l'état initial avec la transition désactivée pour ne pas voir
    // un fade-out parasite quand le bouton se retrouve un instant
    // visible (CSS pas encore appliqué, ou bfcache qui restaure un
    // opacity:1 d'avant la navigation). `setProperty('transition',
    // 'none', 'important')` est nécessaire pour battre le !important
    // posé en CSS sur la transition.
    const applyInitialStateNoTransition = () => {
        button.style.setProperty('transition', 'none', 'important');
        update();
        // Force reflow pour appliquer le style avant de retirer la
        // règle inline → garantit qu'aucune transition n'est en file.
        // eslint-disable-next-line no-unused-expressions
        button.offsetHeight;
        button.style.removeProperty('transition');
    };

    applyInitialStateNoTransition();
    window.addEventListener('scroll', update, { passive: true });
    // bfcache : le `pageshow` se déclenche aussi à la restauration
    // d'une page mise en cache (back/forward). On rejoue l'init sans
    // transition pour rattraper un éventuel opacity:1 résiduel.
    window.addEventListener('pageshow', applyInitialStateNoTransition);

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    let animationId = null;

    const cancelScroll = () => {
        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
            document.documentElement.style.scrollBehavior = '';
        }
    };

    const smoothScrollToTop = () => {
        const start = window.scrollY || window.pageYOffset;
        if (start === 0) return;

        // Désactive le scroll-behavior CSS le temps de l'animation pour
        // éviter qu'il vienne se superposer à nos appels par frame.
        document.documentElement.style.scrollBehavior = 'auto';

        // easeOutQuint pour un vrai amortissement en fin de course :
        // la vitesse approche zéro très progressivement sur les
        // derniers 20% du parcours → arrivée au top sans aucun snap.
        // Comportement unifié quelle que soit la préférence OS — un
        // ralentissement progressif n'est pas un « mouvement excessif ».
        const easeOutQuint = (t) => 1 - Math.pow(1 - t, 5);
        const duration = Math.min(2000, Math.max(500, start * 0.7));
        const ease = easeOutQuint;
        const startTime = performance.now();

        const step = (now) => {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const y = start * (1 - ease(progress));

            // Appel direct par coordonnées : signature legacy, instant,
            // pas affecté par scroll-behavior (qu'on a en plus désactivé).
            window.scrollTo(0, y);

            if (progress < 1) {
                animationId = requestAnimationFrame(step);
            } else {
                animationId = null;
                document.documentElement.style.scrollBehavior = '';
            }
        };

        animationId = requestAnimationFrame(step);
    };

    // Toute interaction utilisateur pendant l'anim => on lui rend la main.
    ['wheel', 'touchstart', 'keydown'].forEach((evt) => {
        window.addEventListener(evt, () => {
            if (animationId !== null) cancelScroll();
        }, { passive: true });
    });

    button.addEventListener('click', smoothScrollToTop);
}

/**
 * Scroll souple vers les ancres internes de la page (ex. le bouton « Voir
 * les réalisations » du hero → section #works). Réplique l'amorti du bouton
 * « Retour en haut » : on intercepte le clic, on désactive le scroll-behavior
 * CSS le temps de l'animation, puis on anime nous-mêmes avec
 * requestAnimationFrame + easeOutQuint jusqu'à la cible (décalée de la
 * hauteur du header sticky pour ne pas la masquer).
 *
 * Comportement unifié quelle que soit la préférence `prefers-reduced-motion`
 * — comme le scroll-top : un ralentissement progressif n'est pas un
 * « mouvement excessif », et c'est l'effet voulu ici (le saut natif était
 * en outre désactivé par l'override universel reduced-motion sur
 * `scroll-behavior`). Annulé si l'utilisateur scrolle pendant l'animation.
 *
 * N'intercepte que les ancres dont la cible existe sur la page courante ;
 * les autres (`#`, ancres hors page) gardent leur comportement natif.
 */
function initSmoothAnchors() {
    const links = document.querySelectorAll('a[href^="#"]');
    if (!links.length) return;

    const easeOutQuint = (t) => 1 - Math.pow(1 - t, 5);
    let animationId = null;

    const cancel = () => {
        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
            document.documentElement.style.scrollBehavior = '';
        }
    };

    ['wheel', 'touchstart', 'keydown'].forEach((evt) => {
        window.addEventListener(evt, cancel, { passive: true });
    });

    const headerOffset = () => {
        const header = document.querySelector('.header');
        return header ? header.offsetHeight : 0;
    };

    const scrollToTarget = (target, hash) => {
        const start = window.scrollY || window.pageYOffset;
        const end = Math.max(0, target.getBoundingClientRect().top + start - headerOffset() - 12);
        const distance = end - start;
        if (Math.abs(distance) < 2) return;

        // Inline `auto` pour neutraliser le scroll-behavior CSS pendant
        // qu'on pilote nous-mêmes le défilement frame par frame.
        document.documentElement.style.scrollBehavior = 'auto';
        const duration = Math.min(2000, Math.max(500, Math.abs(distance) * 0.7));
        const startTime = performance.now();

        const step = (now) => {
            const progress = Math.min((now - startTime) / duration, 1);
            window.scrollTo(0, start + distance * easeOutQuint(progress));
            if (progress < 1) {
                animationId = requestAnimationFrame(step);
            } else {
                animationId = null;
                document.documentElement.style.scrollBehavior = '';
                // Synchronise l'URL sans re-déclencher de saut natif.
                if (window.history && hash) {
                    window.history.replaceState(null, '', hash);
                }
            }
        };

        animationId = requestAnimationFrame(step);
    };

    links.forEach((link) => {
        const hash = link.getAttribute('href');
        if (!hash || hash === '#') return;

        const target = document.getElementById(decodeURIComponent(hash.slice(1)));
        if (!target) return; // ancre sans cible ici → comportement natif

        link.addEventListener('click', (event) => {
            event.preventDefault();
            cancel();
            scrollToTarget(target, hash);
        });
    });
}

function bootstrap() {
    initFaqAccordion();
    initPageFaqAccordion();
    initMobileNav();
    initSubmenuToggle();
    initScrollToTop();
    initSmoothAnchors();
}

// Les scripts ES modules sont chargés en defer : DOMContentLoaded peut
// avoir déjà été émis avant que ce fichier ne soit évalué. On exécute
// l'init immédiatement si le DOM est prêt, sinon on attend l'évènement.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
} else {
    bootstrap();
}

if (import.meta.hot) {
    import.meta.hot.accept();
}
