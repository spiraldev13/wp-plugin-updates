<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Installation et migrations de schéma.
 *
 * Crée la table de statistiques journalières et pose les options de suivi.
 * Idempotent : la version de schéma (`spiral_db_version`) garde la migration,
 * exécutée à l'activation et — filet de sécurité pour les mises à jour sans
 * réactivation — au premier `admin_init` suivant.
 */
final class Install
{
    /** Version du schéma de base ; à incrémenter lors d'un changement de structure. */
    public const DB_VERSION = '1';

    public const DB_VERSION_OPTION = 'spiral_db_version';

    /** Date (site) de bascule vers le suivi journalier détaillé. */
    public const STATS_SINCE_OPTION = 'spiral_stats_since';

    /** Nom court de la table (sans préfixe). */
    private const TABLE = 'spiral_stats';

    /**
     * Nom complet de la table de statistiques, préfixe inclus.
     */
    public static function statsTable(): string
    {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    /**
     * Exécutée par le hook d'activation du plugin.
     */
    public static function activate(): void
    {
        self::install();
    }

    /**
     * Rejoue la migration si la version de schéma enregistrée est obsolète.
     * Branchée sur `admin_init` : couvre les mises à jour où le hook
     * d'activation ne se déclenche pas.
     */
    public static function maybeUpgrade(): void
    {
        if (get_option(self::DB_VERSION_OPTION) !== self::DB_VERSION) {
            self::install();
        }
    }

    /**
     * Crée / met à jour la table et pose les options de suivi.
     */
    private static function install(): void
    {
        global $wpdb;

        $table = self::statsTable();
        $charsetCollate = $wpdb->get_charset_collate();

        // Clé unique (popup_id, event_type, event_date) : socle des upserts atomiques.
        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            popup_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(10) NOT NULL,
            event_date DATE NOT NULL,
            count BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY popup_event_date (popup_id, event_type, event_date),
            KEY event_date (event_date)
        ) $charsetCollate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        update_option(self::DB_VERSION_OPTION, self::DB_VERSION);

        // Date de départ du suivi détaillé : figée une seule fois, sert à distinguer
        // les totaux cumulés hérités des séries journalières.
        if (!get_option(self::STATS_SINCE_OPTION)) {
            update_option(self::STATS_SINCE_OPTION, Dates::today());
        }
    }
}
