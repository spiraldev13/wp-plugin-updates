<?php
/**
 * CSS Generator - Générateur de CSS dynamique
 *
 * Ce fichier génère le CSS dynamique à partir des options WordPress
 * et l'enregistre dans /assets/css/generated-styles.css.
 *
 * Fichier généré :
 * - CSS Front-end : /assets/css/generated-styles.css (créé dynamiquement)
 *
 * Fichiers liés :
 * - style-manager.php : Enqueue le CSS généré sur le front-end
 * - settings.php      : Interface admin (formulaires de configuration)
 *
 * @package UltimateShanks\Style
 */

namespace UltimateShanks\Style;

class CSSGenerator
{
	/**
	 * Chemin absolu du fichier CSS généré.
	 *
	 * Le fichier vit dans uploads/ (et non dans le dossier du plugin) : le dossier du
	 * plugin n'est pas toujours inscriptible par PHP (déploiement sous un autre user)
	 * et il est entièrement remplacé à chaque mise à jour — deux causes historiques
	 * de CSS absent ou périmé sur le front.
	 *
	 * @return string
	 */
	public static function get_css_file_path()
	{
		$upload = wp_upload_dir();
		return $upload['basedir'] . '/ultimate-shanks/generated-styles.css';
	}

	/**
	 * URL publique du fichier CSS généré.
	 *
	 * @return string
	 */
	public static function get_css_file_url()
	{
		$upload = wp_upload_dir();
		return $upload['baseurl'] . '/ultimate-shanks/generated-styles.css';
	}

	/**
	 * Génère le fichier CSS
	 *
	 * @return bool
	 */
	public static function generate_css()
	{
		$css = self::get_css_string();
		$css_file = self::get_css_file_path();

		// Créer le dossier si inexistant
		$css_dir = dirname($css_file);
		if (!file_exists($css_dir) && !wp_mkdir_p($css_dir)) {
			return false;
		}

		// Écrire le CSS dans le fichier
		$result = @file_put_contents($css_file, $css);

		// 644 : lisible par tous, modifiable uniquement par le propriétaire (le process PHP
		// qui régénère le fichier). 666 exposerait le fichier à toute écriture sur mutualisé.
		if ($result !== false) {
			@chmod($css_file, 0644);
			// Invalider le cache stat de PHP pour que filemtime() reflète l'écriture
			// dans la même requête (contrôle de fraîcheur du style-manager).
			clearstatcache(true, $css_file);
		}

		return $result !== false;
	}

	/**
	 * Retourne le CSS généré en mémoire (sans écriture disque)
	 *
	 * @return string
	 */
	public static function get_css_string()
	{
		return self::build_css();
	}

	/**
	 * Construit le CSS complet
	 *
	 * @return string CSS généré
	 */
	private static function build_css()
	{
		$css = "/* CSS généré automatiquement par Ultimate Shanks - Ne pas modifier manuellement */\n\n";

		$css .= self::generate_headings_css();
		$css .= self::generate_lists_css();
		$css .= self::generate_tables_css();
		$css .= self::generate_links_css();
		$css .= self::generate_blockquotes_css();

		return $css;
	}

	/**
	 * Retourne une couleur hex valide, ou chaîne vide si invalide.
	 *
	 * sanitize_hex_color() retourne null pour une valeur invalide : sans ce garde-fou,
	 * on générerait des règles cassées du type "color: ;".
	 *
	 * @param string $color
	 * @return string
	 */
	private static function sanitize_color($color)
	{
		return (string) sanitize_hex_color((string) $color);
	}

	/**
	 * Valide une valeur CSS libre (padding, border, font-size, etc.).
	 *
	 * esc_attr() ne protège pas dans un contexte CSS : une valeur contenant ";" ou "}"
	 * fermerait le bloc et permettrait d'injecter des règles arbitraires. On autorise
	 * uniquement les caractères nécessaires aux valeurs usuelles.
	 *
	 * @param string $value
	 * @return string Valeur validée, ou chaîne vide si rejetée
	 */
	private static function sanitize_value($value)
	{
		$value = (string) $value;
		return preg_match('/^[a-zA-Z0-9\s.,%#()\/-]+$/', $value) ? $value : '';
	}

	/**
	 * Construit la règle background-color d'un élément (avec gestion de l'opacité).
	 *
	 * @param string $option_prefix Préfixe des options (ex: "ultimate_shanks_h1")
	 * @return string Règle CSS, ou chaîne vide si désactivé/invalide
	 */
	private static function get_background_rule($option_prefix)
	{
		$bg_enabled = get_option("{$option_prefix}_background_enabled", '0') === '1';
		$bg = self::sanitize_color(get_option("{$option_prefix}_background", ''));
		$bg_opacity = (float) get_option("{$option_prefix}_background_opacity", '1');

		if (!$bg_enabled || empty($bg)) {
			return '';
		}

		// Utiliser rgba si opacité < 1 (uniquement possible sur un hex 6 caractères)
		$hex = ltrim($bg, '#');
		if ($bg_opacity < 1 && strlen($hex) === 6) {
			$r = hexdec(substr($hex, 0, 2));
			$g = hexdec(substr($hex, 2, 2));
			$b = hexdec(substr($hex, 4, 2));
			return "background-color: rgba({$r}, {$g}, {$b}, {$bg_opacity})";
		}

		return "background-color: {$bg}";
	}

	/**
	 * Ajoute une règle "propriété: valeur" si la valeur est non vide après validation.
	 *
	 * @param array  $rules    Tableau de règles (par référence)
	 * @param string $property Propriété CSS
	 * @param string $value    Valeur déjà validée (sanitize_color / sanitize_value)
	 */
	private static function add_rule(array &$rules, $property, $value)
	{
		if (!empty($value)) {
			$rules[] = "{$property}: {$value}";
		}
	}

	/**
	 * Génère le CSS pour les titres H1-H6
	 *
	 * @return string
	 */
	private static function generate_headings_css()
	{
		$css = "/* === TITRES === */\n";
		$scope = get_option('ultimate_shanks_headings_scope', 'global');

		for ($i = 1; $i <= 6; $i++) {
			$enabled = get_option("ultimate_shanks_h{$i}_enabled", '0') === '1';
			if (!$enabled) continue;

			$prefix = "ultimate_shanks_h{$i}";
			$rules = [];

			self::add_rule($rules, 'color', self::sanitize_color(get_option("{$prefix}_color", '')));

			$bg_rule = self::get_background_rule($prefix);
			if (!empty($bg_rule)) {
				$rules[] = $bg_rule;
			}

			self::add_rule($rules, 'padding', self::sanitize_value(get_option("{$prefix}_padding", '')));
			self::add_rule($rules, 'margin', self::sanitize_value(get_option("{$prefix}_margin", '')));
			self::add_rule($rules, 'font-size', self::sanitize_value(get_option("{$prefix}_font_size", '')));
			self::add_rule($rules, 'font-weight', self::sanitize_value(get_option("{$prefix}_font_weight", '')));
			self::add_rule($rules, 'border', self::sanitize_value(get_option("{$prefix}_border", '')));
			self::add_rule($rules, 'border-radius', self::sanitize_value(get_option("{$prefix}_border_radius", '')));

			if (!empty($rules)) {
				$selector = self::get_scope_selector($scope, "h{$i}");
				$css .= self::render_block($selector, $rules);
			}
		}

		return $css;
	}

	/**
	 * Génère le CSS pour les listes UL et OL
	 *
	 * @return string
	 */
	private static function generate_lists_css()
	{
		$css = "/* === LISTES === */\n";
		$scope = get_option('ultimate_shanks_lists_scope', 'global');

		foreach (['ul' => 'disc', 'ol' => 'decimal'] as $tag => $default_marker) {
			$enabled = get_option("ultimate_shanks_{$tag}_enabled", '0') === '1';
			if (!$enabled) continue;

			$prefix = "ultimate_shanks_{$tag}";
			$rules = [];

			self::add_rule($rules, 'color', self::sanitize_color(get_option("{$prefix}_color", '')));

			$bg_rule = self::get_background_rule($prefix);
			if (!empty($bg_rule)) {
				$rules[] = $bg_rule;
			}

			$padding = self::sanitize_value(get_option("{$prefix}_padding", ''));
			$margin = self::sanitize_value(get_option("{$prefix}_margin", ''));
			self::add_rule($rules, 'padding', $padding);
			self::add_rule($rules, 'margin', $margin);
			self::add_rule($rules, 'border', self::sanitize_value(get_option("{$prefix}_border", '')));
			self::add_rule($rules, 'border-radius', self::sanitize_value(get_option("{$prefix}_border_radius", '')));

			// Toujours forcer un style de marqueur visible quand la liste est activée.
			$list_style = self::sanitize_value(get_option("{$prefix}_list_style", ''));
			$rules[] = "list-style-type: " . (!empty($list_style) ? $list_style : $default_marker);
			$rules[] = "list-style-position: outside";

			// Sécurité anti-reset agressif: conserver un retrait minimal si aucun spacing custom.
			if (empty($padding) && empty($margin)) {
				$rules[] = "padding-inline-start: 1.5em";
			}

			$selector = self::get_scope_selector($scope, $tag);
			$css .= self::render_block($selector, $rules);

			$marker_selector = self::get_scope_selector($scope, "{$tag} li::marker");
			$css .= self::render_block($marker_selector, ['color: currentColor']);
		}

		return $css;
	}

	/**
	 * Génère le CSS pour les tableaux
	 *
	 * @return string
	 */
	private static function generate_tables_css()
	{
		$css = "/* === TABLEAUX === */\n";
		$scope = get_option('ultimate_shanks_tables_scope', 'global');

		// TH
		if (get_option('ultimate_shanks_th_enabled', '0') === '1') {
			$rules = [];

			self::add_rule($rules, 'color', self::sanitize_color(get_option('ultimate_shanks_th_color', '')));

			$bg_rule = self::get_background_rule('ultimate_shanks_th');
			if (!empty($bg_rule)) {
				$rules[] = $bg_rule;
			}

			self::add_rule($rules, 'padding', self::sanitize_value(get_option('ultimate_shanks_th_padding', '')));
			self::add_rule($rules, 'border', self::sanitize_value(get_option('ultimate_shanks_th_border', '')));
			self::add_rule($rules, 'font-weight', self::sanitize_value(get_option('ultimate_shanks_th_font_weight', '')));

			if (!empty($rules)) {
				$css .= self::render_block(self::get_scope_selector($scope, 'table th'), $rules);
			}
		}

		// TD
		if (get_option('ultimate_shanks_td_enabled', '0') === '1') {
			$rules = [];

			self::add_rule($rules, 'color', self::sanitize_color(get_option('ultimate_shanks_td_color', '')));

			$bg_rule = self::get_background_rule('ultimate_shanks_td');
			if (!empty($bg_rule)) {
				$rules[] = $bg_rule;
			}

			self::add_rule($rules, 'padding', self::sanitize_value(get_option('ultimate_shanks_td_padding', '')));
			self::add_rule($rules, 'border', self::sanitize_value(get_option('ultimate_shanks_td_border', '')));

			if (!empty($rules)) {
				$css .= self::render_block(self::get_scope_selector($scope, 'table td'), $rules);
			}
		}

		return $css;
	}

	/**
	 * Génère le CSS pour les liens
	 *
	 * @return string
	 */
	private static function generate_links_css()
	{
		$css = "/* === LIENS === */\n";
		$enabled = get_option('ultimate_shanks_links_enabled', '0') === '1';
		if (!$enabled) return $css;

		$scope = get_option('ultimate_shanks_links_scope', 'global');

		$rules = [];

		self::add_rule($rules, 'color', self::sanitize_color(get_option('ultimate_shanks_links_color', '')));
		self::add_rule($rules, 'text-decoration', self::sanitize_value(get_option('ultimate_shanks_links_decoration', '')));
		self::add_rule($rules, 'font-weight', self::sanitize_value(get_option('ultimate_shanks_links_font_weight', '')));

		$transition = self::sanitize_value(get_option('ultimate_shanks_links_transition', ''));
		if (!empty($transition)) {
			$rules[] = "transition: all {$transition}s ease";
		}

		if (!empty($rules)) {
			$css .= self::render_block(self::get_scope_selector($scope, 'a'), $rules);
		}

		// Hover
		$hover_color = self::sanitize_color(get_option('ultimate_shanks_links_hover_color', ''));
		if (!empty($hover_color)) {
			$css .= self::render_block(self::get_scope_selector($scope, 'a:hover'), ["color: {$hover_color}"]);
		}

		return $css;
	}

	/**
	 * Génère le CSS pour les blockquotes
	 *
	 * @return string
	 */
	private static function generate_blockquotes_css()
	{
		$css = "/* === CITATIONS === */\n";
		$enabled = get_option('ultimate_shanks_blockquote_enabled', '0') === '1';
		if (!$enabled) return $css;

		$scope = get_option('ultimate_shanks_blockquote_scope', 'global');

		$rules = [];

		self::add_rule($rules, 'color', self::sanitize_color(get_option('ultimate_shanks_blockquote_color', '')));

		$bg_rule = self::get_background_rule('ultimate_shanks_blockquote');
		if (!empty($bg_rule)) {
			$rules[] = $bg_rule;
		}

		self::add_rule($rules, 'padding', self::sanitize_value(get_option('ultimate_shanks_blockquote_padding', '')));

		// Bordure gauche
		$border_width = self::sanitize_value(get_option('ultimate_shanks_blockquote_border_width', ''));
		$border_color = self::sanitize_color(get_option('ultimate_shanks_blockquote_border_color', ''));
		if (!empty($border_width) && !empty($border_color)) {
			$rules[] = "border-left: {$border_width} solid {$border_color}";
		}

		if (!empty($rules)) {
			$css .= self::render_block(self::get_scope_selector($scope, 'blockquote'), $rules);
		}

		return $css;
	}

	/**
	 * Rend un bloc CSS "sélecteur { règles }".
	 *
	 * @param string $selector
	 * @param array  $rules
	 * @return string
	 */
	private static function render_block($selector, array $rules)
	{
		$css = "{$selector} {\n";
		foreach ($rules as $rule) {
			$css .= "\t{$rule};\n";
		}
		$css .= "}\n\n";

		return $css;
	}

	/**
	 * Retourne le sélecteur CSS selon le scope
	 *
	 * @param string $scope
	 * @param string $element Élément HTML optionnel (ex: 'h1', 'ul', 'a')
	 * @return string
	 */
	private static function get_scope_selector($scope, $element = '')
	{
		$selectors = [];

		switch ($scope) {
			case 'posts':
				// Scope "Articles uniquement" - cibler les articles de blog
				$selectors = [
					'.single-post .entry-content',
					'.single-post .wp-block-post-content',
					'.single-post article',
					'.single-post .post-content',
					'body.single-post main'
				];
				break;
			case 'pages':
				// Scope "Pages uniquement" - cibler les pages WordPress
				$selectors = [
					'.page .entry-content',
					'.page .wp-block-post-content',
					'.page article',
					'.page .page-content',
					'body.page main'
				];
				break;
			case 'global':
			default:
				// Scope "Global" - cibler partout (articles, pages, archives, etc.)
				$selectors = [
					'.entry-content',
					'.wp-block-post-content',
					'.post-content',
					'.page-content',
					'.content-area',
					'article',
					'main'
				];
				break;
		}

		// Si un élément est spécifié, l'ajouter à chaque sélecteur
		if (!empty($element)) {
			$selectors = array_map(function($selector) use ($element) {
				return $selector . ' ' . $element;
			}, $selectors);
		}

		return implode(', ', $selectors);
	}
}
