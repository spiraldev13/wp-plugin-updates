<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Porte unique de lecture/écriture des données métier du site (AD-2 :
 * « les modules partagent les données métier via le noyau — jamais entre
 * eux », AD-7 transposé) : UNE option canonique, écrite ici et nulle part
 * ailleurs, TOUJOURS validée — à l'écriture ET à la relecture (une option
 * bricolée hors de la porte ne traverse jamais). Les données métier sont
 * une DONNÉE du site — les mises à jour du parent ne les touchent jamais.
 *
 * Migration : aucune donnée antérieure à la v1 n'existe (le service est né
 * avec elle) — un pipeline `migrer()` façon RecipeStore s'écrira AVANT
 * tout bump de SCHEMA_VERSION.
 */
final class DonneesMetier
{
    public const OPTION = 'spiralbase_donnees_metier';

    public const SCHEMA_VERSION = 1;

    public const CODE_INVALIDE = 'spiralbase_donnees_metier_invalides';

    /** Vocabulaire fermé des activités — la table de rendu du module schema_metier s'y aligne. */
    public const TYPES_ACTIVITE = ['restaurant', 'commerce', 'sante', 'artisan'];

    /** Champs admis à la racine — la porte canonique ne persiste jamais de données arbitraires. */
    private const CHAMPS = ['schema_version', 'nom', 'adresse', 'telephone', 'horaires', 'type_activite'];

    private const CHAMPS_ADRESSE = ['rue', 'code_postal', 'ville'];

    private const LONGUEURS = ['nom' => 200, 'telephone' => 50, 'type_activite' => 50];

    /** @var array<string, true> signaux déjà émis cette requête (anti-amplification) */
    private static array $signale = [];

    /** @return true|\WP_Error frontière — jamais d'exception de validation */
    public function set(array $donnees): bool|\WP_Error
    {
        /* Assainir AVANT de juger : les balises tombent, un nom réduit à
           vide sera refusé par le juge — jamais persisté. */
        $donnees = $this->assainir($donnees);
        $verdict = $this->valider($donnees);

        if ($verdict !== true) {
            return $verdict;
        }

        if (get_option(self::OPTION, null) === $donnees) {
            return true;
        }

        if (!update_option(self::OPTION, $donnees, false)) {
            return new \WP_Error(
                'spiralbase_donnees_metier_ecriture',
                __('Échec de persistance des données métier — rien n\'a été enregistré.', 'spiralbase')
            );
        }

        return true;
    }

    /**
     * Données courantes, REVALIDÉES — null = jamais renseignées, non
     * conformes (signalées, jamais confondues : voir existe()) ou version
     * inconnue (jamais interprétée).
     */
    public function get(): ?array
    {
        $donnees = get_option(self::OPTION, null);

        if ($donnees === null || $donnees === false) {
            return null;
        }

        if (!is_array($donnees)) {
            $this->signaler('données corrompues en base (type ' . get_debug_type($donnees) . ')', 'spiralbase_donnees_metier_corrompues');

            return null;
        }

        if (($donnees['schema_version'] ?? null) !== self::SCHEMA_VERSION) {
            $this->signaler('schema_version inconnue — jamais interprétée', 'spiralbase_donnees_metier_version_future');

            return null;
        }

        /* Une écriture hors porte (SQL direct, plugin) ne traverse pas. */
        if ($this->valider($donnees) !== true) {
            $this->signaler('données non conformes en base — écrites hors de la porte ?', 'spiralbase_donnees_metier_corrompues');

            return null;
        }

        return $donnees;
    }

    /** Une donnée existe-t-elle dans l'option canonique (lisible ou non) ? */
    public function existe(): bool
    {
        $valeur = get_option(self::OPTION, null);

        return $valeur !== null && $valeur !== false;
    }

    /** Assainissement récursif des chaînes (sanitize_text_field) — structure intacte. */
    private function assainir(mixed $valeur): mixed
    {
        if (is_string($valeur)) {
            return sanitize_text_field($valeur);
        }

        return is_array($valeur) ? array_map([$this, 'assainir'], $valeur) : $valeur;
    }

    /** @return true|\WP_Error */
    private function valider(array $donnees): bool|\WP_Error
    {
        $inconnues = array_diff(array_keys($donnees), self::CHAMPS);

        if ($inconnues !== []) {
            return $this->refus(sprintf(__('clés inconnues : %s.', 'spiralbase'), implode(', ', array_map('strval', $inconnues))));
        }

        if (($donnees['schema_version'] ?? null) !== self::SCHEMA_VERSION) {
            return $this->refus(sprintf(__('schema_version %d attendue.', 'spiralbase'), self::SCHEMA_VERSION));
        }

        if (!is_string($donnees['nom'] ?? null) || trim((string) ($donnees['nom'] ?? '')) === '') {
            return $this->refus(__('« nom » est obligatoire (chaîne non vide).', 'spiralbase'));
        }

        foreach (self::LONGUEURS as $champ => $max) {
            if (isset($donnees[$champ]) && (!is_string($donnees[$champ]) || mb_strlen($donnees[$champ]) > $max)) {
                return $this->refus(sprintf(__('« %1$s » doit être une chaîne de %2$d caractères au plus.', 'spiralbase'), $champ, $max));
            }
        }

        if (isset($donnees['type_activite']) && $donnees['type_activite'] !== ''
            && !in_array($donnees['type_activite'], self::TYPES_ACTIVITE, true)) {
            return $this->refus(sprintf(
                __('« type_activite » inconnu (admis : %s) — une faute de frappe dégraderait le balisage en silence.', 'spiralbase'),
                implode(', ', self::TYPES_ACTIVITE)
            ));
        }

        $verdict = $this->validerHoraires($donnees) ?? $this->validerAdresse($donnees);

        return $verdict ?? true;
    }

    private function validerHoraires(array $donnees): ?\WP_Error
    {
        if (!isset($donnees['horaires'])) {
            return null;
        }

        $horaires = $donnees['horaires'];

        if (!is_array($horaires) || !array_is_list($horaires) || $horaires === [] || count($horaires) > 30
            || array_filter($horaires, static fn ($h): bool => is_string($h) && trim($h) !== '' && mb_strlen($h) <= 100) !== $horaires) {
            return $this->refus(__('« horaires » doit être une liste non vide (30 max) de chaînes non vides (100 caractères max, format schema.org openingHours).', 'spiralbase'));
        }

        return null;
    }

    private function validerAdresse(array $donnees): ?\WP_Error
    {
        if (!isset($donnees['adresse'])) {
            return null;
        }

        $adresse = $donnees['adresse'];

        if (!is_array($adresse) || $adresse === []
            || array_diff(array_keys($adresse), self::CHAMPS_ADRESSE) !== []
            || array_filter($adresse, static fn ($v): bool => is_string($v) && mb_strlen($v) <= 200) !== $adresse
            || array_filter($adresse, static fn (string $v): bool => trim($v) !== '') === []) {
            return $this->refus(__('« adresse » doit être une map {rue, code_postal, ville} non vide, valeurs chaînes de 200 caractères au plus, au moins une renseignée.', 'spiralbase'));
        }

        return null;
    }

    private function refus(string $detail): \WP_Error
    {
        return new \WP_Error(self::CODE_INVALIDE, sprintf(
            /* translators: %s : détail du refus de validation. */
            __('Données métier invalides : %s', 'spiralbase'),
            $detail
        ));
    }

    /** Signal borné à UNE émission par requête et par hook (anti-amplification wp_head). */
    private function signaler(string $message, string $hook): void
    {
        if (isset(self::$signale[$hook])) {
            return;
        }

        self::$signale[$hook] = true;
        do_action($hook, $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] données métier : ' . $message . '.');
        }
    }

    /** Réservé aux tests : réarme les signaux entre deux requêtes simulées. */
    public static function reinitialiserSignaux(): void
    {
        self::$signale = [];
    }
}
