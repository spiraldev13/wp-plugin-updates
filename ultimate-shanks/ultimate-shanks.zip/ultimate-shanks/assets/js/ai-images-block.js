/**
 * Ultimate Shanks - Bloc Gutenberg « Image IA »
 *
 * Bloc à insérer n'importe où dans le contenu : prompt, format, modèle et
 * bouton Générer avec coût estimé. Après génération, le bloc se remplace par
 * un bloc image natif (core/image) — aucun bloc propriétaire ne subsiste dans
 * le contenu enregistré (save renvoie null tant que rien n'est généré).
 *
 * Écrit sans étape de build : wp.element.createElement, pas de JSX.
 */
(function (wp, $) {
	'use strict';

	if (!wp || !wp.blocks) {
		return;
	}

	var config = window.ultimateShanksAiImagesBlock || {};
	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var registerBlockType = wp.blocks.registerBlockType;
	var createBlock = wp.blocks.createBlock;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var TextareaControl = wp.components.TextareaControl;
	var SelectControl = wp.components.SelectControl;
	var Button = wp.components.Button;
	var Spinner = wp.components.Spinner;

	function modelOptions() {
		var options = [];
		Object.keys(config.models || {}).forEach(function (endpoint) {
			options.push({ value: endpoint, label: config.models[endpoint].label });
		});
		return options;
	}

	function ratioOptions() {
		return (config.ratios || []).map(function (ratio) {
			return { value: ratio, label: ratio };
		});
	}

	function costText(model) {
		var info = (config.models || {})[model];
		if (!info || info.price === null || info.price === undefined) {
			return config.strings.costUnknown;
		}
		var price = info.price.toFixed(3).replace(/0+$/, '').replace(/\.$/, '.0');
		return config.strings.costLabel.replace('%s', price);
	}

	function EditComponent(props) {
		var attributes = props.attributes;
		var setAttributes = props.setAttributes;
		var stateBusy = useState(false);
		var busy = stateBusy[0];
		var setBusy = stateBusy[1];
		var stateError = useState('');
		var errorMessage = stateError[0];
		var setError = stateError[1];

		var model = attributes.model || config.defaultModel;
		var ratio = attributes.ratio || config.defaultRatio;

		function onGenerate() {
			var postId = wp.data.select('core/editor').getCurrentPostId();

			setBusy(true);
			setError('');

			$.post(config.ajaxurl, {
				action: 'ultimate_shanks_ai_generate_image',
				nonce: config.nonce,
				post_id: postId,
				prompt: attributes.prompt || '',
				aspect_ratio: ratio,
				target: 'library',
				model: model
			}).done(function (response) {
				if (!response.success) {
					setBusy(false);
					setError((response.data && response.data.message) || config.strings.error);
					return;
				}
				var data = response.data;
				// Remplace ce bloc par un bloc image natif
				wp.data.dispatch('core/block-editor').replaceBlocks(
					props.clientId,
					createBlock('core/image', {
						id: data.attachment_id,
						url: data.url,
						alt: data.alt,
						sizeSlug: 'large'
					})
				);
			}).fail(function (jqXHR) {
				setBusy(false);
				// Les erreurs métier arrivent en HTTP 4xx/5xx avec un JSON détaillé
				var json = jqXHR && jqXHR.responseJSON;
				setError((json && json.data && json.data.message) || config.strings.error);
			});
		}

		return el(
			'div',
			useBlockProps({ style: { border: '1px dashed #949494', borderRadius: '4px', padding: '16px' } }),
			el('p', { style: { fontWeight: 600, margin: '0 0 8px' } }, 'Image IA'),
			el(TextareaControl, {
				label: 'Prompt',
				value: attributes.prompt || '',
				placeholder: 'Description de l\'image à générer (vide = titre du contenu)',
				onChange: function (value) { setAttributes({ prompt: value }); }
			}),
			el(SelectControl, {
				label: 'Format',
				value: ratio,
				options: ratioOptions(),
				onChange: function (value) { setAttributes({ ratio: value }); }
			}),
			el(SelectControl, {
				label: 'Modèle',
				value: model,
				options: modelOptions(),
				onChange: function (value) { setAttributes({ model: value }); }
			}),
			el('p', { className: 'description', style: { margin: '4px 0 8px' } }, costText(model)),
			el(
				Button,
				{ variant: 'primary', disabled: busy, onClick: onGenerate },
				busy ? config.strings.generating : 'Générer l\'image'
			),
			busy ? el(Spinner, null) : null,
			errorMessage ? el('p', { style: { color: '#b32d2e', margin: '8px 0 0' } }, errorMessage) : null
		);
	}

	registerBlockType('ultimate-shanks/ai-image', {
		title: 'Image IA',
		description: 'Génère une image par IA à cet emplacement, puis se transforme en bloc image natif.',
		icon: 'format-image',
		category: 'media',
		attributes: {
			prompt: { type: 'string', default: '' },
			ratio: { type: 'string', default: '' },
			model: { type: 'string', default: '' }
		},
		edit: EditComponent,
		save: function () {
			// Rien n'est enregistré : le bloc est un outil d'éditeur qui se
			// remplace par un core/image une fois l'image générée
			return null;
		}
	});
})(window.wp, window.jQuery);
