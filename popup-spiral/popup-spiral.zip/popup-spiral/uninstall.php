<?php
/**
 * Désinstallation de Popup Spiral.
 *
 * Les données ne sont supprimées que si l'utilisateur a explicitement
 * coché « supprimer les données à la désinstallation » (désactivé par défaut).
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Toujours : retirer la tâche planifiée d'auto-désactivation (par slug de hook,
// l'autoloader du plugin n'étant pas chargé pendant la désinstallation).
wp_clear_scheduled_hook('spiral_auto_disable_expired');

if (!get_option('spiral_delete_on_uninstall')) {
    return;
}

$spiralPopups = get_posts([
    'post_type' => 'spiral_popup',
    'post_status' => 'any',
    'numberposts' => -1,
    'fields' => 'ids',
]);

foreach ($spiralPopups as $spiralPopupId) {
    wp_delete_post($spiralPopupId, true);
}

delete_option('spiral_saved_designs');
delete_option('spiral_designs_css');
delete_option('spiral_size_presets');
delete_option('spiral_delete_on_uninstall');
delete_option('spiral_config_presets');
delete_option('spiral_auto_disable_expired');
delete_option('spiral_db_version');
delete_option('spiral_stats_since');

// Table de statistiques journalières.
global $wpdb;
$wpdb->query('DROP TABLE IF EXISTS ' . $wpdb->prefix . 'spiral_stats');
