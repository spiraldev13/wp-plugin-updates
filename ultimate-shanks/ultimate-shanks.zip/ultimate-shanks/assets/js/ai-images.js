/**
 * Ultimate Shanks - Images IA (metabox éditeur + bouton colonne)
 *
 * Metabox : lance la génération en AJAX ; si la destination est « contenu »,
 * insère le bloc image directement dans l'état de l'éditeur (Gutenberg) —
 * le serveur ne modifie jamais le post pendant que l'éditeur est ouvert.
 * Affiche le coût estimé du modèle sélectionné avant toute génération.
 * Colonne : génération d'image à la une depuis la liste des articles,
 * précédée d'une confirmation avec le coût estimé.
 */
(function ($) {
	'use strict';

	var config = window.ultimateShanksAiImages || {};

	function modelPrice(model) {
		var info = (config.models || {})[model];
		return info && info.price !== null && info.price !== undefined ? info.price : null;
	}

	function formatPrice(price) {
		return price.toFixed(3).replace(/0+$/, '').replace(/\.$/, '.0');
	}

	function costText(model) {
		var price = modelPrice(model);
		if (price === null) {
			return config.strings.costUnknown;
		}
		return config.strings.costLabel.replace('%s', formatPrice(price));
	}

	function currentTitle() {
		// Gutenberg : titre en cours d'édition ; sinon éditeur classique
		if (window.wp && wp.data && wp.data.select('core/editor')) {
			var title = wp.data.select('core/editor').getEditedPostAttribute('title');
			if (title) {
				return title;
			}
		}
		var $title = $('#title');
		return $title.length ? $title.val() : '';
	}

	function insertImageBlock(attachmentId, url, alt) {
		if (window.wp && wp.data && wp.blocks && wp.data.dispatch('core/block-editor')) {
			var block = wp.blocks.createBlock('core/image', {
				id: attachmentId,
				url: url,
				alt: alt,
				sizeSlug: 'large'
			});
			wp.data.dispatch('core/block-editor').insertBlocks(block, 0);
			return;
		}
		// Éditeur classique : préfixe le textarea de contenu
		var $content = $('#content');
		if ($content.length) {
			var html = '<figure class="wp-block-image size-large"><img src="' + url
				+ '" alt="' + alt + '" class="wp-image-' + attachmentId + '"/></figure>\n\n';
			$content.val(html + $content.val());
		}
	}

	function generate(postId, prompt, ratio, target, model, done) {
		$.post(config.ajaxurl, {
			action: 'ultimate_shanks_ai_generate_image',
			nonce: config.nonce,
			post_id: postId,
			prompt: prompt,
			aspect_ratio: ratio,
			target: target,
			model: model
		}).done(function (response) {
			done(null, response);
		}).fail(function (jqXHR) {
			// Les erreurs métier arrivent en HTTP 4xx/5xx avec un JSON détaillé
			var json = jqXHR && jqXHR.responseJSON;
			var message = (json && json.data && json.data.message) || config.strings.error;
			done(message);
		});
	}

	// --- Metabox éditeur ---
	$(function () {
		var $cost = $('#us_ai_cost');
		if ($cost.length) {
			$cost.text(costText($('#us_ai_model').val()));
		}
	});

	$(document).on('change', '#us_ai_model', function () {
		$('#us_ai_cost').text(costText($(this).val()));
	});

	$(document).on('click', '#us_ai_use_title', function () {
		$('#us_ai_prompt').val(currentTitle());
	});

	$(document).on('click', '#us_ai_generate', function () {
		var $button = $(this);
		var $spinner = $('#us_ai_spinner');
		var $result = $('#us_ai_result');
		var target = $('#us_ai_target').val();

		$button.prop('disabled', true);
		$spinner.addClass('is-active');
		$result.html('<p>' + config.strings.generating + '</p>');

		generate(
			$button.data('post-id'),
			$('#us_ai_prompt').val(),
			$('#us_ai_ratio').val(),
			target,
			$('#us_ai_model').val(),
			function (error, response) {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');

				if (error || !response.success) {
					var message = error || (response.data && response.data.message) || config.strings.error;
					$result.html('<p style="color:#b32d2e;">' + message + '</p>');
					return;
				}

				var data = response.data;
				if (data.target === 'content') {
					insertImageBlock(data.attachment_id, data.url, data.alt);
					$result.html('<p>' + data.message + ' Image insérée : pensez à enregistrer.</p>');
				} else {
					$result.html('<p>' + data.message + '</p>');
				}
				$result.append('<img src="' + data.url + '" style="max-width:100%;height:auto;" alt="">');

				// Rafraîchit la vignette « Image à la une » de l'éditeur Gutenberg
				if (data.target === 'featured' && window.wp && wp.data && wp.data.dispatch('core/editor')) {
					wp.data.dispatch('core/editor').editPost({ featured_media: data.attachment_id });
				}
			}
		);
	});

	// --- Bouton de la colonne « Image à la une » ---
	$(document).on('click', '.us-ai-generate-btn', function () {
		var $button = $(this);
		var price = modelPrice(config.defaultModel);
		var confirmation = config.strings.confirmCost.replace('%s', price === null ? '?' : formatPrice(price));

		if (!window.confirm(confirmation)) {
			return;
		}

		$button.prop('disabled', true).text(config.strings.generating);

		generate($button.data('post-id'), '', '', 'featured', '', function (error, response) {
			if (error || !response.success) {
				var message = error || (response.data && response.data.message) || config.strings.error;
				alert(message);
				$button.prop('disabled', false).text('Générer par IA');
				return;
			}
			location.reload();
		});
	});
})(jQuery);
