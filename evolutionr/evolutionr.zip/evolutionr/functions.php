<?php
/**
 * Bootstrap du thème Evolution'R.
 *
 * Charge les modules : assets Vite, supports, enqueue, nettoyage, walkers,
 * CPT, taxonomies, ACF (garde-fou + options + local JSON).
 */

if (!defined('ABSPATH')) {
    exit;
}

$themeIncludes = [
    'config-viteJs',
    'theme-support',
    'theme-clean',
    'theme-option',
    'walker',
    'helpers',
    'cpt',
    'admin-realisation-order',
    'taxonomies',
    'acf-guard',
    'acf-config',
    'acf-options',
    'acf-location-rules',
    'acf-fields',
    'pricing',
    'seed-content',
];

foreach ($themeIncludes as $module) {
    $path = get_template_directory() . "/inc/{$module}.php";
    if (file_exists($path)) {
        require_once $path;
    }
}
