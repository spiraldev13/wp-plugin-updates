---
stepsCompleted: [1, 2, 3, 4]
inputDocuments: []
session_topic: "Plugin WordPress d'affiliation produits multi-plateformes avec affichages modulaires"
session_goals: "Générer des idées sur (a) plateformes d'affiliation à intégrer, (b) types d'affichage possibles, (c) fonctionnalités différenciantes, (d) cas d'usage utilisateurs"
selected_approach: 'user-selected'
techniques_used: ['SCAMPER Method', 'Mind Mapping', 'Solution Matrix', 'Decision Tree Mapping']
ideas_generated: 45
context_file: ''
session_active: false
workflow_completed: true
---

# Brainstorming Session Results

**Facilitator:** Cyril
**Date:** 2026-04-24

## Session Overview

**Topic:** Plugin WordPress d'affiliation produits multi-plateformes avec affichages modulaires

**Goals:** Générer un maximum d'idées sur :
- Les plateformes d'affiliation à intégrer (Amazon Partners, Awin, CJ, Impact, Rakuten, etc.)
- Les types d'affichage possibles (grille, liste, carrousel, comparateur, etc.)
- Les fonctionnalités différenciantes vs la concurrence
- Les cas d'usage et personas utilisateurs

### Session Setup

- **Approche choisie :** [1] Techniques choisies par l'utilisateur
- **Mindset :** Mode exploration générative — viser 100+ idées avant organisation
- **Anti-biais :** Pivot de domaine tous les 10 idées (technique → UX → business → edge cases)

## Technique Selection

**Approach:** User-Selected Techniques (Catégorie : Pensée Structurée)

**Selected Techniques:**

- **SCAMPER Method** — Génération large via 7 lentilles (Substituer, Combiner, Adapter, Modifier, Puiser, Éliminer, Renverser)
- **Mind Mapping** — Cartographie visuelle de l'univers du plugin, connexions entre branches
- **Decision Tree Mapping** — Chemins UX de choix d'affichage selon contexte et type de produit
- **Solution Matrix** — Grille croisant plateformes × types d'affichage × cas d'usage

**Selection Rationale:** Combinaison structurée qui alterne divergence (SCAMPER), organisation visuelle (Mind Map), logique de choix (Decision Tree) et exploration combinatoire (Solution Matrix). Alignée avec un sujet qui a de multiples dimensions croisées.

**Ordre d'exécution prévu :** SCAMPER → Mind Mapping → Solution Matrix → Decision Tree

---

## Contraintes & Principes Directeurs

### Contraintes externes (non-négociables)

1. **Pas d'accès aux API officielles** des plateformes d'affiliation tant que les critères ne sont pas remplis → import manuel ou OpenGraph scraping en MVP
2. **Les tags d'affiliation** (`tag=`, `awinaffid=`, etc.) **doivent impérativement** être préservés et garantis dans les URLs sortantes pour que les commissions soient comptées
3. **Plugin universel** : destiné à tous les sites de Cyril, toutes thématiques (pas spécialisé)

### Principes directeurs

1. **Setup rapide** — pas de config interminable
2. **Très visuel** — show, don't tell
3. **Choix de templates rapide** — gallery/picker
4. **Intégration facile** dans pages/articles (Gutenberg)
5. **Réutilisation des produits configurés** — bibliothèque centrale
6. **Ajout texte + photos facile et rapide**
7. **Simple ET sécurisé**
8. **MVP rapide** → enrichissement itératif
9. **Léger, code factorisé, propre**

### Décisions d'architecture

- **Option C retenue** : CPT `aff_product` (stockage natif WP) + admin 100% custom React (interface)
- **Aucune dépendance** API payante/restreinte au MVP
- **Focus strict affiliation pure** — pas d'élargissement à portfolio/CTAs/sponsored (rejeté)

---

## Technique Execution Results

### Technique 1 — SCAMPER Method

**S — Substituer** : remplacer "1 produit = 1 lien shortcode" par un système générique réutilisable

- **S#1 Catalogue-Pivot** — CPT central `aff_product`, 1 produit = 1 entrée réutilisable partout
- **S#2 Bloc Gutenberg unique** — un seul bloc natif avec 3 actions (Rechercher / Créer / Choisir template)
- **S#3 Template-First workflow** — choix du template en premier, les champs requis s'adaptent
- **S#4 Média drag-drop** — photo collée directement dans le template = produit créé

**C — Combiner** : fusions inédites qui créent de la valeur

- **C#1 Multi-plateformes par produit** — 1 produit = N liens affiliés, template "comparateur" choisit automatiquement
- **C#2 Bloc affilié inline** — blocs produit mini compact fluides entre paragraphes
- **C#3-bis Import multi-source pragmatique** — 3 modes : manuel / coller URL + OpenGraph / API officielle (V2)
- **C#4 Packs de page pré-assemblés** — templates combinables en structures complètes ("Top 5 comparatif" inséré en 1 clic)
- **C#5 Proxy + tracker intégré** — URLs internes `/go/xxx` → compteur + redirection, esthétique, contrôle, tracking
- **C#6 Template URL + tag global** — profils plateformes avec tag saisi 1 seule fois, URL construite à la volée

**A — Adapter** : patterns empruntés à d'autres univers

- **A#2 Skeleton loaders** — placeholders flouté style Netflix → sensation de vitesse
- **A#5 Split-view éditeur live-preview** — formulaire à gauche, preview live à droite (style VS Code/Notion)
- **A#6 Bento modular layout** — composition libre (1 hero + 4 cards) style Apple
- **A#7 Dashboard de perf** — graphiques simples style Stripe/Plausible (clics, top 5, tendance)

**M — Modifier** : amplification/atténuation

- **M#3 Programmation saisonnière** — dates début/fin d'affichage, plus de fiches zombies
- **M#4-MVP Anti click-fraud + validation URL** — rate-limiting `/go/` + allowlist de domaines

**É — Éliminer** : suppression pour la vitesse et la clarté

- **É#2 Plugin autosuffisant** — remplace Pretty Links, ACF, besoin de plugin cache/analytics
- **É#3 Champs minimum par défaut** — 3 obligatoires (nom / plateforme+URL / image), reste replié, **champs varient selon le template choisi** (nuance importante)
- **É#4 Doc intégrée dans l'interface** — tooltips contextuels + visite guidée rejouable

**R — Renverser** : inversions de patterns habituels

- **R#1 Front statique pré-généré + cache** — 99% des requêtes front ne touchent pas la DB, invalidation auto à l'édition (contrainte critique)
- **R#2 Mobile-first par défaut** — 70%+ du trafic affilié est mobile
- **R#3 Bulk-first natif** — sélection multiple + actions groupées dès le MVP
- **R#4 Plugin s'adapte au thème** — détection auto des couleurs/typo du thème actif

---

### Technique 2 — Mind Mapping

**Branche Plateformes** (12 profils préinstallés MVP)

- **MM#1 Architecture Platform Profiles** — un système générique + profils préinstallés + création custom par l'utilisateur
- **Groupe A — Généralistes** : Amazon, Awin, Rakuten, CJ Affiliate, Custom (fallback universel)
- **Groupe B — Françaises** : Affilae, Effinity
- **Groupe C — Voyage & expériences** : Viator, Tiqets, Musement, GetYourGuide, Headout
- **Mode unique : direct** (pas de variantes via agrégateur — rejeté)

**Branche Templates** (taxonomie complète, 16 candidats)

| Catégorie | Templates candidats |
|---|---|
| Atomiques | Card standard, Card compacte inline, Bouton CTA, Hero massif, Badge minimaliste |
| Listes | Grille multi-colonnes, Liste verticale, Carrousel, Bento grid |
| Comparatifs | Tableau classique, Top 5/10, Face-à-face, Pros/Cons |
| Spéciaux | Sticky bar mobile, Modal scroll, Mini-widget sidebar |

---

### Technique 3 — Solution Matrix

Croisement **Templates × Contextes d'usage** (9 contextes : blog test produit, top, comparatif, long-form, landing, catalogue, sidebar, fin d'article, mobile)

**Verdict : 6 templates MVP** (couvrent ~90% des contextes)

1. **Card standard** — couteau suisse
2. **Card compacte inline** — killer long-form + mobile
3. **Bouton CTA** — landing + mobile
4. **Grille multi-colonnes** — catalogue + fin d'article
5. **Top 5/10 numéroté** — SEO classique
6. **Tableau Pros/Cons** — seul template adapté aux comparatifs

**10 templates → V2** (Hero, Badge, Liste verticale, Carrousel, Bento, Face-à-face, Sticky bar, Modal, Widget sidebar)

**Insights révélés** :
- Mobile = Card inline + CTA + Sticky bar dominent
- Seul template "vraiment comparatif" = Pros/Cons → MVP non-négociable

---

### Technique 4 — Decision Tree Mapping

**Arbre 1 — Créer un produit** : 2 étapes, ~20 secondes (choix plateforme → formulaire split-view avec preview live)

**Arbre 2 — Insérer dans un article** : bloc Gutenberg unique avec 3 actions (Rechercher existant / Créer rapide / Template-first)

**Arbre 3 — Premier lancement** : pas de wizard long, juste "Configurer mes plateformes" puis prêt

**Arbre 4 — Système de Design** (ajout stratégique de Cyril)

- **DT#1 État "Inactif" si tag manquant** — validation UX qui protège le revenu
- **DT#2 Design Tokens globaux** — palette, typo, espacements, hover → tous les templates consomment les mêmes CSS variables
- **DT#3-lite Bibliothèque de boutons sauvegardés** — composants réutilisables (full version en V2 : badges, prix, cards)
- **DT#4 Preview live multi-template** — vue d'ensemble des 6 templates desktop/mobile avec mise à jour temps réel
- **DT#5 Thème adaptatif avec override** — détection auto + possibilité de tout surcharger

---

## Idea Organization and Prioritization

### Organisation thématique

#### Thème 1 — Fondations architecturales (socle)

Base technique sur laquelle tout repose.

- Option C (CPT + admin React)
- S#1 Catalogue-Pivot, S#2 Bloc Gutenberg unique
- MM#1 Platform Profiles générique + 12 préinstallés + création custom
- R#1 Front statique + cache + invalidation à l'édition

#### Thème 2 — Système de liens affiliés (cœur métier)

Tout ce qui touche au lien, à son tracking et à la commission.

- C#5 Proxy `/go/xxx` + compteur de clics
- C#6 Template URL + tag global (1 seule saisie)
- DT#1 État "Inactif" si tag manquant

#### Thème 3 — Workflow de création (UX admin)

Parcours d'édition, le confort quotidien.

- S#3 Template-First, S#4 Média drag-drop
- É#3 Champs minimum + panneau avancé (champs selon template)
- A#5 Split-view éditeur live-preview
- R#3 Bulk-first (actions groupées)

#### Thème 4 — Templates d'affichage (cœur visuel)

Les 6 templates MVP et leur personnalisation.

- 6 templates MVP : Card std, Card inline, CTA, Grille, Top 5, Pros/Cons
- C#2 Bloc affilié inline (fluide dans le texte)
- C#4 Packs de page pré-assemblés
- A#6 Bento modular (en V2 ou template avancé)

#### Thème 5 — Système de design (personnalisation visuelle)

Les couleurs, typo, composants réutilisables.

- DT#2 Design Tokens globaux
- DT#3-lite Bibliothèque de boutons sauvegardés (MVP)
- DT#4 Preview live multi-template
- DT#5 Thème adaptatif + override
- R#4 Détection thème actif

#### Thème 6 — Performance & Mobile

- R#1 Cache pré-généré avec invalidation
- R#2 Mobile-first par défaut
- A#2 Skeleton loaders

#### Thème 7 — Autonomie & Simplicité

- É#2 Plugin autosuffisant
- É#4 Doc intégrée (tooltips + visite guidée)
- Arbre 3 Onboarding ultra-simple (config plateformes puis go)

#### Thème 8 — Sécurité & Intégrité

- M#4-MVP Anti click-fraud + validation URL
- Base WP (nonces, capabilities, sanitization)

#### Thème 9 — Data & Décision

- A#7 Dashboard de perf
- Tracker C#5 (data source)

#### Thème 10 — Contenu dynamique

- M#3 Programmation saisonnière (dates début/fin)
- C#3-bis Import multi-source (manuel + OpenGraph)

### Idées reportées en V2

- **C#3 AI auto-fill avancé** (nécessite API)
- **A#4 A/B test templates** (attend du trafic pour être utile)
- **A#8 Export multi-canal** (Linktree-like)
- **SM#1 Suggestion automatique de template** selon contexte
- **DT#3 full** (bibliothèque complète : badges, prix, cards en plus des boutons)
- **Import/export de profils JSON**
- **10 templates secondaires** : Hero massif, Badge minimaliste, Liste verticale, Carrousel, Bento modular full, Face-à-face, Sticky bar, Modal, Widget sidebar

---

## Action Planning — Roadmap MVP par phases

### Phase 1 — Fondations (Sprint 1-2)

**Objectif** : poser le socle technique

- [ ] Déclaration CPT `aff_product` (hidden admin menu, `show_in_menu => false`)
- [ ] Architecture Platform Profiles + 12 profils préinstallés
- [ ] Page admin parente "Affiliate Studio" (React app)
- [ ] Router admin React + bootstrap
- [ ] Endpoint REST `/wp-json/aff/v1/*` + utilisation REST API auto du CPT
- [ ] Table/option pour stocker les tags d'affiliation par plateforme
- [ ] Base de sécurité : nonces, capabilities, sanitization wrappers

**Sortie** : un admin vide mais fonctionnel, architecture prête à être habillée.

### Phase 2 — Cœur métier : liens & tracking (Sprint 3)

**Objectif** : la chaîne lien → tag → tracking fonctionne de bout en bout

- [ ] Endpoint proxy `/go/{slug}` avec redirection 301/302
- [ ] Compteur de clics en postmeta + table optionnelle `wp_aff_clicks` (IP/UA hashés)
- [ ] Construction dynamique d'URL depuis Platform Profile + tag global
- [ ] Rate-limiting anti click-fraud
- [ ] Validation stricte d'URL (allowlist domaines)
- [ ] DT#1 État "Inactif" si tag plateforme manquant

**Sortie** : un produit test génère un lien avec tag, redirige correctement, compte le clic.

### Phase 3 — UX de création (Sprint 4)

**Objectif** : créer un produit en 20 secondes

- [ ] Formulaire de création en 2 étapes (choix plateforme → remplir)
- [ ] Split-view : formulaire gauche + preview live droite
- [ ] Champs minimum obligatoires (3), panneau "Avancé" replié
- [ ] Upload image drag-drop via Media Library WP
- [ ] Bouton "Tester le lien" (ouvre l'URL construite)
- [ ] Actions bulk (sélection multiple, édit groupé)

**Sortie** : workflow de création fluide, mobile-friendly.

### Phase 4 — Système de design (Sprint 5)

**Objectif** : cohérence visuelle et personnalisation

- [ ] Settings > Design avec 3 onglets (Tokens, Composants, Preview)
- [ ] Design Tokens (palette, typo, espacements, hover) avec CSS variables
- [ ] Détection auto du thème actif (pré-remplissage des tokens)
- [ ] Bibliothèque de boutons sauvegardés (DT#3-lite)
- [ ] Preview live multi-template (vue des 6 templates en grille)

**Sortie** : l'utilisateur peut personnaliser et voir le résultat avant d'insérer.

### Phase 5 — Templates (Sprint 6-7)

**Objectif** : les 6 templates MVP fonctionnels

- [ ] Template Card standard
- [ ] Template Card compacte inline
- [ ] Template Bouton CTA
- [ ] Template Grille multi-colonnes
- [ ] Template Top 5/10 numéroté
- [ ] Template Tableau Pros/Cons
- [ ] Chaque template expose ses champs spécifiques (É#3 nuance)
- [ ] Skeleton loaders (A#2)
- [ ] Mobile-first responsive pour chaque template
- [ ] Cache transient par template + invalidation à l'édition

**Sortie** : 6 rendus front finalisés, performants, responsive.

### Phase 6 — Bloc Gutenberg & insertion (Sprint 8)

**Objectif** : insérer en 2 clics dans un article

- [ ] Bloc Gutenberg unique "Affiliate"
- [ ] 3 actions dans le bloc : Rechercher / Créer rapide / Template-first
- [ ] Autocomplétion des produits
- [ ] Galerie des 6 templates avec preview

**Sortie** : l'éditeur peut insérer un produit existant ou créer rapide.

### Phase 7 — Data & polish (Sprint 9)

**Objectif** : visibilité et finition

- [ ] Dashboard de perf (A#7)
- [ ] Programmation saisonnière (M#3)
- [ ] Import multi-source : OpenGraph scraping fallback (C#3-bis)
- [ ] Packs de page pré-assemblés (C#4)
- [ ] Tooltips contextuels + visite guidée (É#4)
- [ ] Onboarding simplifié (Arbre 3)

**Sortie** : MVP complet et publiable.

### Phase 8 — V2 (plus tard)

Tous les reports listés en "Idées reportées en V2" ci-dessus. Priorité à juger après retour d'usage du MVP.

---

## Session Summary and Insights

### Key Achievements

- **45 idées générées** en ~1h de facilitation sur 4 techniques
- **9 principes directeurs** identifiés, non-négociables
- **3 décisions d'architecture structurantes** (Option C, no-API, focus pur)
- **12 plateformes préinstallées** sélectionnées stratégiquement
- **6 templates MVP verrouillés** via méthode objective (Solution Matrix)
- **4 parcours UX cartographiés** via Decision Tree
- **Roadmap MVP en 7 phases** actionnable

### Creative Breakthroughs

1. **Architecture Platform Profiles (MM#1)** — déclassent la concurrence sur l'extensibilité sans coût de dev linéaire
2. **Système Proxy + Tag global (C#5 + C#6)** — combine tracking, contrôle et esthétique en un seul pattern
3. **Template-First workflow (S#3)** — inversion de la logique classique "data puis affichage"
4. **Design Tokens + Détection thème (DT#2 + R#4)** — cohérence visuelle sans config manuelle
5. **Split-view live-preview (A#5)** — feature killer pour l'UX d'édition quotidienne

### Session Reflections

**Ce qui a bien fonctionné** :
- La rigueur de Cyril à dire "non" ou à reporter en V2 a permis de garder un scope MVP serré (évite le scope creep classique)
- L'ajout spontané de principes (universel, code factorisé, design personnalisable) a enrichi le cadre au fur et à mesure
- Les 4 techniques se sont complétées : SCAMPER a généré large, Mind Map a structuré, Matrix a priorisé, Decision Tree a finalisé l'UX

**Insights facilitation** :
- La combinaison "proposer 4 amorces puis demander validation/rejet/extension" a maintenu un rythme rapide sans sacrifier la génération
- Le passage à Solution Matrix a été décisif pour éviter un MVP avec 16 templates — priorisation objective plutôt qu'intuitive
- Le Decision Tree a révélé UN trou majeur (système de design) que Cyril a lui-même identifié → preuve que la facilitation a bien fonctionné

### Next Steps concrets

1. **Cette semaine** : valider/affiner la roadmap par phases avec les artefacts BMad (PRD, architecture, epics)
2. **Prochaine session** : passer en mode `bmad-create-prd` ou `bmad-create-architecture` pour transformer ces idées en specs implémentables
3. **Avant code** : décider de la stack front (React 18 + `@wordpress/components` + `@wordpress/data` proposé) et du build (Webpack via `@wordpress/scripts`)
4. **Pendant code** : revenir à ce document comme source de vérité des décisions produit
