/**
 * Bloc spiralbase/encart-evenement — JS éditeur écrit à la main, SANS build (AD-12).
 *
 * `save()` rend `InnerBlocks.Content` : un bloc à enfants dont le save rend
 * null ne sérialise pas ses éléments (clause AD-12 établie en 3.2).
 *
 * L'éditeur MONTRE l'expiration, il ne la subit pas : quand la date est
 * passée, un avertissement s'affiche au-dessus du bloc et le contenu reste
 * parfaitement éditable — le cacher ici empêcherait de le corriger, alors que
 * c'est précisément le moment où l'opérateur veut le faire.
 */
( function ( blocks, element, blockEditor, components, i18n, date ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    /* Même vocabulaire que le rendu serveur : AAAA-MM-JJ, heure facultative.
       Une date sans heure vaut jusqu'à la FIN de ce jour. */
    var FORME = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?$/;

    /*
     * Les deux juges — celui-ci et `RenduEncart::limite()` — doivent rendre le
     * MÊME verdict sur la même saisie, sinon l'éditeur ment : la revue a
     * mesuré des divergences franches (« 10:60 » ⇒ le serveur effaçait
     * l'encart pendant que l'éditeur n'affichait rien ; « 0026-01-01 » ⇒ le
     * serveur l'effaçait pendant que l'éditeur promettait « reste affiché »).
     *
     * On compare donc des CHAÎNES « AAAA-MM-JJ HH:MM:SS » plutôt que des
     * instants : l'ordre lexicographique de ce format est l'ordre
     * chronologique, et cela évite d'avoir à reconstruire le fuseau du site en
     * JavaScript — `wp.date.dateI18n` le connaît déjà.
     */
    function limite( valeur ) {
        var m = typeof valeur === 'string' ? FORME.exec( valeur.trim() ) : null;

        if ( ! m ) {
            return null;
        }

        var annee = Number( m[ 1 ] );
        var mois = Number( m[ 2 ] );
        var jour = Number( m[ 3 ] );

        /* Le constructeur `Date` lit 1900+n pour une année à moins de quatre
           chiffres significatifs : le serveur refuse donc la même borne. */
        if ( annee < 1000 ) {
            return null;
        }

        var d = new Date( Date.UTC( annee, mois - 1, jour ) );

        /* `Date.UTC(2026, 12, 32)` ne lève rien, il DÉBORDE sur le mois
           suivant : sans ce contrôle, une date impossible passerait pour
           valide ici alors que le serveur la refuse. */
        if ( d.getUTCFullYear() !== annee || d.getUTCMonth() !== mois - 1 || d.getUTCDate() !== jour ) {
            return null;
        }

        var deuxChiffres = function ( n ) {
            return ( n < 10 ? '0' : '' ) + n;
        };

        if ( m[ 4 ] === undefined ) {
            /* Date nue : minuit du LENDEMAIN, comme le serveur — la borne est
               le premier instant SANS affichage, jamais le dernier avec. */
            d.setUTCDate( d.getUTCDate() + 1 );

            return d.getUTCFullYear() + '-' + deuxChiffres( d.getUTCMonth() + 1 ) + '-' + deuxChiffres( d.getUTCDate() ) + ' 00:00:00';
        }

        var heures = Number( m[ 4 ] );
        var minutes = Number( m[ 5 ] );
        var secondes = m[ 6 ] === undefined ? 0 : Number( m[ 6 ] );

        /* Bornes numériques, identiques au serveur. */
        if ( heures > 23 || minutes > 59 || secondes > 59 ) {
            return null;
        }

        return m[ 1 ] + '-' + m[ 2 ] + '-' + m[ 3 ] + ' '
            + deuxChiffres( heures ) + ':' + deuxChiffres( minutes ) + ':' + deuxChiffres( secondes );
    }

    /* L'heure du SITE, pas celle du navigateur : un opérateur en déplacement
       voyait « Événement passé » jusqu'à un jour avant ou après la réalité. */
    function maintenantAuFuseauDuSite() {
        return date && typeof date.dateI18n === 'function'
            ? date.dateI18n( 'Y-m-d H:i:s' )
            : null;
    }

    blocks.registerBlockType( 'spiralbase/encart-evenement', {
        edit: function ( props ) {
            /* `|| ''` : un attribut absent, `null` ou d'un autre type doit
               valoir « pas de date » — comme au serveur — et non déclencher
               l'avis rouge « date non comprise ». */
            var saisie = props.attributes.expiration || '';
            var echeance = limite( saisie );
            var maintenant = maintenantAuFuseauDuSite();
            var expire = echeance !== null && maintenant !== null && maintenant >= echeance;
            var illisible = saisie !== '' && echeance === null;

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-encart-evenement' + ( expire ? ' spiralbase-encart-evenement--expire' : '' ),
            } );

            var innerProps = blockEditor.useInnerBlocksProps( blockProps, {
                template: [ [ 'core/heading', { level: 3 } ], [ 'core/paragraph' ] ],
            } );

            var avis = null;

            if ( expire ) {
                avis = e(
                    components.Notice,
                    { status: 'warning', isDismissible: false },
                    __( 'Événement passé : cet encart n’est plus affiché sur le site. Le contenu reste ici, modifiable.', 'spiralbase' )
                );
            } else if ( illisible ) {
                avis = e(
                    components.Notice,
                    { status: 'error', isDismissible: false },
                    /* La valeur fautive est CITÉE : un `input[type=date]`
                       affiche un champ vide quand sa valeur n'est pas au
                       format, et l'opérateur cherchait quoi corriger. */
                    __( 'Date de fin non comprise', 'spiralbase' ) + ' (« ' + saisie + ' ») : '
                        + __( 'l’encart reste affiché sur le site tant qu’elle n’est pas corrigée.', 'spiralbase' )
                );
            }

            return e(
                element.Fragment,
                null,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages de l’encart', 'spiralbase' ) },
                        e( components.TextControl, {
                            label: __( 'Dernier jour d’affichage', 'spiralbase' ),
                            type: 'date',
                            value: saisie,
                            help: __(
                                'Au format AAAA-MM-JJ. L’encart reste visible pendant toute cette journée, puis disparaît du site tout seul. Laisser vide pour qu’il ne disparaisse jamais.',
                                'spiralbase'
                            ),
                            onChange: function ( valeur ) {
                                props.setAttributes( { expiration: valeur } );
                            },
                        } )
                    )
                ),
                avis,
                e( 'div', innerProps )
            );
        },
        save: function () {
            return e( blockEditor.InnerBlocks.Content );
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n,
    window.wp.date
);
