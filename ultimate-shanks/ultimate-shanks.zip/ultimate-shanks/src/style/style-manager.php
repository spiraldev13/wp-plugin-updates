<?php
/**
 * Style Manager - Gestionnaire de styles dynamiques
 *
 * Ce fichier gère l'enqueue des assets et l'initialisation du Style Manager.
 * Le CSS est généré dynamiquement et sauvegardé dans generated-styles.css.
 *
 * Assets associés:
 * - CSS Front-end : /assets/css/generated-styles.css (généré dynamiquement)
 * - CSS Admin     : /assets/css/admin-settings.css (interface formulaires)
 * - JS Admin      : /assets/js/style-manager-admin.js (color pickers, sliders)
 *
 * Fichiers liés:
 * - settings.php      : Interface admin (formulaires HTML)
 * - css-generator.php : Génération du CSS dynamique
 *
 * @package UltimateShanks\Style
 */

namespace UltimateShanks\Style;

class StyleManager
{
	/**
	 * Initialise la fonctionnalité
	 */
	public static function init()
	{
		// Charger le CSS généré sur le frontend en fin de queue pour mieux résister aux resets thème.
		add_action('wp_enqueue_scripts', [self::class, 'enqueue_generated_css'], 99);
	}

	/**
	 * Charge le CSS généré sur le frontend
	 */
	public static function enqueue_generated_css()
	{
		$handle = 'ultimate-shanks-generated-styles';
		$css_file = CSSGenerator::get_css_file_path();
		$css_url = CSSGenerator::get_css_file_url();

		// Régénérer si le fichier est absent (déploiement/update) OU plus vieux que la
		// dernière sauvegarde des réglages Style : un fichier périmé peut subsister quand
		// l'écriture a échoué au moment du save (permissions).
		$updated_at = (int) get_option('ultimate_shanks_style_updated_at', 0);
		if (!file_exists($css_file) || filemtime($css_file) < $updated_at) {
			CSSGenerator::generate_css();
		}

		// Charger le fichier généré seulement s'il est disponible ET à jour.
		if (file_exists($css_file) && filemtime($css_file) >= $updated_at) {
			wp_enqueue_style(
				$handle,
				$css_url,
				[],
				filemtime($css_file) // Version basée sur la date de modification
			);
			return;
		}

		// Fallback robuste: injecter le CSS en mémoire si l'écriture fichier échoue.
		$inline_css = CSSGenerator::get_css_string();
		if (!empty($inline_css)) {
			wp_register_style($handle, false, [], null);
			wp_enqueue_style($handle);
			wp_add_inline_style($handle, $inline_css);
		}
	}
}
