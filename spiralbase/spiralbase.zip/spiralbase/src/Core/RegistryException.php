<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Erreur interne du noyau (jamais d'échec silencieux — NFR13).
 * Aux frontières WordPress (WP-CLI, REST), elle sera convertie en WP_Error
 * conformément aux conventions de la spine.
 */
final class RegistryException extends \RuntimeException
{
}
