/**
 * Popup Spiral — comportements de l'admin (vanilla).
 *
 * Onglets, champs conditionnels, copie de classe, recherche AJAX du ciblage,
 * médiathèque et aperçu live du créateur de designs.
 */
(function () {
    'use strict';

    var config = window.spiralAdmin || { ajaxUrl: '', nonce: '', i18n: {} };

    /* ---------- Onglets de la metabox ---------- */

    document.addEventListener('click', function (event) {
        var tab = event.target.closest('.spiral-tab');

        if (!tab) {
            return;
        }

        var container = tab.closest('.spiral-metabox');
        var name = tab.getAttribute('data-tab');

        container.querySelectorAll('.spiral-tab').forEach(function (button) {
            button.classList.toggle('is-active', button === tab);
        });

        container.querySelectorAll('.spiral-tab-panel').forEach(function (panel) {
            panel.classList.toggle('is-active', panel.getAttribute('data-panel') === name);
        });
    });

    /* ---------- Champs conditionnels ---------- */

    function refreshConditionals() {
        var mode = document.querySelector('.spiral-frequency-mode');

        if (mode) {
            var daysWrap = document.querySelector('.spiral-frequency-days');

            if (daysWrap) {
                daysWrap.style.display = mode.value === 'days' ? '' : 'none';
            }
        }

        var sourceChecked = document.querySelector('input[name="spiral[content_source][type]"]:checked');
        var picker = document.querySelector('.spiral-elementor-picker');

        if (sourceChecked && picker) {
            picker.hidden = sourceChecked.value !== picker.getAttribute('data-show-if');
        }

        var buttonTarget = document.querySelector('input[name="spiral[button][target]"]:checked');

        if (buttonTarget) {
            document.querySelectorAll('[data-show-target]').forEach(function (element) {
                element.hidden = element.getAttribute('data-show-target') !== buttonTarget.value;
            });
        }

        var sizeChecked = document.querySelector('input[name="spiral[display][size]"]:checked');
        var customSize = document.querySelector('.spiral-custom-size');

        if (sizeChecked && customSize) {
            customSize.hidden = sizeChecked.value !== 'custom';
        }

        var heightChecked = document.querySelector('input[name="spiral[display][height]"]:checked');
        var customHeight = document.querySelector('.spiral-custom-height');

        if (heightChecked && customHeight) {
            customHeight.hidden = heightChecked.value !== 'custom';
        }

        var padChecked = document.querySelector('input[name="spiral[display][image][padding]"]:checked');
        var customPad = document.querySelector('.spiral-custom-imgpad');

        if (padChecked && customPad) {
            customPad.hidden = padChecked.value !== 'custom';
        }

        // Champs conditionnels génériques : visibles quand le radio
        // data-when a la valeur data-value.
        document.querySelectorAll('.spiral-conditional').forEach(function (element) {
            var name = element.getAttribute('data-when');
            var checked = document.querySelector('input[name="' + name + '"]:checked');
            element.hidden = !checked || checked.value !== element.getAttribute('data-value');
        });
    }

    document.addEventListener('change', refreshConditionals);
    document.addEventListener('DOMContentLoaded', refreshConditionals);

    /* ---------- Toggle actif/inactif (liste des popups) ---------- */

    document.addEventListener('change', function (event) {
        var toggle = event.target.closest('.spiral-toggle');

        if (!toggle) {
            return;
        }

        var data = new FormData();
        data.append('action', 'spiral_toggle_popup');
        data.append('nonce', config.nonce);
        data.append('popup_id', toggle.getAttribute('data-id'));
        data.append('enabled', toggle.checked ? '1' : '0');

        window.fetch(config.ajaxUrl, { method: 'POST', body: data })
            .then(function (response) { return response.json(); })
            .then(function (payload) {
                if (!payload || !payload.success) {
                    toggle.checked = !toggle.checked;
                }
            })
            .catch(function () {
                toggle.checked = !toggle.checked;
            });
    });

    /* ---------- Boutons « Copier » ---------- */

    document.addEventListener('click', function (event) {
        var button = event.target.closest('.spiral-copy');

        if (!button || !navigator.clipboard) {
            return;
        }

        navigator.clipboard.writeText(button.getAttribute('data-copy')).then(function () {
            var original = button.textContent;
            button.textContent = config.i18n.copied || 'Copié !';
            window.setTimeout(function () {
                button.textContent = original;
            }, 1200);
        });
    });

    /* ---------- Confirmation de suppression ---------- */

    document.addEventListener('click', function (event) {
        var link = event.target.closest('.spiral-delete');

        if (link && !window.confirm(link.getAttribute('data-confirm'))) {
            event.preventDefault();
        }
    });

    /* ---------- Champ médiathèque générique (délégation : insensible au
       timing de chargement et aux re-rendus du DOM par l'éditeur de blocs) ---------- */

    function mediaNotifyChange(field) {
        var idInput = field.querySelector('.spiral-media-id');

        if (idInput) {
            idInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    document.addEventListener('click', function (event) {
        var pick = event.target.closest('.spiral-media-pick');

        if (pick && window.wp && window.wp.media) {
            event.preventDefault();

            var field = pick.closest('.spiral-media-field');

            if (!field._spiralFrame) {
                var frame = window.wp.media({
                    title: config.i18n.chooseImage || 'Choisir une image',
                    button: { text: config.i18n.useImage || 'Utiliser cette image' },
                    multiple: false,
                    library: { type: 'image' },
                });

                frame.on('select', function () {
                    var attachment = frame.state().get('selection').first().toJSON();
                    var idInput = field.querySelector('.spiral-media-id');
                    var preview = field.querySelector('.spiral-media-preview');
                    var remove = field.querySelector('.spiral-media-remove');

                    if (idInput) {
                        idInput.value = attachment.id;
                    }

                    if (preview) {
                        preview.src = (attachment.sizes && attachment.sizes.medium)
                            ? attachment.sizes.medium.url
                            : attachment.url;
                        preview.hidden = false;
                    }

                    if (remove) {
                        remove.hidden = false;
                    }

                    mediaNotifyChange(field);
                    syncFeaturedFromPanel(field, attachment.id);
                });

                field._spiralFrame = frame;
            }

            field._spiralFrame.open();
            return;
        }

        var remove = event.target.closest('.spiral-media-remove');

        if (remove) {
            event.preventDefault();

            var removeField = remove.closest('.spiral-media-field');
            var removeId = removeField.querySelector('.spiral-media-id');
            var removePreview = removeField.querySelector('.spiral-media-preview');

            if (removeId) {
                removeId.value = '0';
            }

            if (removePreview) {
                removePreview.hidden = true;
            }

            remove.hidden = true;
            mediaNotifyChange(removeField);
            syncFeaturedFromPanel(removeField, 0);
        }
    });

    /* ---------- Synchro image du panneau ↔ image mise en avant ----------
       Le serveur fait foi à l'enregistrement (Metabox::syncImage) ; ici on
       garde seulement les deux interfaces cohérentes à l'écran. */

    function syncFeaturedFromPanel(field, id) {
        if (!field.classList.contains('spiral-image-field')) {
            return;
        }

        var editor = window.wp && window.wp.data && window.wp.data.select
            ? window.wp.data.select('core/editor')
            : null;

        if (editor && window.wp.data.dispatch('core/editor')) {
            window.wp.data.dispatch('core/editor').editPost({ featured_media: id > 0 ? id : 0 });
            return;
        }

        // Éditeur classique : met à jour la box « Image mise en avant ».
        if (window.wp && window.wp.media && window.wp.media.featuredImage) {
            window.wp.media.featuredImage.set(id > 0 ? id : -1);
        }
    }

    /* Sens inverse (éditeur de blocs) : la box native met à jour le panneau.
       En éditeur classique, la synchro se fait à l'enregistrement. */
    function setupFeaturedSync() {
        var field = document.querySelector('.spiral-image-field');

        if (!field || !window.wp || !window.wp.data || !window.wp.data.select
            || !window.wp.data.select('core/editor')
        ) {
            return;
        }

        var select = window.wp.data.select('core/editor');
        var last = select.getEditedPostAttribute('featured_media') || 0;

        window.wp.data.subscribe(function () {
            var current = select.getEditedPostAttribute('featured_media') || 0;
            var idInput = field.querySelector('.spiral-media-id');

            if (current === last || !idInput || String(current) === idInput.value) {
                last = current;
                return;
            }

            last = current;
            idInput.value = String(current);
            refreshPanelPreview(field, current);
        });
    }

    function refreshPanelPreview(field, id) {
        var preview = field.querySelector('.spiral-media-preview');
        var remove = field.querySelector('.spiral-media-remove');

        if (id > 0 && window.wp && window.wp.media) {
            var attachment = window.wp.media.attachment(id);

            attachment.fetch().done(function () {
                if (preview) {
                    var sizes = attachment.get('sizes');
                    preview.src = sizes && sizes.medium ? sizes.medium.url : attachment.get('url');
                    preview.hidden = false;
                }

                if (remove) {
                    remove.hidden = false;
                }
            });
            return;
        }

        if (preview) {
            preview.hidden = true;
        }

        if (remove) {
            remove.hidden = true;
        }
    }

    /* ---------- Recherche AJAX du ciblage (chips) ---------- */

    function setupSearch(container) {
        var input = container.querySelector('.spiral-search-input');
        var results = container.querySelector('.spiral-search-results');
        var chips = container.querySelector('.spiral-search-chips');
        var type = container.getAttribute('data-type');
        var fieldName = container.getAttribute('data-name');
        var timer = null;

        function selectedIds() {
            return Array.prototype.map.call(
                chips.querySelectorAll('.spiral-chip'),
                function (chip) {
                    return chip.getAttribute('data-id');
                }
            );
        }

        function addChip(id, title) {
            if (selectedIds().indexOf(String(id)) !== -1) {
                return;
            }

            var chip = document.createElement('span');
            chip.className = 'spiral-chip';
            chip.setAttribute('data-id', id);
            chip.appendChild(document.createTextNode(title + ' '));

            var remove = document.createElement('button');
            remove.type = 'button';
            remove.className = 'spiral-chip-remove';
            remove.innerHTML = '&times;';
            chip.appendChild(remove);

            var hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = fieldName;
            hidden.value = id;
            chip.appendChild(hidden);

            chips.appendChild(chip);
        }

        function renderResults(items) {
            results.innerHTML = '';

            if (!items.length) {
                var empty = document.createElement('li');
                empty.textContent = config.i18n.noResult || 'Aucun résultat';
                results.appendChild(empty);
            }

            items.forEach(function (item) {
                var li = document.createElement('li');
                li.textContent = item.title;
                li.addEventListener('click', function () {
                    addChip(item.id, item.title);
                    results.hidden = true;
                    input.value = '';
                });
                results.appendChild(li);
            });

            results.hidden = false;
        }

        input.addEventListener('input', function () {
            window.clearTimeout(timer);

            var query = input.value.trim();

            if (query.length < 2) {
                results.hidden = true;
                return;
            }

            timer = window.setTimeout(function () {
                var url = config.ajaxUrl
                    + '?action=spiral_search_content&nonce=' + encodeURIComponent(config.nonce)
                    + '&type=' + encodeURIComponent(type)
                    + '&q=' + encodeURIComponent(query);

                window.fetch(url)
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (payload && payload.success) {
                            renderResults(payload.data);
                        }
                    });
            }, 250);
        });

        chips.addEventListener('click', function (event) {
            var remove = event.target.closest('.spiral-chip-remove');

            if (remove) {
                remove.closest('.spiral-chip').remove();
            }
        });

        document.addEventListener('click', function (event) {
            if (!container.contains(event.target)) {
                results.hidden = true;
            }
        });
    }

    /* ---------- Réglages : répéteur des tailles réutilisables ---------- */

    var presetCounter = 0;

    document.addEventListener('click', function (event) {
        var add = event.target.closest('.spiral-preset-add');

        if (add) {
            var template = document.getElementById(add.getAttribute('data-template'));
            var target = document.getElementById(add.getAttribute('data-target'));

            if (!template || !target) {
                return;
            }

            presetCounter += 1;

            var wrapper = document.createElement('div');
            // Index « n{N} » : unique dans le POST, la sanitation PHP ignore les clés.
            wrapper.innerHTML = template.innerHTML.replace(/__i__/g, 'n' + presetCounter);

            while (wrapper.firstElementChild) {
                target.appendChild(wrapper.firstElementChild);
            }

            return;
        }

        var removePreset = event.target.closest('.spiral-preset-remove');

        if (removePreset) {
            var usage = parseInt(removePreset.getAttribute('data-usage') || '0', 10);

            if (usage > 0 && !window.confirm(config.i18n.presetInUse
                || 'Cette taille est utilisée par des popups : ils reprendront la taille par défaut. Supprimer ?')) {
                return;
            }

            removePreset.closest('.spiral-preset-row').remove();
        }
    });

    function init() {
        document.querySelectorAll('.spiral-search').forEach(setupSearch);
        setupDesignEditor();
        setupFeaturedSync();
        setupPresetControls();
        setupScheduleRange();
        refreshConditionals();
    }

    /* ---------- Planification : sélecteur de plage date + heure ---------- */

    var DR_MONTHS = [
        'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
        'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'
    ];

    function drPad(n) {
        return (n < 10 ? '0' : '') + n;
    }

    // Un jour = {y, mo (1-12), d}. Aucune conversion de fuseau : on manipule
    // les composantes locales telles qu'affichées (« wall-clock » du site).
    function drParseDate(value) {
        if (!value || value.length < 10) {
            return null;
        }

        return { y: +value.slice(0, 4), mo: +value.slice(5, 7), d: +value.slice(8, 10) };
    }

    function drToday() {
        var now = new Date();
        return { y: now.getFullYear(), mo: now.getMonth() + 1, d: now.getDate() };
    }

    function drCmp(a, b) {
        return (a.y - b.y) || (a.mo - b.mo) || (a.d - b.d);
    }

    function drSame(a, b) {
        return a && b && drCmp(a, b) === 0;
    }

    function drDaysInMonth(y, mo) {
        return new Date(y, mo, 0).getDate();
    }

    function drAddDays(day, n) {
        var date = new Date(day.y, day.mo - 1, day.d + n);
        return { y: date.getFullYear(), mo: date.getMonth() + 1, d: date.getDate() };
    }

    function drFmtFr(day) {
        return drPad(day.d) + '/' + drPad(day.mo) + '/' + day.y;
    }

    // Sélecteur d'heure maison (deux menus 24 h) : lit/écrit « HH:MM ».
    function drTimeValue(ctl) {
        return ctl.querySelector('.spiral-dr-hh').getAttribute('data-value')
            + ':' + ctl.querySelector('.spiral-dr-mm').getAttribute('data-value');
    }

    function drSetUnit(unit, value) {
        unit.setAttribute('data-value', value);
        unit.querySelector('.spiral-dr-unit-btn').textContent = value;
        unit.querySelectorAll('.spiral-dr-unit-opt').forEach(function (opt) {
            var selected = opt.getAttribute('data-value') === value;
            opt.classList.toggle('is-selected', selected);
            opt.setAttribute('aria-selected', selected ? 'true' : 'false');
        });
    }

    function drSetTime(ctl, hm) {
        drSetUnit(ctl.querySelector('.spiral-dr-hh'), hm.slice(0, 2));
        drSetUnit(ctl.querySelector('.spiral-dr-mm'), hm.slice(3, 5));
    }

    // Dropdowns de temps maison : bouton + liste stylable. Renvoie closeAll().
    function setupTimeUnits(root) {
        var units = root.querySelectorAll('.spiral-dr-unit');

        function closeAll(except) {
            units.forEach(function (unit) {
                if (unit === except) { return; }
                unit.querySelector('.spiral-dr-unit-list').hidden = true;
                unit.querySelector('.spiral-dr-unit-btn').setAttribute('aria-expanded', 'false');
            });
        }

        units.forEach(function (unit) {
            var btn = unit.querySelector('.spiral-dr-unit-btn');
            var list = unit.querySelector('.spiral-dr-unit-list');

            btn.addEventListener('click', function (event) {
                event.stopPropagation();
                var willOpen = list.hidden;
                closeAll(willOpen ? unit : null);
                list.hidden = !willOpen;
                btn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

                if (willOpen) {
                    var sel = list.querySelector('.is-selected');
                    if (sel) {
                        list.scrollTop = sel.offsetTop - list.clientHeight / 2 + sel.offsetHeight / 2;
                    }
                }
            });

            list.querySelectorAll('.spiral-dr-unit-opt').forEach(function (opt) {
                opt.addEventListener('click', function (event) {
                    event.stopPropagation();
                    drSetUnit(unit, opt.getAttribute('data-value'));
                    list.hidden = true;
                    btn.setAttribute('aria-expanded', 'false');
                    // Prévient le conteneur de temps (logique d'adoption de date).
                    unit.dispatchEvent(new Event('change', { bubbles: true }));
                });
            });
        });

        document.addEventListener('click', function () { closeAll(null); });

        return closeAll;
    }

    function drAddMonth(v, delta) {
        var date = new Date(v.y, v.mo - 1 + delta, 1);
        return { y: date.getFullYear(), mo: date.getMonth() + 1 };
    }

    function setupScheduleRange() {
        var root = document.querySelector('.spiral-daterange');

        if (!root) {
            return;
        }

        var el = {
            startHidden: root.querySelector('.spiral-dr-start'),
            endHidden: root.querySelector('.spiral-dr-end'),
            trigger: root.querySelector('.spiral-dr-trigger'),
            label: root.querySelector('.spiral-dr-trigger-label'),
            overlay: root.querySelector('.spiral-dr-overlay'),
            cals: root.querySelectorAll('.spiral-dr-cal'),
            startDate: root.querySelector('.spiral-dr-start-date'),
            endDate: root.querySelector('.spiral-dr-end-date'),
            startTime: root.querySelector('.spiral-dr-start-time'),
            endTime: root.querySelector('.spiral-dr-end-time'),
            warning: root.querySelector('.spiral-schedule-warning')
        };

        var state = {
            start: drParseDate(el.startHidden.value),
            end: drParseDate(el.endHidden.value)
        };
        var view = state.start || state.end || drToday();
        view = { y: view.y, mo: view.mo };

        var closeTimeLists = setupTimeUnits(root);

        function isoOf(day, hm) {
            return day.y + '-' + drPad(day.mo) + '-' + drPad(day.d) + 'T' + hm;
        }

        function compose() {
            el.startHidden.value = state.start ? isoOf(state.start, drTimeValue(el.startTime)) : '';
            el.endHidden.value = state.end ? isoOf(state.end, drTimeValue(el.endTime)) : '';
        }

        function summary() {
            var s = state.start ? drFmtFr(state.start) + ' ' + drTimeValue(el.startTime) : '';
            var e = state.end ? drFmtFr(state.end) + ' ' + drTimeValue(el.endTime) : '';

            if (!s && !e) { return 'Permanent (toujours actif)'; }
            if (s && !e) { return 'À partir du ' + s; }
            if (!s && e) { return "Jusqu'au " + e; }
            return 'Du ' + s + ' au ' + e;
        }

        function isInverted() {
            if (!state.start || !state.end) { return false; }
            return el.startHidden.value > el.endHidden.value;
        }

        function hasRange() {
            return state.start && state.end && drCmp(state.end, state.start) > 0;
        }

        function buildDay(day, today) {
            var cell = document.createElement('button');
            cell.type = 'button';
            cell.className = 'spiral-dr-day';
            cell.textContent = day.d;

            if (drSame(day, today)) { cell.classList.add('is-today'); }

            if (drSame(day, state.start)) {
                cell.classList.add('is-start');
                cell.setAttribute('aria-pressed', 'true');
                if (hasRange()) { cell.classList.add('range-start'); }
            }

            if (drSame(day, state.end)) {
                cell.classList.add('is-end');
                cell.setAttribute('aria-pressed', 'true');
                if (hasRange()) { cell.classList.add('range-end'); }
            }

            if (state.start && state.end
                && drCmp(day, state.start) > 0 && drCmp(day, state.end) < 0) {
                cell.classList.add('in-range');
            }

            cell.addEventListener('click', function () { pickDay(day); });

            return cell;
        }

        function renderCal(calEl, y, mo) {
            calEl.querySelector('.spiral-dr-month').textContent = DR_MONTHS[mo - 1] + ' ' + y;
            var grid = calEl.querySelector('.spiral-dr-grid');
            grid.innerHTML = '';

            // Lundi = premier jour de la grille.
            var firstWeekday = (new Date(y, mo - 1, 1).getDay() + 6) % 7;
            var total = drDaysInMonth(y, mo);
            var today = drToday();

            for (var i = 0; i < firstWeekday; i++) {
                grid.appendChild(document.createElement('span'));
            }

            for (var d = 1; d <= total; d++) {
                grid.appendChild(buildDay({ y: y, mo: mo, d: d }, today));
            }
        }

        function render() {
            renderCal(el.cals[0], view.y, view.mo);
            var second = drAddMonth(view, 1);
            renderCal(el.cals[1], second.y, second.mo);

            el.startDate.textContent = state.start ? drFmtFr(state.start) : '—';
            el.endDate.textContent = state.end ? drFmtFr(state.end) : '—';
            root.classList.toggle('has-start', !!state.start);
            root.classList.toggle('has-end', !!state.end);

            el.label.textContent = summary();
            if (el.warning) { el.warning.hidden = !isInverted(); }
        }

        function commit() {
            compose();
            render();
        }

        function setStart(day) {
            state.start = day;
        }

        function setEnd(day) {
            state.end = day;
        }

        function pickDay(day) {
            var s = state.start;
            var e = state.end;

            if (s && e) {
                state.end = null;
                setStart(day);
            } else if (s && !e) {
                if (drCmp(day, s) < 0) { setStart(day); }
                else { setEnd(day); }
            } else if (!s && e) {
                if (drCmp(day, e) > 0) { setEnd(day); }
                else { setStart(day); }
            } else {
                setStart(day);
            }

            commit();
        }

        function openModal() {
            view = state.start || state.end || drToday();
            view = { y: view.y, mo: view.mo };
            el.overlay.hidden = false;
            el.trigger.setAttribute('aria-expanded', 'true');
            render();
        }

        // La modale ne se ferme que sur Valider, la croix ou Échap — jamais en
        // sélectionnant une date (sinon on ne pourrait pas choisir la plage).
        function closeModal() {
            el.overlay.hidden = true;
            el.trigger.setAttribute('aria-expanded', 'false');
        }

        el.trigger.addEventListener('click', openModal);
        root.querySelector('.spiral-dr-x').addEventListener('click', closeModal);
        root.querySelector('.spiral-dr-validate').addEventListener('click', closeModal);

        root.querySelector('.spiral-dr-prev').addEventListener('click', function () {
            view = drAddMonth(view, -1);
            render();
        });
        root.querySelector('.spiral-dr-next').addEventListener('click', function () {
            view = drAddMonth(view, 1);
            render();
        });

        // Régler une heure adopte le jour de l'autre borne si elle manque —
        // permet un créneau de quelques heures sur un même jour (ex. 00:55 → 02:00).
        el.startTime.addEventListener('change', function () {
            if (!state.start && state.end) {
                state.start = { y: state.end.y, mo: state.end.mo, d: state.end.d };
            }
            commit();
        });
        el.endTime.addEventListener('change', function () {
            if (!state.end && state.start) {
                state.end = { y: state.start.y, mo: state.start.mo, d: state.start.d };
            }
            commit();
        });

        root.querySelector('.spiral-dr-clear-start').addEventListener('click', function () {
            state.start = null;
            commit();
        });
        root.querySelector('.spiral-dr-clear-end').addEventListener('click', function () {
            state.end = null;
            commit();
        });

        root.querySelector('.spiral-dr-clear-all').addEventListener('click', function () {
            state.start = null;
            state.end = null;
            commit();
        });

        root.querySelectorAll('.spiral-dr-preset:not(.spiral-dr-clear-all)').forEach(function (button) {
            button.addEventListener('click', function () {
                applyPreset(button.getAttribute('data-preset'));
            });
        });

        function applyPreset(name) {
            var today = drToday();

            if (name === 'today') {
                setStart(today);
                view = { y: today.y, mo: today.mo };
            } else if (name === 'plus7') {
                var base = state.start || today;
                setStart(base);
                setEnd(drAddDays(base, 7));
                view = { y: base.y, mo: base.mo };
            } else if (name === 'month') {
                setStart({ y: view.y, mo: view.mo, d: 1 });
                setEnd({ y: view.y, mo: view.mo, d: drDaysInMonth(view.y, view.mo) });
                drSetTime(el.startTime, '00:00');
                drSetTime(el.endTime, '23:59');
            }

            commit();
        }

        document.addEventListener('keydown', function (event) {
            if (event.key !== 'Escape') { return; }

            // Échap ferme d'abord une liste d'heures ouverte, sinon la modale.
            if (root.querySelector('.spiral-dr-unit-list:not([hidden])')) {
                closeTimeLists(null);
                return;
            }

            if (!el.overlay.hidden) { closeModal(); }
        });

        commit();
    }

    /* ---------- Presets : appliquer / enregistrer (formulaires détachés) ---------- */

    // La metabox vit dans le formulaire d'édition du post : on ne peut pas y
    // imbriquer de <form>. On construit et soumet un formulaire détaché.
    function submitDetached(actionUrl, fields) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = actionUrl;
        form.style.display = 'none';

        Object.keys(fields).forEach(function (name) {
            var value = fields[name];
            var values = Array.isArray(value) ? value : [value];
            values.forEach(function (single) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = name;
                input.value = single;
                form.appendChild(input);
            });
        });

        document.body.appendChild(form);
        form.submit();
    }

    function setupPresetControls() {
        var root = document.querySelector('.spiral-preset-controls');

        if (!root) {
            return;
        }

        var actionUrl = root.getAttribute('data-action-url');
        var popupId = root.getAttribute('data-popup');
        var select = root.querySelector('.spiral-preset-select');
        var targetingBox = root.querySelector('.spiral-preset-section-targeting input');

        // Le ciblage n'est applicable que si le preset sélectionné l'inclut.
        function refreshTargeting() {
            if (!select || !targetingBox) {
                return;
            }

            var option = select.options[select.selectedIndex];
            var included = option && option.getAttribute('data-targeting') === '1';
            targetingBox.disabled = !included;

            if (!included) {
                targetingBox.checked = false;
            }
        }

        if (select) {
            select.addEventListener('change', refreshTargeting);
            refreshTargeting();
        }

        var applyBtn = root.querySelector('.spiral-preset-apply-btn');

        if (applyBtn) {
            applyBtn.addEventListener('click', function () {
                if (!select) {
                    return;
                }

                var sections = [];
                root.querySelectorAll('.spiral-preset-section').forEach(function (cb) {
                    if (cb.checked && !cb.disabled) {
                        sections.push(cb.value);
                    }
                });

                if (sections.length === 0) {
                    window.alert(root.getAttribute('data-alert-sections'));
                    return;
                }

                if (!window.confirm(root.getAttribute('data-confirm'))) {
                    return;
                }

                submitDetached(actionUrl, {
                    action: 'spiral_apply_preset',
                    popup_id: popupId,
                    preset: select.value,
                    'sections[]': sections,
                    _wpnonce: root.getAttribute('data-apply-nonce')
                });
            });
        }

        var saveBtn = root.querySelector('.spiral-preset-save-btn');

        if (saveBtn) {
            saveBtn.addEventListener('click', function () {
                var nameField = root.querySelector('.spiral-preset-name');
                var name = nameField ? nameField.value.trim() : '';

                if (name === '') {
                    window.alert(root.getAttribute('data-alert-name'));
                    return;
                }

                var include = root.querySelector('.spiral-preset-include-targeting');

                submitDetached(actionUrl, {
                    action: 'spiral_create_preset',
                    popup_id: popupId,
                    name: name,
                    includes_targeting: include && include.checked ? '1' : '',
                    redirect_to: root.getAttribute('data-return-url'),
                    _wpnonce: root.getAttribute('data-create-nonce')
                });
            });
        }
    }

    // Le script peut être chargé après DOMContentLoaded (éditeur de blocs).
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    /* ---------- Créateur de designs : aperçu live ---------- */

    function setupDesignEditor() {
        var form = document.getElementById('spiral-design-form');

        if (!form) {
            return;
        }

        var previewStyle = document.getElementById('spiral-preview-css');
        var stage = form.querySelector('.spiral-preview-stage');
        var previewClose = document.getElementById('spiral-preview-close');
        var timer = null;

        /* Le bouton fermer de l'aperçu suit le style choisi (croix / texte). */
        function refreshPreviewClose() {
            if (!previewClose) {
                return;
            }

            var checked = form.querySelector('input[name="settings[close_style]"]:checked');
            var style = checked ? checked.value : 'cross';

            previewClose.className = 'spiral-close spiral-close-style-' + style;
            // En mode croix, le dessin vient des pseudo-éléments CSS.
            previewClose.textContent = style === 'text' ? (config.i18n.close || 'Fermer') : '';
        }

        /* Pastilles de couleur → sélecteur natif adjacent. */
        form.addEventListener('click', function (event) {
            var swatch = event.target.closest('.spiral-swatch');

            if (!swatch) {
                return;
            }

            var colorInput = swatch.closest('.spiral-color-field').querySelector('.spiral-color-input');
            colorInput.value = swatch.getAttribute('data-color');
            refreshPreview();
        });

        /* Aperçu live : le CSS vient du même générateur PHP que le front. */
        function refreshPreview() {
            window.clearTimeout(timer);

            timer = window.setTimeout(function () {
                var data = new FormData(form);
                data.append('action', 'spiral_design_css');
                data.append('nonce', config.nonce);

                window.fetch(config.ajaxUrl, { method: 'POST', body: data })
                    .then(function (response) { return response.json(); })
                    .then(function (payload) {
                        if (!payload || !payload.success) {
                            return;
                        }

                        previewStyle.textContent = payload.data.css;
                        stage.setAttribute('data-overlay', payload.data.overlay);
                    });
            }, 150);
        }

        form.addEventListener('change', function () {
            refreshPreviewClose();
            refreshPreview();
        });
        form.addEventListener('input', function (event) {
            if (event.target.matches('.spiral-color-input, textarea[name="custom_css"]')) {
                refreshPreview();
            }
        });
    }
})();
