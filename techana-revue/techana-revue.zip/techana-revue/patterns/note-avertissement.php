<?php
/**
 * Title: Encadré Avertissement
 * Slug: techana-revue/note-avertissement
 * Categories: techana
 * Keywords: note, avertissement, attention, encadré
 * Viewport Width: 720
 * Description: Encadré d'avertissement du corps d'article (design article) —
 * filet orangé, titre en capitales, un paragraphe.
 */
?>
<!-- wp:group {"className":"note warn"} -->
<div class="wp-block-group note warn"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Avertissement</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Ce qui peut mal tourner si l'étape est faite dans le désordre ou sur la mauvaise machine — et comment s'en prémunir.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
