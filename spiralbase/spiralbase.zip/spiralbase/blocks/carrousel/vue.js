/**
 * Script de vue du carrousel (story 3.5) — JavaScript nu, aucune dépendance.
 *
 * Le défilement lui-même est du CSS (`overflow-x` + `scroll-snap`) : tactile,
 * molette, trackpad et flèches du clavier fonctionnent SANS ce fichier. Il
 * n'ajoute donc que des commandes de confort — et c'est lui qui les crée,
 * pour qu'un bouton mort n'existe jamais dans une page où le script n'a pas
 * chargé.
 *
 * « Jamais de bouton mort » se tient jusqu'au bout depuis la revue : les
 * commandes n'apparaissent que si la piste déborde réellement, et elles
 * disparaissent si elle cesse de déborder.
 */
( function () {
    'use strict';

    var SELECTEUR = '[data-spiralbase-carrousel]';
    var MARGE = 2; // tolérance d'arrondi des navigateurs

    function reduitLesAnimations() {
        return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    }

    /* En écriture droite-à-gauche, `scrollLeft` part de 0 et devient NÉGATIF :
       raisonner sur sa valeur brute désactivait « précédent » en permanence,
       n'a jamais désactivé « suivant », et envoyait « suivant » dans le mur. */
    function versLaDroite( piste ) {
        return window.getComputedStyle( piste ).direction !== 'rtl';
    }

    function position( piste ) {
        return Math.abs( piste.scrollLeft );
    }

    function courseRestante( piste ) {
        return piste.scrollWidth - piste.clientWidth;
    }

    function deborde( piste ) {
        return courseRestante( piste ) > MARGE;
    }

    /*
     * Un pas = autant d'éléments entiers qu'il en tient dans la vue, jamais
     * moins d'un. Un pourcentage de la largeur visible donnait une cible que
     * l'accrochage déplaçait ensuite : sur la variante « cartes » le clic
     * avançait d'un élément, sur « logos » de trois, sans que rien ne
     * l'explique.
     */
    function pas( piste ) {
        var premier = piste.firstElementChild;

        if ( ! premier ) {
            return Math.max( 1, piste.clientWidth );
        }

        var ecart = parseFloat( window.getComputedStyle( piste ).columnGap ) || 0;
        var unite = premier.getBoundingClientRect().width + ecart;

        if ( ! unite ) {
            return Math.max( 1, piste.clientWidth );
        }

        return Math.max( 1, Math.floor( piste.clientWidth / unite ) ) * unite;
    }

    function bouton( libelle, texte ) {
        var b = document.createElement( 'button' );

        b.type = 'button';
        b.className = 'spiralbase-carrousel__commande';
        b.setAttribute( 'aria-label', libelle );
        b.textContent = texte;

        return b;
    }

    function majEtat( piste, precedent, suivant ) {
        var debut = position( piste ) <= MARGE;
        var fin = position( piste ) >= courseRestante( piste ) - MARGE;

        /* `aria-disabled` et non `disabled` : désactiver le bouton QUI A le
           focus le sort de l'ordre de tabulation, et le navigateur renvoie le
           focus au `<body>` — l'utilisateur clavier perdait sa place à la
           dernière pression. Le bouton reste atteignable, l'action est
           neutralisée dans `defiler()`. */
        precedent.setAttribute( 'aria-disabled', debut ? 'true' : 'false' );
        suivant.setAttribute( 'aria-disabled', fin ? 'true' : 'false' );
    }

    function equiper( piste ) {
        var conteneur = piste.parentNode;

        if ( ! conteneur || piste.dataset.spiralbaseEquipe === '1' ) {
            return;
        }

        /* Sans `scrollBy`, la commande lèverait une erreur silencieuse à
           chaque clic : mieux vaut pas de bouton qu'un bouton inerte. */
        if ( typeof piste.scrollBy !== 'function' ) {
            return;
        }

        var libelles = {
            precedent: piste.getAttribute( 'data-spiralbase-precedent' ),
            suivant: piste.getAttribute( 'data-spiralbase-suivant' ),
        };

        /* Les libellés viennent du serveur, traduits. Absents, un bouton
           n'aurait pas de nom accessible — on n'en crée aucun plutôt que
           d'inventer ici une chaîne qu'aucun catalogue ne traduira. */
        if ( ! libelles.precedent || ! libelles.suivant ) {
            return;
        }

        piste.dataset.spiralbaseEquipe = '1';

        var precedent = bouton( libelles.precedent, '‹' );
        var suivant = bouton( libelles.suivant, '›' );

        var defiler = function ( sens ) {
            var vise = sens < 0 ? precedent : suivant;

            if ( vise.getAttribute( 'aria-disabled' ) === 'true' ) {
                return;
            }

            piste.scrollBy( {
                left: sens * pas( piste ) * ( versLaDroite( piste ) ? 1 : -1 ),
                behavior: reduitLesAnimations() ? 'auto' : 'smooth',
            } );
        };

        precedent.addEventListener( 'click', function () {
            defiler( -1 );
        } );
        suivant.addEventListener( 'click', function () {
            defiler( 1 );
        } );

        var commandes = document.createElement( 'div' );
        commandes.className = 'spiralbase-carrousel__commandes';
        commandes.appendChild( precedent );
        commandes.appendChild( suivant );

        var actualiser = function () {
            /* Une piste qui ne déborde pas n'a rien à commander — et un
               arrêt de tabulation sur une zone qui ne défile pas ne mène
               nulle part. Le serveur, lui, pose `tabindex` sans condition :
               c'est le seul chemin clavier quand le script ne charge pas. */
            if ( ! deborde( piste ) ) {
                if ( commandes.parentNode ) {
                    commandes.parentNode.removeChild( commandes );
                }

                piste.removeAttribute( 'tabindex' );

                return;
            }

            if ( ! commandes.parentNode ) {
                conteneur.appendChild( commandes );
            }

            piste.setAttribute( 'tabindex', '0' );
            majEtat( piste, precedent, suivant );
        };

        piste.addEventListener( 'scroll', actualiser, { passive: true } );
        window.addEventListener( 'resize', actualiser );

        /* Les images arrivent après le premier calcul ; un carrousel dans un
           onglet fermé mesure zéro tant qu'il est caché ; le zoom et la
           rotation de l'écran changent la course sans `resize` de fenêtre.
           Un observateur de taille couvre les trois, là où `load` seul
           laissait les commandes figées sur une mesure périmée. */
        if ( typeof window.ResizeObserver === 'function' ) {
            new window.ResizeObserver( actualiser ).observe( piste );
        } else {
            window.addEventListener( 'load', actualiser );
        }

        actualiser();
    }

    function init() {
        var pistes = document.querySelectorAll( SELECTEUR );
        var i;

        for ( i = 0; i < pistes.length; i++ ) {
            equiper( pistes[ i ] );
        }
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', init );
    } else {
        init();
    }
} )();
