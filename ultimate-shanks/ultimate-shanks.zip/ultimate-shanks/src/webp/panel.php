<?php

/**
 * WebP - Panneau de conversion et de validation
 *
 * Deux listes : les médias convertibles (JPEG et PNG présentés séparément) et
 * les conversions en attente de validation (avant/après, gain, restauration,
 * suppression des originaux sélectionnés). Les actions passent par AJAX avec
 * nonce dédié + `manage_options` ; les lots sont dimensionnés côté JS
 * (5 WebP / 2 AVIF — décision D7 du design).
 *
 * Assets associés :
 * - JS : /assets/js/webp-panel.js
 *
 * Fichiers liés :
 * - src/webp/converter.php
 * - src/webp/settings.php (rendu de l'onglet englobant)
 *
 * @package UltimateShanks\Webp
 */

namespace UltimateShanks\Webp;

if (!defined('ABSPATH')) {
	exit;
}

class Panel
{
	const NONCE_ACTION = 'ultimate_shanks_webp_panel';

	/**
	 * Nombre maximum de médias listés par groupe (les plus récents d'abord)
	 */
	const LIST_LIMIT = 100;

	public static function init()
	{
		add_action('wp_ajax_ultimate_shanks_webp_convert', [self::class, 'ajax_convert']);
		add_action('wp_ajax_ultimate_shanks_webp_delete_originals', [self::class, 'ajax_delete_originals']);
		add_action('wp_ajax_ultimate_shanks_webp_restore', [self::class, 'ajax_restore']);
	}

	/**
	 * Attachements convertibles d'un MIME donné, sans conversion en attente
	 *
	 * @param string $mime image/jpeg|image/png
	 * @return \WP_Post[]
	 */
	public static function get_convertible($mime)
	{
		return get_posts([
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => $mime,
			'posts_per_page' => self::LIST_LIMIT,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_query'     => [['key' => Converter::META_KEY, 'compare' => 'NOT EXISTS']],
		]);
	}

	/**
	 * Conversions en attente de validation
	 *
	 * @return \WP_Post[]
	 */
	public static function get_pending()
	{
		return get_posts([
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => self::LIST_LIMIT,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_query'     => [['key' => Converter::META_KEY, 'compare' => 'EXISTS']],
		]);
	}

	/**
	 * Rend le panneau complet (convertibles + validation)
	 */
	public static function render()
	{
		?>
		<h3>Convertir des images</h3>
		<p>
			<label for="us_webp_preset"><strong>Preset :</strong></label>
			<select id="us_webp_preset">
				<?php $default = Presets::get_default(); ?>
				<?php foreach (Presets::get_all() as $preset) : ?>
					<option value="<?php echo esc_attr($preset['id']); ?>"
						data-format="<?php echo esc_attr($preset['format']); ?>"
						<?php disabled(!Capabilities::supports($preset['format'])); ?>
						<?php selected($preset['id'], $default ? $default['id'] : ''); ?>>
						<?php echo esc_html($preset['label']); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<button type="button" class="button button-primary" id="us_webp_convert_btn">Convertir la sélection</button>
			<span id="us_webp_convert_progress"></span>
		</p>
		<?php
		self::render_convertible_group('JPEG', 'image/jpeg');
		self::render_convertible_group('PNG (vérifier la transparence après conversion)', 'image/png');
		self::render_pending_list();
	}

	/**
	 * Une liste de médias convertibles (un groupe par MIME — JPEG et PNG séparés)
	 *
	 * @param string $title
	 * @param string $mime
	 */
	private static function render_convertible_group($title, $mime)
	{
		$items = self::get_convertible($mime);
		?>
		<h4><?php echo esc_html($title); ?> — <?php echo esc_html(count($items)); ?> média(s)</h4>
		<?php if ($items === []) : ?>
			<p class="description">Rien à convertir dans ce groupe.</p>
			<?php return; ?>
		<?php endif; ?>
		<table class="widefat striped us-webp-table" style="max-width:900px;">
			<thead>
				<tr>
					<th style="width:30px;"><input type="checkbox" class="us-webp-check-all"></th>
					<th style="width:70px;">Aperçu</th>
					<th>Fichier</th>
					<th style="width:110px;">Poids</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($items as $item) : ?>
					<?php $file = get_attached_file($item->ID); ?>
					<tr>
						<td><input type="checkbox" class="us-webp-convert-check" value="<?php echo esc_attr($item->ID); ?>"></td>
						<td><?php echo wp_get_attachment_image($item->ID, [60, 60]); ?></td>
						<td><code><?php echo esc_html(wp_basename((string) $file)); ?></code></td>
						<td><?php echo $file && file_exists($file) ? esc_html(size_format(filesize($file))) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Liste des conversions en attente de validation
	 */
	private static function render_pending_list()
	{
		$items = self::get_pending();
		?>
		<h3>Conversions à valider — <?php echo esc_html(count($items)); ?></h3>
		<?php if ($items === []) : ?>
			<p class="description">Aucune conversion en attente. Convertissez des images ci-dessus : les
				originaux resteront sur disque jusqu'à votre validation.</p>
			<?php return; ?>
		<?php endif; ?>
		<table class="widefat striped us-webp-table" style="max-width:1000px;">
			<thead>
				<tr>
					<th style="width:30px;"><input type="checkbox" class="us-webp-check-all"></th>
					<th style="width:70px;">Aperçu</th>
					<th>Fichier converti</th>
					<th style="width:190px;">Avant → après</th>
					<th style="width:130px;">Date / preset</th>
					<th style="width:100px;"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($items as $item) : ?>
					<?php self::render_pending_row($item); ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<button type="button" class="button button-primary" id="us_webp_delete_btn">
				Supprimer les originaux sélectionnés
			</button>
			<span class="description">Action définitive : les fichiers d'origine seront effacés du disque.</span>
		</p>
		<?php
	}

	/**
	 * Une ligne de conversion en attente
	 *
	 * @param \WP_Post $item
	 */
	private static function render_pending_row($item)
	{
		$original = get_post_meta($item->ID, Converter::META_KEY, true);
		$file = get_attached_file($item->ID);
		$new_size = $file && file_exists($file) ? (int) filesize($file) : 0;
		$old_size = isset($original['size']) ? (int) $original['size'] : 0;
		$gain = $old_size > 0 ? round((1 - $new_size / $old_size) * 100) : 0;
		$preset = isset($original['preset']) ? Presets::get($original['preset']) : null;
		?>
		<tr>
			<td><input type="checkbox" class="us-webp-pending-check" value="<?php echo esc_attr($item->ID); ?>"></td>
			<td><?php echo wp_get_attachment_image($item->ID, [60, 60]); ?></td>
			<td><code><?php echo esc_html(wp_basename((string) $file)); ?></code></td>
			<td>
				<?php echo esc_html(size_format($old_size)); ?> → <?php echo esc_html(size_format($new_size)); ?>
				<strong>(−<?php echo esc_html($gain); ?> %)</strong>
			</td>
			<td>
				<?php echo isset($original['date']) ? esc_html(wp_date('d/m/Y H:i', $original['date'])) : '—'; ?><br>
				<span class="description"><?php echo esc_html($preset ? $preset['label'] : (isset($original['preset']) ? $original['preset'] : '—')); ?></span>
			</td>
			<td>
				<button type="button" class="button button-small us-webp-restore-btn"
					data-id="<?php echo esc_attr($item->ID); ?>">Restaurer</button>
			</td>
		</tr>
		<?php
	}

	/**
	 * AJAX : convertit un lot d'attachements avec un preset
	 */
	public static function ajax_convert()
	{
		self::check_ajax_access();

		$ids = array_map('absint', (array) (isset($_POST['ids']) ? $_POST['ids'] : []));
		$preset_id = isset($_POST['preset_id']) ? sanitize_key($_POST['preset_id']) : '';

		$results = [];
		foreach ($ids as $id) {
			$result = Converter::convert_attachment($id, $preset_id);
			$results[$id] = is_wp_error($result)
				? ['success' => false, 'message' => $result->get_error_message()]
				: ['success' => true, 'old_size' => $result['old_size'], 'new_size' => $result['new_size']];
		}

		wp_send_json_success(['results' => $results]);
	}

	/**
	 * AJAX : supprime définitivement les originaux d'un lot de conversions
	 */
	public static function ajax_delete_originals()
	{
		self::check_ajax_access();

		$ids = array_map('absint', (array) (isset($_POST['ids']) ? $_POST['ids'] : []));

		$results = [];
		foreach ($ids as $id) {
			$result = Converter::delete_originals($id);
			$results[$id] = is_wp_error($result)
				? ['success' => false, 'message' => $result->get_error_message()]
				: ['success' => true];
		}

		wp_send_json_success(['results' => $results]);
	}

	/**
	 * AJAX : restaure une conversion non validée
	 */
	public static function ajax_restore()
	{
		self::check_ajax_access();

		$id = isset($_POST['id']) ? absint($_POST['id']) : 0;
		$result = Converter::restore_attachment($id);

		if (is_wp_error($result)) {
			wp_send_json_error(['message' => $result->get_error_message()], 400);
		}

		wp_send_json_success(['message' => 'Conversion restaurée.']);
	}

	/**
	 * Garde commune des handlers AJAX du panneau
	 */
	private static function check_ajax_access()
	{
		check_ajax_referer(self::NONCE_ACTION, 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permissions insuffisantes.'], 403);
		}
	}
}
