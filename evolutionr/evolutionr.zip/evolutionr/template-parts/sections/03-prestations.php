<?php
/**
 * 03 — Section Prestations (services).
 *
 * Visuel : en-tête (eyebrow + grand titre + lede à droite) puis grille de
 * cartes prestations. Chaque carte affiche un numéro, une icône, un titre,
 * une description, des bullets et un lien vers la page publique dédiée
 * (« Voir la prestation »).
 *
 * Source de données : repeater ACF `services_cards` (front-page). Chaque ligne
 * pointe vers une page publique (`/prestations/creation-site-internet/`,
 * `/prestations/consultant-seo/`, `/prestations/maintenance-hebergement/`,
 * `/prestations/identite-visuelle/`), éditée directement sur la page d'accueil.
 *
 * Pilotage ACF (front-page) : services_eyebrow, services_title, services_lede.
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow = get_field('services_eyebrow') ?: __('Nos prestations', 'evolutionr');
$title   = get_field('services_title') ?: '';
$lede    = get_field('services_lede');

if (!function_exists('have_rows') || !have_rows('services_cards')) {
    return;
}
?>
<section class="section" id="services" aria-labelledby="services-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <?php if ($title): ?>
                    <h2 class="section-title" id="services-title"><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
            </div>
            <?php if ($lede): ?>
                <p class="section-lede"><?php echo esc_html($lede); ?></p>
            <?php endif; ?>
        </header>

        <div class="services-grid">
            <?php while (have_rows('services_cards')): the_row();
                $number   = (string) get_sub_field('number');
                $icon     = (string) get_sub_field('icon') ?: 'code';
                $cTitle   = (string) get_sub_field('title');
                $excerpt  = (string) get_sub_field('excerpt');
                $ctaLabel = (string) get_sub_field('cta_label') ?: __('Voir la prestation', 'evolutionr');
                $ctaUrl   = (string) get_sub_field('cta_url') ?: '#';
                ?>
                <article class="service-card">
                    <div class="service-card-inner">
                        <?php if ($number): ?>
                            <span class="service-num"><?php echo esc_html($number); ?></span>
                        <?php endif; ?>

                        <div class="service-icon" aria-hidden="true">
                            <?php evolutionr_icon($icon, 24); ?>
                        </div>

                        <h3 class="service-title"><?php echo esc_html($cTitle); ?></h3>

                        <?php if ($excerpt): ?>
                            <p class="service-desc"><?php echo esc_html($excerpt); ?></p>
                        <?php endif; ?>

                        <?php if (have_rows('bullets')): ?>
                            <ul class="service-list">
                                <?php while (have_rows('bullets')): the_row();
                                    $btext = (string) get_sub_field('text');
                                    if (!$btext) continue;
                                    ?>
                                    <li>
                                        <?php evolutionr_icon('check', 14); ?>
                                        <span><?php echo esc_html($btext); ?></span>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php endif; ?>

                        <a class="service-link" href="<?php echo esc_url($ctaUrl); ?>">
                            <span class="btn-inner">
                                <?php echo esc_html($ctaLabel); ?>
                                <?php evolutionr_icon('arrow-right', 16); ?>
                            </span>
                        </a>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</section>
