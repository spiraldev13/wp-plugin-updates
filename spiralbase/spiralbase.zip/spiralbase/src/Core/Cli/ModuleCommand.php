<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\Registry;
use SpiralBase\Core\RegistryException;

/**
 * `wp spiralbase module` — la porte du CHOIX HUMAIN.
 *
 * L'AC 2 de la story 3.9 s'ouvre sur « un profil déjà appliqué puis des choix
 * manuels modifiés » : sans écran d'administration (Epic 6), aucun chemin
 * supporté ne permettait à un humain de basculer un interrupteur —
 * `Registry::setEnabled()` n'était atteignable que depuis du PHP. C'est le
 * défaut exact déjà payé en 3.4 et en 3.8 : une AC qui parle d'une chose
 * configurée qu'aucune porte livrée ne configure.
 *
 * Messages CLI non traduits (convention WP-CLI).
 */
final class ModuleCommand
{
    /** Tentatives de bascule avant de rendre la main (verrou tenu quelques ms). */
    private const ESSAIS = 4;

    private const ATTENTE_MICROSECONDES = 100000;

    public function __construct(private readonly Registry $registre)
    {
    }

    /**
     * Liste les modules, leur état et l'origine de cet état.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase module lister
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function lister(array $args, array $assocArgs): void
    {
        foreach (EtatModules::lignes($this->registre) as $ligne) {
            \WP_CLI::log($ligne);
        }
    }

    /**
     * Active un module — décision humaine, prioritaire sur le profil.
     *
     * ## OPTIONS
     *
     * <slug>
     * : Slug du module (voir `wp spiralbase module lister`).
     *
     * ## EXAMPLES
     *
     *     wp spiralbase module activer bloc_menu
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function activer(array $args, array $assocArgs): void
    {
        $this->basculer($args[0] ?? '', true);
    }

    /**
     * Désactive un module — décision humaine, prioritaire sur le profil.
     *
     * ## OPTIONS
     *
     * <slug>
     * : Slug du module (voir `wp spiralbase module lister`).
     *
     * ## EXAMPLES
     *
     *     wp spiralbase module desactiver sommaire_auto
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function desactiver(array $args, array $assocArgs): void
    {
        $this->basculer($args[0] ?? '', false);
    }

    private function basculer(string $slug, bool $etat): void
    {
        $slug = trim($slug);

        if ($slug === '') {
            \WP_CLI::error('Slug de module attendu : wp spiralbase module activer|desactiver <slug>.');

            return;
        }

        if (!in_array($slug, $this->registre->slugs(), true)) {
            \WP_CLI::error(sprintf('Module inconnu : « %s ». Voir wp spiralbase module lister.', $slug));

            return;
        }

        /*
         * Le registre sérialise les bascules et REFUSE plutôt que de perdre
         * un choix concurrent (revue 3.9). Le refus est correct, mais il est
         * brutal pour l'usage réel : un script de livraison qui enchaîne
         * plusieurs bascules en parallèle prenait 7 refus sur 8 alors que le
         * verrou n'est tenu que quelques millisecondes. La reprise vit ICI,
         * à la porte humaine — le noyau, lui, reste une primitive stricte.
         */
        for ($essai = 1; ; $essai++) {
            try {
                $this->registre->setEnabled($slug, $etat);

                break;
            } catch (RegistryException $e) {
                if ($essai >= self::ESSAIS) {
                    /* Conversion à la frontière (convention de la spine) :
                       sans elle, l'exception traverserait la commande sans
                       message exploitable. */
                    \WP_CLI::error($e->getMessage());

                    return;
                }

                usleep(self::ATTENTE_MICROSECONDES);
            }
        }

        \WP_CLI::success(sprintf(
            'Module « %s » %s — choix manuel enregistré : aucun profil ne le modifiera.',
            $slug,
            $etat ? 'activé' : 'désactivé'
        ));

        /* La sonde de cession (AD-3) n'a pas été évaluée pour ce module : elle
           l'est au boot, qui a déjà eu lieu. Annoncer un succès sec laisserait
           croire que le module rend quelque chose alors qu'un plugin tiers
           peut le faire céder à la requête suivante. */
        if ($this->registre->actifAuBoot($slug) !== $etat) {
            \WP_CLI::log('Effet au prochain chargement. Vérifier avec « wp spiralbase module lister » : un tiers peut faire céder ce module (AD-3).');
        }
    }
}
