<?php
/**
 * CTA final des pages prestation (Création, SEO, Identité, Maintenance).
 *
 * Bloc d'appel à l'action de bas de page, piloté par les champs `cta_*` du post
 * courant + le toggle `cta_enabled`. Markup factorisé (était dupliqué sur les 4
 * pages). NB : la page Tarifs garde son propre CTA (gating et fallback de
 * libellé différents → pas la même logique).
 */

if (!defined('ABSPATH')) {
    exit;
}

$ctaEnabled   = (bool) get_field('cta_enabled');
$ctaTitle     = (string) get_field('cta_title');
$ctaParagraph = (string) get_field('cta_paragraph');
$ctaLabel     = (string) get_field('cta_label');
$ctaUrl       = (string) get_field('cta_url') ?: '/contact/';

if ($ctaEnabled && ($ctaTitle || $ctaLabel)): ?>
    <section class="page-cta-final" aria-labelledby="page-cta-title">
        <div class="container">
            <?php if ($ctaTitle): ?><h2 id="page-cta-title"><?php echo esc_html($ctaTitle); ?></h2><?php endif; ?>
            <?php if ($ctaParagraph): ?><p><?php echo esc_html($ctaParagraph); ?></p><?php endif; ?>
            <?php if ($ctaLabel): ?>
                <a class="btn btn-primary" href="<?php echo esc_url($ctaUrl); ?>">
                    <?php echo esc_html($ctaLabel); ?>
                    <?php evolutionr_icon('arrow-right', 16); ?>
                </a>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
