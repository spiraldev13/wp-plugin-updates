<?php

declare(strict_types=1);

namespace SpiralBase\Modules\FormulaireContact;

use SpiralBase\Core\Signal;

/**
 * Cloudflare Turnstile — couche OPTIONNELLE, jamais un remplacement (AC 3).
 *
 * Les quatre couches natives restent actives quand Turnstile est allumé :
 * c'est une vérification de PLUS, pas une autre. Éteint — le cas par défaut —
 * cette classe ne rend aucun HTML et n'ouvre aucune connexion : la 2.5 a
 * établi qu'aucun traceur tiers ne se dépose avant consentement, et un script
 * chargé « au cas où » serait exactement cela.
 *
 * En cas de panne du service, la soumission est ACCEPTÉE et l'incident
 * signalé. Un formulaire de contact qui refuse tout parce qu'un tiers ne
 * répond pas coûte plus cher au client que le spam qu'il évite — et les
 * quatre couches natives, elles, ont déjà tranché.
 */
final class Turnstile
{
    public const CHAMP = 'cf-turnstile-response';

    private const POINT_DE_VERIFICATION = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

    public function __construct(
        private readonly string $cleSite,
        private readonly string $cleSecrete,
    ) {
    }

    public function estActif(): bool
    {
        $site   = trim($this->cleSite);
        $secret = trim($this->cleSecrete);

        if (($site === '') !== ($secret === '')) {
            /* Une seule clé renseignée : l'opérateur CROIT son formulaire
               protégé et ne l'est pas. Le silence serait ici le pire des
               services. */
            Signal::emettre(
                'spiralbase_formulaire_turnstile_incomplet',
                'Turnstile a besoin des DEUX clés (site et secrète) — couche inactive',
                'formulaire'
            );
        }

        return $site !== '' && $secret !== '';
    }

    /** Widget invisible — rien du tout si l'option n'est pas renseignée. */
    public function rendreWidget(): string
    {
        if (!$this->estActif()) {
            return '';
        }

        /*
         * `data-appearance="interaction-only"` et NON `data-size="invisible"` :
         * ce dernier n'existe pas dans l'API. Cloudflare le refuse lui-même —
         * « expected "compact", "flexible", or "normal", got "invisible" » —
         * et lève une exception JS à chaque chargement de page. L'apparente
         * invisibilité observée venait de la clé de test toujours-vraie, pas
         * du paramètre : avec une vraie clé « managed », le widget se serait
         * affiché, en contradiction avec « aucune couche visible ».
         */
        return '<div class="cf-turnstile" data-sitekey="' . esc_attr(trim($this->cleSite)) . '"'
            . ' data-appearance="interaction-only"></div>'
            . '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
    }

    /**
     * @param  array<string, mixed> $donnees
     * @return bool `true` si la soumission passe (y compris service injoignable)
     */
    public function verifier(array $donnees, string $ip): bool
    {
        if (!$this->estActif()) {
            return true;
        }

        $reponse = $donnees[self::CHAMP] ?? '';

        if (!is_string($reponse) || trim($reponse) === '') {
            /*
             * Jeton absent : le script tiers n'a pas répondu — bloqueur, CSP,
             * connexion lente, envoi plus rapide que le chargement. C'est la
             * MÊME cause racine qu'un service injoignable, et elle mérite la
             * même politique : on laisse passer, les quatre couches natives
             * ont déjà tranché. Le premier jet refusait ici et acceptait là,
             * deux réponses opposées à un seul problème — et le visiteur
             * légitime au bloqueur voyait son message détruit en silence.
             */
            Signal::emettre(
                'spiralbase_formulaire_turnstile_absent',
                'aucun jeton Turnstile reçu, soumission acceptée sur les couches natives',
                'formulaire'
            );

            return true;
        }

        $retour = wp_remote_post(self::POINT_DE_VERIFICATION, [
            /*
             * `redirection => 0` : SANS lui, le cœur en suit 5 par défaut
             * (`class-wp-http.php:191`) et REJOUE le corps entier sur 301,
             * 307 et 308 (`:1083-1098`) — vers n'importe quel hôte. La CLÉ
             * SECRÈTE du site partait donc chez la cible de la redirection,
             * qui pouvait en prime dicter le verdict en répondant
             * `{"success":true}`. Défaut prouvé en revue, et déjà payé une
             * fois : la story 3.3 l'avait corrigé pour la clé Google.
             */
            'redirection' => 0,
            /* 2 s et non 5 : cet appel est déclenchable par n'importe quel
               anonyme, et il immobilise un worker PHP pendant tout ce temps. */
            'timeout' => 2,
            'body'    => [
                'secret'   => trim($this->cleSecrete),
                'response' => trim($reponse),
                'remoteip' => $ip,
            ],
        ]);

        if (is_wp_error($retour)) {
            Signal::emettre(
                'spiralbase_formulaire_turnstile_injoignable',
                'Turnstile injoignable, soumission acceptée sur les couches natives',
                'formulaire'
            );

            return true;
        }

        $code = wp_remote_retrieve_response_code($retour);

        if ($code !== 200) {
            /* Le code HTTP se lit AVANT le corps : une page d'erreur, une
               redirection non suivie ou un 403 ne sont pas des verdicts. */
            Signal::emettre(
                'spiralbase_formulaire_turnstile_illisible',
                sprintf('Turnstile a répondu %d, soumission acceptée sur les couches natives', $code),
                'formulaire'
            );

            return true;
        }

        $corps = json_decode((string) wp_remote_retrieve_body($retour), true);

        if (!is_array($corps) || !array_key_exists('success', $corps)) {
            /* Réponse illisible : on ne DEVINE pas un verdict. La leçon de la
               3.3 est passée par là — un 200 compris à moitié y effaçait des
               témoignages, la CLI annonçant « Success ». */
            Signal::emettre(
                'spiralbase_formulaire_turnstile_illisible',
                'réponse Turnstile illisible, soumission acceptée sur les couches natives',
                'formulaire'
            );

            return true;
        }

        return $corps['success'] === true;
    }
}
