<?php
/**
 * Settings - Interface d'administration principale
 *
 * Ce fichier gère le menu admin et l'orchestration des onglets.
 * Les interfaces spécifiques sont déléguées aux classes correspondantes.
 *
 * Assets associés :
 * - CSS Admin : /assets/css/admin-settings.css (styles globaux interface admin)
 *
 * Fichiers liés :
 * - src/style/settings.php          : Onglet Style (délégué)
 * - src/text-enhancer/settings.php  : Onglet Optimiseur (délégué)
 *
 * @package UltimateShanks\Admin
 */

namespace UltimateShanks\Admin;

if (!defined('ABSPATH')) {
	exit;
}

class Settings
{
	public static function init()
	{
		// Ajoute le menu dans l'administration WordPress
		add_action('admin_menu', [self::class, 'add_admin_menu']);

		// Enregistre les paramètres
		add_action('admin_init', [self::class, 'register_settings']);

		// Charge les styles CSS
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_admin_styles']);

		// Affiche l'icône du plugin dans la liste "Extensions installées"
		add_action('admin_head-plugins.php', [self::class, 'print_plugins_list_icon_style']);

		// Contraint la taille de l'icône dans le menu latéral (present sur tout wp-admin :
		// WordPress ne redimensionne pas une image brute passee a add_menu_page()).
		add_action('admin_head', [self::class, 'print_admin_menu_icon_style']);
	}

	/**
	 * Ajoute le menu d'administration
	 */
	public static function add_admin_menu()
	{
		add_menu_page(
			'Ultimate Shanks',                          // Titre de la page
			'Ultimate Shanks',                          // Titre du menu
			'manage_options',                           // Capacité requise
			'ultimate-shanks',                          // Slug du menu
			[self::class, 'render_settings_page'],     // Callback pour afficher la page
			MP_URL . 'assets/icone_plugin/icon-128x128.png', // Icône
			59                                          // Position (après Apparence)
		);
	}

	/**
	 * Affiche l'icône du plugin devant son nom dans Extensions > Extensions installées.
	 */
	public static function print_plugins_list_icon_style()
	{
		$icon_url = esc_url(MP_URL . 'assets/icone_plugin/icon-128x128.png');
		// Whitelist de caractères (pas esc_attr) : la valeur est insérée dans du CSS brut, pas un attribut HTML.
		$safe_basename = preg_replace('/[^A-Za-z0-9_\-\.\/]/', '', MP_BASENAME);
		$selector = 'tr[data-plugin="' . $safe_basename . '"] .plugin-title strong';
		?>
		<style>
			<?php echo $selector; ?> {
				display: inline-block;
				background-image: url('<?php echo $icon_url; ?>');
				background-repeat: no-repeat;
				background-position: left center;
				background-size: 18px 18px;
				padding-left: 24px;
				line-height: 18px;
			}
		</style>
		<?php
	}

	/**
	 * Contraint la taille de l'icône du menu latéral admin : WordPress affiche une
	 * URL d'icône personnalisée via <img> brut, sans contrainte de largeur/hauteur
	 * (contrairement aux dashicons, gérés en police). Sans ce style, l'image
	 * s'affiche à sa taille native et déborde sur les entrées de menu voisines.
	 */
	public static function print_admin_menu_icon_style()
	{
		?>
		<style>
			#toplevel_page_ultimate-shanks .wp-menu-image img {
				width: 20px !important;
				height: 20px !important;
				padding: 7px 0 0 !important;
				opacity: 1 !important;
			}
		</style>
		<?php
	}

	/**
	 * Enregistre les paramètres du plugin
	 */
	public static function register_settings()
	{
		register_setting('ultimate_shanks_settings', 'ultimate_shanks_featured_images_enabled');
		register_setting('ultimate_shanks_settings', 'ultimate_shanks_add_image_button_enabled');

		// Shortcodes
		register_setting('ultimate_shanks_shortcodes', 'ultimate_shanks_shortcodes_enabled');
		register_setting('ultimate_shanks_shortcodes', 'ultimate_shanks_shortcodes_in_titles');
		register_setting('ultimate_shanks_shortcodes', 'ultimate_shanks_shortcodes_in_menus');

		// Options / Intégrations
		register_setting('ultimate_shanks_options', 'ultimate_shanks_otomatic_enabled');
		register_setting('ultimate_shanks_options', 'ultimate_shanks_rankmath_enabled');
	}

	/**
	 * Charge les styles CSS et JavaScript pour la page d'administration
	 */
	public static function enqueue_admin_styles($hook)
	{
		// Charge uniquement sur la page du plugin
		if ($hook !== 'toplevel_page_ultimate-shanks') {
			return;
		}

		// CSS global admin
		wp_enqueue_style(
			'ultimate-shanks-admin',
			MP_URL . 'assets/css/admin-settings.css',
			array(),
			'1.1.2'
		);

		// JavaScript pour l'onglet Style (color pickers, sliders, etc.)
		wp_enqueue_script(
			'ultimate-shanks-style-admin',
			MP_URL . 'assets/js/style-manager-admin.js',
			array('jquery'),
			'1.1.2',
			true
		);
	}

	/**
	 * Affiche la page de paramètres
	 */
	public static function render_settings_page()
	{
		// Vérifie les permissions
		if (!current_user_can('manage_options')) {
			return;
		}

		// Déterminer l'onglet actif
		$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'images';
		?>
		<div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>

			<!-- Onglets -->
			<nav class="nav-tab-wrapper">
				<a href="?page=ultimate-shanks&tab=images" class="nav-tab <?php echo $active_tab === 'images' ? 'nav-tab-active' : ''; ?>">
					Images
				</a>
				<a href="?page=ultimate-shanks&tab=ai-images" class="nav-tab <?php echo $active_tab === 'ai-images' ? 'nav-tab-active' : ''; ?>">
					Images IA
				</a>
				<a href="?page=ultimate-shanks&tab=text-enhancer" class="nav-tab <?php echo $active_tab === 'text-enhancer' ? 'nav-tab-active' : ''; ?>">
					Optimiseur de Paragraphes
				</a>
				<a href="?page=ultimate-shanks&tab=style" class="nav-tab <?php echo $active_tab === 'style' ? 'nav-tab-active' : ''; ?>">
					Style
				</a>
				<a href="?page=ultimate-shanks&tab=shortcodes" class="nav-tab <?php echo $active_tab === 'shortcodes' ? 'nav-tab-active' : ''; ?>">
					Shortcodes
				</a>
				<a href="?page=ultimate-shanks&tab=options" class="nav-tab <?php echo $active_tab === 'options' ? 'nav-tab-active' : ''; ?>">
					Options
				</a>
				<a href="?page=ultimate-shanks&tab=about" class="nav-tab <?php echo $active_tab === 'about' ? 'nav-tab-active' : ''; ?>">
					À propos
				</a>
			</nav>

			<!-- Contenu de l'onglet -->
			<div class="tab-content">
				<?php
				switch ($active_tab) {
					case 'images':
						self::render_images_tab();
						break;
					case 'ai-images':
						self::render_ai_images_tab();
						break;
					case 'text-enhancer':
						self::render_text_enhancer_tab();
						break;
					case 'style':
						self::render_style_tab();
						break;
					case 'shortcodes':
						self::render_shortcodes_tab();
						break;
					case 'options':
						self::render_options_tab();
						break;
					case 'about':
						self::render_about_tab();
						break;
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Affiche l'onglet Images
	 */
	private static function render_images_tab()
	{
		// Récupère l'état actuel des fonctionnalités
		$featured_images_enabled = get_option('ultimate_shanks_featured_images_enabled', '1');
		$add_image_button_enabled = get_option('ultimate_shanks_add_image_button_enabled', '1');

		// Gestion du formulaire
		if (isset($_POST['ultimate_shanks_settings_submit'])) {
			check_admin_referer('ultimate_shanks_settings_action', 'ultimate_shanks_settings_nonce');

			$featured_images_enabled = isset($_POST['ultimate_shanks_featured_images_enabled']) ? '1' : '0';
			$add_image_button_enabled = isset($_POST['ultimate_shanks_add_image_button_enabled']) ? '1' : '0';

			update_option('ultimate_shanks_featured_images_enabled', $featured_images_enabled);
			update_option('ultimate_shanks_add_image_button_enabled', $add_image_button_enabled);

			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}
		?>

		<div class="ultimate-shanks-settings-box">
				<h2>Configuration des fonctionnalités</h2>

				<form method="post" action="">
					<?php wp_nonce_field('ultimate_shanks_settings_action', 'ultimate_shanks_settings_nonce'); ?>

					<table class="form-table ultimate-shanks-form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="ultimate_shanks_featured_images_enabled">Affichage des images à la une</label>
								</th>
								<td>
									<label>
										<input
											type="checkbox"
											id="ultimate_shanks_featured_images_enabled"
											name="ultimate_shanks_featured_images_enabled"
											value="1"
											<?php checked($featured_images_enabled, '1'); ?>
										>
										Activer l'affichage des images à la une et des images dans les articles
									</label>
									<p class="description">
										Cette fonctionnalité ajoute une colonne "Image à la une" dans la liste des articles
										et affiche un compteur d'images dans le contenu.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="ultimate_shanks_add_image_button_enabled">Bouton d'ajout d'image rapide</label>
								</th>
								<td>
									<label>
										<input
											type="checkbox"
											id="ultimate_shanks_add_image_button_enabled"
											name="ultimate_shanks_add_image_button_enabled"
											value="1"
											<?php checked($add_image_button_enabled, '1'); ?>
										>
										Activer le bouton "+ Ajouter une image" dans la liste des articles
									</label>
									<p class="description">
										Permet d'ajouter rapidement une image à la une depuis la liste des articles en ouvrant la médiathèque.
										<br><strong>Note :</strong> Cette option nécessite que "Affichage des images à la une" soit activé.
									</p>
								</td>
							</tr>
						</tbody>
					</table>

					<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_settings_submit'); ?>
				</form>
			</div>
		<?php
	}

	/**
	 * Affiche l'onglet Images IA
	 */
	private static function render_ai_images_tab()
	{
		// Charger la classe Settings du module Images IA
		\UltimateShanks\AiImages\Settings::render_tab();
	}

	/**
	 * Affiche l'onglet Optimiseur de Paragraphes
	 */
	private static function render_text_enhancer_tab()
	{
		// Charger la classe Settings
		\UltimateShanks\TextEnhancer\Settings::render_tab();
	}

	/**
	 * Affiche l'onglet Style
	 */
	private static function render_style_tab()
	{
		// Charger la classe Settings du Style Manager
		\UltimateShanks\Style\Settings::render_tab();
	}

	/**
	 * Affiche l'onglet Shortcodes
	 */
	private static function render_shortcodes_tab()
	{
		// Récupère les options actuelles
		$shortcodes_enabled = get_option('ultimate_shanks_shortcodes_enabled', '1');
		$shortcodes_in_titles = get_option('ultimate_shanks_shortcodes_in_titles', '1');
		$shortcodes_in_menus = get_option('ultimate_shanks_shortcodes_in_menus', '1');

		// Gestion du formulaire
		if (isset($_POST['ultimate_shanks_shortcodes_submit'])) {
			check_admin_referer('ultimate_shanks_shortcodes_action', 'ultimate_shanks_shortcodes_nonce');

			$shortcodes_enabled = isset($_POST['ultimate_shanks_shortcodes_enabled']) ? '1' : '0';
			$shortcodes_in_titles = isset($_POST['ultimate_shanks_shortcodes_in_titles']) ? '1' : '0';
			$shortcodes_in_menus = isset($_POST['ultimate_shanks_shortcodes_in_menus']) ? '1' : '0';

			update_option('ultimate_shanks_shortcodes_enabled', $shortcodes_enabled);
			update_option('ultimate_shanks_shortcodes_in_titles', $shortcodes_in_titles);
			update_option('ultimate_shanks_shortcodes_in_menus', $shortcodes_in_menus);

			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}
		?>

		<div class="ultimate-shanks-settings-box">
			<h2>🔧 Shortcodes Utilitaires</h2>
			<p class="description">
				Configurez les shortcodes disponibles et leurs options d'activation.
			</p>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_shortcodes_action', 'ultimate_shanks_shortcodes_nonce'); ?>

				<table class="form-table ultimate-shanks-form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<label for="ultimate_shanks_shortcodes_enabled">Activer les shortcodes</label>
							</th>
							<td>
								<label>
									<input
										type="checkbox"
										id="ultimate_shanks_shortcodes_enabled"
										name="ultimate_shanks_shortcodes_enabled"
										value="1"
										<?php checked($shortcodes_enabled, '1'); ?>
									>
									Activer les shortcodes utilitaires
								</label>
								<p class="description">
									Active ou désactive tous les shortcodes fournis par ce plugin.
								</p>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="ultimate_shanks_shortcodes_in_titles">Shortcodes dans les titres</label>
							</th>
							<td>
								<label>
									<input
										type="checkbox"
										id="ultimate_shanks_shortcodes_in_titles"
										name="ultimate_shanks_shortcodes_in_titles"
										value="1"
										<?php checked($shortcodes_in_titles, '1'); ?>
									>
									Autoriser les shortcodes dans les titres de pages et articles
								</label>
								<p class="description">
									Permet d'utiliser <code>[year]</code> dans les titres. Ex: "Copyright [year]" → "Copyright <?php echo date('Y'); ?>"
								</p>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="ultimate_shanks_shortcodes_in_menus">Shortcodes dans les menus</label>
							</th>
							<td>
								<label>
									<input
										type="checkbox"
										id="ultimate_shanks_shortcodes_in_menus"
										name="ultimate_shanks_shortcodes_in_menus"
										value="1"
										<?php checked($shortcodes_in_menus, '1'); ?>
									>
									Autoriser les shortcodes dans les menus de navigation
								</label>
								<p class="description">
									Permet d'utiliser les shortcodes dans les éléments de menu WordPress.
								</p>
							</td>
						</tr>
					</tbody>
				</table>

				<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_shortcodes_submit'); ?>
			</form>
		</div>

		<div class="ultimate-shanks-info-box" style="margin-top: 20px;">
			<h3>📋 Shortcodes disponibles</h3>

			<table class="widefat striped" style="max-width: 800px;">
				<thead>
					<tr>
						<th>Shortcode</th>
						<th>Description</th>
						<th>Exemple</th>
						<th>Résultat</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code>[year]</code></td>
						<td>Affiche l'année en cours (4 chiffres)</td>
						<td><code>© [year] Mon Site</code></td>
						<td>© <?php echo date('Y'); ?> Mon Site</td>
					</tr>
					<tr>
						<td><code>[year format="y"]</code></td>
						<td>Affiche l'année en cours (2 chiffres)</td>
						<td><code>Version 1.0 - [year format="y"]</code></td>
						<td>Version 1.0 - <?php echo date('y'); ?></td>
					</tr>
				</tbody>
			</table>

			<h4 style="margin-top: 20px;">💡 Utilisations possibles</h4>
			<ul>
				<li><strong>Footer :</strong> <code>© [year] Tous droits réservés</code></li>
				<li><strong>Titre de page :</strong> <code>Rapport Annuel [year]</code></li>
				<li><strong>Widget texte :</strong> <code>Mise à jour : [year]</code></li>
				<li><strong>Menu :</strong> <code>Catalogue [year]</code></li>
			</ul>
		</div>

		<?php
	}

	/**
	 * Récupère la version actuelle du plugin depuis l'en-tête principal.
	 *
	 * @return string
	 */
	private static function get_plugin_version()
	{
		if (!function_exists('get_plugin_data')) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_main_file = self::get_plugin_main_file_path();
		if (!file_exists($plugin_main_file)) {
			return 'unknown';
		}

		$data = get_plugin_data($plugin_main_file, false, false);
		return !empty($data['Version']) ? $data['Version'] : 'unknown';
	}

	/**
	 * Retourne le chemin absolu du fichier principal du plugin.
	 */
	private static function get_plugin_main_file_path()
	{
		$main_file = function_exists('wp_plugin_updater_get_config_value')
			? (string) wp_plugin_updater_get_config_value('main_file', 'ultimate-shanks.php')
			: 'ultimate-shanks.php';

		if (defined('WP_PLUGIN_DIR') && defined('MP_BASENAME') && MP_BASENAME) {
			$from_basename = rtrim(WP_PLUGIN_DIR, '/\\') . '/' . ltrim((string) MP_BASENAME, '/\\');
			if (file_exists($from_basename)) {
				return $from_basename;
			}
		}

		$base_path = defined('MP_PATH') ? MP_PATH : dirname(__DIR__, 2) . '/';
		$candidate = rtrim($base_path, '/\\') . '/' . ltrim($main_file, '/\\');

		return $candidate;
	}

	/**
	 * Retourne le basename WordPress du plugin (compatible chemins custom).
	 */
	private static function get_plugin_basename()
	{
		if (defined('MP_BASENAME') && MP_BASENAME) {
			return MP_BASENAME;
		}

		return plugin_basename(self::get_plugin_main_file_path());
	}

	/**
	 * Affiche l'onglet À propos
	 */
	private static function render_about_tab()
	{
		?>
		<div class="ultimate-shanks-info-box">
			<h3>À propos d'Ultimate Shanks</h3>
			<p><strong>Version :</strong> <?php echo esc_html(self::get_plugin_version()); ?></p>
			<p><strong>Description :</strong> Plugin WordPress multifonctions avec mise à jour automatique via manifest public.</p>
			<p><strong>Auteur :</strong> Shanks</p>

			<hr>

			<h4>Fonctionnalités actuelles :</h4>
			<ul>
				<li><strong>Gestion des images</strong> - Affichage des images à la une et des images dans les articles</li>
				<li><strong>Aperçu rapide</strong> - Aperçu rapide des images dans la liste des articles</li>
				<li><strong>Ajout rapide d'image</strong> - Bouton pour ajouter une image à la une depuis la liste des articles</li>
				<li><strong>Optimiseur de Paragraphes</strong> - Découpage automatique des paragraphes longs et corrections SEO</li>
				<li><strong>Shortcodes utilitaires</strong> - Shortcode [year] pour afficher l'année en cours partout</li>
				<li><strong>Mise à jour automatique</strong> - Mise à jour automatique via GitHub</li>
			</ul>

			<hr>

			<h4>Support et documentation</h4>
			<p>
					Pour plus d'informations, consultez le fichier <code>README.md</code> dans le répertoire du plugin.
			</p>

			<hr>

			<h4>Diagnostic mise à jour</h4>
			<?php self::render_update_diagnostic(); ?>
		</div>
		<?php
	}

	/**
	 * Affiche un diagnostic complet du système de mise à jour.
	 */
	private static function render_update_diagnostic()
	{
		$current_version = self::get_plugin_version();
		$manifest_url = function_exists('ultimate_shanks_get_manifest_url') ? ultimate_shanks_get_manifest_url() : 'Fonction non trouvée';
		$plugin_file = self::get_plugin_basename();
		$canonical_slug = function_exists('wp_plugin_updater_get_config_value')
			? (string) wp_plugin_updater_get_config_value('slug', 'ultimate-shanks')
			: 'ultimate-shanks';
		$canonical_main_file = function_exists('wp_plugin_updater_get_config_value')
			? (string) wp_plugin_updater_get_config_value('main_file', 'ultimate-shanks.php')
			: 'ultimate-shanks.php';
		$canonical_plugin_file = trim(trim($canonical_slug, '/\\') . '/' . ltrim($canonical_main_file, '/\\'), '/\\');
		$path_is_canonical = ($plugin_file === $canonical_plugin_file);

		// Forcer une requête fraîche (sans cache)
		delete_site_transient('ultimate_shanks_update_manifest_data');
		$response = wp_remote_get($manifest_url, [
			'timeout' => 15,
			'headers' => [
				'Accept'     => 'application/vnd.github.raw',
				'User-Agent' => 'WordPress-Ultimate-Shanks-Updater',
			],
		]);

		$http_code = is_wp_error($response) ? 'Erreur: ' . $response->get_error_message() : wp_remote_retrieve_response_code($response);
		$body = is_wp_error($response) ? '' : wp_remote_retrieve_body($response);
		$remote_data = json_decode($body, true);
		$remote_version = is_array($remote_data) && !empty($remote_data['version']) ? $remote_data['version'] : 'N/A';

		$updates = get_site_transient('update_plugins');
		$wp_sees_update = isset($updates->response[$plugin_file]) ? 'Oui → v' . $updates->response[$plugin_file]->new_version : 'Non';
		$wp_checked_version = isset($updates->checked[$plugin_file]) ? $updates->checked[$plugin_file] : 'N/A';

		$style_ok = 'style="color:green;font-weight:bold"';
		$style_ko = 'style="color:red;font-weight:bold"';
		?>
		<?php if (!$path_is_canonical): ?>
			<div class="notice notice-error" style="margin: 10px 0;">
				<p>
					<strong>Migration requise (bloquant)</strong> :
					ce site utilise un chemin plugin legacy (<code><?php echo esc_html($plugin_file); ?></code>).
					Réinstallez une fois le plugin pour revenir au chemin canonique
					<code><?php echo esc_html($canonical_plugin_file); ?></code>.
					Les futures mises à jour ne prennent plus en charge le renommage automatique.
				</p>
			</div>
		<?php endif; ?>
		<table class="widefat" style="max-width:600px">
			<tr><td><strong>Version installée</strong></td><td><?php echo esc_html($current_version); ?></td></tr>
			<tr><td><strong>URL manifest</strong></td><td style="word-break:break-all"><?php echo esc_html($manifest_url); ?></td></tr>
			<tr><td><strong>HTTP Status</strong></td><td <?php echo $http_code == 200 ? $style_ok : $style_ko; ?>><?php echo esc_html($http_code); ?></td></tr>
			<tr><td><strong>Version distante</strong></td><td><?php echo esc_html($remote_version); ?></td></tr>
			<tr>
				<td><strong>MAJ disponible ?</strong></td>
				<td <?php echo version_compare($current_version, $remote_version, '<') ? $style_ok : $style_ko; ?>>
					<?php echo version_compare($current_version, $remote_version, '<') ? 'Oui (' . esc_html($current_version) . ' → ' . esc_html($remote_version) . ')' : 'Non (à jour)'; ?>
				</td>
			</tr>
			<tr><td><strong>WP version connue</strong></td><td><?php echo esc_html($wp_checked_version); ?></td></tr>
			<tr><td><strong>WP détecte MAJ</strong></td><td><?php echo esc_html($wp_sees_update); ?></td></tr>
			<tr><td><strong>Chemin canonique attendu</strong></td><td><code><?php echo esc_html($canonical_plugin_file); ?></code></td></tr>
			<tr><td><strong>Chemin plugin (réel)</strong></td><td><?php echo esc_html($plugin_file); ?></td></tr>
			<tr>
				<td><strong>Chemin canonique respecté</strong></td>
				<td <?php echo $path_is_canonical ? $style_ok : $style_ko; ?>>
					<?php echo $path_is_canonical ? 'Oui' : 'Non — migration requise'; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Affiche l'onglet Options
	 */
	private static function render_options_tab()
	{
		// Récupère les options actuelles. Rank Math reste actif par défaut pour
		// préserver le comportement des installations existantes.
		$otomatic_enabled = get_option('ultimate_shanks_otomatic_enabled', '1');
		$rankmath_enabled = get_option('ultimate_shanks_rankmath_enabled', '1');

		// Vérifie si Otomatic AI est installé
		$otomatic_installed = \UltimateShanks\Integration\OtomaticIntegration::is_otomatic_installed();
		$otomatic_table_exists = \UltimateShanks\Integration\OtomaticIntegration::table_exists();
		$otomatic_plugin_file = \UltimateShanks\Integration\OtomaticIntegration::get_detected_plugin_basename();
		$otomatic_version = \UltimateShanks\Integration\OtomaticIntegration::get_detected_version();

		// Gestion du formulaire
		if (isset($_POST['ultimate_shanks_options_submit'])) {
			check_admin_referer('ultimate_shanks_options_action', 'ultimate_shanks_options_nonce');

			$otomatic_enabled = isset($_POST['ultimate_shanks_otomatic_enabled']) ? '1' : '0';
			$rankmath_enabled = isset($_POST['ultimate_shanks_rankmath_enabled']) ? '1' : '0';
			update_option('ultimate_shanks_otomatic_enabled', $otomatic_enabled);
			update_option('ultimate_shanks_rankmath_enabled', $rankmath_enabled);

			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}
		?>

		<div class="ultimate-shanks-settings-box">
			<h2>⚙️ Options et Intégrations</h2>
			<p class="description">
				Configurez les intégrations avec d'autres plugins et services.
			</p>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_options_action', 'ultimate_shanks_options_nonce'); ?>

				<table class="form-table ultimate-shanks-form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row">
								<label for="ultimate_shanks_otomatic_enabled">Intégration Otomatic AI</label>
							</th>
							<td>
								<label>
									<input
										type="checkbox"
										id="ultimate_shanks_otomatic_enabled"
										name="ultimate_shanks_otomatic_enabled"
										value="1"
										<?php checked($otomatic_enabled, '1'); ?>
									>
									Activer l'intégration avec Otomatic AI
								</label>
								<p class="description">
									Permet d'exposer les statistiques de publications planifiées d'Otomatic AI via l'API REST.
									<br><strong>Endpoint principal :</strong> <code>/wp-json/ultimate-shanks/v1/otomatic-stats</code>
									<br><strong>Endpoint Command Center :</strong> <code>/wp-json/cmd/v1/otomatic-scheduled</code>
								</p>

								<?php if ($otomatic_installed): ?>
									<p class="description" style="color: green;">
										✅ <strong>Otomatic AI détecté</strong> - Le plugin est installé et actif<?php echo $otomatic_version !== '' ? ' (version ' . esc_html($otomatic_version) . ')' : ''; ?>.
									</p>
									<?php if ($otomatic_plugin_file !== ''): ?>
										<p class="description">
											<strong>Plugin actif détecté :</strong> <code><?php echo esc_html($otomatic_plugin_file); ?></code>
										</p>
									<?php else: ?>
										<p class="description">
											<strong>Détection :</strong> via le code chargé (constante <code>OTOMATIC_AI_VERSION</code>) —
											le dossier du plugin porte un nom non standard ou il est installé en mu-plugin.
										</p>
									<?php endif; ?>
								<?php else: ?>
									<p class="description" style="color: orange;">
										⚠️ <strong>Otomatic AI non détecté</strong> - Le plugin n'est pas installé ou inactif.
									</p>
									<p class="description">
										<strong>Diagnostic :</strong>
										<?php
										$active_plugins = \UltimateShanks\Integration\OtomaticIntegration::get_active_plugins();
										$near_matches = array_filter($active_plugins, function ($file) {
											return stripos($file, 'otomatic') !== false;
										});
										if (!empty($near_matches)) {
											echo 'entrées approchantes dans les plugins actifs : <code>'
												. implode('</code>, <code>', array_map('esc_html', $near_matches))
												. '</code>.';
										} else {
											printf(
												'ni la constante <code>OTOMATIC_AI_VERSION</code> ni un plugin actif contenant '
												. '<code>otomatic</code> n\'ont été trouvés (%d plugin(s) actif(s) scanné(s)).',
												count($active_plugins)
											);
										}
										?>
									</p>
								<?php endif; ?>

								<?php if ($otomatic_table_exists): ?>
									<p class="description" style="color: green;">
										✅ <strong>Table détectée</strong> - La table <code>wp_otomatic_ai_publications</code> existe.
									</p>
								<?php else: ?>
									<p class="description" style="color: orange;">
										⚠️ <strong>Table non trouvée</strong> - La table <code>wp_otomatic_ai_publications</code> n'existe pas.
									</p>
								<?php endif; ?>

								<?php if ($otomatic_enabled === '1' && $otomatic_installed && $otomatic_table_exists): ?>
									<p class="description" style="margin-top: 10px;">
										<strong>📊 Test de l'API :</strong>
										<?php
										$count = \UltimateShanks\Integration\OtomaticIntegration::get_scheduled_count();
										echo sprintf('Il y a actuellement <strong>%d</strong> article(s) planifié(s) dans Otomatic AI.', $count);
										?>
									</p>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="ultimate_shanks_rankmath_enabled">Intégration Rank Math</label>
							</th>
							<td>
								<label>
									<input
										type="checkbox"
										id="ultimate_shanks_rankmath_enabled"
										name="ultimate_shanks_rankmath_enabled"
										value="1"
										<?php checked($rankmath_enabled, '1'); ?>
									>
									Exposer les métadonnées SEO Rank Math à WP Command Center
								</label>
								<p class="description">
									<strong>Endpoint Command Center :</strong> <code>/wp-json/cmd/v1/rankmath-keywords</code>
									<br>La route REST reste réservée aux administrateurs authentifiés.
								</p>
							</td>
						</tr>
					</tbody>
				</table>

				<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_options_submit'); ?>
			</form>
		</div>

		<div class="ultimate-shanks-info-box" style="margin-top: 20px;">
			<h3>ℹ️ À propos des intégrations</h3>
			<p>
				Ces intégrations permettent au <strong>WP Command Center</strong> de récupérer les planifications Otomatic AI
				et les métadonnées SEO Rank Math dans le tableau de bord centralisé.
			</p>

			<h4>Comment ça fonctionne ?</h4>
			<ol>
				<li>Les intégrations exposent des endpoints REST API protégés par authentification</li>
				<li>Le Command Center appelle cet endpoint pour chaque site WordPress</li>
				<li>Les articles avec <code>status='idle'</code> dans Otomatic AI sont comptés</li>
				<li>Le total est additionné aux posts WordPress planifiés (status='future')</li>
				<li>Les contenus Rank Math sont récupérés par pages de 100 éléments</li>
			</ol>

			<h4>Sécurité</h4>
			<p>
				L'endpoint nécessite une authentification par <strong>Application Password</strong>.
				Les mêmes identifiants utilisés pour synchroniser les métriques WordPress fonctionneront automatiquement.
			</p>
		</div>
		<?php
	}
}
