<?php
/**
 * Template — Page « Consultant SEO » (slug `consultant-seo`).
 *
 * Tous les contenus sont controlables depuis le metabox ACF
 * `group_evor_page_seo` (inc/acf-fields.php). Hardcodes interdits.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal" id="content">

    <?php /* ─── Hero ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-hero', null, [
        'visual_label' => 'rank.tracker',
        'visual_type'  => 'seo',
    ]); ?>

    <?php /* ─── Bénéfices (partial factorisé, partagé avec Création & Maintenance) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-benefices'); ?>

    <?php /* ─── Packs SEO ─── */ ?>
    <?php if (have_rows('packs') && evolutionr_category_has_offers('seo')):
        $packsEyebrow = (string) get_field('packs_eyebrow');
        $packsTitle   = (string) get_field('packs_title');
        $packsLede    = (string) get_field('packs_lede');
        ?>
        <section class="section section--prestation<?php echo get_field('ben_enabled') ? ' section--no-pad-top' : ''; ?>" id="packs" aria-labelledby="packs-title">
            <div class="container">

                <?php if ($packsEyebrow || $packsTitle || $packsLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($packsEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($packsEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($packsTitle): ?>
                                <h2 class="section-title" id="packs-title"><?php echo esc_html($packsTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($packsLede): ?>
                            <p class="section-lede"><?php echo esc_html($packsLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="formules-grid">
                    <?php $i = 0; while (have_rows('packs')): the_row();
                        $offer = evolutionr_offer_resolve((string) get_sub_field('offre_ref'));
                        if (!$offer['visible']) {
                            continue; // offre « actif = non » ou non liée → carte masquée
                        }
                        get_template_part('template-parts/cards/formule-card', null, [
                            'offer'       => $offer,
                            'index'       => $i,
                            'cta_default' => __('Demander un devis', 'evolutionr'),
                        ]);
                        $i++;
                    endwhile; ?>
                </div>

                <?php evolutionr_render_mid_cta(); ?>

            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── Méthode (partial factorisé, partagé avec Création & Maintenance) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-methode'); ?>

    <?php /* ─── Engagements & limites (2 colonnes) ─── */ ?>
    <?php if (get_field('promesses_enabled')):
        $hasEngagements = have_rows('engagements_list');
        $hasLimites     = have_rows('promesses_limites');
        if ($hasEngagements || $hasLimites):
            $promEyebrow = (string) get_field('promesses_eyebrow');
            $promTitle   = (string) get_field('promesses_title');
            $promLede    = (string) get_field('promesses_lede');
            ?>
            <section class="section section--prestation section--no-pad-top" aria-labelledby="promesses-title">
                <div class="container">

                    <?php if ($promEyebrow || $promTitle || $promLede): ?>
                        <div class="section-head">
                            <div class="section-head-left">
                                <?php if ($promEyebrow): ?>
                                    <div class="section-eyebrow-wrap">
                                        <span class="eyebrow"><?php echo esc_html($promEyebrow); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if ($promTitle): ?>
                                    <h2 class="section-title" id="promesses-title"><?php echo esc_html($promTitle); ?></h2>
                                <?php endif; ?>
                            </div>
                            <?php if ($promLede): ?>
                                <p class="section-lede"><?php echo esc_html($promLede); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="included-grid">
                        <?php if ($hasEngagements):
                            $engTitle = (string) get_field('engagements_title') ?: __('Ce sur quoi nous nous engageons', 'evolutionr');
                            $engSub   = (string) get_field('engagements_sub');
                            ?>
                            <div class="included-col">
                                <h3>
                                    <span class="head-badge ok"><?php evolutionr_icon('check', 16); ?></span>
                                    <?php echo esc_html($engTitle); ?>
                                </h3>
                                <?php if ($engSub): ?><p class="sub"><?php echo esc_html($engSub); ?></p><?php endif; ?>
                                <ul>
                                    <?php while (have_rows('engagements_list')): the_row();
                                        $text = (string) get_sub_field('text');
                                        if (!$text) continue;
                                        ?>
                                        <li><?php evolutionr_icon('check', 16); ?><span><?php echo esc_html($text); ?></span></li>
                                    <?php endwhile; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if ($hasLimites):
                            $limTitle = (string) get_field('limites_title') ?: __('Ce que nous ne promettons pas', 'evolutionr');
                            $limSub   = (string) get_field('limites_sub');
                            ?>
                            <div class="included-col excluded">
                                <h3>
                                    <span class="head-badge no"><?php evolutionr_icon('x', 14); ?></span>
                                    <?php echo esc_html($limTitle); ?>
                                </h3>
                                <?php if ($limSub): ?><p class="sub"><?php echo esc_html($limSub); ?></p><?php endif; ?>
                                <ul>
                                    <?php while (have_rows('promesses_limites')): the_row();
                                        $text = (string) get_sub_field('text');
                                        if (!$text) continue;
                                        ?>
                                        <li><?php evolutionr_icon('x', 16); ?><span><?php echo esc_html($text); ?></span></li>
                                    <?php endwhile; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </section>
        <?php endif;
    endif; ?>

    <?php /* ─── FAQ ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-faq'); ?>

    <?php /* ─── CTA final ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-cta-final'); ?>

</main>

<?php get_footer(); ?>
