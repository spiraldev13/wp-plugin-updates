<?php
/**
 * Text Enhancer - Optimiseur de Paragraphes
 *
 * Ce fichier gère la logique principale de découpage automatique des paragraphes.
 * Hook : the_content (priorité 20)
 *
 * Assets associés :
 * - CSS Metabox : /assets/css/text-enhancer-metabox.css (styles metabox admin)
 *
 * Fichiers liés :
 * - processor.php : Moteur de traitement (découpage des paragraphes)
 * - settings.php  : Interface admin (configuration)
 *
 * @package UltimateShanks\TextEnhancer
 */

namespace UltimateShanks\TextEnhancer;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Classe principale Optimiseur de Paragraphes
 *
 * @package UltimateShanks
 * @subpackage TextEnhancer
 */
class TextEnhancer
{
	/**
	 * Cache local des options (durée de la requête courante).
	 *
	 * @var array<string, mixed>
	 */
	private static $option_cache = [];

	/**
	 * Cache local des meta post (durée de la requête courante).
	 *
	 * @var array<int, array<string, string>>
	 */
	private static $post_meta_cache = [];

	/**
	 * Cache local des catégories par post.
	 *
	 * @var array<int, array<int, int>>
	 */
	private static $post_categories_cache = [];

	/**
	 * Cache des règles d'exclusion globales.
	 *
	 * @var array<string, mixed>|null
	 */
	private static $exclusion_settings_cache = null;

	/**
	 * Retourne une option en cache local.
	 *
	 * @param string $key Clé option.
	 * @param mixed $default Valeur par défaut.
	 * @return mixed
	 */
	private static function get_cached_option($key, $default = '')
	{
		if (!array_key_exists($key, self::$option_cache)) {
			self::$option_cache[$key] = get_option($key, $default);
		}

		return self::$option_cache[$key];
	}

	/**
	 * Retourne une meta post en cache local.
	 *
	 * @param int $post_id ID du post.
	 * @param string $meta_key Clé meta.
	 * @return string
	 */
	private static function get_cached_post_meta($post_id, $meta_key)
	{
		$post_id = (int) $post_id;

		if (!isset(self::$post_meta_cache[$post_id])) {
			self::$post_meta_cache[$post_id] = [];
		}

		if (!array_key_exists($meta_key, self::$post_meta_cache[$post_id])) {
			self::$post_meta_cache[$post_id][$meta_key] = (string) get_post_meta($post_id, $meta_key, true);
		}

		return self::$post_meta_cache[$post_id][$meta_key];
	}

	/**
	 * Retourne les catégories d'un post en cache local.
	 *
	 * @param int $post_id ID du post.
	 * @return array<int, int>
	 */
	private static function get_cached_post_categories($post_id)
	{
		$post_id = (int) $post_id;

		if (!isset(self::$post_categories_cache[$post_id])) {
			self::$post_categories_cache[$post_id] = wp_get_post_categories($post_id);
		}

		return self::$post_categories_cache[$post_id];
	}

	/**
	 * Retourne les réglages d'exclusion globaux pré-normalisés.
	 *
	 * @return array<string, mixed>
	 */
	private static function get_exclusion_settings()
	{
		if (self::$exclusion_settings_cache !== null) {
			return self::$exclusion_settings_cache;
		}

		$excluded_post_types = self::get_cached_option('ultimate_shanks_text_enhancer_excluded_post_types', []);
		if (!is_array($excluded_post_types)) {
			$excluded_post_types = [];
		}

		$excluded_ids_raw = (string) self::get_cached_option('ultimate_shanks_text_enhancer_excluded_ids', '');
		$excluded_ids = array_values(array_filter(array_map('intval', array_map('trim', explode(',', $excluded_ids_raw)))));

		$excluded_slugs_raw = (string) self::get_cached_option('ultimate_shanks_text_enhancer_excluded_slugs', '');
		$excluded_slugs = array_values(array_filter(array_map('trim', explode(',', $excluded_slugs_raw))));

		$excluded_categories = self::get_cached_option('ultimate_shanks_text_enhancer_excluded_categories', []);
		if (!is_array($excluded_categories)) {
			$excluded_categories = [];
		}
		$excluded_categories = array_values(array_filter(array_map('intval', $excluded_categories)));

		$excluded_keywords_raw = (string) self::get_cached_option('ultimate_shanks_text_enhancer_excluded_keywords', '');
		$excluded_keywords = array_values(array_filter(array_map('trim', explode(',', $excluded_keywords_raw))));

		self::$exclusion_settings_cache = [
			'post_types' => $excluded_post_types,
			'ids' => $excluded_ids,
			'slugs' => $excluded_slugs,
			'categories' => $excluded_categories,
			'keywords' => $excluded_keywords,
		];

		return self::$exclusion_settings_cache;
	}

	/**
	 * Initialise la fonctionnalité
	 */
	public static function init()
	{
		// Toujours charger la metabox et les scripts admin
		add_action('add_meta_boxes', [self::class, 'register_metabox']);
		add_action('save_post', [self::class, 'save_metabox']);
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_metabox_scripts']);

		// Charger le CSS de debug sur le frontend si activé
		if (get_option('ultimate_shanks_text_enhancer_debug_mode', '0') === '1') {
			add_action('wp_head', [self::class, 'output_debug_css']);
		}

		// Appliquer le filtre sur the_content
		add_filter('the_content', [self::class, 'process_content'], 20);
	}

	/**
	 * Traite le contenu de l'article
	 *
	 * @param string $content Contenu de l'article
	 * @return string Contenu traité
	 */
	public static function process_content($content)
	{
		$profile_start = \UltimateShanks\Core\Profiler::start('text_enhancer.process_content');
		$post_id = 0;

		try {
			global $post;

			// Ne pas traiter si pas dans une boucle
			if (!$post) {
				return $content;
			}

			$post_id = (int) $post->ID;

			// Vérifier les exclusions globales
			if (self::is_excluded($post)) {
				return $content;
			}

			// Récupérer les paramètres
			$global_enabled = self::get_cached_option('ultimate_shanks_text_enhancer_enabled', '0') === '1';
			$mode = (string) self::get_cached_option('ultimate_shanks_text_enhancer_mode', 'standard');
			$enable_for_post = self::get_cached_post_meta($post->ID, '_ultimate_shanks_text_enhancer_enable') === '1';
			$disable_for_post = self::get_cached_post_meta($post->ID, '_ultimate_shanks_text_enhancer_disable') === '1';

			// Si désactivation explicite pour cet article, ne pas traiter
			if ($disable_for_post) {
				return $content;
			}

			// Logique d'activation :
			// - Si global activé : traiter selon le mode (standard/conservative/manual)
			// - Si global désactivé : traiter uniquement si metabox cochée
			$should_process = false;

			if ($global_enabled) {
				// Global activé : vérifier le mode
				if ($mode === 'manual') {
					// Mode manuel : uniquement si metabox cochée
					$should_process = $enable_for_post;
				} else {
					// Mode standard ou conservative : toujours traiter
					$should_process = true;
				}
			} else {
				// Global désactivé : uniquement si metabox cochée
				$should_process = $enable_for_post;
			}

			// Ne pas traiter si condition pas remplie
			if (!$should_process) {
				return $content;
			}

			// Récupérer les options
			$options = self::get_processing_options();

			// Appliquer le traitement des paragraphes
			$split_start = \UltimateShanks\Core\Profiler::start('text_enhancer.split_long_paragraphs');
			$content = Processor::split_long_paragraphs($content, $options);
			\UltimateShanks\Core\Profiler::stop('text_enhancer.split_long_paragraphs', $split_start, [
				'post_id' => $post_id,
			]);

			// Appliquer les corrections SEO
			$seo_options = self::get_seo_options($post);
			$seo_start = \UltimateShanks\Core\Profiler::start('text_enhancer.apply_seo_corrections');
			$content = Processor::apply_seo_corrections($content, $seo_options);
			\UltimateShanks\Core\Profiler::stop('text_enhancer.apply_seo_corrections', $seo_start, [
				'post_id' => $post_id,
			]);

			return $content;
		} finally {
			\UltimateShanks\Core\Profiler::stop('text_enhancer.process_content', $profile_start, [
				'post_id' => $post_id,
			]);
		}
	}

	/**
	 * Vérifie si un post est exclu
	 *
	 * @param \WP_Post $post Post à vérifier
	 * @return bool True si exclu
	 */
	private static function is_excluded($post)
	{
		$settings = self::get_exclusion_settings();

		// Exclure par post type
		if (in_array($post->post_type, $settings['post_types'], true)) {
			return true;
		}

		// Exclure par ID
		if (in_array((int) $post->ID, $settings['ids'], true)) {
			return true;
		}

		// Exclure par slug
		if (in_array($post->post_name, $settings['slugs'], true)) {
			return true;
		}

		// Exclure par catégorie
		if (!empty($settings['categories'])) {
			$post_categories = self::get_cached_post_categories($post->ID);
			if (array_intersect($post_categories, $settings['categories'])) {
				return true;
			}
		}

		// Vérifier les mots-clés d'exclusion
		if (!empty($settings['keywords'])) {
			foreach ($settings['keywords'] as $keyword) {
				if (stripos($post->post_content, $keyword) !== false) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Récupère les options de traitement
	 *
	 * @return array Options
	 */
	private static function get_processing_options()
	{
		return [
			'min_length' => (int) self::get_cached_option('ultimate_shanks_text_enhancer_min_length', 400),
			'sentences_per_paragraph' => (int) self::get_cached_option('ultimate_shanks_text_enhancer_sentences_per_p', 2),
			'line_breaks' => (int) self::get_cached_option('ultimate_shanks_text_enhancer_line_breaks', 0),
			'ignore_links' => self::get_cached_option('ultimate_shanks_text_enhancer_ignore_links', '0') === '1',
			'ignore_shortcodes' => self::get_cached_option('ultimate_shanks_text_enhancer_ignore_shortcodes', '1') === '1',
			'ignore_classes' => array_map('trim', explode(',', (string) self::get_cached_option('ultimate_shanks_text_enhancer_ignore_classes', ''))),
			'debug_mode' => self::get_cached_option('ultimate_shanks_text_enhancer_debug_mode', '0') === '1',
		];
	}

	/**
	 * Récupère les options SEO
	 *
	 * @param \WP_Post $post Post actuel
	 * @return array Options SEO
	 */
	private static function get_seo_options($post)
	{
		$remove_hr = self::get_cached_option('ultimate_shanks_text_enhancer_remove_hr', '0') === '1';
		$keep_hr_for_post = self::get_cached_post_meta($post->ID, '_ultimate_shanks_text_enhancer_keep_hr') === '1';

		// Si l'option globale est active ET que l'article ne demande pas de conserver les HR
		$should_remove_hr = $remove_hr && !$keep_hr_for_post;

		return [
			'fix_em_dash' => self::get_cached_option('ultimate_shanks_text_enhancer_fix_em_dash', '1') === '1',
			'remove_hr' => $should_remove_hr,
		];
	}

	/**
	 * Enregistre la metabox
	 */
	public static function register_metabox()
	{
		$post_types = ['post', 'page'];

		add_meta_box(
			'ultimate_shanks_text_enhancer',
			'Optimiseur de Paragraphes',
			[self::class, 'render_metabox'],
			$post_types,
			'side',
			'default'
		);
	}

	/**
	 * Affiche la metabox
	 *
	 * @param \WP_Post $post Post actuel
	 */
	public static function render_metabox($post)
	{
		wp_nonce_field('ultimate_shanks_text_enhancer_metabox', 'ultimate_shanks_text_enhancer_nonce');

		$enabled = get_post_meta($post->ID, '_ultimate_shanks_text_enhancer_enable', true);
		$disabled = get_post_meta($post->ID, '_ultimate_shanks_text_enhancer_disable', true);
		$keep_hr = get_post_meta($post->ID, '_ultimate_shanks_text_enhancer_keep_hr', true);
		$global_enabled = get_option('ultimate_shanks_text_enhancer_enabled', '0') === '1';
		$mode = get_option('ultimate_shanks_text_enhancer_mode', 'standard');
		$remove_hr_enabled = get_option('ultimate_shanks_text_enhancer_remove_hr', '0') === '1';
		?>
		<div class="ultimate-shanks-text-enhancer-metabox">
			<?php if ($global_enabled && $mode !== 'manual'): ?>
				<!-- Mode Standard/Conservateur : option de désactivation -->
				<p>
					<label>
						<input
							type="checkbox"
							name="ultimate_shanks_text_enhancer_disable"
							value="1"
							<?php checked($disabled, '1'); ?>
						>
						<strong>Désactiver</strong> l'optimisation pour cet article
					</label>
				</p>
				<p class="description">
					Par défaut, l'optimisation est active globalement. Cochez cette case pour désactiver le traitement sur cet article uniquement.
				</p>
			<?php else: ?>
				<!-- Mode Manuel ou global désactivé : option d'activation -->
				<p>
					<label>
						<input
							type="checkbox"
							name="ultimate_shanks_text_enhancer_enable"
							value="1"
							<?php checked($enabled, '1'); ?>
						>
						Activer l'optimisation pour cet article
					</label>
				</p>
				<p class="description">
					Les paragraphes longs seront automatiquement découpés selon les paramètres configurés dans Ultimate Shanks → Optimiseur de Paragraphes.
				</p>
			<?php endif; ?>

			<?php if ($remove_hr_enabled): ?>
				<!-- Option de conservation des HR si la suppression globale est activée -->
				<hr style="margin: 15px 0; border: none; border-top: 1px solid #ddd;">
				<p>
					<label>
						<input
							type="checkbox"
							name="ultimate_shanks_text_enhancer_keep_hr"
							value="1"
							<?php checked($keep_hr, '1'); ?>
						>
						<strong>Conserver</strong> les séparateurs (HR) pour cet article
					</label>
				</p>
				<p class="description">
					La suppression des séparateurs est activée globalement. Cochez cette case pour les conserver sur cet article uniquement.
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Sauvegarde la metabox
	 *
	 * @param int $post_id ID du post
	 */
	public static function save_metabox($post_id)
	{
		// Vérifications de sécurité
		if (!isset($_POST['ultimate_shanks_text_enhancer_nonce'])) {
			return;
		}

		if (!wp_verify_nonce($_POST['ultimate_shanks_text_enhancer_nonce'], 'ultimate_shanks_text_enhancer_metabox')) {
			return;
		}

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		// Sauvegarder les valeurs
		$enabled = isset($_POST['ultimate_shanks_text_enhancer_enable']) ? '1' : '0';
		update_post_meta($post_id, '_ultimate_shanks_text_enhancer_enable', $enabled);

		$disabled = isset($_POST['ultimate_shanks_text_enhancer_disable']) ? '1' : '0';
		update_post_meta($post_id, '_ultimate_shanks_text_enhancer_disable', $disabled);

		$keep_hr = isset($_POST['ultimate_shanks_text_enhancer_keep_hr']) ? '1' : '0';
		update_post_meta($post_id, '_ultimate_shanks_text_enhancer_keep_hr', $keep_hr);
	}

	/**
	 * Charge les scripts de la metabox
	 *
	 * @param string $hook Hook actuel
	 */
	public static function enqueue_metabox_scripts($hook)
	{
		if (!in_array($hook, ['post.php', 'post-new.php'])) {
			return;
		}

		wp_enqueue_style(
			'ultimate-shanks-text-enhancer-metabox',
			MP_URL . 'assets/css/text-enhancer-metabox.css',
			[],
			'1.0.0'
		);
	}

	/**
	 * Affiche le CSS de debug dans le header du site
	 */
	public static function output_debug_css()
	{
		?>
		<style id="ultimate-shanks-text-enhancer-debug">
			/* Styles pour le mode debug de l'Optimiseur de Paragraphes */
			.te-debug-highlight {
				outline: 3px solid #ff6600 !important;
				background-color: rgba(255, 102, 0, 0.08) !important;
				position: relative !important;
				margin: 15px 0 !important;
				padding: 15px !important;
			}
			.te-debug-highlight::before {
				content: "✂️ Optimiseur de Paragraphes - Paragraphe découpé";
				display: block;
				background: #ff6600;
				color: white;
				font-size: 11px;
				font-weight: bold;
				padding: 4px 8px;
				margin: -15px -15px 10px -15px;
				border-radius: 3px 3px 0 0;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
			}
		</style>
		<?php
	}
}
