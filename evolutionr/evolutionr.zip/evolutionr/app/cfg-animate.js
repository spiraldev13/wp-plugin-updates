/**
 * Configurateur tarifs Evolution'R — module d'animation unique.
 *
 * Remplace les 6 mécaniques d'animation éparses par UN seul jeu d'helpers, partageant
 * une même horloge (tokens `--cfg-dur` / `--cfg-ease`) et un seul garde reduced-motion.
 *
 * Contrat :
 *   · ouverture/fermeture d'une zone  → reveal() / collapse()   (hauteur, via WAAPI)
 *   · défilement d'un nombre (prix)   → countUp()
 *   · « réduire les animations »       → prefersReducedMotion() → état final immédiat
 *
 * Toutes les animations sont ANNULABLES : le handle est stocké sur l'élément
 * (`el._cfgAnim`) et annulé avant toute relance → pas de panneau resté bloqué, pas de
 * styles inline résiduels (WAAPI ne persiste rien après la fin, fill: 'none' par défaut).
 */

const DUR_FALLBACK = 320;                                  // ms
const EASE_FALLBACK = 'cubic-bezier(0.4, 0, 0.2, 1)';

/** Vrai si l'utilisateur a demandé à réduire les animations (garde unique). */
export function prefersReducedMotion() {
    return typeof window.matchMedia === 'function'
        && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/** Lit un token CSS hérité (`--cfg-*`) depuis l'élément ; repli sur la valeur par défaut. */
function readToken(el, name, fallback) {
    const raw = el ? getComputedStyle(el).getPropertyValue(name).trim() : '';
    return raw || fallback;
}
/** Durée en ms depuis `--cfg-dur` (« 320ms » | « 0.32s »), repli 320. */
function duration(el) {
    const raw = readToken(el, '--cfg-dur', '');
    if (!raw) return DUR_FALLBACK;
    if (raw.endsWith('ms')) return parseFloat(raw) || DUR_FALLBACK;
    if (raw.endsWith('s')) return (parseFloat(raw) || DUR_FALLBACK / 1000) * 1000;
    return parseFloat(raw) || DUR_FALLBACK;
}
function easing(el) {
    return readToken(el, '--cfg-ease', EASE_FALLBACK);
}

/**
 * Gap (rangée) du conteneur flex/grid parent, en px (0 sinon). Le `gap` n'appartient pas à
 * l'élément mais au parent : il apparaît/disparaît D'UN COUP à l'insertion/au retrait de
 * l'élément (pas d'animation possible côté gap). reveal/collapse l'absorbent via une marge
 * négative animée, pour que l'ouverture/fermeture d'une ligne reste continue (zéro saut).
 */
function parentRowGap(el) {
    const p = el && el.parentElement;
    if (!p) return 0;
    const cs = getComputedStyle(p);
    if (!cs.display.includes('flex') && !cs.display.includes('grid')) return 0;
    return parseFloat(cs.rowGap) || 0;
}

/** Annule proprement l'animation en cours sur l'élément (si présente). */
function cancelAnim(el) {
    if (el._cfgAnim) {
        try { el._cfgAnim.cancel(); } catch (e) { /* déjà terminée */ }
        el._cfgAnim = null;
    }
}

/**
 * Déploie un élément de hauteur 0 → sa hauteur naturelle (+ padding + fondu) : ce qui le
 * SUIT descend en douceur. WAAPI ne persistant rien après la fin, l'élément retrouve son
 * style CSS naturel automatiquement (aucun nettoyage de hauteur à faire).
 */
export function reveal(el) {
    if (!el) return;
    cancelAnim(el);
    // Repart d'un état propre (l'élément peut sortir d'un collapse remove:false / hidden).
    el.hidden = false;
    ['height', 'padding-top', 'padding-bottom', 'margin-top', 'margin-bottom', 'opacity', 'overflow']
        .forEach((p) => el.style.removeProperty(p));
    if (prefersReducedMotion()) return;

    const cs = getComputedStyle(el);
    const padT = cs.paddingTop;
    const padB = cs.paddingBottom;
    const gap = parentRowGap(el); // le gap du parent surgit d'un coup à l'insertion : on le neutralise
    const target = el.getBoundingClientRect().height; // hauteur naturelle (border-box)
    el.style.overflow = 'hidden';

    const anim = el.animate(
        [
            { height: '0px', opacity: 0, paddingTop: '0px', paddingBottom: '0px', marginBottom: `${-gap}px` },
            { height: `${target}px`, opacity: 1, paddingTop: padT, paddingBottom: padB, marginBottom: '0px' },
        ],
        { duration: duration(el), easing: easing(el) },
    );
    el._cfgAnim = anim;
    anim.finished.then(() => {
        if (el._cfgAnim === anim) el._cfgAnim = null;
        el.style.removeProperty('overflow');
    }).catch(() => { /* annulée → une autre anim a pris le relais */ });
}

/**
 * Replie un élément de sa hauteur courante → 0 (hauteur + padding + marges + fondu) : ce
 * qui le suit REMONTE en douceur. Par défaut l'élément est RETIRÉ du DOM à la fin
 * (`remove: true`) ; `onDone` est appelé dans tous les cas. Réduire les animations →
 * effet immédiat (pas de transition).
 *
 * @param {HTMLElement} el
 * @param {{ remove?: boolean, onDone?: () => void }} [opts]
 */
export function collapse(el, opts = {}) {
    const { remove = true, onDone } = opts;
    if (!el) { if (onDone) onDone(); return; }
    cancelAnim(el);

    const finish = () => {
        if (remove) el.remove();
        else { el.style.overflow = 'hidden'; el.style.height = '0px'; }
        if (onDone) onDone();
    };
    if (prefersReducedMotion()) { finish(); return; }

    const cs = getComputedStyle(el);
    const start = el.getBoundingClientRect().height;
    const gap = parentRowGap(el); // le gap du parent disparaîtra au retrait : on l'absorbe (marge négative)
    el.style.overflow = 'hidden';

    const anim = el.animate(
        [
            {
                height: `${start}px`, opacity: 1,
                paddingTop: cs.paddingTop, paddingBottom: cs.paddingBottom,
                marginTop: cs.marginTop, marginBottom: cs.marginBottom,
            },
            {
                height: '0px', opacity: 0,
                paddingTop: '0px', paddingBottom: '0px',
                marginTop: '0px', marginBottom: `${-gap}px`,
            },
        ],
        { duration: duration(el), easing: easing(el), fill: 'forwards' },
    );
    el._cfgAnim = anim;
    anim.finished.then(() => {
        if (el._cfgAnim === anim) el._cfgAnim = null;
        finish();
        // Libère le `fill: 'forwards'` une fois l'état collapsed figé autrement (élément retiré,
        // ou hidden + height:0 inline). Sinon, pour un bloc GARDÉ (remove:false), le fill continue
        // d'imposer height:0 même après `_cfgAnim = null` → un reveal ultérieur mesurerait une
        // hauteur cible nulle et rouvrirait le bloc sur du vide (cf. bug retour de service).
        anim.cancel();
    }).catch(() => { /* annulée → une autre anim a pris le relais */ });
}

/**
 * Échange le contenu d'un conteneur en animant sa HAUTEUR de l'ancienne à la nouvelle
 * (ce qui suit ne saute pas) + léger fondu du nouveau contenu. `buildFn` remplit le
 * conteneur (typiquement via innerHTML). Reduced-motion ou hauteur inchangée →
 * remplacement direct sans animation.
 */
export function swapHeight(container, buildFn) {
    if (!container) return;
    if (prefersReducedMotion()) { buildFn(); return; }
    const from = container.getBoundingClientRect().height;
    buildFn();
    const to = container.getBoundingClientRect().height;
    if (Math.abs(from - to) < 1) return; // pas de variation de hauteur → rien à animer
    cancelAnim(container);
    container.style.overflow = 'hidden';
    const anim = container.animate(
        [{ height: `${from}px`, opacity: 0.4 }, { height: `${to}px`, opacity: 1 }],
        { duration: duration(container), easing: easing(container) },
    );
    container._cfgAnim = anim;
    anim.finished.then(() => {
        if (container._cfgAnim === anim) container._cfgAnim = null;
        container.style.removeProperty('overflow');
    }).catch(() => { /* annulée */ });
}

/**
 * Défilement d'un nombre `from` → `to` (count-up), aligné sur l'horloge commune. Le prix
 * « glisse » au lieu de sauter. `from` nul ou égal à `to` → écrit directement la cible.
 *
 * @param {HTMLElement} el
 * @param {number|null} from
 * @param {number} to
 * @param {(v:number)=>string} format
 */
export function countUp(el, from, to, format) {
    if (!el) return;
    if (from == null || from === to || prefersReducedMotion()) { el.textContent = format(to); return; }
    const dur = duration(el);
    const start = performance.now();
    const tick = (now) => {
        const t = Math.min(1, (now - start) / dur);
        const eased = 1 - Math.pow(1 - t, 3); // easeOutCubic
        el.textContent = format(Math.round(from + (to - from) * eased));
        if (t < 1) requestAnimationFrame(tick);
        else el.textContent = format(to);
    };
    requestAnimationFrame(tick);
}
