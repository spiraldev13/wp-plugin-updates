<?php
/**
 * Title: Unité article — surimpression
 * Slug: techana-revue/unite-surimpression
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Mosaïque de l'accueil — image 3:2, voile encre, rubrique et titre en surimpression.
 * Viewport Width: 500
 */
?>
<!-- wp:group {"className":"mo k-auto"} -->
<div class="wp-block-group mo k-auto"><!-- wp:post-featured-image {"sizeSlug":"techana-3-2","className":"ph-auto"} /-->

<!-- wp:group {"className":"mo-txt"} -->
<div class="wp-block-group mo-txt"><!-- wp:post-terms {"term":"category","className":"mo-cat"} /-->

<!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:paragraph {"className":"mo-date","metadata":{"bindings":{"content":{"source":"techana/meta-carte"}}}} -->
<p class="mo-date"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
