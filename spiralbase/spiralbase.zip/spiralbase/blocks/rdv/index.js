/**
 * Bloc spiralbase/rdv — JS éditeur écrit à la main, SANS build (AD-12).
 *
 * Bloc dynamique sans enfants : `save()` rend null, tout le HTML vient du
 * serveur. L'édition est directe (RichText sur le libellé et l'accroche),
 * habillée par la MÊME feuille que le front : ce que voit l'opérateur est ce
 * qu'il aura. Pas de ServerSideRender — l'URL vit dans les réglages du site,
 * l'aperçu n'apprendrait rien de plus qu'un rendu local.
 */
( function ( blocks, element, blockEditor, components, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    /* Miroir de Core\TexteRiche::AUTORISE. */
    var FORMATS = [
        'core/bold',
        'core/italic',
        'core/strikethrough',
        'core/subscript',
        'core/superscript',
    ];

    var VARIANTES = [
        { value: 'bouton', label: __( 'Bouton', 'spiralbase' ) },
        { value: 'bandeau', label: __( 'Bandeau pleine largeur', 'spiralbase' ) },
        { value: 'carte', label: __( 'Carte avec accroche', 'spiralbase' ) },
    ];

    blocks.registerBlockType( 'spiralbase/rdv', {
        edit: function ( props ) {
            var variante = props.attributes.variante || 'bouton';

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-rdv spiralbase-rdv--' + variante,
            } );

            return e(
                element.Fragment,
                null,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages du rendez-vous', 'spiralbase' ) },
                        e( components.SelectControl, {
                            label: __( 'Présentation', 'spiralbase' ),
                            value: variante,
                            options: VARIANTES,
                            onChange: function ( valeur ) {
                                props.setAttributes( { variante: valeur } );
                            },
                        } ),
                        e( components.TextControl, {
                            label: __( 'Adresse de réservation (facultatif)', 'spiralbase' ),
                            help: __(
                                'Laissez vide pour utiliser l’adresse enregistrée pour tout le site. À renseigner seulement si CE bouton doit pointer ailleurs.',
                                'spiralbase'
                            ),
                            type: 'url',
                            value: props.attributes.url,
                            onChange: function ( valeur ) {
                                props.setAttributes( { url: valeur } );
                            },
                        } )
                    )
                ),
                e(
                    'div',
                    blockProps,
                    variante === 'bouton'
                        ? null
                        : e( blockEditor.RichText, {
                            tagName: 'p',
                            className: 'spiralbase-rdv__accroche',
                            allowedFormats: FORMATS,
                            value: props.attributes.accroche,
                            placeholder: __( 'Accroche (facultative)', 'spiralbase' ),
                            onChange: function ( valeur ) {
                                props.setAttributes( { accroche: valeur } );
                            },
                        } ),
                    e( blockEditor.RichText, {
                        tagName: 'span',
                        className: 'spiralbase-rdv__lien wp-element-button',
                        allowedFormats: FORMATS,
                        value: props.attributes.libelle,
                        placeholder: __( 'Prendre rendez-vous', 'spiralbase' ),
                        onChange: function ( valeur ) {
                            props.setAttributes( { libelle: valeur } );
                        },
                    } )
                )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n
);
