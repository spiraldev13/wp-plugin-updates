# Popup Spiral

Popups WordPress simples et élégants : ciblage en 1 clic, planification par dates,
designs préconfigurés, **panneau de statistiques**, **prévisualisation sécurisée**,
**presets réutilisables** — compatible Divi et Elementor, sans aucune dépendance
côté front.

- **Aucune usine à gaz** : chaque réglage est un clic (cases, cartes, pastilles).
- **Prêt à l'emploi** : un popup créé sans rien toucher fonctionne déjà (design
  Annonce, centré, ouverture après 2 s, une fois tous les 30 jours) — il ne reste
  qu'à **cocher où l'afficher**.
- **RGPD par conception** : cookie fonctionnel exempté de consentement, compteurs
  100 % anonymes.

---

## Sommaire

- [Prise en main rapide](#prise-en-main-rapide)
- [L'éditeur d'un popup](#léditeur-dun-popup)
  - [Onglet Affichage](#onglet-affichage)
  - [Onglet Déclencheurs](#onglet-déclencheurs)
  - [Onglet Ciblage](#onglet-ciblage)
  - [Onglet Planification](#onglet-planification)
- [Ouvrir un popup depuis un bouton](#ouvrir-un-popup-depuis-un-bouton-divi-elementor-menu)
- [Les designs](#les-designs)
- [Presets de configuration](#presets-de-configuration)
- [Réglages globaux](#réglages-globaux)
- [La liste des popups](#la-liste-des-popups)
- [Prévisualisation sécurisée](#prévisualisation-sécurisée)
- [Panneau de statistiques](#panneau-de-statistiques)
- [Compteurs de vues et de clics](#compteurs-de-vues-et-de-clics)
- [Compatibilité Divi et Elementor](#compatibilité-divi-et-elementor)
- [RGPD](#rgpd)
- [Personnalisation développeur](#personnalisation-développeur)
- [Prérequis](#prérequis)
- [Mises à jour automatiques](#mises-à-jour-automatiques)
- [Désinstallation](#désinstallation)
- [Référence technique (metas & options)](#référence-technique-metas--options)

---

## Prise en main rapide

1. **Popups → Ajouter** : donnez un titre et écrivez le contenu dans l'éditeur.
2. Onglet **Affichage** : choisissez un design, une position à l'écran, éventuellement
   une image et un bouton d'action.
3. Onglet **Ciblage** : cochez une ou plusieurs cibles (⚠️ **aucune case cochée =
   popup inactif**).
4. **Publiez**. Un lien **Tester** apparaît sur la ligne du popup pour le voir
   immédiatement sur une page réelle, sans attendre le déclencheur ni le cookie.

---

## L'éditeur d'un popup

Le **titre** et le **contenu** viennent de l'éditeur WordPress standard. Tous les
autres réglages sont regroupés dans la metabox « Réglages du popup », répartie en
**4 onglets**.

### Onglet Affichage

#### Quel design ?
Galerie de vignettes. Choix parmi les **6 designs fournis** (voir
[Les designs](#les-designs)) et vos designs personnels. Le design fixe l'apparence
complète : couleurs, coins, ombre, police, style et position de la croix, et le
**type de fond** (assombri, flouté ou aucun). *Défaut : Annonce.*

#### Où sur l'écran ?
Grille 3×3 de 9 positions + 2 barres pleine largeur :

| Grille | | | Barres |
|---|---|---|---|
| En haut à gauche | En haut au centre | En haut à droite | Barre flottante en haut |
| Au centre à gauche | **Au centre** *(défaut)* | Au centre à droite | Barre flottante en bas |
| En bas à gauche | En bas au centre | En bas à droite | |

#### Quelle taille ?
- **Automatique** (selon le contenu, *défaut*), **Petit (360 px)**, **Moyen (560 px)**,
  **Grand (820 px)**.
- Vos **tailles réutilisables** créées dans les Réglages apparaissent aussi ici.
- **Personnalisée (ponctuelle)** : largeur en pixels (200–2000, défaut 560).
- Toutes les largeurs sont **plafonnées à la largeur de l'écran** (jamais de
  débordement mobile).

#### Hauteur
**Automatique** (*défaut*) ou **Personnalisée** (hauteur en pixels 100–2000, défaut
400, avec scroll de secours si le contenu déborde).

#### Taille du texte
Corps du texte de 10 à 40 px (*défaut 16*). Les titres s'adaptent proportionnellement.

#### Position du texte
**En haut** *(défaut)* / **Au centre** / **En bas** — aligne verticalement le contenu.
Utile uniquement quand une hauteur personnalisée laisse de l'espace libre.

#### Une image ?
- **Disposition** : Aucune, Bannière en haut, **À gauche** *(défaut)*, À droite, En fond.
- **Média** : choix dans la médiathèque, aperçu, bouton « Retirer l'image ».
- **Synchro** : l'image choisie ici **est aussi l'image mise en avant** du popup, et
  réciproquement (dans les deux sens, y compris via l'éditeur de blocs).
- **Largeur de l'image** : Pleine 100 %, Grande 75 %, Moitié 50 %, Petite 25 % + vos
  largeurs personnalisées (Réglages). Pour une image à gauche/droite, plafonnée à la
  moitié du popup.
- **Espacement autour de l'image** : Aucun, **Petit 12 px** *(défaut)*, Moyen 24 px,
  Personnalisé (0–100 px).
- **Bordure autour de l'image** : Aucune *(défaut)*, Fine 1 px, Épaisse 3 px,
  Personnalisée (1–20 px) + couleur (défaut `#e2e8f0`).

#### Un bouton d'action ?
Désactivé par défaut. Une fois activé :
- **Texte du bouton**.
- **Destination** : vers une page du site (avec option **Page d'accueil**) ou vers une
  **adresse web (URL)**.
- **Position** : À gauche / **Au milieu** *(défaut)* / À droite.
- **Taille du texte du bouton** : 10–40 px (*défaut 16*).
- **Ouvrir dans un nouvel onglet**.

#### Quel contenu ? *(visible si Elementor est actif)*
Utiliser **l'éditeur ci-dessus** *(défaut)* ou **un template Elementor** rendu avec ses
styles (repli automatique sur l'éditeur si le template est supprimé).

#### Avancé
- **Z-index** : niveau de superposition (défaut `1999999999`). À ne changer que si le
  popup passe sous un élément du site.

### Onglet Déclencheurs

**Quand l'afficher ?** — trois modes cumulables :

| Mode | Défaut | Paramètre |
|---|---|---|
| **Après un délai** | Activé | Ouverture après N secondes (0–600, défaut 2) |
| **Au clic sur un bouton/lien** | Activé | Classe `spiral-{ID}`, ancre `#spiral-{ID}`, ou sélecteur CSS libre |
| **À l'intention de sortie (exit-intent)** | Désactivé | Ordinateur uniquement ; sur mobile, le délai prend le relais |

Un **clic déclencheur explicite passe outre le cookie de fréquence** (mais respecte
toujours la planification).

**Fermeture** — *Ne pas fermer en cliquant à l'extérieur* (désactivé par défaut). Une
fois coché, seuls la croix et la touche **Échap** ferment le popup — utile pour une
action importante. Sans effet si le fond du design est réglé sur « Aucun ».

**À quelle fréquence ?**

| Option | Comportement |
|---|---|
| À chaque visite | Aucun cookie, réaffiché à chaque page |
| Une fois par session | Cookie effacé à la fermeture du navigateur |
| **Une fois tous les N jours** *(défaut, N = 30)* | Cookie valable N jours (1–395) |
| Une seule fois (ne plus jamais montrer) | Cookie valable 1 an |

Le cookie `spiral_popup_{ID}` est posé **à la fermeture** du popup (croix, fond ou
Échap). Plafond de 395 jours (~13 mois, limite CNIL).

### Onglet Ciblage

**Où l'afficher ?** — cochez une ou plusieurs cibles (logique **OU** : le popup
s'affiche dès qu'une cible correspond). **Aucune case cochée = popup inactif.**

- **Tout le site** — partout.
- **Page d'accueil** — uniquement la page d'accueil.
- **Pages spécifiques** — liste à cocher de toutes les pages.
- **Articles spécifiques** — recherche par titre avec autocomplétion (puces).
- **Catégories** — la page d'archive **et** tout article de la catégorie.

### Onglet Planification

**Quand le popup doit-il être actif ?** — deux dates optionnelles interprétées dans le
**fuseau du site** (affiché en garde-fou avec l'heure courante) :

- **Afficher à partir de** (vide = démarrage immédiat).
- **Arrêter le** (vide = pas de fin).

| Configuration | Résultat |
|---|---|
| Aucune date | Actif en permanence |
| Début seul | Démarrage programmé |
| Fin seule | Actif tout de suite, puis s'arrête |
| Début + fin | Fenêtre active bornée |

La plage est vérifiée **côté serveur ET côté navigateur** — garde-fou pour les pages
mises en cache qui contiendraient un popup déjà expiré.

---

## Ouvrir un popup depuis un bouton (Divi, Elementor, menu…)

Deux moyens, sans aucune configuration :

- ajouter la classe CSS `spiral-{ID}` à n'importe quel bouton ou module ;
- ou faire pointer un lien vers `#spiral-{ID}`.

L'ID du popup et des boutons « Copier » sont affichés dans l'onglet **Déclencheurs** de
chaque popup. Un sélecteur CSS libre est aussi disponible dans la section Avancé.

---

## Les designs

Un design n'impose que l'**apparence** (couleurs, coins, ombre, croix, fond) via des
variables CSS scopées : aucune fuite de style hors du popup. Menu **Popups → Designs**.

### 6 designs fournis

| Design | En bref |
|---|---|
| **Annonce** *(défaut)* | Fond blanc, accent bleu, coins arrondis, fond assombri, croix intérieure |
| **Opt-in email** | Fond blanc, accent vert, fond flouté, croix extérieure — capture d'email |
| **Promo / urgence** | Fond sombre, accent orange, ton promotionnel |
| **Notice discrète (bas)** | Gris clair, sans fond, fermeture « Fermer » en texte — peu intrusive |
| **Barre flottante** | Ardoise, coins carrés, sans fond — style bandeau |
| **Neutre (page builders)** | Cadre sans style imposé, pour Divi/Elementor |

Les designs fournis sont **immuables** : les personnaliser crée automatiquement une
**copie** dans « Mes designs ».

### Créateur de designs (100 % clic, aperçu live)

- **Couleurs** : fond, texte (auto par contraste si vide), accent (boutons/liens),
  texte des boutons — pastilles + roue chromatique.
- **Croix de fermeture** : couleur et fond, couleur et fond au survol, trait souligné
  (désactivé par défaut), style **Croix** ou **Texte « Fermer »**, position **intérieure**
  ou **extérieure**.
- **Bordure du popup** : Aucune / Fine 1 px / Épaisse 3 px / Personnalisée + couleur.
- **Coins** : Carrés / Arrondis 12 px / Très arrondis 28 px / Personnalisé (0–60 px).
- **Ombre** : Aucune / Douce / Forte / Personnalisée (flou + opacité).
- **Fond derrière le popup** : Assombri / Flouté / Aucun.
- **Police** : celle du thème ou moderne (système).
- **Avancé — CSS manuel** : appliqué au seul design, automatiquement scopé (bloque
  `@import` et l'injection HTML).

**Mes designs** : galerie à deux sections (Fournis / personnels), aperçu live pendant
l'édition, duplication implicite d'un preset (« Personnaliser (copie) »), modification
et suppression des designs personnels.

---

## Presets de configuration

Un **preset** mémorise la configuration d'un popup pour la réappliquer en un clic à
d'autres popups — à ne pas confondre avec un **design**, qui ne concerne que
l'apparence visuelle.

Menu **Popups → Presets**. Un preset capture :

- **l'affichage** (design, position, taille, hauteur, image) ;
- **le bouton d'action** ;
- **les déclencheurs** ;
- **la fréquence** ;
- et, **en option** (case à cocher), **le ciblage**.

Il **n'inclut jamais** la planification, le titre ni le contenu — propres à chaque
popup.

- **Créer** un preset depuis un popup existant (page Presets) ou directement depuis
  l'onglet **Affichage** de l'éditeur (« Enregistrer ces réglages comme preset »).
- **Appliquer** un preset depuis l'onglet Affichage : choisissez les catégories de
  réglages à appliquer (une confirmation prévient avant d'écraser les réglages
  actuels).
- **Renommer**, **dupliquer**, **supprimer** depuis la page Presets.

---

## Réglages globaux

**Popups → Réglages** (administrateurs) :

- **Tailles de popup réutilisables** : créez des tailles nommées (nom + largeur en px)
  qui apparaissent dans le sélecteur « Quelle taille ? ». Chaque taille indique
  « utilisée par N popup(s) ». **Taille par défaut des nouveaux popups** (défaut
  *Automatique*).
- **Largeurs d'image personnalisées** : ajoutez des largeurs en % (au-delà de
  25/50/75/100). **Largeur d'image par défaut** (défaut *100 %*).
- **Planification** : *Désactiver automatiquement l'interrupteur « Actif » d'un popup
  une fois sa date de fin passée* (décoché par défaut). Confort visuel uniquement — un
  popup expiré ne s'affiche déjà jamais, que la tâche planifiée soit passée ou non.
- **Données** : *Supprimer tous les popups et designs à la désinstallation* (décoché
  par défaut).
- Deux encarts informatifs : rappel RGPD (avec phrase type) et rappel du déclencheur
  `spiral-{ID}`.

---

## La liste des popups

Colonnes ajoutées à la liste **Popups** :

| Colonne | Contenu |
|---|---|
| **Actif** | Interrupteur on/off instantané — *autorisation manuelle* (voir ci-dessous) |
| **Statut** | *État calculé* : **Visible** (vert) ou **Masqué : {raison}** (rouge) + résumé du ciblage |
| **Design** | Nom du design appliqué |
| **Planification** | Timeline : **Permanent / En cours / Programmé / Expiré** + dates |
| **Vues** | Total cumulé d'ouvertures |
| **Clics** | Total cumulé de clics dans le contenu |

Actions par ligne : **Prévisualiser** (aperçu sécurisé), **Dupliquer** (crée un
brouillon « (copie) » avec réglages et image) et **Tester (page réelle)**.

### Toggle « Actif », statut et planification

Trois informations distinctes, affichées séparément :

- **Actif** (colonne toggle) = une **autorisation manuelle**. Sur OFF, le popup ne
  s'affiche **jamais**, même si sa planification est « En cours » (le badge de
  planification passe alors en gris neutre, pas en vert).
- **Statut** (colonne) = l'**état calculé** à partir de *toutes* les conditions.
  Quand le popup ne peut pas s'afficher, la **raison précise** est indiquée :
  *Désactivé*, *Aucune cible*, *Non publié*, *Sans contenu*, *Programmé*, *Expiré* ou
  *Dates incohérentes*.
- **Planification** (colonne) = la **timeline** brute (Permanent / En cours /
  Programmé / Expiré) et les dates.

Un popup s'affiche seulement s'il est publié **ET** actif **ET** ciblé **ET** dans sa
plage de planification **ET** non vide.

À la fin d'une planification, le toggle **reste sur ON** par défaut (une planification
expirée est un état *calculé*, le toggle une décision *manuelle*) : le popup ne s'affiche
simplement plus. Une option globale (Réglages → Planification, **désactivée par
défaut**) permet, si vous le souhaitez, de basculer automatiquement le toggle sur OFF en
fin de planification — mais la sûreté d'affichage n'en dépend pas.

---

## Prévisualisation sécurisée

Le bouton **Prévisualiser** (liste des popups **et** en haut de l'éditeur) ouvre le
popup dans une page d'aperçu dédiée, **sans le rendre public** :

- réservée à un utilisateur connecté ayant le droit de modifier le popup (**nonce +
  capacité**) — un lien invalide renvoie une erreur 403 ;
- fonctionne même pour un **brouillon** ou un popup **désactivé** ;
- page **non indexable** (en-tête `X-Robots-Tag: noindex` + balise robots), non mise en
  cache ;
- le popup s'ouvre **immédiatement** (déclencheurs et planification ignorés) ;
- **aucune statistique** n'est comptée, **aucun cookie** du visiteur n'est touché ;
- bascule **Ordinateur / Tablette / Mobile** pour vérifier le rendu responsive ;
- bandeau « Mode prévisualisation » bien visible.

**Tester (page réelle)** — en complément, le lien *Tester (page réelle)* (liste des
popups) ouvre une page réellement ciblée avec `?spiral-test=1` pour voir le popup live
en conditions réelles : le cookie de fréquence est ignoré puis purgé, la console
journalise les déclencheurs, la planification reste respectée, et — depuis cette
version — **les statistiques ne sont plus incrémentées** en mode test.

---

## Panneau de statistiques

Menu **Popups → Statistiques** (accès réservé à la capacité `edit_posts`, filtrable) :

- **totaux** de vues et de clics + **taux de clic** (clics / vues × 100) ;
- **filtre par popup** et **par période** (7 / 30 / 90 derniers jours ou plage
  personnalisée), **jours sans événement affichés à zéro** ;
- **courbe chronologique** vues + clics (SVG, sans aucune dépendance) ;
- **tableau récapitulatif par popup**, triable ;
- **état vide** propre quand aucune donnée n'existe encore.

Le suivi est **anonyme** : agrégats journaliers `(popup, type d'événement, jour)` dans
une table dédiée, **sans adresse IP ni identifiant visiteur**. Les totaux cumulés
affichés dans la liste des popups peuvent inclure une activité antérieure au démarrage
du suivi détaillé (indiqué sous le panneau) — aucune donnée historique n'est inventée.

---

## Compteurs de vues et de clics

- **Vues** : chaque ouverture réelle du popup. **Clics** : chaque clic sur un lien,
  bouton ou champ d'envoi **à l'intérieur** du contenu. *(La prévisualisation et le mode
  test ne comptent pas.)*
- Envoyés en arrière-plan (`sendBeacon`) vers l'endpoint REST `spiral/v1/track`
  (public, pour compter les visiteurs non connectés), avec **anti-rafale de 10 s** par
  empreinte anonyme (l'IP n'est jamais stockée).
- **Incréments atomiques** (côté base) : les totaux cumulés (metas) et les agrégats
  journaliers (table `spiral_stats`) sont mis à jour sans risque de perte en cas de
  requêtes concurrentes.
- **Totaux agrégés uniquement** : aucun suivi individuel. Totaux cumulés dans les
  colonnes **Vues** / **Clics** ; évolution par jour dans le
  [panneau de statistiques](#panneau-de-statistiques).

---

## Compatibilité Divi et Elementor

**Divi** (activé si Divi est détecté) : le **Divi Builder** (y compris le Visual
Builder) s'active directement sur le contenu du popup. Le CPT n'est requêtable que
pendant une session d'édition Divi et jamais pour un visiteur.

**Elementor** (activé si Elementor est présent) : un **template Elementor** publié peut
servir de contenu du popup, rendu avec ses styles (repli automatique sur l'éditeur si
le template disparaît).

Dans les deux cas, un bouton s'associe au popup via la classe `spiral-{ID}` ou un lien
`#spiral-{ID}`.

---

## RGPD

Le plugin est conforme par conception :

- Le cookie de fréquence `spiral_popup_{id}` est un **cookie fonctionnel** : un simple
  drapeau posé à la fermeture du popup, sans aucun identifiant personnel ni empreinte,
  jamais transmis à un tiers, d'une durée maximale de 13 mois. Il est **exempté de
  consentement** (catégorie « préférences », doctrine CNIL).
- Les compteurs de vues et de clics sont des **totaux anonymes** agrégés côté serveur —
  aucun suivi individuel.

**Phrase type pour votre politique de confidentialité :**

> Ce site utilise un cookie fonctionnel (`spiral_popup_*`) qui mémorise la fermeture des
> fenêtres d'information afin de ne pas vous les réafficher. Il ne contient aucune
> donnée personnelle et expire automatiquement.

---

## Personnalisation développeur

- **Template** : copiez `views/popup.php` dans `{votre-theme}/popup-spiral/popup.php`
  pour surcharger le markup.
- **Filtres** : `spiral_popup_content` (formatage du contenu), `spiral_popup_zindex`
  (z-index par popup).
- **CSS manuel** : section « Avancé » du créateur de designs, automatiquement scopé au
  design.
- **Variables CSS** : le design expose `--spiral-bg`, `--spiral-text`, `--spiral-accent`,
  `--spiral-radius`, `--spiral-shadow`, `--spiral-border`, `--spiral-close-*`… ; le popup
  expose `--spiral-text-size`, `--spiral-btn-size`, `--spiral-width`, `--spiral-img-w`,
  `--spiral-img-pad`, `--spiral-img-border-*`.
- **Cache-busting** : la version des assets inclut le `filemtime` du fichier — le cache
  navigateur est invalidé automatiquement à chaque modification, sans bump manuel.

---

## Prérequis

- WordPress ≥ 6.0, PHP ≥ 7.4.
- Aucune dépendance : pas de jQuery côté front, pas de librairie tierce.

---

## Mises à jour automatiques

Les mises à jour apparaissent normalement dans l'écran **Extensions** de WordPress (via
l'updater interne, source GitHub `wp-plugin-updates`). Rien à configurer.

---

## Désinstallation

Par défaut, vos popups et designs sont **conservés**. Pour tout supprimer à la
désinstallation, cochez l'option dans **Popups → Réglages → Données**.

---

## Référence technique (metas & options)

| Meta d'un popup | Rôle |
|---|---|
| `spiral_popup_settings` | Tous les réglages (affichage, bouton, déclencheurs, fréquence, ciblage, planification, source de contenu) |
| `spiral_enabled` | Toggle « Actif » de la liste (`'1'`/`'0'` ; absent = actif). Neutralise le popup sans le dépublier |
| `spiral_open_count` | Total cumulé de vues |
| `spiral_click_count` | Total cumulé de clics dans le contenu |

| Option globale | Rôle |
|---|---|
| `spiral_size_presets` | Tailles de popup et largeurs d'image réutilisables (+ leurs défauts) |
| `spiral_saved_designs` | Designs personnels (« Mes designs ») |
| `spiral_designs_css` | CSS pré-généré des designs personnels |
| `spiral_config_presets` | Presets de configuration réutilisables |
| `spiral_auto_disable_expired` | Auto-désactiver le toggle en fin de planification (off par défaut) |
| `spiral_db_version` / `spiral_stats_since` | Version de schéma / date de départ du suivi détaillé |
| `spiral_delete_on_uninstall` | Supprimer les données à la désinstallation |

| Table | Rôle |
|---|---|
| `{prefix}spiral_stats` | Agrégats journaliers anonymes `(popup_id, event_type, event_date, count)` |
