# Thème Evolution'R

Thème WordPress **classique** (PHP, mobile-first) d'Evolution'R — build **Vite**, champs **ACF**
en Local JSON. Ce dossier est le thème actif du site.

## Build

```bash
npm install
npm run dev      # serveur Vite (HMR) sur http://localhost:5173
npm run build    # build de production -> dist/
```

> Si le site s'affiche sans style/JS après avoir arrêté `npm run dev` : vider le cache de détection
> Vite avec `wp transient delete theme_vite_dev_origin`, puis Ctrl+Shift+R.

## Documentation complète

La présentation du site, la structure, le **guide back-office** (tarifs, offres, `offre_ref`),
le seed et le déploiement sont dans le **[README à la racine du dépôt](../../../README.md)**.

Pièges connus & règles du projet : `tasks/lessons.md`. Plans en cours : `tasks/todo.md`.
