<?php

/**
 * AI Images - Orchestration de la génération et import en médiathèque
 *
 * Point d'entrée commun aux quatre déclencheurs (metabox, colonne, bulk, REST) :
 * résout le provider, génère l'image, la télécharge en médiathèque (sideload)
 * avec alt text et métas de traçabilité, puis applique la cible demandée.
 *
 * Fichiers liés :
 * - src/ai-images/providers.php
 * - src/ai-images/ai-images.php (déclencheurs admin)
 * - src/ai-images/rest.php (déclencheur REST)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class Generator
{
	const VALID_TARGETS = ['featured', 'content', 'library'];

	const VALID_RATIOS = ['1:1', '3:2', '4:3', '16:9', '9:16', '3:4'];

	/**
	 * Budget temps global (secondes) pour la génération, polling compris.
	 * 60 s reste sous les timeouts PHP usuels des requêtes admin-ajax.
	 *
	 * @return int
	 */
	public static function time_budget()
	{
		return (int) apply_filters('ultimate_shanks_ai_images_time_budget', 60);
	}

	/**
	 * Génère une image pour un contenu et applique la cible demandée.
	 *
	 * @param int   $post_id
	 * @param array $args ['prompt', 'aspect_ratio', 'target', 'provider', 'model',
	 *                     'apply_content' => bool — false quand l'éditeur est ouvert
	 *                     (le JS insère alors le bloc lui-même, voir apply_target())]
	 * @return array|\WP_Error ['attachment_id','url','alt','target','provider','model']
	 */
	public static function generate_for_post($post_id, $args = [])
	{
		$post = get_post($post_id);
		if (!$post) {
			return new \WP_Error('ai_images_no_post', 'Contenu introuvable.');
		}

		$provider_id = !empty($args['provider']) ? $args['provider'] : '';
		$provider = $provider_id !== '' ? Providers::get($provider_id) : Providers::get_active();
		if ($provider === null) {
			return new \WP_Error('ai_images_no_provider', sprintf('Fournisseur d\'images inconnu : %s.', $provider_id));
		}

		$prompt = !empty($args['prompt']) ? sanitize_textarea_field($args['prompt']) : $post->post_title;
		if (trim($prompt) === '') {
			return new \WP_Error('ai_images_no_prompt', 'Aucun prompt : saisissez une description ou donnez un titre au contenu.');
		}

		$aspect_ratio = self::validate_ratio(isset($args['aspect_ratio']) ? $args['aspect_ratio'] : '');
		$target = self::validate_target(isset($args['target']) ? $args['target'] : '');

		// Un modèle explicitement demandé doit exister dans le catalogue du
		// provider : évite d'appeler un endpoint arbitraire de l'API
		$model = !empty($args['model']) ? sanitize_text_field($args['model']) : null;
		if ($model !== null && !array_key_exists($model, $provider->get_models())) {
			return new \WP_Error('ai_images_bad_model', sprintf('Modèle inconnu : %s.', $model));
		}

		$generated = $provider->generate($prompt, [
			'aspect_ratio' => $aspect_ratio,
			'model'        => $model,
		]);
		if (is_wp_error($generated)) {
			self::log('Génération en échec : ' . $generated->get_error_message(), ['post_id' => $post_id]);

			return $generated;
		}

		$sideloaded = self::sideload($generated['url'], $post_id, [
			'prompt'   => $prompt,
			'provider' => $provider->get_id(),
			'model'    => $generated['model'],
		]);
		if (is_wp_error($sideloaded)) {
			return $sideloaded;
		}

		$apply_content = !isset($args['apply_content']) || $args['apply_content'];
		self::apply_target($post_id, $sideloaded['id'], $target, $sideloaded['alt'], $apply_content);

		$cost = isset($generated['cost']) ? $generated['cost'] : null;
		if ($cost !== null) {
			update_post_meta($sideloaded['id'], '_ultimate_shanks_ai_cost', (float) $cost);
		}
		Stats::record($cost, [
			'provider'      => $provider->get_id(),
			'model'         => $generated['model'],
			'prompt'        => $prompt,
			'attachment_id' => $sideloaded['id'],
			'post_id'       => $post_id,
		]);

		return [
			'attachment_id' => $sideloaded['id'],
			'url'           => $sideloaded['url'],
			'alt'           => $sideloaded['alt'],
			'target'        => $target,
			'provider'      => $provider->get_id(),
			'model'         => $generated['model'],
			'cost'          => $cost,
		];
	}

	/**
	 * Valide un ratio contre la liste blanche (repli sur l'option puis 3:2)
	 *
	 * @param string $ratio
	 * @return string
	 */
	public static function validate_ratio($ratio)
	{
		if (in_array($ratio, self::VALID_RATIOS, true)) {
			return $ratio;
		}

		$default = get_option('ultimate_shanks_ai_images_default_ratio', '3:2');

		return in_array($default, self::VALID_RATIOS, true) ? $default : '3:2';
	}

	/**
	 * Valide une cible contre la liste blanche (repli sur l'option puis featured)
	 *
	 * @param string $target
	 * @return string
	 */
	public static function validate_target($target)
	{
		if (in_array($target, self::VALID_TARGETS, true)) {
			return $target;
		}

		$default = get_option('ultimate_shanks_ai_images_default_target', 'featured');

		return in_array($default, self::VALID_TARGETS, true) ? $default : 'featured';
	}

	/**
	 * Télécharge l'image générée en médiathèque avec alt et métas de traçabilité
	 *
	 * @param string $image_url URL temporaire renvoyée par le provider
	 * @param int    $post_id
	 * @param array  $context ['prompt','provider','model']
	 * @return array|\WP_Error ['id','url','alt']
	 */
	public static function sideload($image_url, $post_id, $context)
	{
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = download_url($image_url, 60);
		if (is_wp_error($tmp)) {
			return new \WP_Error('ai_images_download_failed', 'Téléchargement de l\'image générée impossible : ' . $tmp->get_error_message());
		}

		$path = (string) wp_parse_url($image_url, PHP_URL_PATH);
		$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
		if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
			$ext = 'jpg';
		}

		$file_array = [
			'name'     => sanitize_file_name('ia-' . $context['provider'] . '-' . $post_id . '-' . gmdate('Ymd-His') . '.' . $ext),
			'tmp_name' => $tmp,
		];

		$title = get_the_title($post_id);
		if ($title === '') {
			$title = wp_html_excerpt($context['prompt'], 80, '…');
		}

		$attachment_id = media_handle_sideload($file_array, $post_id, $title);
		if (is_wp_error($attachment_id)) {
			@unlink($tmp);

			return new \WP_Error('ai_images_sideload_failed', 'Import en médiathèque impossible : ' . $attachment_id->get_error_message());
		}

		$alt = wp_html_excerpt($context['prompt'], 140, '');
		update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
		update_post_meta($attachment_id, '_ultimate_shanks_ai_provider', $context['provider']);
		update_post_meta($attachment_id, '_ultimate_shanks_ai_model', $context['model']);
		update_post_meta($attachment_id, '_ultimate_shanks_ai_prompt', $context['prompt']);
		update_post_meta($attachment_id, '_ultimate_shanks_ai_generated_at', time());

		return [
			'id'  => (int) $attachment_id,
			'url' => wp_get_attachment_url($attachment_id),
			'alt' => $alt,
		];
	}

	/**
	 * Applique la cible demandée à l'image importée.
	 *
	 * Cible « content » : le post n'est modifié que si $apply_content est vrai
	 * (déclencheurs sans éditeur ouvert — REST). Depuis la metabox, c'est le JS
	 * qui insère le bloc dans l'état de l'éditeur pour éviter tout conflit de
	 * révision Gutenberg.
	 *
	 * @param int    $post_id
	 * @param int    $attachment_id
	 * @param string $target
	 * @param string $alt
	 * @param bool   $apply_content
	 * @return void
	 */
	public static function apply_target($post_id, $attachment_id, $target, $alt, $apply_content)
	{
		if ($target === 'featured') {
			set_post_thumbnail($post_id, $attachment_id);

			return;
		}

		if ($target === 'content' && $apply_content) {
			self::prepend_image_block($post_id, $attachment_id, $alt);
		}
	}

	/**
	 * Préfixe le contenu du post avec un bloc image Gutenberg sérialisé
	 * (valide dans l'éditeur de blocs et rendu correctement en classique)
	 *
	 * @param int    $post_id
	 * @param int    $attachment_id
	 * @param string $alt
	 * @return void
	 */
	public static function prepend_image_block($post_id, $attachment_id, $alt)
	{
		$url = wp_get_attachment_url($attachment_id);
		$block = sprintf(
			'<!-- wp:image {"id":%1$d,"sizeSlug":"large","linkDestination":"none"} -->' . "\n"
				. '<figure class="wp-block-image size-large"><img src="%2$s" alt="%3$s" class="wp-image-%1$d"/></figure>' . "\n"
				. '<!-- /wp:image -->' . "\n\n",
			(int) $attachment_id,
			esc_url($url),
			esc_attr($alt)
		);

		$post = get_post($post_id);
		wp_update_post([
			'ID'           => $post_id,
			'post_content' => $block . $post->post_content,
		]);
	}

	/**
	 * Journalisation de debug (WP_DEBUG uniquement) — jamais de clé API,
	 * contexte tronqué pour ne pas divulguer les prompts complets
	 *
	 * @param string $message
	 * @param array  $context
	 * @return void
	 */
	public static function log($message, $context = [])
	{
		if (!defined('WP_DEBUG') || !WP_DEBUG) {
			return;
		}

		$suffix = $context !== [] ? ' ' . wp_html_excerpt(wp_json_encode($context), 100, '…') : '';
		error_log('[Ultimate Shanks AI Images] ' . $message . $suffix);
	}
}
