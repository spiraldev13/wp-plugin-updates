/**
 * Bloc spiralbase/coordonnees — JS éditeur écrit à la main, SANS build
 * (AD-12 : l'artefact livré EST ce fichier). Bloc 100 % dynamique : save()
 * rend null, le serveur rend tout depuis les données métier du site.
 */
( function ( blocks, element, blockEditor, components, i18n, serverSideRender ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    /* Les libellés sont traduits ICI, littéralement : `__( variable )` ne
       serait pas extractible par l'outillage .pot (leçon story 1.1). */
    var SECTIONS = [
        { attribut: 'afficherNom', label: __( 'Afficher le nom', 'spiralbase' ) },
        { attribut: 'afficherAdresse', label: __( 'Afficher l’adresse', 'spiralbase' ) },
        { attribut: 'afficherTelephone', label: __( 'Afficher le téléphone', 'spiralbase' ) },
    ];

    function apercu( props ) {
        var Rendu = serverSideRender && ( serverSideRender.default || serverSideRender );

        /* Tout décoché : le rendu serveur est vide et l'aperçu afficherait
           « aucune coordonnée », ce qui est faux — les données existent,
           c'est l'affichage qui est éteint (revue 3.1). */
        var toutMasque = SECTIONS.every( function ( section ) {
            return props.attributes[ section.attribut ] === false;
        } );

        if ( toutMasque ) {
            return e(
                'p',
                { style: { margin: 0, opacity: 0.8 } },
                __( 'Toutes les sections sont masquées — ce bloc n’affichera rien.', 'spiralbase' )
            );
        }

        if ( typeof Rendu === 'function' ) {
            return e( Rendu, {
                block: 'spiralbase/coordonnees',
                attributes: props.attributes,
                EmptyResponsePlaceholder: function () {
                    return e(
                        'p',
                        { style: { margin: 0, opacity: 0.8 } },
                        __( 'Aucune coordonnée dans les données métier du site.', 'spiralbase' )
                    );
                },
            } );
        }

        return e(
            'p',
            { style: { margin: 0, opacity: 0.8 } },
            __( 'Les coordonnées du site sont rendues sur le front.', 'spiralbase' )
        );
    }

    blocks.registerBlockType( 'spiralbase/coordonnees', {
        edit: function ( props ) {
            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-coordonnees-apercu',
                style: {
                    border: '1px dashed currentColor',
                    borderRadius: '4px',
                    opacity: 0.9,
                    padding: '1em',
                },
            } );

            var controles = SECTIONS.map( function ( section ) {
                return e( components.ToggleControl, {
                    key: section.attribut,
                    label: section.label,
                    checked: props.attributes[ section.attribut ] !== false,
                    onChange: function ( valeur ) {
                        var modification = {};
                        modification[ section.attribut ] = !! valeur;
                        props.setAttributes( modification );
                    },
                } );
            } );

            return e(
                'div',
                blockProps,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages des coordonnées', 'spiralbase' ) },
                        controles
                    )
                ),
                e( 'strong', null, __( 'Coordonnées', 'spiralbase' ) ),
                e( 'div', { style: { marginTop: '0.5em' } }, apercu( props ) )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n,
    window.wp.serverSideRender
);
