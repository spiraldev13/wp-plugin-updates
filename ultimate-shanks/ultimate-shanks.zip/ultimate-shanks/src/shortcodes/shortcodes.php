<?php
/**
 * Shortcodes Utilitaires - Collection de shortcodes pratiques
 *
 * Shortcodes disponibles :
 * - [year] : Affiche l'année en cours
 *
 * Ces shortcodes fonctionnent dans :
 * - Le contenu des articles et pages
 * - Les titres (the_title)
 * - Les widgets texte
 * - Les menus de navigation
 *
 * @package UltimateShanks\Shortcodes
 */

namespace UltimateShanks\Shortcodes;

if (!defined('ABSPATH')) {
    exit;
}

class Shortcodes
{
	/**
	 * Exécute do_shortcode uniquement si nécessaire.
	 *
	 * @param string $value Texte à traiter.
	 * @return string
	 */
	public static function maybe_do_shortcode($value)
	{
		if (!is_string($value) || $value === '' || strpos($value, '[') === false) {
			return $value;
		}

		$profile_start = \UltimateShanks\Core\Profiler::start('shortcodes.do_shortcode');
		try {
			return do_shortcode($value);
		} finally {
			\UltimateShanks\Core\Profiler::stop('shortcodes.do_shortcode', $profile_start, [
				'length' => strlen($value),
			]);
		}
	}

    /**
     * Initialise les shortcodes
     */
    public static function init()
    {
        // Vérifie si la fonctionnalité est activée
        if (get_option('ultimate_shanks_shortcodes_enabled', '1') !== '1') {
            return;
        }

        // Enregistre le shortcode [year]
        add_shortcode('year', [self::class, 'render_year']);

        // Active les shortcodes dans les titres
        if (get_option('ultimate_shanks_shortcodes_in_titles', '1') === '1') {
            add_filter('the_title', [self::class, 'maybe_do_shortcode']);
            add_filter('single_post_title', [self::class, 'maybe_do_shortcode']);
            add_filter('wp_title', [self::class, 'maybe_do_shortcode']);
        }

        // Active les shortcodes dans les widgets texte (WordPress 4.9+)
        add_filter('widget_text', [self::class, 'maybe_do_shortcode']);

        // Active les shortcodes dans les menus de navigation
        if (get_option('ultimate_shanks_shortcodes_in_menus', '1') === '1') {
            add_filter('wp_nav_menu_items', [self::class, 'maybe_do_shortcode']);
            add_filter('walker_nav_menu_start_el', [self::class, 'maybe_do_shortcode']);
        }

        // Active les shortcodes dans les excerpts
        add_filter('the_excerpt', [self::class, 'maybe_do_shortcode']);
    }

    /**
     * Shortcode [year] - Retourne l'année en cours
     *
     * Usage :
     * - [year] → 2026
     * - [year format="y"] → 26
     *
     * @param array $atts Attributs du shortcode
     * @return string L'année formatée
     */
    public static function render_year($atts)
    {
        $atts = shortcode_atts([
            'format' => 'Y', // Format par défaut : année sur 4 chiffres
        ], $atts, 'year');

        // Sécurise le format (autorise uniquement Y, y, o)
        $allowed_formats = ['Y', 'y', 'o'];
        $format = in_array($atts['format'], $allowed_formats) ? $atts['format'] : 'Y';

        return date($format);
    }
}
