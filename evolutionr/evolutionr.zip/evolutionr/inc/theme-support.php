<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('evolutionr_setup')) {
    function evolutionr_setup(): void
    {
        add_theme_support('title-tag');
        add_theme_support('automatic-feed-links');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo', [
            'height'      => 64,
            'width'       => 64,
            'flex-height' => true,
            'flex-width'  => true,
        ]);
        add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
        add_theme_support('responsive-embeds');

        load_theme_textdomain('evolutionr', get_template_directory() . '/languages');

        register_nav_menus([
            'main'               => __('Menu principal (header)', 'evolutionr'),
            'footer_prestations' => __('Footer — Prestations', 'evolutionr'),
            'footer_ressources'  => __('Footer — Ressources', 'evolutionr'),
            'footer_legal'       => __('Footer — Liens légaux', 'evolutionr'),
        ]);

        add_image_size('work-tall', 800, 1000, true);
        add_image_size('work-wide', 1000, 560, true);
        add_image_size('work-sq', 700, 560, true);
    }
}

add_action('after_setup_theme', 'evolutionr_setup');
