<?php

/**
 * Plugin Name: Ultimate Shanks
 * Plugin URI: https://github.com/spiraldev13/ultimate_shanks
 * Description: Plugin WordPress multifonctions avec mise à jour automatique via GitHub privé.
 * Version: 1.17.0
 * Author: Shanks
 * Author URI: https://ton-site.com
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
	exit;
}

define('MP_PATH', plugin_dir_path(__FILE__));
define('MP_URL', plugin_dir_url(__FILE__));
define('MP_BASENAME', plugin_basename(__FILE__));

// Outils internes
require_once MP_PATH . 'src/core/profiler.php';

// Runtime updater: toujours utiliser la copie locale du plugin.
// Cela évite les écarts de comportement quand /vendor contient une version différente.
require_once MP_PATH . 'uploader/updater.php';

// ========================================
// 👇 FONCTIONNALITÉS DU PLUGIN
// ========================================

// Charge les fichiers des fonctionnalités
require_once MP_PATH . 'src/features/featured-images.php';
if (is_admin()) {
	require_once MP_PATH . 'src/admin/settings.php';
	require_once MP_PATH . 'src/admin/site-health.php';
}

// Charge Text Enhancer
require_once MP_PATH . 'src/text-enhancer/processor.php';
require_once MP_PATH . 'src/text-enhancer/text-enhancer.php';
if (is_admin()) {
	require_once MP_PATH . 'src/text-enhancer/settings.php';
}

// Charge Style Manager
require_once MP_PATH . 'src/style/css-generator.php';
require_once MP_PATH . 'src/style/style-manager.php';
if (is_admin()) {
	require_once MP_PATH . 'src/style/settings.php';
}

// Charge Shortcodes Utilitaires
require_once MP_PATH . 'src/shortcodes/shortcodes.php';

// Charge Intégrations
require_once MP_PATH . 'src/integration/otomatic-integration.php';
require_once MP_PATH . 'src/integration/rankmath-integration.php';
require_once MP_PATH . 'src/integration/autologin-integration.php';

// Charge Images IA
require_once MP_PATH . 'src/ai-images/provider-interface.php';
require_once MP_PATH . 'src/ai-images/provider-flux.php';
require_once MP_PATH . 'src/ai-images/providers.php';
require_once MP_PATH . 'src/ai-images/stats.php';
require_once MP_PATH . 'src/ai-images/generator.php';
require_once MP_PATH . 'src/ai-images/ai-images.php';
require_once MP_PATH . 'src/ai-images/rest.php';
if (is_admin()) {
	require_once MP_PATH . 'src/ai-images/settings.php';
}

// Initialisation des fonctionnalités après le chargement de WordPress
add_action('plugins_loaded', function() {
	UltimateShanks\Core\Profiler::init();

	UltimateShanks\Features\FeaturedImages::init();
	UltimateShanks\TextEnhancer\TextEnhancer::init();
	UltimateShanks\Style\StyleManager::init();
	UltimateShanks\Shortcodes\Shortcodes::init();
	UltimateShanks\Integration\OtomaticIntegration::init();
	UltimateShanks\Integration\RankMathIntegration::init();
	UltimateShanks\Integration\AutoLoginIntegration::init();
	UltimateShanks\AiImages\AiImages::init();
	UltimateShanks\AiImages\Rest::init();

	if (is_admin()) {
		if (class_exists('UltimateShanks\\Admin\\Settings')) {
			UltimateShanks\Admin\Settings::init();
		}
		if (class_exists('UltimateShanks\\Admin\\SiteHealth')) {
			UltimateShanks\Admin\SiteHealth::init();
		}
		if (class_exists('UltimateShanks\\TextEnhancer\\Settings')) {
			UltimateShanks\TextEnhancer\Settings::init();
		}
		if (class_exists('UltimateShanks\\Style\\Settings')) {
			UltimateShanks\Style\Settings::init();
		}
		if (class_exists('UltimateShanks\\AiImages\\Settings')) {
			UltimateShanks\AiImages\Settings::init();
		}
	}
});

// Hook d'activation : régénérer le CSS depuis les options existantes
register_activation_hook(__FILE__, function() {
	// Capturer toute sortie pour éviter les warnings "headers already sent"
	ob_start();

	try {
		// Régénérer le CSS depuis les options WordPress existantes.
		// Le fichier vit dans uploads/ultimate-shanks/ : inscriptible par PHP et
		// non affecté par le remplacement du dossier plugin lors des mises à jour.
		if (!UltimateShanks\Style\CSSGenerator::generate_css()) {
			error_log('[Ultimate Shanks] Écriture du CSS généré impossible à l\'activation — fallback inline actif sur le front.');
		}
	} catch (Exception $e) {
		// Silence any errors during activation
	}

	// Nettoyer le buffer de sortie
	ob_end_clean();
});
