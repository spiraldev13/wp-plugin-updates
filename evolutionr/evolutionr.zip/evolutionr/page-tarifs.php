<?php
/**
 * Template — Page « Tarifs » (slug `tarifs`).
 *
 * Structure SITE.MD §§ 7-12 :
 *   1. Hero court
 *   2. Introduction (« tarifs à partir de »)
 *   3. Configurateur tarifs interactif (module JS natif)
 *   4. Fallback <noscript> (grille statique d'entrée)
 *   5. CTA final
 *
 * Le configurateur est rendu par le module JS `app/configurateur.js` —
 * chargé conditionnellement via `inc/config-viteJs.php` quand
 * `is_page('tarifs')` est vrai.
 *
 * Source de vérité tarifaire : .claude/docs/SITE.MD § 9-11.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal page-tarifs-layout" id="content">

    <?php /* ─── 1. Hero (même pattern que les pages prestations) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-hero', null, [
        'visual_label' => 'configurateur.cfg',
        'visual_type'  => 'configurateur',
        'show_ctas'    => false,
        'extra_class'  => 'page-hero--tarifs',
    ]); ?>

    <?php /* ─── 2. Configurateur interactif (visible directement après le hero) ─── */ ?>
    <section class="page-section page-tarifs-configurator" aria-labelledby="configurator-title">
        <div class="container container--wide">
            <h2 class="sr-only" id="configurator-title"><?php esc_html_e('Configurateur de devis', 'evolutionr'); ?></h2>

            <div class="cfg" data-configurateur>

                <div class="cfg-main">

                <?php /* Étape 1 — Choix du service */ ?>
                <section class="cfg-step" aria-labelledby="cfg-step-service">
                    <header class="cfg-step-head">
                        <span class="cfg-step-number">01</span>
                        <h3 class="cfg-step-title" id="cfg-step-service"><?php esc_html_e('Choisissez votre service', 'evolutionr'); ?></h3>
                    </header>
                    <div class="cfg-services" data-configurateur-services>
                        <noscript>
                            <p class="cfg-noscript">
                                <?php esc_html_e('Le configurateur interactif nécessite JavaScript. Sans JS, consultez la grille statique en bas de page ou contactez-nous pour un devis personnalisé.', 'evolutionr'); ?>
                            </p>
                        </noscript>
                    </div>
                </section>

                <?php /* Étape 2 — Mode de facturation */ ?>
                <section class="cfg-step" aria-labelledby="cfg-step-mode">
                    <header class="cfg-step-head">
                        <span class="cfg-step-number">02</span>
                        <h3 class="cfg-step-title" id="cfg-step-mode"><?php esc_html_e('Paiement unique ou abonnement', 'evolutionr'); ?></h3>
                    </header>
                    <div class="cfg-mode" data-configurateur-mode></div>
                </section>

                <?php /* Étape 3 — Offres */ ?>
                <section class="cfg-step" aria-labelledby="cfg-step-offers">
                    <header class="cfg-step-head">
                        <span class="cfg-step-number">03</span>
                        <h3 class="cfg-step-title" id="cfg-step-offers"><?php esc_html_e('Offres disponibles', 'evolutionr'); ?></h3>
                    </header>
                    <div class="cfg-offers" data-configurateur-offers></div>
                </section>

                <?php /* Étape 4 — Options additionnelles */ ?>
                <section class="cfg-step" aria-labelledby="cfg-step-options">
                    <header class="cfg-step-head">
                        <span class="cfg-step-number">04</span>
                        <h3 class="cfg-step-title" id="cfg-step-options"><?php esc_html_e('Options additionnelles (facultatif)', 'evolutionr'); ?></h3>
                    </header>
                    <div class="cfg-options" data-configurateur-options></div>
                </section>

                <?php /* Étape 5 — Demande de devis (formulaire CF7 intégré, envoi AJAX) */ ?>
                <?php $devisForm = (string) get_field('devis_cf7', 'option'); ?>
                <section class="cfg-step cfg-devis" id="cfg-devis" aria-labelledby="cfg-step-devis">
                    <header class="cfg-step-head">
                        <span class="cfg-step-number">05</span>
                        <h3 class="cfg-step-title" id="cfg-step-devis"><?php esc_html_e('Recevoir ce devis', 'evolutionr'); ?></h3>
                    </header>
                    <p class="cfg-devis-intro"><?php esc_html_e('Votre configuration est jointe automatiquement. Renseignez vos coordonnées, nous revenons vers vous sous 48h.', 'evolutionr'); ?></p>
                    <?php if ($devisForm): ?>
                        <?php echo do_shortcode($devisForm); ?>
                    <?php else: ?>
                        <p>
                            <a class="btn btn-primary" href="/contact/">
                                <?php esc_html_e('Demander un devis personnalisé', 'evolutionr'); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                </section>

                </div><?php /* .cfg-main */ ?>

                <?php /* Étape 5 — Résumé sticky */ ?>
                <aside class="cfg-summary" data-configurateur-summary aria-live="polite" aria-atomic="true"></aside>

            </div>

            <?php /* ─── Fallback grille statique pour navigateurs sans JS ─── */ ?>
            <noscript>
                <div class="cfg-fallback">
                    <h2><?php esc_html_e('Tarifs « à partir de »', 'evolutionr'); ?></h2>
                    <ul>
                        <li><strong>Site One Page</strong> — à partir de 1 190 €</li>
                        <li><strong>Site vitrine</strong> — à partir de 1 890 €</li>
                        <li><strong>Site vitrine avancé</strong> — à partir de 2 990 €</li>
                        <li><strong>Refonte de site</strong> — à partir de 1 990 €</li>
                        <li><strong>Petit e-commerce</strong> — à partir de 3 990 €</li>
                        <li><strong>SEO mensuel</strong> — à partir de 350 €/mois</li>
                        <li><strong>Maintenance WordPress</strong> — à partir de 49 €/mois</li>
                        <li><strong>Hébergement web géré</strong> — à partir de 29 €/mois</li>
                    </ul>
                    <p>
                        <a class="btn btn-primary" href="/contact/"><?php esc_html_e('Demander un devis personnalisé', 'evolutionr'); ?></a>
                    </p>
                </div>
            </noscript>

        </div>
    </section>

    <?php /* ─── 3. Introduction sur la nature des tarifs (descendue : le configurateur passe avant) ─── */ ?>
    <?php $introText = (string) get_field('intro_text'); ?>
    <?php if ($introText): ?>
        <section class="page-section page-tarifs-intro" aria-labelledby="tarifs-intro-title">
            <div class="container">
                <div class="page-callout">
                    <h2 id="tarifs-intro-title" class="sr-only"><?php esc_html_e('Comment lire ces tarifs', 'evolutionr'); ?></h2>
                    <p><?php echo esc_html($introText); ?></p>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── 4. CTA final ─── */ ?>
    <?php
    $ctaTitle     = (string) get_field('cta_title');
    $ctaParagraph = (string) get_field('cta_paragraph');
    $ctaLabel     = (string) get_field('cta_label') ?: __('Demander un devis personnalisé', 'evolutionr');
    $ctaUrl       = (string) get_field('cta_url') ?: '/contact/';
    ?>
    <?php if ($ctaTitle || $ctaParagraph): ?>
        <section class="page-cta-final" aria-labelledby="page-cta-title">
            <div class="container">
                <?php if ($ctaTitle): ?>
                    <h2 id="page-cta-title"><?php echo esc_html($ctaTitle); ?></h2>
                <?php endif; ?>
                <?php if ($ctaParagraph): ?>
                    <p><?php echo esc_html($ctaParagraph); ?></p>
                <?php endif; ?>
                <a class="btn btn-primary" href="<?php echo esc_url($ctaUrl); ?>">
                    <?php echo esc_html($ctaLabel); ?>
                    <?php evolutionr_icon('arrow-right', 16); ?>
                </a>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php get_footer(); ?>
