<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocCarrousel;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;
use SpiralBase\Core\TexteRiche;

/**
 * Rendu serveur du bloc `spiralbase/carrousel` (story 3.5).
 *
 * Le défilement est du CSS (`overflow-x` + `scroll-snap`) : le tactile,
 * l'inertie, la molette et le trackpad sont natifs, et le carrousel reste
 * utilisable même si le JavaScript ne charge pas. Le script de vue n'ajoute
 * que les commandes de confort — c'est lui qui les crée, pour qu'un bouton
 * mort n'existe jamais.
 *
 * Les variantes n'agissent QUE par le CSS : le HTML est identique dans les
 * trois, ce qui rend l'AC 2 vraie par construction (même principe que la
 * carte de la 3.2).
 */
final class RenduCarrousel
{
    public const DEFAUT = 'cartes';

    /** @var list<string> vocabulaire fermé : la valeur finit dans une classe CSS */
    public const VARIANTES = ['cartes', 'pleine-largeur', 'logos'];

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs, string $contenu = '', mixed $bloc = null): string
    {
        try {
            return $this->composer($attributs, $contenu);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_bloc_carrousel_echec', 'rendu interrompu : ' . $e->getMessage(), 'bloc carrousel');

            return '';
        }
    }

    /** @param array<string, mixed> $attributs */
    private function composer(array $attributs, string $contenu): string
    {
        /* Carrousel sans élément : pas de piste vide ni de commandes qui ne
           commandent rien (AD-3). Un `trim()` seul ne suffit pas — un enfant
           retiré laisse ses délimiteurs de bloc en commentaires, et une
           espace insécable n'est pas un blanc pour PHP : les deux ouvraient
           un `role="group"` nommé mais vide, annoncé au lecteur d'écran et
           doté d'un arrêt de tabulation mort. */
        if ($this->sansAucunElement($contenu)) {
            return '';
        }

        $variante = $this->variante($attributs);
        $libelle  = TexteRiche::filtrer($attributs['libelle'] ?? null);
        $nom      = TexteRiche::estVide($libelle)
            /* L'échappement se fait au point de sortie, plus bas : `esc_html__`
               ici ferait un second passage sans rien garantir de plus. */
            ? __('Carrousel', 'spiralbase')
            : wp_strip_all_tags($libelle);

        $classes = 'spiralbase-carrousel spiralbase-carrousel--' . $variante;

        /*
         * `role="group"` + nom accessible : le lecteur d'écran annonce la
         * zone et son étiquette. `tabindex="0"` la rend focalisable, ce qui
         * suffit aux navigateurs pour la piloter aux flèches — le clavier
         * fonctionne donc sans une ligne de JavaScript.
         */
        return '<div ' . EnveloppeBloc::attributs($classes) . '>'
            . '<div class="spiralbase-carrousel__piste" role="group" tabindex="0"'
            . ' aria-label="' . esc_attr($nom) . '"'
            . ' data-spiralbase-carrousel="' . esc_attr($variante) . '"'
            /* Les libellés des commandes sont TRADUITS ICI : le script de vue
               est du JavaScript nu, sans `wp-i18n` — les lui passer en
               attributs est le seul moyen qu'ils suivent la langue du site. */
            . ' data-spiralbase-precedent="' . esc_attr__('Élément précédent', 'spiralbase') . '"'
            . ' data-spiralbase-suivant="' . esc_attr__('Élément suivant', 'spiralbase') . '">'
            . $contenu
            . '</div></div>';
    }

    /** @param array<string, mixed> $attributs */
    private function variante(array $attributs): string
    {
        $valeur = $attributs['variante'] ?? null;

        if (is_string($valeur) && in_array($valeur, self::VARIANTES, true)) {
            return $valeur;
        }

        if ($valeur !== null && $valeur !== '') {
            Signal::emettre(
                'spiralbase_bloc_carrousel_variante_inconnue',
                sprintf(
                    'mise en forme « %s » inconnue, « %s » appliquée',
                    /* `(string) false` vaut '' : le message annonçait « mise
                       en forme «  » inconnue » — l'opérateur ne peut pas
                       chercher ce qu'aucun mot ne désigne. */
                    is_int($valeur) || is_float($valeur) || is_string($valeur)
                        ? (string) $valeur
                        : get_debug_type($valeur),
                    self::DEFAUT
                ),
                'bloc carrousel'
            );
        }

        return self::DEFAUT;
    }

    /**
     * « Aucun élément » et « aucun texte » sont deux questions distinctes :
     * un carrousel d'images n'a pas un seul caractère de texte et n'est pas
     * vide pour autant. On juge donc sur ce qui RESTE une fois les
     * commentaires retirés — une balise suffit à faire un élément.
     */
    private function sansAucunElement(string $contenu): bool
    {
        $utile = preg_replace('/<!--.*?-->/s', '', $contenu) ?? $contenu;

        if (preg_match('/<[a-z!\/]/i', $utile) === 1) {
            return false;
        }

        return TexteRiche::estVide($utile);
    }
}
