<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocRdv;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;
use SpiralBase\Core\SondeCession;

/**
 * Bloc « prise de rendez-vous » (CAP-12, story 3.4).
 *
 * PREMIER bloc métier qui CÈDE (AC 2) : contrairement aux blocs 3.1-3.3, un
 * plugin de réservation dédié ne se contente pas de doubler l'affichage — il
 * porte le calendrier, les disponibilités et les confirmations. Le CTA du
 * parent n'a plus lieu d'être, et le client utilisera le bloc du plugin.
 *
 * OFF par défaut (AD-6).
 */
final class BlocRdvModule implements Module
{
    public const OPTION = 'spiralbase_rdv';

    public const HANDLE_STYLE = 'spiralbase-rdv';

    private const REPERTOIRE = 'rdv';

    /**
     * Faits relevés dans Easy Appointments 3.12.28, installé dans
     * l'environnement de dev pour cette story (discipline 2.1-2.4 : jamais de
     * sonde sur des faits non lus) :
     *
     *  - `main.php:29` — `define('EA_SRC_DIR', …)` s'exécute au CHARGEMENT du
     *    fichier : le plugin s'instancie et s'initialise hors de tout hook
     *    (`main.php:371-372`), donc bien avant `after_setup_theme` où le
     *    registre évalue les sondes (leçon de timing 1.3/2.1) ;
     *  - `main.php:70` — la classe `EasyAppointment` n'existe que si le
     *    plugin est réellement chargé, dans TOUS les contextes.
     *
     * Le shortcode `ea_standard` (`src/frontend.php:60`) a d'abord servi de
     * second fait, avec une clause `is_admin()`. C'était une erreur, prouvée
     * en revue : le front d'EA s'enregistre INCONDITIONNELLEMENT hors admin
     * (`main.php:121-128`), donc le shortcode n'apprend rien de plus que le
     * chargement — mais la clause faisait céder l'ÉDITEUR dans un cas où le
     * front gardait la main, et Gutenberg affichait alors « ce bloc n'est pas
     * pris en charge » sur chaque occurrence d'une page qui, elle,
     * fonctionnait. Un verdict de cession doit être le MÊME partout.
     *
     * @var \Closure(): array{charge: bool, classe: bool}
     */
    private \Closure $faits;

    public function __construct(private readonly Options $options, ?callable $faits = null)
    {
        $this->faits = $faits === null
            ? static fn (): array => [
                'charge' => defined('EA_SRC_DIR'),
                'classe' => class_exists('EasyAppointment'),
            ]
            : \Closure::fromCallable($faits);
    }

    public function slug(): string
    {
        return 'bloc_rdv';
    }

    public function boot(): void
    {
        add_action('init', function (): void {
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => fn (array $attributs): string => (new RenduRdv($this->options))->rendre($attributs)]
            );

            if ($type === false) {
                /* Hook DISTINCT de l'échec de rendu (pattern 3.2) : « le bloc
                   n'a jamais pu s'enregistrer » appelle un déploiement, « un
                   rendu s'est interrompu » appelle un diagnostic. */
                Signal::emettre(
                    'spiralbase_bloc_rdv_enregistrement_echoue',
                    'bloc « rdv » non enregistré : répertoire ou block.json illisible',
                    'bloc rdv'
                );
            }
        });

        if (defined('WP_CLI') && WP_CLI) {
            /* La porte qui manquait : sans écran (Epic 6) ni profil métier
               (story 3.9), l'adresse n'était atteignable que par un
               `update_option` direct — hors de la porte AD-11. */
            \WP_CLI::add_command('spiralbase rdv', new \SpiralBase\Core\Cli\RdvCommand($this->options));
        }
    }

    public function defaultSettings(): array
    {
        return ['url' => ''];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            function (): bool {
                $faits = ($this->faits)();

                /* Fait COMPOSÉ (pattern 2.5) : la constante seule pourrait
                   être posée par un extrait de code ou une copie du plugin
                   laissée sur le disque ; la classe seule pourrait provenir
                   d'un chargeur qui n'a pas exécuté le fichier principal. Les
                   deux ensemble ne mentent pas — et valent la même chose au
                   front, en administration, en REST et en cron. */
                return ($faits['charge'] ?? false) && ($faits['classe'] ?? false);
            },
            /* Le produit est NOMMÉ : la sonde ne reconnaît qu'Easy Appointments
               (seul plugin de réservation lu), et une raison qui parlerait de
               « un plugin de réservation » ferait croire à une couverture que
               le code n'a pas — Amelia ou Bookly ne déclenchent rien.
               Même discipline que le patrimoine face à Rank Math. */
            static fn (): string => __('Easy Appointments est actif — le bouton du thème s\'efface devant lui.', 'spiralbase')
        );
    }
}
