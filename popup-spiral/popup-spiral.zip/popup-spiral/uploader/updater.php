<?php

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Config du plugin, gelee a l'init (placeholders substitues par makedev).
 */
function popup_spiral_get_config()
{
	// Config inline, injectee a l'init. L'updater ne depend PLUS de plugin-config.json
	// au runtime : ce fichier est exclu du ZIP de release, donc absent en prod. Les
	// valeurs sont gelees a la creation du plugin (make init).
	return [
		'slug'      => 'popup-spiral',
		'main_file' => 'popup-spiral.php',
		'github'    => [
			'user'         => 'spiraldev13',
			'repo'         => 'popup-spiral',
			'updates_repo' => 'wp-plugin-updates',
		],
	];
}

/**
 * Récupère une valeur de configuration avec support des chemins imbriqués.
 */
function popup_spiral_get_config_value($path, $default = '')
{
	$config = popup_spiral_get_config();
	$keys = explode('.', $path);

	$value = $config;
	foreach ($keys as $key) {
		if (!isset($value[$key])) {
			return $default;
		}
		$value = $value[$key];
	}

	return $value;
}

/**
 * Résout le chemin absolu du fichier principal du plugin.
 */
function popup_spiral_get_main_plugin_file_path()
{
	static $plugin_main_file = null;

	if ($plugin_main_file !== null) {
		return $plugin_main_file;
	}

	$main_file = (string) popup_spiral_get_config_value('main_file', basename(dirname(__DIR__)) . '.php');
	$main_file = ltrim($main_file, '/\\');

	// L'updater vit dans <plugin>/uploader/ : le fichier principal est dans le parent.
	$candidates = [
		dirname(__DIR__) . '/' . $main_file,
	];

	foreach ($candidates as $candidate) {
		if (file_exists($candidate)) {
			$plugin_main_file = $candidate;
			return $plugin_main_file;
		}
	}

	$plugin_main_file = '';
	return $plugin_main_file;
}

/**
 * Retourne le basename WordPress du plugin (compatible chemins custom).
 */
function popup_spiral_get_plugin_basename()
{
	static $plugin_basename = null;

	if ($plugin_basename !== null) {
		return $plugin_basename;
	}

	$plugin_main_file = popup_spiral_get_main_plugin_file_path();
	if ($plugin_main_file !== '') {
		$plugin_basename = plugin_basename($plugin_main_file);
		return $plugin_basename;
	}

	$slug = (string) popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$main_file = (string) popup_spiral_get_config_value('main_file', basename(dirname(__DIR__)) . '.php');
	$plugin_basename = trim($slug . '/' . ltrim($main_file, '/\\'), '/');

	return $plugin_basename;
}

/**
 * URL du manifest update.json (surchargable via constante ou filtre).
 */
function popup_spiral_get_manifest_url()
{
	$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$constant_name = strtoupper($slug) . '_UPDATE_MANIFEST_URL';

	// Vérifier si une constante surcharge l'URL
	if (defined($constant_name) && constant($constant_name)) {
		return esc_url_raw((string) constant($constant_name));
	}

	// Construire l'URL depuis la configuration
	$github_user = popup_spiral_get_config_value('github.user', 'spiraldev13');
	$updates_repo = popup_spiral_get_config_value('github.updates_repo', 'wp-plugin-updates');

	// Manifeste lu depuis raw.githubusercontent.com plutôt que l'API GitHub :
	// api.github.com est limitée à 60 requêtes/h par IP non authentifiée. Sur un
	// hébergement mutualisé (IP partagée entre de nombreux sites), ce quota est
	// vite épuisé → HTTP 403 et AUCUNE mise à jour détectée. raw sert le fichier
	// brut sans cette limite (l'URL du ZIP l'utilise déjà). Branche : main.
	$default_url = sprintf(
		'https://raw.githubusercontent.com/%s/%s/main/%s/update.json',
		$github_user,
		$updates_repo,
		$slug
	);

	$filter_name = $slug . '_update_manifest_url';
	return esc_url_raw((string) apply_filters($filter_name, $default_url));
}

/**
 * Log une erreur de l'updater (seulement si WP_DEBUG est activé).
 */
function popup_spiral_log_error($message, $context = [])
{
	if (!defined('WP_DEBUG') || !WP_DEBUG) {
		return;
	}

	$log_message = '[makedev Plugin Updater] ' . $message;

	if (!empty($context)) {
		$log_message .= ' | Context: ' . wp_json_encode($context);
	}

	error_log($log_message);
}

/**
 * Effectue une requête HTTP avec retry automatique.
 */
function popup_spiral_http_request_with_retry($url, $args = [], $max_attempts = 3)
{
	$is_background_context = wp_doing_cron() || (defined('WP_CLI') && WP_CLI);

	// En contexte admin interactif, éviter les blocages longs.
	if (!$is_background_context) {
		$max_attempts = 1;
		if (empty($args['timeout']) || (int) $args['timeout'] > 8) {
			$args['timeout'] = 8;
		}
	}

	$max_attempts = max(1, (int) $max_attempts);
	$attempt = 0;
	$last_error = null;
	$response = null;

	while ($attempt < $max_attempts) {
		$attempt++;

		$response = wp_remote_get($url, $args);

		// Succès
		if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
			if ($attempt > 1) {
				popup_spiral_log_error("Requête réussie après $attempt tentatives", ['url' => $url]);
			}
			return $response;
		}

		// Échec - logger et réessayer
		$last_error = is_wp_error($response) ? $response->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code($response);

		popup_spiral_log_error("Tentative $attempt/$max_attempts échouée", [
			'url' => $url,
			'error' => $last_error,
		]);

		// Attendre avant de réessayer (sauf dernière tentative)
		if ($is_background_context && $attempt < $max_attempts) {
			sleep(2);
		}
	}

	// Toutes les tentatives ont échoué
	popup_spiral_log_error("Échec après $max_attempts tentatives", [
		'url' => $url,
		'last_error' => $last_error,
	]);

	return is_wp_error($response) ? $response : new WP_Error('http_request_failed', $last_error);
}

/**
 * Récupère et valide le manifest de mise à jour (avec cache intelligent 1h).
 */
function popup_spiral_get_manifest_data($force_refresh = false)
{
	$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$cache_key = $slug . '_update_manifest_data';
	$cache_version_key = $slug . '_cached_version';

	// Force refresh ignorera le cache
	if (!$force_refresh) {
		$cached = get_site_transient($cache_key);
		$cached_version = get_site_transient($cache_version_key);

		// Retourner le cache si valide
		if (is_array($cached) && !empty($cached['version']) && !empty($cached['download_url'])) {
			return $cached;
		}
	}

	$manifest_url = popup_spiral_get_manifest_url();
	if (empty($manifest_url)) {
		popup_spiral_log_error('Manifest URL vide ou invalide');
		return null;
	}

	// Validation HTTPS stricte
	if (strpos($manifest_url, 'https://') !== 0) {
		popup_spiral_log_error('Manifest URL doit être en HTTPS', ['url' => $manifest_url]);
		return null;
	}

	$response = popup_spiral_http_request_with_retry($manifest_url, [
		'timeout' => 15,
		'sslverify' => true,
		'headers' => [
			'Accept'     => 'application/vnd.github.raw',
			'User-Agent' => 'WordPress-Plugin-Updater',
		],
	]);

	if (is_wp_error($response)) {
		popup_spiral_log_error('Échec de récupération du manifest', [
			'error' => $response->get_error_message(),
		]);
		return null;
	}

	$raw_data = json_decode(wp_remote_retrieve_body($response), true);
	if (!is_array($raw_data)) {
		popup_spiral_log_error('Manifest JSON invalide', [
			'body' => substr(wp_remote_retrieve_body($response), 0, 200),
		]);
		return null;
	}

	if (empty($raw_data['version']) || empty($raw_data['download_url'])) {
		popup_spiral_log_error('Manifest incomplet', [
			'version' => $raw_data['version'] ?? 'missing',
			'download_url' => $raw_data['download_url'] ?? 'missing',
		]);
		return null;
	}

	// Validation HTTPS pour download_url
	if (strpos($raw_data['download_url'], 'https://') !== 0) {
		popup_spiral_log_error('Download URL doit être en HTTPS', ['url' => $raw_data['download_url']]);
		return null;
	}

	$manifest = [
		'version' => sanitize_text_field((string) $raw_data['version']),
		'download_url' => esc_url_raw((string) $raw_data['download_url']),
		'details_url' => !empty($raw_data['details_url']) ? esc_url_raw((string) $raw_data['details_url']) : '',
		'tested' => !empty($raw_data['tested']) ? sanitize_text_field((string) $raw_data['tested']) : '6.7',
		'requires' => !empty($raw_data['requires']) ? sanitize_text_field((string) $raw_data['requires']) : '',
		'requires_php' => !empty($raw_data['requires_php']) ? sanitize_text_field((string) $raw_data['requires_php']) : '',
		'tag' => !empty($raw_data['tag']) ? sanitize_text_field((string) $raw_data['tag']) : '',
		'sha256' => !empty($raw_data['sha256']) ? strtolower(trim((string) $raw_data['sha256'])) : '',
	];

	// Cache réduit à 1h au lieu de 6h pour détecter les mises à jour plus rapidement
	set_site_transient($cache_key, $manifest, HOUR_IN_SECONDS);

	// Stocker la version pour invalidation intelligente
	set_site_transient($cache_version_key, $manifest['version'], HOUR_IN_SECONDS);

	return $manifest;
}

/**
 * Invalide le cache si une nouvelle version est détectée lors d'un check.
 */
function popup_spiral_smart_cache_invalidation()
{
	// Éviter les appels réseau forcés pendant les updates lancées depuis l'admin.
	if (!wp_doing_cron()) {
		return;
	}

	$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$cache_key = $slug . '_update_manifest_data';
	$cache_version_key = $slug . '_cached_version';
	$cached_version = get_site_transient($cache_version_key);

	if (empty($cached_version)) {
		return;
	}

	// Forcer un refresh pour comparer avec la version distante
	$fresh_manifest = popup_spiral_get_manifest_data(true);

	if (empty($fresh_manifest) || empty($fresh_manifest['version'])) {
		return;
	}

	// Si nouvelle version détectée, invalider le cache principal
	if (version_compare($fresh_manifest['version'], $cached_version, '>')) {
		popup_spiral_log_error('Nouvelle version détectée - invalidation du cache', [
			'cached' => $cached_version,
			'remote' => $fresh_manifest['version'],
		]);

		delete_site_transient($cache_key);
		delete_site_transient($cache_version_key);
	}
}

// Hook sur les vérifications périodiques de mises à jour WordPress
add_action('wp_update_plugins', 'popup_spiral_smart_cache_invalidation');

/**
 * Enregistre les informations de mise à jour dans l'interface native WordPress.
 */
function popup_spiral_register_updater($transient)
{
	if (!is_object($transient) || empty($transient->checked)) {
		return $transient;
	}

	$plugin_slug = popup_spiral_get_plugin_basename();
	if ($plugin_slug === '') {
		return $transient;
	}

	$current_version = isset($transient->checked[$plugin_slug]) ? $transient->checked[$plugin_slug] : null;

	if (empty($current_version)) {
		return $transient;
	}

	$manifest = popup_spiral_get_manifest_data();

	if (empty($manifest)) {
		return $transient;
	}

	if (version_compare($current_version, $manifest['version'], '<')) {
		// Construire l'URL de détails depuis la config
		$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
		$github_user = popup_spiral_get_config_value('github.user', 'spiraldev13');
		$github_repo = popup_spiral_get_config_value('github.repo', $slug);
		$fallback_url = "https://github.com/$github_user/$github_repo";

		$transient->response[$plugin_slug] = (object) [
			'slug' => dirname($plugin_slug),
			'plugin' => $plugin_slug,
			'new_version' => $manifest['version'],
			'package' => $manifest['download_url'],
			'url' => !empty($manifest['details_url']) ? $manifest['details_url'] : $fallback_url,
			'tested' => $manifest['tested'],
			'requires' => $manifest['requires'],
			'requires_php' => $manifest['requires_php'],
			'icons' => [],
		];
	}

	return $transient;
}

add_filter('pre_set_site_transient_update_plugins', 'popup_spiral_register_updater');

/**
 * Purge le cache manifest quand WordPress lance une vérification fraîche.
 * Se déclenche quand le transient update_plugins est supprimé (clic "Vérifier à nouveau").
 */
function popup_spiral_clear_manifest_cache()
{
	$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$cache_key = $slug . '_update_manifest_data';
	delete_site_transient($cache_key);
}

add_action('delete_site_transient_update_plugins', 'popup_spiral_clear_manifest_cache');

/**
 * Détermine si l'update en cours concerne ce plugin.
 */
function popup_spiral_is_our_plugin_update($package, $hook_extra = [])
{
	$slug = popup_spiral_get_config_value('slug', basename(dirname(__DIR__)));
	$plugin_basename = popup_spiral_get_plugin_basename();
	$plugin_dirname = $plugin_basename !== '' ? dirname($plugin_basename) : '';

	if (is_array($hook_extra)) {
		if (!empty($hook_extra['theme']) || !empty($hook_extra['themes'])) {
			return false;
		}

		if (!empty($hook_extra['type']) && $hook_extra['type'] !== 'plugin') {
			return false;
		}

		if (!empty($hook_extra['plugin']) && is_string($hook_extra['plugin'])) {
			return $hook_extra['plugin'] === $plugin_basename;
		}

		if (!empty($hook_extra['plugins']) && is_array($hook_extra['plugins'])) {
			return in_array($plugin_basename, $hook_extra['plugins'], true);
		}
	}

	if (!is_string($package) || $package === '') {
		return false;
	}

	if ($plugin_basename !== '' && strpos($package, $plugin_basename) !== false) {
		return true;
	}

	if ($plugin_dirname !== '' && $plugin_dirname !== '.' && strpos($package, '/' . $plugin_dirname . '/') !== false) {
		return true;
	}

	if (strpos($package, '/' . $slug . '/') !== false || strpos($package, $slug . '.zip') !== false) {
		return true;
	}

	return false;
}

/**
 * Vérifie l'intégrité du ZIP téléchargé via hash SHA256.
 * Hook: upgrader_pre_download (court-circuite le téléchargement WordPress).
 */
function popup_spiral_verify_package_integrity($reply, $package, $updater = null, $hook_extra = [])
{
	// Si un autre filtre a déjà répondu, respecter sa valeur.
	if (false !== $reply) {
		return $reply;
	}

	if (!is_string($package) || $package === '') {
		return $reply;
	}

	// N'intervenir que pour notre plugin.
	if (!popup_spiral_is_our_plugin_update($package, $hook_extra)) {
		return $reply;
	}

	// Récupérer le hash attendu depuis le manifest
	$manifest = popup_spiral_get_manifest_data();
	if (empty($manifest) || empty($manifest['sha256'])) {
		popup_spiral_log_error('Impossible de vérifier l\'intégrité: hash non disponible dans le manifest');
		// On continue quand même (rétrocompatibilité avec anciens manifests sans hash)
		return $reply;
	}

	$expected_hash = $manifest['sha256'];

	// Télécharger le ZIP nous-mêmes pour pouvoir valider l'intégrité
	if (!function_exists('download_url')) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}

	$downloaded_file = download_url($package, 60);
	if (is_wp_error($downloaded_file)) {
		popup_spiral_log_error('Échec du téléchargement du package', [
			'package' => $package,
			'error' => $downloaded_file->get_error_message(),
		]);
		// Ne pas bloquer les mises à jour globales: laisser WordPress gérer le download natif.
		return false;
	}

	// Calculer le hash du fichier téléchargé
	if (!file_exists($downloaded_file)) {
		popup_spiral_log_error('Fichier téléchargé introuvable', ['path' => $downloaded_file]);
		return false;
	}

	$actual_hash = hash_file('sha256', $downloaded_file);

	if ($actual_hash === false) {
		@unlink($downloaded_file);
		popup_spiral_log_error('Impossible de calculer le hash du fichier téléchargé');
		return false;
	}

	// Comparer les hashs
	if ($actual_hash !== $expected_hash) {
		popup_spiral_log_error('Hash invalide - package corrompu ou modifié', [
			'expected' => $expected_hash,
			'actual' => $actual_hash,
		]);

		// Supprimer le fichier corrompu
		@unlink($downloaded_file);

		return new WP_Error(
			'package_integrity_failed',
			sprintf(
				'L\'intégrité du package n\'a pas pu être vérifiée. Hash attendu: %s, obtenu: %s',
				substr($expected_hash, 0, 16) . '...',
				substr($actual_hash, 0, 16) . '...'
			)
		);
	}

	popup_spiral_log_error('Intégrité du package vérifiée avec succès', [
		'hash' => substr($actual_hash, 0, 16) . '...',
	]);

	return $downloaded_file;
}

// IMPORTANT: temporairement désactivé car certains hébergements bloquent les mises à jour globales
// (plugins/thèmes tiers) lors de ce hook. Réactiver après validation complète sur tous les environnements.
// add_filter('upgrader_pre_download', 'popup_spiral_verify_package_integrity', 10, 4);
