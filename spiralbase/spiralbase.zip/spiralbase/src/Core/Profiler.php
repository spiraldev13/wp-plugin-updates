<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Profiler interne ultra léger — repris d'ultimate-shanks (verdict
 * brownfield), renommé et typé. Comportements de l'original préservés :
 * seuil de 120 ms pour la ligne « slow », agrégation count/total/max,
 * résumé de requête au shutdown en UNE ligne plafonnée aux 6 sections les
 * plus coûteuses, discriminant de contexte `req=admin|ajax|cron|front`.
 *
 * Opt-in strict par constante `SPIRALBASE_PROFILE` (wp-config.php) : quand
 * il dort, `start()`/`stop()` court-circuitent avant tout calcul — le
 * profiler ne coûte rien en production. Aucune API de test n'est exposée :
 * le journal passe toujours par `error_log()`, y compris sous PHPUnit.
 */
final class Profiler
{
    public const SEUIL_LENT_MS = 120.0;

    /** Plafond du résumé (fidèle à l'original) — les 6 sections les plus coûteuses. */
    private const TOP_RESUME = 6;

    /** Garde-fou mémoire : au-delà, on cesse de créer de nouvelles sections. */
    private const MAX_SECTIONS = 200;

    private const MAX_URI = 255;

    private static ?bool $active = null;

    /** @var array<string, array{count: int, total_ms: float, max_ms: float}> */
    private static array $stats = [];

    public static function init(): void
    {
        if (!self::isEnabled()) {
            return;
        }

        add_action('shutdown', [self::class, 'logRequestSummary'], PHP_INT_MAX);
    }

    public static function isEnabled(): bool
    {
        if (self::$active !== null) {
            return self::$active;
        }

        /* 'false', '0', 'off' en wp-config doivent désactiver, pas activer. */
        self::$active = defined('SPIRALBASE_PROFILE')
            && filter_var(SPIRALBASE_PROFILE, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) === true;

        return self::$active;
    }

    /** Démarre un chrono ; null quand le profiler dort (stop() l'ignorera). */
    public static function start(string $nom): ?float
    {
        if (!self::isEnabled() || !self::nomValide($nom)) {
            return null;
        }

        return microtime(true);
    }

    /**
     * Arrête un chrono, agrège, et journalise si la section dépasse le seuil.
     *
     * @param array<string, mixed> $contexte
     */
    public static function stop(string $nom, ?float $depuis, array $contexte = []): void
    {
        if (!self::isEnabled() || !self::nomValide($nom) || $depuis === null) {
            return;
        }

        $maintenant = microtime(true);

        /* Chrono impossible (horloge, valeur fabriquée) : signalé, pas agrégé. */
        if ($depuis > $maintenant) {
            error_log(sprintf('[spiralbase Profiler] chrono invalide section=%s', $nom));

            return;
        }

        if (!isset(self::$stats[$nom]) && count(self::$stats) >= self::MAX_SECTIONS) {
            return;
        }

        $ecouleMs = max(0.0, ($maintenant - $depuis) * 1000);

        if (!isset(self::$stats[$nom])) {
            self::$stats[$nom] = ['count' => 0, 'total_ms' => 0.0, 'max_ms' => 0.0];
        }

        self::$stats[$nom]['count']++;
        self::$stats[$nom]['total_ms'] += $ecouleMs;
        self::$stats[$nom]['max_ms'] = max(self::$stats[$nom]['max_ms'], $ecouleMs);

        if ($ecouleMs >= self::SEUIL_LENT_MS) {
            $suffixe = self::formaterContexte($contexte);

            error_log(sprintf(
                '[spiralbase Profiler] slow section=%s time=%.2fms%s',
                $nom,
                $ecouleMs,
                $suffixe === '' ? '' : ' ' . $suffixe
            ));
        }
    }

    /**
     * Résumé de fin de requête : UNE ligne (contexte, durée, pic mémoire,
     * top sections) — comme l'original, pour ne pas inonder le journal.
     */
    public static function logRequestSummary(): void
    {
        if (!self::isEnabled() || self::$stats === []) {
            return;
        }

        $stats = self::$stats;
        /* Les statistiques ne survivent pas à la requête (worker persistant). */
        self::$stats = [];

        uasort($stats, static fn (array $a, array $b): int => $b['total_ms'] <=> $a['total_ms']);

        $top = [];

        foreach ($stats as $nom => $mesure) {
            if (count($top) >= self::TOP_RESUME) {
                break;
            }

            $top[] = sprintf('%s(%dx,%.1fms,max%.1f)', $nom, $mesure['count'], $mesure['total_ms'], $mesure['max_ms']);
        }

        error_log(sprintf(
            '[spiralbase Profiler] summary req=%s uri=%s total=%s peak=%.2fMo top=%s',
            self::contexteRequete(),
            self::uri(),
            self::dureeRequete(),
            memory_get_peak_usage(true) / 1048576,
            implode(' ', $top)
        ));
    }

    /** @return array<string, array{count: int, total_ms: float, max_ms: float}> */
    public static function stats(): array
    {
        return self::$stats;
    }

    /** Remise à zéro complète — utilisée entre deux scénarios de test. */
    public static function reinitialiser(): void
    {
        self::$active = null;
        self::$stats  = [];
    }

    private static function nomValide(string $nom): bool
    {
        return $nom !== '' && preg_match('/^[A-Za-z0-9_.:\-]{1,64}$/', $nom) === 1;
    }

    /** Discriminant repris de l'original : un pic AJAX ne se lit pas comme un pic front. */
    private static function contexteRequete(): string
    {
        if (defined('WP_CLI') && WP_CLI) {
            return 'cli';
        }

        if (function_exists('wp_doing_cron') && wp_doing_cron()) {
            return 'cron';
        }

        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            return 'ajax';
        }

        if (function_exists('is_admin') && is_admin()) {
            return 'admin';
        }

        return 'front';
    }

    private static function dureeRequete(): string
    {
        $debut = isset($_SERVER['REQUEST_TIME_FLOAT']) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : 0.0;
        $fin   = microtime(true);

        /* Valeur absente ou aberrante : le dire, plutôt qu'afficher un chiffre faux. */
        if ($debut <= 0.0 || $debut > $fin) {
            return 'inconnu';
        }

        return sprintf('%.2fms', ($fin - $debut) * 1000);
    }

    private static function uri(): string
    {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : 'cli';

        /* Entrée contrôlée par le client : assainie et bornée avant le journal. */
        return substr(str_replace(["\r", "\n", ' '], ['', '', '%20'], $uri), 0, self::MAX_URI);
    }

    /** @param array<string, mixed> $contexte */
    private static function formaterContexte(array $contexte): string
    {
        $paires = [];

        foreach ($contexte as $cle => $valeur) {
            $paires[] = sprintf('%s=%s', (string) $cle, self::valeurLisible($valeur));
        }

        return implode(' ', $paires);
    }

    private static function valeurLisible(mixed $valeur): string
    {
        if ($valeur === null) {
            return 'null';
        }

        if (is_bool($valeur)) {
            return $valeur ? 'true' : 'false';
        }

        if (!is_scalar($valeur)) {
            /* Ne jamais perdre l'information en silence : dire le type. */
            return '<' . get_debug_type($valeur) . '>';
        }

        /* Fidèle à l'original ((string) $valeur), délimiteurs du format key=value préservés. */
        return str_replace(["\r", "\n", ' '], ['', '', '_'], (string) $valeur);
    }
}
