<?php

declare(strict_types=1);

namespace SpiralBase\Modules\RelatedPostsInline;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;
use SpiralBase\Core\Walker;

/**
 * Related posts inline (CAP-9, story 2.7) : INSERTION du walker après le
 * N-ième paragraphe (réglable) — articles publiés partageant une
 * catégorie avec le post courant. Rien sans candidat : aucune balise vide.
 *
 * Contrat 2.6/2.7 tranché : « après le paragraphe N » compte les unités
 * POST-transformations (après découpage) — documenté au Walker, testé.
 *
 * Sonde (fait LU dans le plugin réel intelly-related-posts) : IRP hooke
 * `the_content` dès qu'il est actif (`includes/core.php:227`) — fait :
 * `IRP_PLUGIN_VERSION` définie.
 */
final class RelatedPostsInlineModule implements Module
{
    public const OPTION = 'spiralbase_related_posts';

    public function __construct(
        private readonly Walker $walker,
        private readonly Options $options,
        private readonly ?\Closure $faitIrp = null,
    ) {
    }

    public function slug(): string
    {
        return 'related_posts_inline';
    }

    public function boot(): void
    {
        $this->walker->addInsertion(
            'related_posts',
            Walker::POINT_APRES_PARAGRAPHE,
            fn (array $contexte): string => $this->rendre(),
            $this->reglage('apres_paragraphe')
        );
    }

    public function defaultSettings(): array
    {
        return ['apres_paragraphe' => 2, 'nombre' => 3];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitIrp ?? static fn (): bool => defined('IRP_PLUGIN_VERSION'),
            static fn (): string => __('Related posts réellement insérés par Inline Related Posts.', 'spiralbase')
        );
    }

    /** Encart depuis la taxonomie partagée — le walker attrape les Throwable. */
    private function rendre(): string
    {
        $post = get_post();

        if (!is_object($post) || (($post->post_type ?? '') !== 'post')) {
            return '';
        }

        $categories = array_values(array_filter(array_map(
            static fn ($c): int => is_object($c) ? (int) ($c->term_id ?? 0) : 0,
            (array) get_the_category((int) ($post->ID ?? 0))
        )));

        if ($categories === []) {
            return '';
        }

        $lies = get_posts([
            'numberposts'            => $this->reglage('nombre'),
            'post_status'            => 'publish',
            'category__in'           => $categories,
            'post__not_in'           => [(int) ($post->ID ?? 0)],
            /* Revue 2.7 : les filtres SQL des tiers (multilingue…) doivent
               s'appliquer, et seuls titre+permalien sont consommés — pas
               d'amorçage inutile des caches meta/terms. */
            'suppress_filters'       => false,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);

        if (!is_array($lies) || $lies === []) {
            return '';
        }

        $items = '';

        foreach ($lies as $lie) {
            $titre = is_object($lie) ? (string) ($lie->post_title ?? '') : '';
            $lien  = is_object($lie) ? get_permalink((int) ($lie->ID ?? 0)) : false;

            if ($titre === '' || !is_string($lien) || $lien === '') {
                continue;
            }

            $items .= '<li><a href="' . esc_url($lien) . '">' . esc_html($titre) . '</a></li>';
        }

        if ($items === '') {
            return '';
        }

        return '<aside class="spiralbase-related" aria-label="' . esc_attr__('À lire aussi', 'spiralbase') . '">'
            . '<p class="spiralbase-related__titre">' . esc_html__('À lire aussi', 'spiralbase') . '</p>'
            . '<ul>' . $items . '</ul></aside>';
    }

    /** Réglage assaini — corrompu = défaut sûr. */
    private function reglage(string $cle): int
    {
        $reglages = $this->options->get(self::OPTION, []);
        $valeur   = is_array($reglages) && is_numeric($reglages[$cle] ?? null) ? (int) $reglages[$cle] : 0;

        return $valeur > 0 ? $valeur : (int) $this->defaultSettings()[$cle];
    }
}
