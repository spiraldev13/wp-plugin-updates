#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Self-update avec copie atomique
# Met a jour .make/ et .claude/ sans toucher project.conf ni Makefile
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

source "$SCRIPT_DIR/utils.sh"

# Charger les repos depuis project.conf
MAKEDEV_REPO="${MAKEDEV_REPO:-git@github.com:spiraldev13/makedev.git}"
CLAUDE_REPO="${CLAUDE_REPO:-git@github.com:spiraldev13/claude-config.git}"

if [ -f "$PROJECT_ROOT/project.conf" ]; then
  source "$PROJECT_ROOT/project.conf"
fi

# === Copie atomique avec rollback ===

atomic_update() {
  local repo="$1"
  local target="$2"
  local label="$3"
  local tmp_dir=""
  local backup_dir=""

  tmp_dir="$(mktemp -d)"

  info "Mise a jour de $label..."
  if ! git clone --depth 1 "$repo" "$tmp_dir/clone" >/dev/null 2>&1; then
    rm -rf "$tmp_dir"
    warn "Clone de $repo echoue (reseau ?). $label non mis a jour."
    return 1
  fi

  rm -rf "$tmp_dir/clone/.git"

  # Backup de l'existant
  if [ -d "$target" ]; then
    backup_dir="${target}.bak.$$"
    mv "$target" "$backup_dir"
  fi

  # Copie atomique
  if ! mv "$tmp_dir/clone" "$target"; then
    warn "Copie echouee. Rollback en cours..."
    if [ -n "$backup_dir" ] && [ -d "$backup_dir" ]; then
      mv "$backup_dir" "$target"
      warn "Etat precedent restaure."
    fi
    rm -rf "$tmp_dir"
    error "Mise a jour de $label echouee."
    return 1
  fi

  # Nettoyage
  if [ -n "$backup_dir" ] && [ -d "$backup_dir" ]; then
    rm -rf "$backup_dir"
  fi
  rm -rf "$tmp_dir"

  ok "$label mis a jour."
  return 0
}

# === Main ===

run_self_update() {
  echo ""
  printf "%b%bmakedev — Self-update%b\n" "$C_BOLD" "$C_CYAN" "$C_RESET"
  printf "%b====================%b\n\n" "$C_CYAN" "$C_RESET"

  local has_error=false

  # Mise a jour .make/
  if atomic_update "$MAKEDEV_REPO" "$PROJECT_ROOT/.make" ".make/"; then
    # Nettoyer les fichiers du projet makedev (inutiles dans .make/)
    rm -f "$PROJECT_ROOT/.make/Makefile" "$PROJECT_ROOT/.make/project.conf" "$PROJECT_ROOT/.make/version.txt" "$PROJECT_ROOT/.make/.gitignore"
    rm -rf "$PROJECT_ROOT/.make/_bmad" "$PROJECT_ROOT/.make/_bmad-output" "$PROJECT_ROOT/.make/.claude" "$PROJECT_ROOT/.make/docs"
  else
    has_error=true
  fi

  # Mise a jour Claude (seulement si .claude/ existe)
  if [ -d "$PROJECT_ROOT/.claude" ]; then
    echo ""
    info "Mise a jour de la config Claude..."
    local tmp_claude
    tmp_claude="$(mktemp -d)"
    if git clone --depth 1 "$CLAUDE_REPO" "$tmp_claude/clone" >/dev/null 2>&1; then
      local src="$tmp_claude/clone/claude-code-projet"
      if [ -d "$src" ]; then
        # Copier README dans .claude/
        [ -f "$src/README.md" ] && cp "$src/README.md" "$PROJECT_ROOT/.claude/README.md"
        # Mettre a jour .claude/ (settings, rules, docs)
        [ -d "$src/.claude" ] && cp -a "$src/.claude/." "$PROJECT_ROOT/.claude/"
        # Mettre a jour CLAUDE.md et tasks/
        [ -f "$src/CLAUDE.md" ] && cp "$src/CLAUDE.md" "$PROJECT_ROOT/CLAUDE.md"
        [ -d "$src/tasks" ] && cp -a "$src/tasks/." "$PROJECT_ROOT/tasks/"
        ok "Config Claude mise a jour."
      else
        warn "Dossier claude-code-projet/ introuvable dans claude-config."
        has_error=true
      fi
      rm -rf "$tmp_claude"
    else
      rm -rf "$tmp_claude"
      warn "Clone de claude-config echoue (reseau ?). Config Claude non mise a jour."
      has_error=true
    fi
  else
    info ".claude/ non present, mise a jour ignoree."
  fi

  echo ""
  if [ "$has_error" = true ]; then
    warn "Self-update termine avec des avertissements. Verifiez les messages ci-dessus."
  else
    ok "Self-update termine avec succes !"
  fi

  info "project.conf et Makefile non modifies."
}

run_self_update
