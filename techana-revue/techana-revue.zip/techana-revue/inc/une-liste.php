<?php
/**
 * Colonne « À la une » de la liste des articles (edit.php) — composer la une
 * sans ouvrir chaque article : la case s'enregistre au clic, en Ajax.
 *
 * Même méta et même sémantique que la case du panneau d'éditeur
 * (inc/metas.php) : cochée = `_techana_une` à '1', décochée = méta retirée.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_UNE_COLONNE = 'techana_une';
const TECHANA_UNE_ACTION  = 'techana-une-bascule';

add_filter( 'manage_post_posts_columns', 'techanaRevueUneColonne' );
add_action( 'manage_post_posts_custom_column', 'techanaRevueUneColonneCase', 10, 2 );
add_action( 'admin_enqueue_scripts', 'techanaRevueUneListeAssets' );
add_action( 'admin_head-edit.php', 'techanaRevueUneListeStyle' );
add_action( 'wp_ajax_' . TECHANA_UNE_ACTION, 'techanaRevueUneBascule' );

/**
 * Colonne insérée juste après le titre — là où l'œil descend la liste.
 *
 * @param array $colonnes Colonnes de la liste.
 * @return array
 */
function techanaRevueUneColonne( array $colonnes ): array {
    $sortie = array();
    foreach ( $colonnes as $cle => $libelle ) {
        $sortie[ $cle ] = $libelle;
        if ( 'title' === $cle ) {
            $sortie[ TECHANA_UNE_COLONNE ] = 'À la une';
        }
    }
    // Filet si le thème d'admin n'expose pas de colonne « title ».
    if ( ! isset( $sortie[ TECHANA_UNE_COLONNE ] ) ) {
        $sortie[ TECHANA_UNE_COLONNE ] = 'À la une';
    }
    return $sortie;
}

/**
 * @param string $colonne Colonne rendue.
 * @param int    $postId  Article de la ligne.
 */
function techanaRevueUneColonneCase( string $colonne, int $postId ) {
    if ( TECHANA_UNE_COLONNE !== $colonne ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $postId ) ) {
        echo '<span aria-hidden="true">—</span>';
        return;
    }
    printf(
        '<label class="techana-une-cellule"><input type="checkbox" class="techana-une-case"'
            . ' data-post="%1$d" %2$s /><span class="screen-reader-text">%3$s</span>'
            . '<span class="techana-une-etat" aria-live="polite"></span></label>',
        $postId,
        checked( get_post_meta( $postId, '_techana_une', true ), '1', false ),
        esc_html( sprintf( 'Afficher « %s » à la une', get_the_title( $postId ) ) )
    );
}

function techanaRevueUneListeAssets( string $hook ) {
    $ecran = get_current_screen();
    if ( 'edit.php' !== $hook || ! $ecran || 'post' !== $ecran->post_type ) {
        return;
    }
    wp_enqueue_script(
        'techana-revue-liste-une',
        get_theme_file_uri( 'assets/js/liste-une.js' ),
        array(),
        TECHANA_REVUE_VERSION,
        true
    );
    wp_localize_script( 'techana-revue-liste-une', 'techanaUne', array(
        'url'    => admin_url( 'admin-ajax.php' ),
        'action' => TECHANA_UNE_ACTION,
        'nonce'  => wp_create_nonce( TECHANA_UNE_ACTION ),
        'erreur' => 'Échec de l’enregistrement',
    ) );
}

/**
 * Colonne étroite et centrée — quelques règles, pas de feuille dédiée.
 */
function techanaRevueUneListeStyle() {
    $ecran = get_current_screen();
    if ( ! $ecran || 'post' !== $ecran->post_type ) {
        return;
    }
    echo '<style>'
        . '.column-techana_une{width:5.5em;text-align:center}'
        . '.techana-une-cellule{display:inline-flex;align-items:center;gap:4px}'
        . '.techana-une-case:disabled{opacity:.5}'
        . '.techana-une-etat{font-size:12px;line-height:1}'
        . '.techana-une-etat.ok{color:#00a32a}'
        . '.techana-une-etat.ko{color:#d63638}'
        . '</style>';
}

/**
 * Bascule Ajax de la méta. Décocher retire la ligne plutôt que d'y écrire une
 * chaîne vide — la sélection se lit sur `meta_value = '1'`.
 */
function techanaRevueUneBascule() {
    check_ajax_referer( TECHANA_UNE_ACTION );

    $postId = isset( $_POST['post'] ) ? (int) $_POST['post'] : 0;
    if ( ! $postId || 'post' !== get_post_type( $postId ) ) {
        wp_send_json_error( array( 'message' => 'Article introuvable.' ), 400 );
    }
    if ( ! current_user_can( 'edit_post', $postId ) ) {
        wp_send_json_error( array( 'message' => 'Modification refusée.' ), 403 );
    }

    $actif = isset( $_POST['actif'] ) && 'true' === $_POST['actif'];
    if ( $actif ) {
        update_post_meta( $postId, '_techana_une', '1' );
    } else {
        delete_post_meta( $postId, '_techana_une' );
    }

    wp_send_json_success( array(
        'actif' => $actif,
        'total' => count( techanaRevueUneMarques() ),
    ) );
}
