#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Workflow Git (git, merge, feature, feature-merge)
# Usage: bash core/scripts/git.sh {git|merge|feature|feature-merge|branch-dev}
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/load-config.sh"

ACTION="${1:-}"

# Charger la config projet
load_project_config "$(pwd)"

# === Fonctions de versioning ===

read_version() {
  local file="$1"

  if [ ! -f "$file" ]; then
    return 0
  fi

  case "$VERSION_FORMAT" in
    semver)
      head -n1 "$file"
      ;;
    php-return)
      awk -F"'" "/return[[:space:]]*'/{print \$2; exit}" "$file"
      ;;
    css-header)
      grep -oP '^Version:\s*\K\S+' "$file" 2>/dev/null || true
      ;;
    php-array)
      check_python3
      python3 -c "
import re, sys
text = open(sys.argv[1]).read()
m = re.search(r\"'number'\s*=>\s*'([^']+)'\", text)
print(m.group(1) if m else '')
" "$file"
      ;;
    *)
      head -n1 "$file"
      ;;
  esac
}

write_version() {
  local file="$1"
  local version="$2"

  case "$VERSION_FORMAT" in
    semver)
      printf "%s\n" "$version" > "$file"
      ;;
    php-return)
      printf "%s\n" "<?php" \
        "/**" \
        " * Version du projet" \
        " *" \
        " * Format: Semantic Versioning (MAJOR.MINOR.PATCH)" \
        " * - MAJOR: Changements majeurs (breaking changes)" \
        " * - MINOR: Nouvelles fonctionnalites (compatibles)" \
        " * - PATCH: Corrections de bugs" \
        " */" \
        "" \
        "return '$version';" > "$file"
      ;;
    css-header)
      sed -i "s/^\(Version:\s*\).*/\1$version/" "$file"
      ;;
    php-array)
      check_python3
      local today
      today="$(date +%F)"
      python3 -c "
import re, sys

path = sys.argv[1]
version = sys.argv[2]
today = sys.argv[3]

try:
    text = open(path, 'r').read()
except FileNotFoundError:
    text = '<?php\n\nreturn [\n];\n'

def upsert(content, key, value):
    pattern = re.compile(rf\"('{re.escape(key)}'\s*=>\s*')[^']*(')\")
    if pattern.search(content):
        return pattern.sub(lambda m: f'{m.group(1)}{value}{m.group(2)}', content, count=1)
    insert_line = f\"    '{key}' => '{value}',\n\"
    close_match = re.search(r'^\s*\];\s*$', content, flags=re.MULTILINE)
    if close_match:
        idx = close_match.start()
        return content[:idx] + insert_line + content[idx:]
    return content + insert_line

text = upsert(text, 'number', version)
text = upsert(text, 'date', today)

with open(path, 'w') as fh:
    fh.write(text)
" "$file" "$version" "$today"
      ;;
    *)
      printf "%s\n" "$version" > "$file"
      ;;
  esac
}

bootstrap_version_file() {
  local file="$1"
  local initial_version="${2:-1.0.0}"

  if [ -f "$file" ]; then
    return 0
  fi

  mkdir -p "$(dirname "$file")"
  write_version "$file" "$initial_version"
  info "$file cree avec version initiale $initial_version"
}

prompt_version_update() {
  bootstrap_version_file "$VERSION_FILE" "1.0.0"
  local current_version
  current_version="$(read_version "$VERSION_FILE" || true)"
  if [ -z "$current_version" ]; then
    current_version="non definie"
  fi

  echo ""
  printf "%bVersion actuelle:%b %b%s%b\n" "$C_RED$C_BOLD" "$C_RESET" "$C_RED" "$current_version" "$C_RESET"

  if [[ "$current_version" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)$ ]]; then
    local major="${BASH_REMATCH[1]}"
    local minor="${BASH_REMATCH[2]}"
    local patch="${BASH_REMATCH[3]}"

    local next_patch="$major.$minor.$((patch + 1))"
    local next_minor="$major.$((minor + 1)).0"
    local next_major="$((major + 1)).0.0"

    echo ""
    printf "%bChoisissez le type de version :%b\n" "$C_BOLD" "$C_RESET"
    printf "  %b1)%b %bPatch%b   %b->%b %b%s%b (corrections, ajustements mineurs)\n" "$C_YELLOW" "$C_RESET" "$C_BLUE" "$C_RESET" "$C_CYAN" "$C_RESET" "$C_GREEN" "$next_patch" "$C_RESET"
    printf "  %b2)%b %bMinor%b   %b->%b %b%s%b (nouvelles fonctionnalites)\n" "$C_YELLOW" "$C_RESET" "$C_BLUE" "$C_RESET" "$C_CYAN" "$C_RESET" "$C_GREEN" "$next_minor" "$C_RESET"
    printf "  %b3)%b %bMajor%b   %b->%b %b%s%b (changements majeurs)\n" "$C_YELLOW" "$C_RESET" "$C_BLUE" "$C_RESET" "$C_CYAN" "$C_RESET" "$C_GREEN" "$next_major" "$C_RESET"
    printf "  %b4)%b %bCustom%b  %b->%b Saisir manuellement\n" "$C_YELLOW" "$C_RESET" "$C_BLUE" "$C_RESET" "$C_CYAN" "$C_RESET"
    echo ""
    read -r -p "Choix [1/2/3/4 ou Entree pour passer] : " choice

    local new_version=""
    case "$choice" in
      "")
        info "Version conservee: $current_version"
        return 0
        ;;
      1) new_version="$next_patch" ;;
      2) new_version="$next_minor" ;;
      3) new_version="$next_major" ;;
      4)
        read -r -p "Version custom (ex: 1.2.3) : " new_version
        if [ -z "$new_version" ]; then
          info "Version conservee: $current_version"
          return 0
        fi
        ;;
      *)
        info "Choix invalide, version conservee: $current_version"
        return 0
        ;;
    esac
  else
    echo ""
    info "Version non semver detectee. Saisie manuelle uniquement."
    read -r -p "Nouvelle version ? (Entree pour ne pas changer): " new_version
    if [ -z "$new_version" ]; then
      info "Version conservee: $current_version"
      return 0
    fi
  fi

  if [ "$new_version" = "$current_version" ]; then
    info "Version inchangee: $current_version"
    return 0
  fi

  write_version "$VERSION_FILE" "$new_version"
  git add "$VERSION_FILE"
  ok "Version mise a jour dans $VERSION_FILE: $new_version"
}

# === Fonctions utilitaires merge ===

checkout_main_branch() {
  local remote="$1"
  local main_branch="$2"

  if git show-ref --verify --quiet "refs/heads/$main_branch"; then
    git checkout "$main_branch"
    return 0
  fi

  if git show-ref --verify --quiet "refs/remotes/$remote/$main_branch"; then
    git checkout -b "$main_branch" "$remote/$main_branch"
    return 0
  fi

  error "Branche $main_branch introuvable (locale ou remote $remote)."
  return 1
}

remote_branch_exists() {
  local remote="$1"
  local branch="$2"
  git ls-remote --exit-code --heads "$remote" "$branch" >/dev/null 2>&1
}

# === Post-merge hook ===

run_post_merge_hook() {
  if [ -z "${POST_MERGE_HOOK:-}" ]; then
    return 0
  fi

  local hook_script="$MAKEDEV_DIR/types/$PROJECT_TYPE/$POST_MERGE_HOOK"
  if [ ! -f "$hook_script" ]; then
    warn "Hook post-merge configure ($POST_MERGE_HOOK) mais fichier introuvable: $hook_script"
    return 0
  fi

  echo ""
  info "Execution du hook post-merge: $POST_MERGE_HOOK"
  export MAKEDEV_DIR PROJECT_TYPE PROJECT_SLUG VERSION_FILE VERSION_FORMAT
  if ! bash "$hook_script"; then
    warn "Hook post-merge echoue. Le merge reste valide."
  fi
}

# === Actions ===

run_git() {
  ensure_repo
  ensure_branch_in "dev" "feature/*"

  prompt_version_update

  git add -A
  if git diff --cached --quiet; then
    info "Aucun changement a commiter."
    exit 0
  fi

  echo ""
  read -r -p "Message du commit: " msg
  if [ -z "$msg" ]; then
    error "Message vide, annule."
    exit 1
  fi

  git commit -m "$msg"

  local remote=""
  if remote="$(resolve_remote "" 2>/dev/null)"; then
    push_branch "$remote" "$(git branch --show-current)"
    echo ""
    ok "Modifications commitees et poussees sur $remote."
  else
    echo ""
    warn "Aucun remote configure, push ignore."
    ok "Modifications commitees localement."
  fi
}

run_merge() {
  ensure_repo
  ensure_branch "dev"

  # Verifier s'il y a des changements AVANT de proposer le versioning
  git add -A
  if ! git diff --cached --quiet; then
    # Il y a des changements non commites → proposer version + commit
    git reset HEAD -- . >/dev/null 2>&1
    prompt_version_update
    echo ""
    git add -A
    read -r -p "Message du commit: " msg
    if [ -z "$msg" ]; then
      error "Message vide, annule."
      exit 1
    fi
    git commit -m "$msg"
  else
    info "Aucun changement local a commiter sur dev."
  fi

  local remote=""
  if ! remote="$(resolve_remote "" 2>/dev/null)"; then
    warn "Aucun remote configure, push ignore."
    # Merge local uniquement
    info "Merge de dev vers main..."
    checkout_main_branch "" "main" 2>/dev/null || git checkout main
    local merge_msg
    merge_msg="$(git log -1 --pretty=%s dev || true)"
    if [ -z "$merge_msg" ]; then
      merge_msg="merge: dev -> main"
    fi
    git merge --no-ff dev -m "$merge_msg"
    run_post_merge_hook
    git checkout dev
    echo ""
    ok "Branche dev mergee dans main et retour sur dev."
    return 0
  fi

  push_branch "$remote" "dev"
  echo ""
  info "Merge de dev vers main..."

  checkout_main_branch "$remote" "main"
  if remote_branch_exists "$remote" "main"; then
    git pull --ff-only "$remote" "main"
  else
    info "Branche distante $remote/main absente: pull ignore (premier push)."
  fi

  local merge_msg
  merge_msg="$(git log -1 --pretty=%s dev || true)"
  if [ -z "$merge_msg" ]; then
    merge_msg="merge: dev -> main"
  fi
  git merge --no-ff dev -m "$merge_msg"
  run_post_merge_hook
  push_branch "$remote" "main"
  git checkout dev

  echo ""
  ok "Branche dev mergee dans main et retour sur dev."
}

run_feature() {
  ensure_repo
  ensure_branch "dev"

  echo ""
  read -r -p "Nom de la feature : " feature_name
  if [ -z "$feature_name" ]; then
    error "Nom de feature vide. Annule."
    exit 1
  fi

  local branch="feature/$feature_name"
  if git show-ref --verify --quiet "refs/heads/$branch"; then
    error "La branche $branch existe deja."
    exit 1
  fi

  git checkout -b "$branch"
  echo ""
  ok "Branche $branch creee. Vous etes maintenant dessus."
}

run_feature_merge() {
  ensure_repo
  ensure_branch_pattern "feature/*"

  local feature_branch
  feature_branch="$(git branch --show-current)"

  # Commit modifications non commitees si present
  git add -A
  if ! git diff --cached --quiet; then
    warn "Modifications non commitees sur $feature_branch."
    prompt_version_update
    echo ""
    read -r -p "Message du commit: " msg
    if [ -z "$msg" ]; then
      error "Message vide, annule."
      exit 1
    fi
    git commit -m "$msg"
  fi

  echo ""
  info "Merge de $feature_branch vers dev..."
  git checkout dev

  local merge_msg="merge: $feature_branch -> dev"
  if ! git merge --no-ff "$feature_branch" -m "$merge_msg"; then
    error "Conflit de merge detecte. Resolvez les conflits manuellement puis commitez."
    error "Vous etes sur la branche dev. La feature n a pas ete supprimee."
    exit 1
  fi

  echo ""
  ok "Branche $feature_branch mergee dans dev."
}

# === Branch dev ===

run_branch_dev() {
  ensure_repo

  if ! git show-ref --verify --quiet "refs/heads/main"; then
    error "Branche main introuvable. Lancez d abord: make init"
    exit 1
  fi

  if git show-ref --verify --quiet "refs/heads/dev"; then
    info "La branche dev existe deja."
    git checkout dev
  else
    git branch dev
    git checkout dev
    ok "Branche dev creee."
  fi

  info "Synchronisation de dev avec main..."
  if ! git merge main -m "sync: main -> dev"; then
    error "Conflit de merge detecte. Resolvez les conflits manuellement."
    exit 1
  fi

  echo ""
  ok "Branche dev prete et alignee avec main."
}

# === Dispatch ===

case "$ACTION" in
  git)
    run_git
    ;;
  merge)
    run_merge
    ;;
  feature)
    run_feature
    ;;
  feature-merge)
    run_feature_merge
    ;;
  branch-dev)
    run_branch_dev
    ;;
  *)
    error "Usage: git.sh {git|merge|feature|feature-merge|branch-dev}"
    exit 2
    ;;
esac
