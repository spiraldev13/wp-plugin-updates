<?php
/**
 * Fallback générique — utilisé seulement quand aucun template plus
 * spécifique ne s'applique. Pour la page d'articles : `home.php`. Pour les
 * archives de catégorie : `category.php`. Pour les autres archives (tag,
 * auteur, date) qui ne sont pas exposées dans le menu : on retombe ici.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<section class="section">
    <div class="container">
        <?php evolutionr_breadcrumb(); ?>

        <header class="section-head">
            <div class="section-head-left">
                <h1 class="section-title"><?php echo esc_html(get_the_archive_title() ?: get_bloginfo('name')); ?></h1>
            </div>
        </header>

        <?php get_template_part('template-parts/blog/articles-grid'); ?>
    </div>
</section>

<?php get_footer(); ?>
