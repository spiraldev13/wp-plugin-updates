<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Ciblage à cases, logique OU implicite : le popup se charge dès qu'une
 * cible cochée correspond à la page courante. Aucune case = jamais chargé.
 */
final class Targeting
{
    /**
     * Vrai si au moins une cible est définie (indépendamment de la page
     * courante). Sert à l'état d'affichage calculé : « Aucune cible ».
     */
    public static function hasAnyTarget(array $targeting): bool
    {
        return !empty($targeting['whole_site'])
            || !empty($targeting['front_page'])
            || !empty($targeting['pages'])
            || !empty($targeting['posts'])
            || !empty($targeting['categories']);
    }

    /**
     * Résumé court et lisible du ciblage, pour la liste admin.
     */
    public static function summary(array $targeting): string
    {
        if (!empty($targeting['whole_site'])) {
            return __('Tout le site', 'popup-spiral');
        }

        $parts = [];

        if (!empty($targeting['front_page'])) {
            $parts[] = __('Accueil', 'popup-spiral');
        }

        foreach (['pages' => __('page', 'popup-spiral'), 'posts' => __('article', 'popup-spiral'), 'categories' => __('catégorie', 'popup-spiral')] as $key => $singular) {
            $count = !empty($targeting[$key]) ? count($targeting[$key]) : 0;

            if ($count > 0) {
                // Pluriel simple (les libellés français ci-dessus prennent un « s »).
                $parts[] = $count . ' ' . $singular . ($count > 1 ? 's' : '');
            }
        }

        return $parts !== [] ? implode(', ', $parts) : __('Aucune cible', 'popup-spiral');
    }

    public static function matches(array $targeting): bool
    {
        if (!empty($targeting['whole_site'])) {
            return true;
        }

        if (!empty($targeting['front_page']) && is_front_page()) {
            return true;
        }

        if (!empty($targeting['pages']) && is_page($targeting['pages'])) {
            return true;
        }

        if (!empty($targeting['posts']) && is_single($targeting['posts'])) {
            return true;
        }

        if (!empty($targeting['categories'])) {
            if (is_category($targeting['categories'])) {
                return true;
            }

            if (is_single() && has_category($targeting['categories'])) {
                return true;
            }
        }

        return false;
    }
}
