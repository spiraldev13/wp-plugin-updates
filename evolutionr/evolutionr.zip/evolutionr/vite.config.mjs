import { defineConfig } from 'vite'
import { resolve } from 'path'
import { existsSync } from 'fs'
import { viteStaticCopy } from 'vite-plugin-static-copy'
import { imagetools } from 'vite-imagetools'
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer'
import viteCompression from 'vite-plugin-compression'
import webfontDownload from 'vite-plugin-webfont-dl'
import ViteRestart from 'vite-plugin-restart'
import { visualizer } from 'rollup-plugin-visualizer'

/**
 * ════════════════════════════════════════════════════════════════════════════
 * 🔧 VARIABLES GLOBALES
 * ════════════════════════════════════════════════════════════════════════════
 */
const THEME_NAME = 'evolutionr'
const DEV_SERVER_PORT = parseInt(process.env.VITE_DEV_PORT ?? '5173', 10)

/**
 * 🔍 Détection automatique du chemin WordPress (classique vs Bedrock)
 */
function getWordPressThemePath() {
  const cwd = process.cwd()
  
  if (cwd.includes('/content/themes/') || cwd.includes('\\content\\themes\\')) {
    return `/content/themes/${THEME_NAME}/dist/`
  }
  
  if (cwd.includes('/app/themes/') || cwd.includes('\\app\\themes\\')) {
    return `/app/themes/${THEME_NAME}/dist/`
  }
  
  return `/wp-content/themes/${THEME_NAME}/dist/`
}

/**
 * 🔥 PLUGIN CUSTOM : Rechargement automatique des fichiers PHP
 */
const phpFullReload = {
  name: 'php-full-reload',
  handleHotUpdate(ctx) {
    if (ctx.file.endsWith('.php')) {
      ctx.server.ws.send({ type: 'full-reload', path: '*' })
      console.log('🔄 PHP modifié:', ctx.file.replace(process.cwd(), ''))
    }
  },
}

/**
 * 🚀 CONFIGURATION PRINCIPALE VITE
 */
export default defineConfig(({ command }) => {
  const isDev = command === 'serve'
  const themePath = getWordPressThemePath()
  
  if (!isDev) {
    console.log(`📦 Build path: ${themePath}`)
  }

  return {
    base: isDev ? '/' : themePath,

    build: {
      outDir: resolve(process.cwd(), 'dist'),
      emptyOutDir: true,
      manifest: true,
      minify: 'esbuild',
      sourcemap: false,

      rollupOptions: {
        input: {
          main: resolve(process.cwd(), 'app/main.js'),
          configurateur: resolve(process.cwd(), 'app/configurateur.js'),
        },

        output: {
          entryFileNames: 'js/[name].[hash].js',
          chunkFileNames: 'js/[name].[hash].js',
          assetFileNames: ({ name }) => {
            if (/\.(css)$/.test(name ?? '')) return 'css/[name].[hash][extname]'
            if (/\.(woff2?|ttf|otf|eot)$/.test(name ?? '')) return 'fonts/[name][extname]'
            if (/\.(png|jpg|jpeg|svg|gif|webp|avif)$/.test(name ?? '')) 
              return 'img/[name].[hash][extname]'
            return 'assets/[name].[hash][extname]'
          },
        },
      },
    },

    /**
     * 🌐 SERVEUR DE DÉVELOPPEMENT
     */
    server: {
      host: '0.0.0.0',
      port: DEV_SERVER_PORT,
      strictPort: true, // Échoue bruyamment si 5173 est déjà pris (évite les Vite zombies sur 5174/5175 non sondés par le PHP).
      cors: true,
      origin: `http://localhost:${DEV_SERVER_PORT}`,

      hmr: {
        protocol: 'ws',
        host: 'localhost',
        port: DEV_SERVER_PORT,
        overlay: true,
      },

      watch: {
        usePolling: true,
        interval: 300,
        ignored: ['**/node_modules/**', '**/dist/**'],
      },
    },

    resolve: {
      alias: {
        '@': resolve(process.cwd(), 'app'),
        '@styles': resolve(process.cwd(), 'app/stylesheets'),
        '@assets': resolve(process.cwd(), 'app/assets'),
        '@js': resolve(process.cwd(), 'app/js'),
      },
    },

    plugins: [
      phpFullReload,
      ViteRestart({
        restart: ['vite.config.mjs', 'postcss.config.js'],
      }),
      webfontDownload([
        'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap',
        'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap',
      ]),
      viteStaticCopy({
        targets: [
          {
            src: resolve(process.cwd(), 'app/assets/fonts/**/*'),
            dest: 'fonts',
          },
        ],
      }),
      imagetools({
        defaultDirectives: (url) => {
          return new URLSearchParams({
            format: 'webp',
            quality: '80',
          })
        },
      }),
      !isDev && ViteImageOptimizer({
        png: { quality: 80 },
        jpeg: { quality: 80 },
        jpg: { quality: 80 },
        webp: { quality: 80 },
        avif: { quality: 70 },
      }),
      !isDev && viteCompression({
        algorithm: 'gzip',
        ext: '.gz',
        threshold: 10240,
        deleteOriginFile: false,
      }),
      !isDev && viteCompression({
        algorithm: 'brotliCompress',
        ext: '.br',
        threshold: 10240,
        deleteOriginFile: false,
      }),
      !isDev && visualizer({
        open: false,
        filename: 'stats.html',
        gzipSize: true,
        brotliSize: true,
        template: 'treemap',
      }),
    ].filter(Boolean),

    css: {
      preprocessorOptions: {
        scss: {
          api: 'modern-compiler',
          silenceDeprecations: ['color-functions', 'import'],
          quietDeps: true,
        },
      },
    },

    optimizeDeps: {
      include: [],
    },
  }
})
