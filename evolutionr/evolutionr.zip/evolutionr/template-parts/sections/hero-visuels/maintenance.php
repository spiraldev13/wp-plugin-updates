<?php
/**
 * Motif hero « Maintenance & hébergement » — moniteur d'uptime.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Une rangée de barres de statut (vertes, quelques ambrées) façon statuspage +
 * un grand « 99.9% ». Le nombre de barres s'adapte par flex → responsive.
 */

if (!defined('ABSPATH')) {
    exit;
}

// 28 barres de disponibilité ; indices ci-dessous = incidents (ambre).
$bars     = 28;
$warnings = [9, 19];
?>
<div class="hvm">
    <div class="hvm-head">
        <span class="hvm-title">uptime · 90&nbsp;jours</span>
        <span class="hvm-ok">operational</span>
    </div>
    <div class="hvm-bars">
        <?php for ($i = 0; $i < $bars; $i++):
            $state = in_array($i, $warnings, true) ? ' is-warn' : '';
            ?>
            <span class="hvm-bar<?php echo $state; ?>" style="--i: <?php echo (int) $i; ?>;"></span>
        <?php endfor; ?>
    </div>
    <div class="hvm-stat">
        <span class="hvm-value">99.9<span class="hvm-pct">%</span></span>
        <span class="hvm-meta">disponibilité mesurée</span>
    </div>
</div>
