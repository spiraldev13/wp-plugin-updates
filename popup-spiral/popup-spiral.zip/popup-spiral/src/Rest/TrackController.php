<?php

namespace Spiral\Rest;

use Spiral\PostTypes;
use Spiral\Stats\Repository as Stats;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Comptage anonyme des vues et clics : totaux agrégés en meta,
 * aucune donnée personnelle transmise ni stockée.
 */
final class TrackController
{
    private const META_KEYS = [
        'open' => 'spiral_open_count',
        'click' => 'spiral_click_count',
    ];

    /** Fenêtre anti-rafale par client (secondes). */
    private const RATE_LIMIT_WINDOW = 10;

    public static function register(): void
    {
        add_action('rest_api_init', [self::class, 'registerRoutes']);
    }

    public static function registerRoutes(): void
    {
        register_rest_route('spiral/v1', '/track', [
            'methods' => 'POST',
            'callback' => [self::class, 'handle'],
            'permission_callback' => '__return_true',
            'args' => [
                'popup_id' => [
                    'required' => true,
                    'type' => 'integer',
                    'sanitize_callback' => 'absint',
                ],
                'event' => [
                    'required' => true,
                    'type' => 'string',
                    'enum' => ['open', 'click'],
                ],
            ],
        ]);
    }

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function handle(\WP_REST_Request $request): \WP_REST_Response
    {
        $popupId = (int) $request->get_param('popup_id');
        $event = (string) $request->get_param('event');

        $popup = get_post($popupId);

        if (!$popup instanceof \WP_Post
            || $popup->post_type !== PostTypes::POPUP
            || $popup->post_status !== 'publish'
        ) {
            return new \WP_REST_Response(['ok' => false], 404);
        }

        if (self::isRateLimited($popupId, $event)) {
            return new \WP_REST_Response(['ok' => false], 429);
        }

        // Total cumulé hérité (rétrocompat, colonnes de la liste) — incrément atomique.
        self::incrementMeta($popupId, self::META_KEYS[$event]);

        // Série journalière (panneau de statistiques) — upsert atomique.
        Stats::record($popupId, $event);

        return new \WP_REST_Response(['ok' => true], 200);
    }

    /**
     * Incrément atomique d'une meta compteur : `meta_value = meta_value + 1`
     * exécuté par la base (pas de lecture-puis-écriture applicative, donc pas
     * de course entre requêtes concurrentes).
     */
    private static function incrementMeta(int $popupId, string $metaKey): void
    {
        global $wpdb;

        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE $wpdb->postmeta SET meta_value = meta_value + 1
             WHERE post_id = %d AND meta_key = %s",
            $popupId,
            $metaKey
        ));

        if (!$updated) {
            // Première occurrence : créer la ligne (unique = pas de doublon en cas de course).
            add_post_meta($popupId, $metaKey, 1, true);
        }

        // Le cache d'objet garde l'ancienne valeur après un UPDATE SQL direct.
        wp_cache_delete($popupId, 'post_meta');
    }

    /**
     * Anti-rafale : un transient éphémère par empreinte hachée — l'adresse IP
     * n'est jamais stockée en clair, et l'empreinte disparaît en quelques secondes.
     */
    private static function isRateLimited(int $popupId, string $event): bool
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        $agent = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
        $key = 'spiral_rl_' . md5($ip . '|' . $agent . '|' . $popupId . '|' . $event);

        if (get_transient($key)) {
            return true;
        }

        set_transient($key, 1, self::RATE_LIMIT_WINDOW);

        return false;
    }
}
