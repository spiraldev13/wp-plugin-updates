/**
 * Popup Spiral — runtime front (vanilla, sans dépendance).
 *
 * Lit window.spiralPopups, gère les déclencheurs (délai, clic, exit-intent),
 * la fréquence par cookie fonctionnel et le comptage anonyme vues/clics.
 */
(function () {
    'use strict';

    var config = window.spiralPopups;

    if (!config || !Array.isArray(config.popups) || config.popups.length === 0) {
        return;
    }

    var openStack = [];
    var lastFocused = null;

    // Mode test : ?spiral-test dans l'URL ignore le cookie de fréquence,
    // pour vérifier un popup déjà fermé sans attendre l'expiration.
    var testMode = /[?&]spiral-test\b/.test(window.location.search);

    // Mode prévisualisation : page d'aperçu authentifiée (nonce + capacité).
    // Ouvre le popup immédiatement, sans cookie, sans comptage, sans respecter
    // les déclencheurs ni la planification — c'est un rendu pour l'admin.
    var previewMode = config.preview === true;

    function testLog(message) {
        if (testMode && window.console && window.console.info) {
            window.console.info('Popup Spiral [test] ' + message);
        }
    }

    /* ---------- Cookies (drapeau simple, aucune donnée personnelle) ---------- */

    function cookieName(id) {
        return 'spiral_popup_' + id;
    }

    function hasCookie(id) {
        return document.cookie.split('; ').indexOf(cookieName(id) + '=1') !== -1;
    }

    function setCookie(id, frequency) {
        // Mode test/aperçu : ne jamais toucher aux cookies du visiteur.
        // (Test : les visites normales suivantes doivent revoir le popup.)
        if (testMode || previewMode || frequency.mode === 'always') {
            return;
        }

        var cookie = cookieName(id) + '=1; path=/; SameSite=Lax';

        if (frequency.mode === 'forever') {
            cookie += '; max-age=' + 365 * 86400;
        } else if (frequency.mode === 'days') {
            cookie += '; max-age=' + Math.max(1, frequency.days) * 86400;
        }
        // mode "session" : pas de max-age, le cookie expire avec le navigateur.

        document.cookie = cookie;
    }

    /* ---------- Comptage anonyme ---------- */

    function track(id, event) {
        // Jamais de comptage en test ni en prévisualisation.
        if (testMode || previewMode || !config.restUrl || !navigator.sendBeacon) {
            return;
        }

        var data = new FormData();
        data.append('popup_id', id);
        data.append('event', event);
        navigator.sendBeacon(config.restUrl, data);
    }

    /* ---------- Ouverture / fermeture ---------- */

    function rootOf(popup) {
        return document.getElementById('spiral-popup-' + popup.id);
    }

    function withinSchedule(popup) {
        var now = Date.now();
        var schedule = popup.schedule || {};

        if (schedule.start && now < schedule.start) {
            return false;
        }

        if (schedule.end && now > schedule.end) {
            return false;
        }

        return true;
    }

    function canOpen(popup) {
        return withinSchedule(popup) && (testMode || !hasCookie(popup.id));
    }

    function open(popup, force) {
        var root = rootOf(popup);

        if (!root || !root.hasAttribute('hidden')) {
            return;
        }

        // En prévisualisation, on ouvre sans condition (rendu admin).
        if (!previewMode) {
            // Un clic explicite du visiteur passe outre le cookie de fréquence.
            if (!force && !canOpen(popup)) {
                testLog('popup ' + popup.id + ' bloqué : '
                    + (withinSchedule(popup) ? 'cookie de fréquence' : 'hors planification'));
                return;
            }

            if (force && !withinSchedule(popup)) {
                return;
            }
        }

        root.removeAttribute('hidden');

        // Reflow avant d'ajouter la classe, sinon la transition ne joue pas.
        void root.offsetWidth;
        root.classList.add('spiral-open');
        openStack.push(popup);

        lastFocused = document.activeElement;
        var closeButton = root.querySelector('.spiral-close');

        if (closeButton) {
            closeButton.focus();
        }

        track(popup.id, 'open');
    }

    function close(popup) {
        var root = rootOf(popup);

        if (!root || root.hasAttribute('hidden')) {
            return;
        }

        root.classList.remove('spiral-open');

        window.setTimeout(function () {
            root.setAttribute('hidden', '');
        }, 260);

        openStack = openStack.filter(function (item) {
            return item.id !== popup.id;
        });

        setCookie(popup.id, popup.frequency);

        if (lastFocused && typeof lastFocused.focus === 'function') {
            lastFocused.focus();
        }
    }

    /* ---------- Déclencheurs ---------- */

    function isValidSelector(selector) {
        if (!selector) {
            return false;
        }

        try {
            document.querySelector(selector);
            return true;
        } catch (error) {
            return false;
        }
    }

    function setupDelay(popup, delaySeconds) {
        window.setTimeout(function () {
            open(popup, false);
        }, Math.max(0, delaySeconds) * 1000);
    }

    function setupExitIntent(popup) {
        // Armement différé : le curseur qui entre dans la page par le haut
        // au chargement ne doit pas déclencher un faux départ.
        var armedAt = Date.now() + 1500;

        function onMouseOut(event) {
            // Seuil 10px : en sortie par le haut, les navigateurs rapportent
            // souvent un clientY de quelques px positifs (événements throttlés)
            // — le test strict `> 0` ne se déclenchait quasi jamais.
            if (event.relatedTarget || event.clientY > 10 || Date.now() < armedAt) {
                return;
            }

            document.removeEventListener('mouseout', onMouseOut);
            testLog('exit-intent déclenché (popup ' + popup.id + ')');
            open(popup, false);
        }

        document.addEventListener('mouseout', onMouseOut);
    }

    function clickMatches(popup, target) {
        var selectors = ['.spiral-' + popup.id, 'a[href$="#spiral-' + popup.id + '"]'];

        if (isValidSelector(popup.triggers.clickSelector)) {
            selectors.push(popup.triggers.clickSelector);
        }

        return target.closest(selectors.join(', '));
    }

    function setupTriggers(popup) {
        var triggers = popup.triggers;
        var finePointer = window.matchMedia('(pointer: fine)').matches;

        testLog('popup ' + popup.id + ' armé — délai : '
            + (triggers.delayEnabled ? triggers.delay + 's' : 'non')
            + ', clic : ' + (triggers.clickEnabled ? 'oui' : 'non')
            + ', exit-intent : '
            + (triggers.exitIntent ? (finePointer ? 'oui' : 'repli délai (tactile)') : 'non'));

        if (triggers.exitIntent && finePointer) {
            setupExitIntent(popup);
        }

        if (triggers.delayEnabled) {
            setupDelay(popup, triggers.delay);
        } else if (triggers.exitIntent && !finePointer) {
            // Exit-intent impossible au tactile : repli sur le délai.
            setupDelay(popup, triggers.delay);
        }
    }

    /* ---------- Écouteurs globaux ---------- */

    document.addEventListener('click', function (event) {
        var target = event.target;

        config.popups.forEach(function (popup) {
            if (popup.triggers.clickEnabled && clickMatches(popup, target)) {
                event.preventDefault();
                open(popup, true);
            }
        });

        // Fermeture : croix ou overlay.
        var closer = target.closest('[data-spiral-close]');

        if (closer) {
            var root = closer.closest('.spiral-root');

            if (root) {
                var id = parseInt(root.getAttribute('data-spiral-id'), 10);
                var popup = findPopup(id);

                if (popup) {
                    close(popup);
                }
            }
        }

        // Comptage des clics dans le contenu du popup ouvert.
        var link = target.closest('.spiral-content a, .spiral-content button, .spiral-content input[type="submit"]');

        if (link) {
            var contentRoot = link.closest('.spiral-root');

            if (contentRoot && !contentRoot.hasAttribute('hidden')) {
                track(parseInt(contentRoot.getAttribute('data-spiral-id'), 10), 'click');
            }
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && openStack.length > 0) {
            close(openStack[openStack.length - 1]);
        }
    });

    function findPopup(id) {
        for (var i = 0; i < config.popups.length; i++) {
            if (config.popups[i].id === id) {
                return config.popups[i];
            }
        }

        return null;
    }

    /* ---------- Initialisation ---------- */

    config.popups.forEach(function (popup) {
        // Prévisualisation : ouverture immédiate, aucun déclencheur à armer.
        if (previewMode) {
            open(popup, true);
            return;
        }

        // Un passage en mode test réarme le popup pour les visites normales.
        if (testMode) {
            document.cookie = cookieName(popup.id) + '=; max-age=0; path=/';
        }

        setupTriggers(popup);
    });
})();
