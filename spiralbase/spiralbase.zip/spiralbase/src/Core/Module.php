<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Contrat de tout module spiralbase — FIGÉ par la story 1.2 (séquencement
 * spine : les contrats du noyau se figent avant le premier module).
 *
 * Toute fonctionnalité du parent est un module enregistré au registre
 * (AD-1) ; un module ne dépend que du noyau, jamais d'un autre module
 * (AD-4).
 */
interface Module
{
    /** Identifiant unique du module (frontière WordPress : snake_case). */
    public function slug(): string;

    /** Démarre le module — appelé par le registre seul, et seulement si actif. */
    public function boot(): void;

    /**
     * Réglages par défaut du module. Forme : map sérialisable clé => valeur
     * (scalaires et tableaux imbriqués uniquement — destinée aux options
     * WordPress).
     *
     * Le noyau ne les consomme PAS : la story 3.9 a tranché de ne pas livrer
     * le volet « réglages par défaut » d'AD-14 (voir `deferred-work.md`), et
     * chaque module reste seul juge de son propre repli. Le contrat est
     * conservé — il est figé depuis la 1.2 et 25 modules l'implémentent —
     * mais il ne promet plus une consommation qui n'a pas eu lieu.
     *
     * @return array<string, scalar|array|null>
     */
    public function defaultSettings(): array;

    /**
     * Noms des options que le module déclare (AD-11 : données déclarées,
     * jamais sauvages). Toutes préfixées `spiralbase_`.
     *
     * @return list<string>
     */
    public function options(): array;

    /** Interrupteur par défaut, tant qu'aucun humain ni seed n'a tranché. */
    public function enabledByDefault(): bool;

    /**
     * Sonde de cession (règle d'or, AD-3) — DÉCLARÉE dès maintenant pour que
     * le contrat ne casse pas ses implémenteurs ; le noyau ne l'évalue qu'à
     * partir de la story 1.3. `null` = ce module ne cède jamais.
     *
     * Signature du callable, figée avec le contrat :
     * `callable(): bool|string` — `false` ou `''` = le module garde la main ;
     * une chaîne non vide = le module cède, la chaîne est la raison
     * exposée au tableau de bord (ex. « OpenGraph réellement émis par
     * Rank Math »).
     *
     * Contrainte de timing (assumée) : la sonde est évaluée au boot du
     * noyau, à `after_setup_theme` — elle s'appuie sur des faits déjà
     * établis chez le tiers (options, constantes, classes), jamais sur des
     * hooks que le tiers enregistre plus tard (`init`, `wp_head`…).
     *
     * @return null|callable():(bool|string)
     */
    public function cessionProbe(): ?callable;
}
