<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Attributs du conteneur d'un bloc dynamique — juge unique du parent
 * (remonté dans le noyau en revue 3.5).
 *
 * Fait LU dans le cœur : `get_block_wrapper_attributes()` déréférence sans
 * garde le bloc en cours de rendu (`class-wp-block-supports.php:97-99`,
 * `self::$block_to_render['blockName']`). Appelé hors de `WP_Block::render()`
 * — ce que fait une extension qui invoque un `render_callback` directement,
 * ou un outil d'aperçu — il émet un `PHP Warning` que le filet `Throwable`
 * des rendus ne peut PAS rattraper, et qui s'imprime dans la page sous
 * `WP_DEBUG_DISPLAY`.
 *
 * La garde était écrite en story 3.2, mais dans la classe mère du seul bloc
 * menu : les quatre autres blocs métier appelaient le cœur à nu. Un défaut
 * déjà payé une fois ne doit pas se rejouer bloc par bloc — d'où ce juge
 * unique, sur le modèle de `PlagesOuverture` (3.1) et `TexteRiche` (3.2).
 *
 * Hors rendu, on se replie sur la classe seule : le bloc perd sa classe
 * générée `wp-block-*` et ses supports (couleur, espacement), il ne casse
 * rien.
 */
final class EnveloppeBloc
{
    /** @param array<string, string> $extra attributs propres au bloc (`data-*`…), conservés dans les deux chemins */
    public static function attributs(string $classes, array $extra = []): string
    {
        $horsRendu = !class_exists('WP_Block_Supports')
            || !isset(\WP_Block_Supports::$block_to_render['blockName']);

        if (!$horsRendu) {
            return get_block_wrapper_attributes(array_merge($extra, ['class' => $classes]));
        }

        /* Le repli perd les supports du cœur, jamais les attributs que le
           bloc porte lui-même : les `data-*` des horaires transportent la
           donnée que le script de vue consomme. */
        $rendu = 'class="' . esc_attr($classes) . '"';

        foreach ($extra as $nom => $valeur) {
            $rendu .= ' ' . $nom . '="' . esc_attr($valeur) . '"';
        }

        return $rendu;
    }
}
