<?php

declare(strict_types=1);

namespace SpiralBase\Modules\SchemaMetier;

use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\PlagesOuverture;
use SpiralBase\Core\Module;

/**
 * JSON-LD schema.org du métier (LocalBusiness et sous-types), émis sur la
 * page d'accueil depuis les données métier du noyau (CAP-15, story 2.3).
 *
 * Ce module ne cède JAMAIS (AC 2, AD-2) : Rank Math ne connaît pas les
 * données métier du thème — aucun tiers ne fournit ce JSON-LD à sa place.
 */
final class SchemaMetierModule implements Module
{
    /**
     * Table type d'activité → @type schema.org — inconnu = LocalBusiness.
     * Les clés DOIVENT couvrir `DonneesMetier::TYPES_ACTIVITE` (vocabulaire
     * fermé du juge — cohérence testée).
     */
    public const TYPES = [
        'restaurant' => 'Restaurant',
        'commerce'   => 'Store',
        'sante'      => 'MedicalBusiness',
        'artisan'    => 'HomeAndConstructionBusiness',
    ];

    private bool $emis = false;

    public function __construct(private readonly DonneesMetier $donnees)
    {
    }

    public function slug(): string
    {
        return 'schema_metier';
    }

    public function boot(): void
    {
        add_action('wp_head', [$this, 'emettre'], 5);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        /* Les données vivent dans l'option canonique du noyau (réservée) —
           le module n'en revendique aucune (AD-11). */
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        /* AC 2 : ne cède jamais — voir docblock de classe. */
        return null;
    }

    public function emettre(): void
    {
        /* Idempotence : wp_head peut être rejoué (constructeurs, previews) —
           jamais deux nœuds LocalBusiness concurrents. */
        if ($this->emis) {
            return;
        }

        try {
            $json = $this->jsonLd();
        } catch (\Throwable $e) {
            /* Des métadonnées ne fatalisent JAMAIS la page (précédent 2.1). */
            $this->signaler('émission abandonnée — ' . $e->getMessage());

            return;
        }

        if ($json !== null) {
            $this->emis = true;
            printf('<script type="application/ld+json">%s</script>' . "\n", $json);
        }
    }

    /**
     * JSON-LD prêt à émettre — null si hors page d'accueil, sans données,
     * sans nom, ou si l'encodage échoue (signalé). Aucune propriété vide.
     *
     * Public pour l'émission et les tests UNIQUEMENT — pas un service (AD-4).
     */
    public function jsonLd(): ?string
    {
        if (!is_front_page()) {
            return null;
        }

        $donnees = $this->donnees->get();

        if ($donnees === null) {
            return null;
        }

        $nom = is_string($donnees['nom'] ?? null) ? trim($donnees['nom']) : '';

        if ($nom === '') {
            return null;
        }

        $type    = self::TYPES[$donnees['type_activite'] ?? ''] ?? 'LocalBusiness';
        $adresse = $this->adresse($donnees['adresse'] ?? null);
        $url     = home_url('/');

        if ($adresse === []) {
            /* Sans adresse, Google refuse le résultat enrichi LocalBusiness :
               le nœud part quand même (inoffensif) mais l'opérateur doit
               pouvoir le savoir (Site Health, tableau de bord 6.x). */
            $this->signaler('adresse absente — JSON-LD émis mais inéligible aux résultats enrichis locaux', 'spiralbase_schema_metier_sans_adresse');
        }

        $schema = array_filter([
            '@context'     => 'https://schema.org',
            '@type'        => $type,
            'name'         => $nom,
            /* Jamais d'URL relative dans un schema (home mal provisionnée). */
            'url'          => preg_match('#^https?://#i', $url) === 1 ? $url : '',
            'telephone'    => is_string($donnees['telephone'] ?? null) ? trim($donnees['telephone']) : '',
            'address'      => $adresse,
            /* Filtré par le JUGE UNIQUE du noyau, le même que le bloc
               horaires (AD-2). Sans lui, les deux publiaient des horaires
               CONTRADICTOIRES : le visiteur lisait deux lignes, Google en
               recevait quatre — dont deux que le bloc jugeait illisibles
               (revue 3.1, AC 2 réfutée au front). */
            'openingHours' => is_array($donnees['horaires'] ?? null)
                ? array_values(array_filter(
                    $donnees['horaires'],
                    static fn ($h): bool => is_string($h) && PlagesOuverture::analyserEntree($h) !== null
                ))
                : [],
        ], static fn (mixed $valeur): bool => $valeur !== '' && $valeur !== []);

        /*
         * Contexte <script> : JSON_HEX_TAG/HEX_AMP neutralisent tout
         * `</script>` littéral d'une donnée (XSS stocké attrapé en revue) —
         * JAMAIS JSON_UNESCAPED_SLASHES ici : la leçon « échappement au
         * point de sortie » se décline PAR CONTEXTE, elle ne se copie pas.
         */
        $json = wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);

        if (!is_string($json)) {
            /* Défensif : le vrai wp_json_encode sanitise l'UTF-8 et ne rend
               quasiment jamais false — mais son contrat l'autorise. */
            $this->signaler('encodage JSON-LD impossible — rien d\'émis');

            return null;
        }

        return $json;
    }

    /** Convention NFR13 (Walker) : hook TOUJOURS, error_log sous WP_DEBUG. */
    private function signaler(string $message, string $hook = 'spiralbase_schema_metier_echec'): void
    {
        do_action($hook, $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] schema_metier : ' . $message . '.');
        }
    }

    /** @return array<string, string> PostalAddress, ou [] si inutilisable */
    private function adresse(mixed $adresse): array
    {
        if (!is_array($adresse)) {
            return [];
        }

        $postale = array_filter([
            'streetAddress'   => is_string($adresse['rue'] ?? null) ? trim($adresse['rue']) : '',
            'postalCode'      => is_string($adresse['code_postal'] ?? null) ? trim($adresse['code_postal']) : '',
            'addressLocality' => is_string($adresse['ville'] ?? null) ? trim($adresse['ville']) : '',
        ], static fn (string $v): bool => $v !== '');

        return $postale === [] ? [] : ['@type' => 'PostalAddress'] + $postale;
    }
}
