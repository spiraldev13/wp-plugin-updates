/**
 * Bloc spiralbase/formulaire-contact — JS éditeur écrit à la main, SANS build
 * (AD-12).
 *
 * `save()` rend `null` : le formulaire est entièrement rendu par le serveur,
 * qui seul peut poser un nonce et un jeton signés — deux valeurs qui ne
 * doivent JAMAIS être figées dans le contenu enregistré.
 *
 * L'éditeur n'affiche pas le formulaire réel : le montrer donnerait envie de
 * cliquer dessus, et un aperçu interactif dans l'éditeur n'enverrait rien.
 */
( function ( blocks, element, blockEditor, components, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    blocks.registerBlockType( 'spiralbase/formulaire-contact', {
        edit: function () {
            return e(
                'div',
                blockEditor.useBlockProps( { className: 'spiralbase-formulaire-edition' } ),
                e(
                    components.Placeholder,
                    {
                        icon: 'email',
                        label: __( 'Formulaire de contact', 'spiralbase' ),
                    },
                    __(
                        'Nom, e-mail et message. Les messages reçus s’ajoutent au menu « Messages reçus » et partent aussi par e-mail.',
                        'spiralbase'
                    )
                )
            );
        },
        save: function () {
            return null;
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n
);
