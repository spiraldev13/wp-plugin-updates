<?php
/**
 * Page d'articles — `/blog/` (page définie en Réglages → Lecture).
 *
 * Header éditorial constant + barre de pills hybride (filtre par catégorie)
 * + grille d'articles + pagination native. Délègue tout le rendu de la grille
 * au partial `template-parts/blog/articles-grid.php` qui est partagé avec
 * `category.php` — un seul rendu pour deux contextes (D3 du change
 * `add-navigation-and-blog`).
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<section class="section">
    <div class="container">
        <?php evolutionr_breadcrumb(); ?>

        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php esc_html_e('Journal & conseils', 'evolutionr'); ?></span>
                </div>
                <h1 class="section-title"><?php esc_html_e('Conseils web, SEO et maintenance', 'evolutionr'); ?></h1>
            </div>
            <p class="section-lede"><?php esc_html_e('Articles, conseils et retours d\'expérience sur la création de sites, le référencement naturel et la maintenance web.', 'evolutionr'); ?></p>
        </header>

        <?php get_template_part('template-parts/blog/pills-filters'); ?>

        <?php get_template_part('template-parts/blog/articles-grid'); ?>
    </div>
</section>

<?php get_footer(); ?>
