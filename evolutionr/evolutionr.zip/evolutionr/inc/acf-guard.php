<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Détecte la présence d'ACF (Pro, free ou Secure Custom Fields).
 *
 * ACF est une dépendance externe du thème (voir CLAUDE.md). Si elle est
 * absente, on se contente d'afficher une notice admin — on NE déclare PAS
 * de stubs pour `get_field` & co. Raison : déclarer un stub `get_field()`
 * empêche l'activation ultérieure d'ACF (fatal « Cannot redeclare »).
 */
function evolutionr_acf_is_active(): bool
{
    return class_exists('ACF') || function_exists('acf_add_options_page');
}

if (!evolutionr_acf_is_active()) {
    add_action('admin_notices', function () {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        $message = sprintf(
            /* translators: %s : nom du thème */
            esc_html__('Le thème %s nécessite Advanced Custom Fields (ACF Pro ou Secure Custom Fields) pour fonctionner. Active le plugin pour que les contenus dynamiques s\'affichent.', 'evolutionr'),
            '<strong>Evolution\'R</strong>'
        );

        printf('<div class="notice notice-error"><p>%s</p></div>', wp_kses_post($message));
    });
}
