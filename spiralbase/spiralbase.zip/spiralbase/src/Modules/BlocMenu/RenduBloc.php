<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;

/**
 * Socle des trois rendus de la carte : la garantie fail-safe, écrite une fois.
 *
 * Un bloc placé dans une page ne doit JAMAIS pouvoir écrouler cette page.
 * Le chemin de rendu traverse du code tiers en production —
 * `get_block_wrapper_attributes()` exécute les callbacks des supports de bloc,
 * y compris ceux enregistrés par des extensions (`class-wp-block-supports.php`
 * :176, `apply_block_supports()`) — et un `Throwable` y remonterait jusqu'au
 * template. Le contrat est donc : toute panne rend une chaîne vide et se
 * signale (NFR13), le reste de la carte continue de s'afficher.
 */
abstract class RenduBloc
{
    private const HOOK_ECHEC = 'spiralbase_bloc_menu_echec';

    /**
     * Signature imposée par le cœur : `call_user_func($render_callback,
     * $attributes, $block_content, $this)` (`class-wp-block.php:596`).
     *
     * @param array<string, mixed> $attributs
     * @param string               $contenu   HTML DÉJÀ RENDU des blocs enfants
     * @param mixed                $bloc      `WP_Block` en production, rien de garanti
     */
    final public function rendre(array $attributs, string $contenu = '', mixed $bloc = null): string
    {
        try {
            return $this->composer($attributs, $contenu, $bloc);
        } catch (\Throwable $e) {
            Signal::emettre(
                self::HOOK_ECHEC,
                sprintf('%s : rendu interrompu (%s)', $this->nomDuBloc(), $e->getMessage()),
                'bloc menu'
            );

            return '';
        }
    }

    abstract protected function nomDuBloc(): string;

    /**
     * @param array<string, mixed> $attributs
     */
    abstract protected function composer(array $attributs, string $contenu, mixed $bloc): string;

    /**
     * Attributs du conteneur, y compris hors d'un rendu de bloc.
     *
     * La garde vit désormais dans le noyau (`Core\EnveloppeBloc`, revue 3.5) :
     * elle était écrite ici depuis la 3.2, mais les quatre autres blocs
     * métier appelaient le cœur à nu et émettaient le Warning.
     */
    final protected function conteneur(string $classes): string
    {
        return EnveloppeBloc::attributs($classes);
    }
}
