<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Juge UNIQUE du texte saisi dans un champ `RichText` de l'éditeur, pour tous
 * les blocs métier du parent (story 3.2, réutilisable par l'Epic 3 entier).
 *
 * Pourquoi dans le noyau et pas dans chaque module : deux blocs qui filtrent
 * différemment le même genre de contenu finissent par publier deux vérités —
 * l'un laisse passer ce que l'autre refuse (leçon 3.1, `Core\PlagesOuverture`).
 *
 * Pourquoi une liste blanche PROPRE plutôt que `wp_kses_post` : le contexte
 * « post » du cœur autorise `<a>`, `<img>`, `<table>`, `<h1>`… (`kses.php`,
 * `$allowedposttags`). Un nom de plat, un prix ou un titre de section n'ont
 * besoin que d'emphase : tout le reste, dans un champ de cette taille, est du
 * markup collé par mégarde ou de l'injection. La liste ci-dessous n'autorise
 * AUCUN attribut — donc ni `style`, ni `on*`, ni `href`.
 *
 * Ce que fait le cœur avec cette liste, et sur quoi le rendu s'appuie :
 *  - `kses.php:1396-1398` — élément hors liste : la balise disparaît, le
 *    texte qu'elle entoure reste. L'opérateur qui colle du HTML depuis un
 *    traitement de texte ne perd donc jamais son plat, seulement sa mise en
 *    forme exotique ;
 *  - `kses.php:1401-1403` — une balise fermante autorisée ressort sans
 *    attribut ;
 *  - `kses.php:1437` (`wp_kses_attr`) — un élément autorisé perd tout
 *    attribut non déclaré.
 */
final class TexteRiche
{
    /**
     * Emphase et exposants — ce que produisent les formats natifs de
     * `RichText` que le parent laisse actifs. Aucun attribut n'est déclaré.
     *
     * @var array<string, array<string, mixed>>
     */
    private const AUTORISE = [
        'strong' => [],
        'em'     => [],
        'b'      => [],
        'i'      => [],
        's'      => [],
        'sub'    => [],
        'sup'    => [],
        'br'     => [],
    ];

    /**
     * Filtre une valeur d'attribut de bloc destinée à sortir en HTML.
     *
     * Une valeur non textuelle rend une chaîne vide : le cœur refuse déjà
     * un attribut dont le type contredit le schéma du `block.json`
     * (`class-wp-block-type.php:517-520` — la valeur invalide est retirée,
     * puis remplacée par le défaut). Convertir ici serait plus permissif que
     * la porte qui persiste la donnée, et ferait apparaître au rendu ce que
     * l'éditeur n'a jamais accepté.
     */
    /**
     * Balises que le rendu laisse passer — le contrat que la barre d'outils
     * de l'éditeur doit refléter (un test relie les deux listes : promettre
     * un format que la publication retire est une trahison silencieuse).
     *
     * @return list<string>
     */
    public static function balisesAutorisees(): array
    {
        return array_keys(self::AUTORISE);
    }

    public static function filtrer(mixed $valeur): string
    {
        if (!is_string($valeur)) {
            return '';
        }

        /* Les commentaires HTML sortent AVANT la liste blanche : `wp_kses`
           les conserve (`kses.php:1363-1379`), et ils traversent donc jusqu'à
           la page. Un champ de carte n'a aucune raison d'en porter — ce qu'on
           y trouve vient d'un collage bureautique (`<!--[if gte mso 9]>`) ou
           d'un copier-coller de contenu, délimiteurs de bloc compris. Or le
           walker du parent traite les commentaires comme des frontières de
           texte (stories 2.6-2.8, deux défauts CRITIQUES à leur actif) : en
           laisser filtrer dans du contenu rendu serait lui tendre un piège.
           Un commentaire NON fermé n'est pas touché ici — `wp_kses`
           l'échappe en `&lt;!--`, ce qui est le bon traitement. */
        $sansCommentaire = preg_replace('/<!--.*?-->/s', '', $valeur) ?? $valeur;

        /* `wp_kses` filtre, il ne rééquilibre pas : « Bœuf <em>bourguignon »
           ressortait avec son `<em>` ouvert, et l'algorithme d'adoption du
           navigateur le refermait après TOUTE la carte — plats, prix et
           section suivante basculaient en italique, et l'alignement des prix
           s'effondrait (un `<span>` cessait d'être enfant direct du flex).
           `force_balance_tags` est la réponse du cœur au même problème sur
           les extraits (`formatting.php:2591`). */
        return trim(force_balance_tags(wp_kses($sansCommentaire, self::AUTORISE)));
    }

    /** Vrai si, une fois le balisage retiré, il ne reste rien à afficher. */
    public static function estVide(string $html): bool
    {
        /* Un blanc insécable s'écrit de trois façons — `&nbsp;`, `&#160;`,
           `&#xA0;` — et `wp_kses_normalize_entities` conserve les formes
           numériques. Les décoder d'abord, sinon deux écritures du MÊME
           caractère recevaient deux verdicts opposés et un prix « &#160; »
           ouvrait un conteneur vide. */
        $texte = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return trim(str_replace("\u{00A0}", ' ', $texte)) === '';
    }
}
