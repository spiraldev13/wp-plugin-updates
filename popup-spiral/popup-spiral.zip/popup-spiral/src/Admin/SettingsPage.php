<?php

namespace Spiral\Admin;

use Spiral\AutoExpire;
use Spiral\PostTypes;
use Spiral\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Page « Réglages » : tailles réutilisables, option de désinstallation
 * et informations RGPD.
 */
final class SettingsPage
{
    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addMenu']);
        add_action('admin_init', [self::class, 'registerSettings']);
    }

    public static function addMenu(): void
    {
        add_submenu_page(
            'edit.php?post_type=' . PostTypes::POPUP,
            __('Réglages de Popup Spiral', 'popup-spiral'),
            __('Réglages', 'popup-spiral'),
            'manage_options',
            'spiral-settings',
            [self::class, 'render']
        );
    }

    public static function registerSettings(): void
    {
        register_setting('spiral_settings', 'spiral_delete_on_uninstall', [
            'type' => 'boolean',
            'default' => false,
            'sanitize_callback' => 'rest_sanitize_boolean',
        ]);

        register_setting('spiral_settings', Settings::SIZE_PRESETS_OPTION, [
            'type' => 'array',
            'default' => [],
            'sanitize_callback' => [Settings::class, 'sanitizeSizePresets'],
        ]);

        register_setting('spiral_settings', AutoExpire::OPTION, [
            'type' => 'boolean',
            'default' => false,
            'sanitize_callback' => 'rest_sanitize_boolean',
        ]);
    }

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap spiral-admin">
            <h1><?php esc_html_e('Réglages de Popup Spiral', 'popup-spiral'); ?></h1>

            <form method="post" action="options.php">
                <?php settings_fields('spiral_settings'); ?>

                <?php self::renderSizesCard(); ?>
                <?php self::renderImageWidthsCard(); ?>

                <div class="spiral-card">
                    <h2><?php esc_html_e('Planification', 'popup-spiral'); ?></h2>
                    <label>
                        <input type="checkbox" name="<?php echo esc_attr(AutoExpire::OPTION); ?>" value="1" <?php checked(get_option(AutoExpire::OPTION)); ?> />
                        <?php esc_html_e('Désactiver automatiquement l\'interrupteur « Actif » d\'un popup une fois sa date de fin passée', 'popup-spiral'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Confort visuel uniquement : un popup expiré ne s\'affiche déjà jamais (la planification prime, que la tâche planifiée de WordPress soit passée ou non). Cette option bascule simplement l\'interrupteur sur OFF pour clarifier la liste. Désactivée par défaut ; vous pourrez toujours réactiver un popup manuellement pour le réutiliser.', 'popup-spiral'); ?>
                    </p>
                </div>

                <div class="spiral-card">
                    <h2><?php esc_html_e('Données', 'popup-spiral'); ?></h2>
                    <label>
                        <input type="checkbox" name="spiral_delete_on_uninstall" value="1" <?php checked(get_option('spiral_delete_on_uninstall')); ?> />
                        <?php esc_html_e('Supprimer tous les popups et designs à la désinstallation du plugin', 'popup-spiral'); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e('Décoché (par défaut), vos popups sont conservés en base si vous désinstallez le plugin.', 'popup-spiral'); ?>
                    </p>
                </div>

                <?php submit_button(__('Enregistrer', 'popup-spiral')); ?>
            </form>

            <div class="spiral-card">
                <h2><?php esc_html_e('RGPD : cookie de fréquence', 'popup-spiral'); ?></h2>
                <p>
                    <?php esc_html_e('Quand un visiteur ferme un popup, un cookie fonctionnel « spiral_popup_{id} » est posé pour ne pas le lui remontrer. Il ne contient aucun identifiant personnel (un simple drapeau), n\'est transmis à aucun tiers et expire au plus tard après 13 mois : il est exempté de consentement (cookie de préférence). Les compteurs de vues et de clics sont des totaux anonymes, sans suivi individuel.', 'popup-spiral'); ?>
                </p>
                <p><strong><?php esc_html_e('Phrase type pour votre politique de confidentialité :', 'popup-spiral'); ?></strong></p>
                <blockquote class="spiral-quote">
                    <?php esc_html_e('« Ce site utilise un cookie fonctionnel (spiral_popup_*) qui mémorise la fermeture des fenêtres d\'information afin de ne pas vous les réafficher. Il ne contient aucune donnée personnelle et expire automatiquement. »', 'popup-spiral'); ?>
                </blockquote>
            </div>

            <div class="spiral-card">
                <h2><?php esc_html_e('Ouvrir un popup depuis un bouton (Divi, Elementor…)', 'popup-spiral'); ?></h2>
                <p>
                    <?php esc_html_e('Ajoutez la classe CSS « spiral-{ID} » à n\'importe quel bouton ou module, ou faites pointer un lien vers « #spiral-{ID} ». L\'ID de chaque popup est visible dans l\'onglet Déclencheurs de son éditeur.', 'popup-spiral'); ?>
                </p>
            </div>
        </div>
        <?php
    }

    /* ---------- Tailles réutilisables ---------- */

    private static function renderSizesCard(): void
    {
        $presets = Settings::sizePresets();
        $usage = self::presetUsage();
        $opt = Settings::SIZE_PRESETS_OPTION;
        ?>
        <div class="spiral-card">
            <h2><?php esc_html_e('Tailles de popup réutilisables', 'popup-spiral'); ?></h2>
            <p class="description">
                <?php esc_html_e('Créez vos propres tailles nommées : elles apparaissent dans « Quelle taille ? » de chaque popup. Un popup dont la taille est supprimée reprend la taille par défaut.', 'popup-spiral'); ?>
            </p>

            <div id="spiral-size-presets">
                <?php foreach ($presets['sizes'] as $i => $size) : ?>
                    <p class="spiral-preset-row">
                        <input type="hidden" name="<?php echo esc_attr($opt); ?>[sizes][<?php echo (int) $i; ?>][key]" value="<?php echo esc_attr($size['key']); ?>" />
                        <input type="text" name="<?php echo esc_attr($opt); ?>[sizes][<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr($size['label']); ?>" placeholder="<?php esc_attr_e('Nom (ex. Bandeau promo)', 'popup-spiral'); ?>" />
                        <input type="number" name="<?php echo esc_attr($opt); ?>[sizes][<?php echo (int) $i; ?>][width]" value="<?php echo (int) $size['width']; ?>" min="200" max="2000" step="10" class="spiral-input-small" />
                        <?php esc_html_e('pixels', 'popup-spiral'); ?>
                        <button type="button" class="button-link button-link-delete spiral-preset-remove" data-usage="<?php echo (int) ($usage[$size['key']] ?? 0); ?>"><?php esc_html_e('Supprimer', 'popup-spiral'); ?></button>
                        <?php if (!empty($usage[$size['key']])) : ?>
                            <span class="description">
                                <?php
                                /* translators: %d : nombre de popups utilisant cette taille */
                                echo esc_html(sprintf(_n('utilisée par %d popup', 'utilisée par %d popups', $usage[$size['key']], 'popup-spiral'), $usage[$size['key']]));
                                ?>
                            </span>
                        <?php endif; ?>
                    </p>
                <?php endforeach; ?>
            </div>

            <template id="spiral-size-template">
                <p class="spiral-preset-row">
                    <input type="hidden" name="<?php echo esc_attr($opt); ?>[sizes][__i__][key]" value="" />
                    <input type="text" name="<?php echo esc_attr($opt); ?>[sizes][__i__][label]" value="" placeholder="<?php esc_attr_e('Nom (ex. Bandeau promo)', 'popup-spiral'); ?>" />
                    <input type="number" name="<?php echo esc_attr($opt); ?>[sizes][__i__][width]" value="560" min="200" max="2000" step="10" class="spiral-input-small" />
                    <?php esc_html_e('pixels', 'popup-spiral'); ?>
                    <button type="button" class="button-link button-link-delete spiral-preset-remove" data-usage="0"><?php esc_html_e('Supprimer', 'popup-spiral'); ?></button>
                </p>
            </template>

            <p>
                <button type="button" class="button spiral-preset-add" data-template="spiral-size-template" data-target="spiral-size-presets"><?php esc_html_e('Ajouter une taille', 'popup-spiral'); ?></button>
            </p>

            <label>
                <strong><?php esc_html_e('Taille par défaut des nouveaux popups :', 'popup-spiral'); ?></strong>
                <select name="<?php echo esc_attr($opt); ?>[default_size]">
                    <?php foreach (Settings::sizeChoices() as $value => $label) : ?>
                        <?php if ($value === 'custom') { continue; } ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($presets['default_size'], $value); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <p class="description"><?php esc_html_e('Une taille tout juste ajoutée doit être enregistrée avant de pouvoir devenir la taille par défaut.', 'popup-spiral'); ?></p>
        </div>
        <?php
    }

    private static function renderImageWidthsCard(): void
    {
        $presets = Settings::sizePresets();
        $opt = Settings::SIZE_PRESETS_OPTION;
        ?>
        <div class="spiral-card">
            <h2><?php esc_html_e('Largeurs d\'image personnalisées', 'popup-spiral'); ?></h2>
            <p class="description">
                <?php esc_html_e('En plus de 25 / 50 / 75 / 100 %, ajoutez vos propres largeurs d\'image (en % du popup) — elles apparaissent dans « Largeur de l\'image » de chaque popup.', 'popup-spiral'); ?>
            </p>

            <div id="spiral-imgw-presets">
                <?php foreach ($presets['image_widths'] as $width) : ?>
                    <p class="spiral-preset-row">
                        <input type="number" name="<?php echo esc_attr($opt); ?>[image_widths][]" value="<?php echo (int) $width; ?>" min="5" max="100" class="spiral-input-small" />
                        <?php esc_html_e('% du popup', 'popup-spiral'); ?>
                        <button type="button" class="button-link button-link-delete spiral-preset-remove" data-usage="0"><?php esc_html_e('Supprimer', 'popup-spiral'); ?></button>
                    </p>
                <?php endforeach; ?>
            </div>

            <template id="spiral-imgw-template">
                <p class="spiral-preset-row">
                    <input type="number" name="<?php echo esc_attr($opt); ?>[image_widths][]" value="60" min="5" max="100" class="spiral-input-small" />
                    <?php esc_html_e('% du popup', 'popup-spiral'); ?>
                    <button type="button" class="button-link button-link-delete spiral-preset-remove" data-usage="0"><?php esc_html_e('Supprimer', 'popup-spiral'); ?></button>
                </p>
            </template>

            <p>
                <button type="button" class="button spiral-preset-add" data-template="spiral-imgw-template" data-target="spiral-imgw-presets"><?php esc_html_e('Ajouter une largeur', 'popup-spiral'); ?></button>
            </p>

            <label>
                <strong><?php esc_html_e('Largeur d\'image par défaut :', 'popup-spiral'); ?></strong>
                <select name="<?php echo esc_attr($opt); ?>[default_image_width]">
                    <?php foreach (Settings::allowedImageWidths() as $width) : ?>
                        <option value="<?php echo (int) $width; ?>" <?php selected($presets['default_image_width'], $width); ?>><?php echo esc_html($width . ' %'); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <?php
    }

    /**
     * Nombre de popups par taille réutilisable (clé c-* => total).
     */
    private static function presetUsage(): array
    {
        $usage = [];
        $popups = get_posts([
            'post_type' => PostTypes::POPUP,
            'post_status' => 'any',
            'numberposts' => -1,
            'fields' => 'ids',
        ]);

        foreach ($popups as $popupId) {
            $size = (string) Settings::get((int) $popupId)['display']['size'];

            if (strpos($size, 'c-') === 0) {
                $usage[$size] = ($usage[$size] ?? 0) + 1;
            }
        }

        return $usage;
    }
}
