<?php

namespace Spiral\Admin;

use Spiral\Presets\Repository;
use Spiral\PostTypes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Page d'administration des presets de configuration.
 *
 * Créer un preset depuis un popup, le renommer, le dupliquer, le supprimer.
 * L'application d'un preset à un popup se fait depuis l'onglet Affichage de
 * l'éditeur (handler `spiral_apply_preset`).
 */
final class PresetsPage
{
    public const CAPABILITY = 'edit_posts';

    public const PAGE = 'spiral-presets';

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addPage']);
        add_action('admin_post_spiral_create_preset', [self::class, 'handleCreate']);
        add_action('admin_post_spiral_rename_preset', [self::class, 'handleRename']);
        add_action('admin_post_spiral_duplicate_preset', [self::class, 'handleDuplicate']);
        add_action('admin_post_spiral_delete_preset', [self::class, 'handleDelete']);
        add_action('admin_post_spiral_apply_preset', [self::class, 'handleApply']);
    }

    private static function capability(): string
    {
        return (string) apply_filters('spiral_presets_capability', self::CAPABILITY);
    }

    public static function addPage(): void
    {
        add_submenu_page(
            'edit.php?post_type=' . PostTypes::POPUP,
            __('Presets de configuration', 'popup-spiral'),
            __('Presets', 'popup-spiral'),
            self::capability(),
            self::PAGE,
            [self::class, 'render']
        );
    }

    public static function pageUrl(): string
    {
        return add_query_arg(
            ['post_type' => PostTypes::POPUP, 'page' => self::PAGE],
            admin_url('edit.php')
        );
    }

    /* ---------------------------------------------------------------- Rendu */

    public static function render(): void
    {
        if (!current_user_can(self::capability())) {
            wp_die(esc_html__('Accès refusé.', 'popup-spiral'));
        }

        $presets = Repository::all();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Presets de configuration', 'popup-spiral') . '</h1>';
        echo '<p class="description">' . esc_html__('Un preset mémorise l\'affichage, le bouton, les déclencheurs et la fréquence d\'un popup (et, en option, son ciblage) pour les réappliquer en un clic. À ne pas confondre avec un design, qui ne concerne que l\'apparence visuelle.', 'popup-spiral') . '</p>';

        self::renderCreateForm();
        self::renderList($presets);

        echo '</div>';
    }

    private static function renderCreateForm(): void
    {
        $popups = get_posts([
            'post_type' => PostTypes::POPUP,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        echo '<h2>' . esc_html__('Créer un preset depuis un popup', 'popup-spiral') . '</h2>';

        if ($popups === []) {
            echo '<p>' . esc_html__('Créez d\'abord un popup pour en enregistrer les réglages en preset.', 'popup-spiral') . '</p>';
            return;
        }
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="spiral-preset-create">
            <input type="hidden" name="action" value="spiral_create_preset">
            <?php wp_nonce_field('spiral_preset_create'); ?>
            <p>
                <label><?php esc_html_e('Popup source', 'popup-spiral'); ?>
                    <select name="popup_id" required>
                        <?php foreach ($popups as $popup) : ?>
                            <option value="<?php echo (int) $popup->ID; ?>"><?php echo esc_html($popup->post_title !== '' ? $popup->post_title : __('(sans titre)', 'popup-spiral')); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </p>
            <p>
                <label><?php esc_html_e('Nom du preset', 'popup-spiral'); ?>
                    <input type="text" name="name" required placeholder="<?php esc_attr_e('Ex. Promo agressive', 'popup-spiral'); ?>">
                </label>
            </p>
            <p>
                <label>
                    <input type="checkbox" name="includes_targeting" value="1">
                    <?php esc_html_e('Inclure aussi le ciblage (les pages/articles visés)', 'popup-spiral'); ?>
                </label>
            </p>
            <p><button type="submit" class="button button-primary"><?php esc_html_e('Créer le preset', 'popup-spiral'); ?></button></p>
        </form>
        <?php
    }

    /**
     * @param array<string, array{name: string, includes_targeting: bool, settings: array}> $presets
     */
    private static function renderList(array $presets): void
    {
        echo '<h2>' . esc_html__('Mes presets', 'popup-spiral') . '</h2>';

        if ($presets === []) {
            echo '<p>' . esc_html__('Aucun preset pour l\'instant.', 'popup-spiral') . '</p>';
            return;
        }

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Nom', 'popup-spiral') . '</th>';
        echo '<th>' . esc_html__('Contenu', 'popup-spiral') . '</th>';
        echo '<th>' . esc_html__('Actions', 'popup-spiral') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($presets as $slug => $preset) {
            self::renderRow($slug, $preset);
        }

        echo '</tbody></table>';
    }

    private static function renderRow(string $slug, array $preset): void
    {
        $sections = [
            __('Affichage', 'popup-spiral'),
            __('Bouton', 'popup-spiral'),
            __('Déclencheurs', 'popup-spiral'),
            __('Fréquence', 'popup-spiral'),
        ];

        if (!empty($preset['includes_targeting'])) {
            $sections[] = __('Ciblage', 'popup-spiral');
        }

        $actionUrl = esc_url(admin_url('admin-post.php'));

        echo '<tr>';

        // Renommage inline.
        echo '<td><form method="post" action="' . $actionUrl . '" class="spiral-preset-rename">';
        echo '<input type="hidden" name="action" value="spiral_rename_preset">';
        echo '<input type="hidden" name="slug" value="' . esc_attr($slug) . '">';
        wp_nonce_field('spiral_preset_rename_' . $slug);
        echo '<input type="text" name="name" value="' . esc_attr($preset['name']) . '">';
        echo ' <button type="submit" class="button button-small">' . esc_html__('Renommer', 'popup-spiral') . '</button>';
        echo '</form></td>';

        echo '<td>' . esc_html(implode(' · ', $sections)) . '</td>';

        // Dupliquer + supprimer.
        echo '<td>';
        echo '<form method="post" action="' . $actionUrl . '" style="display:inline">';
        echo '<input type="hidden" name="action" value="spiral_duplicate_preset">';
        echo '<input type="hidden" name="slug" value="' . esc_attr($slug) . '">';
        wp_nonce_field('spiral_preset_duplicate_' . $slug);
        echo '<button type="submit" class="button button-small">' . esc_html__('Dupliquer', 'popup-spiral') . '</button>';
        echo '</form> ';
        echo '<form method="post" action="' . $actionUrl . '" style="display:inline" onsubmit="return confirm(' . esc_attr(wp_json_encode(__('Supprimer ce preset ?', 'popup-spiral'))) . ');">';
        echo '<input type="hidden" name="action" value="spiral_delete_preset">';
        echo '<input type="hidden" name="slug" value="' . esc_attr($slug) . '">';
        wp_nonce_field('spiral_preset_delete_' . $slug);
        echo '<button type="submit" class="button button-small button-link-delete">' . esc_html__('Supprimer', 'popup-spiral') . '</button>';
        echo '</form>';
        echo '</td>';

        echo '</tr>';
    }

    /* ------------------------------------------------------------- Handlers */

    public static function handleCreate(): void
    {
        self::guard('spiral_preset_create');

        $popupId = isset($_POST['popup_id']) ? absint($_POST['popup_id']) : 0;
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $includesTargeting = !empty($_POST['includes_targeting']);

        if ($popupId > 0 && current_user_can('edit_post', $popupId)) {
            Repository::createFromPopup($popupId, $name, $includesTargeting);
        }

        // Depuis l'éditeur : revenir à l'éditeur ; sinon la liste des presets.
        $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : '';
        self::redirect($redirect !== '' ? $redirect : self::pageUrl());
    }

    public static function handleRename(): void
    {
        $slug = isset($_POST['slug']) ? sanitize_key((string) $_POST['slug']) : '';
        self::guard('spiral_preset_rename_' . $slug);

        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        Repository::rename($slug, $name);

        self::redirect(self::pageUrl());
    }

    public static function handleDuplicate(): void
    {
        $slug = isset($_POST['slug']) ? sanitize_key((string) $_POST['slug']) : '';
        self::guard('spiral_preset_duplicate_' . $slug);

        Repository::duplicate($slug);

        self::redirect(self::pageUrl());
    }

    public static function handleDelete(): void
    {
        $slug = isset($_POST['slug']) ? sanitize_key((string) $_POST['slug']) : '';
        self::guard('spiral_preset_delete_' . $slug);

        Repository::delete($slug);

        self::redirect(self::pageUrl());
    }

    /**
     * Applique un preset à un popup (depuis l'éditeur), puis retourne à l'éditeur.
     */
    public static function handleApply(): void
    {
        $popupId = isset($_POST['popup_id']) ? absint($_POST['popup_id']) : 0;

        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'spiral_preset_apply_' . $popupId)
            || !current_user_can('edit_post', $popupId)
        ) {
            wp_die(esc_html__('Action non autorisée.', 'popup-spiral'));
        }

        $slug = isset($_POST['preset']) ? sanitize_key((string) $_POST['preset']) : '';
        $sections = isset($_POST['sections']) && is_array($_POST['sections'])
            ? array_map('sanitize_key', wp_unslash($_POST['sections']))
            : [];

        if ($slug !== '' && $sections !== []) {
            Repository::applyToPopup($popupId, $slug, $sections);
        }

        self::redirect(add_query_arg(['spiral_preset_applied' => 1], get_edit_post_link($popupId, 'url')));
    }

    /**
     * Vérifie capacité + nonce d'une action de gestion de presets.
     */
    private static function guard(string $nonceAction): void
    {
        if (!current_user_can(self::capability())
            || !wp_verify_nonce($_POST['_wpnonce'] ?? '', $nonceAction)
        ) {
            wp_die(esc_html__('Action non autorisée.', 'popup-spiral'));
        }
    }

    private static function redirect(string $url): void
    {
        wp_safe_redirect($url);
        exit;
    }
}
