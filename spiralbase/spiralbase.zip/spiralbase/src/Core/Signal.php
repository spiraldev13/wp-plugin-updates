<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Émission bornée des signaux NFR13 — un seul référentiel pour tout le parent.
 *
 * Contrat NFR13 : `do_action` TOUJOURS (un site de la flotte peut brancher sa
 * supervision dessus), `error_log` seulement sous `WP_DEBUG`. Le bornage par
 * requête est ce qui rend la règle tenable : une carte de 40 plats, une page
 * de 30 blocs ou une boucle de 200 articles ne doivent pas remplir le journal
 * avec le même message répété.
 *
 * Mutualisé en story 3.2 : les rendus de blocs 3.1 dupliquaient déjà ce
 * mécanisme à l'identique, et l'Epic 3 ajoute un module de blocs par story —
 * un référentiel dupliqué finit toujours par diverger (leçon rétro Epic 1).
 * Les émetteurs du noyau aux politiques différentes (Walker, Updater,
 * RecipeStore, DonneesMetier) restent en l'état : leur bornage n'est pas le
 * même, les aligner sortirait du périmètre d'une story de bloc.
 */
final class Signal
{
    /**
     * Plafond d'émissions par hook et par requête.
     *
     * La déduplication par message ne suffit PAS : dès que le message porte
     * une donnée d'opérateur (« entrée d'horaire ignorée : … », « mise en
     * forme « … » inconnue »), chaque valeur distincte est un message
     * distinct — 40 entrées fautives donnaient 40 journaux, à rebours de ce
     * que ce fichier promettait. Au-delà du plafond, le hook se tait pour le
     * reste de la requête : les premiers cas suffisent au diagnostic.
     */
    private const PLAFOND_PAR_HOOK = 5;

    /** @var array<string, true> couples hook+message déjà émis cette requête */
    private static array $emis = [];

    /** @var array<string, int> nombre d'émissions par hook cette requête */
    private static array $compte = [];

    /**
     * Émet un signal NFR13, au plus une fois par message et
     * self::PLAFOND_PAR_HOOK fois par hook et par requête.
     *
     * Portée du signal : QUALITATIF, jamais quantitatif. Il dit « ce défaut
     * s'est produit », pas « il s'est produit N fois » — une supervision
     * branchée dessus ne distingue pas un plat perdu d'une carte entière
     * perdue. Compter demanderait un tampon vidé en fin de requête, hors de
     * proportion avec ce que le contrat NFR13 demande.
     *
     * @param string $contexte préfixe humain du journal (ex. « bloc menu »)
     */
    public static function emettre(string $hook, string $message, string $contexte = ''): void
    {
        /* Le séparateur NUL empêche la collision entre deux couples dont la
           concaténation coïncide — un même message ne masque pas un autre
           hook (défaut du mécanisme dupliqué en 3.1). */
        $cle = $hook . "\0" . $message;

        if (isset(self::$emis[$cle]) || (self::$compte[$hook] ?? 0) >= self::PLAFOND_PAR_HOOK) {
            return;
        }

        self::$emis[$cle]  = true;
        self::$compte[$hook] = (self::$compte[$hook] ?? 0) + 1;
        do_action($hook, $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] ' . ($contexte === '' ? '' : $contexte . ' : ') . $message);
        }
    }

    /**
     * Réarme le bornage entre deux requêtes simulées.
     *
     * @internal Réservé au harnais de test. Le motif est déjà toléré sur
     *           `DonneesMetier` ; il reste borné à une remise à zéro d'état
     *           statique, sans effet observable en production.
     */
    public static function reinitialiser(): void
    {
        self::$emis   = [];
        self::$compte = [];
    }
}
