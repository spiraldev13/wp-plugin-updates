<?php
/**
 * Template — Page « Création de site web » (slug `creation-site-internet`).
 *
 * Tous les contenus sont controlables depuis le metabox ACF
 * `group_evor_page_creation` (inc/acf-fields.php). Hardcodes interdits.
 *
 * Sections : hero (avec mini-stats) / formules / mid-cta / inclus-exclus /
 * faq / cta final. Chaque section peut etre desactivee via un toggle ACF
 * ou auto-cachee si son repeater est vide.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal" id="content">

    <?php /* ─── Hero ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-hero', null, [
        'visual_label' => 'creation.layout',
        'visual_type'  => 'creation',
    ]); ?>

    <?php /* ─── Bénéfices (partial factorisé, partagé avec SEO & Maintenance) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-benefices'); ?>

    <?php /* ─── Formules ─── */ ?>
    <?php if (have_rows('types') && evolutionr_category_has_offers('creation')):
        $typesEyebrow = (string) get_field('types_eyebrow');
        $typesTitle   = (string) get_field('types_title');
        $typesLede    = (string) get_field('types_lede');
        ?>
        <section class="section section--prestation" id="formules" aria-labelledby="formules-title">
            <div class="container">

                <?php if ($typesEyebrow || $typesTitle || $typesLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($typesEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($typesEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($typesTitle): ?>
                                <h2 class="section-title" id="formules-title"><?php echo esc_html($typesTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($typesLede): ?>
                            <p class="section-lede"><?php echo esc_html($typesLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="formules-grid">
                    <?php $i = 0; while (have_rows('types')): the_row();
                        $tNum      = (string) get_sub_field('num');
                        $tLabel    = (string) get_sub_field('label');
                        // Lien au modèle central : on extrait le nom de l'offre de la réf
                        // « creation|nom|mode » et on résout les DEUX modes par ce nom
                        // (le double prix « unique ou abonnement » est conservé).
                        [, $tOfferName] = array_pad(explode('|', (string) get_sub_field('offre_ref'), 3), 3, '');
                        $tUnique = ($tOfferName !== '' && function_exists('evolutionr_pricing_find_offer')) ? evolutionr_pricing_find_offer('creation', $tOfferName, 'paiement_unique') : null;
                        $tAbo    = ($tOfferName !== '' && function_exists('evolutionr_pricing_find_offer')) ? evolutionr_pricing_find_offer('creation', $tOfferName, 'abonnement') : null;
                        // Visibilité héritée du modèle : aucune offre active liée → type masqué.
                        if (!$tUnique && !$tAbo) {
                            continue;
                        }
                        $tDesc     = (string) get_sub_field('desc');
                        $tFeatured = (bool) get_sub_field('featured');
                        $tFeaturedLbl = (string) get_sub_field('featured_label') ?: __('Le plus demandé', 'evolutionr');
                        $tCtaLbl   = (string) get_sub_field('cta_label') ?: __('Voir le tarif détaillé', 'evolutionr');
                        // URL réglable par formule (sous-champ ACF `cta_url`) ; à défaut, le
                        // configurateur de tarifs (catégorie creation). Aligné sur les autres
                        // pages prestation (SEO, Maintenance, Identité) qui lisent déjà `cta_url`.
                        $tCtaUrl   = (string) get_sub_field('cta_url') ?: '/tarifs/?service=creation';
                        $displayNum = $tNum ?: sprintf('%02d', $i + 1);
                        ?>
                        <div class="formule-card-wrap<?php echo $tFeatured ? ' featured' : ''; ?>">
                            <?php if ($tFeatured): ?>
                                <div class="formule-badge"><?php echo esc_html($tFeaturedLbl); ?></div>
                            <?php endif; ?>
                            <article class="formule-card<?php echo $tFeatured ? ' featured' : ''; ?>">

                            <?php if ($displayNum): ?>
                                <div class="formule-num">— <?php echo esc_html($displayNum); ?></div>
                            <?php endif; ?>

                            <?php if ($tLabel): ?>
                                <h3 class="formule-name"><?php echo esc_html($tLabel); ?></h3>
                            <?php endif; ?>

                            <?php if ($tUnique || $tAbo): ?>
                                <div class="formule-price">
                                    <?php if ($tUnique): ?>
                                        <span class="amount"><?php echo esc_html($tUnique['price_label']); ?></span>
                                    <?php endif; ?>
                                    <?php if ($tAbo): ?>
                                        <span class="formule-price-abo">
                                            <span class="formule-price-or"><?php esc_html_e('ou', 'evolutionr'); ?></span>
                                            <?php echo esc_html($tAbo['price_label']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($tDesc): ?>
                                <p class="formule-desc"><?php echo esc_html($tDesc); ?></p>
                            <?php endif; ?>

                            <?php if (have_rows('included')): ?>
                                <ul class="formule-features">
                                    <?php while (have_rows('included')): the_row();
                                        $iText = (string) get_sub_field('text');
                                        if (!$iText) continue;
                                        ?>
                                        <li>
                                            <?php evolutionr_icon('check', 14); ?>
                                            <span><?php echo esc_html($iText); ?></span>
                                        </li>
                                    <?php endwhile; ?>
                                </ul>
                            <?php endif; ?>

                            <?php if ($tCtaLbl): ?>
                                <a class="formule-cta" href="<?php echo esc_url($tCtaUrl); ?>">
                                    <span class="btn-inner">
                                        <?php echo esc_html($tCtaLbl); ?>
                                        <?php evolutionr_icon('arrow-right', 14); ?>
                                    </span>
                                </a>
                            <?php endif; ?>
                            </article>
                        </div>
                        <?php $i++;
                    endwhile; ?>
                </div>

                <?php evolutionr_render_mid_cta(); ?>

            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── Paiement unique ou abonnement ─── */ ?>
    <?php if (get_field('pay_enabled') && (get_field('pay_title') || get_field('pay_uniq_text') || get_field('pay_abo_text'))):
        $payEyebrow   = (string) get_field('pay_eyebrow');
        $payTitle     = (string) get_field('pay_title');
        $payLede      = (string) get_field('pay_lede');
        $payUniqTitle = (string) get_field('pay_uniq_title') ?: __('Payer en une fois', 'evolutionr');
        $payUniqText  = (string) get_field('pay_uniq_text');
        $payAboTitle  = (string) get_field('pay_abo_title') ?: __('Démarrer en abonnement', 'evolutionr');
        $payAboText   = (string) get_field('pay_abo_text');
        $payCtaLabel  = (string) get_field('pay_cta_label');
        $payCtaUrl    = (string) get_field('pay_cta_url') ?: '/tarifs/?service=creation';
        ?>
        <section class="section section--prestation section--no-pad-top" id="paiement" aria-labelledby="paiement-title">
            <div class="container">
                <?php if ($payEyebrow || $payTitle || $payLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($payEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($payEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($payTitle): ?>
                                <h2 class="section-title" id="paiement-title"><?php echo esc_html($payTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($payLede): ?>
                            <p class="section-lede"><?php echo esc_html($payLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="paiement-grid">
                    <article class="paiement-col">
                        <h3 class="paiement-col-title"><?php echo esc_html($payUniqTitle); ?></h3>
                        <?php if ($payUniqText): ?><p><?php echo esc_html($payUniqText); ?></p><?php endif; ?>
                    </article>
                    <article class="paiement-col paiement-col--abo">
                        <h3 class="paiement-col-title"><?php echo esc_html($payAboTitle); ?></h3>
                        <?php if ($payAboText): ?><p><?php echo esc_html($payAboText); ?></p><?php endif; ?>
                    </article>
                </div>

                <?php if ($payCtaLabel): ?>
                    <div class="paiement-cta">
                        <a class="btn btn-primary" href="<?php echo esc_url($payCtaUrl); ?>">
                            <?php echo esc_html($payCtaLabel); ?>
                            <?php evolutionr_icon('arrow-right', 16); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── Méthode (partial factorisé, partagé avec SEO & Maintenance) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-methode'); ?>

    <?php /* ─── Périmètre (Inclus / Non inclus) ─── */ ?>
    <?php
    $hasIncluded = have_rows('creation_included');
    $hasExcluded = have_rows('creation_excluded');
    $inexEyebrow = (string) get_field('inex_eyebrow');
    $inexTitle   = (string) get_field('inex_title');
    $inexLede    = (string) get_field('inex_lede');
    if ($hasIncluded || $hasExcluded): ?>
        <section class="section section--prestation section--no-pad-top" aria-labelledby="inex-title">
            <div class="container">

                <?php if ($inexEyebrow || $inexTitle || $inexLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($inexEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($inexEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($inexTitle): ?>
                                <h2 class="section-title" id="inex-title"><?php echo esc_html($inexTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($inexLede): ?>
                            <p class="section-lede"><?php echo esc_html($inexLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="included-grid">
                    <?php if ($hasIncluded):
                        $incTitle = (string) get_field('included_title') ?: __('Ce qui est inclus', 'evolutionr');
                        $incSub   = (string) get_field('included_sub');
                        ?>
                        <div class="included-col">
                            <h3>
                                <span class="head-badge ok"><?php evolutionr_icon('check', 16); ?></span>
                                <?php echo esc_html($incTitle); ?>
                            </h3>
                            <?php if ($incSub): ?><p class="sub"><?php echo esc_html($incSub); ?></p><?php endif; ?>
                            <ul>
                                <?php while (have_rows('creation_included')): the_row();
                                    $text = (string) get_sub_field('text');
                                    if (!$text) continue;
                                    ?>
                                    <li>
                                        <?php evolutionr_icon('check', 16); ?>
                                        <span><?php echo esc_html($text); ?></span>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if ($hasExcluded):
                        $excTitle = (string) get_field('excluded_title') ?: __('Non inclus par défaut', 'evolutionr');
                        $excSub   = (string) get_field('excluded_sub');
                        ?>
                        <div class="included-col excluded">
                            <h3>
                                <span class="head-badge no"><?php evolutionr_icon('x', 14); ?></span>
                                <?php echo esc_html($excTitle); ?>
                            </h3>
                            <?php if ($excSub): ?><p class="sub"><?php echo esc_html($excSub); ?></p><?php endif; ?>
                            <ul>
                                <?php while (have_rows('creation_excluded')): the_row();
                                    $text = (string) get_sub_field('text');
                                    if (!$text) continue;
                                    ?>
                                    <li>
                                        <?php evolutionr_icon('x', 16); ?>
                                        <span><?php echo esc_html($text); ?></span>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── FAQ ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-faq'); ?>

    <?php /* ─── CTA final ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-cta-final'); ?>

</main>

<?php get_footer(); ?>
