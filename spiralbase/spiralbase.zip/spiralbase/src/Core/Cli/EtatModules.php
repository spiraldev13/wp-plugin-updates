<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\Registry;

/**
 * Rendu du tableau « état des modules », partagé par `wp spiralbase module
 * lister` et par la confirmation d'application d'un profil.
 *
 * Un référentiel unique : les deux commandes montrent le même état, décrit
 * avec les mêmes mots. Deux rendus recopiés finissent toujours par diverger
 * (leçon rétro Epic 1) — et ici la divergence porterait sur ce que
 * l'opérateur croit avoir configuré.
 *
 * Le tableau distingue ce qui vaut MAINTENANT de ce qui ne vaudra qu'à la
 * requête suivante. `bootActive()` tourne sur `after_setup_theme`, donc AVANT
 * toute commande : un module que la commande vient d'allumer n'a pas démarré
 * et sa sonde de cession n'a jamais été évaluée. L'annoncer « actif » sans
 * réserve, c'est ce que faisait la première version — et l'opérateur livrait
 * un site en croyant son bloc de rendez-vous en place alors qu'un plugin
 * tiers le faisait céder (revue 3.9).
 */
final class EtatModules
{
    private const MARQUE_DIFFERE = '*';

    /** @return list<string> */
    public static function lignes(Registry $registre): array
    {
        $lignes  = [];
        $differe = false;

        try {
            $etats = $registre->states();
        } catch (\Throwable $e) {
            /* Les cessions ne sont connues qu'après le boot du registre. Sans
               elles, on montre l'interrupteur plutôt que rien — en le disant. */
            $etats    = null;
            $lignes[] = 'État de cession indisponible (registre non démarré) : seuls les interrupteurs sont montrés.';
        }

        foreach ($registre->slugs() as $slug) {
            $actif = $registre->isActive($slug);
            $etat  = $etats[$slug] ?? ($actif ? Registry::ETAT_ACTIF : Registry::ETAT_DESACTIVE);

            /* L'interrupteur a bougé depuis le boot : la cession affichée (ou
               son absence) ne dit rien de ce qui se passera vraiment. */
            if ($registre->actifAuBoot($slug) !== null && $registre->actifAuBoot($slug) !== $actif) {
                $etat .= self::MARQUE_DIFFERE;
                $differe = true;
            }

            $ligne = sprintf('%-28s %-11s %s', $slug, $etat, self::origine($registre, $slug));

            if ($etats !== null && $etat === Registry::ETAT_CEDE) {
                $ligne .= ' — ' . (string) $registre->cessionReason($slug);
            }

            $lignes[] = $ligne;
        }

        if ($differe) {
            $lignes[] = '';
            $lignes[] = self::MARQUE_DIFFERE . ' prendra effet au prochain chargement : la sonde de cession (AD-3) n\'a pas encore été évaluée pour ce module. Relancer « wp spiralbase module lister » pour l\'état réel.';
        }

        return $lignes;
    }

    private static function origine(Registry $registre, string $slug): string
    {
        return match ($registre->origine($slug)) {
            Registry::ORIGINE_HUMAIN => 'choix manuel',
            Registry::ORIGINE_PROFIL => 'profil',
            default                  => 'défaut du module',
        };
    }
}
