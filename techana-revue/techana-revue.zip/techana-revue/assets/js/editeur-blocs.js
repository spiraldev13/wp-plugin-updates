/**
 * Stub éditeur des blocs dynamiques TechAna : ils sont rendus côté serveur,
 * l'éditeur n'a besoin que d'un aperçu nominal et d'une carte d'identité.
 */
( function ( blocks, element ) {
    'use strict';

    var el = element.createElement;

    var BLOCS = [
        [ 'techana/rubriques', 'TechAna — liste de rubriques' ],
        [ 'techana/ticker', 'TechAna — fil à la une' ],
        [ 'techana/plus-lus', 'TechAna — articles populaires' ],
        [ 'techana/dernieres-maj', 'TechAna — dernières mises à jour' ],
        [ 'techana/menu-mobile', 'TechAna — menu mobile' ],
        [ 'techana/haut-page', 'TechAna — retour en haut de page' ],
        [ 'techana/pave-rubrique', 'TechAna — pavé de rubrique (accueil)' ],
        [ 'techana/hub-facts', 'TechAna — faits de la rubrique' ],
        [ 'techana/fil-ariane', 'TechAna — fil d’Ariane' ],
        [ 'techana/auteur-tete', 'TechAna — en-tête auteur' ],
        [ 'techana/recherche-entete', 'TechAna — en-tête de recherche' ],
        [ 'techana/tampon-page', 'TechAna — tampon de version' ],
        [ 'techana/pages-liees', 'TechAna — pages liées' ],
        [ 'techana/en-bref', 'TechAna — en bref' ],
        [ 'techana/faq', 'TechAna — FAQ' ],
        [ 'techana/sommaire', 'TechAna — sommaire' ],
        [ 'techana/sponsor-bar', 'TechAna — bandeau sponsorisé' ],
        [ 'techana/annonceur', 'TechAna — encart annonceur' ],
        [ 'techana/byline', 'TechAna — signature d’article' ],
        [ 'techana/figure-article', 'TechAna — figure de tête' ],
        [ 'techana/auteur-boite', 'TechAna — boîte auteur' ],
        [ 'techana/prevnext', 'TechAna — précédent / suivant' ],
        [ 'techana/meme-rubrique', 'TechAna — même rubrique' ],
        [ 'techana/formulaire-contact', 'TechAna — formulaire de contact' ]
    ];

    BLOCS.forEach( function ( bloc ) {
        blocks.registerBlockType( bloc[ 0 ], {
            title: bloc[ 1 ],
            icon: 'layout',
            category: 'theme',
            attributes: {
                format: { type: 'string', default: '' },
                nombre: { type: 'number', default: 0 },
                position: { type: 'string', default: '' },
                ref: { type: 'number', default: 0 }
            },
            edit: function () {
                return el(
                    'div',
                    { style: {
                        padding: '12px',
                        border: '1px dashed #94a3b8',
                        fontFamily: 'monospace',
                        fontSize: '12px'
                    } },
                    bloc[ 1 ] + ' (rendu sur le site)'
                );
            },
            save: function () {
                return null;
            }
        } );
    } );
}( window.wp.blocks, window.wp.element ) );
