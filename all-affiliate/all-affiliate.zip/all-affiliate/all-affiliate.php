<?php
/**
 * Plugin Name: All Affiliate
 * Description: Plugin WordPress
 * Version: 1.0.1
 * Author: spiraldev13
 */

if (!defined('ABSPATH')) {
	exit;
}
