<?php

/**
 * AI Images - Déclencheurs admin de la génération d'images par IA
 *
 * Metabox dans l'éditeur (articles et pages), bouton « Générer par IA » dans
 * la colonne « Image à la une », action groupée sur les listes, et handler
 * AJAX commun. La génération elle-même est déléguée à Generator.
 *
 * Assets associés :
 * - JS : /assets/js/ai-images.js (metabox + bouton colonne)
 *
 * Fichiers liés :
 * - src/ai-images/generator.php
 * - src/features/featured-images.php (hook de colonne)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class AiImages
{
	const OPTION_NAME = 'ultimate_shanks_ai_images_enabled';

	const POST_TYPES = ['post', 'page'];

	/**
	 * Nombre maximum de contenus traités par action groupée : la génération
	 * est synchrone (~60 s max par image), au-delà on risque le timeout PHP
	 */
	const BULK_LIMIT = 3;

	public static function init()
	{
		if (!self::is_enabled()) {
			return;
		}

		add_action('add_meta_boxes', [self::class, 'register_metabox']);
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
		add_action('enqueue_block_editor_assets', [self::class, 'enqueue_block_editor_assets']);
		add_action('wp_ajax_ultimate_shanks_ai_generate_image', [self::class, 'ajax_generate_image']);

		// Bouton dans la colonne « Image à la une » (module Featured Images)
		add_action('ultimate_shanks_featured_image_column_actions', [self::class, 'render_column_button']);

		// Actions groupées sur les listes d'articles et de pages
		foreach (self::POST_TYPES as $post_type) {
			add_filter('bulk_actions-edit-' . $post_type, [self::class, 'register_bulk_action']);
			add_filter('handle_bulk_actions-edit-' . $post_type, [self::class, 'handle_bulk_action'], 10, 3);
		}
		add_action('admin_notices', [self::class, 'bulk_notices']);
	}

	/**
	 * Vérifie si le module est activé (désactivé par défaut : requiert une clé API)
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		return get_option(self::OPTION_NAME, '0') === '1';
	}

	/**
	 * Limite d'articles traités par lot, filtrable
	 *
	 * @return int
	 */
	public static function bulk_limit()
	{
		return max(1, (int) apply_filters('ultimate_shanks_ai_images_bulk_limit', self::BULK_LIMIT));
	}

	/**
	 * Enregistre la metabox dans l'éditeur des articles et pages
	 */
	public static function register_metabox()
	{
		add_meta_box(
			'ultimate_shanks_ai_images',
			'Image par IA',
			[self::class, 'render_metabox'],
			self::POST_TYPES,
			'side',
			'default'
		);
	}

	/**
	 * Affiche la metabox : prompt, ratio, cible, bouton de génération.
	 * Aucune donnée n'est sauvegardée au save du post — tout passe par AJAX.
	 */
	public static function render_metabox($post)
	{
		$default_ratio = Generator::validate_ratio('');
		$default_target = Generator::validate_target('');
		$provider = Providers::get_active();
		$models = $provider->get_models();
		$default_model = self::default_model($provider);
		?>
		<p>
			<label for="us_ai_prompt"><strong>Prompt</strong></label>
			<textarea id="us_ai_prompt" rows="4" style="width:100%;"
				placeholder="Description de l'image à générer (vide = titre du contenu)"></textarea>
		</p>
		<p>
			<button type="button" class="button button-small" id="us_ai_use_title">Utiliser le titre</button>
		</p>
		<p>
			<label for="us_ai_ratio"><strong>Format</strong></label>
			<select id="us_ai_ratio" style="width:100%;">
				<?php foreach (Generator::VALID_RATIOS as $ratio) : ?>
					<option value="<?php echo esc_attr($ratio); ?>" <?php selected($ratio, $default_ratio); ?>>
						<?php echo esc_html($ratio); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<label for="us_ai_model"><strong>Modèle</strong></label>
			<select id="us_ai_model" style="width:100%;">
				<?php foreach ($models as $endpoint => $model) : ?>
					<option value="<?php echo esc_attr($endpoint); ?>" <?php selected($endpoint, $default_model); ?>>
						<?php echo esc_html($model['label']); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<label for="us_ai_target"><strong>Destination</strong></label>
			<select id="us_ai_target" style="width:100%;">
				<option value="featured" <?php selected('featured', $default_target); ?>>Image à la une</option>
				<option value="content" <?php selected('content', $default_target); ?>>Début du contenu</option>
			</select>
		</p>
		<p>
			<button type="button" class="button button-primary" id="us_ai_generate"
				data-post-id="<?php echo esc_attr($post->ID); ?>">Générer l'image</button>
			<span class="spinner" id="us_ai_spinner" style="float:none;"></span>
		</p>
		<p class="description" id="us_ai_cost"></p>
		<div id="us_ai_result"></div>
		<?php
	}

	/**
	 * Charge le JS sur l'éditeur (metabox) et les listes (bouton colonne)
	 */
	public static function enqueue_scripts($hook)
	{
		$is_editor = in_array($hook, ['post.php', 'post-new.php'], true);
		$is_list = $hook === 'edit.php';
		if (!$is_editor && !$is_list) {
			return;
		}

		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if ($screen && !in_array($screen->post_type, self::POST_TYPES, true)) {
			return;
		}

		wp_enqueue_script(
			'ultimate-shanks-ai-images',
			MP_URL . 'assets/js/ai-images.js',
			['jquery'],
			'1.0.0',
			true
		);

		wp_localize_script('ultimate-shanks-ai-images', 'ultimateShanksAiImages', self::script_data());
	}

	/**
	 * Charge le script du bloc Gutenberg « Image IA » dans l'éditeur
	 */
	public static function enqueue_block_editor_assets()
	{
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if ($screen && $screen->post_type && !in_array($screen->post_type, self::POST_TYPES, true)) {
			return;
		}

		wp_enqueue_script(
			'ultimate-shanks-ai-images-block',
			MP_URL . 'assets/js/ai-images-block.js',
			['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-data', 'jquery'],
			'1.0.0',
			true
		);

		wp_localize_script('ultimate-shanks-ai-images-block', 'ultimateShanksAiImagesBlock', self::script_data());
	}

	/**
	 * Données communes localisées pour les scripts (metabox, colonne, bloc)
	 *
	 * @return array
	 */
	private static function script_data()
	{
		$provider = Providers::get_active();
		$models = [];
		foreach ($provider->get_models() as $endpoint => $model) {
			$models[$endpoint] = [
				'label' => $model['label'],
				'price' => isset($model['price']) ? $model['price'] : null,
			];
		}

		return [
			'ajaxurl'      => admin_url('admin-ajax.php'),
			'nonce'        => wp_create_nonce('ultimate_shanks_ai_generate_image'),
			'models'       => $models,
			'defaultModel' => self::default_model($provider),
			'ratios'       => Generator::VALID_RATIOS,
			'defaultRatio' => Generator::validate_ratio(''),
			'strings'      => [
				'generating'  => 'Génération en cours… (jusqu\'à une minute)',
				'success'     => 'Image générée avec succès.',
				'error'       => 'Erreur inattendue. Réessayez.',
				'costLabel'   => 'Coût estimé : ~%s $ par image',
				'costUnknown' => 'Coût : inconnu (prix non renseigné pour ce modèle)',
				'confirmCost' => 'Générer une image à la une par IA ? Coût estimé : ~%s $',
			],
		];
	}

	/**
	 * Modèle par défaut du provider actif (option provider, repli premier du catalogue)
	 *
	 * @param ProviderInterface $provider
	 * @return string
	 */
	private static function default_model($provider)
	{
		$models = $provider->get_models();
		$default = (string) Providers::get_setting($provider->get_id(), 'model', '');

		if ($default !== '' && isset($models[$default])) {
			return $default;
		}

		$keys = array_keys($models);

		return $keys !== [] ? $keys[0] : '';
	}

	/**
	 * Bouton « Générer par IA » dans la colonne « Image à la une »
	 * (accroché au hook ultimate_shanks_featured_image_column_actions)
	 */
	public static function render_column_button($post_id)
	{
		if (!current_user_can('edit_post', $post_id)) {
			return;
		}
		?>
		<button type="button" class="button button-small us-ai-generate-btn"
			data-post-id="<?php echo esc_attr($post_id); ?>">Générer par IA</button>
		<?php
	}

	/**
	 * Handler AJAX commun (metabox + bouton colonne).
	 * Chaîne de validation : nonce → post valide → capacités → listes blanches.
	 */
	public static function ajax_generate_image()
	{
		check_ajax_referer('ultimate_shanks_ai_generate_image', 'nonce');

		$post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
		$post = get_post($post_id);
		if (!$post || !in_array($post->post_type, self::POST_TYPES, true)) {
			wp_send_json_error(['message' => 'Contenu introuvable ou type non pris en charge.'], 400);
		}

		if (!current_user_can('edit_post', $post_id) || !current_user_can('upload_files')) {
			wp_send_json_error(['message' => 'Permissions insuffisantes.'], 403);
		}

		$prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';
		$ratio = isset($_POST['aspect_ratio']) ? sanitize_text_field(wp_unslash($_POST['aspect_ratio'])) : '';
		$target = isset($_POST['target']) ? sanitize_text_field(wp_unslash($_POST['target'])) : '';
		$model = isset($_POST['model']) ? sanitize_text_field(wp_unslash($_POST['model'])) : '';

		$result = Generator::generate_for_post($post_id, [
			'prompt'        => $prompt,
			'aspect_ratio'  => $ratio,
			'target'        => $target,
			'model'         => $model,
			// L'éditeur est potentiellement ouvert : le JS insère le bloc lui-même
			'apply_content' => false,
		]);

		if (is_wp_error($result)) {
			wp_send_json_error([
				'code'    => $result->get_error_code(),
				'message' => $result->get_error_message(),
			], 502);
		}

		$result['message'] = 'Image générée avec succès.';
		wp_send_json_success($result);
	}

	/**
	 * Ajoute l'action groupée aux listes d'articles et de pages
	 */
	public static function register_bulk_action($actions)
	{
		$actions['us_ai_generate'] = 'Générer l\'image à la une par IA';

		return $actions;
	}

	/**
	 * Traite l'action groupée : cible fixe « image à la une », prompt = titre.
	 * Les contenus déjà illustrés et ceux au-delà de la limite sont ignorés.
	 */
	public static function handle_bulk_action($redirect_url, $action, $post_ids)
	{
		if ($action !== 'us_ai_generate') {
			return $redirect_url;
		}

		$generated = 0;
		$failed = 0;
		$skipped = 0;
		$cost = 0.0;
		$limit = self::bulk_limit();

		foreach ($post_ids as $post_id) {
			if ($generated + $failed >= $limit || has_post_thumbnail($post_id)) {
				$skipped++;
				continue;
			}

			if (!current_user_can('edit_post', $post_id) || !current_user_can('upload_files')) {
				$skipped++;
				continue;
			}

			$result = Generator::generate_for_post($post_id, ['target' => 'featured']);
			if (is_wp_error($result)) {
				$failed++;
			} else {
				$generated++;
				$cost += isset($result['cost']) ? (float) $result['cost'] : 0.0;
			}
		}

		return add_query_arg([
			'us_ai_bulk_generated' => $generated,
			'us_ai_bulk_failed'    => $failed,
			'us_ai_bulk_skipped'   => $skipped,
			'us_ai_bulk_cost'      => number_format($cost, 3, '.', ''),
		], $redirect_url);
	}

	/**
	 * Affiche le résultat de l'action groupée
	 */
	public static function bulk_notices()
	{
		if (!isset($_GET['us_ai_bulk_generated'])) {
			return;
		}

		$generated = absint($_GET['us_ai_bulk_generated']);
		$failed = isset($_GET['us_ai_bulk_failed']) ? absint($_GET['us_ai_bulk_failed']) : 0;
		$skipped = isset($_GET['us_ai_bulk_skipped']) ? absint($_GET['us_ai_bulk_skipped']) : 0;
		$cost = isset($_GET['us_ai_bulk_cost']) ? (float) $_GET['us_ai_bulk_cost'] : 0.0;

		$class = $failed > 0 ? 'notice-warning' : 'notice-success';
		$message = sprintf(
			'%d image(s) générée(s) pour un coût estimé de ~%s $, %d échec(s), %d ignoré(s) (déjà illustrés ou au-delà de la limite de %d par lot).',
			$generated,
			number_format_i18n($cost, 3),
			$failed,
			$skipped,
			self::bulk_limit()
		);

		printf('<div class="notice %s is-dismissible"><p>%s</p></div>', esc_attr($class), esc_html($message));
	}
}
