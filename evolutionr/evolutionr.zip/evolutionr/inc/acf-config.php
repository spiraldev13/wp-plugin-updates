<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!evolutionr_acf_is_active()) {
    return;
}

add_filter('acf/settings/save_json', function (): string {
    return get_stylesheet_directory() . '/acf-json';
});

add_filter('acf/settings/load_json', function (array $paths): array {
    unset($paths[0]);
    $paths[] = get_stylesheet_directory() . '/acf-json';
    return $paths;
});

/**
 * Auto-synchronisation des groupes ACF au déploiement.
 *
 * Les groupes vivent dans `acf-json/` (source de vérité) et sont chargés
 * automatiquement par ACF — le front-end et les métaboxes des pages
 * fonctionnent donc sans aucune intervention. En revanche, pour qu'un
 * groupe apparaisse dans la liste « Field Groups » et que ses définitions
 * soient éditables dans l'admin, il doit exister en base. Sur un nouvel
 * environnement (prod, nouvelle install), ce n'est pas le cas → ils
 * apparaîtraient en « Sync available » à synchroniser à la main.
 *
 * On automatise donc l'import en base des groupes JSON ABSENTS de la base.
 * Règles de sûreté :
 *  - admin uniquement (jamais en front, jamais en CLI sans admin) ;
 *  - on n'importe QUE les groupes sans équivalent en base → un groupe déjà
 *    synchronisé et édité dans l'admin n'est JAMAIS écrasé ;
 *  - on désactive l'écriture JSON le temps de l'import pour ne pas
 *    réécrire les fichiers du thème déployé (pas de `local_file`/chemin
 *    absolu injecté, pas d'écriture dans un dossier potentiellement en
 *    lecture seule).
 */
add_action('acf/init', 'evolutionr_acf_autosync_json_groups', 20);

function evolutionr_acf_autosync_json_groups(): void
{
    if (!is_admin() || !function_exists('acf_import_field_group')) {
        return;
    }

    $missing = array_filter(acf_get_field_groups(), function ($group): bool {
        $in_db   = is_numeric($group['ID'] ?? null) && (int) $group['ID'] > 0;
        $is_json = (($group['local'] ?? '') === 'json');
        return $is_json && !$in_db;
    });

    if (empty($missing)) {
        return;
    }

    $previous_json = acf_get_setting('json');
    acf_update_setting('json', false); // n'écrit pas dans acf-json/ pendant l'import

    foreach ($missing as $group) {
        $group['fields'] = acf_get_fields($group);
        acf_import_field_group($group);
    }

    acf_update_setting('json', $previous_json);
}

/**
 * Styles admin pour la lisibilité des repeaters ACF (démarcation des lignes +
 * numéro de gauche au fond alterné). Chargé uniquement sur les écrans où ACF
 * rend ses champs (post, pages d'options, etc.), via le hook ACF dédié.
 */
add_action('acf/input/admin_enqueue_scripts', 'evolutionr_acf_admin_styles');

function evolutionr_acf_admin_styles(): void
{
    $rel  = '/assets/admin/acf-repeater.css';
    $path = get_stylesheet_directory() . $rel;

    wp_enqueue_style(
        'evolutionr-acf-admin',
        get_stylesheet_directory_uri() . $rel,
        [],
        file_exists($path) ? (string) filemtime($path) : '1.0.0'
    );
}
