<?php

/*
 * Manifeste du script de VUE (front) — écrit à la main, AUCUNE dépendance :
 * `vue.js` est du JavaScript nu, chargé par WordPress uniquement sur les
 * pages qui contiennent réellement le bloc (mécanique `viewScript`).
 *
 * C'est la traduction de la décision 1 de la story : le défilement est du
 * CSS, le script n'ajoute que les commandes de confort.
 *
 * La version suit celle du THÈME, jamais un numéro figé.
 */
return [
    'dependencies' => [],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
