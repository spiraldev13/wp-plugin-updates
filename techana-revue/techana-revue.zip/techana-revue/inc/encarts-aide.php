<?php
/**
 * Aide en ligne des encarts, affichée dans le back-office.
 *
 * L'écran « Encarts » ouvre sur une liste vide tant qu'aucun encart n'existe :
 * WordPress y affiche « Aucun encart » et rien d'autre. Ce module meuble ce
 * vide — un panneau d'introduction en tête de liste, les onglets « Aide »
 * natifs sur les trois écrans concernés, et deux lignes de rappel au-dessus du
 * formulaire d'édition.
 *
 * Le texte vit ici et nulle part ailleurs : panneau et onglets lisent les
 * mêmes sections, et les emplacements comme les interrupteurs sont relus à
 * l'affichage (`techanaRevueEncartEmplacements()`, `techanaRevueReglagesPub()`)
 * plutôt que recopiés — une aide qui ment est pire qu'une aide absente.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'current_screen', 'techanaRevueEncartAideOnglets' );
add_action( 'admin_notices', 'techanaRevueEncartAidePanneau' );
add_action( 'edit_form_after_title', 'techanaRevueEncartAideEdition' );

/** Écran d'administration courant, du point de vue des encarts. */
function techanaRevueEncartAideEcran(): string {
    $ecran = get_current_screen();
    if ( ! $ecran ) {
        return '';
    }
    if ( 'appearance_page_' . TECHANA_PUB_PAGE === $ecran->id ) {
        return 'publicite';
    }
    if ( TECHANA_ENCART_TYPE !== $ecran->post_type ) {
        return '';
    }
    if ( 'edit' === $ecran->base ) {
        return 'liste';
    }
    return 'post' === $ecran->base ? 'edition' : '';
}

/** Lien vers l'écran des interrupteurs. */
function techanaRevueEncartAideLienReglages(): string {
    return admin_url( 'themes.php?page=' . TECHANA_PUB_PAGE );
}

/** Lien vers la liste des encarts. */
function techanaRevueEncartAideLienListe(): string {
    return admin_url( 'edit.php?post_type=' . TECHANA_ENCART_TYPE );
}

/** Ce qu'est un encart, en deux phrases. */
function techanaRevueEncartAidePrincipe(): string {
    return '<p>Un <strong>encart</strong> est un espace commercial — publicité,'
        . ' lien partenaire, lien affilié — que le site place tout seul aux endroits'
        . ' prévus par le thème. Vous le décrivez <em>une fois</em> ici ; il ressort'
        . ' ensuite sur toutes les pages qui correspondent, sans rien coller dans vos'
        . ' articles.</p>'
        . '<p>Un encart n’a pas d’adresse à lui : il n’existe qu’à l’intérieur des'
        . ' pages du site. C’est pourquoi le bouton « Voir » n’apparaît pas ici.</p>';
}

/** Le parcours de création, dans l'ordre où les champs se présentent. */
function techanaRevueEncartAideCreer(): string {
    return '<p>Six décisions, dans cet ordre :</p><ol>'
        . '<li><strong>Ce qui s’affiche</strong> — soit un <em>visuel</em> pris dans la'
        . ' médiathèque, soit un <em>code de régie</em> collé (AdSense et compagnie).'
        . ' Si les deux sont remplis, le code l’emporte. Sans l’un ou l’autre,'
        . ' l’encart n’a rien à montrer et reste invisible.</li>'
        . '<li><strong>Où il peut sortir</strong> — les cases « Emplacements », dans la'
        . ' colonne de droite. Aucune cochée : l’encart n’apparaît nulle part.</li>'
        . '<li><strong>Pour quelles rubriques</strong> — la boîte « Catégories »'
        . ' habituelle. Une ou plusieurs cochées : l’encart ne sort que dans'
        . ' celles-là. <strong>Aucune cochée</strong> : c’est un encart <em>par'
        . ' défaut</em>, servi partout où aucun encart de rubrique ne s’applique.</li>'
        . '<li><strong>Pour un article précis</strong> — le ciblage ci-dessus vise'
        . ' des rubriques entières. Pour poser un encart sur <em>un seul</em> article,'
        . ' ouvrez cet article : le panneau « TechAna » de l’éditeur propose'
        . ' « Encart de cet article » et son emplacement (corps ou pied). Ce choix'
        . ' passe avant la rubrique, à cet emplacement seulement — la latérale du même'
        . ' article continue de suivre les règles habituelles.</li>'
        . '<li><strong>La déclaration du lien</strong> — <code>sponsored</code> est coché'
        . ' d’office, <code>nofollow</code> vous est laissé au choix (voir plus bas).</li>'
        . '<li><strong>Publier</strong> — publié vaut allumé, brouillon vaut éteint.'
        . ' Pour arrêter une campagne, repassez l’encart en brouillon : inutile de le'
        . ' supprimer, vous le rallumerez d’un clic.</li>'
        . '</ol>'
        . '<p>Le <strong>titre</strong> est un nom de travail (« Hébergeur X ») :'
        . ' il ne s’affiche jamais sur le site, il sert à vous y retrouver dans la'
        . ' liste. Ce que voit le lecteur au-dessus de l’encart, c’est le'
        . ' <strong>libellé</strong> — « Publicité » si vous le laissez vide, jamais'
        . ' rien : un encart commercial doit être signalé comme tel.</p>';
}

/** Où les encarts tombent dans la page, emplacement par emplacement. */
function techanaRevueEncartAideEmplacements(): string {
    $html = '<p>Cinq endroits, chacun décrit ci-dessous :</p><ul>';
    foreach ( techanaRevueEncartEmplacements() as $def ) {
        $html .= sprintf(
            '<li><strong>%s</strong> — %s</li>',
            esc_html( $def['label'] ),
            esc_html( $def['aide'] )
        );
    }
    $html .= '</ul>';
    return $html . '<p>Quand plusieurs encarts peuvent occuper le même endroit, le site'
        . ' en <strong>tire un au sort</strong> à chaque affichage : c’est ce qui fait'
        . ' tourner les liens entre vos annonceurs.</p>'
        . '<p>Un emplacement allumé mais <strong>sans encart disponible</strong> peut'
        . ' proposer l’espace aux visiteurs — « Votre publicité ici », avec un bouton'
        . ' vers la page « Annoncez sur TechAna ». Les endroits concernés et les textes'
        . ' se règlent dans <a href="' . esc_url( techanaRevueEncartAideLienReglages() ) . '">Apparence → Publicité</a>,'
        . ' section « Espace à vendre ». Cette proposition <strong>n’est pas une'
        . ' publicité</strong> : elle ne porte pas la mention « Publicité », et un encart'
        . ' réel reprend sa place automatiquement dès qu’il y en a un.</p>'
        . '<p>Chaque encart choisit enfin sa <strong>déclaration de lien</strong> :'
        . ' <code>rel="sponsored"</code> (coché d’office) annonce à Google un lien payé —'
        . ' publicité, partenariat, affiliation ; <code>rel="nofollow"</code>, plus large et'
        . ' seul compris de Bing, peut s’y ajouter. Sans déclaration, un lien commercial'
        . ' passe pour une recommandation éditoriale, ce qui expose le site à une'
        . ' pénalité : ne les décochez que pour un lien qui n’est pas commercial.</p>';
}

/** La checklist de dépannage, dans l'ordre où les garde-fous s'appliquent. */
function techanaRevueEncartAideDiagnostic(): string {
    return '<p>Reprenez ces points dans l’ordre — le premier qui cloche explique tout :</p><ol>'
        . '<li>L’encart est-il <strong>publié</strong> ? Un brouillon est éteint.</li>'
        . '<li>A-t-il <strong>au moins un emplacement</strong> coché ? La colonne'
        . ' « Emplacements » de la liste affiche <em>aucun — invisible</em> dans le cas'
        . ' contraire.</li>'
        . '<li>A-t-il un <strong>visuel ou un code</strong> de régie ? Les deux vides,'
        . ' il n’y a rien à afficher.</li>'
        . '<li>L’emplacement est-il <strong>allumé</strong> dans <a href="' . esc_url( techanaRevueEncartAideLienReglages() ) . '">Apparence → Publicité</a> ?'
        . ' Un interrupteur éteint coupe l’emplacement pour tout le site, sans toucher'
        . ' aux encarts — <strong>y compris un encart épinglé sur un article</strong> :'
        . ' c’est ce qui permet d’arrêter toute la publicité d’un geste.</li>'
        . '<li>Un <strong>autre encart est-il épinglé sur cet article</strong> ?'
        . ' Le panneau « TechAna » de l’éditeur l’indique : un encart épinglé prend'
        . ' la place de celui de la rubrique, à son emplacement. Un encart épinglé'
        . ' puis repassé en brouillon rend la main à la rubrique.</li>'
        . '<li>Regardez-vous la <strong>bonne rubrique</strong> ? Une catégorie cochée'
        . ' restreint l’encart à celle-ci ; sur un article, c’est sa première rubrique'
        . ' qui compte.</li>'
        . '<li>Pour « dans le corps de l’article » : l’article a-t-il <strong>assez de'
        . ' paragraphes</strong> (le seuil se règle dans Apparence → Publicité) ? Un'
        . ' article <strong>sponsorisé</strong> n’en reçoit aucun d’office — il porte'
        . ' déjà ses encarts annonceur ; seul un encart <em>épinglé</em> y apparaît,'
        . ' parce que vous l’avez choisi pour lui.</li>'
        . '</ol>'
        . '<p>Un emplacement allumé mais sans encart disponible affiche la'
        . ' <strong>proposition d’achat</strong> (« Votre publicité ici ») s’il est coché'
        . ' pour cela dans Apparence → Publicité. Sinon il ne montre rien aux visiteurs :'
        . ' vous, connecté, y voyez un cadre « Aucun encart pour cet emplacement », un'
        . ' repère de travail que personne d’autre n’a sous les yeux.</p>';
}

/** Ce que l'outil ne fait pas — pour ne pas le chercher. */
function techanaRevueEncartAideLimites(): string {
    return '<p>Cet écran gère la <em>diffusion</em>, pas la régie : il n’y a ni dates'
        . ' de campagne (on allume et on éteint à la main), ni comptage de clics ou'
        . ' d’impressions, ni pondération entre annonceurs — le tirage est équitable.'
        . ' Pour des statistiques, comptez sur celles de votre régie ou du programme'
        . ' d’affiliation.</p>';
}

/** Nombre d'encarts existants, brouillons compris — la corbeille ne compte pas. */
function techanaRevueEncartAideCompte(): int {
    $comptes = (array) wp_count_posts( TECHANA_ENCART_TYPE );
    $total   = 0;
    foreach ( array( 'publish', 'draft', 'pending', 'private', 'future' ) as $statut ) {
        $total += (int) ( $comptes[ $statut ] ?? 0 );
    }
    return $total;
}

/**
 * État des interrupteurs, relu à l'affichage.
 *
 * Première cause d'un encart invisible, et elle se règle sur un autre écran que
 * celui qu'on a sous les yeux : l'aide nomme les emplacements réellement
 * éteints plutôt que d'en parler en théorie.
 */
function techanaRevueEncartAideEtatEmplacements(): string {
    $reglages = techanaRevueReglagesPub();
    $tous     = techanaRevueEncartEmplacements();
    $eteints  = array();
    foreach ( $tous as $cle => $def ) {
        if ( empty( $reglages[ $cle . '_actif' ] ) ) {
            $eteints[] = $def['label'];
        }
    }
    $lien = sprintf(
        '<a href="%s">Apparence → Publicité</a>',
        esc_url( techanaRevueEncartAideLienReglages() )
    );

    if ( ! $eteints ) {
        return sprintf(
            '<p>Les <strong>%d emplacements sont allumés</strong> : un encart publié et'
                . ' correctement rempli sortira. Ils se coupent un par un dans %s.</p>',
            count( $tous ),
            $lien
        );
    }
    return sprintf(
        '<p><strong>%s éteint%s pour tout le site</strong> : %s. Aucun encart n’y paraîtra,'
            . ' quels que soient ses réglages. Se rallume dans %s.</p>',
        1 === count( $eteints ) ? 'Emplacement' : 'Emplacements',
        1 === count( $eteints ) ? '' : 's',
        esc_html( implode( ', ', $eteints ) ),
        $lien
    );
}

/**
 * Panneau d'introduction en tête de la liste des encarts.
 *
 * Dépliable, ouvert tant qu'aucun encart n'existe : celui qui découvre l'écran
 * lit tout, celui qui l'utilise garde une liste propre. Un `<details>` suffit —
 * ni JavaScript, ni préférence à stocker par utilisateur.
 */
function techanaRevueEncartAidePanneau() {
    if ( 'liste' !== techanaRevueEncartAideEcran() ) {
        return;
    }
    $vide = 0 === techanaRevueEncartAideCompte();

    echo '<div class="notice notice-info"><details' . ( $vide ? ' open' : '' ) . '>';
    printf(
        '<summary style="cursor:pointer;font-size:14px;padding:4px 0"><strong>%s</strong></summary>',
        $vide
            ? 'Aucun encart pour l’instant — voici à quoi sert cet écran'
            : 'À quoi sert cet écran, et comment poser un encart'
    );
    echo '<div style="max-width:52em">';
    echo techanaRevueEncartAidePrincipe();
    echo '<h3 style="margin-bottom:0">Poser un encart</h3>';
    echo techanaRevueEncartAideCreer();
    echo '<h3 style="margin-bottom:0">Où il apparaît</h3>';
    echo techanaRevueEncartAideEmplacements();
    echo techanaRevueEncartAideEtatEmplacements();
    echo '<p class="description">Le détail — dont « mon encart n’apparaît pas » — vit dans'
        . ' l’onglet <strong>Aide</strong>, en haut à droite de cet écran.</p>';
    if ( $vide ) {
        printf(
            '<p><a class="button button-primary" href="%s">Créer un premier encart</a></p>',
            esc_url( admin_url( 'post-new.php?post_type=' . TECHANA_ENCART_TYPE ) )
        );
    }
    echo '</div></details></div>';
}

/** Rappel au-dessus du formulaire : le minimum pour qu'un encart sorte. */
function techanaRevueEncartAideEdition( WP_Post $post ) {
    if ( TECHANA_ENCART_TYPE !== $post->post_type ) {
        return;
    }
    echo '<div class="notice notice-info inline" style="margin:10px 0"><p>'
        . 'Ce titre est un <strong>nom de travail</strong>, jamais affiché sur le site.'
        . ' Pour que cet encart sorte, il lui faut un <strong>visuel ou un code de'
        . ' régie</strong>, <strong>au moins un emplacement</strong> coché à droite, et'
        . ' d’être <strong>publié</strong>. Sans rubrique cochée, il sert d’encart par'
        . ' défaut, partout où aucun encart de rubrique ne s’applique.'
        . '</p></div>';
}

/** Onglets « Aide » natifs, sur les trois écrans où la question se pose. */
function techanaRevueEncartAideOnglets() {
    $ecran = techanaRevueEncartAideEcran();
    if ( '' === $ecran ) {
        return;
    }
    $courant = get_current_screen();
    $onglets = array(
        'techana-encart-principe'     => array( 'À quoi ça sert', techanaRevueEncartAidePrincipe() ),
        'techana-encart-creer'        => array( 'Poser un encart', techanaRevueEncartAideCreer() ),
        'techana-encart-emplacements' => array( 'Où il apparaît', techanaRevueEncartAideEmplacements() ),
        'techana-encart-diagnostic'   => array( 'Il n’apparaît pas', techanaRevueEncartAideDiagnostic() ),
        'techana-encart-limites'      => array( 'Ce que ça ne fait pas', techanaRevueEncartAideLimites() ),
    );
    foreach ( $onglets as $id => $onglet ) {
        $courant->add_help_tab( array(
            'id'      => $id,
            'title'   => $onglet[0],
            'content' => $onglet[1],
        ) );
    }
    $courant->set_help_sidebar( sprintf(
        '<p><strong>Les deux écrans</strong></p><p><a href="%s">Encarts</a> — le contenu :'
            . ' quoi, où, pour quelle rubrique.</p><p><a href="%s">Apparence → Publicité</a>'
            . ' — les interrupteurs : allumer ou couper un emplacement pour tout le site.</p>',
        esc_url( techanaRevueEncartAideLienListe() ),
        esc_url( techanaRevueEncartAideLienReglages() )
    ) );
}
