<?php
/**
 * Seeder one-shot du thème Evolution'R.
 *
 * À la première activation du thème, insère :
 *  - 2 réalisations (CPT `realisation`)
 *  - 1 page « Accueil » si aucune front-page n'est configurée
 *
 * Les prestations et la FAQ de la home sont des repeaters ACF (`services_cards`,
 * `faq_items`) édités sur la page d'accueil — voir `evolutionr_seed_front_page()`.
 *
 * Chaque contenu reçoit :
 *  - ses champs ACF (via `update_field`) si ACF est actif
 *  - son trio de méta Rank Math (`rank_math_title`, `rank_math_description`,
 *    `rank_math_focus_keyword`) via `update_post_meta`, indépendamment de la
 *    présence d'ACF ou de Rank Math (les méta sont posées en base et seront
 *    reprises automatiquement par Rank Math s'il est activé plus tard).
 *
 * Idempotence : l'option `evolutionr_seeded` est posée à la fin du seed.
 * Tant qu'elle est présente, le seeder se contente de retourner.
 * Pour relancer le seed : `delete_option('evolutionr_seeded')` puis
 * désactiver / réactiver le thème.
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('after_switch_theme', 'evolutionr_seed_content');

function evolutionr_seed_content(): void
{
    // Idempotence à deux niveaux :
    //  - `evolutionr_seed_realisations()` déduplique par post_type + post_title
    //    exact, donc relancer ne crée jamais de doublon.
    //  - Les contenus de la front-page (text + repeaters) sont sous le
    //    guard `evolutionr_front_page_seeded` : ils ne sont peuplés qu'une
    //    seule fois, pour ne jamais écraser ce que l'admin saisit ensuite.
    evolutionr_seed_realisations();

    if (!get_option('evolutionr_front_page_seeded')) {
        evolutionr_seed_front_page();
        update_option('evolutionr_front_page_seeded', true);
    }

    if (!get_option('evolutionr_lancement_seeded')) {
        evolutionr_seed_lancement_pages();
        update_option('evolutionr_lancement_seeded', true);
    }

    if (!get_option('evolutionr_lancement_home_v2_seeded')) {
        evolutionr_seed_lancement_home_extensions();
        update_option('evolutionr_lancement_home_v2_seeded', true);
    }

    if (!get_option('evolutionr_lancement_pages_v2_seeded')) {
        evolutionr_seed_lancement_pages_v2_extensions();
        update_option('evolutionr_lancement_pages_v2_seeded', true);
    }

    if (!get_option('evolutionr_tarifs_seeded')) {
        evolutionr_seed_tarifs();
        update_option('evolutionr_tarifs_seeded', true);
    }

    if (!get_option('evolutionr_creation_sections_seeded')) {
        evolutionr_seed_creation_sections();
        update_option('evolutionr_creation_sections_seeded', true);
    }

    if (!get_option('evolutionr_tarifs_hero_stats_seeded')) {
        evolutionr_seed_tarifs_hero_stats();
        update_option('evolutionr_tarifs_hero_stats_seeded', true);
    }

    if (!get_option('evolutionr_seo_sections_seeded')) {
        evolutionr_seed_seo_sections();
        update_option('evolutionr_seo_sections_seeded', true);
    }

    if (!get_option('evolutionr_maintenance_sections_seeded')) {
        evolutionr_seed_maintenance_sections();
        update_option('evolutionr_maintenance_sections_seeded', true);
    }

    if (!get_option('evolutionr_contact_hero_stats_seeded')) {
        evolutionr_seed_contact_hero_stats();
        update_option('evolutionr_contact_hero_stats_seeded', true);
    }

    if (!get_option('evolutionr_contact_form_seeded')) {
        evolutionr_seed_contact_form();
        update_option('evolutionr_contact_form_seeded', true);
    }

    if (!get_option('evolutionr_blog_categories_seeded')) {
        evolutionr_seed_blog_categories();
        update_option('evolutionr_blog_categories_seeded', true);
    }

    if (!get_option('evolutionr_about_seeded')) {
        evolutionr_seed_about_page();
        update_option('evolutionr_about_seeded', true);
    }

    if (!get_option('evolutionr_identite_visuelle_seeded')) {
        evolutionr_seed_identite_visuelle_home_card();
        evolutionr_seed_identite_visuelle_pricing();
        update_option('evolutionr_identite_visuelle_seeded', true);
    }

    if (!get_option('evolutionr_iv_page_seeded')) {
        evolutionr_seed_identite_visuelle_page();
        update_option('evolutionr_iv_page_seeded', true);
    }

    if (!get_option('evolutionr_tarifs_contact_hero_text_seeded')) {
        evolutionr_seed_tarifs_contact_hero_text();
        update_option('evolutionr_tarifs_contact_hero_text_seeded', true);
    }

    // Refonte de contenu — stratégie SEO locale Toulouse + remote (cf.
    // change `refonte-contenu-seo`, CONTEXT.md). RÉÉCRIT le contenu (pas de
    // garde « if empty ») car c'est une refonte assumée.
    if (!get_option('evolutionr_contenu_refonte_seeded')) {
        evolutionr_seed_refonte_options();
        update_option('evolutionr_contenu_refonte_seeded', true);
    }

    // Snapshot de contenu (texte peaufiné live) — appliqué EN DERNIER pour qu'une
    // réinstallation reparte sur le contenu final. Médias exclus, URLs relatives.
    if (!get_option('evolutionr_content_snapshot_v1_seeded')) {
        evolutionr_seed_content_snapshot();
        update_option('evolutionr_content_snapshot_v1_seeded', true);
    }

    update_option('evolutionr_seeded', true);
}

/**
 * Insère un post + ses méta ACF (si dispo) + ses méta Rank Math.
 * Ne crée jamais de doublon : vérification préalable par post_type + post_title exact.
 *
 * @param array $args       Arguments passés à `wp_insert_post()`.
 * @param array $acf        ['nom_champ_acf' => valeur].
 * @param array $rank_math  ['title' => …, 'description' => …, 'focus_keyword' => …].
 * @return int|null         ID du post créé, ou null si échec / doublon.
 */
function evolutionr_seed_insert_post(array $args, array $acf = [], array $rank_math = []): ?int
{
    $existing = get_posts([
        'post_type'      => $args['post_type'] ?? 'post',
        'title'          => $args['post_title'] ?? '',
        'post_status'    => 'any',
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ]);

    if (!empty($existing)) {
        return null;
    }

    $post_id = wp_insert_post(array_merge([
        'post_status' => 'publish',
    ], $args), true);

    if (is_wp_error($post_id) || !$post_id) {
        error_log('[evolutionr seeder] échec insertion : ' . (is_wp_error($post_id) ? $post_id->get_error_message() : 'ID 0'));
        return null;
    }

    if (!empty($acf) && evolutionr_acf_is_active()) {
        foreach ($acf as $field_name => $value) {
            update_field($field_name, $value, $post_id);
        }
    }

    if (!empty($rank_math)) {
        evolutionr_seed_rank_math_meta($post_id, $rank_math);
    }

    return (int) $post_id;
}

/**
 * Pose les méta Rank Math sur un post donné.
 *
 * Les méta sont écrites en base même si Rank Math n'est pas (encore) actif :
 * ce sont de simples `wp_postmeta`, sans dépendance à l'API du plugin.
 * Si Rank Math est activé plus tard, il reprend automatiquement ces valeurs.
 *
 * @param int   $post_id ID du post.
 * @param array $meta    ['title' => string, 'description' => string, 'focus_keyword' => string].
 */
function evolutionr_seed_rank_math_meta(int $post_id, array $meta): void
{
    $map = [
        'title'         => 'rank_math_title',
        'description'   => 'rank_math_description',
        'focus_keyword' => 'rank_math_focus_keyword',
    ];

    foreach ($map as $key => $meta_key) {
        if (isset($meta[$key]) && $meta[$key] !== '') {
            update_post_meta($post_id, $meta_key, $meta[$key]);
        }
    }
}

function evolutionr_seed_realisations(): void
{
    evolutionr_seed_insert_post(
        [
            'post_type'    => 'realisation',
            'post_title'   => 'Site vitrine — Atelier Maréchal',
            'post_content' => 'Création d\'un site vitrine pour un atelier d\'artisan local : structure claire, contenu adapté au métier et optimisation SEO sur les recherches géographiques.',
        ],
        [
            'realisation_client'  => 'Atelier Maréchal',
            'realisation_mission' => 'Site vitrine • SEO local',
            'realisation_year'    => 2024,
            'realisation_layout'  => 'wide',
        ],
        [
            'title'         => 'Site vitrine artisan — Atelier Maréchal | Evolution\'R',
            'description'   => 'Création d\'un site vitrine pour un atelier d\'artisan local : structure claire, contenu adapté et optimisation SEO sur les recherches géographiques.',
            'focus_keyword' => 'site vitrine artisan',
        ]
    );

    evolutionr_seed_insert_post(
        [
            'post_type'    => 'realisation',
            'post_title'   => 'Refonte SEO — Cabinet Lemaire',
            'post_content' => 'Refonte complète d\'un site professionnel et restructuration SEO : meilleure visibilité Google sur les requêtes métier et amélioration du parcours visiteur.',
        ],
        [
            'realisation_client'  => 'Cabinet Lemaire',
            'realisation_mission' => 'Refonte complète • SEO',
            'realisation_year'    => 2024,
            'realisation_layout'  => 'tall',
        ],
        [
            'title'         => 'Refonte de site et SEO — Cabinet Lemaire | Evolution\'R',
            'description'   => 'Refonte complète d\'un site professionnel et restructuration SEO : meilleure visibilité Google sur les requêtes métier et parcours visiteur amélioré.',
            'focus_keyword' => 'refonte site internet',
        ]
    );
}

function evolutionr_seed_front_page(): void
{
    $front_id = (int) get_option('page_on_front');

    if (!$front_id) {
        $front_id = wp_insert_post([
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => 'Accueil',
            'post_name'    => 'accueil',
            'post_content' => '',
        ], true);

        if (is_wp_error($front_id) || !$front_id) {
            error_log('[evolutionr seeder] échec création front-page');
            return;
        }

        update_option('show_on_front', 'page');
        update_option('page_on_front', $front_id);
    }

    if (evolutionr_acf_is_active()) {
        evolutionr_seed_front_page_text((int) $front_id);

        update_field('hero_meta', [
            ['label' => 'Devis sous 48h'],
            ['label' => 'Solution complète'],
            ['label' => 'Interlocuteur unique'],
            ['label' => 'Sans engagement'],
        ], $front_id);

        update_field('hero_stats', [
            ['label' => 'Délai de réponse', 'value' => '48h', 'delta' => ''],
            ['label' => 'Services intégrés', 'value' => '4', 'delta' => 'Création • SEO • Maintenance • Hébergement'],
        ], $front_id);

        update_field('reassure_items', [
            ['label' => 'Réponse sous', 'value' => '48h'],
            ['label' => 'Services intégrés', 'value' => '4'],
            ['label' => 'Interlocuteur', 'value' => 'unique'],
            ['label' => 'Solution', 'value' => 'complète'],
        ], $front_id);

        update_field('pillars', [
            [
                'icon'  => 'compass',
                'title' => 'Un interlocuteur unique',
                'desc'  => 'Création, SEO, maintenance, hébergement : un seul interlocuteur, pour plus de simplicité et de cohérence dans le suivi de votre site.',
            ],
            [
                'icon'  => 'shield',
                'title' => 'Fiabilité dans la durée',
                'desc'  => 'Mises à jour, sauvegardes et surveillance régulière. Votre site reste sain et accessible, mois après mois.',
            ],
            [
                'icon'  => 'search',
                'title' => 'Pensé pour Google',
                'desc'  => 'Structure, contenus et balises optimisés dès la conception. Le SEO n\'est pas un ajout, c\'est une fondation.',
            ],
            [
                'icon'  => 'trend',
                'title' => 'Présence durable',
                'desc'  => 'Pas de site vite fait, vite oublié : un travail conçu pour évoluer avec votre activité.',
            ],
        ], $front_id);

        update_field('method_steps', [
            [
                'num'   => '01',
                'title' => 'Comprendre votre activité',
                'desc'  => 'On échange sur votre métier, vos objectifs et votre cible. Vous nous parlez, nous prenons des notes.',
                'meta'  => '≈ 1h d\'échange',
            ],
            [
                'num'   => '02',
                'title' => 'Cadrer le projet',
                'desc'  => 'Nous vous proposons une arborescence, un périmètre clair, un devis détaillé. Aucune zone d\'ombre.',
                'meta'  => 'Sous 2 à 5 jours',
            ],
            [
                'num'   => '03',
                'title' => 'Concevoir & rédiger',
                'desc'  => 'Maquettes, structure des contenus, balises SEO. On valide ensemble avant tout développement.',
                'meta'  => '1 à 2 semaines',
            ],
            [
                'num'   => '04',
                'title' => 'Développer & mettre en ligne',
                'desc'  => 'Intégration, tests, recette, mise en production sur un hébergement adapté.',
                'meta'  => '2 à 4 semaines',
            ],
            [
                'num'   => '05',
                'title' => 'Suivre dans la durée',
                'desc'  => 'Maintenance, sauvegardes, conseils SEO, ajustements. Votre site continue d\'évoluer.',
                'meta'  => 'En continu',
            ],
        ], $front_id);
    }

    evolutionr_seed_rank_math_meta((int) $front_id, [
        'title'         => 'Agence web, SEO & maintenance WordPress | Evolution\'R',
        'description'   => 'Agence web & consultant SEO : création de sites vitrines, référencement naturel, maintenance et hébergement. Devis gratuit sous 48h, sans engagement.',
        'focus_keyword' => 'agence web',
    ]);
}

/**
 * Peuple tous les champs text/textarea de la front-page avec les valeurs alignées
 * sur l'activité (agence web et consultant SEO).
 *
 * Appelée une seule fois lors du premier passage du seeder front-page (sous
 * l'option-guard `evolutionr_front_page_seeded`). Une fois posée, ne se ré-applique
 * jamais : tout changement ultérieur de l'admin est respecté.
 */
function evolutionr_seed_front_page_text(int $front_id): void
{
    $fields = [
        // Hero
        'hero_status_text'        => 'Disponible — devis gratuit sous 48h',
        'hero_title_lead'         => 'Un site web',
        'hero_title_accent'       => 'clair, visible',
        'hero_title_trail'        => 'et durable pour votre activité.',
        'hero_sub'                => 'Création de sites vitrines, référencement naturel, maintenance et hébergement : un interlocuteur unique pour une présence en ligne fiable, pensée pour vos visiteurs et pour Google.',
        'hero_visual_label'       => 'presence_en_ligne.plan',

        // Services
        'services_eyebrow'        => 'Nos prestations',
        'services_title'          => 'Quatre services pour bâtir votre présence en ligne',
        'services_lede'           => 'De la création du site à son hébergement, en passant par le référencement et la maintenance, nous accompagnons vos projets de bout en bout.',

        // Pillars
        'pillars_eyebrow'         => 'Pourquoi nous choisir',
        'pillars_title'           => 'Un partenaire web, pas seulement un prestataire',

        // Method
        'method_eyebrow'          => 'Comment nous travaillons',
        'method_title'            => 'Une méthode simple, transparente, étape par étape',
        'method_lede'             => 'Chaque projet suit un cadre clair : on comprend votre activité, on conçoit, on développe, on met en ligne, on suit dans la durée.',
        'method_active_index'     => 3,

        // Works
        'works_eyebrow'           => 'Quelques réalisations',
        'works_title'             => 'Des sites pensés pour leurs visiteurs',
        // works_url vide par défaut : le CTA « Voir tout le portfolio »
        // n'apparaît pas tant qu'aucune page portfolio publique n'existe.
        'works_url'               => '',

        // Blog
        'blog_eyebrow'            => 'Journal & conseils',
        'blog_title'              => 'Conseils web, SEO et maintenance',
        'blog_archive_url'        => '/blog/',

        // FAQ
        'faq_eyebrow'             => 'Questions fréquentes',
        'faq_title'               => 'Vos questions, des réponses claires',
        'faq_lede'                => 'Tarifs, délais, contenu, hébergement : les questions que l\'on nous pose le plus souvent.',

        // Final CTA
        'final_cta_eyebrow'       => 'Devis gratuit — réponse sous 48h',
        'final_cta_title'         => 'Parlons de votre projet web',
        'final_cta_paragraph'     => 'Un site à créer, à refondre, à référencer ou à maintenir ? Décrivez-nous votre besoin : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.',
        'final_cta_primary_label' => 'Demander un devis gratuit',
        // CTA secondaire facultatif laissé vide par défaut (on n'expose pas
        // de téléphone, donc « Réserver un appel » serait un CTA mort). Si
        // tu veux un second bouton, remplis label + URL en BO.
        'final_cta_secondary_label' => '',
        'final_cta_secondary_url'   => '',
    ];

    foreach ($fields as $name => $value) {
        update_field($name, $value, $front_id);
    }
}

/* ─────────────────────────────────────────────────────────────────────
 *  Seeder du change `lancement-site-evolutionr` :
 *  crée les 5 pages publiques + 3 pages légales avec leurs champs ACF
 *  et leurs méta Rank Math (cf. .claude/docs/SITE.MD).
 *
 *  Idempotent : dédup par post_type=page + post_name unique.
 *  Guarded par l'option `evolutionr_lancement_seeded`.
 *
 *  Pour relancer : `wp option delete evolutionr_lancement_seeded;
 *  wp eval 'evolutionr_seed_lancement_pages();'`.
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_lancement_pages(): void
{
    evolutionr_seed_lancement_page_creation();
    evolutionr_seed_lancement_page_seo();
    evolutionr_seed_lancement_page_maintenance();
    evolutionr_seed_lancement_page_tarifs();
    evolutionr_seed_lancement_page_contact();
    evolutionr_seed_lancement_page_mentions_legales();
    evolutionr_seed_lancement_page_confidentialite();
    evolutionr_seed_lancement_page_cgv();
}

/**
 * Retrouve l'ID d'une page par son slug, indépendamment de sa position dans
 * la hiérarchie. `get_page_by_path('<slug>')` échoue sur une page enfant
 * (il attend le chemin complet `parent/enfant`) — d'où ce lookup par
 * `post_name` qui matche quel que soit le parent. Retourne null si absent.
 */
function evolutionr_seed_get_page_id(string $slug): ?int
{
    $ids = get_posts([
        'post_type'      => 'page',
        'name'           => $slug,
        'post_status'    => 'any',
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ]);

    return empty($ids) ? null : (int) $ids[0];
}

/**
 * Insère ou récupère une page par slug. Si la page existe déjà, retourne son ID
 * sans la modifier (sauf injection des méta ACF + Rank Math en cas de pose
 * initiale). Permet de relancer le seed sans créer de doublons.
 */
function evolutionr_seed_get_or_create_page(string $title, string $slug, string $content = ''): ?int
{
    $existing = evolutionr_seed_get_page_id($slug);
    if ($existing !== null) {
        return $existing;
    }

    $post_id = wp_insert_post([
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_content' => $content,
    ], true);

    if (is_wp_error($post_id) || !$post_id) {
        error_log('[evolutionr seeder lancement] échec création page ' . $slug);
        return null;
    }

    return (int) $post_id;
}

function evolutionr_seed_lancement_page_creation(): void
{
    $id = evolutionr_seed_get_or_create_page(
        'Création de site web',
        'creation-site-internet',
        ''
    );
    if (!$id) return;

    if (evolutionr_acf_is_active()) {
        update_field('types', [
            [
                'label' => 'Site One Page',
                'desc'  => 'Pour les activités simples qui ont besoin d\'une présence professionnelle rapide, en une seule page complète et soignée.',
                'included' => [
                    ['text' => 'Une page complète et structurée'],
                    ['text' => '5 à 7 sections (présentation, services, arguments, contact)'],
                    ['text' => 'Design responsive et lisible'],
                    ['text' => 'Formulaire de contact'],
                    ['text' => 'SEO de base'],
                ],
            ],
            [
                'label' => 'Site vitrine',
                'desc'  => 'Pour présenter une entreprise avec plusieurs pages structurées et un message clair par audience.',
                'included' => [
                    ['text' => 'Page d\'accueil + pages services + à propos + contact'],
                    ['text' => 'Pages complémentaires selon besoin'],
                    ['text' => 'Design responsive et accessible'],
                    ['text' => 'Optimisation SEO de base'],
                ],
            ],
            [
                'label' => 'Site vitrine avancé',
                'desc'  => 'Pour les entreprises qui veulent un site plus structuré, avec plus de pages et une meilleure base SEO.',
                'included' => [
                    ['text' => '6 à 10 pages organisées'],
                    ['text' => 'Arborescence personnalisée'],
                    ['text' => 'Maillage interne soigné'],
                    ['text' => 'SEO renforcé dès la conception'],
                    ['text' => 'Accompagnement sur la structure des contenus'],
                ],
            ],
            [
                'label' => 'Refonte de site internet',
                'desc'  => 'Pour moderniser un site existant : design, structure, référencement et confort d\'utilisation.',
                'included' => [
                    ['text' => 'Audit complet de l\'existant'],
                    ['text' => 'Restructuration des contenus'],
                    ['text' => 'Amélioration du design et du responsive'],
                    ['text' => 'Optimisation SEO de base'],
                ],
            ],
            [
                'label' => 'Site e-commerce',
                'desc'  => 'Pour vendre des produits ou services en ligne, avec une boutique claire et adaptée à votre catalogue.',
                'included' => [
                    ['text' => 'Catalogue produits structuré'],
                    ['text' => 'Panier et paiement en ligne'],
                    ['text' => 'Configuration des livraisons'],
                    ['text' => 'Pages légales obligatoires'],
                    ['text' => 'Formation à la prise en main'],
                ],
            ],
        ], $id);

        update_field('creation_included', [
            ['text' => 'Cadrage du projet et de l\'arborescence'],
            ['text' => 'Structure des pages adaptée à votre activité'],
            ['text' => 'Design responsive (mobile, tablette, ordinateur)'],
            ['text' => 'Intégration des contenus fournis'],
            ['text' => 'Formulaire de contact opérationnel'],
            ['text' => 'Optimisation SEO de base (balises, structure)'],
            ['text' => 'Mise en ligne accompagnée'],
            ['text' => 'Formation à la prise en main'],
        ], $id);

        update_field('creation_excluded', [
            ['text' => 'Rédaction complète des contenus SEO avancés'],
            ['text' => 'Stratégie SEO mensuelle'],
            ['text' => 'Création de logo'],
            ['text' => 'Photos professionnelles'],
            ['text' => 'Fonctionnalités complexes sur-mesure'],
            ['text' => 'Maintenance après mise en ligne (sauf formule)'],
            ['text' => 'Hébergement (sauf formule ou pack choisi)'],
        ], $id);

        update_field('faq', [
            ['question' => 'Quel type de site choisir ?', 'answer' => 'Cela dépend de votre besoin : une activité simple peut suffire avec une one page, une entreprise qui veut développer son SEO partira sur un site vitrine avancé. Nous échangeons en amont pour vous orienter.'],
            ['question' => 'Combien de temps faut-il pour créer un site ?', 'answer' => 'Entre 1 et 8 semaines selon le type de site, la disponibilité des contenus et le nombre d\'allers-retours nécessaires. Un planning précis est donné lors du cadrage.'],
            ['question' => 'Le site sera-t-il responsive ?', 'answer' => 'Oui, c\'est non négociable. Tous nos sites sont conçus mobile-first et fonctionnent du smartphone à l\'ordinateur.'],
            ['question' => 'Le site sera-t-il optimisé pour Google ?', 'answer' => 'Tous les sites sont livrés avec un SEO de base (balises titre/description, structure des contenus, maillage). Pour un SEO mensuel actif, voir la prestation Consultant SEO.'],
            ['question' => 'Puis-je payer en plusieurs fois ou par abonnement ?', 'answer' => 'Oui. Nous proposons un paiement unique ou un abonnement mensuel (engagement 24 ou 36 mois selon formule), qui inclut hébergement et maintenance.'],
            ['question' => 'Puis-je gérer mon site moi-même ?', 'answer' => 'Oui. Le site est livré avec une interface d\'administration claire et une courte formation à la prise en main. Vous restez autonome sur vos contenus.'],
        ], $id);
    }

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Création de site internet professionnel | Evolution\'R',
        'description'   => 'Création de site vitrine, e-commerce, refonte : sites clairs, responsive et optimisés SEO. Paiement unique ou abonnement. Devis sous 48h.',
        'focus_keyword' => 'création site internet',
    ]);
}

function evolutionr_seed_lancement_page_seo(): void
{
    $id = evolutionr_seed_get_or_create_page(
        'Consultant SEO',
        'consultant-seo',
        ''
    );
    if (!$id) return;

    if (evolutionr_acf_is_active()) {
        update_field('packs', [
            [
                'label' => 'Audit SEO ponctuel',
                'price' => 'à partir de 590 €',
                'included' => [
                    ['text' => 'Analyse complète du site'],
                    ['text' => 'Points techniques (vitesse, structure, mobile)'],
                    ['text' => 'Analyse des contenus et balises'],
                    ['text' => 'Recommandations prioritaires'],
                ],
                'cta_label' => 'Demander un audit',
                'cta_url' => '/contact/',
            ],
            [
                'label' => 'SEO Starter',
                'price' => '350 €/mois',
                'included' => [
                    ['text' => 'Suivi de visibilité mensuel'],
                    ['text' => 'Optimisation de pages existantes'],
                    ['text' => 'Ajustement des balises'],
                    ['text' => 'Maillage interne simple'],
                    ['text' => 'Reporting synthétique mensuel'],
                ],
                'cta_label' => 'Choisir Starter',
                'cta_url' => '/contact/',
            ],
            [
                'label' => 'SEO Croissance',
                'price' => '690 €/mois',
                'included' => [
                    ['text' => 'Recherche de mots-clés approfondie'],
                    ['text' => 'Optimisation et création de contenus'],
                    ['text' => 'Maillage interne renforcé'],
                    ['text' => 'Suivi concurrentiel léger'],
                    ['text' => 'Reporting et recommandations mensuelles'],
                ],
                'cta_label' => 'Choisir Croissance',
                'cta_url' => '/contact/',
            ],
            [
                'label' => 'SEO Performance',
                'price' => 'à partir de 1 200 €/mois',
                'included' => [
                    ['text' => 'Stratégie SEO complète'],
                    ['text' => 'Plan éditorial avec contenus réguliers'],
                    ['text' => 'Suivi concurrentiel approfondi'],
                    ['text' => 'Optimisation technique'],
                    ['text' => 'Reporting détaillé'],
                ],
                'cta_label' => 'Choisir Performance',
                'cta_url' => '/contact/',
            ],
        ], $id);

        update_field('promesses_limites', [
            ['text' => 'Aucune première position sur Google ne peut être garantie.'],
            ['text' => 'Les résultats dépendent du marché, de la concurrence et de l\'historique du site.'],
            ['text' => 'Le SEO demande du temps : compter plusieurs mois pour des résultats significatifs.'],
            ['text' => 'La régularité et la qualité des contenus comptent beaucoup.'],
            ['text' => 'Aucune technique risquée (black hat) n\'est utilisée — visibilité durable plutôt que pic éphémère.'],
        ], $id);

        update_field('faq', [
            ['question' => 'Combien de temps pour voir des résultats SEO ?', 'answer' => 'Comptez généralement 3 à 6 mois pour les premiers signaux significatifs, et 6 à 12 mois pour une progression consolidée. Le SEO est un travail de fond.'],
            ['question' => 'Peut-on garantir la première place sur Google ?', 'answer' => 'Non, et personne ne le peut honnêtement. Nous nous engageons sur la méthode et le travail, pas sur des positions précises qui dépendent de Google.'],
            ['question' => 'Le SEO est-il inclus dans la création du site ?', 'answer' => 'Un SEO de base est inclus dans toute création (balises, structure, maillage). Pour un accompagnement actif et continu, voir les packs SEO mensuels.'],
            ['question' => 'Faut-il publier régulièrement du contenu ?', 'answer' => 'Pas toujours, mais c\'est souvent un accélérateur. Selon votre marché, nous identifions ensemble si une stratégie éditoriale est pertinente.'],
            ['question' => 'Quelle différence entre audit SEO et accompagnement SEO ?', 'answer' => 'L\'audit est un état des lieux ponctuel avec recommandations. L\'accompagnement met en œuvre ces recommandations dans le temps et suit les résultats.'],
        ], $id);
    }

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Consultant SEO — référencement naturel | Evolution\'R',
        'description'   => 'Consultant SEO pour améliorer la visibilité de votre site sur Google. Audit, optimisation, packs mensuels. Approche honnête et progressive.',
        'focus_keyword' => 'consultant SEO',
    ]);
}

function evolutionr_seed_lancement_page_maintenance(): void
{
    $id = evolutionr_seed_get_or_create_page(
        'Maintenance & hébergement',
        'maintenance-hebergement',
        ''
    );
    if (!$id) return;

    if (evolutionr_acf_is_active()) {
        // Packs & hébergement de cette page : seedés (avec liaison offre_ref) par
        // evolutionr_seed_v2_page_maintenance(), qui s'exécute après et fait autorité.

        update_field('excluded', [
            ['text' => 'Refonte complète du site'],
            ['text' => 'Ajout de fonctionnalités importantes hors forfait'],
            ['text' => 'Rédaction de contenu'],
            ['text' => 'SEO mensuel actif (voir la prestation dédiée)'],
            ['text' => 'Interventions lourdes en dehors du temps inclus'],
            ['text' => 'Résolution de problèmes causés par des modifications externes non validées'],
        ], $id);

        update_field('faq', [
            ['question' => 'Est-ce obligatoire de maintenir un site WordPress ?', 'answer' => 'Techniquement non, mais fortement recommandé. Un site non maintenu finit par se dégrader, devenir vulnérable aux failles, et peut être piraté ou cassé après une mise à jour ratée.'],
            ['question' => 'Que se passe-t-il si mon site tombe en panne ?', 'answer' => 'Nous intervenons en priorité selon votre formule, restaurons une sauvegarde si nécessaire et identifions la cause pour éviter la récidive.'],
            ['question' => 'Les sauvegardes sont-elles incluses ?', 'answer' => 'Oui, dès le pack Sécurité (49 €/mois). Les sauvegardes sont automatiques, régulières, et conservées sur un espace séparé.'],
            ['question' => 'Puis-je prendre uniquement l\'hébergement ?', 'answer' => 'Oui, l\'hébergement et la maintenance sont deux prestations distinctes que vous pouvez prendre séparément ou combiner.'],
            ['question' => 'Puis-je prendre uniquement la maintenance ?', 'answer' => 'Oui également. Vous pouvez garder votre hébergeur actuel et nous confier uniquement le suivi technique de votre site.'],
            ['question' => 'Les modifications de contenu sont-elles incluses ?', 'answer' => 'Le pack Confort inclut 30 min par mois, le Premium 1h30. Au-delà, les modifications sont facturées à la demande ou via une formule plus élevée.'],
        ], $id);
    }

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Maintenance WordPress et hébergement web géré | Evolution\'R',
        'description'   => 'Maintenance WordPress et hébergement web géré : mises à jour, sauvegardes, sécurité, suivi technique. Trois packs adaptés à votre site.',
        'focus_keyword' => 'maintenance WordPress',
    ]);
}

function evolutionr_seed_lancement_page_tarifs(): void
{
    $id = evolutionr_seed_get_or_create_page(
        'Tarifs',
        'tarifs',
        ''
    );
    if (!$id) return;

    // Pas de méta ACF custom à seeder ici : les champs ACF de la page Tarifs
    // ont leurs default_value posées dans la déclaration du groupe.
    // Le configurateur lui-même est géré en JS (cf. capability configurateur-tarifs).

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Tarifs création site, SEO, maintenance et hébergement | Evolution\'R',
        'description'   => 'Configurez votre devis : création de site, SEO, maintenance et hébergement, en paiement unique ou abonnement mensuel. Tarifs transparents.',
        'focus_keyword' => 'tarifs création site internet',
    ]);
}

function evolutionr_seed_lancement_page_contact(): void
{
    $id = evolutionr_seed_get_or_create_page(
        'Contact',
        'contact',
        ''
    );
    if (!$id) return;

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Contact — devis gratuit sous 48h | Evolution\'R',
        'description'   => 'Parlons de votre projet web. Décrivez-nous votre besoin : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.',
        'focus_keyword' => 'contact agence web',
    ]);
}

function evolutionr_seed_lancement_page_mentions_legales(): void
{
    $content = <<<HTML
<h2>Éditeur du site</h2>
<p><strong>Nom commercial :</strong> [À COMPLÉTER : nom commercial / dénomination sociale]</p>
<p><strong>Statut juridique :</strong> [À COMPLÉTER : auto-entrepreneur / EI / SASU / SARL / autre]</p>
<p><strong>Numéro SIRET :</strong> [À COMPLÉTER : numéro SIRET à 14 chiffres]</p>
<p><strong>Adresse :</strong> [À COMPLÉTER : adresse postale du siège]</p>
<p><strong>Email de contact :</strong> [À COMPLÉTER : email professionnel]</p>
<p><strong>Téléphone :</strong> [À COMPLÉTER : numéro professionnel — optionnel]</p>
<p><strong>Directeur de la publication :</strong> [À COMPLÉTER : nom du dirigeant]</p>

<h2>Hébergement</h2>
<p><strong>Hébergeur :</strong> [À COMPLÉTER : nom de l'hébergeur]</p>
<p><strong>Adresse :</strong> [À COMPLÉTER : adresse postale de l'hébergeur]</p>
<p><strong>Téléphone :</strong> [À COMPLÉTER : téléphone de l'hébergeur]</p>

<h2>Propriété intellectuelle</h2>
<p>L'ensemble des contenus présents sur ce site (textes, images, logo, code source, structure) est protégé par le droit d'auteur et reste la propriété exclusive d'Evolution'R, sauf mention contraire. Toute reproduction, représentation, modification ou exploitation, totale ou partielle, sans autorisation écrite préalable, est interdite.</p>

<h2>Données personnelles</h2>
<p>Les données collectées via le formulaire de contact (nom, email, téléphone, message) sont traitées uniquement dans le cadre du traitement de votre demande. Elles ne sont pas transmises à des tiers à des fins commerciales. Pour plus de détails, consultez la <a href="/politique-de-confidentialite/">politique de confidentialité</a>.</p>

<h2>Cookies</h2>
<p>Ce site utilise des cookies à des fins de fonctionnement et de mesure d'audience. Les cookies de mesure d'audience nécessitent votre consentement, recueilli via le bandeau cookies. Vous pouvez à tout moment modifier vos préférences en effaçant les cookies de votre navigateur.</p>

<h2>Loi applicable et juridiction compétente</h2>
<p>Les présentes mentions légales sont soumises au droit français. En cas de litige, les juridictions françaises sont seules compétentes.</p>

<p><em>Dernière mise à jour : 21 mai 2026.</em></p>
HTML;

    $id = evolutionr_seed_get_or_create_page(
        'Mentions légales',
        'mentions-legales',
        $content
    );
    if (!$id) return;

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Mentions légales | Evolution\'R',
        'description'   => 'Mentions légales du site Evolution\'R : éditeur, hébergeur, propriété intellectuelle, données personnelles et droit applicable.',
        'focus_keyword' => 'mentions légales Evolution\'R',
    ]);
}

function evolutionr_seed_lancement_page_confidentialite(): void
{
    $content = <<<HTML
<h2>Responsable du traitement</h2>
<p>Le responsable du traitement des données personnelles est : <strong>[À COMPLÉTER : nom commercial]</strong>, [À COMPLÉTER : statut juridique], SIRET [À COMPLÉTER], situé [À COMPLÉTER : adresse postale]. Pour toute question relative à vos données personnelles, contactez-nous à <strong>[À COMPLÉTER : email RGPD]</strong>.</p>

<h2>Données collectées et finalités</h2>
<p>Nous collectons et traitons les catégories de données suivantes :</p>
<ul>
<li><strong>Données de contact</strong> (nom, email, téléphone) — finalité : répondre à votre demande de devis ou d'information. Base légale : exécution de mesures précontractuelles.</li>
<li><strong>Contenu de votre message</strong> — finalité : comprendre votre besoin. Base légale : intérêt légitime à pouvoir vous proposer un service adapté.</li>
<li><strong>Données de navigation</strong> (cookies de mesure d'audience) — finalité : améliorer le site. Base légale : votre consentement, recueilli via le bandeau cookies.</li>
</ul>

<h2>Destinataires</h2>
<p>Vos données sont destinées uniquement à Evolution'R. Elles peuvent être transmises aux prestataires techniques suivants, soumis à des obligations strictes :</p>
<ul>
<li><strong>Hébergeur du site :</strong> [À COMPLÉTER : nom de l'hébergeur] — stockage des données.</li>
<li><strong>Prestataire d'envoi d'emails</strong> (WP Mail SMTP via [À COMPLÉTER : fournisseur SMTP]) — acheminement de nos emails.</li>
<li><strong>Google Analytics</strong> (si consentement) — mesure d'audience.</li>
</ul>

<h2>Durée de conservation</h2>
<ul>
<li>Données de demande de contact : 3 ans à compter du dernier échange.</li>
<li>Données client (devis, factures) : 10 ans (obligation comptable).</li>
<li>Cookies de mesure d'audience : 13 mois maximum.</li>
</ul>

<h2>Vos droits</h2>
<p>Conformément au RGPD et à la loi Informatique et Libertés, vous disposez des droits suivants :</p>
<ul>
<li><strong>Accès</strong> : obtenir une copie des données vous concernant.</li>
<li><strong>Rectification</strong> : corriger des données inexactes.</li>
<li><strong>Effacement</strong> : demander la suppression de vos données (hors obligations légales).</li>
<li><strong>Limitation</strong> : limiter temporairement le traitement.</li>
<li><strong>Portabilité</strong> : recevoir vos données dans un format structuré.</li>
<li><strong>Opposition</strong> : vous opposer au traitement pour motif légitime.</li>
<li><strong>Retrait du consentement</strong> à tout moment pour les traitements fondés sur le consentement.</li>
</ul>
<p>Pour exercer ces droits, écrivez à <strong>[À COMPLÉTER : email RGPD]</strong>. Une réponse vous sera apportée sous 1 mois maximum.</p>

<h2>Recours auprès de la CNIL</h2>
<p>Si vous estimez que vos droits ne sont pas respectés, vous pouvez introduire une réclamation auprès de la <a href="https://www.cnil.fr/" target="_blank" rel="noopener noreferrer">Commission Nationale de l'Informatique et des Libertés (CNIL)</a>.</p>

<h2>Cookies</h2>
<p>Les cookies utilisés sur ce site sont détaillés dans le bandeau cookies. Vous pouvez à tout moment modifier vos préférences en effaçant les cookies de votre navigateur.</p>

<p><em>Dernière mise à jour : 21 mai 2026.</em></p>
HTML;

    $id = evolutionr_seed_get_or_create_page(
        'Politique de confidentialité',
        'politique-de-confidentialite',
        $content
    );
    if (!$id) return;

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Politique de confidentialité | Evolution\'R',
        'description'   => 'Politique de confidentialité d\'Evolution\'R : données collectées, finalités, durée de conservation, vos droits RGPD et exercice de ces droits.',
        'focus_keyword' => 'politique confidentialité',
    ]);
}

function evolutionr_seed_lancement_page_cgv(): void
{
    $content = <<<HTML
<h2>1. Identification du prestataire</h2>
<p>Les présentes conditions générales de vente sont conclues entre :</p>
<p><strong>Evolution'R</strong>, [À COMPLÉTER : statut juridique], SIRET [À COMPLÉTER], dont le siège est situé [À COMPLÉTER : adresse], ci-après dénommé « le Prestataire »,</p>
<p>et toute personne physique ou morale souscrivant à l'une des prestations proposées sur ce site, ci-après dénommée « le Client ».</p>

<h2>2. Objet</h2>
<p>Les présentes CGV ont pour objet de définir les conditions dans lesquelles le Prestataire fournit ses services au Client, notamment la création de sites web, le référencement naturel (SEO), la maintenance WordPress et l'hébergement web géré.</p>

<h2>3. Modalités de souscription</h2>
<p>Toute commande est précédée d'un devis personnalisé établi sur la base des besoins exprimés par le Client. La signature du devis (manuscrite ou électronique) et le paiement de l'acompte valent acceptation des présentes CGV.</p>

<h2>4. Tarifs et facturation</h2>
<p>Les tarifs sont indiqués en euros, hors taxes ou toutes taxes comprises selon le statut fiscal du Prestataire (mentionné sur le devis). Les tarifs « à partir de » affichés sur le site servent de base d'estimation ; un tarif définitif est précisé dans le devis personnalisé.</p>
<p>Pour les prestations en paiement unique : un acompte de 30 à 50 % est demandé à la commande, le solde à la livraison ou selon échéancier convenu.</p>
<p>Pour les prestations en abonnement mensuel : des frais de mise en service sont facturés au démarrage, puis la mensualité est prélevée chaque mois sur la durée d'engagement.</p>

<h2>5. Abonnement mensuel — durée et résiliation</h2>
<p>Les formules d'abonnement (création de site par abonnement, maintenance, hébergement, SEO mensuel) sont soumises à une durée d'engagement minimum précisée dans le devis (généralement 24 ou 36 mois selon la formule).</p>
<p><strong>Résiliation en fin de période d'engagement :</strong> le Client peut résilier avec un préavis d'un mois avant la fin de la période d'engagement, par courrier ou email.</p>
<p><strong>Résiliation anticipée :</strong> la résiliation avant la fin de la période d'engagement reste possible, mais le solde des mensualités restantes jusqu'à la fin de l'engagement reste dû, sauf cas de force majeure.</p>
<p><strong>Tacite reconduction :</strong> à l'issue de la période d'engagement initiale, le contrat est reconduit tacitement par périodes mensuelles, résiliables avec un préavis d'un mois.</p>

<h2>6. Délai de rétractation</h2>
<p>Conformément à l'article L221-5 du Code de la consommation, le Client consommateur dispose d'un délai de 14 jours à compter de la signature du devis pour exercer son droit de rétractation, sauf si l'exécution de la prestation a commencé avec son accord exprès.</p>
<p>Pour les clients professionnels (B2B), le droit de rétractation ne s'applique pas.</p>

<h2>7. Modalités de paiement</h2>
<p>Les paiements peuvent être effectués par virement bancaire ou prélèvement automatique (pour les abonnements). Tout retard de paiement entraîne, après mise en demeure restée infructueuse, l'application de pénalités au taux légal en vigueur.</p>

<h2>8. Obligations du Prestataire</h2>
<p>Le Prestataire s'engage à fournir les services convenus dans les délais indiqués, avec le sérieux et la qualité attendus de sa profession. En cas de retard imputable au Prestataire, un avoir ou une remise pourra être accordé, sans préjudice de la résiliation possible du contrat.</p>

<h2>9. Obligations du Client</h2>
<p>Le Client s'engage à :</p>
<ul>
<li>fournir les contenus, accès et informations nécessaires à la réalisation de la prestation dans les délais convenus ;</li>
<li>valider les livrables aux étapes prévues du projet ;</li>
<li>régler les sommes dues aux échéances convenues ;</li>
<li>ne pas modifier le site sans concertation pendant les périodes de maintenance.</li>
</ul>

<h2>10. Propriété intellectuelle</h2>
<p>La propriété intellectuelle du site livré est transférée au Client à l'issue du paiement complet de la prestation. Les éléments tiers (extensions, polices, images sous licence) restent soumis à leurs licences respectives.</p>

<h2>11. Données personnelles</h2>
<p>Le traitement des données personnelles est régi par la <a href="/politique-de-confidentialite/">politique de confidentialité</a>.</p>

<h2>12. Force majeure</h2>
<p>Aucune des parties ne pourra être tenue pour responsable d'un manquement à ses obligations résultant d'un cas de force majeure tel que défini par la jurisprudence française.</p>

<h2>13. Médiation et juridiction compétente</h2>
<p>En cas de litige, les parties s'efforceront de trouver une solution amiable. Conformément aux articles L611-1 et suivants du Code de la consommation, le client consommateur peut recourir à un médiateur de la consommation. À défaut d'accord amiable, les juridictions françaises sont seules compétentes.</p>

<p><em>Dernière mise à jour : 21 mai 2026.</em></p>
HTML;

    $id = evolutionr_seed_get_or_create_page(
        'Conditions générales de vente',
        'cgv',
        $content
    );
    if (!$id) return;

    evolutionr_seed_rank_math_meta($id, [
        'title'         => 'Conditions générales de vente (CGV) | Evolution\'R',
        'description'   => 'CGV Evolution\'R : prestations, tarifs, abonnement mensuel, durée d\'engagement, résiliation, rétractation, propriété intellectuelle.',
        'focus_keyword' => 'CGV agence web',
    ]);
}

/* ─────────────────────────────────────────────────────────────────────
 *  Seeder des menus de navigation (Phase 2bis du lancement-site).
 *
 *  Crée et peuple 4 menus, un par emplacement déclaré dans theme-support :
 *    - main               → 5 entrées (pages publiques principales)
 *    - footer_prestations → 3 entrées (services)
 *    - footer_ressources  → 2 entrées (Tarifs, Contact)
 *    - footer_legal       → 3 entrées (Mentions, Confidentialité, CGV)
 *
 *  Idempotent : vide les items existants des menus du même nom avant
 *  re-remplissage, puis assigne aux emplacements via theme_mod.
 *
 *  Guard : option `evolutionr_lancement_menus_seeded`. Pour relancer :
 *  wp option delete evolutionr_lancement_menus_seeded;
 *  wp eval 'evolutionr_seed_lancement_menus();'.
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_lancement_menus(): void
{
    $slugs_to_titles = [
        'creation-site-internet'        => 'Création de site web',
        'consultant-seo'                => 'Consultant SEO',
        'maintenance-hebergement'       => 'Maintenance & hébergement',
        'tarifs'                        => 'Tarifs',
        'contact'                       => 'Contact',
        'mentions-legales'              => 'Mentions légales',
        'politique-de-confidentialite'  => 'Politique de confidentialité',
        'cgv'                           => 'CGV',
    ];

    // Résoudre les slugs vers les IDs réels
    $page_ids = [];
    foreach ($slugs_to_titles as $slug => $title) {
        $pid = evolutionr_seed_get_page_id($slug);
        if ($pid !== null) {
            $page_ids[$slug] = $pid;
        }
    }

    $menus_config = [
        'main' => [
            'name'  => 'Menu Principal',
            'slugs' => ['creation-site-internet', 'consultant-seo', 'maintenance-hebergement', 'tarifs', 'contact'],
        ],
        'footer_prestations' => [
            'name'  => 'Footer Prestations',
            'slugs' => ['creation-site-internet', 'consultant-seo', 'maintenance-hebergement'],
        ],
        'footer_ressources' => [
            'name'  => 'Footer Ressources',
            'slugs' => ['tarifs', 'contact'],
        ],
        'footer_legal' => [
            'name'  => 'Footer Liens légaux',
            'slugs' => ['mentions-legales', 'politique-de-confidentialite', 'cgv'],
        ],
    ];

    $locations = (array) get_theme_mod('nav_menu_locations', []);

    foreach ($menus_config as $location => $config) {
        // Récupérer le menu par son nom, ou le créer
        $menu_obj = wp_get_nav_menu_object($config['name']);
        if (!$menu_obj) {
            $menu_id = wp_create_nav_menu($config['name']);
            if (is_wp_error($menu_id) || !$menu_id) {
                error_log('[evolutionr seeder menus] échec création menu : ' . $config['name']);
                continue;
            }
            $menu_obj = wp_get_nav_menu_object($menu_id);
        }

        $menu_id = (int) $menu_obj->term_id;

        // Vider les items existants pour réécrire propre (idempotence)
        $existing_items = wp_get_nav_menu_items($menu_id);
        if (is_array($existing_items)) {
            foreach ($existing_items as $item) {
                wp_delete_post((int) $item->ID, true);
            }
        }

        // Ajouter les items dans l'ordre du tableau de configuration
        foreach ($config['slugs'] as $slug) {
            if (!isset($page_ids[$slug])) {
                continue;
            }

            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-object-id' => $page_ids[$slug],
                'menu-item-object'    => 'page',
                'menu-item-type'      => 'post_type',
                'menu-item-status'    => 'publish',
            ]);
        }

        // Assigner ce menu à l'emplacement correspondant
        $locations[$location] = $menu_id;
    }

    set_theme_mod('nav_menu_locations', $locations);

    update_option('evolutionr_lancement_menus_seeded', true);
}

/* ─────────────────────────────────────────────────────────────────────
 *  Seeder Phase 3 — Extensions home v2 (SITE.MD §3 : 10 sections).
 *
 *  Peuple les nouveaux champs ACF de la home (front-page, ID via
 *  page_on_front) :
 *    - services_cards (repeater) : 4 cartes Création / SEO / Maintenance /
 *      Hébergement, pointant vers les pages publiques creees en Phase 2.
 *    - paiement_*    : section paiement unique vs abonnement.
 *    - apercu_tarifs_* : 3 a 5 tarifs « a partir de » + CTA /tarifs/.
 *
 *  Garde par l'option evolutionr_lancement_home_v2_seeded. One-shot.
 *  Pour relancer : wp option delete evolutionr_lancement_home_v2_seeded;
 *  wp eval 'evolutionr_seed_lancement_home_extensions();'.
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_lancement_home_extensions(): void
{
    $front_id = (int) get_option('page_on_front');
    if (!$front_id || !evolutionr_acf_is_active()) {
        return;
    }

    // ─── Section Prestations (cartes pointant vers les nouvelles pages publiques)
    update_field('services_cards', [
        [
            'number'    => '01 — CRÉATION',
            'icon'      => 'code',
            'title'     => 'Création de site web',
            'excerpt'   => 'Sites vitrines clairs, responsive et bien structurés, pensés pour vos visiteurs et conçus pour être trouvés par Google.',
            'bullets'   => [
                ['text' => 'Site vitrine, one-page, refonte ou e-commerce'],
                ['text' => 'Design responsive et accessible'],
                ['text' => 'SEO de base intégré dès la conception'],
            ],
            'cta_label' => 'Découvrir la création',
            'cta_url'   => '/prestations/creation-site-internet/',
        ],
        [
            'number'    => '02 — RÉFÉRENCEMENT',
            'icon'      => 'search',
            'title'     => 'Consultant SEO',
            'excerpt'   => 'Audit, optimisation, accompagnement mensuel pour gagner durablement en visibilité sur Google.',
            'bullets'   => [
                ['text' => 'Audit SEO ponctuel ou accompagnement mensuel'],
                ['text' => 'Optimisation balises, structure, maillage interne'],
                ['text' => 'Approche progressive et honnête (pas de promesse magique)'],
            ],
            'cta_label' => "Voir l'offre SEO",
            'cta_url'   => '/prestations/consultant-seo/',
        ],
        [
            'number'    => '03 — SUIVI',
            'icon'      => 'shield',
            'title'     => 'Maintenance & hébergement',
            'excerpt'   => 'Mises à jour, sauvegardes, sécurité et hébergement web géré. Un interlocuteur unique pour la vie technique du site.',
            'bullets'   => [
                ['text' => 'Mises à jour WordPress et extensions régulières'],
                ['text' => 'Sauvegardes automatiques + restauration'],
                ['text' => 'Hébergement web géré inclus en option'],
            ],
            'cta_label' => 'Voir la maintenance',
            'cta_url'   => '/prestations/maintenance-hebergement/',
        ],
        [
            'number'    => '04 — TARIFS',
            'icon'      => 'chart',
            'title'     => 'Configurer votre devis',
            'excerpt'   => 'Configurez votre projet en quelques clics : type de site, mode de paiement, options. Devis transparent affiché en direct.',
            'bullets'   => [
                ['text' => 'Paiement unique ou abonnement mensuel'],
                ['text' => 'Options : SEO, maintenance, hébergement'],
                ['text' => 'Tarifs « à partir de » clairs et sans surprise'],
            ],
            'cta_label' => 'Voir les tarifs',
            'cta_url'   => '/tarifs/',
        ],
    ], $front_id);

    // ─── Section Paiement modes
    update_field('paiement_eyebrow', 'Modèles de paiement', $front_id);
    update_field('paiement_title', 'Paiement unique ou abonnement mensuel', $front_id);
    update_field('paiement_lede', 'Choisissez le mode qui correspond à votre budget : un investissement initial avec une livraison définitive, ou des mensualités allégées avec création, hébergement et maintenance inclus.', $front_id);
    update_field('paiement_modes', [
        [
            'label'     => 'Paiement unique',
            'argument'  => 'Vous financez la création de votre site en une fois et restez propriétaire à la livraison.',
            'bullets'   => [
                ['text' => 'Idéal pour un budget initial préparé'],
                ['text' => 'Propriété intellectuelle transférée au paiement complet'],
                ['text' => 'Hébergement et maintenance optionnels en mensuel'],
                ['text' => 'Délai de livraison court (1 à 6 semaines selon projet)'],
            ],
            'cta_label' => 'Voir les tarifs one-shot',
            'cta_url'   => '/tarifs/',
        ],
        [
            'label'     => 'Abonnement mensuel',
            'argument'  => 'Démarrez votre site avec un budget initial réduit, et payez sur la durée. Création, hébergement et maintenance compris.',
            'bullets'   => [
                ['text' => 'Frais de mise en service réduits (290 à 990 €)'],
                ['text' => 'Mensualité fixe sur 24 ou 36 mois'],
                ['text' => 'Hébergement + maintenance + sauvegardes inclus'],
                ['text' => 'Engagement clair, conditions de résiliation transparentes'],
            ],
            'cta_label' => 'Voir les tarifs abonnement',
            'cta_url'   => '/tarifs/',
        ],
    ], $front_id);

    // ─── Section Aperçu tarifs
    update_field('apercu_tarifs_eyebrow', 'Tarifs transparents', $front_id);
    update_field('apercu_tarifs_title', 'Quelques tarifs d\'entrée pour vous repérer', $front_id);
    update_field('apercu_tarifs_lede', 'Prix « à partir de » selon le type de projet. Un devis personnalisé est proposé après échange.', $front_id);
    // `offre_ref` (catégorie|nom|facturation) relie chaque carte à une offre du
    // modèle central : le prix est lu en direct (cf. section 07), jamais saisi ici.
    // `afficher` permet de masquer une carte sans la supprimer.
    update_field('apercu_tarifs_items', [
        [
            'label'     => 'Site One Page',
            'offre_ref' => 'creation|Site One Page|paiement_unique',
            'desc'      => 'Une page complète pour une activité simple, livrée en 1 à 2 semaines.',
            'afficher'  => 1,
        ],
        [
            'label'     => 'Site vitrine',
            'offre_ref' => 'creation|Site vitrine|paiement_unique',
            'desc'      => 'Jusqu\'à 5 pages structurées, livré en 2 à 4 semaines.',
            'afficher'  => 1,
        ],
        [
            'label'     => 'Site e-commerce',
            'offre_ref' => 'creation|Petit e-commerce|paiement_unique',
            'desc'      => 'Boutique simple : catalogue, paiement, livraison configurés.',
            'afficher'  => 1,
        ],
        [
            'label'     => 'Abonnement vitrine',
            'offre_ref' => 'creation|Site vitrine|abonnement',
            'desc'      => 'Mise en service réduite, mensualité fixe sur 24 mois. Hébergement et maintenance inclus.',
            'afficher'  => 1,
        ],
        [
            'label'     => 'SEO mensuel',
            'offre_ref' => 'seo|SEO Starter|abonnement',
            'desc'      => 'Suivi régulier, optimisation des pages, recommandations mensuelles.',
            'afficher'  => 1,
        ],
        [
            'label'     => 'Maintenance',
            'offre_ref' => 'maintenance_hebergee|Pack Essentiel|abonnement',
            'desc'      => 'Mises à jour, sauvegardes, surveillance et restauration en cas de souci.',
            'afficher'  => 1,
        ],
    ], $front_id);
    update_field('apercu_tarifs_cta_label', 'Configurer mon devis', $front_id);
    update_field('apercu_tarifs_cta_url', '/tarifs/', $front_id);
}

/* ─────────────────────────────────────────────────────────────────────
 *  Seeder Phase 5 ter — Extensions des pages prestations.
 *
 *  Peuple les nouveaux champs ACF ajoutes lors de la refonte editable
 *  des pages Creation, SEO, Maintenance (mini-stats, prix par formule,
 *  toggles featured, mid-cta, headers sections, CTAs finals).
 *
 *  Idempotent via l'option-guard `evolutionr_lancement_pages_v2_seeded`.
 *  Relancable via wp option delete evolutionr_lancement_pages_v2_seeded;
 *  wp eval 'evolutionr_seed_lancement_pages_v2_extensions();'.
 *
 *  Note : peuple uniquement les nouveaux champs. Les champs deja seedes
 *  en v1 (hero_title, hero_sub, etc.) ne sont pas touches.
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_lancement_pages_v2_extensions(): void
{
    if (!evolutionr_acf_is_active()) {
        return;
    }

    evolutionr_seed_v2_page_creation();
    evolutionr_seed_v2_page_seo();
    evolutionr_seed_v2_page_maintenance();
}

function evolutionr_seed_v2_page_creation(): void
{
    $id = evolutionr_seed_get_page_id('creation-site-internet');
    if (!$id) return;

    // Hero stats
    update_field('hero_stats', [
        ['label' => 'À partir de', 'value' => '1 190 €'],
        ['label' => 'Formules', 'value' => '5'],
        ['label' => 'Délai', 'value' => '1–8 sem.'],
    ], $id);

    // Re-écrire le repeater `types` avec les nouveaux sub-fields (num, price, featured, cta)
    update_field('types', [
        [
            'num' => '01', 'label' => 'Site One Page', 'offre_ref' => 'creation|Site One Page|paiement_unique',
            'desc' => 'Pour les activités simples qui ont besoin d\'une présence professionnelle rapide, en une seule page complète et soignée.',
            'included' => [
                ['text' => 'Une page complète et structurée'],
                ['text' => '5 à 7 sections (présentation, services, contact)'],
                ['text' => 'Design responsive et lisible'],
                ['text' => 'Formulaire de contact'],
                ['text' => 'SEO de base'],
            ],
            'featured' => false, 'featured_label' => 'Le plus demandé',
            'cta_label' => 'Demander un devis', 'cta_url' => '/contact/?service=one_page',
        ],
        [
            'num' => '02', 'label' => 'Site vitrine', 'offre_ref' => 'creation|Site vitrine|paiement_unique',
            'desc' => 'Pour présenter une entreprise avec plusieurs pages structurées et un message clair par audience.',
            'included' => [
                ['text' => 'Accueil + pages services + à propos + contact'],
                ['text' => 'Pages complémentaires selon besoin'],
                ['text' => 'Design responsive et accessible'],
                ['text' => 'Optimisation SEO de base'],
            ],
            'featured' => false, 'featured_label' => 'Le plus demandé',
            'cta_label' => 'Demander un devis', 'cta_url' => '/contact/?service=vitrine',
        ],
        [
            'num' => '03', 'label' => 'Site vitrine avancé', 'offre_ref' => 'creation|Site vitrine avancé|paiement_unique',
            'desc' => 'Pour les entreprises qui veulent un site plus structuré, avec plus de pages et une meilleure base SEO.',
            'included' => [
                ['text' => '6 à 10 pages organisées'],
                ['text' => 'Arborescence personnalisée'],
                ['text' => 'Maillage interne soigné'],
                ['text' => 'SEO renforcé dès la conception'],
                ['text' => 'Accompagnement sur la structure des contenus'],
            ],
            'featured' => true, 'featured_label' => 'Le plus demandé',
            'cta_label' => 'Demander un devis', 'cta_url' => '/contact/?service=vitrine_plus',
        ],
        [
            'num' => '04', 'label' => 'Refonte de site', 'offre_ref' => 'creation|Refonte de site|paiement_unique',
            'desc' => 'Pour moderniser un site existant : design, structure, référencement et confort d\'utilisation.',
            'included' => [
                ['text' => 'Audit complet de l\'existant'],
                ['text' => 'Restructuration des contenus'],
                ['text' => 'Amélioration du design et du responsive'],
                ['text' => 'Optimisation SEO de base'],
            ],
            'featured' => false, 'featured_label' => 'Le plus demandé',
            'cta_label' => 'Demander un devis', 'cta_url' => '/contact/?service=refonte',
        ],
        [
            'num' => '05', 'label' => 'Site e-commerce', 'offre_ref' => 'creation|Petit e-commerce|paiement_unique',
            'desc' => 'Pour vendre des produits ou services en ligne, avec une boutique claire et adaptée à votre catalogue.',
            'included' => [
                ['text' => 'Catalogue produits structuré'],
                ['text' => 'Panier et paiement en ligne'],
                ['text' => 'Configuration des livraisons'],
                ['text' => 'Pages légales obligatoires'],
                ['text' => 'Formation à la prise en main'],
            ],
            'featured' => false, 'featured_label' => 'Le plus demandé',
            'cta_label' => 'Demander un devis', 'cta_url' => '/contact/?service=ecommerce',
        ],
    ], $id);

    // Mid-CTA
    update_field('midcta_enabled', true, $id);
    update_field('midcta_strong', 'Pas sûr de la formule à choisir ?', $id);
    update_field('midcta_sub', 'On échange en amont pour vous orienter — sans engagement.', $id);
    update_field('midcta_label', 'Configurer mon devis', $id);
    update_field('midcta_url', '/tarifs/', $id);

    // Périmètre — headers
    update_field('inex_eyebrow', 'Périmètre', $id);
    update_field('inex_title', 'Ce qui est inclus, ce qui ne l\'est pas.', $id);
    update_field('inex_lede', 'Pas de surprise au moment du devis. Tout ce qui est en option figure en clair sur le bon de commande.', $id);
    update_field('included_title', 'Ce qui est inclus', $id);
    update_field('included_sub', 'Dans toutes les formules, par défaut.', $id);
    update_field('excluded_title', 'Non inclus par défaut', $id);
    update_field('excluded_sub', 'Disponible en option ou via une prestation séparée.', $id);

    // FAQ
    update_field('faq_eyebrow', 'FAQ', $id);

    // CTA final
    update_field('cta_enabled', true, $id);
    update_field('cta_title', 'Prêt à lancer votre projet ?', $id);
    update_field('cta_paragraph', 'Décrivez-nous votre besoin : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.', $id);
    update_field('cta_label', 'Demander un devis gratuit', $id);
    update_field('cta_url', '/contact/', $id);
}

function evolutionr_seed_v2_page_seo(): void
{
    $id = evolutionr_seed_get_page_id('consultant-seo');
    if (!$id) return;

    // Hero stats
    update_field('hero_stats', [
        ['label' => 'À partir de', 'value' => '350 €/mois'],
        ['label' => 'Packs', 'value' => '3 + audit'],
        ['label' => 'Démarrage', 'value' => '1–2 sem.'],
    ], $id);

    // Hero sub
    update_field('hero_sub', "Audit SEO, optimisation on-page et accompagnement régulier pour que votre site remonte durablement sur les requêtes de votre métier. Pas de promesses magiques : un travail progressif, mesuré, transparent.", $id);

    // Packs SEO — re-écrire avec featured + num
    update_field('packs_eyebrow', 'Quatre formules SEO', $id);
    update_field('packs_title', 'Un pack adapté à chaque étape de votre stratégie.', $id);
    update_field('packs_lede', 'De l\'audit ponctuel à la stratégie SEO complète. Tous les packs sont mensuels et résiliables.', $id);
    update_field('packs', [
        [
            'num' => '01', 'label' => 'Audit SEO ponctuel', 'offre_ref' => 'seo|Audit SEO ponctuel|paiement_unique',
            'desc' => '', 'featured' => false, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Analyse complète du site'],
                ['text' => 'Points techniques (vitesse, structure, mobile)'],
                ['text' => 'Analyse contenus et balises'],
                ['text' => 'Recommandations priorisées'],
            ],
            'cta_label' => 'Demander un audit', 'cta_url' => '/contact/?service=seo&mode=one_shot',
        ],
        [
            'num' => '02', 'label' => 'SEO Starter', 'offre_ref' => 'seo|SEO Starter|abonnement',
            'desc' => '', 'featured' => true, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Suivi de visibilité mensuel'],
                ['text' => 'Optimisation de pages existantes'],
                ['text' => 'Ajustement des balises'],
                ['text' => 'Maillage interne simple'],
                ['text' => 'Reporting synthétique'],
            ],
            'cta_label' => 'Choisir Starter', 'cta_url' => '/contact/?service=seo&pack=starter',
        ],
        [
            'num' => '03', 'label' => 'SEO Croissance', 'offre_ref' => 'seo|SEO Croissance|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Recherche de mots-clés approfondie'],
                ['text' => 'Optimisation et création de contenus'],
                ['text' => 'Maillage interne renforcé'],
                ['text' => 'Suivi concurrentiel léger'],
                ['text' => 'Reporting mensuel détaillé'],
            ],
            'cta_label' => 'Choisir Croissance', 'cta_url' => '/contact/?service=seo&pack=croissance',
        ],
        [
            'num' => '04', 'label' => 'SEO Performance', 'offre_ref' => 'seo|SEO Performance|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Stratégie SEO complète'],
                ['text' => 'Plan éditorial mensuel'],
                ['text' => 'Suivi concurrentiel approfondi'],
                ['text' => 'Optimisation technique'],
                ['text' => 'Reporting détaillé'],
            ],
            'cta_label' => 'Choisir Performance', 'cta_url' => '/contact/?service=seo&pack=performance',
        ],
    ], $id);

    // Mid-CTA
    update_field('midcta_enabled', true, $id);
    update_field('midcta_strong', 'Pas sûr du pack à choisir ?', $id);
    update_field('midcta_sub', 'Un audit ponctuel à 590 € vous permet de poser un diagnostic avant de vous engager.', $id);
    update_field('midcta_label', 'Demander un audit', $id);
    update_field('midcta_url', '/contact/?service=seo', $id);

    // Engagements & limites
    update_field('promesses_enabled', true, $id);
    update_field('promesses_eyebrow', 'Honnêteté SEO', $id);
    update_field('promesses_title', 'Nos engagements et nos limites', $id);
    update_field('promesses_lede', 'Le SEO repose sur un travail progressif. Pour rester clairs et honnêtes, voici ce sur quoi nous nous engageons et ce que nous ne promettons pas.', $id);
    update_field('engagements_title', 'Ce sur quoi nous nous engageons', $id);
    update_field('engagements_sub', 'La méthode, le sérieux, la transparence.', $id);
    update_field('engagements_list', [
        ['text' => 'Diagnostic technique et sémantique honnête'],
        ['text' => 'Optimisations conformes aux guidelines Google'],
        ['text' => 'Reporting clair, sans jargon, livré à date'],
        ['text' => 'Recommandations priorisées sur le retour attendu'],
    ], $id);
    update_field('limites_title', 'Ce que nous ne promettons pas', $id);
    update_field('limites_sub', 'Le SEO repose sur un travail progressif, pas sur la magie.', $id);
    // Le repeater `promesses_limites` existe déjà avec des données : on le laisse tel quel
    // sauf s'il est vide → on remet les valeurs par défaut
    if (!have_rows('promesses_limites')) {
        update_field('promesses_limites', [
            ['text' => 'Aucune première position sur Google ne peut être garantie.'],
            ['text' => 'Les résultats dépendent du marché, de la concurrence et de l\'historique du site.'],
            ['text' => 'Le SEO demande du temps : compter plusieurs mois pour des résultats significatifs.'],
            ['text' => 'La régularité et la qualité des contenus comptent beaucoup.'],
            ['text' => 'Aucune technique risquée (black hat) n\'est utilisée.'],
        ], $id);
    }

    // FAQ
    update_field('faq_eyebrow', 'FAQ', $id);

    // CTA final
    update_field('cta_enabled', true, $id);
    update_field('cta_title', 'Améliorons votre visibilité ensemble', $id);
    update_field('cta_paragraph', 'Audit SEO ponctuel ou accompagnement mensuel : décrivez-nous votre site et vos objectifs, nous répondons sous 48 heures.', $id);
    update_field('cta_label', 'Demander un audit SEO', $id);
    update_field('cta_url', '/contact/', $id);
}

function evolutionr_seed_v2_page_maintenance(): void
{
    $id = evolutionr_seed_get_page_id('maintenance-hebergement');
    if (!$id) return;

    // Hero stats
    update_field('hero_stats', [
        ['label' => 'À partir de', 'value' => '49 €/mois'],
        ['label' => 'Packs', 'value' => '3 + 2'],
        ['label' => 'Prise en charge', 'value' => '< 48h'],
    ], $id);

    // Hero sub
    update_field('hero_sub', "Mises à jour, sauvegardes, sécurité, hébergement : un interlocuteur unique pour la vie technique de votre site. Vous gardez la maîtrise de votre activité, sans plus jamais vous demander si tout fonctionne.", $id);

    // Packs maintenance
    update_field('packs_enabled', true, $id);
    update_field('packs_eyebrow', 'Pack Maintenance + Hébergement', $id);
    update_field('packs_title', 'Votre site hébergé et maintenu, sans rien à gérer.', $id);
    update_field('packs_lede', 'Hébergement (serveur de base inclus) + maintenance sur nos serveurs : environnement maîtrisé, donc engagements pleins. Mensuel et résiliable.', $id);
    update_field('packs', [
        [
            'num' => '01', 'label' => 'Pack Essentiel', 'offre_ref' => 'maintenance_hebergee|Pack Essentiel|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Mises à jour WordPress et extensions'],
                ['text' => 'Sauvegardes régulières'],
                ['text' => 'Surveillance de base'],
                ['text' => 'Restauration en cas de souci'],
            ],
            'cta_label' => 'Choisir Sécurité', 'cta_url' => '/contact/?service=maintenance&pack=securite',
        ],
        [
            'num' => '02', 'label' => 'Pack Confort', 'offre_ref' => 'maintenance_hebergee|Pack Confort|abonnement',
            'desc' => '', 'featured' => true, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Tout le pack Sécurité'],
                ['text' => '30 minutes de modifications par mois'],
                ['text' => 'Corrections au fil de l\'eau'],
                ['text' => 'Assistance prioritaire raisonnable'],
            ],
            'cta_label' => 'Choisir Confort', 'cta_url' => '/contact/?service=maintenance&pack=confort',
        ],
        [
            'num' => '03', 'label' => 'Pack Premium', 'offre_ref' => 'maintenance_hebergee|Pack Premium|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Tout le pack Confort'],
                ['text' => 'Jusqu\'à 1h30 de modifications/mois'],
                ['text' => 'Suivi technique renforcé'],
                ['text' => 'Optimisation continue'],
                ['text' => 'Support prioritaire'],
            ],
            'cta_label' => 'Choisir Premium', 'cta_url' => '/contact/?service=maintenance&pack=premium',
        ],
    ], $id);

    // Hébergement
    update_field('hosting_enabled', true, $id);
    update_field('hosting_eyebrow', 'Maintenance seule', $id);
    update_field('hosting_title', 'Vous avez déjà votre propre serveur ?', $id);
    update_field('hosting_lede', 'Nous maintenons votre site là où il est hébergé. Environnement non maîtrisé : engagements plus prudents, et éligibilité à valider selon votre infrastructure.', $id);
    update_field('hosting_offers', [
        [
            'num' => '01', 'label' => 'Pack Externe Essentiel', 'offre_ref' => 'maintenance_seule|Pack Externe Essentiel|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'Recommandé',
            'included' => [
                ['text' => 'Hébergement web géré'],
                ['text' => 'Certificat SSL inclus'],
                ['text' => 'Sauvegardes automatiques'],
                ['text' => 'Suivi basique'],
                ['text' => 'Assistance accès'],
            ],
            'cta_label' => 'Choisir Essentiel', 'cta_url' => '/contact/?service=hebergement&offre=essentiel',
        ],
        [
            'num' => '02', 'label' => 'Pack Externe Confort', 'offre_ref' => 'maintenance_seule|Pack Externe Confort|abonnement',
            'desc' => '', 'featured' => true, 'featured_label' => 'Le plus choisi',
            'included' => [
                ['text' => 'Hébergement web géré'],
                ['text' => 'Certificat SSL inclus'],
                ['text' => 'Sauvegardes renforcées'],
                ['text' => 'Surveillance complète'],
                ['text' => 'Assistance prioritaire'],
            ],
            'cta_label' => 'Choisir Confort', 'cta_url' => '/contact/?service=hebergement&offre=confort',
        ],
        [
            'num' => '03', 'label' => 'Pack Externe Premium', 'offre_ref' => 'maintenance_seule|Pack Externe Premium|abonnement',
            'desc' => '', 'featured' => false, 'featured_label' => 'E-commerce',
            'included' => [
                ['text' => 'Hébergement plus robuste'],
                ['text' => 'Sauvegardes renforcées'],
                ['text' => 'Surveillance complète'],
                ['text' => 'Restauration prioritaire'],
                ['text' => 'Adapté e-commerce léger'],
            ],
            'cta_label' => 'Choisir Premium', 'cta_url' => '/contact/?service=hebergement&offre=premium',
        ],
    ], $id);

    // Mid-CTA
    update_field('midcta_enabled', true, $id);
    update_field('midcta_strong', 'Pack tout-en-un possible', $id);
    update_field('midcta_sub', 'Maintenance et hébergement combinés dans une seule formule mensuelle.', $id);
    update_field('midcta_label', 'Configurer mon devis', $id);
    update_field('midcta_url', '/tarifs/', $id);

    // Distinction
    update_field('distinction_enabled', true, $id);
    update_field('distinction_eyebrow', 'Réversibilité & conditions', $id);
    update_field('distinction_title', 'Pourquoi la maintenance seule peut coûter plus.', $id);
    update_field('distinction_text', 'Sur nos serveurs, l\'environnement est maîtrisé : le Pack Maintenance + Hébergement est souvent plus avantageux que la maintenance seule sur un serveur tiers, où le travail est moins prévisible (éligibilité à valider au cas par cas). Et vous restez libre : si vous partez un jour, nous assurons la migration sortante de votre site, facturée selon la complexité.', $id);

    // Non inclus
    update_field('excluded_enabled', true, $id);
    update_field('excluded_eyebrow', 'Périmètre', $id);
    update_field('excluded_title', 'Ce qui n\'est pas inclus par défaut', $id);
    update_field('excluded_lede', 'Disponible en option ou via une prestation séparée. Devis sur demande.', $id);
    update_field('excluded_col_title', 'Hors forfait standard', $id);
    update_field('excluded_col_sub', 'Souvent traités via un devis ponctuel ou un changement de formule.', $id);

    // FAQ
    update_field('faq_eyebrow', 'FAQ', $id);

    // CTA final
    update_field('cta_enabled', true, $id);
    update_field('cta_title', 'Prendre soin de votre site, longtemps', $id);
    update_field('cta_paragraph', 'Maintenance et hébergement gérés par un interlocuteur unique. Réponse sous 48 heures, sans engagement.', $id);
    update_field('cta_label', 'Demander une prise en charge', $id);
    update_field('cta_url', '/contact/', $id);
}

/* ────────────────────────────────────────────────────────────────────
 *  Seed du modèle de prix central (page d'options « Tarifs »).
 *  Reprend fidèlement l'inventaire de l'ancien `pricingData` + SITE.MD.
 *  Garde : option `evolutionr_tarifs_seeded`. Pour relancer :
 *  wp option delete evolutionr_tarifs_seeded; wp eval 'evolutionr_seed_tarifs();'
 *  Les noms des offres `creation` matchent les libellés de formules de la
 *  page Création (appariement du double-ancrage, décision D6).
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_tarifs(): void
{
    if (!function_exists('evolutionr_acf_is_active') || !evolutionr_acf_is_active()) {
        return;
    }

    /** Construit une ligne d'offre avec valeurs par défaut. */
    $offre = static function (array $o): array {
        return array_merge([
            'categorie'        => 'creation',
            'nom'              => '',
            'facturation'      => 'paiement_unique',
            'prix'             => 0,
            'frais_setup'      => 0,
            'engagement'       => '',
            'prefixe_a_partir' => 1,
            'delai'            => '',
            'inclus'           => [],
            'exclus'           => [],
            'mis_en_avant'     => 0,
            'libelle_badge'    => '',
            'actif'            => 1,
            'sur_devis'        => 0,
        ], $o);
    };
    $pts = static fn (array $textes): array => array_map(static fn ($t) => ['texte' => $t], $textes);

    $offres = [
        // ─── Création de site (paiement unique + abonnement)
        $offre([
            'categorie' => 'creation', 'nom' => 'Site One Page', 'facturation' => 'paiement_unique',
            'prix' => 1190, 'delai' => '1 à 2 semaines',
            'inclus' => $pts(['1 page unique (scroll long)', 'De 5 à 7 sections, (ex. : services, témoignages, contact, footer)', 'Design responsive (mobile, tablette)', 'Formulaire de contact simple (nom, email, message)', 'Optimisation SEO de base (balises title, meta description, H1)', 'Mise en ligne accompagnée']),
            'exclus' => $pts(['Rédaction des textes (sauf si fournis)', 'Page supplémentaire (blog, mentions dédiées, etc.)', 'Animations avancées', 'Maintenance et hébergement (option)']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Site One Page', 'facturation' => 'abonnement',
            'prix' => 89, 'frais_setup' => 390, 'engagement' => 'Engagement 24 mois', 'delai' => '1 à 2 semaines',
            'inclus_maintenance' => 'Pack Essentiel',
            'inclus' => $pts(['Création du site one page', 'Hébergement web géré', 'Maintenance Pack Essentiel', 'Mises à jour de sécurité', 'Sauvegardes automatiques', 'Certificat SSL inclus']),
            'exclus' => $pts(['Création de nouvelles pages ou sections supplémentaires', 'Correction d’erreurs causées par le client (ex : cassé via accès admin)']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Site vitrine', 'facturation' => 'paiement_unique',
            'prix' => 1990, 'delai' => '2 à 4 semaines', 'mis_en_avant' => 1, 'libelle_badge' => 'Le plus demandé',
            'inclus' => $pts(['Jusqu\'à 5 pages structurées (ex. : accueil, services, à propos, galerie, contact, mentions)', 'Arborescence simple', 'Design responsive', 'Formulaire de contact', 'Optimisation SEO de base', 'Mise en ligne']),
            'exclus' => $pts(['Stratégie de contenu ou rédaction SEO des textes', 'Fonctionnalités avancées', 'Maintenance et hébergement (option)']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Site vitrine', 'facturation' => 'abonnement',
            'prix' => 119, 'frais_setup' => 490, 'engagement' => 'Engagement 24 mois', 'delai' => '2 à 4 semaines',
            'inclus_maintenance' => 'Pack Essentiel',
            'inclus' => $pts(['Création du site vitrine (jusqu\'à 5 pages)', 'Hébergement web géré', 'Maintenance Pack Essentiel', 'Sauvegardes et mises à jour', 'SEO de base inclus', 'Maquette simple']),
            'exclus' => $pts(['Rédaction complète', 'Migration d’ancien contenu depuis autre site']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Site vitrine avancé', 'facturation' => 'paiement_unique',
            'prix' => 3290, 'delai' => '4 à 6 semaines',
            'inclus' => $pts(['6 à 10 pages structurées', 'Arborescence personnalisée', 'Maillage interne soigné', 'SEO renforcé dès la conception', 'Accompagnement sur les contenus']),
            'exclus' => $pts(['Stratégie SEO mensuelle', 'Espace client ou membre', 'Maintenance (option)']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Site vitrine avancé', 'facturation' => 'abonnement',
            'prix' => 199, 'frais_setup' => 690, 'engagement' => 'Engagement 24 mois', 'delai' => '4 à 6 semaines',
            'inclus_maintenance' => 'Pack Essentiel',
            'inclus' => $pts(['Site 8 à 10 pages', 'Hébergement et maintenance', 'SEO de base renforcé', 'Petites modifications mensuelles', 'Suivi technique régulier']),
            'exclus' => $pts(['Rédaction longue', 'Développement sur-mesure']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Refonte de site', 'facturation' => 'paiement_unique',
            'prix' => 2490, 'delai' => '3 à 6 semaines',
            'inclus' => $pts(['Audit complet de l\'existant', 'Restructuration des contenus', 'Amélioration design et responsive', 'Optimisation SEO de base', 'Mise en ligne']),
            'exclus' => $pts(['Reprise massive de contenus', 'Migration complexe', 'SEO mensuel']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Petit e-commerce', 'facturation' => 'paiement_unique',
            'prix' => 3990, 'delai' => '4 à 8 semaines',
            'inclus' => $pts(['Boutique simple WooCommerce (10 produits Max)', 'Catalogue de base', 'Paiement en ligne', 'Livraison simple configurée', 'Pages légales obligatoires', 'Formation à la prise en main']),
            'exclus' => $pts(['Import massif de produits', 'Connecteurs ERP / marketplace', 'SEO e-commerce avancé']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'Petit e-commerce', 'facturation' => 'abonnement',
            'prix' => 299, 'frais_setup' => 990, 'engagement' => 'Engagement 36 mois', 'delai' => '4 à 8 semaines',
            'inclus_maintenance' => 'Pack Confort',
            'inclus' => $pts(['Création d\'un petit site e-commerce (10 produits Max)', 'Hébergement et maintenance', 'Paiement et livraison configurés', 'Mises à jour et sauvegardes', 'Accompagnement à la prise en main']),
            'exclus' => $pts(['Gros catalogue', 'Intégrations complexes', 'SEO e-commerce avancé']),
        ]),
        $offre([
            'categorie' => 'creation', 'nom' => 'E-commerce standard', 'facturation' => 'paiement_unique',
            'prix' => 6900, 'frais_setup' => 990, 'engagement' => '36 mois', 'prefixe_a_partir' => 0, 'delai' => '6 à 10 semaines', 'sur_devis' => 1,
            'inclus_maintenance' => 'Maintenance Confort',
            'inclus' => $pts(['Boutique structurée avec catégories', 'Paiement + livraison complets', 'Optimisation UX', 'SEO e-commerce de base', 'Accompagnement à la prise en main']),
            'exclus' => $pts(['Catalogue massif', 'Marketplace', 'Stratégie e-commerce avancée']),
        ]),
        // ─── Référencement SEO
        $offre([
            'categorie' => 'seo', 'nom' => 'Audit SEO ponctuel', 'facturation' => 'paiement_unique',
            'prix' => 590, 'delai' => '1 à 2 semaines',
            'inclus' => $pts(['Analyse complète du site', 'Points techniques (vitesse, structure)', 'Analyse contenus et balises', 'Recommandations priorisées']),
            'exclus' => $pts(['Mise en œuvre des recommandations', 'Suivi mensuel']),
        ]),
        $offre([
            'categorie' => 'seo', 'nom' => 'SEO Starter', 'facturation' => 'abonnement',
            'prix' => 390, 'engagement' => 'Engagement 6 mois', 'delai' => 'Démarrage sous 1 semaine',
            'inclus' => $pts(['Audit technique initial (1 fois)', 'Recherche de 5 à 10 mots-clés (volume, concurrence)', 'Optimisation on-page : balises title, meta descriptions, H1/H2, URLs (jusqu’à 1 pages/mois)', 'Maillage interne simple', 'Rédaction SEO de 1 article de blog (400–600 mots)', 'Soumission à Google Search Console', 'Suivi des positions (10 mots-clés principaux)']),
            'exclus' => $pts(['Netlinking (achat de liens)', 'Stratégie de contenu avancée (siloring, clusters)', 'Audit concurrentiel détaillé', 'Référencement international ou multilingue']),
        ]),
        $offre([
            'categorie' => 'seo', 'nom' => 'SEO Croissance', 'facturation' => 'abonnement',
            'prix' => 690, 'engagement' => 'Engagement 6 mois', 'delai' => 'Démarrage sous 1 semaine', 'mis_en_avant' => 1, 'libelle_badge' => 'Le plus demandé',
            'inclus' => $pts(['Audit technique approfondi (1 fois)', 'Recherche de 10 – 20 mots-clés (avec intention / information)', 'Optimisation on-page : balises title, meta descriptions, H1/H2, URLs (jusqu’à 3 pages/mois)', 'Maillage interne renforcé', 'Rédaction SEO de 2 articles (500–700 mots chacun)', 'Optimisation des images (alt, taille, lazy loading)', 'Suivi des positions (10 mots-clés principaux)']),
            'exclus' => $pts(['Création de pages', 'Rédaction technique (whitepaper, étude de cas longue)', 'SEO E-commerce (fiches produits multiples)']),
        ]),
        $offre([
            'categorie' => 'seo', 'nom' => 'SEO Performance', 'facturation' => 'abonnement',
            'prix' => 1190, 'engagement' => 'Engagement 12 mois', 'delai' => 'Démarrage sous 2 semaines',
            'inclus' => $pts(['Audit technique complet', 'Recherche de 20+ mots-clés + opportunités longue traîne et sémantique', 'Optimisation on-page : toutes pages stratégiques (jusqu’à 5 pages/mois)', 'Rédaction SEO de 4 articles (700–1000 mots)', 'Stratégie de netlinking éditorial ', 'Analyse concurrentielle poussée (backlinks, contenu)', 'Suivi concurrentiel approfondi', 'Optimisation technique', 'Suivi des positions (30 mots-clés principaux)']),
            'exclus' => $pts(['Campagne de netlinking à grande échelle (500€+ de budget liens)', 'Création de plus de 4 articles/mois (supplément possible)', 'Rédaction en langue étrangère (sauf devis spécifique)']),
        ]),
        // ─── Maintenance + Hébergement (Pack M+H)
        $offre([
            'categorie' => 'maintenance_hebergee', 'nom' => 'Pack Essentiel', 'facturation' => 'abonnement',
            'prix' => 79, 'engagement' => 'Sans engagement', 'delai' => 'Prise en charge sous 48h',
            'inclus' => $pts(['Maintenance + hébergement mutualisé standard inclus', 'Mises à jour WordPress, thème et extensions', 'Sauvegardes régulières', 'Maintenance corrective (réparation d’un bug critique, site down, erreur 500)', 'Modifications ponctuelles : 15 minutes/mois (texte, image, lien, ajustement mineur)', 'Support technique : email uniquement, réponse sous 72h ouvrées', 'Certificat SSL automatique (Let\'s Encrypt)', 'Restauration en cas de souci']),
            'exclus' => $pts(['Modifications au-delà de 15 min/mois (Facturé 70€/h)', 'Mises à jour de thèmes ou plugins premium (sauf si licence fournie)', 'Correction après piratage lié à mot de passe faible du client', 'Amélioration des performances (Core Web Vitals, cache avancé)']),
        ]),
        $offre([
            'categorie' => 'maintenance_hebergee', 'nom' => 'Pack Confort', 'facturation' => 'abonnement',
            'prix' => 119, 'engagement' => 'Sans engagement', 'delai' => 'Prise en charge sous 48h', 'mis_en_avant' => 1, 'libelle_badge' => 'Le plus demandé',
            'inclus' => $pts(['Tout le pack Essentiel', 'Modifications ponctuelles : 30 minutes/mois', 'Support technique : email + chat, réponse sous 48h ouvrées', 'Analyse des erreurs 404 et correction des liens cassés (jusqu’à 5 par mois)']),
            'exclus' => $pts(['Modifications au-delà de 30 min/mois (facturé 70€/h)', 'Correction d’incompatibilité entre plugins tiers non validés', 'Création de nouvelles pages (hors modification de contenu existant)']),
        ]),
        $offre([
            'categorie' => 'maintenance_hebergee', 'nom' => 'Pack Premium', 'facturation' => 'abonnement',
            'prix' => 199, 'engagement' => 'Sans engagement', 'delai' => 'Prise en charge prioritaire',
            'inclus' => $pts(['Tout le pack Confort', 'Modifications ponctuelles : 1 heure/mois', 'Support prioritaire : email, chat, téléphone (réponse sous 24h ouvrées)', 'Nettoyage base de données (optimisation, révisions, spam)', 'Optimisation continue', 'Intervention d’urgence (site down)']),
            'exclus' => $pts(['Modifications au-delà de 1h/mois (facturé 70€/h)', 'Refonte de structure ou design (devis spécifique)', 'Correction après piratage complexe (nette augmentation du temps – facturable au-delà de 1h/mois)', 'Création de nouvelles fonctionnalités (ex : formulaire multistep, tableau de bord)', 'Intégration d’API tierces (sauf dépannage mineur)']),
        ]),
        // ─── Maintenance seule / Hébergement externe
        $offre([
            'categorie' => 'maintenance_seule', 'nom' => 'Pack Externe Essentiel', 'facturation' => 'abonnement',
            'prix' => 118, 'engagement' => 'Sans engagement', 'delai' => 'Mise en place sous 48h',
            'inclus' => $pts(['Mises à jour WordPress, thème et extensions', 'Backups (vers un stockage externe)', 'Maintenance corrective (réparation bug critique, site down, erreur 500)', 'Support technique : email uniquement, réponse sous 72h', 'Restauration en cas de souci']),
            'exclus' => $pts(['Hébergement (fourni par le client)', 'Certificat SSL (à la charge du client ou de son hébergeur)', 'Intervention sur serveur client (configuration PHP, mémoire, timeout)', 'Correction de problèmes liés à l’hébergeur (indisponibilité, lenteur serveur)', 'Migration vers un autre hébergeur', 'Modifications au-delà de 15 min/mois (facturé 80€/h)']),
        ]),
        $offre([
            'categorie' => 'maintenance_seule', 'nom' => 'Pack Externe Confort', 'facturation' => 'abonnement',
            'prix' => 169, 'engagement' => 'Sans engagement', 'delai' => 'Mise en place sous 48h',
            'inclus' => $pts(['Tout le pack Externe Essentiel', 'Modifications ponctuelles : 30 minutes/mois', 'Support technique : email + chat, réponse sous 48h ouvrées', 'Analyse des erreurs 404 et correction des liens cassés (jusqu’à 5 par mois)', 'Adapté e-commerce léger']),
            'exclus' => $pts(['Modifications au-delà de 30 min/mois (facturé 80€/h)', 'Correction d’incompatibilité entre plugins tiers non validés', 'Création de nouvelles pages (hors modification de contenu existant)']),
        ]),
        $offre([
            'categorie' => 'maintenance_seule', 'nom' => 'Pack Externe Premium', 'facturation' => 'abonnement',
            'prix' => 269, 'engagement' => 'Sans engagement', 'delai' => 'Mise en place sous 48h',
            'inclus' => $pts(['Tout le pack Externe Confort', 'Modifications ponctuelles : 1 heure/mois', 'Support prioritaire : email, chat, téléphone (réponse sous 24h ouvrées)', 'Nettoyage base de données (optimisation, révisions, spam)', 'Intervention d’urgence (site down)']),
            'exclus' => $pts(['Modifications au-delà de 1h/mois (facturé 80€/h)', 'Refonte de structure ou design (devis spécifique)', 'Correction après piratage complexe (nette augmentation du temps – facturable au-delà de 1h/mois)', 'Création de nouvelles fonctionnalités (ex : formulaire multistep, tableau de bord)', 'Intégration d’API tierces (sauf dépannage mineur)']),
        ]),
        // ─── Identité visuelle / Logo
        $offre([
            'categorie' => 'logo', 'nom' => 'Logo seul', 'facturation' => 'paiement_unique',
            'prix' => 590, 'delai' => '1 à 2 semaines',
            'inclus' => $pts(['Recherche créative (2 propositions de direction)', '2 allers-retours de modifications sur la proposition retenue (ajustements de forme, couleur, typo)', 'Fichiers vectoriels (AI, PDF)', 'Versions couleur et monochrome']),
            'exclus' => $pts(['Charte graphique complète', 'Création de déclinaisons spécifiques (ex : logo pour enseigne, flocage textile, print)']),
        ]),
        $offre([
            'categorie' => 'logo', 'nom' => 'Logo + charte graphique', 'facturation' => 'paiement_unique',
            'prix' => 1490, 'delai' => '2 à 3 semaines',
            'inclus' => $pts(['Recherche créative (3 propositions de direction)', 'Logo + déclinaisons', 'Palette de couleurs et typographies', 'Charte graphique (carte de visite, en-tête de lettre, signature mail)', 'Fichiers pour web et print']),
            'exclus' => $pts(['Création de templates avancés (PowerPoint, Canva, plaquette commerciale)', 'Création de visuels photos ou illustrations sur mesure']),
        ]),
        // ─── Régie (taux horaire / journalier)
        $offre([
            'categorie' => 'regie', 'nom' => 'Intervention à l\'heure', 'facturation' => 'horaire',
            'prix' => 70, 'prefixe_a_partir' => 0,
            'inclus' => $pts(['Modifications ponctuelles', 'Corrections, ajustements', 'Conseil technique']),
        ]),
        $offre([
            'categorie' => 'regie', 'nom' => 'Intervention à la journée', 'facturation' => 'journalier',
            'prix' => 450, 'prefixe_a_partir' => 0, 'libelle_badge' => 'Le plus demandé',
            'inclus' => $pts(['Travaux plus conséquents', 'Demi-journée ou journée complète', 'Tarif dégressif sur volume']),
        ]),
        // ─── Identité visuelle / Logo
        $offre([
            'categorie' => 'logo', 'nom' => 'Identité complète', 'facturation' => 'paiement_unique',
            'prefixe_a_partir' => 0, 'delai' => 'Sur devis', 'libelle_badge' => 'Le plus demandé', 'sur_devis' => 1,
            'inclus' => $pts(['Logo + charte complète', 'Papeterie (cartes, signatures…)', 'Déclinaisons web et print', 'Accompagnement sur-mesure']),
        ]),
    ];

    // Options ponctuelles : forfaits/abonnements à l'unité (famille service, serveur,
    // migration). Lues telles quelles par evolutionr_get_pricing().
    $options = [
        [
            'cle' => 'extra_page', 'label' => 'Page supplémentaire', 'famille' => 'service', 'unite' => 'forfait', 'prix' => 220, 'actif' => 1,
            'description' => 'Une page de contenu en plus, optimisée SEO de base.',
            'description_detail' => 'Ajoute une page de contenu au site, au-delà des pages comprises dans la formule choisie : intégration, mise en forme responsive et optimisation SEO de base. Idéale pour une page service, une page « zone d\'intervention » ou une landing dédiée.',
        ],
        [
            'cle' => 'creation_logo', 'label' => 'Création de logo', 'famille' => 'service', 'unite' => 'forfait', 'prix' => 690, 'actif' => 1,
            'description' => 'Logo professionnel : 3 propositions, allers-retours, fichiers vectoriels livrés.',
            'description_detail' => 'Comprend : 3 directions créatives proposées, 2 séances de retours pour affinage, livraison en formats vectoriels (SVG, AI) et adaptés (PNG, PDF). Si une charte graphique complète vous intéresse (couleurs, typographies, déclinaisons), nous établissons un devis dédié.',
        ],
        [
            'cle' => 'serveur_performance', 'label' => 'Serveur Performance', 'famille' => 'serveur', 'unite' => 'mensuel', 'prix' => 19, 'actif' => 1,
            'description' => 'Hébergement renforcé pour une meilleure stabilité et une meilleure tenue en charge',
            'description_detail' => 'Cette option repose sur un hébergement mutualisé plus performant qu’une offre standard. Elle est adaptée aux sites vitrines plus complets, aux sites avec davantage de contenu ou aux projets nécessitant plus de confort, de stockage et une meilleure capacité à absorber les pics de trafic ponctuels.',
        ],
        [
            'cle' => 'serveur_vps', 'label' => 'Serveur VPS', 'famille' => 'serveur', 'unite' => 'mensuel', 'prix' => 39, 'actif' => 1,
            'description' => 'Ressources dédiées pour un site plus exigeant.',
            'description_detail' => 'Le VPS offre un environnement serveur dédié, avec CPU et RAM réservés au site. Il permet de meilleures performances qu’un hébergement mutualisé et convient aux projets plus exigeants, évolutifs ou nécessitant une configuration technique spécifique.',
        ],
        [
            'cle' => 'migration_entrante', 'label' => 'Migration de votre site vers nos serveurs', 'famille' => 'migration', 'unite' => 'forfait', 'prix' => 0, 'actif' => 1, 'sur_devis' => 1,
            'description' => 'Transfert de votre site existant vers notre infrastructure.',
            'description_detail' => 'Sauvegarde, transfert, remise en service et vérifications. Tarif selon la complexité.',
        ],
    ];

    // Promotions : remises paliers déclenchées selon les familles/dimensions présentes.
    $promotions = [
        [
            'label' => 'Site + Pack Maintenance & Hébergement', 'remise_pct' => 5, 'cible' => 'mensuel', 'actif' => 1,
            'familles_requises' => ['creation', 'maintenance_hebergee'],
        ],
        [
            'label' => 'Site + Pack Maintenance & Hébergement + SEO', 'remise_pct' => 10, 'cible' => 'les_deux', 'actif' => 1,
            'familles_requises' => ['creation', 'seo', 'maintenance_hebergee'],
        ],
    ];

    update_field('tva_pct', 20, 'option');
    update_field('offres', $offres, 'option');
    update_field('options', $options, 'option');
    update_field('promotions', $promotions, 'option');

    // Shortcode du formulaire de devis : recherche le formulaire CF7
    // « Devis Evolution'R » par titre (l'ID varie selon l'environnement).
    if (!get_field('devis_cf7', 'option')) {
        $devis = get_posts([
            'post_type'      => 'wpcf7_contact_form',
            'title'          => 'Devis Evolution\'R',
            'posts_per_page' => 1,
            'post_status'    => 'publish',
        ]);
        if (!empty($devis)) {
            update_field('devis_cf7', sprintf('[contact-form-7 id="%d" title="Devis Evolution\'R"]', $devis[0]->ID), 'option');
        }
    }
}

/* ────────────────────────────────────────────────────────────────────
 *  Formulaire CF7 dédié à la page Contact.
 *
 *  Le formulaire de devis (#69, page Tarifs) contient un champ « Récapitulatif
 *  de votre configuration » (`[textarea your-config]`) alimenté par le
 *  configurateur — pertinent sur Tarifs, parasite sur Contact (champ vide,
 *  déroutant). On crée donc un second formulaire « Contact Evolution'R » :
 *  copie du devis MOINS ce bloc de récap, puis on câble la page Contact dessus.
 *  Garde : option `evolutionr_contact_form_seeded`. Pour relancer :
 *  wp option delete evolutionr_contact_form_seeded; wp eval 'evolutionr_seed_contact_form();'
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_contact_form(): void
{
    if (!function_exists('evolutionr_acf_is_active') || !evolutionr_acf_is_active()) {
        return;
    }
    if (!class_exists('WPCF7_ContactForm')) {
        return;
    }

    // Réutilise le formulaire de contact s'il existe déjà (idempotence) ; sinon
    // le dérive du formulaire de devis pour garder les champs synchronisés.
    $existing = get_posts([
        'post_type'      => 'wpcf7_contact_form',
        'title'          => "Contact Evolution'R",
        'posts_per_page' => 1,
        'post_status'    => 'publish',
    ]);

    if (!empty($existing)) {
        $contactId = (int) $existing[0]->ID;
    } else {
        $devis = get_posts([
            'post_type'      => 'wpcf7_contact_form',
            'title'          => "Devis Evolution'R",
            'posts_per_page' => 1,
            'post_status'    => 'publish',
        ]);
        if (empty($devis)) {
            return; // pas de formulaire source → rien à dériver
        }

        $source = WPCF7_ContactForm::get_instance((int) $devis[0]->ID);
        if (!$source) {
            return;
        }

        $form = $source->copy();
        $form->set_title("Contact Evolution'R");

        $props = $form->get_properties();

        // Retire le bloc « Récapitulatif de votre configuration » du formulaire
        // (champ propre au configurateur Tarifs).
        if (!empty($props['form'])) {
            $props['form'] = preg_replace(
                '#\s*<p class="cfg-config-wrap">.*?</p>#s',
                '',
                $props['form']
            );
        }

        // Retire la section « Configuration choisie : [your-config] » du mail.
        if (!empty($props['mail']['body'])) {
            $props['mail']['body'] = preg_replace(
                '#\s*Configuration choisie\s*:\s*\R\[your-config\]\R?#u',
                '',
                $props['mail']['body']
            );
        }

        $form->set_properties($props);
        $contactId = (int) $form->save();
        if (!$contactId) {
            return;
        }
    }

    // Câble la page Contact sur ce formulaire dédié.
    $contactPage = get_page_by_path('contact');
    if ($contactPage) {
        update_field(
            'cf7_shortcode',
            sprintf('[contact-form-7 id="%d" title="Contact Evolution\'R"]', $contactId),
            $contactPage->ID
        );
    }
}

/* ────────────────────────────────────────────────────────────────────
 *  Seed des sections explicatives de la page Création (Bénéfices, Méthode,
 *  lede Paiement). Les titres/eyebrows/toggles s'appuient sur leurs
 *  default_value ACF ; on peuple ici les repeaters et ledes sans défaut.
 *  Garde : option `evolutionr_creation_sections_seeded`. Pour relancer :
 *  wp option delete evolutionr_creation_sections_seeded; wp eval 'evolutionr_seed_creation_sections();'
 * ──────────────────────────────────────────────────────────────────── */

function evolutionr_seed_creation_sections(): void
{
    if (!function_exists('evolutionr_acf_is_active') || !evolutionr_acf_is_active()) {
        return;
    }
    $id = evolutionr_seed_get_or_create_page('Création de site web', 'creation-site-internet', '');
    if (!$id) {
        return;
    }

    // Bénéfices — tous les champs explicites (les default_value ACF ne
    // s'appliquent pas via get_field() en front-end pour un champ non sauvé).
    update_field('ben_enabled', true, $id);
    update_field('ben_eyebrow', 'Pourquoi un site web', $id);
    update_field('ben_title', 'Un site professionnel change la donne pour votre activité', $id);
    update_field('ben_lede', "Au-delà d'un simple site, vous gagnez en crédibilité, en visibilité sur Google et en contacts qualifiés.", $id);
    update_field('ben_items', [
        ['icon' => 'compass', 'title' => 'Crédibilité immédiate', 'desc' => 'Un site soigné rassure vos prospects et reflète le sérieux de votre activité dès le premier regard.'],
        ['icon' => 'search', 'title' => 'Visible sur Google', 'desc' => 'Une structure et des contenus pensés pour le référencement vous font apparaître sur les recherches de vos clients.'],
        ['icon' => 'trend', 'title' => 'Des contacts qualifiés', 'desc' => 'Appels, formulaires, demandes de devis : un site bien conçu transforme vos visiteurs en demandes concrètes.'],
        ['icon' => 'shield', 'title' => 'Disponible 24/7', 'desc' => "Votre activité se présente et répond aux questions courantes, même quand vous n'êtes pas disponible."],
    ], $id);

    // Paiement unique ou abonnement
    update_field('pay_enabled', true, $id);
    update_field('pay_eyebrow', 'Deux façons de financer', $id);
    update_field('pay_title', 'Paiement unique ou abonnement, à vous de choisir', $id);
    update_field('pay_lede', "Selon votre budget de départ, financez votre site en une fois ou lancez-le en abonnement mensuel.", $id);
    update_field('pay_uniq_title', 'Payer en une fois', $id);
    update_field('pay_uniq_text', "Vous financez votre site directement et en devenez pleinement propriétaire. Idéal si vous disposez du budget de départ et préférez un coût maîtrisé, sans engagement dans la durée.", $id);
    update_field('pay_abo_title', 'Démarrer en abonnement', $id);
    update_field('pay_abo_text', "Vous lancez votre site avec un coût de départ réduit, puis une mensualité. L'abonnement inclut la création, l'hébergement, la maintenance et les mises à jour de sécurité. Un engagement est prévu sur les formules mensuelles.", $id);
    update_field('pay_cta_label', 'Comparer les deux modes', $id);
    update_field('pay_cta_url', '/tarifs/?service=creation', $id);

    // Méthode
    update_field('meth_enabled', true, $id);
    update_field('meth_eyebrow', 'Comment ça se passe', $id);
    update_field('meth_title', 'Une méthode claire, étape par étape', $id);
    update_field('meth_lede', "Chaque projet suit un cadre clair, du premier échange à la mise en ligne.", $id);
    update_field('meth_steps', [
        ['num' => '01', 'title' => 'Comprendre votre activité', 'desc' => 'On échange sur votre métier, vos objectifs et votre cible. Vous nous parlez, nous prenons des notes.'],
        ['num' => '02', 'title' => 'Cadrer le projet', 'desc' => "Nous vous proposons une arborescence, un périmètre clair, un devis détaillé. Aucune zone d'ombre."],
        ['num' => '03', 'title' => 'Concevoir & rédiger', 'desc' => 'Maquettes, structure des contenus, balises SEO. On valide ensemble avant tout développement.'],
        ['num' => '04', 'title' => 'Développer & mettre en ligne', 'desc' => 'Intégration, tests, recette, mise en production sur un hébergement adapté.'],
        ['num' => '05', 'title' => 'Suivre dans la durée', 'desc' => "Maintenance, sauvegardes, conseils SEO, ajustements. Votre site continue d'évoluer."],
    ], $id);
}

/**
 * Pré-remplit le repeater `hero_stats` de la page Tarifs avec 3 mini-encarts
 * affichés à droite du titre du hero. Le repeater reste pleinement éditable
 * depuis le métabox ACF de la page — c'est juste un seed initial.
 *
 * Rappel : sur ce thème, `default_value` ACF n'est pas appliqué par
 * `get_field()` en front-end (cf. tasks/lessons.md 2026-05-27). Toute valeur
 * dont dépend l'affichage doit donc être seedée explicitement.
 */
function evolutionr_seed_tarifs_hero_stats(): void
{
    if (!evolutionr_acf_is_active()) return;

    $page = get_page_by_path('tarifs');
    if (!$page) return;

    $existing = get_field('hero_stats', $page->ID);
    if (!empty($existing)) return; // ne pas écraser une saisie admin

    update_field('hero_stats', [
        ['label' => 'Tarifs',   'value' => 'Transparents'],
        ['label' => 'Devis',    'value' => 'Personnalisé'],
        ['label' => 'Paiement', 'value' => 'Unique ou mensuel'],
    ], $page->ID);
}

/**
 * Seede les sections marketing (Bénéfices + Méthode) de la page Consultant SEO.
 *
 * Au passage, supprime les metas orphelines `_why_*` qui pointent vers
 * `field_evor_pm_why*` (mauvais préfixe, vestige du seeder précédent qui
 * empêchait la lecture du repeater).
 *
 * Rappel : `default_value` ACF non lu en front-end → toutes les valeurs
 * dont dépend l'affichage doivent être seedées explicitement.
 */
function evolutionr_seed_seo_sections(): void
{
    if (!evolutionr_acf_is_active()) return;

    $id = evolutionr_seed_get_page_id('consultant-seo');
    if (!$id) return;

    // Nettoyage des données orphelines de l'ancienne section « Pourquoi le SEO ».
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND (meta_key LIKE %s OR meta_key LIKE %s)",
        $id,
        'why_%',
        '_why_%'
    ));

    // Bénéfices — seedés uniquement si vides (ne pas écraser une saisie admin).
    if (empty(get_field('ben_items', $id))) {
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Pourquoi le SEO', $id);
        update_field('ben_title', 'Un trafic durable, qualifié, qui vous appartient', $id);
        update_field('ben_lede', 'Le SEO ne se résume pas à « apparaître sur Google ». C\'est un travail de fond qui transforme votre site en source régulière de prospects.', $id);
        update_field('ben_items', [
            ['icon' => 'search',  'title' => 'Trafic qualifié et durable',  'desc' => 'Le SEO attire les visiteurs qui cherchent déjà vos services — un flux régulier qui ne s\'arrête pas quand vous coupez la pub.'],
            ['icon' => 'trend',   'title' => 'Crédibilité renforcée',        'desc' => 'Apparaître en haut de Google inspire confiance avant même que le visiteur clique. Une présence forte est un argument commercial.'],
            ['icon' => 'compass', 'title' => 'Une audience comprise',        'desc' => 'Le travail SEO révèle ce que vos prospects cherchent vraiment. Vous adaptez votre offre et votre discours en conséquence.'],
            ['icon' => 'shield',  'title' => 'Investissement long terme',    'desc' => 'Contrairement à la publicité payante, le SEO construit un actif qui continue de produire des résultats mois après mois.'],
        ], $id);
    }

    // Méthode SEO — seedée uniquement si vide.
    if (empty(get_field('meth_steps', $id))) {
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Méthode SEO', $id);
        update_field('meth_title', 'Comment nous travaillons votre référencement', $id);
        update_field('meth_lede', 'Une démarche structurée, du diagnostic à la mesure des résultats. Pas de boîte noire.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Audit SEO complet',         'desc' => 'Analyse technique, contenu, maillage interne et concurrence. On part de ce qui existe pour identifier les leviers prioritaires.'],
            ['num' => '02', 'title' => 'Plan d\'action priorisé',   'desc' => 'Un plan clair distinguant les « quick wins » (gains rapides) des chantiers de fond. Vous savez exactement ce qui est fait et pourquoi.'],
            ['num' => '03', 'title' => 'Optimisations',             'desc' => 'Mise en œuvre : balises, structure des pages, maillage interne, contenus. Modifications appliquées et documentées au fil de l\'eau.'],
            ['num' => '04', 'title' => 'Suivi du positionnement',   'desc' => 'Tableau de bord mensuel : rankings, trafic organique, conversions. On mesure ce qui bouge pour orienter la suite.'],
            ['num' => '05', 'title' => 'Ajustements continus',      'desc' => 'Le SEO n\'est jamais figé. On itère selon les résultats, les évolutions Google et vos objectifs commerciaux.'],
        ], $id);
    }
}

/**
 * Seede les sections marketing (Bénéfices + Méthode) de la page Maintenance.
 * Méthode = variante B « cycle mensuel » (ce qui se passe chaque mois).
 */
function evolutionr_seed_maintenance_sections(): void
{
    if (!evolutionr_acf_is_active()) return;

    $id = evolutionr_seed_get_page_id('maintenance-hebergement');
    if (!$id) return;

    if (empty(get_field('ben_items', $id))) {
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Pourquoi maintenir', $id);
        update_field('ben_title', 'Un site fiable, sécurisé, suivi dans la durée', $id);
        update_field('ben_lede', 'Un site internet n\'est jamais figé : il doit évoluer, être mis à jour et surveillé. La maintenance vous décharge de toute cette partie technique.', $id);
        update_field('ben_items', [
            ['icon' => 'shield',  'title' => 'Site sécurisé en continu',    'desc' => 'Mises à jour WordPress, thèmes et extensions appliquées dès qu\'elles sortent. Votre site ne devient pas une faille à exploiter.'],
            ['icon' => 'compass', 'title' => 'Sauvegardes automatiques',    'desc' => 'Votre site est sauvegardé régulièrement et restaurable en cas de pépin. La tranquillité, sans y penser.'],
            ['icon' => 'trend',   'title' => 'Performances préservées',     'desc' => 'Vérifications régulières pour que le site reste rapide, accessible et fonctionnel mois après mois.'],
            ['icon' => 'search',  'title' => 'Un interlocuteur dédié',      'desc' => 'Une question, un bug, une modification : vous avez un contact direct au lieu de chercher un tutoriel sur YouTube.'],
        ], $id);
    }

    if (empty(get_field('meth_steps', $id))) {
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Cycle mensuel', $id);
        update_field('meth_title', 'Ce qui se passe chaque mois sur votre site', $id);
        update_field('meth_lede', 'Chaque mois, votre site passe par un cycle simple et discret. Vous n\'avez rien à faire, vous recevez juste le compte-rendu.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Sauvegarde complète du site',           'desc' => 'Avant toute opération, votre site est sauvegardé intégralement (fichiers + base de données). En cas de souci, restauration possible.'],
            ['num' => '02', 'title' => 'Mises à jour en environnement de test', 'desc' => 'WordPress, thème et extensions mis à jour sur une copie du site, jamais directement en production. Aucune mauvaise surprise visible pour vos visiteurs.'],
            ['num' => '03', 'title' => 'Vérification du bon fonctionnement',    'desc' => 'Parcours des pages clés, tests des formulaires, contrôle de l\'affichage. Le site est validé avant retour en production.'],
            ['num' => '04', 'title' => 'Surveillance sécurité et performances', 'desc' => 'Monitoring continu, scan de sécurité, contrôle des temps de chargement. Toute anomalie est traitée sans attendre.'],
            ['num' => '05', 'title' => 'Rapport mensuel transmis au client',    'desc' => 'Vous recevez un compte-rendu clair : ce qui a été fait, ce qui a été détecté, les recommandations éventuelles.'],
        ], $id);
    }
}

/**
 * Pré-remplit les 3 mini-stats du hero Contact (cohérence avec les autres
 * pages internes). Repeater pleinement éditable depuis le métabox ACF —
 * seed initial uniquement.
 */
function evolutionr_seed_contact_hero_stats(): void
{
    if (!evolutionr_acf_is_active()) return;

    $page = get_page_by_path('contact');
    if (!$page) return;

    if (!empty(get_field('hero_stats', $page->ID))) return; // ne pas écraser une saisie admin

    update_field('hero_stats', [
        ['label' => 'Réponse',    'value' => 'Sous 48h'],
        ['label' => 'Devis',      'value' => 'Gratuit'],
        ['label' => 'Engagement', 'value' => 'Aucun'],
    ], $page->ID);
}

/**
 * Pré-remplit le texte du hero (eyebrow + titre + sous-titre) des pages
 * Tarifs et Contact, pour respecter la charte des autres pages internes
 * (qui ont toutes eyebrow + H1 descriptif + paragraphe). Les champs ACF
 * existent déjà dans les groupes `group_evor_page_tarifs` / `_contact` et
 * restent pleinement éditables — seed initial uniquement, posé seulement
 * si le champ est vide (respect d'une saisie BO).
 *
 * Lookup par slug insensible à la hiérarchie (cf. lessons.md).
 */
function evolutionr_seed_tarifs_contact_hero_text(): void
{
    if (!evolutionr_acf_is_active()) return;

    $pages = [
        'tarifs' => [
            'hero_eyebrow' => 'Tarifs',
            'hero_title'   => 'Des tarifs clairs, adaptés à votre projet',
            'hero_sub'     => "Création de site, référencement, maintenance, hébergement : des offres lisibles et sans surprise. Estimez votre budget avec le configurateur ou demandez un devis personnalisé — réponse sous 48 heures.",
        ],
        'contact' => [
            'hero_eyebrow' => 'Contact',
            'hero_title'   => 'Parlons de votre projet',
            'hero_sub'     => "Une création, une refonte, un besoin de visibilité ou de maintenance ? Décrivez-nous votre projet : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.",
        ],
    ];

    foreach ($pages as $slug => $fields) {
        $ids = get_posts([
            'post_type'      => 'page',
            'name'           => $slug,
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);
        if (empty($ids)) continue;
        $id = (int) $ids[0];

        foreach ($fields as $name => $value) {
            if (!get_field($name, $id)) {
                update_field($name, $value, $id);
            }
        }
    }
}

/**
 * REFONTE CONTENU (change `refonte-contenu-seo`) — Réglages globaux.
 * Ré-angle tagline, alt et CTA sur l'axe Toulouse + 100 % à distance + 1190 €.
 * Réécrit (refonte assumée). Cf. .claude/docs/CONTEXT.md.
 */
function evolutionr_seed_refonte_options(): void
{
    if (!evolutionr_acf_is_active()) return;

    update_field('logo_alt', "Evolution'R — studio web indépendant en Haute-Garonne", 'option');
    update_field('footer_tagline', "Votre présence en ligne, pensée pour durer : site vitrine sur-mesure, référencement naturel et maintenance, sans engagement. Evolution'R, studio web indépendant en Haute-Garonne, au service des TPE, PME et artisans — à distance, partout en France.", 'option');
    update_field('cta_primary_label', 'Devis gratuit en ligne', 'option');
    update_field('cta_primary_url', '/contact/', 'option');
}

/**
 * SNAPSHOT DE CONTENU (généré) — applique le texte live actuel (héros, sections,
 * repeaters) de chaque page. Couche appliquée EN DERNIER pour qu'une réinstallation
 * reparte sur le contenu peaufiné. Médias exclus (IDs propres à l'environnement),
 * URLs normalisées en relatif. Régénérable : tools/generate-content-snapshot.php.
 */
function evolutionr_seed_content_snapshot(): void
{
    if (!evolutionr_acf_is_active()) return;

    // ── Accueil ──
    if ($id = (int) get_option('page_on_front')) {
        update_field('hero_status_text', 'Devis, création et suivi — tout se fait en ligne', $id);
        update_field('hero_title_lead', 'Un site web', $id);
        update_field('hero_title_accent', 'clair et visible', $id);
        update_field('hero_title_trail', 'qui travaille pour votre activité.', $id);
        update_field('hero_sub', 'Création de sites web, référencement naturel et maintenance WordPress pour artisans, TPE et PME. Basés près de Toulouse, nous concevons votre site 100 % à distance simplement, par mail et visio. Pensé pour vos clients et pour Google. ', $id);
        update_field('hero_visual_label', 'site.pro.dev', $id);
        update_field('services_eyebrow', 'Nos prestations', $id);
        update_field('services_title', 'Toute votre présence en ligne, au même endroit', $id);
        update_field('services_lede', 'De la création de votre site à son référencement, sa maintenance et son identité visuelle, nous réunissons les services essentiels pour construire une présence en ligne claire, fiable et cohérente.', $id);
        update_field('pillars_eyebrow', 'Pourquoi nous choisir', $id);
        update_field('pillars_title', 'Un partenaire web simple et durable', $id);
        update_field('method_eyebrow', 'Comment nous travaillons', $id);
        update_field('method_title', 'Une méthode simple, à distance, étape par étape', $id);
        update_field('method_lede', 'Nous avançons à distance, par mail, formulaire de cadrage ou visio selon les besoins du projet. L’objectif : cadrer le projet dès le départ, limiter les échanges inutiles et livrer un site prêt à être utilisé.', $id);
        update_field('method_active_index', '1', $id);
        update_field('works_eyebrow', 'Nos réalisations', $id);
        update_field('works_title', 'Des sites en ligne, pour de vrais clients', $id);
        update_field('blog_eyebrow', 'Conseils & ressources', $id);
        update_field('blog_title', 'Guides, conseils et bonnes pratiques', $id);
        update_field('blog_archive_url', '/blog/', $id);
        update_field('faq_eyebrow', 'Questions fréquentes', $id);
        update_field('faq_title', 'Vos questions, des réponses claires', $id);
        update_field('faq_lede', 'Prix, délais, fonctionnement à distance : les questions qu\'on nous pose le plus souvent.', $id);
        update_field('final_cta_eyebrow', 'Devis gratuit — réponse sous 48h', $id);
        update_field('final_cta_title', 'Prêt à lancer votre projet web ?', $id);
        update_field('final_cta_paragraph', 'Un site à créer, à refondre, à référencer ou à maintenir ? Décrivez-nous votre besoin : nous vous répondons sous 48 heures, sans engagement. Tout se fait à distance, simplement.', $id);
        update_field('final_cta_primary_label', 'Demander mon devis', $id);
        update_field('final_cta_primary_url', '/tarifs/', $id);
        update_field('hero_meta', [
            ['label' => 'Besoin analysé'],
            ['label' => 'Devis clair'],
            ['label' => 'Budget transparent'],
        ], $id);
        update_field('hero_stats', [
            ['label' => 'OFFRE WEB', 'value' => 'Site One-page', 'delta' => 'Formule au choix'],
            ['label' => 'Prestations', 'value' => '4', 'delta' => 'Web · SEO · Maintenance · Design'],
        ], $id);
        update_field('reassure_items', [
            ['label' => 'Réponse sous', 'value' => '48h'],
            ['label' => 'Travail', 'value' => '100 % en ligne'],
            ['label' => 'Interlocuteur', 'value' => 'unique'],
            ['label' => 'À partir de', 'value' => '1190 €'],
        ], $id);
        update_field('pillars', [
            ['icon' => 'compass', 'title' => 'Un interlocuteur unique', 'desc' => 'Création de site, référencement, maintenance et identité visuelle : nous centralisons les échanges pour garder un projet clair, cohérent et plus simple et rapide à suivre.'],
            ['icon' => 'trend', 'title' => 'Projet 100 % à distance', 'desc' => 'Les échanges se font par mail et visio, avec une méthode structurée. Vous avancez sans rendez-vous inutiles, sans déplacement et avec des étapes clairement définies.'],
            ['icon' => 'search', 'title' => 'Pensé pour Google', 'desc' => 'Structure, contenus, balises et performance sont intégrés dès la conception. Le référencement n’est pas ajouté après coup : il fait partie de la base du site.'],
            ['icon' => 'shield', 'title' => 'Proche de Toulouse, partout en France', 'desc' => 'Nous accompagnons les artisans, TPE et PME de la région toulousaine comme partout en France, avec le même niveau de suivi et de réactivité.'],
        ], $id);
        update_field('method_steps', [
            ['num' => '01', 'title' => 'Cadrage du besoin', 'desc' => 'Nous collectons les informations essentielles sur votre activité, vos objectifs, vos clients, vos contenus et les attentes autour de votre futur site.', 'meta' => '≈ 30-45 min'],
            ['num' => '02', 'title' => 'Devis & périmètre', 'desc' => 'Nous définissons l’arborescence, les fonctionnalités, les contenus attendus et le budget avant le démarrage.', 'meta' => 'Sous 5 jours'],
            ['num' => '03', 'title' => 'Conception & rédaction', 'desc' => 'Nous préparons la structure des pages, les textes, les bases SEO et les éléments visuels nécessaires pour valoriser votre activité.', 'meta' => '1 à 2 semaines'],
            ['num' => '04', 'title' => 'Intégration & mise en ligne', 'desc' => 'Le site est intégré, testé, ajusté puis mis en ligne sur un hébergement adapté, avec les vérifications techniques essentielles.', 'meta' => '2 à 4 semaines'],
            ['num' => '05', 'title' => 'Suivi dans la durée', 'desc' => 'Maintenance, sauvegardes, sécurité, ajustements et conseils SEO. Votre site continue d\'évoluer avec votre activité.', 'meta' => 'En continu'],
        ], $id);
        update_field('services_cards', [
            ['number' => '01 — CRÉATION', 'icon' => 'code', 'title' => 'Création de site web', 'excerpt' => 'Un site clair, rapide et pensé pour convertir vos visiteurs en contacts. Structure, design, contenus et base SEO sont travaillés dès le départ.', 'bullets' => [
            ['text' => 'Sur-mesure ou refonte'],
            ['text' => 'Responsive et rapide'],
            ['text' => 'Optimisé pour le référencement'],
        ], 'cta_label' => 'Découvrir la création', 'cta_url' => '/evolutionr/prestations/creation-site-internet/'],
            ['number' => '02 — RÉFÉRENCEMENT', 'icon' => 'search', 'title' => 'Consultant SEO', 'excerpt' => 'Nous travaillons votre visibilité sur Google avec une approche durable : audit, optimisation des pages, contenus utiles.', 'bullets' => [
            ['text' => 'Audit et plan d\'action'],
            ['text' => 'Optimisations on-page'],
            ['text' => 'Suivi du positionnement'],
        ], 'cta_label' => 'Voir l\'offre SEO', 'cta_url' => '/evolutionr/prestations/consultant-seo/'],
            ['number' => '03 — SUIVI', 'icon' => 'shield', 'title' => 'Maintenance & hébergement', 'excerpt' => 'Votre site reste à jour, sécurisé et sauvegardé. Nous assurons le suivi technique pour que vous puissiez vous concentrer sur votre activité.', 'bullets' => [
            ['text' => 'Mises à jour et sauvegardes'],
            ['text' => 'Sécurité surveillée'],
            ['text' => 'Hébergement suivi'],
        ], 'cta_label' => 'Voir la maintenance', 'cta_url' => '/evolutionr/prestations/maintenance-hebergement/'],
            ['number' => '04 — IDENTITÉ VISUELLE', 'icon' => 'code', 'title' => 'Identité visuelle', 'excerpt' => 'Logo, couleurs, typographies et supports : nous créons une identité cohérente pour renforcer votre image sur le web et vos supports de communication.', 'bullets' => [
            ['text' => 'Logo sur-mesure'],
            ['text' => 'Charte graphique'],
            ['text' => 'Déclinaisons prêtes'],
        ], 'cta_label' => 'Découvrir l\'identité visuelle', 'cta_url' => '/evolutionr/prestations/identite-visuelle/'],
        ], $id);
        update_field('paiement_eyebrow', 'Paiement', $id);
        update_field('paiement_title', 'Deux façons de lancer votre projet web', $id);
        update_field('paiement_lede', 'Réglez votre site en une fois, ou démarrez avec un budget initial réduit grâce à une formule mensuelle. Dans les deux cas, le périmètre est clair, le budget est annoncé à l’avance et le suivi peut être adapté à vos besoins.', $id);
        update_field('paiement_modes', [
            ['label' => 'Paiement unique', 'argument' => 'Vous financez la création de votre site en une seule fois. Une fois livré et réglé, le site vous appartient et vous restez libre d’ajouter ou non un contrat de suivi.', 'bullets' => [
            ['text' => 'Idéal si votre budget est déjà prévu'],
            ['text' => 'Maintenance et hébergement proposés séparément'],
            ['text' => 'Droits d’exploitation prévus au contrat'],
            ['text' => 'Budget clair dès le départ'],
            ['text' => 'Délai de livraison court (1 à 6 semaines selon projet)'],
        ], 'cta_label' => 'Voir les tarifs one-shot', 'cta_url' => '/tarifs/'],
            ['label' => 'Abonnement mensuel', 'argument' => 'Vous lancez votre site avec un coût de départ réduit, puis une mensualité fixe définie selon la durée choisie. Les services inclus dépendent de la formule choisie.', 'bullets' => [
            ['text' => 'Frais de mise en service réduits'],
            ['text' => 'Mensualité fixe et connue à l’avance'],
            ['text' => 'Services inclus selon la formule'],
            ['text' => 'Durée adaptée au projet'],
            ['text' => 'Évolution possible selon vos besoins'],
        ], 'cta_label' => 'Voir les tarifs abonnement', 'cta_url' => '/tarifs/'],
        ], $id);
        update_field('apercu_tarifs_eyebrow', 'Nos tarifs', $id);
        update_field('apercu_tarifs_title', 'Des budgets clairs pour lancer votre site', $id);
        update_field('apercu_tarifs_lede', 'Pas de devis surprise : le tarif dépend de vos besoins, et comme tout se fait en ligne, vous ne payez aucun déplacement.', $id);
        update_field('apercu_tarifs_items', [
            ['label' => 'Site One Page', 'afficher' => true, 'offre_ref' => 'creation|Site One Page|paiement_unique', 'desc' => 'Une page complète pour présenter votre activité, vos services et vos informations essentielles.'],
            ['label' => 'Site vitrine', 'afficher' => true, 'offre_ref' => 'creation|Site vitrine|paiement_unique', 'desc' => 'Un site structuré jusqu’à 5 pages, pensé pour présenter votre activité et générer des contacts.'],
            ['label' => 'Site e-commerce', 'afficher' => true, 'offre_ref' => 'creation|Petit e-commerce|paiement_unique', 'desc' => 'Une boutique simple avec catalogue, paiement en ligne et configuration des bases de vente.'],
            ['label' => 'Abonnement vitrine', 'afficher' => true, 'offre_ref' => 'creation|Site vitrine|abonnement', 'desc' => 'Un coût de départ réduit, puis une mensualité fixe selon la formule et la durée choisies.'],
            ['label' => 'SEO mensuel', 'afficher' => true, 'offre_ref' => 'seo|SEO Starter|abonnement', 'desc' => 'Un suivi régulier pour améliorer vos pages, vos contenus et votre visibilité sur Google.'],
            ['label' => 'Maintenance', 'afficher' => true, 'offre_ref' => 'maintenance_hebergee|Pack Essentiel|abonnement', 'desc' => 'Mises à jour, sauvegardes, sécurité, surveillance et restauration selon le niveau de maintenance choisi.'],
        ], $id);
        update_field('apercu_tarifs_cta_label', 'Estimer mon projet', $id);
        update_field('apercu_tarifs_cta_url', '/tarifs/', $id);
        update_field('hero_cta_primary_show', true, $id);
        update_field('hero_cta_primary_label', 'Devis gratuit en ligne', $id);
        update_field('hero_cta_primary_url', '/tarifs/', $id);
        update_field('hero_cta_secondary_show', true, $id);
        update_field('hero_cta_secondary_label', 'Voir les réalisations', $id);
        update_field('hero_cta_secondary_url', '#works', $id);
        update_field('faq_items', [
            ['question' => 'Combien de temps faut-il pour créer un site vitrine ?', 'answer' => 'Pour un site vitrine standard de 5 à 10 pages, comptez en général 4 à 6 semaines entre le lancement du projet et la mise en ligne. Le calendrier dépend surtout de la rapidité des validations. Un site one page peut être livré plus rapidement, tandis qu’un projet plus complet demande davantage de cadrage.'],
            ['question' => 'Faut-il rédiger soi-même les contenus de son site ?', 'answer' => 'Vous pouvez fournir vos textes si vous les avez déjà, que nous structurons et optimisons pour le référencement. Si vous n\'avez pas le temps ou pas l\'envie de rédiger, nous pouvons aussi prendre en charge la rédaction des textes sur la base d\'un échange pour bien comprendre votre métier et votre voix.'],
            ['question' => 'Mon site sera-t-il optimisé pour Google ?', 'answer' => 'Oui, les bases SEO sont intégrées dès la création : structure des pages, balises, contenus, responsive et performance. En revanche, le positionnement dépend aussi de la concurrence, de l’ancienneté du site, du contenu publié et du suivi SEO dans le temps..'],
            ['question' => 'Puis-je modifier mon site moi-même après la mise en ligne ?', 'answer' => 'Oui, si le site est prévu pour cela (WordPress). Nous pouvons vous livrer un site administrable afin que vous puissiez modifier certains textes, images ou pages simples. Les modifications plus techniques peuvent aussi être prises en charge dans le cadre d’une maintenance'],
            ['question' => 'Que comprend exactement la maintenance ?', 'answer' => 'La maintenance peut inclure les mises à jour régulières de WordPress et des extensions, les sauvegardes automatiques, la surveillance de sécurité, les corrections techniques et certains ajustements mineurs selon la formule choisie. En cas de problème, nous intervenons pour restaurer ou remettre le site en état. L’objectif est de garder un site fiable, sécurisé et fonctionnel dans le temps. L’hébergement peut être inclus en option, sur une infrastructure adaptée à votre site.'],
            ['question' => 'Travaillez-vous uniquement à distance ?', 'answer' => "Oui, et c'est une force : tout se fait par mail formulaire de cadrage ou visio selon les besoins, sans déplacement. Vous gagnez du temps et permet d’avancer efficacement, sans rendez-vous inutiles, avec des validations à chaque étape.\n"],
            ['question' => 'Combien coûte un site internet ?', 'answer' => "Nos sites démarrent à partir de 1 190 € pour un site one page. Le tarif final dépend du nombre de pages, des fonctionnalités et de vos besoins en référencement. Paiement en une fois ou en mensualités, au choix. Le plus simple : configurez votre devis en ligne ou décrivez-nous votre projet pour une estimation sous 48h.\n"],
        ], $id);
        update_post_meta($id, 'rank_math_title', 'Création de site internet à Toulouse & à distance | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Création de site, référencement et maintenance pour artisans, TPE, PME à Toulouse et partout en France, 100 % à distance. Site pro dès 1190 €, devis sous 48h.');
        update_post_meta($id, 'rank_math_focus_keyword', 'création site internet Toulouse');
    }

    // ── creation-site-internet ──
    if ($id = evolutionr_seed_get_page_id('creation-site-internet')) {
        update_field('types', [
            ['num' => '01', 'label' => 'Site One Page', 'offre_ref' => 'creation|Site One Page|paiement_unique', 'desc' => 'Pour les activités simples qui ont besoin d\'une présence professionnelle rapide, en une seule page complète et soignée.', 'included' => [
            ['text' => 'Une page complète et structurée'],
            ['text' => 'Sections essentielles : activité, services, contact'],
            ['text' => 'Design responsive et lisible'],
            ['text' => 'Formulaire de contact'],
            ['text' => 'Bases SEO intégrées'],
        ], 'featured' => false, 'featured_label' => 'Le plus demandé', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '02', 'label' => 'Site vitrine', 'offre_ref' => 'creation|Site vitrine|paiement_unique', 'desc' => 'Pour présenter une entreprise avec plusieurs pages, une structure optimisé et un parcours de navigation simple.', 'included' => [
            ['text' => 'Accueil, services, à propos, contact'],
            ['text' => 'Pages complémentaires selon besoin'],
            ['text' => 'Design responsive et accessible'],
            ['text' => 'Structure adaptée à vos contenus'],
            ['text' => 'Bases SEO intégrées'],
        ], 'featured' => false, 'featured_label' => 'Le plus demandé', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '03', 'label' => 'Site vitrine avancé', 'offre_ref' => 'creation|Site vitrine avancé|paiement_unique', 'desc' => 'Pour les entreprises qui souhaitent un site plus complet, avec davantage de pages, un meilleur maillage et une base SEO plus poussée.', 'included' => [
            ['text' => '6 à 10 pages structurées'],
            ['text' => 'Arborescence personnalisée'],
            ['text' => 'Maillage interne travaillé'],
            ['text' => 'SEO renforcé dès la conception'],
            ['text' => 'Parcours utilisateur optimisé'],
        ], 'featured' => true, 'featured_label' => 'Le plus demandé', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '04', 'label' => 'Refonte de site', 'offre_ref' => 'creation|Refonte de site|paiement_unique', 'desc' => 'Pour moderniser un site existant : design, structure, référencement et confort d\'utilisation.', 'included' => [
            ['text' => 'Audit complet de l\'existant'],
            ['text' => 'Restructuration des contenus'],
            ['text' => 'Amélioration du design et du responsive'],
            ['text' => 'Optimisation des pages importantes'],
            ['text' => 'Bases SEO corrigées'],
        ], 'featured' => false, 'featured_label' => 'Le plus demandé', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '05', 'label' => 'Site e-commerce', 'offre_ref' => 'creation|Petit e-commerce|paiement_unique', 'desc' => 'Pour vendre des produits ou services en ligne avec une boutique WooCommerce structurée, adaptée à votre catalogue et à vos besoins de vente.', 'included' => [
            ['text' => 'Catalogue produits structuré'],
            ['text' => 'Jusqu’à 10 fiches produits incluses'],
            ['text' => 'Panier et paiement en ligne'],
            ['text' => 'Configuration des livraisons'],
            ['text' => 'Pages légales obligatoires'],
        ], 'featured' => false, 'featured_label' => 'Le plus demandé', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
        ], $id);
        update_field('creation_included', [
            ['text' => 'Cadrage du projet et de l\'arborescence'],
            ['text' => 'Structure des pages adaptée à votre activité'],
            ['text' => 'Design responsive (mobile, tablette, ordinateur)'],
            ['text' => 'Intégration des contenus fournis'],
            ['text' => 'Formulaire de contact opérationnel'],
            ['text' => 'Bases SEO intégrées : balises, structure, lisibilité'],
            ['text' => 'Mise en ligne accompagnée'],
        ], $id);
        update_field('creation_excluded', [
            ['text' => 'Rédaction complète des contenus'],
            ['text' => 'Stratégie SEO mensuelle'],
            ['text' => 'Création de logo'],
            ['text' => 'Photos professionnelles'],
            ['text' => 'Fonctionnalités complexes sur-mesure'],
            ['text' => 'Maintenance après mise en ligne (sauf formule)'],
            ['text' => 'Hébergement (sauf formule ou pack choisi)'],
        ], $id);
        update_field('faq', [
            ['question' => 'Quel type de site choisir ?', 'answer' => 'Tout dépend de votre activité, de vos objectifs et du volume de contenus à présenter. Un site One Page suffit pour une présence simple et rapide. Un site vitrine convient mieux si vous avez plusieurs services à détailler. Une formule avancée est plus adaptée si vous avez besoin de plus de pages, d’un maillage interne travaillé ou d’une base SEO plus poussée.'],
            ['question' => 'Combien de temps faut-il pour créer un site ?', 'answer' => 'Un site One Page peut généralement être livré en 1 à 2 semaines. Un site vitrine demande plutôt 2 à 4 semaines, et un projet plus complet peut aller jusqu’à 6 à 8 semaines. Le délai dépend surtout du nombre de pages, des fonctionnalités, des contenus à intégrer et de la rapidité des validations.'],
            ['question' => 'Que devons-nous fournir avant le démarrage ?', 'answer' => 'Nous avons besoin des informations essentielles sur votre activité, vos services, votre cible, vos contenus existants, vos visuels et vos objectifs. Si tout n’est pas encore prêt, nous pouvons vous guider avec un formulaire de cadrage pour structurer les éléments nécessaires.'],
            ['question' => 'Le site sera-t-il adapté aux mobiles ?', 'answer' => 'Oui. Les sites sont conçus pour être consultés sur ordinateur, tablette et mobile. Le responsive n’est pas une option : il fait partie des bases indispensables pour offrir une bonne expérience aux visiteurs et éviter un site difficile à utiliser sur smartphone.'],
            ['question' => 'Puis-je payer en plusieurs fois ou par abonnement ?', 'answer' => 'Oui. Vous pouvez financer votre site avec un paiement unique ou choisir une formule mensuelle selon le projet. L’abonnement permet de réduire le coût de départ, avec une mensualité définie selon la formule, la durée choisie et les services inclus.'],
            ['question' => 'L’hébergement et la maintenance sont-ils inclus ?', 'answer' => 'Pas toujours. Cela dépend de la formule choisie. Certains abonnements peuvent inclure l’hébergement, la maintenance, les sauvegardes ou la sécurité. Pour un paiement unique, ces services peuvent être ajoutés séparément selon vos besoins.'],
        ], $id);
        update_field('hero_eyebrow', 'Création de site internet', $id);
        update_field('hero_title', 'Un site vitrine sur-mesure, pensé pour convertir', $id);
        update_field('hero_sub', 'Nous concevons des sites WordPress professionnels pour les artisans, TPE et PME à Toulouse comme partout en France, 100 % à distance. Un site responsive et structurée pour présenter votre activité, chaque page est pensée pour valoriser votre activité et faciliter la prise de contact.', $id);
        update_field('hero_cta1_label', 'Demander un devis', $id);
        update_field('hero_cta1_url', '/tarifs/', $id);
        update_field('hero_cta2_label', 'Voir les formules', $id);
        update_field('hero_cta2_url', '#formules', $id);
        update_field('hero_stats', [
            ['label' => 'À partir de', 'value' => '1 190 €'],
            ['label' => 'Formules', 'value' => '5'],
            ['label' => 'Délai', 'value' => '1–8 sem.'],
        ], $id);
        update_field('types_eyebrow', 'Cinq formules', $id);
        update_field('types_title', 'Du plus simple au plus complet vous choisissez le périmètre.', $id);
        update_field('types_lede', 'Chaque formule sert de point de départ. Nous ajustons ensuite le périmètre selon vos besoins, vos contenus, vos objectifs et le niveau d’accompagnement souhaité.', $id);
        update_field('midcta_enabled', true, $id);
        update_field('midcta_strong', 'Pas sûr de la formule à choisir ?', $id);
        update_field('midcta_sub', 'On échange en amont pour vous orienter — sans engagement.', $id);
        update_field('midcta_label', 'Configurer mon devis', $id);
        update_field('midcta_url', '/tarifs/', $id);
        update_field('inex_eyebrow', 'Périmètre', $id);
        update_field('inex_title', 'Ce qui est prévu, ce qui reste en option', $id);
        update_field('inex_lede', 'Chaque projet est cadré avant le démarrage. Les éléments inclus, les options et les prestations complémentaires sont précisés dans le devis.', $id);
        update_field('included_title', 'Ce qui est inclus', $id);
        update_field('included_sub', 'Dans toutes les formules, par défaut.', $id);
        update_field('excluded_title', 'Non inclus par défaut', $id);
        update_field('excluded_sub', 'Disponible en option ou via une prestation séparée.', $id);
        update_field('faq_eyebrow', 'FAQ', $id);
        update_field('faq_title', 'Questions fréquentes sur la création de site', $id);
        update_field('cta_enabled', true, $id);
        update_field('cta_title', 'Prêt à lancer votre site ?', $id);
        update_field('cta_paragraph', 'Décrivez-nous votre projet en quelques lignes : nous vous répondons sous 48h avec un premier retour et un devis clair. Tout se fait en ligne, sans déplacement.', $id);
        update_field('cta_label', 'Demander un devis', $id);
        update_field('cta_url', '/tarifs/', $id);
        update_field('ben_lede', 'Au-delà d\'un simple site, vous gagnez en crédibilité, en visibilité sur Google et en contacts qualifiés.', $id);
        update_field('ben_items', [
            ['icon' => 'compass', 'title' => 'Crédibilité immédiate', 'desc' => 'Un site soigné rassure vos prospects et reflète le sérieux de votre activité dès le premier regard.'],
            ['icon' => 'search', 'title' => 'Préparé pour Google', 'desc' => 'Une structure, des contenus organisés et des bases SEO propres permettent à votre site d’être mieux compris par les moteurs de recherche'],
            ['icon' => 'trend', 'title' => 'Plus de demandes entrantes', 'desc' => 'Formulaires, appels, demandes de devis : un site bien construit facilite la prise de contact et transforme vos visiteurs en prospects.'],
            ['icon' => 'shield', 'title' => 'Accessible à tout moment', 'desc' => 'Votre site présente votre activité, vos services et vos informations essentielles même lorsque vous n’êtes pas disponible.'],
        ], $id);
        update_field('pay_lede', 'Selon votre budget de départ et le niveau d’accompagnement souhaité, vous pouvez régler votre site en une fois ou démarrer avec une formule mensuelle.', $id);
        update_field('meth_lede', 'Chaque projet suit un cadre clair, du premier échange à la mise en ligne.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Comprendre votre activité', 'desc' => 'On échange sur votre métier, vos objectifs et votre cible. Vous nous parlez, nous prenons des notes.'],
            ['num' => '02', 'title' => 'Définir le périmètre', 'desc' => 'Nous préparons l’arborescence, les pages à prévoir, les fonctionnalités, les contenus attendus et le budget avant le démarrage.'],
            ['num' => '03', 'title' => 'Concevoir & rédiger', 'desc' => 'Maquettes, structure des contenus, balises SEO. On valide ensemble avant tout développement.'],
            ['num' => '04', 'title' => 'Développer & mettre en ligne', 'desc' => 'Intégration, tests, recette, mise en production sur un hébergement adapté.'],
            ['num' => '05', 'title' => 'Suivre dans la durée', 'desc' => 'Maintenance, sauvegardes, conseils SEO, ajustements. Votre site continue d\'évoluer.'],
        ], $id);
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Pourquoi un site web', $id);
        update_field('ben_title', 'Un site professionnel pour gagner en crédibilité et en visibilité', $id);
        update_field('pay_enabled', true, $id);
        update_field('pay_eyebrow', 'Deux façons de financer', $id);
        update_field('pay_title', 'Paiement unique ou abonnement, à vous de choisir', $id);
        update_field('pay_uniq_title', 'Payer en une fois', $id);
        update_field('pay_uniq_text', 'Vous financez votre site directement et en devenez pleinement propriétaire. Idéal si vous disposez du budget de départ et préférez un coût maîtrisé, sans engagement dans la durée.', $id);
        update_field('pay_abo_title', 'Démarrer en abonnement', $id);
        update_field('pay_abo_text', 'Vous lancez votre site avec un coût de départ réduit, puis une mensualité. L\'abonnement inclut la création, l\'hébergement, la maintenance et les mises à jour de sécurité. Un engagement est prévu sur les formules mensuelles.', $id);
        update_field('pay_cta_label', 'Comparer les deux modes', $id);
        update_field('pay_cta_url', '/tarifs/', $id);
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Comment ça se passe', $id);
        update_field('meth_title', 'Une méthode, étape par étape', $id);
        update_post_meta($id, 'rank_math_title', 'Création de site vitrine pour TPE & artisans | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Création de site vitrine sur-mesure, responsive et optimisé SEO pour artisans, TPE et PME. À distance depuis la région toulousaine, dès 1190 €. Devis 48h.');
        update_post_meta($id, 'rank_math_focus_keyword', 'création site vitrine');
    }

    // ── consultant-seo ──
    if ($id = evolutionr_seed_get_page_id('consultant-seo')) {
        update_field('packs', [
            ['num' => '02', 'label' => 'SEO Starter', 'offre_ref' => 'seo|SEO Starter|abonnement', 'desc' => 'Pour poser et maintenir des bases SEO propres : suivi de visibilité, optimisation des pages existantes, balises, structure et maillage interne simple.', 'included' => [
            ['text' => 'Suivi mensuel de visibilité'],
            ['text' => 'Optimisation de pages existantes'],
            ['text' => 'Ajustement des balises'],
            ['text' => 'Maillage interne simple'],
            ['text' => 'Reporting synthétique'],
        ], 'featured' => true, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Starter', 'cta_url' => '/tarifs/'],
            ['num' => '03', 'label' => 'SEO Croissance', 'offre_ref' => 'seo|SEO Croissance|abonnement', 'desc' => 'Pour aller plus loin avec un travail régulier sur les mots-clés, les contenus, le maillage interne et les premières actions d’autorité si elles sont pertinentes. ', 'included' => [
            ['text' => 'Recherche de mots-clés approfondie'],
            ['text' => 'Optimisation de pages existantes'],
            ['text' => 'Création ou amélioration d’un contenu SEO'],
            ['text' => 'Recommandations d’autorité / netlinking en option'],
            ['text' => 'Maillage interne renforcé'],
            ['text' => 'Reporting mensuel détaillé'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Croissance', 'cta_url' => '/tarifs/'],
            ['num' => '04', 'label' => 'SEO Performance', 'offre_ref' => 'seo|SEO Performance|abonnement', 'desc' => 'Un accompagnement avancé pour les sites qui veulent accélérer leur visibilité avec une stratégie éditoriale, technique et d’autorité plus poussée.', 'included' => [
            ['text' => 'Stratégie SEO complète'],
            ['text' => 'Plan éditorial'],
            ['text' => 'Suivi concurrentiel approfondi'],
            ['text' => 'Optimisation technique'],
            ['text' => 'Création ou optimisation de contenus'],
            ['text' => 'Optimisation technique ciblée'],
            ['text' => 'Reporting détaillé'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Performance', 'cta_url' => '/tarifs/'],
            ['num' => '01', 'label' => 'Audit SEO ponctuel', 'offre_ref' => 'seo|Audit SEO ponctuel|paiement_unique', 'desc' => 'Analyse du site, des contenus, des bases techniques, des balises, du maillage interne et des premières opportunités SEO. Recommandations priorisées pour savoir quoi corriger en premier.', 'included' => [
            ['text' => 'Analyse complète du site'],
            ['text' => 'Points techniques (vitesse, structure, mobile)'],
            ['text' => 'Analyse contenus et balises'],
            ['text' => 'Recommandations priorisées'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Demander un audit', 'cta_url' => '/tarifs/'],
        ], $id);
        update_field('promesses_limites', [
            ['text' => 'Aucune première position sur Google ne peut être garantie.'],
            ['text' => 'Les résultats dépendent du marché, de la concurrence et de l\'historique du site.'],
            ['text' => 'Le SEO demande du temps : compter plusieurs mois pour des résultats significatifs.'],
            ['text' => 'Le netlinking n’est pas systématique : il dépend de la concurrence, du budget et de la stratégie retenue.'],
            ['text' => 'Les résultats ne sont pas immédiats comme avec une campagne publicitaire'],
        ], $id);
        update_field('faq', [
            ['question' => 'Combien de temps pour voir des résultats SEO ?', 'answer' => 'Comptez généralement 3 à 6 mois pour les premiers signaux significatifs, et 6 à 12 mois pour une progression consolidée. Le SEO est un travail de fond.'],
            ['question' => 'Peut-on garantir la première place sur Google ?', 'answer' => 'Non, et personne ne le peut honnêtement. Nous nous engageons sur la méthode et le travail, pas sur des positions précises qui dépendent de Google. Notre rôle est d’améliorer les bases techniques, les contenus, le maillage, l’autorité du site et le suivi des performances pour augmenter vos chances de progression durable.'],
            ['question' => 'Le SEO est-il inclus dans la création du site ?', 'answer' => 'Oui, les bases SEO sont intégrées lors de la création : structure des pages, balises, hiérarchie des titres, responsive et performance. En revanche, une vraie stratégie SEO mensuelle demande un travail régulier après la mise en ligne.'],
            ['question' => 'Faut-il publier régulièrement du contenu ?', 'answer' => 'Souvent, oui. Le contenu permet de travailler de nouvelles requêtes, de répondre aux questions de vos clients et d’élargir votre visibilité. La fréquence dépend de votre secteur, de la concurrence et de vos objectifs.'],
            ['question' => 'Quelle différence entre audit SEO et accompagnement SEO ?', 'answer' => 'L’audit SEO permet de faire le point à un instant donné : problèmes techniques, contenus, balises, maillage, concurrence et priorités. L’accompagnement SEO va plus loin : il met en œuvre les actions mois après mois et suit les résultats dans la durée.'],
            ['question' => 'Le netlinking est-il inclus dans les packs SEO ?', 'answer' => 'Pas systématiquement. Le netlinking dépend de la concurrence, du budget, des objectifs et du niveau d’accompagnement choisi. Il peut être intégré dans une stratégie d’autorité, mais il doit rester cadré pour privilégier des liens cohérents et utiles.'],
            ['question' => 'Quel pack SEO choisir ?', 'answer' => 'Tout dépend de votre situation. Un audit suffit pour identifier les priorités. Un pack Starter permet de suivre et corriger les bases. Un pack Croissance développe les contenus et les optimisations. Un pack Performance convient aux projets plus concurrentiels avec une stratégie plus complète'],
        ], $id);
        update_field('hero_stats', [
            ['label' => 'À partir de', 'value' => '350 €/mois'],
            ['label' => 'Packs', 'value' => '3 + audit'],
            ['label' => 'Démarrage', 'value' => '1–2 sem.'],
        ], $id);
        update_field('packs_eyebrow', 'Formules SEO', $id);
        update_field('packs_title', 'Audit ponctuel ou suivi mensuel, selon vos besoins', $id);
        update_field('packs_lede', 'Vous pouvez commencer par un audit SEO pour identifier les priorités, ou choisir un accompagnement mensuel pour travailler votre visibilité dans la durée. Les packs SEO sont ajustés selon votre site, votre concurrence et vos objectifs.', $id);
        update_field('midcta_enabled', true, $id);
        update_field('midcta_strong', 'Pas sûr du pack à choisir ?', $id);
        update_field('midcta_sub', 'Un audit SEO ponctuel permet d’identifier les priorités avant de choisir un pack mensuel ou de lancer les premières optimisations.', $id);
        update_field('midcta_label', 'Demander un audit', $id);
        update_field('midcta_url', '/tarifs/', $id);
        update_field('promesses_enabled', true, $id);
        update_field('promesses_eyebrow', 'Honnêteté SEO', $id);
        update_field('promesses_title', 'Nos engagements et nos limites', $id);
        update_field('promesses_lede', 'Le SEO repose sur un travail progressif. Nous nous engageons sur la méthode, la qualité des actions et le suivi, mais jamais sur une position garantie dans Google.', $id);
        update_field('engagements_title', 'Ce sur quoi nous nous engageons', $id);
        update_field('engagements_sub', 'La méthode, le sérieux, la transparence.', $id);
        update_field('engagements_list', [
            ['text' => 'Diagnostic technique et sémantique honnête'],
            ['text' => 'Optimisations conformes aux bonnes pratiques Google'],
            ['text' => 'Actions priorisées selon leur impact potentiel'],
            ['text' => 'Suivi régulier des positions et du trafic organique'],
            ['text' => 'Aucune technique risquée ou artificielle'],
        ], $id);
        update_field('limites_title', 'Ce que nous ne promettons pas', $id);
        update_field('limites_sub', 'Le SEO repose sur un travail progressif, pas sur la magie.', $id);
        update_field('faq_eyebrow', 'FAQ', $id);
        update_field('cta_enabled', true, $id);
        update_field('cta_title', 'Faites le point sur votre référencement', $id);
        update_field('cta_paragraph', 'Vous voulez comprendre pourquoi votre site ne progresse pas sur Google ? Nous analysons votre situation, identifions les priorités et vous proposons les premières actions à mener.', $id);
        update_field('cta_label', 'Auditer mon site', $id);
        update_field('cta_url', '/tarifs/', $id);
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Pourquoi le SEO', $id);
        update_field('ben_title', 'Un levier durable pour attirer des prospects qualifiés', $id);
        update_field('ben_lede', 'Le SEO ne consiste pas seulement à apparaître sur Google. C’est un travail de fond pour rendre votre site plus visible, plus utile pour vos visiteurs et plus efficace dans le temps.', $id);
        update_field('ben_items', [
            ['icon' => 'search', 'title' => 'Trafic qualifié', 'desc' => 'Le référencement naturel attire des visiteurs qui recherchent déjà vos services. L’objectif n’est pas de générer du volume, mais des visites plus pertinentes.'],
            ['icon' => 'trend', 'title' => 'Crédibilité renforcée', 'desc' => 'Un site bien positionné inspire confiance avant même la prise de contact. Votre présence sur Google devient un signal de sérieux pour vos prospects.'],
            ['icon' => 'compass', 'title' => 'Contenus mieux orientés', 'desc' => 'Le travail SEO permet de comprendre ce que vos clients recherchent vraiment, puis d’adapter vos pages, vos titres et vos messages en conséquence.'],
            ['icon' => 'shield', 'title' => 'Investissement long terme', 'desc' => 'Contrairement à la publicité, le SEO construit progressivement un actif durable. Les résultats demandent du temps, mais les optimisations continuent de servir votre site.'],
        ], $id);
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Méthode SEO', $id);
        update_field('meth_title', 'Comment nous travaillons votre référencement', $id);
        update_field('meth_lede', 'Nous partons de l’existant, identifions les priorités, appliquons les optimisations puis mesurons les résultats. Chaque action est expliquée, suivie et ajustée selon l’évolution du site.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Audit SEO complet', 'desc' => 'Analyse technique, contenus, balises, maillage interne, performances, indexation et concurrence. Nous identifions les freins qui limitent la visibilité du site.'],
            ['num' => '02', 'title' => 'Plan d\'action priorisé', 'desc' => 'Nous distinguons les corrections rapides, les optimisations importantes et les chantiers de fond. Vous savez ce qui est prévu, dans quel ordre et pourquoi.'],
            ['num' => '03', 'title' => 'Optimisations SEO', 'desc' => 'Mise en œuvre des actions : balises, structure des pages, contenus, maillage interne, performance technique et corrections prioritaires.'],
            ['num' => '04', 'title' => 'Autorité & opportunités', 'desc' => 'Lorsque c’est pertinent, nous travaillons les signaux d’autorité : recommandations, partenariats, netlinking cadré ou pistes de liens à valider selon le budget.'],
            ['num' => '05', 'title' => 'Suivi et ajustements', 'desc' => 'Suivi des positions, du trafic organique, des pages qui progressent et des points à améliorer. Le plan est ajusté selon les résultats, la concurrence et vos objectifs.'],
        ], $id);
        update_field('hero_sub', 'Votre site existe, mais il ne génère pas assez de trafic qualifié ? Nous analysons ses freins SEO, corrigeons les points prioritaires et mettons en place un suivi régulier pour faire progresser sa visibilité.', $id);
        update_field('hero_eyebrow', 'Référencement naturel (SEO)', $id);
        update_field('hero_title', 'Une stratégie SEO pour rendre votre site plus visible', $id);
        update_field('hero_cta1_label', 'Demander un audit SEO', $id);
        update_field('hero_cta1_url', 'evolutionr/contact/', $id);
        update_field('hero_cta2_label', 'Voir les packs', $id);
        update_field('hero_cta2_url', '#packs', $id);
        update_field('faq_title', 'Questions fréquentes sur le SEO', $id);
        update_post_meta($id, 'rank_math_title', 'Consultant en référencement naturel (SEO) | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Référencement naturel pour TPE, PME et artisans : audit SEO, optimisation et suivi du positionnement pour durer sur Google. Accompagnement 100 % à distance.');
        update_post_meta($id, 'rank_math_focus_keyword', 'référencement naturel');
    }

    // ── maintenance-hebergement ──
    if ($id = evolutionr_seed_get_page_id('maintenance-hebergement')) {
        update_field('packs', [
            ['num' => '01', 'label' => 'Pack Essentiel', 'offre_ref' => 'maintenance_hebergee|Pack Essentiel|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Mises à jour WordPress et extensions'],
            ['text' => 'Sauvegardes régulières'],
            ['text' => 'Surveillance de base'],
            ['text' => 'Restauration en cas de souci'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Sécurité', 'cta_url' => '/tarifs/'],
            ['num' => '02', 'label' => 'Pack Confort', 'offre_ref' => 'maintenance_hebergee|Pack Confort|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Tout le pack Sécurité'],
            ['text' => '30 minutes de modifications par mois'],
            ['text' => 'Corrections au fil de l\'eau'],
            ['text' => 'Assistance prioritaire raisonnable'],
        ], 'featured' => true, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Confort', 'cta_url' => '/tarifs/'],
            ['num' => '03', 'label' => 'Pack Premium', 'offre_ref' => 'maintenance_hebergee|Pack Premium|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Tout le pack Confort'],
            ['text' => 'Jusqu\'à 1h30 de modifications/mois'],
            ['text' => 'Suivi technique renforcé'],
            ['text' => 'Optimisation continue'],
            ['text' => 'Support prioritaire'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Premium', 'cta_url' => '/tarifs/'],
        ], $id);
        update_field('hosting_offers', [
            ['num' => '01', 'label' => 'Pack Externe Essentiel', 'offre_ref' => 'maintenance_seule|Pack Externe Essentiel|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Hébergement web géré'],
            ['text' => 'Certificat SSL inclus'],
            ['text' => 'Sauvegardes automatiques'],
            ['text' => 'Suivi basique'],
            ['text' => 'Assistance accès'],
        ], 'featured' => false, 'featured_label' => 'Recommandé', 'cta_label' => 'Choisir Essentiel', 'cta_url' => '/tarifs/'],
            ['num' => '02', 'label' => 'Pack Externe Confort', 'offre_ref' => 'maintenance_seule|Pack Externe Confort|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Hébergement web géré'],
            ['text' => 'Certificat SSL inclus'],
            ['text' => 'Sauvegardes renforcées'],
            ['text' => 'Surveillance complète'],
            ['text' => 'Assistance prioritaire'],
        ], 'featured' => true, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Choisir Confort', 'cta_url' => '/tarifs/'],
            ['num' => '03', 'label' => 'Pack Externe Premium', 'offre_ref' => 'maintenance_seule|Pack Externe Premium|abonnement', 'desc' => '', 'included' => [
            ['text' => 'Hébergement plus robuste'],
            ['text' => 'Sauvegardes renforcées'],
            ['text' => 'Surveillance complète'],
            ['text' => 'Restauration prioritaire'],
            ['text' => 'Adapté e-commerce léger'],
        ], 'featured' => false, 'featured_label' => 'E-commerce', 'cta_label' => 'Choisir Premium', 'cta_url' => '/tarifs/'],
        ], $id);
        update_field('excluded', [
            ['text' => 'Refonte complète du site'],
            ['text' => 'Ajout de fonctionnalités importantes'],
            ['text' => 'Création de nouvelles pages ou rédaction complète de contenus'],
            ['text' => 'SEO mensuel actif (voir la prestation dédiée)'],
            ['text' => 'Interventions lourdes en dehors du temps inclus'],
            ['text' => 'Résolution de problèmes causés par des modifications externes non prévues'],
        ], $id);
        update_field('faq', [
            ['question' => 'Maintenance ou hébergement, quelle différence ?', 'answer' => 'L’hébergement correspond à l’espace serveur qui permet à votre site d’être accessible en ligne. La maintenance concerne le suivi technique du site : mises à jour WordPress, extensions, sauvegardes, sécurité, vérifications et corrections selon la formule choisie. Les deux services sont complémentaires, mais peuvent être proposés séparément.'],
            ['question' => 'Est-ce obligatoire de maintenir un site WordPress ?', 'answer' => 'Techniquement non, mais fortement recommandé. Un site non maintenu finit par se dégrader, devenir vulnérable aux failles, et peut être piraté ou cassé après une mise à jour ratée. La maintenance permet de limiter les risques et de garder un site fonctionnel.'],
            ['question' => 'Que se passe-t-il si mon site tombe en panne ?', 'answer' => 'Selon la formule choisie, nous analysons l’origine du problème, restaurons une sauvegarde si nécessaire et intervenons pour remettre le site en état. Les délais et le niveau de prise en charge dépendent du contrat de maintenance ou de l’intervention demandée.'],
            ['question' => 'Les sauvegardes sont-elles incluses ?', 'answer' => 'Oui, les sauvegardes peuvent être incluses dans les formules de maintenance. Elles permettent de restaurer le site en cas de problème technique, de mauvaise manipulation ou d’incident. La fréquence et la durée de conservation dépendent de la formule choisie.'],
            ['question' => 'Puis-je prendre uniquement l\'hébergement ?', 'answer' => 'Oui, l\'hébergement et la maintenance sont deux prestations distinctes que vous pouvez prendre séparément ou combiner.'],
            ['question' => 'Puis-je prendre uniquement la maintenance ?', 'answer' => 'Oui également. Vous pouvez garder votre hébergeur actuel et nous confier uniquement le suivi technique de votre site, à condition que l’environnement soit stable et compatible avec nos interventions. Un diagnostic peut être nécessaire avant la mise en place du suivi.'],
            ['question' => 'Les modifications de contenu sont-elles incluses ?', 'answer' => 'Oui, nos formules peuvent inclure un temps dédié aux modifications de contenu : remplacement de textes, changement d’images, ajustements simples ou petites corrections. Ce temps dépend de la formule choisie. Les demandes plus importantes, comme la création de nouvelles pages, la refonte d’une section ou la rédaction complète de contenus, font l’objet d’un devis séparé.'],
        ], $id);
        update_field('hero_stats', [
            ['label' => 'À partir de', 'value' => '79 €/mois'],
            ['label' => 'Packs', 'value' => '3 + 2'],
            ['label' => 'Prise en charge', 'value' => '< 48h'],
        ], $id);
        update_field('packs_enabled', true, $id);
        update_field('packs_eyebrow', 'Pack Maintenance + Hébergement', $id);
        update_field('packs_title', 'Votre site hébergé et maintenu, sans rien à gérer.', $id);
        update_field('packs_lede', 'Hébergement (serveur de base inclus) + maintenance sur nos serveurs : environnement maîtrisé, donc engagements pleins. Mensuel et résiliable.', $id);
        update_field('hosting_enabled', true, $id);
        update_field('hosting_eyebrow', 'Maintenance seule', $id);
        update_field('hosting_title', 'Vous avez déjà votre propre serveur ?', $id);
        update_field('hosting_lede', 'Nous maintenons votre site là où il est hébergé. Environnement non maîtrisé : engagements plus prudents, et éligibilité à valider selon votre infrastructure.', $id);
        update_field('midcta_enabled', true, $id);
        update_field('midcta_strong', 'Pack tout-en-un possible', $id);
        update_field('midcta_sub', 'Maintenance et hébergement combinés dans une seule formule mensuelle.', $id);
        update_field('midcta_label', 'Configurer mon devis', $id);
        update_field('midcta_url', '/tarifs/', $id);
        update_field('distinction_enabled', true, $id);
        update_field('distinction_eyebrow', 'Réversibilité & conditions', $id);
        update_field('distinction_title', 'Pourquoi la maintenance seule peut coûter plus.', $id);
        update_field('excluded_enabled', true, $id);
        update_field('excluded_eyebrow', 'Périmètre', $id);
        update_field('excluded_title', 'Ce qui reste hors forfait', $id);
        update_field('excluded_lede', 'Certaines demandes sortent du cadre de la maintenance ou de l’hébergement standard. Elles peuvent être traitées via une option, un devis ponctuel ou un changement de formule.', $id);
        update_field('excluded_col_title', 'Hors forfait standard', $id);
        update_field('excluded_col_sub', 'Souvent traités via un devis ponctuel ou une formule adaptée.', $id);
        update_field('faq_eyebrow', 'FAQ', $id);
        update_field('cta_enabled', true, $id);
        update_field('cta_title', 'Confiez-nous votre site', $id);
        update_field('cta_paragraph', 'Mises à jour, sauvegardes, sécurité : on s\'occupe de tout pendant que vous gérez votre activité. Dites-nous où en est votre site, réponse sous 48h.', $id);
        update_field('cta_label', 'Demander un devis', $id);
        update_field('cta_url', '/tarifs/', $id);
        update_field('distinction_text', 'Sur nos serveurs, l\'environnement est maîtrisé : le Pack Maintenance + Hébergement est souvent plus avantageux que la maintenance seule sur un serveur tiers, où le travail est moins prévisible (éligibilité à valider au cas par cas). Et vous restez libre : si vous partez un jour, nous assurons la migration sortante de votre site, facturée selon la complexité.', $id);
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Pourquoi maintenir', $id);
        update_field('ben_title', 'Un site fiable, surveillé et prêt à durer', $id);
        update_field('ben_lede', 'Un site WordPress doit être mis à jour, sauvegardé et contrôlé régulièrement. La maintenance évite les problèmes techniques, limite les risques de sécurité et vous permet de rester concentré sur votre activité.', $id);
        update_field('ben_items', [
            ['icon' => 'shield', 'title' => 'Mises à jour contrôlées', 'desc' => 'WordPress, le thème et les extensions sont mis à jour avec attention pour limiter les failles, les bugs et les incompatibilités.'],
            ['icon' => 'compass', 'title' => 'Sauvegardes restaurables', 'desc' => 'Votre site est sauvegardé régulièrement afin de pouvoir être restauré en cas de problème technique, erreur ou incident.'],
            ['icon' => 'trend', 'title' => 'Sécurité surveillée', 'desc' => 'Nous suivons les signaux sensibles : accès, extensions, alertes, scans et correctifs nécessaires selon la formule choisie.'],
            ['icon' => 'search', 'title' => 'Hébergement adapté', 'desc' => 'Votre site repose sur une infrastructure adaptée à ses besoins, avec un suivi technique pour préserver stabilité, accès et performances.'],
        ], $id);
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Cycle mensuel', $id);
        update_field('meth_title', 'Ce que nous vérifions chaque mois', $id);
        update_field('meth_lede', 'Chaque mois, votre site est contrôlé, mis à jour et sauvegardé selon la formule choisie. Vous gardez un site suivi, sans avoir à gérer la technique au quotidien.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Sauvegarde du site', 'desc' => 'Avant les principales interventions, une sauvegarde est réalisée afin de pouvoir restaurer le site en cas de problème.'],
            ['num' => '02', 'title' => 'Mises à jour contrôlées', 'desc' => 'WordPress, le thème et les extensions sont mis à jour avec attention, en tenant compte des compatibilités et du niveau de maintenance prévu.'],
            ['num' => '03', 'title' => 'Vérification du bon fonctionnement', 'desc' => 'Nous contrôlons les éléments essentiels : pages importantes, formulaires, affichage, accès et points sensibles du site.'],
            ['num' => '04', 'title' => 'Sécurité & performances', 'desc' => 'Nous surveillons les signaux importants : alertes de sécurité, disponibilité, lenteurs visibles et anomalies techniques selon la formule choisie.'],
            ['num' => '05', 'title' => 'Ajustements utiles', 'desc' => 'Nous corrigeons les petits points détectés, appliquons les réglages nécessaires et vous signalons les évolutions à prévoir si le site demande une attention particulière.'],
        ], $id);
        update_field('hero_sub', 'Mises à jour, sauvegardes, sécurité et hébergement : nous prenons soin de votre site WordPress pour qu\'il reste rapide et fiable, mois après mois. Un interlocuteur unique, à distance, pour les artisans et TPE de Toulouse et d\'ailleurs.', $id);
        update_field('hero_eyebrow', 'Maintenance & hébergement', $id);
        update_field('hero_title', 'Votre site WordPress entre de bonnes mains', $id);
        update_field('hero_cta1_label', 'Demander une prise en charge', $id);
        update_field('hero_cta1_url', '/tarifs/', $id);
        update_field('hero_cta2_label', 'Voir les packs', $id);
        update_field('hero_cta2_url', '#maintenance', $id);
        update_field('faq_title', 'Questions fréquentes sur la maintenance', $id);
        update_post_meta($id, 'rank_math_title', 'Maintenance WordPress & hébergement web | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Maintenance de site WordPress : mises à jour, sauvegardes, sécurité et hébergement web suivi. Un interlocuteur unique, à distance, pour TPE et artisans.');
        update_post_meta($id, 'rank_math_focus_keyword', 'maintenance WordPress');
    }

    // ── tarifs ──
    if ($id = evolutionr_seed_get_page_id('tarifs')) {
        update_field('hero_stats', [
            ['label' => 'Tarifs', 'value' => 'Transparents'],
            ['label' => 'Devis', 'value' => 'Personnalisé'],
            ['label' => 'Paiement', 'value' => 'Unique ou mensuel'],
        ], $id);
        update_field('hero_eyebrow', 'Tarifs', $id);
        update_field('hero_title', 'Des budgets lisibles pour créer, suivre et faire évoluer votre site', $id);
        update_field('hero_sub', 'Création de site, SEO, maintenance, hébergement ou identité visuelle : nos tarifs donnent une base concrète pour estimer votre projet. Chaque offre peut ensuite être ajustée selon le périmètre, les contenus, les fonctionnalités et le niveau d’accompagnement souhaité.', $id);
        update_field('intro_text', 'Chaque projet dépend de son périmètre : nombre de pages, fonctionnalités, contenus, niveau de SEO, maintenance ou hébergement souhaité. Nos tarifs servent de repères pour choisir une formule adaptée, en paiement unique ou en abonnement mensuel.', $id);
        update_field('cta_title', 'Un projet à estimer ?', $id);
        update_field('cta_paragraph', 'Décrivez-nous votre besoin ou utilisez le configurateur pour obtenir une première base de tarif. Nous vous répondons sous 48 heures ouvrées avec une orientation adaptée à votre projet.', $id);
        update_field('cta_label', 'Estimer mon projet', $id);
        update_field('cta_url', '/contact/', $id);
        update_post_meta($id, 'rank_math_title', 'Prix d\'un site internet — tarifs clairs | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Combien coûte un site internet ? Tarifs transparents dès 1190 €, paiement unique ou mensuel, SEO inclus. Estimez votre projet en ligne. Devis gratuit sous 48h.');
        update_post_meta($id, 'rank_math_focus_keyword', 'prix création site internet');
    }

    // ── contact ──
    if ($id = evolutionr_seed_get_page_id('contact')) {
        update_field('cf7_shortcode', '[contact-form-7 id="942" title="Contact Evolution\'R"]', $id);
        update_field('hero_stats', [
            ['label' => 'Réponse', 'value' => 'Sous 48h'],
            ['label' => 'Devis', 'value' => 'Gratuit'],
            ['label' => 'Demande', 'value' => 'Sans engagement'],
        ], $id);
        update_field('hero_eyebrow', 'Contact', $id);
        update_field('hero_title', 'Présentez-nous votre projet web', $id);
        update_field('hero_sub', "Un site à créer, une refonte, un besoin SEO, une maintenance ou une identité visuelle à travailler ?\nDécrivez-nous votre besoin en quelques minutes. Nous revenons vers vous sous 48 heures ouvrées avec une première orientation ou un devis si les éléments sont suffisants. \nTout se fait à distance, par mail et visio simplement.", $id);
        update_field('delai_title', 'Une réponse utile', $id);
        update_field('delai_text', 'Nous étudions chaque demande sous 48 heures ouvrées. Si votre besoin est suffisamment précis, nous vous envoyons une première estimation ou un devis détaillé. Sinon, nous revenons vers vous avec les questions nécessaires pour cadrer le projet.', $id);
        update_field('zone_title', 'Notre zone d\'intervention', $id);
        update_field('zone_text', "Basés près de Toulouse, nous accompagnons les artisans, TPE et PME de toute la Haute-Garonne, Colomiers, Tournefeuille, Blagnac, Muret, Cugnaux, Balma et alentours et partout en France à distance. Où que vous soyez, le projet se mène en ligne.\n", $id);
        update_field('coords_email_label', 'Par email', $id);
        update_field('coords_phone_label', 'Par téléphone', $id);
        update_post_meta($id, 'rank_math_title', 'Contact — devis gratuit pour votre site | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Contactez Evolution\'R pour votre site internet : devis gratuit sous 48h, 100 % en ligne. Pour artisans, TPE et PME à Toulouse, en Haute-Garonne et partout en France.');
        update_post_meta($id, 'rank_math_focus_keyword', 'contact création site internet');
    }

    // ── a-propos ──
    if ($id = evolutionr_seed_get_page_id('a-propos')) {
        update_field('hero_eyebrow', 'À propos', $id);
        update_field('hero_title', 'Un studio web indépendant pour créer, suivre et faire évoluer votre site', $id);
        update_field('hero_sub', 'Evolution’R est un studio web basé près de Toulouse. Nous accompagnons les artisans, TPE et PME dans la création de site internet, le référencement naturel, la maintenance, l’hébergement et l’identité visuelle avec une méthode structurée, 100 % à distance.', $id);
        update_field('hero_stats', [
            ['label' => 'Réponse', 'value' => 'Sous 48h'],
            ['label' => 'Approche', 'value' => 'Sur-mesure'],
            ['label' => 'Méthode', 'value' => 'À distance'],
        ], $id);
        update_field('app_eyebrow', 'Notre approche', $id);
        update_field('app_title', 'Un partenaire web, pas seulement un prestataire', $id);
        update_field('app_lede', 'Nous pensons qu’un site internet ne doit pas être un simple livrable posé en ligne. C’est un outil de travail qui doit présenter votre activité, rassurer vos visiteurs, rester visible et continuer d’évoluer avec le temps. Notre rôle : concevoir, optimiser et maintenir votre présence en ligne avec un accompagnement simple, structuré et durable.', $id);
        update_field('app_bullets', [
            ['text' => 'Un seul interlocuteur du cadrage à la mise en ligne, puis dans le suivi'],
            ['text' => 'Des sites pensés pour vos visiteurs, votre activité et les bases du référencement'],
            ['text' => 'Un accompagnement possible dans la durée, selon vos besoins réels'],
            ['text' => 'Des conseils compréhensibles, sans jargon inutile ni promesse exagérée'],
        ], $id);
        update_field('eng_eyebrow', 'Nos engagements', $id);
        update_field('eng_title', 'Des engagements simples, tenus dès le premier échange', $id);
        update_field('eng_lede', 'Nous privilégions un cadre lisible, des échanges directs et des décisions compréhensibles. Vous savez ce qui est prévu, ce qui est inclus, et comment votre projet avance.', $id);
        update_field('engagements', [
            ['icon' => 'shield', 'title' => 'Périmètre défini', 'desc' => 'Devis détaillé, prestations cadrées, options identifiées : vous savez ce qui est compris dans le projet avant de vous engager.'],
            ['icon' => 'compass', 'title' => 'Un interlocuteur unique', 'desc' => 'Une seule personne suit votre projet, répond à vos questions et coordonne les étapes, du premier échange à la mise en ligne.'],
            ['icon' => 'trend', 'title' => 'Réactivité réelle', 'desc' => 'Nous répondons sous 48 heures ouvrées, avec un suivi régulier et des retours concrets aux moments importants du projet.'],
            ['icon' => 'search', 'title' => 'Solutions adaptées', 'desc' => 'Nos formules servent de base. Elles peuvent être ajustées selon votre activité, vos objectifs, votre budget et le niveau d’accompagnement souhaité.'],
        ], $id);
        update_field('meth_eyebrow', 'Notre méthode', $id);
        update_field('meth_title', 'Une démarche simple et transparente', $id);
        update_field('meth_lede', 'Chaque projet avance avec une méthode structurée : on comprend, on cadre, on conçoit, on met en ligne, on suit.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Comprendre votre activité', 'timing' => '≈ 30-45 min d\'échange', 'desc' => "Nous collectons les informations essentielles sur votre métier, vos objectifs, vos clients et les besoins réels de votre futur site.\n"],
            ['num' => '02', 'title' => 'Définir le périmètre', 'timing' => 'Sous 5 jours', 'desc' => 'Nous préparons l’arborescence, les pages à prévoir, les contenus attendus, les fonctionnalités et le budget avant le démarrage.'],
            ['num' => '03', 'title' => 'Concevoir et rédiger', 'timing' => '1 à 2 semaines', 'desc' => 'Nous travaillons la structure des pages, les contenus, les bases SEO et les éléments visuels nécessaires pour valoriser votre activité.'],
            ['num' => '04', 'title' => 'Développer et mettre en ligne', 'timing' => '2 à 4 semaines', 'desc' => 'Nous intégrons le site, réalisons les tests, corrigeons les derniers détails et procédons à la mise en ligne sur un hébergement adapté.'],
            ['num' => '05', 'title' => 'Suivre dans la durée', 'timing' => 'En continu', 'desc' => "Maintenance, sauvegardes, sécurité, ajustements et conseils SEO permettent à votre site de rester fiable.\nVotre site continue d'évoluer avec votre activité."],
        ], $id);
        update_field('val_eyebrow', 'Nos principes', $id);
        update_field('val_title', 'Ce qui guide nos choix au quotidien', $id);
        update_field('values', [
            ['icon' => 'compass', 'title' => 'Lisibilité', 'desc' => 'Des échanges compréhensibles, des devis détaillés et des décisions expliquées. Vous savez ce qui est prévu, pourquoi c’est fait et comment le projet avance.'],
            ['icon' => 'shield', 'title' => 'Fiabilité', 'desc' => 'Nous privilégions des solutions stables, maintenables et adaptées à votre activité. L’objectif : un site qui reste propre, fonctionnel et évolutif dans le temps.'],
            ['icon' => 'search', 'title' => 'Utilité', 'desc' => 'Pas de fonctionnalités inutiles. Chaque page, chaque section et chaque choix technique doivent servir un objectif concret pour votre activité.'],
            ['icon' => 'trend', 'title' => 'Honnêteté', 'desc' => 'Si une demande n’est pas pertinente, nous le disons. Si une option n’est pas nécessaire, nous ne la poussons pas. Pas de promesse exagérée, pas de vente forcée.'],
        ], $id);
        update_field('cta_title', 'Discutons de votre projet web', $id);
        update_field('cta_paragraph', 'Un site à créer, une refonte, un besoin de visibilité ou un suivi technique ? Présentez-nous votre projet : nous vous répondons sous 48 heures avec une première orientation utile, sans engagement.', $id);
        update_field('cta_primary_label', 'Présenter mon projet', $id);
        update_field('cta_primary_url', '/evolutionr/contact/', $id);
        update_post_meta($id, 'rank_math_title', 'À propos — studio web indépendant près de Toulouse | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Evolution\'R, studio web indépendant près de Toulouse : création de sites, SEO et maintenance pour TPE, PME et artisans, 100 % à distance. Un interlocuteur unique.');
        update_post_meta($id, 'rank_math_focus_keyword', 'studio web Toulouse');
    }

    // ── identite-visuelle ──
    if ($id = evolutionr_seed_get_page_id('identite-visuelle')) {
        update_field('hero_eyebrow', 'Identité visuelle', $id);
        update_field('hero_title', 'Un logo et une image qui vous ressemblent', $id);
        update_field('hero_sub', 'Création de logo, charte graphique et identité de marque pour donner à votre activité une image cohérente et professionnelle. Du logo seul à l\'identité complète, des visuels adaptés à vos supports.', $id);
        update_field('hero_cta1_label', 'Demander un devis', $id);
        update_field('hero_cta1_url', '/tarifs/', $id);
        update_field('hero_stats', [
            ['label' => 'Logo', 'value' => '690 €'],
            ['label' => 'Délai', 'value' => '2-4 sem.'],
            ['label' => 'Fichiers', 'value' => 'SVG·AI·PNG'],
        ], $id);
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Notre approche', $id);
        update_field('ben_title', 'Une identité visuelle pensée pour durer', $id);
        update_field('ben_lede', 'Un logo ne se limite pas à un dessin. Il doit être lisible, mémorisable et utilisable sur tous vos supports. Nous construisons une identité visuelle cohérente, avec des choix graphiques adaptés à votre activité, votre positionnement et vos futurs usages.', $id);
        update_field('ben_items', [
            ['icon' => 'palette', 'title' => 'Logo professionnel', 'desc' => 'Création d’un logo sur mesure, avec propositions créatives, ajustements et livraison des fichiers adaptés à vos usages web et print.'],
            ['icon' => 'layers', 'title' => 'Charte graphique', 'desc' => 'Définition des couleurs, typographies, règles d’utilisation et déclinaisons pour garder une image cohérente sur tous vos supports.'],
            ['icon' => 'compass', 'title' => 'Identité complète', 'desc' => 'Logo, charte, déclinaisons web, papeterie ou supports de communication : nous préparons les éléments nécessaires pour une image professionnelle.'],
            ['icon' => 'trend', 'title' => 'Refonte de logo', 'desc' => 'Nous modernisons votre logo existant sans repartir de zéro, en conservant ce qui fonctionne et en corrigeant ce qui affaiblit votre image.'],
        ], $id);
        update_field('packs_eyebrow', 'Nos formules', $id);
        update_field('packs_title', '3 niveaux d\'engagement, selon votre besoin', $id);
        update_field('packs_lede', 'Que vous démarriez ou que vous souhaitiez professionnaliser une image existante, il y a un niveau adapté à votre projet et votre budget.', $id);
        update_field('packs', [
            ['num' => '01', 'label' => 'Logo seul', 'offre_ref' => 'logo|Logo seul|paiement_unique', 'desc' => 'Le logo, vectorisé et prêt à l\'emploi. Idéal si vous démarrez votre activité ou si vous voulez rafraîchir votre image sans tout refaire.', 'included' => [
            ['text' => '3 directions créatives proposées'],
            ['text' => '2 séances de retours pour affiner'],
            ['text' => 'Fichiers vectoriels (SVG, AI) + adaptés (PNG, PDF)'],
            ['text' => 'Délai : 2 à 4 semaines'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '02', 'label' => 'Logo + charte graphique', 'offre_ref' => 'logo|Logo + charte graphique|paiement_unique', 'desc' => 'Le logo plus le document qui cadre votre identité dans la durée : couleurs, typographies, règles d\'usage.', 'included' => [
            ['text' => 'Tout ce qui est inclus dans le pack Logo seul'],
            ['text' => 'Palette de couleurs définie et justifiée'],
            ['text' => 'Typographies titre et corps choisies'],
            ['text' => 'Charte graphique PDF'],
        ], 'featured' => true, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Demander un devis', 'cta_url' => '/tarifs/'],
            ['num' => '03', 'label' => 'Identité complète', 'offre_ref' => 'logo|Identité complète|paiement_unique', 'desc' => 'Logo + charte + papeterie + déclinaisons web : tout ce qu\'il faut pour une marque immédiatement professionnelle sur tous vos supports.', 'included' => [
            ['text' => 'Tout ce qui est inclus dans le pack Logo + charte'],
            ['text' => 'Papeterie : carte de visite, papier en-tête, signature email'],
            ['text' => 'Déclinaisons web : favicon, images réseaux sociaux'],
            ['text' => 'Iconographie et illustrations sur-mesure si besoin'],
        ], 'featured' => false, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Discuter du projet', 'cta_url' => '/contact/'],
        ], $id);
        update_field('midcta_enabled', true, $id);
        update_field('midcta_strong', 'Pas sûr du niveau qu\'il vous faut ?', $id);
        update_field('midcta_sub', 'Décrivez-nous votre activité, nous vous orientons vers la formule juste.', $id);
        update_field('midcta_label', 'Demander conseil', $id);
        update_field('midcta_url', '/tarifs/', $id);
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Notre méthode', $id);
        update_field('meth_title', 'Comment nous concevons votre identité', $id);
        update_field('meth_lede', 'Nous avançons étape par étape : cadrage, recherches graphiques, propositions, ajustements puis livraison des fichiers. Vous validez les grandes étapes avant la finalisation.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Cadrage de l’identité', 'desc' => 'Nous faisons le point sur votre activité, vos valeurs, vos supports, vos concurrents et l’image que votre marque doit transmettre.'],
            ['num' => '02', 'title' => 'Recherches graphiques', 'desc' => 'Nous explorons plusieurs pistes visuelles : inspirations, formes, typographies, couleurs et univers adaptés à votre positionnement.'],
            ['num' => '03', 'title' => 'Propositions créatives', 'desc' => 'Nous vous présentons les pistes les plus pertinentes, avec une explication des choix graphiques pour vous aider à choisir la bonne direction.'],
            ['num' => '04', 'title' => 'Ajustements', 'desc' => 'Nous affinons la piste retenue : couleurs, formes, détails, lisibilité et déclinaisons selon les supports prévus.'],
            ['num' => '05', 'title' => 'Livraison des fichiers', 'desc' => 'Nous livrons les fichiers adaptés à vos usages web et print, accompagnés des indications nécessaires pour utiliser votre identité correctement.'],
        ], $id);
        update_field('faq_eyebrow', 'Questions fréquentes', $id);
        update_field('faq_title', 'Vos questions sur l\'identité visuelle', $id);
        update_field('faq', [
            ['question' => 'Combien de temps pour créer un logo ?', 'answer' => 'Comptez généralement 2 à 4 semaines selon le niveau de prestation, le nombre d’allers-retours et la rapidité des validations. Une identité complète demande plus de temps qu’un logo seul, car elle inclut davantage de déclinaisons et de règles d’utilisation.'],
            ['question' => 'Que reçoit-on à la fin du projet ?', 'answer' => 'Vous recevez les fichiers adaptés aux usages prévus : web, impression, réseaux sociaux ou documents professionnels. Selon la formule, la livraison peut inclure les formats PNG, SVG, PDF ou AI, ainsi que les déclinaisons nécessaires.'],
            ['question' => 'Puis-je faire évoluer mon logo plus tard ?', 'answer' => 'Oui. Un logo peut être adapté ou enrichi avec le temps : nouvelles déclinaisons, variantes pour les réseaux sociaux, supports imprimés, signalétique ou évolution de la charte graphique.'],
            ['question' => 'Combien de propositions sont incluses ?', 'answer' => 'Le nombre de pistes créatives dépend de la formule choisie. L’objectif n’est pas de multiplier les versions, mais de présenter des directions pertinentes, expliquées et adaptées à votre activité.'],
            ['question' => 'Les retours et corrections sont-ils inclus ?', 'answer' => 'Oui, des ajustements sont prévus sur la piste retenue : couleurs, typographies, détails, lisibilité ou déclinaisons. Les demandes qui changent complètement la direction validée peuvent faire l’objet d’un cadrage complémentaire.'],
            ['question' => 'Puis-je demander uniquement un logo ?', 'answer' => 'Oui. Vous pouvez demander un logo seul si vous avez simplement besoin d’une base professionnelle. Si vous souhaitez une image plus complète et cohérente sur plusieurs supports, une charte graphique ou une identité complète sera plus adaptée.'],
            ['question' => 'Les fichiers sont-ils utilisables par un imprimeur ?', 'answer' => 'Oui, les fichiers peuvent être fournis dans des formats adaptés à l’impression lorsque c’est prévu dans la prestation. Cela permet de les utiliser pour des cartes de visite, flyers, enseignes, documents ou autres supports professionnels.'],
            ['question' => 'Les droits d’utilisation sont-ils prévus ?', 'answer' => 'Oui, les droits d’utilisation des créations livrées sont cadrés dans le devis ou le contrat. Les éléments tiers éventuels, comme certaines typographies ou ressources sous licence, restent soumis à leurs propres conditions d’utilisation.'],
        ], $id);
        update_field('cta_enabled', true, $id);
        update_field('cta_title', 'Donnons une image à votre activité', $id);
        update_field('cta_paragraph', 'Un logo à créer, une identité à formaliser ? Décrivez-nous votre projet : premier retour sous 48h, à distance, sans engagement.', $id);
        update_field('cta_label', 'Discuter du projet', $id);
        update_field('cta_url', '/tarifs/', $id);
        update_field('hero_cta2_label', 'Voir les packs', $id);
        update_field('hero_cta2_url', '#packs', $id);
        update_post_meta($id, 'rank_math_title', 'Création de logo & charte graphique | Evolution\'R');
        update_post_meta($id, 'rank_math_description', 'Création de logo et d\'identité visuelle pour artisans, TPE et PME : une image de marque claire, cohérente et déclinable sur tous vos supports. À distance, sur devis.');
        update_post_meta($id, 'rank_math_focus_keyword', 'création de logo');
    }

}

/**
 * Crée les 4 catégories de blog miroir-services si elles n'existent pas.
 *
 * Les slugs sont stables (pas de migration ultérieure prévue). Les libellés
 * et descriptions seedés peuvent être édités dans Articles → Catégories.
 * Idempotence : on n'écrase jamais une catégorie existante (même slug).
 *
 * Pattern aligné sur le change `add-navigation-and-blog`, capability
 * `blog-listing` (cf. `openspec/changes/add-navigation-and-blog/`).
 */
function evolutionr_seed_blog_categories(): void
{
    $categories = [
        [
            'slug'        => 'creation',
            'name'        => 'Création de site web',
            'description' => "Articles sur la création de sites vitrines, refontes et conception web.",
        ],
        [
            'slug'        => 'seo',
            'name'        => 'Référencement naturel',
            'description' => "Conseils SEO, optimisations on-page, stratégies de contenu.",
        ],
        [
            'slug'        => 'maintenance',
            'name'        => 'Maintenance & hébergement',
            'description' => "Sécurité, sauvegardes, mises à jour, hébergement web.",
        ],
        [
            'slug'        => 'identite-visuelle',
            'name'        => 'Identité visuelle',
            'description' => "Logo, charte graphique, identité de marque.",
        ],
    ];

    foreach ($categories as $cat) {
        if (term_exists($cat['slug'], 'category')) {
            continue;
        }
        wp_insert_term(
            $cat['name'],
            'category',
            [
                'slug'        => $cat['slug'],
                'description' => $cat['description'],
            ]
        );
    }
}

/**
 * Crée la page « À propos » (slug `a-propos`) si elle n'existe pas et
 * remplit tous les champs ACF du groupe `group_evor_page_about` avec un
 * contenu seedé en voix « nous » institutionnel (sans mention d'équipe).
 *
 * Idempotence : `evolutionr_seed_get_or_create_page` retourne l'ID
 * existant si la page est déjà là, et les `update_field` n'écrasent qu'à
 * la première exécution (gardée par l'option `evolutionr_about_seeded`).
 *
 * Pattern aligné sur le change `add-about-page`, capability `about-page`.
 */
function evolutionr_seed_about_page(): void
{
    $id = evolutionr_seed_get_or_create_page("À propos", 'a-propos');
    if (!$id) return;

    if (!evolutionr_acf_is_active()) return;

    // ─── Hero ─────────────────────────────────────────────────────
    update_field('hero_eyebrow', 'À propos', $id);
    update_field('hero_title', "Une présence en ligne claire, fiable et durable", $id);
    update_field('hero_sub', "Evolution'R est une agence web et consultant SEO indépendant. Nous accompagnons les entreprises, indépendants et associations dans la création, le référencement et la maintenance de leur site internet — avec un interlocuteur unique, du début à la fin.", $id);
    update_field('hero_stats', [
        ['label' => 'Réponse',     'value' => 'Sous 48h'],
        ['label' => 'Approche',    'value' => 'Sur-mesure'],
        ['label' => 'Engagement',  'value' => 'Aucun'],
    ], $id);

    // ─── Approche ──────────────────────────────────────────────────
    update_field('app_eyebrow', 'Notre approche', $id);
    update_field('app_title', 'Un partenaire web, pas seulement un prestataire', $id);
    update_field('app_lede', "Nous croyons qu'un site internet ne se limite pas à un livrable. C'est un outil vivant, qui doit servir votre activité sur la durée. Notre rôle : le concevoir, le rendre visible, et le maintenir en bonne santé — sans que vous ayez à vous en soucier.", $id);
    update_field('app_bullets', [
        ['text' => 'Un seul interlocuteur du cadrage à la mise en ligne et au-delà.'],
        ['text' => "Des sites pensés pour vos visiteurs et conçus pour Google dès la première ligne."],
        ['text' => "Un accompagnement dans la durée, pas un livrable qu'on oublie."],
        ['text' => "Aucun jargon, aucune promesse exagérée — un discours clair et honnête."],
    ], $id);

    // ─── Engagements ───────────────────────────────────────────────
    update_field('eng_eyebrow', 'Nos engagements', $id);
    update_field('eng_title', 'Ce que nous vous promettons', $id);
    update_field('eng_lede', "Des engagements concrets, mesurables, et tenus dès le premier échange.", $id);
    update_field('engagements', [
        ['icon' => 'shield',  'title' => 'Transparence totale',     'desc' => "Devis détaillé, périmètre clair, aucune zone d'ombre. Vous savez ce que vous payez et pourquoi."],
        ['icon' => 'compass', 'title' => 'Un interlocuteur unique', 'desc' => "Une seule personne pour comprendre votre projet, le piloter, et répondre à vos questions — sans transfert d'équipe à équipe."],
        ['icon' => 'trend',   'title' => 'Réactivité réelle',       'desc' => "Réponse sous 48 heures ouvrées, devis sous quelques jours, suivi sans relance de votre part."],
        ['icon' => 'search',  'title' => 'Solutions adaptées',      'desc' => "Pas de pack standard imposé : nous proposons ce qui sert votre activité, à votre rythme et à votre budget."],
    ], $id);

    // ─── Méthodes ──────────────────────────────────────────────────
    update_field('meth_eyebrow', 'Notre méthode', $id);
    update_field('meth_title', 'Une démarche simple et transparente', $id);
    update_field('meth_lede', "Chaque projet suit le même cadre clair : on comprend, on cadre, on conçoit, on met en ligne, on suit.", $id);
    update_field('meth_steps', [
        ['num' => '01', 'title' => 'Comprendre votre activité',  'timing' => "≈ 1h d'échange", 'desc' => "On échange sur votre métier, vos objectifs, votre cible. Vous nous parlez, nous prenons des notes — c'est la base de tout."],
        ['num' => '02', 'title' => 'Cadrer le projet',           'timing' => 'Sous 2 à 5 jours', 'desc' => "Nous vous proposons une arborescence, un périmètre clair, un devis détaillé. Aucune zone d'ombre avant signature."],
        ['num' => '03', 'title' => 'Concevoir et rédiger',       'timing' => '1 à 2 semaines', 'desc' => "Maquettes, structure des contenus, balises SEO. On valide ensemble chaque étape avant tout développement."],
        ['num' => '04', 'title' => 'Développer et mettre en ligne', 'timing' => '2 à 4 semaines', 'desc' => "Intégration, tests, recette, mise en production sur un hébergement adapté. Votre site va vivre dans de bonnes conditions."],
        ['num' => '05', 'title' => 'Suivre dans la durée',       'timing' => 'En continu', 'desc' => "Maintenance, sauvegardes, conseils SEO, ajustements. Votre site continue d'évoluer avec votre activité."],
    ], $id);

    // ─── Valeurs ───────────────────────────────────────────────────
    update_field('val_eyebrow', 'Nos valeurs', $id);
    update_field('val_title', 'Ce qui guide nos choix au quotidien', $id);
    update_field('values', [
        ['icon' => 'compass', 'title' => 'Clarté',     'desc' => "Un discours sans jargon, des devis compréhensibles, des décisions justifiées. Vous savez toujours où vous en êtes."],
        ['icon' => 'shield',  'title' => 'Durabilité', 'desc' => "Nous construisons pour le long terme : technologies pérennes, code maintenable, choix qui tiennent dans le temps."],
        ['icon' => 'search',  'title' => 'Utilité',    'desc' => "Pas de fonctionnalités gadget. Chaque ligne de code, chaque section, chaque mot sert un objectif concret pour votre activité."],
        ['icon' => 'trend',   'title' => 'Honnêteté',  'desc' => "Si un projet n'est pas pour nous, nous le disons. Si une demande n'est pas pertinente, nous le disons. Pas de vente forcée."],
    ], $id);

    // ─── CTA final ─────────────────────────────────────────────────
    update_field('cta_title', 'Discutons de votre projet', $id);
    update_field('cta_paragraph', "Une idée, une refonte, un besoin de visibilité ? Décrivez-nous votre projet : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.", $id);
    update_field('cta_primary_label', 'Démarrer mon projet', $id);
    update_field('cta_primary_url', '/contact/', $id);
}

/**
 * Seede les sections de la page « Identité visuelle » (slug `identite-visuelle`)
 * sur le groupe ACF `group_evor_page_identite_visuelle`. Calque les autres pages
 * prestation : Hero / Bénéfices / Packs / Mid-CTA / Méthode / FAQ / CTA final.
 *
 * Idempotent : chaque section n'est posée que si son repeater pivot est vide
 * (respect d'une édition BO). Le prix du pack « Logo seul » est initialisé
 * depuis le tarif central (`evolutionr_get_pricing()`, option `creation_logo`,
 * fallback 690 €), puis devient éditable indépendamment dans l'ACF de la page.
 */
function evolutionr_seed_identite_visuelle_page(): void
{
    if (!evolutionr_acf_is_active()) return;

    // Lookup par slug insensible à la hiérarchie (la page est enfant de
    // `prestations`, donc get_page_by_path('identite-visuelle') échouerait).
    $id = evolutionr_seed_get_or_create_page('Identité visuelle', 'identite-visuelle');
    if (!$id) return;

    // Prix du logo depuis la source de vérité Tarifs (fallback 690 €).
    $logoBasePrice = 690.0;
    if (function_exists('evolutionr_get_pricing')) {
        $pricing = evolutionr_get_pricing();
        foreach (($pricing['options'] ?? []) as $cle => $opt) {
            if ($cle === 'creation_logo' || ($opt['label'] ?? '') === 'Création de logo') {
                $logoBasePrice = (float) $opt['price'];
                break;
            }
        }
    }
    $logoPriceFmt = number_format($logoBasePrice, 0, ',', "\u{202f}") . "\u{202f}€";

    // ─── Hero ──────────────────────────────────────────────────────
    if (!get_field('hero_sub', $id)) {
        update_field('hero_eyebrow', 'Identité visuelle', $id);
        update_field('hero_title', 'Une identité de marque claire et mémorable', $id);
        update_field('hero_sub', "Création de logo, charte graphique et identité de marque pour donner à votre activité une image cohérente et professionnelle. Du logo seul à l'identité complète, nous concevons des visuels durables, déclinables sur tous vos supports.", $id);
        update_field('hero_cta1_label', 'Demander un devis', $id);
        update_field('hero_cta1_url', '/contact/', $id);
        update_field('hero_stats', [
            ['label' => 'Logo',      'value' => $logoPriceFmt],
            ['label' => 'Délai',     'value' => '2-4 sem.'],
            ['label' => 'Livraison', 'value' => 'SVG·AI·PNG'],
        ], $id);
    }

    // ─── Bénéfices (partial presta-benefices) ──────────────────────
    if (empty(get_field('ben_items', $id))) {
        update_field('ben_enabled', true, $id);
        update_field('ben_eyebrow', 'Notre approche', $id);
        update_field('ben_title', 'Une identité claire, cohérente et durable', $id);
        update_field('ben_lede', "Un logo n'est pas qu'un dessin : c'est la première chose que vos prospects retiennent. Nous concevons des visuels lisibles, mémorables et déclinables, pensés pour vivre sur tous vos supports : site internet, papeterie, signalétique, réseaux sociaux.", $id);
        update_field('ben_items', [
            ['icon' => 'palette', 'title' => 'Logo professionnel', 'desc' => "3 directions créatives proposées, allers-retours pour affinage, livraison en formats vectoriels (SVG, AI) et adaptés (PNG, PDF)."],
            ['icon' => 'layers',  'title' => 'Charte graphique',   'desc' => "Couleurs, typographies, déclinaisons : un document cadre pour que votre marque garde sa cohérence partout, dans le temps."],
            ['icon' => 'compass', 'title' => 'Identité complète',  'desc' => "Logo + charte + papeterie + déclinaisons web : tout ce qu'il faut pour une marque immédiatement professionnelle."],
            ['icon' => 'trend',   'title' => 'Refonte de logo',    'desc' => "Vous avez déjà un logo mais il ne vous ressemble plus ? Nous le rafraîchissons en conservant ce qui marche et en corrigeant ce qui pèse."],
        ], $id);
    }

    // ─── Packs ─────────────────────────────────────────────────────
    if (empty(get_field('packs', $id))) {
        update_field('packs_eyebrow', 'Nos formules', $id);
        update_field('packs_title', "3 niveaux d'engagement, selon votre besoin", $id);
        update_field('packs_lede', 'Que vous démarriez ou que vous souhaitiez professionnaliser une image existante, il y a un niveau adapté à votre projet et votre budget.', $id);
        update_field('packs', [
            [
                'num' => '01', 'label' => 'Logo seul', 'offre_ref' => 'logo|Logo seul|paiement_unique',
                'desc' => "Le logo, vectorisé et prêt à l'emploi. Idéal si vous démarrez votre activité ou si vous voulez rafraîchir votre image sans tout refaire.",
                'included' => [
                    ['text' => '3 directions créatives proposées'],
                    ['text' => '2 séances de retours pour affiner'],
                    ['text' => 'Fichiers vectoriels (SVG, AI) + adaptés (PNG, PDF)'],
                    ['text' => 'Délai : 2 à 4 semaines'],
                ],
                'featured' => false, 'cta_label' => 'Demander un devis', 'cta_url' => '/contact/',
            ],
            [
                'num' => '02', 'label' => 'Logo + charte graphique', 'offre_ref' => 'logo|Logo + charte graphique|paiement_unique',
                'desc' => "Le logo plus le document qui cadre votre identité dans la durée : couleurs, typographies, règles d'usage.",
                'included' => [
                    ['text' => 'Tout ce qui est inclus dans le pack Logo seul'],
                    ['text' => 'Palette de couleurs définie et justifiée'],
                    ['text' => 'Typographies titre et corps choisies'],
                    ['text' => 'Charte graphique PDF (8 à 12 pages)'],
                ],
                'featured' => true, 'featured_label' => 'Le plus choisi', 'cta_label' => 'Demander un devis', 'cta_url' => '/contact/',
            ],
            [
                'num' => '03', 'label' => 'Identité complète', 'offre_ref' => 'logo|Identité complète|paiement_unique',
                'desc' => "Logo + charte + papeterie + déclinaisons web : tout ce qu'il faut pour une marque immédiatement professionnelle sur tous vos supports.",
                'included' => [
                    ['text' => 'Tout ce qui est inclus dans le pack Logo + charte'],
                    ['text' => 'Papeterie : carte de visite, papier en-tête, signature email'],
                    ['text' => 'Déclinaisons web : favicon, images réseaux sociaux'],
                    ['text' => 'Iconographie et illustrations sur-mesure si besoin'],
                ],
                'featured' => false, 'cta_label' => 'Discuter du projet', 'cta_url' => '/contact/',
            ],
        ], $id);
    }

    // ─── Mid-CTA ───────────────────────────────────────────────────
    if (!get_field('midcta_strong', $id)) {
        update_field('midcta_enabled', true, $id);
        update_field('midcta_strong', "Pas sûr du niveau qu'il vous faut ?", $id);
        update_field('midcta_sub', 'Décrivez-nous votre activité, nous vous orientons vers la formule juste.', $id);
        update_field('midcta_label', 'Demander conseil', $id);
        update_field('midcta_url', '/contact/', $id);
    }

    // ─── Méthode (partial presta-methode) ──────────────────────────
    if (empty(get_field('meth_steps', $id))) {
        update_field('meth_enabled', true, $id);
        update_field('meth_eyebrow', 'Notre méthode', $id);
        update_field('meth_title', 'Comment nous concevons votre identité', $id);
        update_field('meth_lede', 'Une démarche créative cadrée, du brief à la livraison des fichiers. Vous validez à chaque étape.', $id);
        update_field('meth_steps', [
            ['num' => '01', 'title' => 'Brief & immersion',     'desc' => "On échange sur votre activité, vos valeurs, vos goûts et vos concurrents. On définit ensemble ce que votre marque doit dégager."],
            ['num' => '02', 'title' => 'Exploration créative',  'desc' => "Recherches, pistes, moodboards. On explore plusieurs directions avant de présenter les plus pertinentes."],
            ['num' => '03', 'title' => 'Propositions',          'desc' => "3 directions créatives présentées et expliquées. Vous choisissez celle qui vous correspond le plus."],
            ['num' => '04', 'title' => 'Affinage',              'desc' => "Allers-retours sur la piste retenue : couleurs, formes, détails. On peaufine jusqu'à ce que ce soit juste."],
            ['num' => '05', 'title' => 'Livraison & guide',     'desc' => "Fichiers vectoriels et adaptés, plus un guide d'utilisation pour décliner votre identité partout, sans faux pas."],
        ], $id);
    }

    // ─── FAQ ───────────────────────────────────────────────────────
    if (empty(get_field('faq', $id))) {
        update_field('faq_eyebrow', 'Questions fréquentes', $id);
        update_field('faq_title', "Vos questions sur l'identité visuelle", $id);
        update_field('faq', [
            ['question' => 'Combien de temps pour créer un logo ?', 'answer' => "Comptez en général 2 à 4 semaines entre le brief et la livraison des fichiers, selon le nombre d'allers-retours et votre disponibilité pour valider les étapes."],
            ['question' => 'Que reçois-je à la fin ?', 'answer' => "Vos fichiers en formats vectoriels (SVG, AI) pour l'impression et le grand format, et en formats adaptés (PNG, PDF) pour le web et la bureautique. Avec la charte, vous recevez aussi un document d'utilisation."],
            ['question' => 'Puis-je faire évoluer mon logo plus tard ?', 'answer' => "Oui. Un logo bien conçu est pensé pour durer, mais il peut être décliné ou rafraîchi. Nous conservons vos fichiers sources pour faciliter toute évolution future."],
        ], $id);
    }

    // ─── CTA final ─────────────────────────────────────────────────
    if (!get_field('cta_title', $id)) {
        update_field('cta_enabled', true, $id);
        update_field('cta_title', 'Parlons de votre identité visuelle', $id);
        update_field('cta_paragraph', "Un logo à créer, une charte à formaliser, une identité complète à concevoir ? Décrivez-nous votre projet : nous vous répondons sous 48 heures avec un premier retour honnête, sans engagement.", $id);
        update_field('cta_label', 'Demander un devis', $id);
        update_field('cta_url', '/contact/', $id);
    }
}

/**
 * Remplace la 4e card de `services_cards` sur la front-page :
 *   « 04 — TARIFS / Configurer votre devis » → « 04 — IDENTITÉ VISUELLE / Identité visuelle »
 *
 * Idempotent et non destructif : ne touche la card 04 que si son titre actuel
 * est « Configurer votre devis » ou si son numéro contient « TARIFS ». Si
 * l'utilisateur a renommé manuellement la card 04, le seeder respecte ce choix.
 *
 * Cf. change `add-identite-visuelle-service`, décision D1.
 */
function evolutionr_seed_identite_visuelle_home_card(): void
{
    $front_id = (int) get_option('page_on_front');
    if (!$front_id || !evolutionr_acf_is_active()) {
        return;
    }

    $cards = get_field('services_cards', $front_id);
    if (!is_array($cards) || count($cards) < 4) {
        return;
    }

    $card4 = $cards[3] ?? [];
    $title4  = (string) ($card4['title'] ?? '');
    $number4 = (string) ($card4['number'] ?? '');

    $isTarifsCard = (str_contains($title4, 'Configurer votre devis')
        || stripos($number4, 'TARIFS') !== false);

    if (!$isTarifsCard) {
        return; // édition manuelle de l'utilisateur — on respecte
    }

    $cards[3] = [
        'number'    => '04 — IDENTITÉ VISUELLE',
        'icon'      => 'palette',
        'title'     => 'Identité visuelle',
        'excerpt'   => 'Création de logo, charte graphique et identité de marque pour donner à votre activité une image cohérente et professionnelle.',
        'bullets'   => [
            ['text' => 'Logo seul ou identité complète'],
            ['text' => 'Charte graphique cohérente avec votre site'],
            ['text' => 'Fichiers vectoriels livrés (SVG, AI)'],
        ],
        'cta_label' => "Découvrir l'identité visuelle",
        'cta_url'   => '/prestations/identite-visuelle/',
    ];

    update_field('services_cards', $cards, $front_id);
}

/**
 * Ajoute une ligne « Création de logo » au repeater `options` de la page
 * d'options « Tarifs Evolution'R ». Forfait simple à 690 € par défaut.
 *
 * Idempotent : si une option dont la clé est `creation_logo` ou dont le
 * libellé est « Création de logo » existe déjà, aucun ajout n'est effectué.
 *
 * Cf. change `add-identite-visuelle-service`, décision D4.
 */
function evolutionr_seed_identite_visuelle_pricing(): void
{
    if (!evolutionr_acf_is_active()) {
        return;
    }

    $options = get_field('options', 'option');
    if (!is_array($options)) {
        $options = [];
    }

    foreach ($options as $opt) {
        $key   = (string) ($opt['cle'] ?? '');
        $label = (string) ($opt['label'] ?? '');
        if ($key === 'creation_logo' || $key === 'identite-visuelle') {
            return;
        }
        if (mb_strtolower(trim($label)) === 'création de logo') {
            return;
        }
    }

    $options[] = [
        'label'              => 'Création de logo',
        'unite'              => 'forfait',
        'prix'               => 690,
        'actif'              => true,
        'description'        => 'Logo professionnel : 3 propositions, allers-retours, fichiers vectoriels livrés.',
        'description_detail' => "Comprend : 3 directions créatives proposées, 2 séances de retours pour affinage, livraison en formats vectoriels (SVG, AI) et adaptés (PNG, PDF). Si une charte graphique complète vous intéresse (couleurs, typographies, déclinaisons), nous établissons un devis dédié.",
        'cle'                => 'creation_logo',
    ];

    update_field('options', $options, 'option');
}
