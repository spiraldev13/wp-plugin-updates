<?php
/**
 * Template — Page « Identité visuelle » (slug `identite-visuelle`).
 *
 * Tous les contenus sont contrôlables depuis le metabox ACF
 * `group_evor_page_identite_visuelle` (acf-json/). Hardcodes interdits.
 *
 * Sections : hero (avec mini-stats) / bénéfices / packs / mid-cta / méthode /
 * faq / cta final. Chaque section se désactive via son toggle ACF ou s'auto-
 * cache si son repeater est vide. Calqué sur page-consultant-seo.php.
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal" id="content">

    <?php /* ─── Hero ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-hero', null, [
        'visual_label' => 'brand.kit',
        'visual_type'  => 'identite',
    ]); ?>

    <?php /* ─── Bénéfices (partial factorisé, partagé avec les autres pages prestation) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-benefices'); ?>

    <?php /* ─── Packs ─── */ ?>
    <?php if (have_rows('packs') && evolutionr_category_has_offers('logo')):
        $packsEyebrow = (string) get_field('packs_eyebrow');
        $packsTitle   = (string) get_field('packs_title');
        $packsLede    = (string) get_field('packs_lede');
        ?>
        <section class="section section--prestation" id="packs" aria-labelledby="packs-title">
            <div class="container">

                <?php if ($packsEyebrow || $packsTitle || $packsLede): ?>
                    <div class="section-head">
                        <div class="section-head-left">
                            <?php if ($packsEyebrow): ?>
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php echo esc_html($packsEyebrow); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($packsTitle): ?>
                                <h2 class="section-title" id="packs-title"><?php echo esc_html($packsTitle); ?></h2>
                            <?php endif; ?>
                        </div>
                        <?php if ($packsLede): ?>
                            <p class="section-lede"><?php echo esc_html($packsLede); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="formules-grid">
                    <?php $i = 0; while (have_rows('packs')): the_row();
                        $offer = evolutionr_offer_resolve((string) get_sub_field('offre_ref'));
                        if (!$offer['visible']) {
                            continue; // offre « actif = non » ou non liée → carte masquée
                        }
                        get_template_part('template-parts/cards/formule-card', null, [
                            'offer'       => $offer,
                            'index'       => $i,
                            'cta_default' => __('Demander un devis', 'evolutionr'),
                        ]);
                        $i++;
                    endwhile; ?>
                </div>

                <?php evolutionr_render_mid_cta(); ?>

            </div>
        </section>
    <?php endif; ?>

    <?php /* ─── Méthode (partial factorisé, partagé avec les autres pages prestation) ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-methode'); ?>

    <?php /* ─── FAQ ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-faq'); ?>

    <?php /* ─── CTA final ─── */ ?>
    <?php get_template_part('template-parts/sections/presta-cta-final'); ?>

</main>

<?php get_footer(); ?>
