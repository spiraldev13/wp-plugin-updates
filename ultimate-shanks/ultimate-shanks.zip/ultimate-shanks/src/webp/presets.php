<?php

/**
 * WebP - Presets de conversion (format + qualité nommés)
 *
 * Évite toute re-saisie : chaque conversion (panneau ou automatique) consomme
 * un preset. Des presets d'usine sont créés à la première lecture ; la
 * qualité est par preset car les échelles WebP et AVIF ne se correspondent
 * pas (WebP 80 ≈ AVIF 60 visuellement — décision D5 du design).
 *
 * Fichiers liés :
 * - src/webp/converter.php (consommateur)
 * - src/webp/settings.php (CRUD)
 *
 * @package UltimateShanks\Webp
 */

namespace UltimateShanks\Webp;

if (!defined('ABSPATH')) {
	exit;
}

class Presets
{
	const OPTION = 'ultimate_shanks_webp_presets';

	const DEFAULT_OPTION = 'ultimate_shanks_webp_default_preset';

	/**
	 * Presets créés quand aucun n'existe
	 *
	 * @return array
	 */
	public static function factory_presets()
	{
		return [
			['id' => 'standard-webp', 'label' => 'Standard WebP 82', 'format' => 'webp', 'quality' => 82],
			['id' => 'leger-webp', 'label' => 'Léger WebP 65', 'format' => 'webp', 'quality' => 65],
			['id' => 'archive-avif', 'label' => 'Archive AVIF 55', 'format' => 'avif', 'quality' => 55],
		];
	}

	/**
	 * Tous les presets, indexés par id (seed d'usine si l'option est vide)
	 *
	 * @return array id => ['id','label','format','quality']
	 */
	public static function get_all()
	{
		$presets = (array) get_option(self::OPTION, []);

		if ($presets === []) {
			$presets = self::factory_presets();
			update_option(self::OPTION, $presets);
			update_option(self::DEFAULT_OPTION, 'standard-webp');
		}

		$indexed = [];
		foreach ($presets as $preset) {
			if (!empty($preset['id'])) {
				$indexed[$preset['id']] = $preset;
			}
		}

		return $indexed;
	}

	/**
	 * Un preset par id
	 *
	 * @param string $id
	 * @return array|null
	 */
	public static function get($id)
	{
		$presets = self::get_all();

		return isset($presets[$id]) ? $presets[$id] : null;
	}

	/**
	 * Le preset par défaut (repli : premier preset existant)
	 *
	 * @return array
	 */
	public static function get_default()
	{
		$presets = self::get_all();
		$default_id = (string) get_option(self::DEFAULT_OPTION, '');

		if (isset($presets[$default_id])) {
			return $presets[$default_id];
		}

		return reset($presets);
	}

	/**
	 * Remplace la liste des presets et réassigne le défaut si nécessaire.
	 * Une liste vide recrée les presets d'usine (le module exige un preset).
	 *
	 * @param array  $presets    Liste de ['id','label','format','quality']
	 * @param string $default_id
	 * @return void
	 */
	public static function save_all($presets, $default_id)
	{
		$clean = [];
		foreach ($presets as $preset) {
			$sanitized = self::sanitize_preset($preset);
			if ($sanitized !== null) {
				$clean[$sanitized['id']] = $sanitized;
			}
		}

		if ($clean === []) {
			delete_option(self::OPTION);
			delete_option(self::DEFAULT_OPTION);
			self::get_all();

			return;
		}

		update_option(self::OPTION, array_values($clean));

		$default_id = sanitize_key($default_id);
		if (!isset($clean[$default_id])) {
			$keys = array_keys($clean);
			$default_id = $keys[0];
		}
		update_option(self::DEFAULT_OPTION, $default_id);
	}

	/**
	 * Nettoie un preset (null si invalide)
	 *
	 * @param array $preset
	 * @return array|null
	 */
	private static function sanitize_preset($preset)
	{
		$label = isset($preset['label']) ? sanitize_text_field($preset['label']) : '';
		$format = isset($preset['format']) ? sanitize_key($preset['format']) : '';
		$quality = isset($preset['quality']) ? (int) $preset['quality'] : 0;

		if ($label === '' || !isset(Capabilities::FORMATS[$format]) || $quality < 1 || $quality > 100) {
			return null;
		}

		$id = !empty($preset['id']) ? sanitize_key($preset['id']) : sanitize_key(sanitize_title($label));
		if ($id === '') {
			return null;
		}

		return ['id' => $id, 'label' => $label, 'format' => $format, 'quality' => $quality];
	}
}
