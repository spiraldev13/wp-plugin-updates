<?php

/*
 * Manifeste d'asset ÉCRIT À LA MAIN (pas de build — AD-12).
 * La version suit celle du THÈME (garde-fou testé : AssetsBlocsTest).
 */
return [
    /* `wp-date` : l'éditeur juge l'expiration à l'heure du SITE, pas à celle
       du navigateur — les deux juges doivent s'accorder (revue 3.6). */
    'dependencies' => ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-date'],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
