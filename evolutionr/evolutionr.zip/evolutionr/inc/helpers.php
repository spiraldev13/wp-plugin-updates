<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Retourne l'URL du logo du site, dans l'ordre de priorité suivant :
 *   1. Logo défini dans le Customizer WordPress (Apparence → Personnaliser
 *      → Identité du site → Logo). C'est l'emplacement standard, attendu
 *      par WordPress et les utilisateurs.
 *   2. Logo ACF (`logo_image`, page d'options) — héritage de l'ancien
 *      seeder. Conservé pour rétro-compatibilité.
 *   3. Fallback statique embarqué dans le thème.
 */
function evolutionr_logo_url(): string
{
    $customLogoId = (int) get_theme_mod('custom_logo');
    if ($customLogoId > 0) {
        $url = wp_get_attachment_image_url($customLogoId, 'full');
        if ($url) {
            return $url;
        }
    }

    $acfLogo = function_exists('get_field') ? get_field('logo_image', 'option') : null;
    if (is_array($acfLogo) && !empty($acfLogo['url'])) {
        return $acfLogo['url'];
    }

    return get_template_directory_uri() . '/assets/img/evolutionr-logo.png';
}

/**
 * Texte alternatif du logo : champ ACF `logo_alt` si présent, sinon nom du site.
 */
function evolutionr_logo_alt(): string
{
    $alt = function_exists('get_field') ? get_field('logo_alt', 'option') : '';
    return $alt ?: get_bloginfo('name');
}

/**
 * Indique si un vrai logo est défini par l'utilisateur (Customizer ou ACF),
 * par opposition au fallback statique embarqué dans le thème. Permet de
 * masquer le wordmark texte « EVOLUTION'R » quand l'image suffit.
 */
function evolutionr_has_logo(): bool
{
    if ((int) get_theme_mod('custom_logo') > 0) {
        return true;
    }

    $acfLogo = function_exists('get_field') ? get_field('logo_image', 'option') : null;
    return is_array($acfLogo) && !empty($acfLogo['url']);
}

/**
 * Rend une icône SVG inline issue de la lib du mockup.
 * Utilise `currentColor` côté CSS pour s'adapter au contexte.
 */
function evolutionr_icon(string $name, int $size = 16, bool $echo = true): string
{
    $props = sprintf(
        'width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"',
        $size
    );

    $paths = [
        'arrow-right'    => '<path d="M5 12h14M13 5l7 7-7 7"/>',
        'arrow-up-right' => '<path d="M7 17L17 7M9 7h8v8"/>',
        'check'          => '<path d="M20 6L9 17l-5-5"/>',
        'plus'           => '<path d="M12 5v14M5 12h14"/>',
        'x'              => '<path d="M18 6L6 18M6 6l12 12"/>',
        'code'           => '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6M14 4l-4 16"/>',
        'search'         => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
        'trend'          => '<path d="M3 17l6-6 4 4 8-8M14 7h7v7"/>',
        'shield'         => '<path d="M12 2l8 4v6c0 5-3.5 9-8 10-4.5-1-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/>',
        'zap'            => '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
        'compass'        => '<circle cx="12" cy="12" r="10"/><path d="M16 8l-2 6-6 2 2-6 6-2z"/>',
        'layers'         => '<path d="M12 2l10 5-10 5L2 7l10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>',
        'chart'          => '<path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-6"/>',
        'globe'          => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20"/>',
        // Palette : utilisée pour les services « identité visuelle / logo / charte ».
        // Forme : palette classique avec 4 points de couleur figurant les pastilles.
        'palette'        => '<path d="M12 2a10 10 0 100 20c1.04 0 1.5-.8 1.5-1.65 0-.4-.16-.77-.4-1.04-.24-.27-.4-.64-.4-1.04 0-.92.75-1.65 1.65-1.65H16c2.76 0 5-2.24 5-5C21 6.48 16.97 2 12 2z"/>'
                          . '<circle cx="7.5" cy="11.5" r="1.2"/>'
                          . '<circle cx="9.5" cy="7.5" r="1.2"/>'
                          . '<circle cx="13.5" cy="6.5" r="1.2"/>'
                          . '<circle cx="17.5" cy="10.5" r="1.2"/>',
    ];

    $inner = $paths[$name] ?? '';
    $svg   = '<svg ' . $props . '>' . $inner . '</svg>';

    if ($echo) {
        echo $svg;
    }

    return $svg;
}

/**
 * Catalogue d'icônes proposé dans les menus déroulants ACF (name => libellé FR).
 *
 * Source unique des choix d'icône de toutes les métaboxes (cf. le filtre
 * `acf/load_field/name=icon` ci-dessous). Doit rester un sous-ensemble des
 * icônes définies dans `evolutionr_icon()` : ajouter une icône ici sans le SVG
 * correspondant produirait un choix qui ne rend rien.
 */
function evolutionr_icon_choices(): array
{
    return [
        'code'    => __('Code', 'evolutionr'),
        'search'  => __('Loupe', 'evolutionr'),
        'trend'   => __('Croissance', 'evolutionr'),
        'chart'   => __('Graphique', 'evolutionr'),
        'shield'  => __('Bouclier', 'evolutionr'),
        'zap'     => __('Éclair', 'evolutionr'),
        'compass' => __('Boussole', 'evolutionr'),
        'layers'  => __('Couches', 'evolutionr'),
        'globe'   => __('Globe', 'evolutionr'),
        'palette' => __('Palette', 'evolutionr'),
    ];
}

/**
 * Peuple dynamiquement tous les menus déroulants « Icône » depuis le catalogue
 * central. Les 8 sous-champs concernés sont tous nommés `icon`, donc un seul
 * filtre suffit. Admin uniquement : en front, le template lit la valeur brute
 * (le nom d'icône) et la rend via `evolutionr_icon()`, sans avoir besoin des choix.
 */
add_filter('acf/load_field/name=icon', function (array $field): array {
    if (is_admin()) {
        $field['choices'] = evolutionr_icon_choices();
    }
    return $field;
});

/**
 * Rend une icône réseau social (utilise `fill="currentColor"`, viewBox spécifique).
 */
function evolutionr_social_icon(string $network, int $size = 14, bool $echo = true): string
{
    $glyphs = [
        'linkedin' => '<path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8h4.56v14H.22V8zm7.61 0h4.36v1.92h.06c.61-1.15 2.1-2.36 4.32-2.36 4.62 0 5.47 3.04 5.47 7v8.44h-4.56v-7.48c0-1.78-.03-4.07-2.48-4.07-2.48 0-2.86 1.94-2.86 3.94V22H7.83V8z"/>',
        'github'   => '<path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.69-3.87-1.54-3.87-1.54-.52-1.32-1.27-1.68-1.27-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.02 1.76 2.69 1.25 3.34.96.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.7 0-1.26.45-2.29 1.18-3.1-.12-.29-.51-1.46.11-3.04 0 0 .96-.31 3.15 1.18.91-.25 1.89-.38 2.86-.38s1.95.13 2.86.38c2.18-1.49 3.14-1.18 3.14-1.18.62 1.58.23 2.75.11 3.04.74.81 1.18 1.84 1.18 3.1 0 4.43-2.7 5.41-5.27 5.69.41.36.78 1.06.78 2.13 0 1.54-.01 2.78-.01 3.16 0 .31.21.67.8.55C20.22 21.39 23.5 17.07 23.5 12 23.5 5.65 18.35.5 12 .5z"/>',
        'twitter'  => '<path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>',
        'facebook' => '<path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/>',
        'instagram'=> '<path d="M12 2.2c3.2 0 3.6 0 4.8.1 1.2.1 1.8.3 2.3.5.6.2 1 .5 1.5 1 .5.5.8.9 1 1.5.2.5.4 1.1.5 2.3.1 1.2.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 1.2-.3 1.8-.5 2.3-.2.6-.5 1-1 1.5-.5.5-.9.8-1.5 1-.5.2-1.1.4-2.3.5-1.2.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-1.2-.1-1.8-.3-2.3-.5-.6-.2-1-.5-1.5-1-.5-.5-.8-.9-1-1.5-.2-.5-.4-1.1-.5-2.3-.1-1.2-.1-1.6-.1-4.8s0-3.6.1-4.8c.1-1.2.3-1.8.5-2.3.2-.6.5-1 1-1.5.5-.5.9-.8 1.5-1 .5-.2 1.1-.4 2.3-.5 1.2-.1 1.6-.1 4.8-.1zm0 6.3a3.5 3.5 0 100 7 3.5 3.5 0 000-7zm5-.4a.9.9 0 100 1.8.9.9 0 000-1.8zM12 10.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3z"/>',
    ];

    $glyph = $glyphs[$network] ?? '';
    $svg   = sprintf('<svg viewBox="0 0 24 24" width="%1$d" height="%1$d" fill="currentColor" aria-hidden="true">%2$s</svg>', $size, $glyph);

    if ($echo) {
        echo $svg;
    }

    return $svg;
}

/**
 * Rend le CTA principal du header (Démarrer mon projet), piloté depuis la
 * page d'options. Réutilisé en header (desktop + mobile).
 */
function evolutionr_header_ctas(): void
{
    $primaryLabel = get_field('cta_primary_label', 'option') ?: __('Démarrer mon projet', 'evolutionr');
    $primaryUrl   = get_field('cta_primary_url', 'option') ?: '/contact/';
    ?>
    <a class="btn btn-primary" href="<?php echo esc_url($primaryUrl); ?>">
        <?php echo esc_html($primaryLabel); ?>
        <?php evolutionr_icon('arrow-right', 14); ?>
    </a>
    <?php
}

/**
 * Reconstruit le fil d'Ariane selon le contexte WordPress. Retourne un
 * tableau de segments :
 *
 *   [ ['title' => 'Accueil', 'url' => 'https://…/'],
 *     ['title' => 'Prestations', 'url' => 'https://…/prestations/'],
 *     ['title' => 'Consultant SEO', 'url' => null] ]  // dernier = page courante
 *
 * Contextes gérés :
 *  - Pages : hiérarchie `post_parent` récursive.
 *  - Page d'articles (`/blog/`) : Accueil / Blog.
 *  - Archives (catégorie, étiquette, taxo, auteur, date) + recherche :
 *    Accueil / Blog / <intitulé>.
 *  - Article : Accueil / Blog / <titre de l'article>.
 *
 * Le premier élément (Accueil) pointe vers `home_url('/')`. Le dernier segment
 * (page courante) a `url => null` pour ne pas être cliquable. Le segment
 * « Blog » reprend le titre/URL de la page d'articles (Réglages → Lecture).
 *
 * Fonction agnostique du rendu : utilisée à la fois par l'affichage HTML
 * (`evolutionr_breadcrumb()`) et par le JSON-LD Schema.org (`evolutionr_breadcrumb_jsonld()`).
 */
function evolutionr_breadcrumb_trail(): array
{
    $trail = [];
    $trail[] = [
        'title' => __('Accueil', 'evolutionr'),
        'url'   => home_url('/'),
    ];

    // Page d'accueil : pas de fil au-delà de « Accueil ».
    if (is_front_page()) {
        return $trail;
    }

    // Segment « Blog » réutilisé par tous les contextes d'articles (page
    // d'articles définie en Réglages → Lecture). Cliquable, sauf quand il EST
    // la page courante.
    $blog_page_id = (int) get_option('page_for_posts');
    $blog_title   = $blog_page_id ? get_the_title($blog_page_id) : __('Blog', 'evolutionr');
    $blog_url     = $blog_page_id ? get_permalink($blog_page_id) : null;

    // Page d'articles elle-même (`/blog/`) → Accueil / Blog.
    if (is_home()) {
        $trail[] = ['title' => $blog_title, 'url' => null];
        return $trail;
    }

    // Archives (catégorie, étiquette, taxonomie, auteur, date) + recherche →
    // Accueil / Blog / <intitulé courant>.
    if (is_archive() || is_search()) {
        if ($blog_url) {
            $trail[] = ['title' => $blog_title, 'url' => $blog_url];
        }
        if (is_category()) {
            $label = single_cat_title('', false);
        } elseif (is_tag()) {
            $label = single_tag_title('', false);
        } elseif (is_search()) {
            $label = sprintf(__('Recherche : %s', 'evolutionr'), get_search_query());
        } else {
            $label = wp_strip_all_tags(get_the_archive_title());
        }
        $trail[] = ['title' => $label, 'url' => null];
        return $trail;
    }

    if (!is_singular()) {
        return $trail;
    }

    $current_id = get_queried_object_id();
    if (!$current_id) {
        return $trail;
    }

    // Article de blog → Accueil / Blog / <titre de l'article>.
    if (is_single() && get_post_type($current_id) === 'post') {
        if ($blog_url) {
            $trail[] = ['title' => $blog_title, 'url' => $blog_url];
        }
        $trail[] = ['title' => get_the_title($current_id), 'url' => null];
        return $trail;
    }

    // Remonte la chaîne des parents via post_parent.
    $ancestors = [];
    $parent_id = wp_get_post_parent_id($current_id);
    while ($parent_id) {
        $ancestors[] = $parent_id;
        $parent_id = wp_get_post_parent_id($parent_id);
    }

    // Ancêtres dans l'ordre racine → enfant direct.
    // Un ancêtre qui n'a ni contenu rédactionnel substantiel (post_content < 200
    // chars) ni template custom est un simple hub de slug : on le rend non
    // cliquable, pour éviter de renvoyer le visiteur vers une page vide (cas
    // typique : « Prestations » utilisée seulement comme parent d'URL de
    // /prestations/<slug>/, sans page hub réelle).
    foreach (array_reverse($ancestors) as $ancestor_id) {
        $post = get_post($ancestor_id);
        $content_length = $post ? mb_strlen(trim(wp_strip_all_tags((string) $post->post_content))) : 0;
        $template = (string) get_post_meta($ancestor_id, '_wp_page_template', true);
        $has_custom_template = $template !== '' && $template !== 'default';

        // Seuil pragmatique : moins de 200 chars de contenu réel = page non
        // rédactionnelle (placeholder, paragraphe descriptif court, etc.).
        $is_hub_page = $content_length < 200 && !$has_custom_template;

        $trail[] = [
            'title' => get_the_title($ancestor_id),
            'url'   => $is_hub_page ? null : get_permalink($ancestor_id),
        ];
    }

    // Page courante (non cliquable).
    $trail[] = [
        'title' => get_the_title($current_id),
        'url'   => null,
    ];

    return $trail;
}

/**
 * Affiche le HTML du fil d'Ariane. Tous les segments sont cliquables sauf
 * le dernier (page courante). Reprend le markup existant (`.breadcrumb`,
 * `.sep`, `.current`) — pas de modification CSS requise.
 *
 * Conditions :
 *  - Aucun affichage sur la page d'accueil
 *  - Aucun affichage si la chaîne ne contient que l'Accueil
 */
function evolutionr_breadcrumb(): void
{
    $trail = evolutionr_breadcrumb_trail();
    if (count($trail) < 2) {
        return; // sur l'accueil ou si la chaîne est vide
    }

    $last = count($trail) - 1;
    ?>
    <nav class="breadcrumb" aria-label="<?php esc_attr_e('Fil d\'Ariane', 'evolutionr'); ?>">
        <?php foreach ($trail as $i => $segment): ?>
            <?php if ($i > 0): ?>
                <span class="sep" aria-hidden="true">/</span>
            <?php endif; ?>
            <?php if ($i === $last || empty($segment['url'])): ?>
                <span class="current"><?php echo esc_html($segment['title']); ?></span>
            <?php else: ?>
                <a href="<?php echo esc_url($segment['url']); ?>"><?php echo esc_html($segment['title']); ?></a>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>
    <?php
}

/**
 * Injecte le JSON-LD Schema.org BreadcrumbList dans le <head> sur les pages
 * concernées. Permet à Google d'afficher le breadcrumb dans la SERP (rich
 * result) — indépendant de Rank Math (qui ne le génère pas par défaut sur
 * cette installation).
 *
 * Hook : `wp_head` priorité tardive (100) pour passer après les schémas
 * Rank Math.
 */
function evolutionr_breadcrumb_jsonld(): void
{
    $trail = evolutionr_breadcrumb_trail();
    if (count($trail) < 2) {
        return;
    }

    $items = [];
    foreach ($trail as $i => $segment) {
        $items[] = array_filter([
            '@type'    => 'ListItem',
            'position' => $i + 1,
            'name'     => $segment['title'],
            'item'     => !empty($segment['url']) ? $segment['url'] : null,
        ]);
    }

    $payload = [
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $items,
    ];

    echo "\n<script type=\"application/ld+json\" class=\"evolutionr-breadcrumb-schema\">"
        . wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
        . "</script>\n";
}
add_action('wp_head', 'evolutionr_breadcrumb_jsonld', 100);

/**
 * Estime le temps de lecture d'un contenu, en minutes (base 200 mots/min,
 * minimum 1). Utilisé dans la méta de l'article (`single.php`).
 *
 * @param int|WP_Post|null $post Article ciblé (défaut : article courant).
 */
function evolutionr_reading_time($post = null): int
{
    $post = get_post($post);
    if (!$post) {
        return 1;
    }

    $words = str_word_count(wp_strip_all_tags((string) $post->post_content));

    return (int) max(1, (int) ceil($words / 200));
}

/**
 * Affiche le bloc « mid-CTA » des pages prestation (appel à l'action inséré
 * entre deux sections), piloté par les champs `midcta_*` + le toggle
 * `midcta_enabled` du post courant. Auto-masqué si désactivé ou vide.
 *
 * @param bool $wrap_in_section Enveloppe le bloc dans une `<section>` dédiée
 *                              (cas Maintenance). Défaut : inline (Création/SEO/Identité).
 */
function evolutionr_render_mid_cta(bool $wrap_in_section = false): void
{
    $midEnabled = (bool) get_field('midcta_enabled');
    $midStrong  = (string) get_field('midcta_strong');
    $midSub     = (string) get_field('midcta_sub');
    $midLabel   = (string) get_field('midcta_label');
    $midUrl     = (string) get_field('midcta_url');

    if (!$midEnabled || (!$midStrong && !$midLabel)) {
        return;
    }

    if ($wrap_in_section) {
        echo '<section class="section section--prestation section--no-pad-top"><div class="container">';
    }
    ?>
    <div class="mid-cta">
        <div class="mid-cta-text">
            <?php if ($midStrong): ?><strong><?php echo esc_html($midStrong); ?></strong><?php endif; ?>
            <?php if ($midSub): ?><span><?php echo esc_html($midSub); ?></span><?php endif; ?>
        </div>
        <?php if ($midLabel): ?>
            <a class="btn btn-primary" href="<?php echo esc_url($midUrl ?: '/contact/'); ?>">
                <?php echo esc_html($midLabel); ?>
                <?php evolutionr_icon('arrow-right', 14); ?>
            </a>
        <?php endif; ?>
    </div>
    <?php
    if ($wrap_in_section) {
        echo '</div></section>';
    }
}
