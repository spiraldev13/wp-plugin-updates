<?php
/*
Template Name: Page légale
*/

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<section class="section">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <h1 class="section-title"><?php the_title(); ?></h1>
            </div>
        </header>

        <div class="prose page-legal">
            <?php
            while (have_posts()) {
                the_post();
                the_content();
            }
            ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
