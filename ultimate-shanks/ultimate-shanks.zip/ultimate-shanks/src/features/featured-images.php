<?php
/**
 * Featured Images - Gestion de la colonne images à la une
 *
 * Ce fichier gère l'affichage d'une colonne "Image à la une" dans la liste des articles
 * et permet l'ajout rapide d'images via la médiathèque WordPress.
 *
 * Assets associés :
 * - JS : /assets/js/featured-images.js (médiathèque WordPress)
 *
 * @package UltimateShanks\Features
 */

namespace UltimateShanks\Features;

if (!defined('ABSPATH')) {
	exit;
}

class FeaturedImages
{
	public static function init()
	{
		// Vérifie si la fonctionnalité est activée
		if (get_option('ultimate_shanks_featured_images_enabled', '1') === '1') {
			add_filter('manage_posts_columns', [self::class, 'add_featured_image_column']);
			add_action('manage_posts_custom_column', [self::class, 'show_featured_image_column'], 10, 2);

			// Vérifie si le bouton d'ajout d'image est activé
			if (get_option('ultimate_shanks_add_image_button_enabled', '1') === '1') {
				// Charge les scripts de la médiathèque et le JavaScript
				add_action('admin_enqueue_scripts', [self::class, 'enqueue_media_scripts']);

				// Ajoute le handler AJAX
				add_action('wp_ajax_ultimate_shanks_set_featured_image', [self::class, 'ajax_set_featured_image']);
			}
		}
	}

	/**
	 * Charge les scripts de la médiathèque WordPress et notre JavaScript
	 */
	public static function enqueue_media_scripts($hook)
	{
		// Charge uniquement sur la page de liste des articles
		if ($hook !== 'edit.php') {
			return;
		}

		global $typenow;
		if ($typenow !== 'post') {
			return;
		}

		// Charge les scripts de la médiathèque WordPress
		wp_enqueue_media();

		// Charge notre script JavaScript
		wp_enqueue_script(
			'ultimate-shanks-featured-images',
			MP_URL . 'assets/js/featured-images.js',
			array('jquery', 'media-upload', 'media-views'),
			'1.0.0',
			true
		);

		// Passe les données au JavaScript
		wp_localize_script(
			'ultimate-shanks-featured-images',
			'ultimateShanksData',
			array(
				'nonce' => wp_create_nonce('ultimate_shanks_set_featured_image'),
				'ajaxurl' => admin_url('admin-ajax.php')
			)
		);
	}

	/**
	 * Ajoute la colonne "Image à la une" dans la liste des articles
	 */
	public static function add_featured_image_column($columns)
	{
		$columns['featured_image'] = __('Image à la une');
		return $columns;
	}

	/**
	 * Affiche le contenu de la colonne "Image à la une"
	 */
	public static function show_featured_image_column($column_name, $post_id)
	{
		if ($column_name == 'featured_image') {
			$post = get_post($post_id);
			$content = $post->post_content;

			// Récupération des images dans le contenu
			preg_match_all('/<img[^>]+src="([^">]+)"/i', $content, $matches);
			$img_count = count($matches[0]);
			$image_urls = $matches[1];

			// Affichage de l'image à la une
			if (has_post_thumbnail($post_id)) {
				$image_url = get_the_post_thumbnail_url($post_id);
				echo '<div style="width: 120px; aspect-ratio: 4/3; overflow: hidden; border-radius: 4px; border: 1px solid #ccc; margin-bottom: 4px;">';
				echo '<img src="' . esc_url($image_url) . '" style="width: 100%; height: 100%; object-fit: cover;">';
				echo '</div>';
			} else {
				echo '<div style="width: 120px; height: 90px; border: 1px dashed #ccc; display: flex; align-items: center; justify-content: center;">–</div>';
			}

			// Compteur + bouton aperçu
			echo '<small style="color: #666;">🖼️ ' . $img_count . ' image' . ($img_count > 1 ? 's' : '') . '</small>';

			if ($img_count > 0) {
				echo '<br><a href="#" onclick="event.preventDefault(); document.getElementById(\'preview-' . $post_id . '\').style.display = (document.getElementById(\'preview-' . $post_id . '\').style.display === \'none\' ? \'block\' : \'none\');" style="font-size:12px; color:#0073aa;">👁️ Aperçu</a>';

				// Mini lightbox / preview
				echo '<div id="preview-' . $post_id . '" style="display:none; margin-top:6px;">';
				foreach ($image_urls as $img) {
					echo '<img src="' . esc_url($img) . '" style="width:120px; height:auto; object-fit:cover; margin:2px; border:1px solid #ddd;">';
				}
				echo '</div>';
			}

			// Bouton "Ajouter une image" (si activé)
			if (get_option('ultimate_shanks_add_image_button_enabled', '1') === '1') {
				echo '<br><button class="button button-small us-add-image-btn" data-post-id="' . $post_id . '" style="margin-top: 6px; font-size: 11px;">+ Ajouter une image</button>';
			}

			// Actions additionnelles fournies par d'autres modules (ex. Images IA)
			do_action('ultimate_shanks_featured_image_column_actions', $post_id);
		}
	}

	/**
	 * Handler AJAX pour définir l'image à la une
	 */
	public static function ajax_set_featured_image()
	{
		// Vérification de sécurité
		check_ajax_referer('ultimate_shanks_set_featured_image', 'nonce');

		$post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
		$image_id = isset($_POST['image_id']) ? absint($_POST['image_id']) : 0;
		$post = get_post($post_id);
		$image = get_post($image_id);

		if (!$post || $post->post_type === 'attachment') {
			wp_send_json_error('Article introuvable.', 400);
		}

		// Vérifie que l'utilisateur a les droits
		if (!current_user_can('edit_post', $post_id)) {
			wp_send_json_error('Vous n\'avez pas les droits pour modifier cet article.', 403);
		}

		if (!$image || $image->post_type !== 'attachment' || !wp_attachment_is_image($image_id)) {
			wp_send_json_error('Le média sélectionné n\'est pas une image valide.', 400);
		}

		if (!current_user_can('upload_files') || !current_user_can('edit_post', $image_id)) {
			wp_send_json_error('Vous n\'avez pas les droits pour utiliser cette image.', 403);
		}

		// Définit l'image à la une
		$result = set_post_thumbnail($post_id, $image_id);

		if ($result) {
			wp_send_json_success('Image à la une définie avec succès.');
		} else {
			wp_send_json_error('Erreur lors de la définition de l\'image à la une.');
		}
	}
}
