<?php
/**
 * Motif hero « Identité visuelle » — palette de couleurs + échantillon typo.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Une rangée de pastilles (swatches) + un grand « Aa » en police display avec
 * sa fiche technique. Unités relatives → responsive 320px → desktop.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Swatches décoratifs : couleur + code affiché.
$swatches = [
    ['c' => '#22d3ee', 'hex' => 'CYAN'],
    ['c' => '#3b82f6', 'hex' => 'BLUE'],
    ['c' => '#0f1f35', 'hex' => 'INK'],
    ['c' => '#6ee7b7', 'hex' => 'MINT'],
    ['c' => '#f8fafc', 'hex' => 'SNOW'],
];
?>
<div class="hvi">
    <div class="hvi-swatches">
        <?php foreach ($swatches as $i => $s): ?>
            <div class="hvi-swatch" style="--c: <?php echo esc_attr($s['c']); ?>; --i: <?php echo (int) $i; ?>;">
                <span class="hvi-chip"></span>
                <span class="hvi-hex"><?php echo esc_html($s['hex']); ?></span>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="hvi-type">
        <span class="hvi-aa">Aa</span>
        <span class="hvi-type-meta">
            <span class="hvi-type-name">Space Grotesk</span>
            <span class="hvi-type-spec">Display · 700</span>
        </span>
    </div>
</div>
