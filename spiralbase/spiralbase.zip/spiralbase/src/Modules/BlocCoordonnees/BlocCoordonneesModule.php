<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocCoordonnees;

use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\Module;

/**
 * Bloc métier « Coordonnées » (CAP-12, story 3.1) — jumeau du bloc horaires,
 * écrit sur le même pattern de référence (block.json + index.js à la main +
 * index.asset.php + `render_callback`, AD-12, forme canonique gravée dans la
 * spine le 2026-07-30).
 *
 * Module SÉPARÉ de `bloc_horaires` (et non deux blocs d'un même module) :
 * un artisan sur rendez-vous veut ses coordonnées sans ses horaires, et la
 * story 3.9 (profils métier) active module par module.
 *
 * OFF par défaut (AD-6). Aucune sonde : voir le docblock de
 * `BlocHorairesModule` — même raisonnement, aucun fait lu dans un plugin
 * réel, et un bloc posé par l'opérateur ne doit pas disparaître.
 */
final class BlocCoordonneesModule implements Module
{
    public function __construct(private readonly DonneesMetier $donnees)
    {
    }

    /** Handle de la feuille du bloc — voir boot(). */
    public const HANDLE_STYLE = 'spiralbase-coordonnees';

    public function slug(): string
    {
        return 'bloc_coordonnees';
    }

    public function boot(): void
    {
        add_action('init', function (): void {
            /* Feuille enregistrée ICI, et déclarée par HANDLE dans le
               block.json : le cœur versionne les feuilles depuis le
               block.json (`blocks.php:350-351`), fichier statique — la
               version y restait figée à 1.0.0 et une correction livrée par
               une release de la flotte n'aurait jamais franchi les caches
               (revue 3.2 ; les scripts étaient déjà couverts par leur
               manifeste depuis la revue 3.1). */
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/coordonnees/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            register_block_type(
                get_template_directory() . '/blocks/coordonnees',
                ['render_callback' => fn (array $attributs): string => (new RenduCoordonnees($this->donnees))->rendre($attributs)]
            );
        });
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
