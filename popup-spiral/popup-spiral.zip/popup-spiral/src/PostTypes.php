<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enregistre le type de contenu « popup ».
 */
final class PostTypes
{
    public const POPUP = 'spiral_popup';

    public static function register(): void
    {
        add_action('init', [self::class, 'registerPostType']);
    }

    public static function registerPostType(): void
    {
        register_post_type(self::POPUP, [
            'labels' => [
                'name' => __('Popups', 'popup-spiral'),
                'singular_name' => __('Popup', 'popup-spiral'),
                'add_new' => __('Ajouter un popup', 'popup-spiral'),
                'add_new_item' => __('Ajouter un popup', 'popup-spiral'),
                'edit_item' => __('Modifier le popup', 'popup-spiral'),
                'new_item' => __('Nouveau popup', 'popup-spiral'),
                'view_item' => __('Voir le popup', 'popup-spiral'),
                'search_items' => __('Rechercher des popups', 'popup-spiral'),
                'not_found' => __('Aucun popup trouvé', 'popup-spiral'),
                'not_found_in_trash' => __('Aucun popup dans la corbeille', 'popup-spiral'),
                'all_items' => __('Tous les popups', 'popup-spiral'),
                'menu_name' => __('Popups', 'popup-spiral'),
            ],
            'description' => __('Popups affichés sur le site par Popup Spiral.', 'popup-spiral'),
            'public' => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-external',
            'hierarchical' => false,
            'has_archive' => false,
            'rewrite' => false,
            'supports' => ['title', 'editor', 'revisions', 'thumbnail'],
            'capability_type' => 'post',
        ]);
    }
}
