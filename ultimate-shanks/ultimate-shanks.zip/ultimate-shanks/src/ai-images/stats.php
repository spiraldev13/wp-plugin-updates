<?php

/**
 * AI Images - Suivi de consommation des générations
 *
 * Deux niveaux, tous deux en options (autoload désactivé, aucune table custom) :
 * un compteur mensuel (nombre d'images + coût estimé, clé AAAA-MM) et un
 * journal détaillé plafonné aux 200 dernières générations. Les coûts sont des
 * estimations basées sur la grille de prix des réglages, pas la facturation
 * réelle du fournisseur.
 *
 * Fichiers liés :
 * - src/ai-images/generator.php (enregistre chaque génération réussie)
 * - src/ai-images/settings.php (affichage de l'encart Consommation)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class Stats
{
	const STATS_OPTION = 'ultimate_shanks_ai_images_stats';

	const LOG_OPTION = 'ultimate_shanks_ai_images_log';

	const LOG_MAX_ENTRIES = 200;

	/**
	 * Enregistre une génération réussie (compteur mensuel + journal)
	 *
	 * @param float|null $cost    Coût estimé en USD (null si prix inconnu)
	 * @param array      $context ['provider','model','prompt','attachment_id','post_id']
	 * @return void
	 */
	public static function record($cost, $context)
	{
		$month = gmdate('Y-m');
		$stats = (array) get_option(self::STATS_OPTION, []);

		if (!isset($stats[$month])) {
			$stats[$month] = ['count' => 0, 'cost' => 0.0];
		}
		$stats[$month]['count']++;
		$stats[$month]['cost'] += (float) $cost;
		update_option(self::STATS_OPTION, $stats, false);

		$log = (array) get_option(self::LOG_OPTION, []);
		array_unshift($log, [
			'date'          => time(),
			'provider'      => isset($context['provider']) ? $context['provider'] : '',
			'model'         => isset($context['model']) ? $context['model'] : '',
			'prompt'        => wp_html_excerpt(isset($context['prompt']) ? $context['prompt'] : '', 80, '…'),
			'cost'          => $cost !== null ? (float) $cost : null,
			'attachment_id' => isset($context['attachment_id']) ? (int) $context['attachment_id'] : 0,
			'post_id'       => isset($context['post_id']) ? (int) $context['post_id'] : 0,
		]);
		update_option(self::LOG_OPTION, array_slice($log, 0, self::LOG_MAX_ENTRIES), false);
	}

	/**
	 * Consommation d'un mois donné
	 *
	 * @param string $month AAAA-MM (défaut : mois courant)
	 * @return array ['count' => int, 'cost' => float]
	 */
	public static function get_monthly($month = '')
	{
		if ($month === '') {
			$month = gmdate('Y-m');
		}
		$stats = (array) get_option(self::STATS_OPTION, []);

		return isset($stats[$month]) ? $stats[$month] : ['count' => 0, 'cost' => 0.0];
	}

	/**
	 * Consommation cumulée depuis l'installation
	 *
	 * @return array ['count' => int, 'cost' => float]
	 */
	public static function get_totals()
	{
		$totals = ['count' => 0, 'cost' => 0.0];

		foreach ((array) get_option(self::STATS_OPTION, []) as $entry) {
			$totals['count'] += isset($entry['count']) ? (int) $entry['count'] : 0;
			$totals['cost'] += isset($entry['cost']) ? (float) $entry['cost'] : 0.0;
		}

		return $totals;
	}

	/**
	 * Dernières entrées du journal (les plus récentes d'abord)
	 *
	 * @param int $limit
	 * @return array
	 */
	public static function get_log($limit = 20)
	{
		return array_slice((array) get_option(self::LOG_OPTION, []), 0, max(1, (int) $limit));
	}
}
