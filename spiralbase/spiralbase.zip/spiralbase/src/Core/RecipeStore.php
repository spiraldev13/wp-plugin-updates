<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Porte unique de lecture/écriture de la recette du site (AD-7) : UNE
 * option canonique, écrite ici et nulle part ailleurs, toujours validée
 * par l'unique juge (AD-8) quel que soit le canal d'entrée. La recette est
 * une DONNÉE du site : les mises à jour du parent ne la touchent jamais.
 */
final class RecipeStore
{
    public const OPTION = 'spiralbase_recipe';

    public const SCHEMA_VERSION = 1;

    public function __construct(
        private readonly RecipeValidator $validator,
        private readonly Archetypes $archetypes,
    ) {
    }

    /** @return true|\WP_Error frontière — jamais d'exception de validation */
    public function apply(array $recette): bool|\WP_Error
    {
        $slug = $recette['archetype'] ?? null;

        if (!is_string($slug) || $slug === '') {
            return new \WP_Error(
                RecipeValidator::CODE_INVALIDE,
                sprintf('Recette invalide : « archetype » doit être une chaîne non vide (%s reçu).', get_debug_type($slug))
            );
        }

        $archetype = $this->archetypes->get($slug);

        if ($archetype instanceof \WP_Error) {
            return $archetype;
        }

        if ($archetype === null) {
            return new \WP_Error(
                'spiralbase_archetype_inconnu',
                sprintf('Archétype « %s » introuvable dans la bibliothèque du parent.', $slug)
            );
        }

        $verdict = $this->validator->validate($recette, $archetype);

        if ($verdict !== true) {
            return $verdict;
        }

        /* Idempotence explicite (modèle Registry) : rien à écrire = succès. */
        if (get_option(self::OPTION, null) === $recette) {
            return true;
        }

        if (!update_option(self::OPTION, $recette, false)) {
            return new \WP_Error(
                'spiralbase_recette_ecriture',
                'Échec de persistance de la recette — rien n\'a été enregistré.'
            );
        }

        return true;
    }

    /**
     * Recette courante, migrée EN MÉMOIRE vers la version courante (AD-8).
     * La base n'est jamais réécrite en lecture ; matérialiser la migration
     * passe par une ré-application explicite via apply(). null = pas de
     * recette, données corrompues (signalées), ou version FUTURE (jamais
     * interprétée) — `existe()` permet aux frontières de distinguer.
     */
    public function get(): ?array
    {
        $recette = get_option(self::OPTION, null);

        if ($recette === null || $recette === false) {
            return null;
        }

        if (!is_array($recette)) {
            $this->signaler('recette corrompue en base (type ' . get_debug_type($recette) . ')', 'spiralbase_recette_corrompue');

            return null;
        }

        $version = $recette['schema_version'] ?? 0;

        if (!is_int($version)) {
            $this->signaler('schema_version corrompue (type ' . get_debug_type($version) . ')', 'spiralbase_recette_corrompue');

            return null;
        }

        if ($version > self::SCHEMA_VERSION) {
            $this->signaler(sprintf('recette en schema_version %d > %d : ignorée', $version, self::SCHEMA_VERSION), 'spiralbase_recette_version_future');

            return null;
        }

        while ($version < self::SCHEMA_VERSION) {
            $recette = $this->migrer($version, $recette);
            $version++;
        }

        return $recette;
    }

    /** Une donnée existe-t-elle dans l'option canonique (lisible ou non) ? */
    public function existe(): bool
    {
        $valeur = get_option(self::OPTION, null);

        return $valeur !== null && $valeur !== false;
    }

    /**
     * Pipeline de migrations — une étape par version, sans perte. Une étape
     * manquante est une erreur de programmation : elle DOIT exister avant
     * tout bump de SCHEMA_VERSION.
     */
    private function migrer(int $depuis, array $recette): array
    {
        return match ($depuis) {
            /* v0 : format legacy sans schema_version — normalisation pure. */
            0 => ['schema_version' => 1] + $recette,
            default => throw new RegistryException(sprintf(
                'Migration de recette manquante depuis la version %d — écrire l\'étape avant de bumper SCHEMA_VERSION.',
                $depuis
            )),
        };
    }

    private function signaler(string $message, string $hook): void
    {
        do_action($hook, $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] recette : ' . $message . '.');
        }
    }
}
