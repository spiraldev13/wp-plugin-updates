<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Erreur de configuration de l'updater (type inconnu, slug vide) — domaine
 * distinct du registre de modules : attraper les erreurs de registre ne
 * doit pas avaler celles de la chaîne de mise à jour.
 */
final class UpdaterException extends \RuntimeException
{
}
