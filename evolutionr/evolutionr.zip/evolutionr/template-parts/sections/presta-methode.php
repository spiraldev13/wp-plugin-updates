<?php
/**
 * Partial — Section « Méthode » (liste numérotée d'étapes).
 *
 * Utilisée sur les 3 pages prestation. Chaque page a son propre jeu de champs
 * ACF avec des clés distinctes mais des noms identiques (`meth_enabled`,
 * `meth_eyebrow`, `meth_title`, `meth_lede`, `meth_steps` — sous-champs `num`,
 * `title`, `desc`).
 *
 * Le partial est agnostique : il lit les champs depuis le post courant via
 * `get_field()` / `have_rows()`. À inclure via `get_template_part()`.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!get_field('meth_enabled') || (!get_field('meth_title') && !have_rows('meth_steps'))) {
    return;
}

$methEyebrow = (string) get_field('meth_eyebrow');
$methTitle   = (string) get_field('meth_title');
$methLede    = (string) get_field('meth_lede');
?>
<section class="section section--prestation section--no-pad-top" aria-labelledby="methode-title">
    <div class="container">
        <?php if ($methEyebrow || $methTitle || $methLede): ?>
            <div class="section-head">
                <div class="section-head-left">
                    <?php if ($methEyebrow): ?>
                        <div class="section-eyebrow-wrap">
                            <span class="eyebrow"><?php echo esc_html($methEyebrow); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($methTitle): ?>
                        <h2 class="section-title" id="methode-title"><?php echo esc_html($methTitle); ?></h2>
                    <?php endif; ?>
                </div>
                <?php if ($methLede): ?>
                    <p class="section-lede"><?php echo esc_html($methLede); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (have_rows('meth_steps')): ?>
            <ol class="methode-steps">
                <?php $mi = 0; while (have_rows('meth_steps')): the_row();
                    $mNum   = (string) get_sub_field('num');
                    $mTitle = (string) get_sub_field('title');
                    $mDesc  = (string) get_sub_field('desc');
                    if (!$mTitle) continue;
                    $mShow = $mNum ?: sprintf('%02d', $mi + 1);
                    ?>
                    <li class="methode-step">
                        <span class="methode-step-num"><?php echo esc_html($mShow); ?></span>
                        <div class="methode-step-body">
                            <h3 class="methode-step-title"><?php echo esc_html($mTitle); ?></h3>
                            <?php if ($mDesc): ?><p><?php echo esc_html($mDesc); ?></p><?php endif; ?>
                        </div>
                    </li>
                    <?php $mi++;
                endwhile; ?>
            </ol>
        <?php endif; ?>
    </div>
</section>
