/**
 * État d'ouverture — correction côté client (story 3.1).
 *
 * POURQUOI : le serveur dit la vérité au moment du rendu, mais un état
 * ouvert/fermé se périme. Sous cache pleine page, « Ouvert » resterait
 * affiché toute la nuit (leçon de la story 2.5 : ce qui varie se décide côté
 * client). Ce script recalcule l'état à l'affichage, dans le fuseau du SITE
 * — pas celui du visiteur.
 *
 * Fail-safe : au moindre doute (fuseau non reconnu par Intl, données
 * illisibles, libellés absents), il ne touche à RIEN et l'état serveur
 * subsiste. Il ne doit jamais dégrader ce que le serveur a écrit.
 */
( function () {
    'use strict';

    var JOUR = 1440;
    var JOURS = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };

    /** Minutes écoulées depuis lundi 00:00 dans le fuseau donné, ou null. */
    function minuteSemaine( fuseau ) {
        if ( ! fuseau ) {
            return null;
        }

        var parties;

        try {
            parties = new Intl.DateTimeFormat( 'en-US', {
                timeZone: fuseau,
                weekday: 'short',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false,
            } ).formatToParts( new Date() );
        } catch ( erreur ) {
            /* Mesuré sur V8 récent : les fuseaux en offset (« +02:00 »,
               « -06:30 »), servis par les sites sans timezone_string, sont
               acceptés — ce repli ne concerne donc que les moteurs anciens.
               Dans ce cas on s'abstient : l'état serveur, juste au moment du
               rendu, vaut mieux qu'un calcul dans le fuseau du visiteur. */
            return null;
        }

        var valeurs = {};

        parties.forEach( function ( partie ) {
            valeurs[ partie.type ] = partie.value;
        } );

        var jour = JOURS[ valeurs.weekday ];
        /* hour12:false rend « 24 » pour minuit sur certains moteurs. */
        var heure = parseInt( valeurs.hour, 10 ) % 24;
        var minute = parseInt( valeurs.minute, 10 );

        if ( jour === undefined || isNaN( heure ) || isNaN( minute ) ) {
            return null;
        }

        return jour * JOUR + heure * 60 + minute;
    }

    function corriger( bloc ) {
        var etat = bloc.querySelector( '[data-spiralbase-etat]' );

        if ( ! etat ) {
            return;
        }

        var libelleOuvert = etat.getAttribute( 'data-spiralbase-libelle-ouvert' );
        var libelleFerme = etat.getAttribute( 'data-spiralbase-libelle-ferme' );

        if ( ! libelleOuvert || ! libelleFerme ) {
            return;
        }

        var segments;

        try {
            segments = JSON.parse( bloc.getAttribute( 'data-spiralbase-horaires' ) || 'null' );
        } catch ( erreur ) {
            return;
        }

        if ( ! Array.isArray( segments ) || ! segments.length ) {
            return;
        }

        var minute = minuteSemaine( bloc.getAttribute( 'data-spiralbase-fuseau' ) );

        if ( minute === null ) {
            return;
        }

        var ouvert = segments.some( function ( segment ) {
            return (
                Array.isArray( segment ) &&
                typeof segment[ 0 ] === 'number' &&
                typeof segment[ 1 ] === 'number' &&
                minute >= segment[ 0 ] &&
                minute < segment[ 1 ]
            );
        } );

        etat.classList.toggle( 'spiralbase-horaires__etat--ouvert', ouvert );
        etat.classList.toggle( 'spiralbase-horaires__etat--ferme', ! ouvert );
        etat.textContent = ouvert ? libelleOuvert : libelleFerme;
    }

    function corrigerTout() {
        var blocs = document.querySelectorAll( '.spiralbase-horaires[data-spiralbase-horaires]' );

        Array.prototype.forEach.call( blocs, corriger );
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', corrigerTout );
    } else {
        corrigerTout();
    }

    /* Un calcul au seul chargement laissait l'onglet resté ouvert franchir
       l'heure de fermeture sans bouger — exactement la panne que ce script
       existe pour empêcher, à une échelle de temps plus courte que le cache
       (revue 3.1). On réarme donc sur les trois moments où l'heure a pu
       changer sans nouveau rendu. */
    window.addEventListener( 'pageshow', corrigerTout );

    document.addEventListener( 'visibilitychange', function () {
        if ( ! document.hidden ) {
            corrigerTout();
        }
    } );

    window.setInterval( corrigerTout, 60000 );
} )();
