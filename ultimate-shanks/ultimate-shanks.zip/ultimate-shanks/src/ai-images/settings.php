<?php

/**
 * AI Images - Onglet de réglages « Images IA »
 *
 * Rend les champs génériques déclarés par chaque provider (via
 * get_settings_fields()) : un futur fournisseur déclare ses propres champs
 * sans modifier cette classe. La clé API n'est jamais réaffichée en clair.
 *
 * Assets associés :
 * - JS : /assets/js/ai-images-settings.js (test connexion, remplacement de clé)
 *
 * Fichiers liés :
 * - src/ai-images/providers.php
 * - src/admin/settings.php (nav + switch de l'onglet)
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class Settings
{
	public static function init()
	{
		add_action('admin_init', [self::class, 'register_settings']);
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
		add_action('wp_ajax_ultimate_shanks_ai_images_test', [self::class, 'ajax_test_connection']);
	}

	/**
	 * Enregistre les paramètres généraux du module
	 */
	public static function register_settings()
	{
		register_setting('ultimate_shanks_ai_images', AiImages::OPTION_NAME);
		register_setting('ultimate_shanks_ai_images', 'ultimate_shanks_ai_images_provider');
		register_setting('ultimate_shanks_ai_images', 'ultimate_shanks_ai_images_default_ratio');
		register_setting('ultimate_shanks_ai_images', 'ultimate_shanks_ai_images_default_target');
	}

	/**
	 * Charge le JS des réglages sur la page Ultimate Shanks uniquement
	 */
	public static function enqueue_scripts($hook)
	{
		if ($hook !== 'toplevel_page_ultimate-shanks') {
			return;
		}

		wp_enqueue_script(
			'ultimate-shanks-ai-images-settings',
			MP_URL . 'assets/js/ai-images-settings.js',
			['jquery'],
			'1.0.0',
			true
		);

		wp_localize_script('ultimate-shanks-ai-images-settings', 'ultimateShanksAiImagesSettings', [
			'ajaxurl' => admin_url('admin-ajax.php'),
			'nonce'   => wp_create_nonce('ultimate_shanks_ai_images_test'),
			'strings' => [
				'testing' => 'Test en cours…',
				'error'   => 'Erreur inattendue pendant le test.',
			],
		]);
	}

	/**
	 * Affiche l'onglet Images IA (traitement du POST puis formulaire)
	 */
	public static function render_tab()
	{
		if (isset($_POST['ultimate_shanks_ai_images_submit'])) {
			check_admin_referer('ultimate_shanks_ai_images_action', 'ultimate_shanks_ai_images_nonce');
			self::save_settings();
			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}

		$enabled = get_option(AiImages::OPTION_NAME, '0');
		$active_provider_id = get_option('ultimate_shanks_ai_images_provider', Providers::DEFAULT_PROVIDER);
		$default_ratio = get_option('ultimate_shanks_ai_images_default_ratio', '3:2');
		$default_target = get_option('ultimate_shanks_ai_images_default_target', 'featured');
		?>

		<div class="ultimate-shanks-settings-box">
			<h2>Images IA - Génération d'images par intelligence artificielle</h2>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_ai_images_action', 'ultimate_shanks_ai_images_nonce'); ?>

				<table class="form-table ultimate-shanks-form-table">
					<tbody>
						<tr>
							<th scope="row"><label for="us_ai_images_enabled">Activer le module</label></th>
							<td>
								<label>
									<input type="checkbox" id="us_ai_images_enabled" name="us_ai_images_enabled"
										value="1" <?php checked($enabled, '1'); ?>>
									Activer la génération d'images par IA
								</label>
								<p class="description">
									Ajoute une metabox dans l'éditeur (articles et pages), un bouton dans la liste
									des articles, une action groupée et l'endpoint REST
									<code>POST /wp-json/cmd/v1/ai-image</code>.
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="us_ai_images_provider">Fournisseur</label></th>
							<td>
								<select id="us_ai_images_provider" name="us_ai_images_provider">
									<?php foreach (Providers::get_all() as $id => $provider) : ?>
										<option value="<?php echo esc_attr($id); ?>" <?php selected($id, $active_provider_id); ?>>
											<?php echo esc_html($provider->get_label()); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description">Service d'IA utilisé pour générer les images.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="us_ai_images_default_ratio">Format par défaut</label></th>
							<td>
								<select id="us_ai_images_default_ratio" name="us_ai_images_default_ratio">
									<?php foreach (Generator::VALID_RATIOS as $ratio) : ?>
										<option value="<?php echo esc_attr($ratio); ?>" <?php selected($ratio, $default_ratio); ?>>
											<?php echo esc_html($ratio); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="us_ai_images_default_target">Destination par défaut</label></th>
							<td>
								<select id="us_ai_images_default_target" name="us_ai_images_default_target">
									<option value="featured" <?php selected('featured', $default_target); ?>>Image à la une</option>
									<option value="content" <?php selected('content', $default_target); ?>>Début du contenu</option>
									<option value="library" <?php selected('library', $default_target); ?>>Médiathèque seulement</option>
								</select>
							</td>
						</tr>
					</tbody>
				</table>

				<?php foreach (Providers::get_all() as $provider) : ?>
					<?php self::render_provider_fields($provider); ?>
				<?php endforeach; ?>

				<?php self::render_models_section(Providers::get_active()); ?>

				<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_ai_images_submit'); ?>
			</form>

			<p>
				<button type="button" class="button" id="us_ai_images_test_btn">Tester la connexion</button>
				<span id="us_ai_images_test_result"></span>
			</p>

			<div class="ultimate-shanks-info-box">
				<h3>Clé API et facturation</h3>
				<p>
					La clé API peut être définie dans <code>wp-config.php</code> via la constante
					<code>ULTIMATE_SHANKS_BFL_API_KEY</code> (recommandé : elle est alors prioritaire
					et jamais stockée en base de données). Chaque génération d'image est facturée
					par le fournisseur — le test de connexion, lui, ne consomme aucun crédit.
					Les prix affichés sont des estimations modifiables, pas la facturation réelle.
				</p>
			</div>

			<?php self::render_consumption(); ?>
		</div>
		<?php
	}

	/**
	 * Tableau des modèles du provider actif : prix éditables pour les intégrés,
	 * lignes entièrement éditables (+ suppression, + ajout) pour les personnalisés
	 *
	 * @param ProviderInterface $provider
	 */
	private static function render_models_section($provider)
	{
		$custom_index = 0;
		?>
		<h3>Modèles et tarifs — <?php echo esc_html($provider->get_label()); ?></h3>
		<table class="widefat striped" id="us_ai_models_table" style="max-width:900px;">
			<thead>
				<tr>
					<th>Endpoint</th>
					<th>Libellé</th>
					<th>Dimensions attendues</th>
					<th style="width:120px;">Prix ($/image)</th>
					<th style="width:100px;"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($provider->get_models() as $endpoint => $model) : ?>
					<?php if (!empty($model['builtin'])) : ?>
						<tr>
							<td><code><?php echo esc_html($endpoint); ?></code></td>
							<td><?php echo esc_html($model['label']); ?></td>
							<td><?php echo $model['dims'] === 'aspect_ratio' ? 'aspect_ratio' : 'width/height (conversion auto)'; ?></td>
							<td>
								<input type="number" step="0.001" min="0" style="width:90px;"
									name="us_ai_prices[<?php echo esc_attr($endpoint); ?>]"
									value="<?php echo esc_attr($model['price']); ?>">
							</td>
							<td><em>intégré</em></td>
						</tr>
					<?php else : ?>
						<?php self::render_custom_model_row($custom_index, $endpoint, $model); ?>
						<?php $custom_index++; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<button type="button" class="button" id="us_ai_add_model">+ Ajouter un modèle</button>
			<span class="description">Les nouveaux endpoints BFL peuvent être ajoutés ici sans mise à jour du plugin.</span>
		</p>
		<?php
	}

	/**
	 * Ligne éditable d'un modèle personnalisé
	 *
	 * @param int    $index
	 * @param string $endpoint
	 * @param array  $model
	 */
	private static function render_custom_model_row($index, $endpoint, $model)
	{
		?>
		<tr class="us-ai-custom-model">
			<td>
				<input type="text" style="width:100%;" placeholder="/flux-nouveau-modele"
					name="us_ai_custom[<?php echo esc_attr($index); ?>][endpoint]"
					value="<?php echo esc_attr($endpoint); ?>">
			</td>
			<td>
				<input type="text" style="width:100%;" placeholder="Libellé"
					name="us_ai_custom[<?php echo esc_attr($index); ?>][label]"
					value="<?php echo esc_attr($model['label']); ?>">
			</td>
			<td>
				<select name="us_ai_custom[<?php echo esc_attr($index); ?>][dims]">
					<option value="width_height" <?php selected($model['dims'], 'width_height'); ?>>width/height (conversion auto)</option>
					<option value="aspect_ratio" <?php selected($model['dims'], 'aspect_ratio'); ?>>aspect_ratio</option>
				</select>
			</td>
			<td>
				<input type="number" step="0.001" min="0" style="width:90px;"
					name="us_ai_custom[<?php echo esc_attr($index); ?>][price]"
					value="<?php echo esc_attr($model['price']); ?>">
			</td>
			<td><button type="button" class="button button-small us-ai-remove-model">Supprimer</button></td>
		</tr>
		<?php
	}

	/**
	 * Encart Consommation : mois courant, cumul et journal des dernières générations
	 */
	private static function render_consumption()
	{
		$monthly = Stats::get_monthly();
		$totals = Stats::get_totals();
		$log = Stats::get_log(20);
		?>
		<div class="ultimate-shanks-info-box">
			<h3>Consommation</h3>
			<p>
				Mois en cours (<?php echo esc_html(gmdate('Y-m')); ?>) :
				<strong><?php echo esc_html(number_format_i18n($monthly['count'])); ?> image(s)</strong>
				pour un coût estimé de <strong>~<?php echo esc_html(number_format_i18n($monthly['cost'], 3)); ?> $</strong>.
				Cumul : <?php echo esc_html(number_format_i18n($totals['count'])); ?> image(s),
				~<?php echo esc_html(number_format_i18n($totals['cost'], 3)); ?> $.
			</p>
			<?php if ($log !== []) : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th>Date</th>
							<th>Modèle</th>
							<th>Prompt</th>
							<th>Coût</th>
							<th>Image</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($log as $entry) : ?>
							<tr>
								<td><?php echo esc_html(wp_date('d/m/Y H:i', $entry['date'])); ?></td>
								<td><code><?php echo esc_html($entry['model']); ?></code></td>
								<td><?php echo esc_html($entry['prompt']); ?></td>
								<td><?php echo $entry['cost'] !== null ? '~' . esc_html(number_format_i18n($entry['cost'], 3)) . ' $' : '—'; ?></td>
								<td>
									<?php if ($entry['attachment_id'] && get_post($entry['attachment_id'])) : ?>
										<a href="<?php echo esc_url(get_edit_post_link($entry['attachment_id'])); ?>">#<?php echo esc_html($entry['attachment_id']); ?></a>
									<?php else : ?>
										supprimée
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description">Les <?php echo esc_html(Stats::LOG_MAX_ENTRIES); ?> dernières générations sont conservées ; les compteurs mensuels, eux, ne sont jamais purgés.</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Rend les champs déclarés par un provider (section dédiée)
	 *
	 * @param ProviderInterface $provider
	 */
	private static function render_provider_fields($provider)
	{
		?>
		<h3><?php echo esc_html($provider->get_label()); ?></h3>
		<table class="form-table ultimate-shanks-form-table">
			<tbody>
				<?php foreach ($provider->get_settings_fields() as $field) : ?>
					<?php self::render_provider_field($provider, $field); ?>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Rend un champ de provider selon son type (secret, select, text)
	 *
	 * @param ProviderInterface $provider
	 * @param array             $field
	 */
	private static function render_provider_field($provider, $field)
	{
		$input_name = self::field_input_name($provider->get_id(), $field['key']);
		$value = (string) Providers::get_setting($provider->get_id(), $field['key'], $field['default']);
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr($input_name); ?>"><?php echo esc_html($field['label']); ?></label></th>
			<td>
				<?php
				if ($field['type'] === 'secret') {
					self::render_secret_field($provider, $field, $input_name);
				} elseif ($field['type'] === 'select') {
					self::render_select_field($field, $input_name, $value);
				} else {
					printf(
						'<input type="text" class="regular-text" id="%1$s" name="%1$s" value="%2$s">',
						esc_attr($input_name),
						esc_attr($value)
					);
				}
				?>
				<?php if (!empty($field['description'])) : ?>
					<p class="description"><?php echo esc_html($field['description']); ?></p>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Champ secret : la valeur enregistrée n'est JAMAIS réinjectée dans le HTML
	 *
	 * @param ProviderInterface $provider
	 * @param array             $field
	 * @param string            $input_name
	 */
	private static function render_secret_field($provider, $field, $input_name)
	{
		$is_constant = $provider instanceof FluxProvider && $provider->get_api_key_source() === 'constant';
		$has_saved = (string) Providers::get_setting($provider->get_id(), $field['key'], '') !== '';

		if ($is_constant) {
			echo '<p><strong>Clé définie dans wp-config.php</strong> (prioritaire sur ce champ).</p>';

			return;
		}

		if ($has_saved) {
			printf(
				'<p>Clé enregistrée : <code>••••••••</code>
					<button type="button" class="button button-small us-ai-replace-key" data-target="%1$s">Remplacer la clé</button>
				</p>
				<input type="password" class="regular-text" id="%1$s" name="%1$s" value="" autocomplete="new-password"
					placeholder="Nouvelle clé" style="display:none;">
				<p><label><input type="checkbox" name="%1$s_clear" value="1"> Effacer la clé enregistrée</label></p>',
				esc_attr($input_name)
			);

			return;
		}

		printf(
			'<input type="password" class="regular-text" id="%1$s" name="%1$s" value="" autocomplete="new-password">',
			esc_attr($input_name)
		);
	}

	/**
	 * Champ select générique
	 *
	 * @param array  $field
	 * @param string $input_name
	 * @param string $value
	 */
	private static function render_select_field($field, $input_name, $value)
	{
		printf('<select id="%1$s" name="%1$s">', esc_attr($input_name));
		foreach ($field['options'] as $option_value => $option_label) {
			printf(
				'<option value="%s" %s>%s</option>',
				esc_attr($option_value),
				selected($option_value, $value, false),
				esc_html($option_label)
			);
		}
		echo '</select>';
	}

	/**
	 * Nom de champ de formulaire pour un réglage de provider
	 *
	 * @param string $provider_id
	 * @param string $key
	 * @return string
	 */
	private static function field_input_name($provider_id, $key)
	{
		return Providers::setting_option_name($provider_id, $key);
	}

	/**
	 * Sauvegarde les réglages généraux puis les champs de chaque provider
	 */
	private static function save_settings()
	{
		update_option(AiImages::OPTION_NAME, isset($_POST['us_ai_images_enabled']) ? '1' : '0');

		$provider_id = isset($_POST['us_ai_images_provider'])
			? sanitize_key($_POST['us_ai_images_provider']) : Providers::DEFAULT_PROVIDER;
		if (Providers::get($provider_id) !== null) {
			update_option('ultimate_shanks_ai_images_provider', $provider_id);
		}

		$ratio = isset($_POST['us_ai_images_default_ratio'])
			? sanitize_text_field(wp_unslash($_POST['us_ai_images_default_ratio'])) : '';
		if (in_array($ratio, Generator::VALID_RATIOS, true)) {
			update_option('ultimate_shanks_ai_images_default_ratio', $ratio);
		}

		$target = isset($_POST['us_ai_images_default_target'])
			? sanitize_text_field(wp_unslash($_POST['us_ai_images_default_target'])) : '';
		if (in_array($target, Generator::VALID_TARGETS, true)) {
			update_option('ultimate_shanks_ai_images_default_target', $target);
		}

		// Modèles d'abord : un modèle personnalisé ajouté dans cette soumission
		// doit exister avant la validation du select « Modèle par défaut »
		self::save_models(Providers::get_active());

		foreach (Providers::get_all() as $provider) {
			self::save_provider_fields($provider);
		}
	}

	/**
	 * Sauvegarde la grille de prix des modèles intégrés et les modèles
	 * personnalisés du provider actif
	 *
	 * @param ProviderInterface $provider
	 */
	private static function save_models($provider)
	{
		$provider_id = $provider->get_id();

		$prices = [];
		$builtin = FluxProvider::get_builtin_models();
		foreach ((array) (isset($_POST['us_ai_prices']) ? wp_unslash($_POST['us_ai_prices']) : []) as $endpoint => $price) {
			$endpoint = self::sanitize_endpoint($endpoint);
			if ($endpoint !== '' && isset($builtin[$endpoint]) && is_numeric($price)) {
				$prices[$endpoint] = round((float) $price, 4);
			}
		}
		update_option(Providers::setting_option_name($provider_id, 'prices'), $prices);

		$custom = [];
		foreach ((array) (isset($_POST['us_ai_custom']) ? wp_unslash($_POST['us_ai_custom']) : []) as $row) {
			$endpoint = isset($row['endpoint']) ? self::sanitize_endpoint($row['endpoint']) : '';
			if ($endpoint === '' || isset($builtin[$endpoint])) {
				continue;
			}
			$custom[] = [
				'endpoint' => $endpoint,
				'label'    => isset($row['label']) ? sanitize_text_field($row['label']) : $endpoint,
				'dims'     => (isset($row['dims']) && $row['dims'] === 'aspect_ratio') ? 'aspect_ratio' : 'width_height',
				'price'    => (isset($row['price']) && is_numeric($row['price'])) ? round((float) $row['price'], 4) : null,
			];
		}
		update_option(Providers::setting_option_name($provider_id, 'custom_models'), $custom);
	}

	/**
	 * Nettoie un endpoint de modèle : slash initial + caractères sûrs uniquement
	 *
	 * @param string $endpoint
	 * @return string Vide si invalide
	 */
	private static function sanitize_endpoint($endpoint)
	{
		$endpoint = strtolower(trim((string) $endpoint));
		if ($endpoint === '' || $endpoint[0] !== '/') {
			$endpoint = '/' . $endpoint;
		}

		return preg_match('#^/[a-z0-9][a-z0-9.\-]*$#', $endpoint) === 1 ? $endpoint : '';
	}

	/**
	 * Sauvegarde les champs d'un provider. Champ secret : case « effacer » →
	 * suppression ; champ rempli → remplacement ; champ vide → conservation.
	 *
	 * @param ProviderInterface $provider
	 */
	private static function save_provider_fields($provider)
	{
		foreach ($provider->get_settings_fields() as $field) {
			$option_name = Providers::setting_option_name($provider->get_id(), $field['key']);
			$posted = isset($_POST[$option_name])
				? trim(sanitize_text_field(wp_unslash($_POST[$option_name]))) : '';

			if ($field['type'] === 'secret') {
				if (!empty($_POST[$option_name . '_clear'])) {
					delete_option($option_name);
				} elseif ($posted !== '') {
					update_option($option_name, $posted);
				}
				continue;
			}

			if ($field['type'] === 'select') {
				if (isset($field['options'][$posted])) {
					update_option($option_name, $posted);
				}
				continue;
			}

			update_option($option_name, $posted);
		}
	}

	/**
	 * Handler AJAX du test de connexion (clé enregistrée uniquement)
	 */
	public static function ajax_test_connection()
	{
		check_ajax_referer('ultimate_shanks_ai_images_test', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'Permissions insuffisantes.'], 403);
		}

		$result = Providers::get_active()->test_connection();

		if (is_wp_error($result)) {
			wp_send_json_error(['message' => $result->get_error_message()], 400);
		}

		wp_send_json_success($result);
	}
}
