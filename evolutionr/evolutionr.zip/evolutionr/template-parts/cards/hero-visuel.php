<?php
/**
 * Carte visuelle de hero — cadre « console » réutilisable.
 *
 * Cadre commun (coins cyan + label mono + readout « live ») partagé par la
 * page Tarifs et les 6 pages internes (prestations + à-propos + contact).
 * Le motif intérieur — décor fixe, distinct par page — est délégué à un
 * sous-template `template-parts/sections/hero-visuels/{visual}.php`.
 *
 * Décor pur : `aria-hidden`, aucun champ ACF.
 *
 * @param array $args {
 *     @type string $label   Libellé mono affiché en haut à gauche (ex. « rank.tracker »).
 *     @type string $visual  Slug du sous-template de contenu (sans extension).
 *     @type string $readout Texte du readout en haut à droite. Défaut « live ».
 * }
 */

if (!defined('ABSPATH')) {
    exit;
}

$label   = isset($args['label']) ? (string) $args['label'] : '';
// Slug en liste blanche de caractères → jamais de remontée de chemin.
$visual  = isset($args['visual']) ? preg_replace('/[^a-z0-9_-]/', '', (string) $args['visual']) : '';
$readout = isset($args['readout']) ? (string) $args['readout'] : __('live', 'evolutionr');

if ($visual === '') {
    return;
}
?>
<div class="hv hv--<?php echo esc_attr($visual); ?>" aria-hidden="true">
    <span class="hv-corner tl"></span>
    <span class="hv-corner tr"></span>
    <span class="hv-corner bl"></span>
    <span class="hv-corner br"></span>

    <?php if ($label !== ''): ?>
        <span class="hv-label"><?php echo esc_html($label); ?></span>
    <?php endif; ?>
    <span class="hv-readout"><span class="hv-dot"></span> <?php echo esc_html($readout); ?></span>

    <div class="hv-body">
        <?php get_template_part('template-parts/sections/hero-visuels/' . $visual); ?>
    </div>
</div>
