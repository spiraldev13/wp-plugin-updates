/**
 * JavaScript pour l'interface d'administration du Style Manager
 *
 * Gère les interactions utilisateur sur la page de configuration des styles:
 * - Synchronisation des color pickers avec les champs texte
 * - Sliders d'opacité
 * - Spinners de nombres
 * - Toggle d'affichage des champs de couleur de fond
 *
 * @package UltimateShanks\Style
 * @since 1.0.0
 */

document.addEventListener('DOMContentLoaded', function() {

	/**
	 * Synchroniser les color pickers avec les champs texte (bidirectionnel)
	 * Le champ texte peut être modifié manuellement avec une valeur hexadécimale
	 */
	const colorInputs = document.querySelectorAll('input[type="color"]');
	colorInputs.forEach(function(colorInput) {
		const textInput = colorInput.nextElementSibling;
		if (textInput && textInput.type === 'text') {
			// Color picker → champ texte
			colorInput.addEventListener('input', function() {
				textInput.value = this.value;
			});

			// Champ texte → color picker (synchronisation inverse)
			textInput.addEventListener('input', function() {
				let value = this.value.trim();

				// Ajouter # si absent
				if (value && !value.startsWith('#')) {
					value = '#' + value;
				}

				// Valider le format hexadécimal (#RGB ou #RRGGBB)
				if (/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(value)) {
					// Convertir #RGB en #RRGGBB pour le color picker
					if (value.length === 4) {
						value = '#' + value[1] + value[1] + value[2] + value[2] + value[3] + value[3];
					}
					colorInput.value = value;
					this.value = value;
				}
			});

			// Formater à la perte du focus
			textInput.addEventListener('blur', function() {
				let value = this.value.trim();

				if (value && !value.startsWith('#')) {
					value = '#' + value;
				}

				if (/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(value)) {
					if (value.length === 4) {
						value = '#' + value[1] + value[1] + value[2] + value[2] + value[3] + value[3];
					}
					this.value = value.toLowerCase();
					colorInput.value = value.toLowerCase();
				}
			});
		}
	});

	/**
	 * Gérer les sliders d'opacité
	 * Met à jour l'affichage de la valeur en temps réel
	 */
	const opacitySliders = document.querySelectorAll('.opacity-slider');
	opacitySliders.forEach(function(slider) {
		const valueDisplay = slider.nextElementSibling;
		slider.addEventListener('input', function() {
			if (valueDisplay) {
				valueDisplay.textContent = this.value;
			}
		});
	});

	/**
	 * Gérer les spinners de nombres
	 * Boutons +/- pour incrémenter/décrémenter les valeurs numériques
	 */
	document.querySelectorAll('.number-spinner').forEach(function(spinner) {
		const input = spinner.querySelector('input[type="number"]');
		const decreaseBtn = spinner.querySelector('.decrease');
		const increaseBtn = spinner.querySelector('.increase');

		// Bouton de décrémentation
		if (decreaseBtn && input) {
			decreaseBtn.addEventListener('click', function(e) {
				e.preventDefault();
				const step = parseInt(input.getAttribute('step')) || 1;
				const min = parseInt(input.getAttribute('min')) || 0;
				const currentValue = parseInt(input.value) || 0;
				input.value = Math.max(min, currentValue - step);
			});
		}

		// Bouton d'incrémentation
		if (increaseBtn && input) {
			increaseBtn.addEventListener('click', function(e) {
				e.preventDefault();
				const step = parseInt(input.getAttribute('step')) || 1;
				const max = parseInt(input.getAttribute('max')) || 9999;
				const currentValue = parseInt(input.value) || 0;
				input.value = Math.min(max, currentValue + step);
			});
		}
	});

	/**
	 * Toggle des champs de couleur de fond
	 *
	 * Affiche/masque les champs de couleur et d'opacité selon l'état de la checkbox
	 * Utilise la classe générique .hn-bg-checkbox pour tous les éléments HTML
	 * (titres, listes, tableaux, citations)
	 */
	document.querySelectorAll('.hn-bg-checkbox').forEach(function(checkbox) {
		const table = checkbox.closest('table');
		const bgRow = table.querySelector('.hn-bg-row');
		const opacityRow = table.querySelector('.hn-opacity-row');

		/**
		 * Fonction de toggle
		 * Affiche en table-row si checked, masque sinon
		 */
		function toggleColorControls() {
			if (bgRow) bgRow.style.display = checkbox.checked ? 'table-row' : 'none';
			if (opacityRow) opacityRow.style.display = checkbox.checked ? 'table-row' : 'none';
		}

		// Initialiser l'état au chargement de la page
		toggleColorControls();

		// Écouter les changements de la checkbox
		checkbox.addEventListener('change', toggleColorControls);
	});

});
