<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocCarrousel;

use SpiralBase\Core\Module;
use SpiralBase\Core\Signal;

/**
 * Bloc « carrousel » (CAP-12, story 3.5) — images, témoignages ou logos qui
 * défilent, sans aucune bibliothèque JavaScript.
 *
 * OFF par défaut (AD-6). Aucune sonde de cession (`null`) : aucun plugin de
 * carrousel n'est installé dans l'environnement de dev, et la discipline du
 * projet interdit une sonde sur des faits non lus (leçon 2.4). Le fond
 * diffère d'ailleurs des modules SEO : ce bloc ne rend que là où l'opérateur
 * l'a POSÉ — céder ferait disparaître un carrousel explicitement placé.
 */
final class BlocCarrouselModule implements Module
{
    public const HANDLE_STYLE = 'spiralbase-carrousel';

    public const NOM = 'spiralbase/carrousel';

    private const REPERTOIRE = 'carrousel';

    public function slug(): string
    {
        return 'bloc_carrousel';
    }

    public function boot(): void
    {
        add_action('init', static function (): void {
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => static fn (array $attributs, string $contenu = '', mixed $bloc = null): string
                    => (new RenduCarrousel())->rendre($attributs, $contenu, $bloc)]
            );

            if ($type === false) {
                /* Le cœur rend `false` pour deux causes sans rapport
                   (`class-wp-block-type-registry.php:83-91` pour le doublon,
                   `blocks.php` pour le métadonnées illisibles) : annoncer la
                   mauvaise envoie l'opérateur chercher un fichier corrompu
                   qui n'existe pas. */
                $doublon = class_exists('WP_Block_Type_Registry')
                    && \WP_Block_Type_Registry::get_instance()->is_registered(self::NOM);

                Signal::emettre(
                    'spiralbase_bloc_carrousel_enregistrement_echoue',
                    $doublon
                        ? 'bloc « carrousel » non enregistré : le nom ' . self::NOM . ' est déjà enregistré par une extension ou un thème enfant'
                        : 'bloc « carrousel » non enregistré : répertoire ou block.json illisible',
                    'bloc carrousel'
                );
            }
        });

        /*
         * `excerpt_remove_blocks()` supprime le bloc ET tout son contenu : une
         * page bâtie autour d'un carrousel n'avait plus d'extrait automatique
         * — donc plus d'`og:description` (le repli du module `opengraph`
         * s'effondre à son tour), plus de description RSS, plus de teaser
         * d'archive. Corrigé pour la carte en 3.2, jamais reporté ici.
         *
         * Les DEUX listes sont nécessaires : un bloc autorisé QUI A des
         * enfants est ignoré en silence (`blocks.php:2243-2256`) tant qu'il
         * n'est pas déclaré « wrapper » — seule la seconde autorise la
         * descente vers les images et les citations du carrousel.
         */
        $ajouter = static function ($blocs): array {
            return array_values(array_unique(array_merge(is_array($blocs) ? $blocs : [], [self::NOM])));
        };

        add_filter('excerpt_allowed_blocks', $ajouter);
        add_filter('excerpt_allowed_wrapper_blocks', $ajouter);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
