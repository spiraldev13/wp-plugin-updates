<?php

/**
 * Otomatic AI Integration
 *
 * Gère l'intégration avec le plugin Otomatic AI pour exposer
 * les statistiques de publications planifiées via l'API REST.
 *
 * @package UltimateShanks\Integration
 */

namespace UltimateShanks\Integration;

if (!defined('ABSPATH')) {
	exit;
}

class OtomaticIntegration
{
	/**
	 * Nom de l'option pour activer/désactiver l'intégration
	 */
	const OPTION_NAME = 'ultimate_shanks_otomatic_enabled';

	/**
	 * Cache des colonnes de la table Otomatic.
	 *
	 * @var array<int, string>|null
	 */
	private static $table_columns_cache = null;

	/**
	 * Liste des fichiers plugin Otomatic les plus courants.
	 *
	 * @var array<int, string>
	 */
	private static $otomatic_plugin_candidates = [
		'otomatic-ai/otomatic-ai.php',
		'otomatic-ai/otomatic.php',
		'otomatic/otomatic-ai.php',
		'otomatic/otomatic.php',
	];

	/**
	 * Initialise l'intégration
	 */
	public static function init()
	{
		add_action('rest_api_init', [self::class, 'register_rest_routes']);
	}

	/**
	 * Vérifie si l'intégration est activée
	 *
	 * @return bool
	 */
	public static function is_enabled()
	{
		return get_option(self::OPTION_NAME, '1') === '1';
	}

	/**
	 * Vérifie si le plugin Otomatic AI est installé
	 *
	 * @return bool
	 */
	public static function is_otomatic_installed()
	{
		return self::has_runtime_marker() || self::get_detected_plugin_basename() !== '';
	}

	/**
	 * Détecte Otomatic via son code chargé (constante / classe définies au load).
	 *
	 * Détection fiable quel que soit le nom du dossier ou le mode d'installation
	 * (dossier renommé, mu-plugin...) : si le code d'Otomatic tourne, ces
	 * marqueurs existent — là où active_plugins dépend du chemin du fichier.
	 *
	 * @return bool
	 */
	public static function has_runtime_marker()
	{
		return defined('OTOMATIC_AI_VERSION') || class_exists('OtomaticAi\\Plugin');
	}

	/**
	 * Retourne la version d'Otomatic si son code est chargé.
	 *
	 * @return string
	 */
	public static function get_detected_version()
	{
		return defined('OTOMATIC_AI_VERSION') ? (string) constant('OTOMATIC_AI_VERSION') : '';
	}

	/**
	 * Retourne le basename plugin Otomatic actif détecté.
	 *
	 * @return string
	 */
	public static function get_detected_plugin_basename()
	{
		$active_plugins = self::get_active_plugins();

		foreach (self::$otomatic_plugin_candidates as $candidate) {
			if (in_array($candidate, $active_plugins, true)) {
				return $candidate;
			}
		}

		// Fallback large : "otomatic" n'importe où dans le chemin, insensible à la
		// casse (dossiers renommés type wp-otomatic-ai/, Otomatic-AI/...). Le risque
		// de faux positif est neutralisé par la priorité au marqueur runtime dans
		// is_otomatic_installed().
		foreach ($active_plugins as $plugin_file) {
			if (stripos($plugin_file, 'otomatic') !== false) {
				return $plugin_file;
			}
		}

		return '';
	}

	/**
	 * Retourne la liste des plugins actifs (site + network).
	 * Public pour le diagnostic de l'onglet Options.
	 *
	 * @return array<int, string>
	 */
	public static function get_active_plugins()
	{
		$active_plugins = get_option('active_plugins', []);
		if (!is_array($active_plugins)) {
			$active_plugins = [];
		}

		if (is_multisite()) {
			$network_active = get_site_option('active_sitewide_plugins', []);
			if (is_array($network_active)) {
				$active_plugins = array_merge($active_plugins, array_keys($network_active));
			}
		}

		$active_plugins = array_map('strval', $active_plugins);
		return array_values(array_unique($active_plugins));
	}

	/**
	 * Vérifie si la table Otomatic AI existe
	 *
	 * @return bool
	 */
	public static function table_exists()
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'otomatic_ai_publications';
		return $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") === $table_name;
	}

	/**
	 * Récupère les colonnes disponibles de la table Otomatic.
	 *
	 * @return array<int, string>
	 */
	private static function get_table_columns()
	{
		if (is_array(self::$table_columns_cache)) {
			return self::$table_columns_cache;
		}

		if (!self::table_exists()) {
			self::$table_columns_cache = [];
			return self::$table_columns_cache;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'otomatic_ai_publications';
		$columns = $wpdb->get_col("SHOW COLUMNS FROM {$table_name}", 0);

		self::$table_columns_cache = is_array($columns) ? array_map('strval', $columns) : [];
		return self::$table_columns_cache;
	}

	/**
	 * Récupère le nombre d'articles planifiés dans Otomatic AI
	 *
	 * @return int
	 */
	public static function get_scheduled_count()
	{
		if (!self::is_enabled()) {
			return 0;
		}

		if (!self::table_exists()) {
			return 0;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'otomatic_ai_publications';
		$columns = self::get_table_columns();
		$where = in_array('status', $columns, true) ? "status = 'idle'" : '1=1';

		$count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name} WHERE {$where}");

		return (int) $count;
	}

	/**
	 * Récupère les données des publications Otomatic planifiées dans le futur
	 *
	 * @return array { count: int, furthest_date: string|null }
	 */
	public static function get_future_scheduled()
	{
		if (!self::is_enabled() || !self::table_exists()) {
			return ['count' => 0, 'furthest_date' => null];
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'otomatic_ai_publications';
		$columns = self::get_table_columns();

		// Certaines versions d'Otomatic n'exposent pas published_at.
		// On retourne alors un fallback sans date pour éviter les erreurs SQL.
		if (!in_array('published_at', $columns, true)) {
			return [
				'count' => self::get_scheduled_count(),
				'furthest_date' => null,
			];
		}

		$state_filters = [];
		if (in_array('status', $columns, true)) {
			$state_filters[] = "status = 'idle'";
		}
		if (in_array('post_id', $columns, true)) {
			$state_filters[] = 'post_id IS NULL';
		}
		$state_sql = empty($state_filters) ? '1=1' : '(' . implode(' OR ', $state_filters) . ')';

		$row = $wpdb->get_row(
			"SELECT COUNT(*) as count, MAX(published_at) as furthest_date
			 FROM {$table_name}
			 WHERE published_at > NOW()
			 AND {$state_sql}"
		);

		if (!is_object($row)) {
			return ['count' => 0, 'furthest_date' => null];
		}

		return [
			'count'         => isset($row->count) ? (int) $row->count : 0,
			'furthest_date' => isset($row->furthest_date) ? $row->furthest_date : null,
		];
	}

	/**
	 * Enregistre les routes REST API
	 */
	public static function register_rest_routes()
	{
		if (!self::is_enabled()) {
			return;
		}

		register_rest_route('ultimate-shanks/v1', '/otomatic-stats', [
			'methods'             => 'GET',
			'callback'            => [self::class, 'get_stats'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);

		register_rest_route('cmd/v1', '/otomatic-scheduled', [
			'methods'             => 'GET',
			'callback'            => [self::class, 'get_scheduled_for_cmd'],
			'permission_callback' => [self::class, 'check_permissions'],
		]);
	}

	/**
	 * Callback pour l'endpoint REST API existant
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function get_stats($request)
	{
		$scheduled_count = self::get_scheduled_count();
		$future = self::get_future_scheduled();

		return new \WP_REST_Response([
			'success'        => true,
			'scheduled'      => $scheduled_count,
			'future_count'   => $future['count'],
			'furthest_date'  => $future['furthest_date'],
			'enabled'        => self::is_enabled(),
			'installed'      => self::is_otomatic_installed(),
			'table_exists'   => self::table_exists(),
		], 200);
	}

	/**
	 * Callback pour WP Command Center
	 * Endpoint dédié : GET /wp-json/cmd/v1/otomatic-scheduled
	 *
	 * Retourne les articles individuels planifiés dans le futur.
	 *
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public static function get_scheduled_for_cmd($request)
	{
		if (!self::is_enabled() || !self::table_exists()) {
			return new \WP_REST_Response([
				'success'   => true,
				'scheduled' => [],
			], 200);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'otomatic_ai_publications';
		$columns = self::get_table_columns();

		if (!in_array('published_at', $columns, true)) {
			return new \WP_REST_Response([
				'success'   => true,
				'scheduled' => [],
			], 200);
		}

		// Construire SELECT dynamiquement selon les colonnes disponibles
		$select_fields = ['id', 'published_at'];

		if (in_array('title', $columns, true)) {
			$select_fields[] = 'title';
		}
		if (in_array('category', $columns, true)) {
			$select_fields[] = 'category';
		}
		if (in_array('status', $columns, true)) {
			$select_fields[] = 'status';
		}

		$select_sql = implode(', ', $select_fields);

		// Filtrer les articles planifiés dans le futur
		$state_filters = [];
		if (in_array('status', $columns, true)) {
			$state_filters[] = "status = 'idle'";
		}
		if (in_array('post_id', $columns, true)) {
			$state_filters[] = 'post_id IS NULL';
		}
		$state_sql = empty($state_filters) ? '1=1' : '(' . implode(' OR ', $state_filters) . ')';

		$rows = $wpdb->get_results(
			"SELECT {$select_sql}
			 FROM {$table_name}
			 WHERE published_at > NOW()
			 AND {$state_sql}
			 ORDER BY published_at ASC",
			ARRAY_A
		);

		if (!is_array($rows)) {
			$rows = [];
		}

		$scheduled = [];
		foreach ($rows as $row) {
			$scheduled[] = [
				'id'           => (int) $row['id'],
				'title'        => $row['title'] ?? 'Article Otomatic',
				'published_at' => $row['published_at'],
				'category'     => $row['category'] ?? null,
				'status'       => $row['status'] ?? 'idle',
			];
		}

		return new \WP_REST_Response([
			'success'   => true,
			'scheduled' => $scheduled,
		], 200);
	}

	/**
	 * Vérifie les permissions pour l'API REST
	 *
	 * @param \WP_REST_Request $request
	 * @return bool
	 */
	public static function check_permissions($request)
	{
		// Stats de planification = donnée business : réservé aux administrateurs.
		return current_user_can('manage_options');
	}
}
