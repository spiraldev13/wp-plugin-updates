#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Affichage de l'aide avec couleurs et emojis
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/utils.sh"

# Charger le type de projet si disponible
PROJECT_TYPE="basic"
if [ -f "$(pwd)/project.conf" ]; then
  source "$(pwd)/project.conf" 2>/dev/null || true
fi

echo ""
printf "  %b🚀 makedev — Commandes disponibles%b\n" "$C_BOLD$C_CYAN" "$C_RESET"
printf "  %b──────────────────────────────────%b\n" "$C_CYAN" "$C_RESET"

# --- Git ---
echo ""
printf "  %b📦 Git%b\n" "$C_BOLD$C_CYAN" "$C_RESET"
printf "  %b──────%b\n" "$C_CYAN" "$C_RESET"
printf "  📦  %bmake git%b             %bCommit + push sur dev/feature%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  🔀  %bmake merge%b           %bMerge dev → main%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  🌿  %bmake feature%b         %bCreer une branche feature%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  🔗  %bmake feature-merge%b   %bMerger la feature dans dev%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  🔧  %bmake branch-dev%b     %bCreer/synchroniser dev depuis main%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"

# --- WordPress ---
if [ "$PROJECT_TYPE" = "wordpress-plugin" ] || [ "$PROJECT_TYPE" = "wordpress-theme" ]; then
  echo ""
  printf "  %b🔧 WordPress%b\n" "$C_BOLD$C_CYAN" "$C_RESET"
  printf "  %b─────────────%b\n" "$C_CYAN" "$C_RESET"
  printf "  🔐  %bmake droits%b         %bAppliquer les permissions WordPress%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
  printf "  🔓  %bmake repo-public%b    %bPasser le repo updates en public%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
  printf "  🔒  %bmake repo-private%b   %bPasser le repo updates en prive%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
fi

# --- Outils ---
echo ""
printf "  %b⚙️  Outils%b\n" "$C_BOLD$C_CYAN" "$C_RESET"
printf "  %b──────────%b\n" "$C_CYAN" "$C_RESET"
printf "  🏁  %bmake init%b            %bInitialiser un nouveau projet%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  🔄  %bmake self-update%b     %bMettre a jour makedev + config Claude%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
printf "  ❓  %bmake help%b            %bAfficher cette aide%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"

if [ ! -d "$(pwd)/.make" ]; then
  printf "  📥  %bmake install%b        %bInstaller makedev sur le projet parent%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
fi
echo ""
