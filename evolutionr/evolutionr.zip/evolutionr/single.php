<?php
/**
 * single.php — Article de blog isolé (`/blog/<slug>/`).
 *
 * Présentation éditoriale : hero (breadcrumb + catégories + titre + chapô +
 * méta), image à la une optionnelle « en débord », corps en colonne de lecture
 * centrée avec typographie riche (`.prose`, partagée), puis pied (tags, partage
 * natif sans JS, navigation article précédent/suivant, retour au blog) et une
 * section « Articles liés » (même catégorie, réutilise `.blog-list`).
 *
 * Robuste avec ou sans image à la une. Aucun champ ACF : rendu issu du contenu
 * WordPress standard (titre, extrait, contenu, catégories, étiquettes).
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

while (have_posts()) :
    the_post();

    $categories  = get_the_category();
    $primaryCat  = !empty($categories) ? $categories[0] : null;
    $readingTime = evolutionr_reading_time(get_post());
    $permalink   = get_permalink();
    $shareTitle  = get_the_title();
    $blogUrl     = get_permalink((int) get_option('page_for_posts')) ?: home_url('/');
    ?>
    <main class="page-internal single-article" id="content">
        <article class="article">

            <?php /* ─── Hero ─── */ ?>
            <header class="article-hero">
                <div class="container">
                    <div class="article-shell">
                        <?php evolutionr_breadcrumb(); ?>

                        <?php if (!empty($categories)): ?>
                            <div class="article-cats">
                                <?php foreach ($categories as $c): ?>
                                    <a class="article-cat" href="<?php echo esc_url(get_category_link($c)); ?>">
                                        <?php echo esc_html($c->name); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <h1 class="article-title"><?php the_title(); ?></h1>

                        <?php if (has_excerpt()): ?>
                            <p class="article-lede"><?php echo esc_html(get_the_excerpt()); ?></p>
                        <?php endif; ?>

                        <div class="article-meta">
                            <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date()); ?></time>
                            <span class="article-meta-sep" aria-hidden="true">·</span>
                            <span><?php printf(esc_html__('%d min de lecture', 'evolutionr'), $readingTime); ?></span>
                        </div>
                    </div>
                </div>
            </header>

            <?php /* ─── Image à la une (optionnelle) ─── */ ?>
            <?php if (has_post_thumbnail()): ?>
                <figure class="article-cover">
                    <div class="container">
                        <div class="article-cover-frame">
                            <?php the_post_thumbnail('large', ['class' => 'article-cover-img', 'loading' => 'eager']); ?>
                        </div>
                    </div>
                </figure>
            <?php endif; ?>

            <?php /* ─── Corps ─── */ ?>
            <div class="article-body">
                <div class="container">
                    <div class="article-shell">
                        <div class="prose">
                            <?php the_content(); ?>
                        </div>

                        <?php
                        wp_link_pages([
                            'before'      => '<nav class="article-pagelinks" aria-label="' . esc_attr__('Pages de l\'article', 'evolutionr') . '"><span>' . esc_html__('Pages :', 'evolutionr') . '</span>',
                            'after'       => '</nav>',
                            'link_before' => '<span>',
                            'link_after'  => '</span>',
                        ]);
                        ?>

                        <?php $tags = get_the_tags(); ?>
                        <?php if ($tags): ?>
                            <div class="article-tags">
                                <?php foreach ($tags as $t): ?>
                                    <a class="article-tag" href="<?php echo esc_url(get_tag_link($t)); ?>">#<?php echo esc_html($t->name); ?></a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php /* ─── Pied : navigation article ─── */ ?>
            <?php
            $prevPost = get_previous_post();
            $nextPost = get_next_post();
            ?>
            <footer class="article-footer">
                <div class="container">
                    <div class="article-shell">
                        <?php if ($prevPost || $nextPost): ?>
                            <nav class="article-nav" aria-label="<?php esc_attr_e('Navigation des articles', 'evolutionr'); ?>">
                                <?php if ($prevPost): ?>
                                    <a class="article-nav-link is-prev" href="<?php echo esc_url(get_permalink($prevPost)); ?>" rel="prev">
                                        <span class="article-nav-dir"><?php esc_html_e('← Précédent', 'evolutionr'); ?></span>
                                        <span class="article-nav-title"><?php echo esc_html(get_the_title($prevPost)); ?></span>
                                    </a>
                                <?php else: ?>
                                    <span class="article-nav-spacer" aria-hidden="true"></span>
                                <?php endif; ?>

                                <?php if ($nextPost): ?>
                                    <a class="article-nav-link is-next" href="<?php echo esc_url(get_permalink($nextPost)); ?>" rel="next">
                                        <span class="article-nav-dir"><?php esc_html_e('Suivant →', 'evolutionr'); ?></span>
                                        <span class="article-nav-title"><?php echo esc_html(get_the_title($nextPost)); ?></span>
                                    </a>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>

                        <a class="article-back" href="<?php echo esc_url($blogUrl); ?>">
                            <?php esc_html_e('← Tous les articles', 'evolutionr'); ?>
                        </a>
                    </div>
                </div>
            </footer>
        </article>

        <?php /* ─── Articles liés (même catégorie) ─── */ ?>
        <?php
        if ($primaryCat) :
            $related = new \WP_Query([
                'category__in'        => [$primaryCat->term_id],
                'post__not_in'        => [get_the_ID()],
                'posts_per_page'      => 3,
                'no_found_rows'       => true,
                'ignore_sticky_posts' => true,
            ]);

            if ($related->have_posts()) : ?>
                <section class="section article-related" aria-labelledby="related-title">
                    <div class="container">
                        <header class="section-head">
                            <div class="section-head-left">
                                <div class="section-eyebrow-wrap">
                                    <span class="eyebrow"><?php esc_html_e('À lire aussi', 'evolutionr'); ?></span>
                                </div>
                                <h2 class="section-title" id="related-title"><?php esc_html_e('Articles liés', 'evolutionr'); ?></h2>
                            </div>
                        </header>

                        <div class="blog-list">
                            <?php $ri = 1; while ($related->have_posts()) : $related->the_post();
                                get_template_part('template-parts/cards/ligne-article', null, ['index' => $ri]);
                                $ri++;
                            endwhile; ?>
                        </div>
                    </div>
                </section>
            <?php endif;
            wp_reset_postdata();
        endif;
        ?>
    </main>
    <?php
endwhile;

get_footer();
