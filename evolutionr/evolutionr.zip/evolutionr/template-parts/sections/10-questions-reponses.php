<?php
/**
 * 08 — Questions/Réponses (FAQ accordéon).
 *
 * Visuel : grille 2 colonnes desktop. À gauche : eyebrow + titre + lede.
 * À droite : liste accordéon de questions. La première est ouverte par défaut.
 * Clic = bascule la classe `.open` sur l'item (JS dans app/main.js).
 *
 * Pilotage ACF (front-page) : faq_eyebrow, faq_title, faq_lede.
 * Questions alimentées par le repeater ACF `faq_items` (sous-champs
 * `question` / `answer`), édité directement sur la page d'accueil.
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow = get_field('faq_eyebrow') ?: __('FAQ', 'evolutionr');
$title   = get_field('faq_title') ?: __('Les questions qu\'on nous pose, en clair.', 'evolutionr');
$lede    = get_field('faq_lede');

$has_items = function_exists('have_rows') && have_rows('faq_items');

if (!$has_items) {
    return;
}
?>
<section class="section" aria-labelledby="faq-title">
    <div class="container">
        <div class="faq-grid">
            <div>
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <h2 class="section-title" id="faq-title" style="font-size: clamp(28px, 4.6vw, 46px);"><?php echo esc_html($title); ?></h2>
                <?php if ($lede): ?>
                    <p class="section-lede"><?php echo esc_html($lede); ?></p>
                <?php endif; ?>
            </div>

            <div class="faq-list">
                <?php $i = 0; while (have_rows('faq_items')): the_row();
                    $question = (string) get_sub_field('question');
                    $answer   = (string) get_sub_field('answer');
                    if ($question === '') continue;
                    $isOpen   = $i === 0;
                    ?>
                    <div class="faq-item<?php echo $isOpen ? ' open' : ''; ?>">
                        <button class="faq-q" type="button" aria-expanded="<?php echo $isOpen ? 'true' : 'false'; ?>">
                            <span><?php echo esc_html($question); ?></span>
                            <span class="chev" aria-hidden="true">
                                <?php evolutionr_icon('plus', 14); ?>
                            </span>
                        </button>
                        <div class="faq-a">
                            <div class="faq-a-inner"><?php echo wp_kses_post(wpautop($answer)); ?></div>
                        </div>
                    </div>
                    <?php $i++;
                endwhile; ?>
            </div>
        </div>
    </div>
</section>
