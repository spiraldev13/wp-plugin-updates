#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Initialisation interactive d'un projet
# Usage: bash core/scripts/init.sh
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAKEDEV_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
PROJECT_ROOT="$(pwd)"

source "$SCRIPT_DIR/utils.sh"

# === Fonctions d'init Git (extraites de git.sh original) ===

init_repo_if_needed() {
  if is_repo; then
    info "Depot Git deja initialise."
    return 0
  fi

  if git init -b main >/dev/null 2>&1; then
    info "Depot Git initialise (branche initiale: main)."
    return 0
  fi

  git init >/dev/null
  local current
  current="$(git branch --show-current || true)"
  if [ -n "$current" ] && [ "$current" != "main" ]; then
    git branch -m "main" >/dev/null 2>&1 || true
  fi
  info "Depot Git initialise."
}

ensure_initial_commit() {
  if has_commits; then
    return 0
  fi

  git add -A
  if git diff --cached --quiet; then
    error "Aucun fichier a commiter pour l initialisation. Ajoutez des fichiers puis relancez make init."
    exit 1
  fi

  if git commit -m "first commit" >/dev/null 2>&1; then
    info "Commit initial cree: first commit"
    return 0
  fi

  error "Impossible de creer le commit initial (configurez git user.name et user.email)."
  exit 1
}

ensure_branch_exists() {
  local branch="$1"

  if git show-ref --verify --quiet "refs/heads/$branch"; then
    return 0
  fi

  git branch "$branch"
  info "Branche $branch creee."
}

# === Clone sans .git (copie atomique) ===

clone_without_git() {
  local repo="$1"
  local target="$2"
  local tmp_dir
  tmp_dir="$(mktemp -d)"

  if ! git clone --depth 1 "$repo" "$tmp_dir/clone" >/dev/null 2>&1; then
    rm -rf "$tmp_dir"
    warn "Clone de $repo echoue (reseau ?). Etape ignoree."
    return 1
  fi

  rm -rf "$tmp_dir/clone/.git"
  mkdir -p "$(dirname "$target")"

  if [ -d "$target" ]; then
    rm -rf "$target"
  fi

  mv "$tmp_dir/clone" "$target"
  rm -rf "$tmp_dir"
  return 0
}

# === Creation du fichier de version initial ===

create_initial_version() {
  local type="$1"
  local project_root="$2"

  # Charger type.conf pour connaitre VERSION_FILE
  local type_conf="$MAKEDEV_DIR/types/$type/type.conf"
  local version_file="version.txt"
  local version_format="semver"

  if [ -f "$type_conf" ]; then
    source "$type_conf"
    version_file="${VERSION_FILE:-version.txt}"
    version_format="${VERSION_FORMAT:-semver}"
  fi

  local target="$project_root/$version_file"

  if [ -f "$target" ]; then
    info "Fichier de version $version_file deja existant."
    return 0
  fi

  mkdir -p "$(dirname "$target")"

  case "$version_format" in
    semver)
      printf "%s\n" "1.0.0" > "$target"
      ;;
    php-return)
      printf "%s\n" "<?php" \
        "/**" \
        " * Version du projet" \
        " *" \
        " * Format: Semantic Versioning (MAJOR.MINOR.PATCH)" \
        " * - MAJOR: Changements majeurs (breaking changes)" \
        " * - MINOR: Nouvelles fonctionnalites (compatibles)" \
        " * - PATCH: Corrections de bugs" \
        " */" \
        "" \
        "return '1.0.0';" > "$target"
      ;;
    css-header)
      local slug_name
      slug_name="$(basename "$project_root")"
      local theme_name
      theme_name="$(printf '%s' "$slug_name" | awk '{ gsub(/[-_]/, " "); for (i = 1; i <= NF; i++) { $i = toupper(substr($i,1,1)) substr($i,2) } print }')"
      printf "%s\n" "/*" \
        "Theme Name: $theme_name" \
        "Version: 1.0.0" \
        "Description: Theme WordPress" \
        "*/" > "$target"
      ;;
    php-array)
      local today
      today="$(date +%F)"
      printf "%s\n" "<?php" \
        "" \
        "return [" \
        "    'number' => '1.0.0'," \
        "    'date' => '$today'," \
        "];" > "$target"
      ;;
    *)
      printf "%s\n" "1.0.0" > "$target"
      ;;
  esac

  info "Fichier de version cree: $version_file (1.0.0)"
}

# === Generation du Makefile projet ===

generate_project_makefile() {
  local target="$1"

  cat > "$target" << 'MAKEFILE'
SHELL := /bin/bash
.DEFAULT_GOAL := help
.PHONY: help init git merge feature feature-merge self-update

include .make/core/makefile
MAKEFILE

  ok "Makefile genere."
}

# === Detection et backup Makefile existant ===

handle_existing_makefile() {
  local makefile_path=""

  if [ -f "$PROJECT_ROOT/Makefile" ]; then
    makefile_path="$PROJECT_ROOT/Makefile"
  elif [ -f "$PROJECT_ROOT/makefile" ]; then
    makefile_path="$PROJECT_ROOT/makefile"
  fi

  if [ -z "$makefile_path" ]; then
    return 0
  fi

  warn "Un Makefile existant a ete detecte: $(basename "$makefile_path")"
  echo ""
  read -r -p "Sauvegarder et remplacer ? (o/n) [o] : " choice
  choice="${choice:-o}"

  case "$choice" in
    o|O|oui|OUI|y|Y|yes)
      local timestamp
      timestamp="$(date +%Y%m%d-%H%M%S)"
      local backup="$makefile_path.bak.$timestamp"
      cp "$makefile_path" "$backup"
      ok "Backup cree: $(basename "$backup")"
      rm -f "$makefile_path"
      ;;
    *)
      info "Makefile conserve. Le nouveau sera ecrit dans Makefile (ecrasement)."
      rm -f "$makefile_path"
      ;;
  esac
}

# === Generation de project.conf ===

generate_project_conf() {
  local type="$1"
  local slug="$2"
  local target="$PROJECT_ROOT/project.conf"

  cat > "$target" << CONF
# project.conf — genere par makedev init
PROJECT_TYPE=$type
PROJECT_SLUG=$slug
MAKEDEV_REPO=git@github.com:spiraldev13/makedev.git
CLAUDE_REPO=git@github.com:spiraldev13/claude-config.git
CONF

  # Ajouter UPDATES_REPO pour les types WordPress
  case "$type" in
    wordpress-plugin|wordpress-theme)
      echo "UPDATES_REPO=wp-plugin-updates" >> "$target"
      ;;
  esac

  ok "project.conf genere (type=$type, slug=$slug)."
}

# === Detection migration ancien systeme ===

detect_legacy_artifacts() {
  local found=false

  if [ -d "$PROJECT_ROOT/.makefile-core" ]; then
    warn "Ancien dossier .makefile-core/ detecte (ancien systeme makefile_project)"
    found=true
  fi

  if [ -f "$PROJECT_ROOT/scripts/sync-makefile-core.sh" ]; then
    warn "Ancien script scripts/sync-makefile-core.sh detecte"
    found=true
  fi

  if [ -f "$PROJECT_ROOT/Makefile" ] && grep -q "MAKEFILE_CORE_DIR" "$PROJECT_ROOT/Makefile" 2>/dev/null; then
    warn "Ancien Makefile avec reference a MAKEFILE_CORE_DIR detecte"
    found=true
  fi

  if [ "$found" = false ]; then
    return 0
  fi

  echo ""
  info "Artefacts de l ancien systeme detectes. Migration recommandee."
  echo ""

  if [ -d "$PROJECT_ROOT/.makefile-core" ]; then
    read -r -p "Supprimer .makefile-core/ ? (o/n) [o] : " choice
    choice="${choice:-o}"
    case "$choice" in
      o|O|oui|y|Y) rm -rf "$PROJECT_ROOT/.makefile-core" && ok ".makefile-core/ supprime." ;;
      *) info ".makefile-core/ conserve. Supprimez-le manuellement plus tard." ;;
    esac
  fi

  if [ -f "$PROJECT_ROOT/scripts/sync-makefile-core.sh" ]; then
    read -r -p "Supprimer scripts/sync-makefile-core.sh ? (o/n) [o] : " choice
    choice="${choice:-o}"
    case "$choice" in
      o|O|oui|y|Y) rm -f "$PROJECT_ROOT/scripts/sync-makefile-core.sh" && ok "sync-makefile-core.sh supprime." ;;
      *) info "sync-makefile-core.sh conserve. Supprimez-le manuellement plus tard." ;;
    esac
  fi

  echo ""
}

# === Main ===

run_init() {
  echo ""
  printf "%b%bmakedev — Initialisation de projet%b\n" "$C_BOLD" "$C_CYAN" "$C_RESET"
  printf "%b=================================%b\n\n" "$C_CYAN" "$C_RESET"

  # --- Detection migration ---
  detect_legacy_artifacts

  # --- Prompt type de projet (menu numerote) ---
  local -a type_names=()
  local -a type_descs=()
  local i=0

  while IFS= read -r type_dir; do
    local tname
    tname="$(basename "$type_dir")"
    type_names+=("$tname")
    # Lire la description depuis la ligne 2 du type.conf (commentaire)
    local desc=""
    if [ -f "$type_dir/type.conf" ]; then
      desc="$(sed -n '2s/^# *//p' "$type_dir/type.conf" 2>/dev/null || true)"
    fi
    type_descs+=("${desc:-Pas de description}")
    i=$((i + 1))
  done < <(find "$MAKEDEV_DIR/types" -mindepth 1 -maxdepth 1 -type d | sort)

  if [ "${#type_names[@]}" -eq 0 ]; then
    error "Aucun type de projet trouve dans $MAKEDEV_DIR/types/"
    exit 1
  fi

  printf "%bTypes de projet disponibles :%b\n" "$C_BOLD" "$C_RESET"
  for i in "${!type_names[@]}"; do
    printf "  %b%d)%b %-12s %b— %s%b\n" "$C_YELLOW" "$((i + 1))" "$C_RESET" "${type_names[$i]}" "$C_GREEN" "${type_descs[$i]}" "$C_RESET"
  done
  echo ""
  read -r -p "Choix [1] : " type_choice
  type_choice="${type_choice:-1}"

  # Valider le choix
  if ! [[ "$type_choice" =~ ^[0-9]+$ ]] || [ "$type_choice" -lt 1 ] || [ "$type_choice" -gt "${#type_names[@]}" ]; then
    error "Choix invalide : $type_choice"
    exit 1
  fi

  local chosen_type="${type_names[$((type_choice - 1))]}"

  if [ ! -d "$MAKEDEV_DIR/types/$chosen_type" ]; then
    error "Type inconnu : $chosen_type"
    exit 1
  fi

  # Charger type.conf pour les hooks
  if [ -f "$MAKEDEV_DIR/types/$chosen_type/type.conf" ]; then
    source "$MAKEDEV_DIR/types/$chosen_type/type.conf"
  fi

  # --- Prompt slug ---
  local default_slug
  default_slug="$(basename "$PROJECT_ROOT")"
  echo ""
  read -r -p "Slug du projet (identifiant unique, ex: mon-plugin) ? [$default_slug] : " chosen_slug
  chosen_slug="${chosen_slug:-$default_slug}"

  # --- Verifier coherence slug / nom du dossier ---
  local current_dir_name
  current_dir_name="$(basename "$PROJECT_ROOT")"
  if [ "$chosen_slug" != "$current_dir_name" ]; then
    echo ""
    warn "Le slug \"$chosen_slug\" ne correspond pas au nom du dossier \"$current_dir_name\"."
    printf "  %b1)%b Renommer le dossier en %b$chosen_slug%b\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
    printf "  %b2)%b Utiliser %b$current_dir_name%b comme slug\n" "$C_YELLOW" "$C_RESET" "$C_GREEN" "$C_RESET"
    echo ""
    read -r -p "Choix [1] : " rename_choice
    rename_choice="${rename_choice:-1}"

    case "$rename_choice" in
      1)
        local new_path="$(dirname "$PROJECT_ROOT")/$chosen_slug"
        if [ -d "$new_path" ]; then
          error "Le dossier $new_path existe deja. Impossible de renommer."
          exit 1
        fi
        mv "$PROJECT_ROOT" "$new_path"
        PROJECT_ROOT="$new_path"
        MAKEDEV_DIR="$PROJECT_ROOT/.make"
        cd "$PROJECT_ROOT"
        ok "Dossier renomme en $chosen_slug/"
        ;;
      2)
        chosen_slug="$current_dir_name"
        info "Slug mis a jour : $chosen_slug"
        ;;
      *)
        chosen_slug="$current_dir_name"
        info "Choix invalide. Slug mis a jour : $chosen_slug"
        ;;
    esac
  fi

  # --- Prompt Claude ---
  echo ""
  if [ -d "$PROJECT_ROOT/.claude" ] || [ -f "$PROJECT_ROOT/CLAUDE.md" ]; then
    warn "Une config Claude Code existe deja. L installation ecrasera : .claude/, CLAUDE.md, tasks/"
  fi
  read -r -p "Installer la config Claude Code ? (o/n) [o] : " install_claude
  install_claude="${install_claude:-o}"

  echo ""
  info "Configuration : type=$chosen_type, slug=$chosen_slug, claude=$install_claude"
  echo ""

  # --- Generation des fichiers ---
  generate_project_conf "$chosen_type" "$chosen_slug"
  create_initial_version "$chosen_type" "$PROJECT_ROOT"

  # --- Task 4 : Clone Claude ---
  case "$install_claude" in
    o|O|oui|OUI|y|Y|yes)
      info "Installation de la config Claude Code..."
      local tmp_claude
      tmp_claude="$(mktemp -d)"
      if git clone --depth 1 "git@github.com:spiraldev13/claude-config.git" "$tmp_claude/clone" >/dev/null 2>&1; then
        local src="$tmp_claude/clone/claude-code-projet"
        if [ -d "$src" ]; then
          # Copier tout sauf README.md a la racine
          find "$src" -maxdepth 1 -mindepth 1 ! -name 'README.md' -exec cp -a {} "$PROJECT_ROOT/" \;
          # Copier README.md dans .claude/
          [ -f "$src/README.md" ] && cp "$src/README.md" "$PROJECT_ROOT/.claude/README.md"
          ok "Config Claude installee (.claude/, CLAUDE.md, tasks/)"
        else
          warn "Dossier claude-code-projet/ introuvable dans le repo claude-config."
        fi
        rm -rf "$tmp_claude"
      else
        rm -rf "$tmp_claude"
        warn "Clone de claude-config echoue (reseau ?). Etape ignoree."
      fi
      ;;
    *)
      info "Config Claude ignoree."
      ;;
  esac

  # --- README.md du projet ---
  if [ ! -f "$PROJECT_ROOT/README.md" ]; then
    printf '%s\n' "# $chosen_slug" > "$PROJECT_ROOT/README.md"
    info "README.md cree."
  fi

  # --- .TREE.md ---
  if [ ! -f "$PROJECT_ROOT/.TREE.md" ]; then
    local tree_src="$MAKEDEV_DIR/types/$chosen_type/.TREE.md"
    if [ -f "$tree_src" ]; then
      cp "$tree_src" "$PROJECT_ROOT/.TREE.md"
      info ".TREE.md cree."
    fi
  fi

  # --- STATUS.md ---
  if [ ! -f "$PROJECT_ROOT/STATUS.md" ]; then
    local status_src="$MAKEDEV_DIR/core/templates/STATUS.md"
    if [ -f "$status_src" ]; then
      sed "s/{{SLUG}}/$chosen_slug/g" "$status_src" > "$PROJECT_ROOT/STATUS.md"
      info "STATUS.md cree."
    fi
  fi

  # --- Ajout de .make/ au .gitignore ---
  local gitignore="$PROJECT_ROOT/.gitignore"
  if [ -f "$gitignore" ]; then
    if ! grep -qx '.make/' "$gitignore" 2>/dev/null; then
      echo '.make/' >> "$gitignore"
      info ".make/ ajoute au .gitignore existant."
    fi
  else
    printf '%s\n' '.make/' '*.bak.*' > "$gitignore"
    info ".gitignore cree avec .make/ et *.bak.*"
  fi

  # --- Task 3 : Init Git ---
  echo ""
  init_repo_if_needed
  ensure_initial_commit
  ensure_branch_exists "main"
  ensure_branch_exists "dev"
  git checkout "main" >/dev/null 2>&1 || git checkout "main"

  # --- Hook post-init specifique au type ---
  if [ -n "${POST_INIT_HOOK:-}" ]; then
    local hook_script="$MAKEDEV_DIR/types/$chosen_type/$POST_INIT_HOOK"
    if [ -f "$hook_script" ]; then
      echo ""
      info "Configuration specifique au type $chosen_type..."
      export MAKEDEV_DIR PROJECT_ROOT="$PROJECT_ROOT" PROJECT_SLUG="$chosen_slug" PROJECT_TYPE="$chosen_type"
      if ! bash "$hook_script"; then
        warn "Hook post-init echoue. L initialisation reste valide."
      fi
    else
      warn "Hook post-init configure ($POST_INIT_HOOK) mais fichier introuvable: $hook_script"
    fi
  fi

  echo ""
  ok "Initialisation terminee !"
  info "Branche active : main"
  info "Pour developper : git checkout dev"
  echo ""
}

run_init
