<?php

declare(strict_types=1);

/*
 * Autoload PSR-4 maison : SpiralBase\ → src/.
 * Zéro Composer au runtime (convention spine) — Composer ne sert qu'à
 * l'outillage de dev (PHPUnit).
 */
spl_autoload_register(static function (string $class): void {
    $prefix = 'SpiralBase\\';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));

    /*
     * class_exists() transmet la chaîne brute à l'autoloader : un nom de
     * classe légitime ne contient jamais « .. » — rejeter toute tentative
     * de traversée de chemin hors de src/.
     */
    if (str_contains($relative, '..')) {
        return;
    }

    $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';

    if (is_file($file)) {
        require $file;
    }
});
