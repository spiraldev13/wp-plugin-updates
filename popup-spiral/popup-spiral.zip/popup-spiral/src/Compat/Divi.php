<?php

namespace Spiral\Compat;

use Spiral\PostTypes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Compatibilité Divi : le Divi Builder (y compris le Visual Builder)
 * s'active directement sur le contenu des popups.
 *
 * Hooks posés sur `after_setup_theme` car Divi peut être un thème,
 * chargé après les plugins.
 */
final class Divi
{
    public static function register(): void
    {
        add_action('after_setup_theme', [self::class, 'setup'], 5);
    }

    public static function setup(): void
    {
        if (!self::isDiviAvailable()) {
            return;
        }

        add_filter('et_builder_post_types', [self::class, 'addPopupSupport']);
        add_filter('et_fb_post_types', [self::class, 'addPopupSupport']);
        add_filter('register_post_type_args', [self::class, 'makeQueryableForBuilder'], 10, 2);

        // Divi 4 casse l'éditeur de blocs sur les CPT : éditeur classique forcé.
        if (self::isDiviFour()) {
            add_filter('use_block_editor_for_post_type', [self::class, 'forceClassicEditor'], 999, 2);
        }
    }

    /**
     * @param array $postTypes
     * @return array
     */
    public static function addPopupSupport($postTypes)
    {
        if (is_array($postTypes) && !in_array(PostTypes::POPUP, $postTypes, true)) {
            $postTypes[] = PostTypes::POPUP;
        }

        return $postTypes;
    }

    /**
     * Le CPT popup n'est interrogeable publiquement que pendant une session
     * d'édition Divi, par un utilisateur autorisé — jamais pour un visiteur.
     *
     * @param array  $args
     * @param string $postType
     * @return array
     */
    public static function makeQueryableForBuilder($args, $postType)
    {
        if ($postType !== PostTypes::POPUP || !self::isBuilderRequest()) {
            return $args;
        }

        if (!current_user_can('edit_posts')) {
            return $args;
        }

        $args['publicly_queryable'] = true;

        return $args;
    }

    /**
     * @param bool   $useBlockEditor
     * @param string $postType
     * @return bool
     */
    public static function forceClassicEditor($useBlockEditor, $postType)
    {
        if ($postType === PostTypes::POPUP) {
            return false;
        }

        return $useBlockEditor;
    }

    private static function isDiviAvailable(): bool
    {
        return defined('ET_BUILDER_THEME')
            || defined('ET_BUILDER_PLUGIN_VERSION')
            || defined('ET_BUILDER_VERSION')
            || function_exists('et_setup_builder')
            || function_exists('et_divi_fonts_url');
    }

    private static function isDiviFour(): bool
    {
        if (defined('ET_BUILDER_PRODUCT_VERSION')) {
            return version_compare(ET_BUILDER_PRODUCT_VERSION, '5.0', '<');
        }

        // Version indéterminable : on force l'éditeur classique par prudence.
        return true;
    }

    private static function isBuilderRequest(): bool
    {
        // Lecture seule de marqueurs d'URL Divi — pas une donnée de formulaire.
        return isset($_GET['et_fb']) || isset($_GET['et_bfb']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    }
}
