<?php
/**
 * Motif hero « Création de site » — wireframe de navigateur.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Une fenêtre stylisée (feux + barre d'URL) au-dessus d'un canevas de blocs de
 * layout qui s'assemblent. Tout en unités relatives → responsive 320px → desktop.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="hvw">
    <div class="hvw-bar">
        <span class="hvw-dot"></span>
        <span class="hvw-dot"></span>
        <span class="hvw-dot"></span>
        <span class="hvw-url">evolutionr.fr</span>
    </div>
    <div class="hvw-canvas">
        <span class="hvw-block hvw-hero" style="--d: 0;"></span>
        <div class="hvw-row">
            <span class="hvw-block hvw-card" style="--d: 1;"></span>
            <span class="hvw-block hvw-card" style="--d: 2;"></span>
            <span class="hvw-block hvw-card" style="--d: 3;"></span>
        </div>
        <span class="hvw-block hvw-line" style="--d: 4;"></span>
        <span class="hvw-block hvw-line hvw-line--short" style="--d: 5;"></span>
    </div>
</div>
