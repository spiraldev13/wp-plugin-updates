# spiralbase — thème parent

Thème parent modulaire (microkernel) de la base WordPress réutilisable.
Planchers : WordPress ≥ 6.8, PHP ≥ 8.3. Text-domain : `spiralbase`.

- Architecture de référence : spine « base-wordpress-reutilisable » dans le dépôt
  source <https://github.com/spiraldev13/wordpress-theme-spiralbase> (le thème
  distribué seul n'embarque pas ce document).
- Toute fonctionnalité est un module du registre (AD-1) — le noyau (`src/Core/`) ne contient aucune logique métier.

## Slugs canoniques de tokens — contrat gelé (AD-15)

Les slugs ci-dessous sont un **contrat immuable** : thèmes enfants générés,
presets, CSS d'appoint et panneau Couleurs n'emploient que ces slugs. Un design
client change les **valeurs**, jamais les slugs. Toute évolution de cette liste
est un breaking change du parent.

### Palette (`settings.color.palette`)

| Slug | Usage |
| --- | --- |
| `primary` | Couleur de marque principale (liens, boutons) |
| `secondary` | Couleur de marque secondaire |
| `accent` | Accent ponctuel (CTA, surlignages) |
| `base` | Fond du site |
| `contrast` | Texte principal (contraste sur `base`) |
| `base-2` | Fond alternatif (sections, cartes) |
| `contrast-2` | Texte atténué (métadonnées, légendes) |

### Typographie

| Type | Slug | Usage |
| --- | --- | --- |
| Famille | `heading` | Titres (h1–h6 via `elements.heading`) |
| Famille | `body` | Corps de texte |
| Taille | `small` | Métadonnées, légendes, h5/h6 — **non fluide** (exception assumée au contrat « chaque taille avec bornes » : une petite taille qui rétrécit encore devient illisible) |
| Taille | `medium` | Corps de texte, h4 (fluide) |
| Taille | `large` | h3, intertitres (fluide) |
| Taille | `x-large` | h2 (fluide) |
| Taille | `xx-large` | h1, héros (fluide) |

### Espacements (`settings.spacing.spacingSizes`)

Échelle standard WordPress — compatible avec les presets `var:preset|spacing|N`
émis par l'éditeur :

| Slug | Valeur par défaut | Usage |
| --- | --- | --- |
| `20` | 0.25rem | Micro-espacement (icône/texte) |
| `30` | 0.5rem | Espacement serré intra-composant |
| `40` | 1rem | Espacement courant (padding header) |
| `50` | 1.5rem | Rythme vertical par défaut (`blockGap`, gouttières) |
| `60` | 2.5rem | Respiration de section (padding footer) |
| `70` | 4rem | Séparation de sections |
| `80` | 6rem | Grandes respirations (héros, CTA) |

Variables CSS générées : `--wp--preset--color--{slug}`,
`--wp--preset--font-size--{slug}`, `--wp--preset--font-family--{slug}`,
`--wp--preset--spacing--{slug}`.

## Développement

```bash
composer install        # outillage dev uniquement (PHPUnit) — jamais requis au runtime
./vendor/bin/phpunit    # tests du noyau
```

L'autoload runtime est maison (`src/autoload.php`, PSR-4 `SpiralBase\` → `src/`) —
zéro dépendance Composer en production.
