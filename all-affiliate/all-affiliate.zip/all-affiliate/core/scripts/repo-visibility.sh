#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Gestion de la visibilite du repo updates GitHub
# Usage: bash repo-visibility.sh {public|private}
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

source "$SCRIPT_DIR/utils.sh"

VISIBILITY="${1:-}"

if [ "$VISIBILITY" != "public" ] && [ "$VISIBILITY" != "private" ]; then
  error "Usage: repo-visibility.sh {public|private}"
  exit 1
fi

# === Charger la config ===

UPDATES_REPO_NAME="${UPDATES_REPO:-wp-plugin-updates}"

if [ -f "$PROJECT_ROOT/project.conf" ]; then
  source "$PROJECT_ROOT/project.conf"
  UPDATES_REPO_NAME="${UPDATES_REPO:-wp-plugin-updates}"
fi

# Detecter le user GitHub depuis le remote origin
GITHUB_USER=""
origin_url="$(git remote get-url origin 2>/dev/null || true)"

if [ -n "$origin_url" ]; then
  GITHUB_USER="$(echo "$origin_url" | sed -nE 's#.*github\.com[:/]([^/]+)/.*#\1#p')"
fi

if [ -z "$GITHUB_USER" ]; then
  error "Impossible de detecter le user GitHub depuis le remote origin."
  exit 1
fi

REPO="$GITHUB_USER/$UPDATES_REPO_NAME"

# === Verifier gh CLI ===

if ! command -v gh >/dev/null 2>&1; then
  error "GitHub CLI (gh) n est pas installe."
  info "Installation : https://cli.github.com/"
  exit 1
fi

if ! gh auth status >/dev/null 2>&1; then
  error "GitHub CLI n est pas authentifie."
  info "Lancez : gh auth login"
  exit 1
fi

# === Changer la visibilite ===

echo ""
if [ "$VISIBILITY" = "public" ]; then
  printf "%b%b🔓 Passage de %s en public...%b\n" "$C_BOLD" "$C_CYAN" "$REPO" "$C_RESET"
else
  printf "%b%b🔒 Passage de %s en prive...%b\n" "$C_BOLD" "$C_CYAN" "$REPO" "$C_RESET"
fi
echo ""

if ! gh repo edit "$REPO" --visibility "$VISIBILITY" --accept-visibility-change-consequences 2>&1; then
  error "Impossible de changer la visibilite de $REPO."
  exit 1
fi

echo ""
if [ "$VISIBILITY" = "public" ]; then
  ok "$REPO est maintenant public."
  info "Les sites WordPress peuvent detecter les mises a jour."
  info "Pensez a repasser en prive apres les mises a jour : make repo-private"
else
  ok "$REPO est maintenant prive."
  info "Les mises a jour WordPress sont bloquees (raw.githubusercontent.com retourne 404)."
  info "Les plugins deja installes continuent de fonctionner normalement."
fi
echo ""
