<?php
/**
 * Les cinq requêtes de l'accueil (integration-wordpress.md) sans PHP de
 * gabarit : les Query Loop de front-page.html portent un queryId réservé, et
 * ce filtre leur injecte sélection « à la une », offsets et déduplication.
 *
 * Cartographie des queryId (front-page.html) :
 *   30      — mosaïque, articles 1-5 de la sélection à la une
 *   31      — liste « À la une », articles 6-25 de la sélection
 *   32      — « Derniers articles », 12 derniers hors doublons
 *   40 + i  — bloc de rubrique i (0-5), unité grande (1 article)
 *   50 + i  — bloc de rubrique i (0-5), unités liste (3 articles)
 *
 * Un même article n'apparaît jamais deux fois sur l'écran : chaque requête
 * enregistre ses identifiants dans un registre partagé et les suivantes les
 * excluent. Les volumes viennent tous de techanaRevueReglagesUne()
 * (inc/une-reglages.php), aucun n'est codé ici.
 *
 * La sélection est un complément, pas un repli : les articles cochés
 * « Afficher à la une » passent devant, les places restantes sont prises par
 * les plus récents. Une une à moitié remplie ne vide donc jamais l'accueil.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'query_loop_block_query_vars', 'techanaRevueQueryAccueil', 10, 2 );
add_filter( 'render_block_core/group', 'techanaRevueSectionVide', 10, 2 );

/**
 * Une section de l'accueil sans aucun article n'est pas émise du tout : un
 * volume réglé à 0 (ou une rubrique au-delà de la limite) laisserait sinon son
 * pavé de titre, son filet et ses marges seuls à l'écran.
 *
 * Le test porte sur les unités rendues par core/post-template, qui émet des
 * `<li class="wp-block-post post-123 …">` — l'espace après la classe évite de
 * confondre avec wp-block-post-title ou wp-block-post-template.
 */
function techanaRevueSectionVide( $html, $block ) {
    if ( ! is_front_page() || ! is_string( $html ) ) {
        return $html;
    }
    $classes = explode( ' ', (string) ( $block['attrs']['className'] ?? '' ) );
    if ( ! in_array( 'block', $classes, true ) ) {
        return $html;
    }
    return str_contains( $html, 'wp-block-post ' ) ? $html : '';
}

/**
 * Articles cochés « à la une », complétés par les plus récents jusqu'à
 * $total. Un complément partiel, jamais un remplacement : trois articles
 * cochés donnent trois articles choisis suivis des plus récents.
 *
 * @param int $total Nombre de places à pourvoir.
 * @return int[]
 */
function techanaRevueArticlesUne( int $total ): array {
    if ( $total < 1 ) {
        return array();
    }
    $ids = get_posts( array(
        'numberposts' => $total,
        'fields'      => 'ids',
        'meta_key'    => '_techana_une',
        'meta_value'  => '1',
    ) );
    $manquants = $total - count( $ids );
    if ( $manquants < 1 ) {
        return $ids;
    }
    return array_merge( $ids, get_posts( array(
        'numberposts' => $manquants,
        'fields'      => 'ids',
        'exclude'     => $ids,
    ) ) );
}

/**
 * Sélection de la une : mosaïque puis section « À la une », dans cet ordre.
 *
 * @return int[]
 */
function techanaRevueSelectionUne(): array {
    static $ids = null;
    if ( null === $ids ) {
        $reglages = techanaRevueReglagesUne();
        $ids      = techanaRevueArticlesUne( $reglages['mosaique'] + $reglages['une'] );
    }
    return $ids;
}

/**
 * Registre des articles déjà affichés sur l'écran courant.
 *
 * @param int[] $ajouts Identifiants à enregistrer.
 * @return int[] Registre à jour.
 */
function techanaRevueRegistre( array $ajouts = array() ): array {
    static $vus = array();
    if ( $ajouts ) {
        $vus = array_values( array_unique( array_merge( $vus, $ajouts ) ) );
    }
    return $vus;
}

/**
 * Rubrique affichée en position $i sur l'accueil — les premières par volume,
 * dans la limite du réglage, même source que le pavé techana/pave-rubrique.
 * Au-delà de la limite : null, donc ni pavé ni articles (section escamotée).
 */
function techanaRevueRubriquePosition( int $i ): ?object {
    static $rubs = null;
    if ( null === $rubs ) {
        $limite = techanaRevueReglagesUne()['rubriques'];
        $rubs   = $limite > 0 ? techanaRevueRubriques( $limite ) : array();
    }
    return $rubs[ $i ] ?? null;
}

/**
 * Force une liste d'identifiants calculée : post__in strict, ordre préservé.
 */
function techanaRevueQueryFixe( array $query, array $ids ): array {
    techanaRevueRegistre( $ids );
    $query['post__in']            = $ids ? $ids : array( 0 );
    $query['orderby']             = 'post__in';
    $query['posts_per_page']      = max( 1, count( $ids ) );
    $query['ignore_sticky_posts'] = true;
    unset( $query['offset'] );
    return $query;
}

function techanaRevueQueryAccueil( array $query, WP_Block $block ): array {
    $id       = (int) ( $block->context['queryId'] ?? -1 );
    $reglages = techanaRevueReglagesUne();

    if ( 30 === $id ) {
        $selection = techanaRevueSelectionUne();
        return techanaRevueQueryFixe( $query, array_slice( $selection, 0, $reglages['mosaique'] ) );
    }
    if ( 31 === $id ) {
        $selection = techanaRevueSelectionUne();
        return techanaRevueQueryFixe(
            $query,
            array_slice( $selection, $reglages['mosaique'], $reglages['une'] )
        );
    }
    if ( 32 === $id ) {
        $ids = $reglages['derniers'] > 0 ? get_posts( array(
            'numberposts' => $reglages['derniers'],
            'fields'      => 'ids',
            'exclude'     => techanaRevueRegistre(),
        ) ) : array();
        return techanaRevueQueryFixe( $query, $ids );
    }
    if ( 60 === $id && is_singular( 'post' ) ) {
        // « Articles similaires » de l'article : même rubrique d'abord,
        // article courant exclu, complété par les plus récents si besoin.
        $courant = get_queried_object_id();
        $cats    = get_the_category( $courant );
        $ids     = $cats ? get_posts( array(
            'numberposts' => 4,
            'fields'      => 'ids',
            'category'    => $cats[0]->term_id,
            'exclude'     => array( $courant ),
        ) ) : array();
        if ( count( $ids ) < 4 ) {
            $complement = get_posts( array(
                'numberposts' => 4 - count( $ids ),
                'fields'      => 'ids',
                'exclude'     => array_merge( array( $courant ), $ids ),
            ) );
            $ids = array_merge( $ids, $complement );
        }
        return techanaRevueQueryFixe( $query, $ids );
    }
    if ( $id >= 40 && $id < 60 ) {
        $position = $id % 10;
        $nombre   = $id < 50 ? 1 : $reglages['rub_liste'];
        $rubrique = techanaRevueRubriquePosition( $position );
        if ( ! $rubrique || $nombre < 1 ) {
            return techanaRevueQueryFixe( $query, array() );
        }
        $ids = get_posts( array(
            'numberposts' => $nombre,
            'fields'      => 'ids',
            'category'    => $rubrique->term->term_id,
            'exclude'     => techanaRevueRegistre(),
        ) );
        return techanaRevueQueryFixe( $query, $ids );
    }
    return $query;
}
