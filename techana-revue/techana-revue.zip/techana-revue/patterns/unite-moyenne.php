<?php
/**
 * Title: Unité article — moyenne
 * Slug: techana-revue/unite-moyenne
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Image 3:2, étiquette, titre 19px, signature — grilles « Derniers articles ».
 * Viewport Width: 400
 */
?>
<!-- wp:group {"className":"u-med k-auto"} -->
<div class="wp-block-group u-med k-auto"><!-- wp:post-featured-image {"sizeSlug":"techana-3-2","className":"ph-auto"} /-->

<!-- wp:post-terms {"term":"category","className":"u-cat"} /-->

<!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:paragraph {"className":"meta","metadata":{"bindings":{"content":{"source":"techana/meta-carte"}}}} -->
<p class="meta"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
