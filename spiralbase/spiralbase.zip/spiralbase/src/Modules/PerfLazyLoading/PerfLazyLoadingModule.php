<?php

declare(strict_types=1);

namespace SpiralBase\Modules\PerfLazyLoading;

use SpiralBase\Core\Module;
use SpiralBase\Core\SondeCession;

/**
 * Garant du lazy loading natif (CAP-15, AC 2 story 2.4) : le cœur WP pose
 * `loading="lazy"` sur les images de contenu depuis 5.5 — le module
 * garantit qu'aucun tiers ne l'éteint (pattern garant 2.2, priorité 100 —
 * écrasement ASSUMÉ et silencieux : c'est la définition d'un garant).
 * Le cœur EXEMPTE les 3 premiers médias de contenu (candidats LCP, seuil
 * `wp_omit_loading_attr_threshold`, vérifié en audit 2.4) :
 * « systématiquement » = toutes les images lazy-loadables au-delà.
 *
 * Faits FlyingPress : voir `Core\FlyingPress` (statut documentaire).
 */
final class PerfLazyLoadingModule implements Module
{
    /** @param \Closure():bool|null $faitLazyFlyingPress fait injectable pour les tests */
    public function __construct(private readonly ?\Closure $faitLazyFlyingPress = null)
    {
    }

    public function slug(): string
    {
        return 'perf_lazy_loading';
    }

    public function boot(): void
    {
        add_filter('wp_lazy_loading_enabled', '__return_true', 100);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitLazyFlyingPress ?? static fn (): bool => \SpiralBase\Core\FlyingPress::levierActif('lazy_load'),
            static fn (): string => __('Lazy loading réellement pris en charge par FlyingPress.', 'spiralbase')
        );
    }
}
