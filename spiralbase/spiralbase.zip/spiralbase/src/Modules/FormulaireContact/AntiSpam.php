<?php

declare(strict_types=1);

namespace SpiralBase\Modules\FormulaireContact;

/**
 * Quatre couches anti-spam, aucune visible (story 3.8).
 *
 * Le parti pris de l'AC 2 est qu'un visiteur légitime ne doit RIEN voir : pas
 * de CAPTCHA, pas de case à cocher, pas de calcul. Les robots sont écartés par
 * des propriétés qu'un humain a naturellement et qu'un script n'a pas — un
 * champ leurre qu'il est seul à remplir, un délai de saisie plausible, un
 * jeton qu'il ne peut pas forger, et un débit raisonnable.
 *
 * Chaque vérification rend une RAISON, jamais un simple booléen : le rejet est
 * silencieux pour le visiteur, mais il doit être diagnosticable côté serveur —
 * c'est la seule trace qu'un opérateur aura d'un formulaire qui refuse tout.
 */
final class AntiSpam
{
    /** Nom plausible : un robot qui remplit « tout ce qui ressemble à un champ » tombe dedans. */
    public const CHAMP_LEURRE = 'spiralbase_site_web';

    public const CHAMP_JETON = 'spiralbase_jeton';

    /** Un humain ne lit pas, ne réfléchit pas et ne tape pas en moins de 3 secondes. */
    public const DELAI_MINIMAL = 3;

    /**
     * Âge maximal d'un jeton — LARGE, et c'est délibéré.
     *
     * Le formulaire est rendu dans une page, donc mis en cache avec elle. Un
     * jeton court transformait chaque page cachée depuis plus d'une heure en
     * formulaire mort : le visiteur était remercié, sa demande jetée, et
     * l'opérateur ne voyait rien — prouvé en revue, 100 % des demandes perdues
     * sur un site derrière un cache. La fraîcheur n'est pas ce que ce jeton
     * prouve ; il prouve que le formulaire vient bien de CE site.
     */
    public const VALIDITE_JETON = 604800;

    public const PLAFOND_IP = 5;

    public const FENETRE_IP = 3600;

    /**
     * Bornes de RÉCEPTION — avant tout traitement.
     *
     * Le stockage bornait déjà, mais le sujet du courriel était construit sur
     * le nom BRUT : un nom de 200 000 caractères produisait un sujet de
     * 200 025 caractères, encodé et recopié plusieurs fois par PHPMailer. Le
     * plafond réel était `post_max_size`, soit 8 Mo.
     */
    public const LONGUEUR_MAX = ['spiralbase_nom' => 200, 'spiralbase_email' => 320, 'spiralbase_message' => 5000];

    /** @var \Closure(): int horloge injectable — sans elle, rien de tout ceci n'est testable */
    private \Closure $maintenant;

    public function __construct(?\Closure $maintenant = null)
    {
        $this->maintenant = $maintenant ?? static fn (): int => time();
    }

    /**
     * Jeton SIGNÉ portant l'instant d'affichage.
     *
     * Un horodatage en clair dans le HTML se réécrit d'une ligne de script ;
     * signé par `wp_hash()`, il ne se falsifie pas sans les clés du site.
     */
    public function jeton(): string
    {
        $instant = ($this->maintenant)();

        return $instant . '.' . $this->signature($instant);
    }

    /**
     * @param  array<string, mixed> $donnees champs reçus, déjà déslashés
     * @return string|null la raison du rejet, ou `null` si la soumission passe
     */
    public function verifier(array $donnees, string $ip): ?string
    {
        /* Le leurre d'abord : c'est la vérification la moins chère, et celle
           qui attrape la majorité des robots. */
        if (trim((string) ($donnees[self::CHAMP_LEURRE] ?? '')) !== '') {
            return 'leurre';
        }

        $instant = $this->instantDuJeton((string) ($donnees[self::CHAMP_JETON] ?? ''));

        if ($instant === null) {
            return 'jeton';
        }

        $ecoule = ($this->maintenant)() - $instant;

        if ($ecoule < self::DELAI_MINIMAL) {
            return 'delai';
        }

        if (!$this->champsComplets($donnees)) {
            return 'champs';
        }

        if (!$this->longueursRaisonnables($donnees)) {
            return 'longueur';
        }

        if (!$this->sousLePlafond($ip)) {
            return 'plafond';
        }

        return null;
    }

    /** @param array<string, mixed> $donnees */
    private function champsComplets(array $donnees): bool
    {
        foreach (['spiralbase_nom', 'spiralbase_message'] as $champ) {
            $valeur = $donnees[$champ] ?? null;

            if (!is_string($valeur) || trim($valeur) === '') {
                return false;
            }
        }

        $email = $donnees['spiralbase_email'] ?? null;

        return is_string($email) && is_email(trim($email)) !== false;
    }

    /** @param array<string, mixed> $donnees */
    private function longueursRaisonnables(array $donnees): bool
    {
        foreach (self::LONGUEUR_MAX as $champ => $max) {
            $valeur = $donnees[$champ] ?? '';

            if (is_string($valeur) && mb_strlen($valeur) > $max) {
                return false;
            }
        }

        return true;
    }

    /**
     * Fenêtre glissante par adresse — l'IP n'est JAMAIS stockée en clair.
     *
     * Le plafond est une donnée de sécurité, pas une donnée personnelle
     * conservée : ce qui vit en base est un condensat, et il périme tout seul.
     * Le module RGPD (2.5) n'a donc rien à déclarer de plus que le contenu du
     * message lui-même.
     */
    /**
     * Incrémente le compteur de façon ATOMIQUE.
     *
     * `get_transient` puis `set_transient` est une séquence lue-puis-écrite :
     * 30 processus concurrents lisaient tous la même valeur et 20 passaient là
     * où 5 étaient permis — mesuré. Un `UPDATE … = … + 1` en base est
     * indivisible, et c'est la seule façon de borner un débit face à ce que ce
     * plafond est censé arrêter : un robot qui tire en parallèle.
     */
    public function compter(string $ip): void
    {
        $cle = $this->cleDuCompteur($ip);

        if (!$this->incrementerAtomiquement($cle)) {
            set_transient($cle, ((int) get_transient($cle)) + 1, self::FENETRE_IP);
        }
    }

    private function incrementerAtomiquement(string $cle): bool
    {
        global $wpdb;

        if (!is_object($wpdb) || !method_exists($wpdb, 'query') || wp_using_ext_object_cache()) {
            /* Cache objet externe : les transients ne vivent plus en base,
               l'UPDATE ne mordrait sur rien. */
            return false;
        }

        $option = '_transient_' . $cle;

        if ((int) $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = %s",
            $option
        )) === 1) {
            return true;
        }

        /* Première tentative de la fenêtre : `set_transient` pose la valeur ET
           sa péremption. Une course ici fait au pire repartir le compteur à 1
           une fois — sans commune mesure avec le défaut corrigé. */
        return false;
    }

    private function sousLePlafond(string $ip): bool
    {
        return ((int) get_transient($this->cleDuCompteur($ip))) < self::PLAFOND_IP;
    }

    /**
     * Clé de comptage — sur le RÉSEAU, pas sur l'adresse exacte.
     *
     * Compter par adresse exacte ne plafonnait rien : une même machine
     * dispose couramment d'une IPv4 et d'une IPv6 (deux compteurs), et tout
     * abonné IPv6 se voit déléguer un /64 — soit 2⁶⁴ compteurs pour une seule
     * personne. Prouvé en revue : quota épuisé en `::1`, soumission acceptée
     * depuis `127.0.0.1`, même client.
     *
     * On agrège donc sur /32 en IPv4 et sur /64 en IPv6.
     */
    private function cleDuCompteur(string $ip): string
    {
        $binaire = @inet_pton($ip);

        if ($binaire === false) {
            /* Adresse illisible : tout le monde dans le même seau plutôt
               qu'un seau par valeur fantaisiste. */
            $reseau = 'inconnu';
        } elseif (strlen($binaire) === 16) {
            $reseau = 'v6:' . bin2hex(substr($binaire, 0, 8));
        } else {
            $reseau = 'v4:' . bin2hex($binaire);
        }

        return 'spiralbase_formulaire_' . substr(wp_hash($reseau, 'nonce'), 0, 32);
    }

    /** Instant d'affichage porté par un jeton valide, ou `null`. */
    private function instantDuJeton(string $jeton): ?int
    {
        if (!str_contains($jeton, '.')) {
            return null;
        }

        [$instant, $signature] = explode('.', $jeton, 2);

        /* Modificateur `D` : sans lui, `$` accepte un saut de ligne final en
           PCRE, et « 1800000000\n » passait pour une forme canonique. */
        if (preg_match('/^\d{1,12}$/D', $instant) !== 1) {
            return null;
        }

        /* `hash_equals` : la comparaison d'une signature ne se fait pas avec
           `===`, dont le temps d'exécution renseigne sur le préfixe correct. */
        if (!hash_equals($this->signature((int) $instant), $signature)) {
            return null;
        }

        $ecoule = ($this->maintenant)() - (int) $instant;

        /* Un jeton venu du FUTUR ne s'explique par rien de légitime : horloge
           trafiquée ou horodatage réécrit. Un jeton vieux, lui, s'explique
           très bien — une page servie par un cache. */
        return $ecoule < 0 || $ecoule > self::VALIDITE_JETON ? null : (int) $instant;
    }

    private function signature(int $instant): string
    {
        return wp_hash('spiralbase_formulaire|' . $instant, 'nonce');
    }
}
