<?php
/**
 * Portrait des rédacteurs : une image choisie dans la médiathèque depuis
 * l'écran de profil, avec repli en initiales.
 *
 * Le thème appelait get_avatar(), donc Gravatar : sans compte associé, il ne
 * renvoie qu'une silhouette générique — et il expose l'adresse IP du lecteur à
 * un service tiers à chaque page d'article. Le portrait est désormais servi par
 * le site ; le repli en initiales garantit qu'un rédacteur a toujours une
 * identité visuelle, sans requête externe.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_PORTRAIT_META = '_techana_portrait';

// Seule la substitution d'URL est un filtre global : elle vaut aussi pour
// get_avatar_url(), donc pour le JSON-LD, sans jamais changer le markup.
// La pastille d'initiales, elle, n'est PAS branchée sur le filtre get_avatar :
// ce filtre s'applique à tous les appels de WordPress — dont ceux de la barre
// d'administration, qui n'est pas une vue d'admin côté front — et la pastille
// s'y affichait à la place de l'avatar, sans tenir compte de la taille
// demandée. Le thème l'appelle explicitement où il la veut.
add_filter( 'pre_get_avatar_data', 'techanaRevuePortraitData', 10, 2 );
add_action( 'show_user_profile', 'techanaRevueChampPortrait' );
add_action( 'edit_user_profile', 'techanaRevueChampPortrait' );
add_action( 'personal_options_update', 'techanaRevueEnregistrerPortrait' );
add_action( 'edit_user_profile_update', 'techanaRevueEnregistrerPortrait' );
add_action( 'admin_enqueue_scripts', 'techanaRevuePortraitAssets' );

/**
 * Identifiant d'utilisateur derrière les formes acceptées par get_avatar().
 *
 * @param mixed $source WP_User, identifiant, e-mail, WP_Post ou WP_Comment.
 */
function techanaRevueIdUtilisateur( $source ): int {
    if ( $source instanceof WP_User ) {
        return (int) $source->ID;
    }
    if ( $source instanceof WP_Post ) {
        return (int) $source->post_author;
    }
    if ( $source instanceof WP_Comment ) {
        return (int) $source->user_id;
    }
    if ( is_numeric( $source ) ) {
        return (int) $source;
    }
    if ( is_string( $source ) && is_email( $source ) ) {
        $user = get_user_by( 'email', $source );
        return $user ? (int) $user->ID : 0;
    }
    return 0;
}

/** Image de la médiathèque associée au rédacteur, 0 si aucune. */
function techanaRevuePortraitId( int $userId ): int {
    return $userId ? (int) get_user_meta( $userId, TECHANA_PORTRAIT_META, true ) : 0;
}

/**
 * Substitue le portrait local à l'URL Gravatar — vaut aussi pour
 * get_avatar_url(), donc pour le JSON-LD des auteurs.
 */
function techanaRevuePortraitData( array $args, $source ): array {
    $piece = techanaRevuePortraitId( techanaRevueIdUtilisateur( $source ) );
    if ( ! $piece ) {
        return $args;
    }
    $url = wp_get_attachment_image_url( $piece, 'techana-avatar' );
    if ( $url ) {
        $args['url']           = $url;
        $args['found_avatar']  = true;
    }
    return $args;
}

/** Deux initiales au plus, tirées du nom affiché. */
function techanaRevueInitiales( string $nom ): string {
    $mots = preg_split( '/[\s\-]+/u', trim( $nom ), -1, PREG_SPLIT_NO_EMPTY );
    if ( ! $mots ) {
        return '?';
    }
    $lettres = mb_substr( $mots[0], 0, 1 );
    if ( isset( $mots[1] ) ) {
        $lettres .= mb_substr( $mots[1], 0, 1 );
    }
    return mb_strtoupper( $lettres );
}

/**
 * Portrait d'un rédacteur pour les deux emplacements du thème qui en montrent
 * un : la boîte de fin d'article et l'en-tête de la page auteur.
 *
 * Portrait de la médiathèque s'il existe, sinon une pastille d'initiales. À
 * appeler explicitement — surtout pas à brancher sur le filtre `get_avatar` :
 * WordPress s'en sert aussi pour la barre d'administration et les
 * commentaires, où une pastille sans dimensions propres n'a rien à faire.
 *
 * @param int    $userId Rédacteur concerné.
 * @param int    $taille Côté demandé, en pixels.
 * @param string $alt    Texte de remplacement (nom affiché par défaut).
 */
function techanaRevuePortrait( int $userId, int $taille = 144, string $alt = '' ): string {
    $user = $userId ? get_userdata( $userId ) : null;
    if ( ! $user ) {
        return '';
    }
    $nom = '' !== $alt ? $alt : $user->display_name;

    if ( techanaRevuePortraitId( $userId ) ) {
        return get_avatar( $userId, $taille, '', $nom, array( 'class' => 'avatar' ) );
    }

    // L'initiale est portée par un enfant : c'est lui qui se dimensionne sur
    // la pastille (unités de conteneur), impossible depuis la pastille même.
    return sprintf(
        '<span class="avatar avatar-initiales" role="img" aria-label="%s"><span>%s</span></span>',
        esc_attr( $nom ),
        esc_html( techanaRevueInitiales( $user->display_name ) )
    );
}

/**
 * Champ de choix du portrait, sur l'écran de profil.
 */
function techanaRevueChampPortrait( WP_User $user ) {
    if ( ! current_user_can( 'edit_user', $user->ID ) ) {
        return;
    }
    $piece = techanaRevuePortraitId( $user->ID );
    wp_nonce_field( 'techana-portrait', 'techana_portrait_nonce' );
    ?>
    <h2>Portrait TechAna</h2>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="techana-image-techana-portrait-bouton">Photo du rédacteur</label></th>
            <td>
                <?php
                techanaRevueChampImage( array(
                    'nom'    => 'techana_portrait',
                    'valeur' => $piece,
                    'titre'  => 'Portrait du rédacteur',
                    'vide'   => sprintf(
                        'Aucune photo : les initiales « %s » s\'affichent à la place.',
                        techanaRevueInitiales( $user->display_name )
                    ),
                    'taille' => 'techana-avatar',
                    'cote'   => 96,
                ) );
                ?>
                <p class="description">
                    Affichée en carré sur la fiche auteur, la boîte de fin d'article et la page
                    de l'auteur. L'image est recadrée, jamais déformée.
                </p>
            </td>
        </tr>
    </table>
    <?php
}

function techanaRevueEnregistrerPortrait( int $userId ) {
    if ( ! current_user_can( 'edit_user', $userId ) ) {
        return;
    }
    $nonce = $_POST['techana_portrait_nonce'] ?? '';
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), 'techana-portrait' ) ) {
        return;
    }
    $piece = isset( $_POST['techana_portrait'] ) ? (int) $_POST['techana_portrait'] : 0;
    if ( $piece && 'attachment' === get_post_type( $piece ) ) {
        update_user_meta( $userId, TECHANA_PORTRAIT_META, $piece );
    } else {
        delete_user_meta( $userId, TECHANA_PORTRAIT_META );
    }
}

function techanaRevuePortraitAssets( string $hook ) {
    if ( ! in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) ) {
        return;
    }
    techanaRevueChampImageAssets();
}
