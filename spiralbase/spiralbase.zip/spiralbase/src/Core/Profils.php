<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Profils métier (AD-14) : `profiles/{slug}.json`, données pures du parent.
 *
 * Un profil n'écrit JAMAIS un interrupteur. Il fournit au registre le DÉFAUT
 * des modules qu'aucun humain n'a tranchés — exactement au même titre que
 * `Module::enabledByDefault()`, qu'il précède d'un cran. L'option canonique
 * du registre ne contient donc que des décisions HUMAINES, et « les choix
 * manuels ne sont jamais écrasés » (AC 2) cesse d'être une promesse tenue par
 * vigilance : aucun chemin de code ne permet à un profil d'y toucher.
 *
 * « Appliqué une seule fois » porte sur le CHOIX du profil : le marqueur est
 * revendiqué de façon atomique (`add_option`, seule primitive indivisible
 * sans cache objet — leçons 3.3 et 3.8), et une re-sélection exige une action
 * humaine explicite.
 *
 * Deux régimes, un seul juge :
 *  - STRICT à la porte (`appliquer`) — un humain est là, il peut corriger ;
 *  - TOLÉRANT au runtime — une entrée douteuse est écartée et signalée, le
 *    reste du profil tient. Un site ne perd pas sa configuration parce qu'une
 *    release a retiré un module (doctrine de la 3.6 : le doute conserve).
 */
final class Profils
{
    public const OPTION = 'spiralbase_profil';

    public const SCHEMA_VERSION = 1;

    /** Champs admis à la racine — vocabulaire fermé, comme DonneesMetier. */
    private const CHAMPS = ['schema_version', 'slug', 'libelle', 'description', 'modules'];

    private const LONGUEUR_LIBELLE = 100;

    private const LONGUEUR_DESCRIPTION = 300;

    /** Un slug de module plus long n'existe pas (frontière WordPress). */
    private const LONGUEUR_SLUG_MODULE = 60;

    /** Borne de plausibilité d'un horodatage d'application (an 2100). */
    private const DATE_MAX = 4102444800;

    /** @var array<string, array<string, bool>> map des modules, par slug de profil (une lecture disque par requête) */
    private array $memo = [];

    public function __construct(private readonly string $repertoire)
    {
    }

    /**
     * Slugs des profils livrés, triés. Un répertoire absent n'est pas une
     * erreur ici : c'est « aucun profil ».
     *
     * @return list<string>
     */
    public function disponibles(): array
    {
        $slugs = [];

        foreach (glob($this->repertoire . '/*.json') ?: [] as $fichier) {
            $slug = basename($fichier, '.json');

            if ($this->slugValide($slug)) {
                $slugs[] = $slug;

                continue;
            }

            /* Un fichier posé là que le thème refuse de voir doit se dire :
               sans ce signal, « Restaurant.json » est un profil livré,
               invisible, et l'opérateur cherche une panne qui n'existe pas. */
            $this->signalerIllisible(sprintf(
                'fichier « %s » ignoré : nom hors format (minuscules, chiffres, tiret et souligné)',
                basename($fichier)
            ));
        }

        sort($slugs);

        return $slugs;
    }

    /**
     * Profil normalisé, ou l'échec exact.
     *
     * @return array{slug: string, libelle: string, description: string, modules: array<string, bool>, rejets: list<string>}|\WP_Error|null
     *         null = slug inconnu ; WP_Error = présent mais inexploitable
     */
    public function get(string $slug): array|\WP_Error|null
    {
        /* Le slug vient potentiellement d'une entrée externe (CLI) : aucun
           chemin relatif ne doit pouvoir sortir du répertoire. */
        if (!$this->slugValide($slug)) {
            return null;
        }

        $fichier = $this->repertoire . '/' . $slug . '.json';

        if (!is_dir($this->repertoire) || !is_file($fichier)) {
            return null;
        }

        if (!is_readable($fichier)) {
            return $this->refus($slug, 'fichier présent mais non lisible (permissions)');
        }

        $brut = file_get_contents($fichier);

        if ($brut === false) {
            return $this->refus($slug, 'échec de lecture du fichier (I/O)');
        }

        $donnees = json_decode($brut, true);

        if (!is_array($donnees)) {
            return $this->refus($slug, 'JSON invalide');
        }

        return $this->normaliser($slug, $donnees);
    }

    /**
     * Marqueur du profil appliqué, ou null.
     *
     * @return array{slug: string, applique_le: int, modules: array<string, bool>}|null
     */
    public function marqueur(): ?array
    {
        $valeur = get_option(self::OPTION, null);

        if ($valeur === null || $valeur === false) {
            return null;
        }

        if (!is_array($valeur) || !is_string($valeur['slug'] ?? null) || !$this->slugValide($valeur['slug'])) {
            $this->signalerIllisible('marqueur de profil corrompu — aucun profil appliqué ne sera pris en compte');

            return null;
        }

        $date = $valeur['applique_le'] ?? 0;

        return [
            'slug'        => $valeur['slug'],
            /* Jamais de cast aveugle : un objet en base lèverait un warning
               dans `after_setup_theme`, et une valeur démesurée afficherait
               une date de l'an 71856. */
            'applique_le' => is_int($date) && $date > 0 && $date <= self::DATE_MAX ? $date : 0,
            'modules'     => $this->modulesDeSecours($valeur['modules'] ?? null),
        ];
    }

    /**
     * Instantané de secours : la carte des modules figée au moment de
     * l'application.
     *
     * Sans lui, le fichier de profil est une dépendance VIVE de chaque
     * requête, donc un point de défaillance permanent pour toute la flotte —
     * et le pire qui soit, puisque tous les blocs métier naissent OFF (AD-6) :
     * un `.json` abîmé par un transfert interrompu ou renommé par une release
     * faisait disparaître carte, horaires, adresse et formulaire du site d'un
     * client, en HTTP 200, sans un mot (revue 3.9, mesuré sur le front réel).
     *
     * Doctrine déjà établie en 3.3 pour les avis Google : la copie de secours
     * ne peut pas être vidée par une panne. Le fichier reste prioritaire tant
     * qu'il est lisible — une release qui amende un profil produit donc bien
     * son effet.
     *
     * @return array<string, bool>
     */
    private function modulesDeSecours(mixed $brut): array
    {
        if (!is_array($brut)) {
            return [];
        }

        $modules = [];

        foreach ($brut as $slug => $etat) {
            if (is_string($slug) && is_bool($etat) && preg_match('/^[a-z][a-z0-9_]*$/D', $slug)) {
                $modules[$slug] = $etat;
            }
        }

        return $modules;
    }

    public function slugApplique(): ?string
    {
        return $this->marqueur()['slug'] ?? null;
    }

    /**
     * Revendique le profil. Seconde application refusée : c'est le sens de
     * « seed appliqué une seule fois » (AD-14). `--force` est l'action humaine
     * explicite que l'AC 2 nomme — et même sous force, aucun interrupteur
     * humain n'est touché : la garantie ne dépend pas du drapeau.
     *
     * @return true|\WP_Error
     */
    public function appliquer(string $slug, bool $force = false): bool|\WP_Error
    {
        $profil = $this->get($slug);

        if ($profil instanceof \WP_Error) {
            return $profil;
        }

        if ($profil === null) {
            $disponibles = $this->disponibles();

            return new \WP_Error('spiralbase_profil_inconnu', sprintf(
                /* translators: 1: slug demandé, 2: liste des profils livrés. */
                __('Profil « %1$s » inconnu. Profils livrés : %2$s.', 'spiralbase'),
                $slug,
                $disponibles === [] ? __('aucun', 'spiralbase') : implode(', ', $disponibles)
            ));
        }

        if ($profil['rejets'] !== []) {
            return new \WP_Error('spiralbase_profil_invalide', sprintf(
                /* translators: 1: slug du profil, 2: liste des entrées refusées. */
                __('Profil « %1$s » refusé : %2$s', 'spiralbase'),
                $slug,
                implode(' ; ', $profil['rejets'])
            ));
        }

        /* Le marqueur emporte la carte résolue : c'est elle qui sert de
           secours si le fichier devient illisible (voir modulesDeSecours). */
        $valeur = ['slug' => $slug, 'applique_le' => time(), 'modules' => $profil['modules']];

        if (!$force) {
            /* Revendication INDIVISIBLE : deux processus concurrents (le
               pipeline du mardi et une commande lancée à la main) ne peuvent
               pas appliquer deux profils différents en croyant chacun être
               seul. `add_option()` ne le garantit pas — il contrôle par
               lecture puis écrase (revue 3.9, `option.php:1117-1140`). */
            if (!OptionAtomique::insererSiAbsent(self::OPTION, $valeur, true)) {
                /* Distinguer les deux causes d'un refus : un marqueur présent
                   (course perdue, ou profil déjà appliqué) et une écriture
                   impossible (base en lecture seule, disque plein). Les
                   confondre envoie l'opérateur relancer avec --force alors
                   que rien ne sera écrit non plus. */
                if (get_option(self::OPTION, null) === null) {
                    return new \WP_Error('spiralbase_profil_ecriture', __('Échec d\'écriture du marqueur de profil — rien n\'a été enregistré.', 'spiralbase'));
                }

                return new \WP_Error('spiralbase_profil_deja_applique', sprintf(
                    /* translators: %s : slug du profil déjà en place. */
                    __('Un profil est déjà appliqué sur ce site (« %s »). La re-sélection est une action humaine explicite : relancer avec --force. Les choix manuels ne seront pas écrasés.', 'spiralbase'),
                    $this->slugApplique() ?? __('illisible', 'spiralbase')
                ));
            }

            $this->memo = [];
            do_action('spiralbase_profil_applique', $slug, false);

            return true;
        }

        /* update_option() rend false quand la valeur est INCHANGÉE : relire
           fait la différence entre « rien à écrire » et « écriture ratée ». */
        if (!update_option(self::OPTION, $valeur, true) && $this->slugApplique() !== $slug) {
            return new \WP_Error('spiralbase_profil_ecriture', __('Échec de persistance du profil — rien n\'a été enregistré.', 'spiralbase'));
        }

        $this->memo = [];
        do_action('spiralbase_profil_applique', $slug, true);

        return true;
    }

    /**
     * Retire le profil appliqué — action humaine explicite, écrite par le
     * propriétaire de l'option (AD-11), jamais par un `wp option delete`.
     *
     * @return bool false = il n'y avait rien à retirer
     */
    public function retirer(): bool
    {
        if (get_option(self::OPTION, null) === null) {
            return false;
        }

        delete_option(self::OPTION);
        $this->memo = [];
        do_action('spiralbase_profil_retire');

        return true;
    }

    /**
     * Défaut fourni par le profil appliqué pour CE module — null quand le
     * profil ne dit rien de lui (il ne décide alors pas à sa place), quand
     * aucun profil n'est appliqué, ou quand le profil est devenu illisible.
     *
     * Ne jette jamais : le registre l'appelle pour chaque module, à chaque
     * requête, depuis `after_setup_theme`.
     */
    public function defautModule(string $slugModule): ?bool
    {
        $marqueur = $this->marqueur();

        if ($marqueur === null) {
            return null;
        }

        $slug = $marqueur['slug'];

        if (!isset($this->memo[$slug])) {
            $this->memo[$slug] = $this->chargerModules($marqueur);
        }

        return $this->memo[$slug][$slugModule] ?? null;
    }

    /**
     * @param array{slug: string, applique_le: int, modules: array<string, bool>} $marqueur
     *
     * @return array<string, bool>
     */
    private function chargerModules(array $marqueur): array
    {
        $profil = $this->get($marqueur['slug']);

        if (is_array($profil)) {
            foreach ($profil['rejets'] as $rejet) {
                Signal::emettre('spiralbase_profil_entree_ignoree', $rejet, 'profil');
            }

            return $profil['modules'];
        }

        if ($marqueur['modules'] !== []) {
            $this->signalerIllisible(sprintf(
                'profil appliqué « %s » introuvable ou illisible — configuration de secours du marqueur utilisée (%d module(s))',
                $marqueur['slug'],
                count($marqueur['modules'])
            ));

            return $marqueur['modules'];
        }

        $this->signalerIllisible(sprintf(
            'profil appliqué « %s » introuvable ou illisible, et aucune configuration de secours — chaque module retombe sur son propre défaut',
            $marqueur['slug']
        ));

        return [];
    }

    /**
     * @param array<mixed> $donnees
     *
     * @return array{slug: string, libelle: string, description: string, modules: array<string, bool>, rejets: list<string>}|\WP_Error
     */
    private function normaliser(string $slug, array $donnees): array|\WP_Error
    {
        $inconnues = array_diff(array_keys($donnees), self::CHAMPS);

        if ($inconnues !== []) {
            return $this->refus($slug, sprintf('clés inconnues : %s', implode(', ', array_map('strval', $inconnues))));
        }

        if (($donnees['schema_version'] ?? null) !== self::SCHEMA_VERSION) {
            return $this->refus($slug, sprintf('schema_version %d attendue — une version inconnue n\'est jamais interprétée', self::SCHEMA_VERSION));
        }

        /* Deux identités pour un même profil finiraient par diverger : le
           marqueur pointe le nom de FICHIER, le fichier doit s'y reconnaître. */
        if (($donnees['slug'] ?? null) !== $slug) {
            return $this->refus($slug, 'le slug déclaré ne correspond pas au nom du fichier');
        }

        $libelle = $donnees['libelle'] ?? null;

        if (!is_string($libelle) || trim($libelle) === '' || mb_strlen($libelle) > self::LONGUEUR_LIBELLE) {
            return $this->refus($slug, sprintf('« libelle » obligatoire (chaîne non vide de %d caractères au plus)', self::LONGUEUR_LIBELLE));
        }

        /* Clé PRÉSENTE mais nulle ≠ clé absente : `?? ''` coercerait `null`
           en silence, et un profil dont la clause « modules » vaut null
           s'appliquerait en ne configurant rien, en annonçant un succès. */
        $description = array_key_exists('description', $donnees) ? $donnees['description'] : '';

        if (!is_string($description) || mb_strlen($description) > self::LONGUEUR_DESCRIPTION) {
            return $this->refus($slug, sprintf('« description » doit être une chaîne de %d caractères au plus', self::LONGUEUR_DESCRIPTION));
        }

        $brut = array_key_exists('modules', $donnees) ? $donnees['modules'] : [];

        if (!is_array($brut)) {
            return $this->refus($slug, '« modules » doit être un objet {slug: booléen}');
        }

        $modules = [];
        $rejets  = [];

        foreach ($brut as $slugModule => $etat) {
            /* PHP caste les clés numériques d'un objet JSON en entiers
               (leçon 2.8) : la garde de type précède toute opération de
               chaîne, sinon str_starts_with() lèverait une TypeError. */
            if (!is_string($slugModule) || strlen($slugModule) > self::LONGUEUR_SLUG_MODULE
                || !preg_match('/^[a-z][a-z0-9_]*$/D', $slugModule)) {
                $rejets[] = sprintf('entrée « %s » : slug de module hors format', is_string($slugModule) ? $slugModule : (string) $slugModule);

                continue;
            }

            if (!is_bool($etat)) {
                $rejets[] = sprintf('module « %s » : booléen attendu (%s reçu)', $slugModule, get_debug_type($etat));

                continue;
            }

            $modules[$slugModule] = $etat;
        }

        return [
            'slug'        => $slug,
            'libelle'     => $libelle,
            'description' => $description,
            'modules'     => $modules,
            'rejets'      => $rejets,
        ];
    }

    private function slugValide(string $slug): bool
    {
        return (bool) preg_match('/^[a-z0-9][a-z0-9_-]*$/D', $slug);
    }

    private function refus(string $slug, string $detail): \WP_Error
    {
        $message = sprintf(
            /* translators: 1: slug du profil, 2: détail du refus. */
            __('Profil « %1$s » inexploitable : %2$s.', 'spiralbase'),
            $slug,
            $detail
        );

        $this->signalerIllisible(sprintf('profil « %s » : %s', $slug, $detail));

        return new \WP_Error('spiralbase_profil_illisible', $message);
    }

    private function signalerIllisible(string $message): void
    {
        Signal::emettre('spiralbase_profil_illisible', $message, 'profil');
    }
}
