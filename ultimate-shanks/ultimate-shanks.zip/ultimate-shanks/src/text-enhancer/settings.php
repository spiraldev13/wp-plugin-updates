<?php

namespace UltimateShanks\TextEnhancer;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Page de paramètres Optimiseur de Paragraphes
 *
 * @package UltimateShanks
 * @subpackage TextEnhancer
 */
class Settings
{
	/**
	 * Initialise les paramètres
	 */
	public static function init()
	{
		// Enregistrer les paramètres
		add_action('admin_init', [self::class, 'register_settings']);
	}

	/**
	 * Enregistre tous les paramètres
	 */
	public static function register_settings()
	{
		// Activation globale
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_enabled');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_mode');

		// Options de découpage
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_min_length');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_sentences_per_p');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_ignore_links');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_ignore_shortcodes');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_ignore_classes');

		// Options SEO
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_fix_em_dash');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_remove_hr');

		// Mode debug
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_debug_mode');

		// Espacement
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_line_breaks');

		// Exclusions
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_excluded_post_types');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_excluded_ids');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_excluded_slugs');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_excluded_categories');
		register_setting('ultimate_shanks_text_enhancer', 'ultimate_shanks_text_enhancer_excluded_keywords');
	}

	/**
	 * Affiche l'onglet Optimiseur de Paragraphes
	 */
	public static function render_tab()
	{
		// Gestion du formulaire
		if (isset($_POST['ultimate_shanks_text_enhancer_submit'])) {
			check_admin_referer('ultimate_shanks_text_enhancer_action', 'ultimate_shanks_text_enhancer_nonce');

			self::save_settings();

			echo '<div class="notice notice-success is-dismissible"><p>Paramètres enregistrés avec succès.</p></div>';
		}

		// Récupérer les valeurs actuelles
		$enabled = get_option('ultimate_shanks_text_enhancer_enabled', '0');
		$mode = get_option('ultimate_shanks_text_enhancer_mode', 'standard');
		$min_length = get_option('ultimate_shanks_text_enhancer_min_length', '400');
		$sentences_per_p = get_option('ultimate_shanks_text_enhancer_sentences_per_p', '2');
		$ignore_links = get_option('ultimate_shanks_text_enhancer_ignore_links', '0');
		$ignore_shortcodes = get_option('ultimate_shanks_text_enhancer_ignore_shortcodes', '1');
		$ignore_classes = get_option('ultimate_shanks_text_enhancer_ignore_classes', '');
		$fix_em_dash = get_option('ultimate_shanks_text_enhancer_fix_em_dash', '1');
		$remove_hr = get_option('ultimate_shanks_text_enhancer_remove_hr', '0');
		$debug_mode = get_option('ultimate_shanks_text_enhancer_debug_mode', '0');
		$line_breaks = get_option('ultimate_shanks_text_enhancer_line_breaks', '0');
		$excluded_post_types = get_option('ultimate_shanks_text_enhancer_excluded_post_types', ['page', 'attachment']);
		$excluded_ids = get_option('ultimate_shanks_text_enhancer_excluded_ids', '');
		$excluded_slugs = get_option('ultimate_shanks_text_enhancer_excluded_slugs', '');
		$excluded_categories = get_option('ultimate_shanks_text_enhancer_excluded_categories', []);
		$excluded_keywords = get_option('ultimate_shanks_text_enhancer_excluded_keywords', '');
		?>

		<div class="ultimate-shanks-settings-box">
			<h2>Optimiseur de Paragraphes - Amélioration automatique de la lisibilité</h2>

			<form method="post" action="">
				<?php wp_nonce_field('ultimate_shanks_text_enhancer_action', 'ultimate_shanks_text_enhancer_nonce'); ?>

				<!-- Activation globale -->
				<div class="te-section">
					<h3>Activation</h3>
					<table class="form-table ultimate-shanks-form-table">
						<tbody>
							<tr>
								<th scope="row">
									<label for="text_enhancer_enabled">Activer l'optimisation</label>
								</th>
								<td>
									<label>
										<input
											type="checkbox"
											id="text_enhancer_enabled"
											name="text_enhancer_enabled"
											value="1"
											<?php checked($enabled, '1'); ?>
										>
										Activer l'optimiseur de paragraphes
									</label>
									<p class="description">
										Si activé, le traitement s'applique selon le mode choisi ci-dessous. Si désactivé, seuls les articles avec la metabox cochée seront traités.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="text_enhancer_mode">Mode de fonctionnement</label>
								</th>
								<td>
									<select id="text_enhancer_mode" name="text_enhancer_mode">
										<option value="standard" <?php selected($mode, 'standard'); ?>>Standard</option>
										<option value="conservative" <?php selected($mode, 'conservative'); ?>>Conservateur</option>
										<option value="manual" <?php selected($mode, 'manual'); ?>>Manuel</option>
									</select>
									<p class="description">
										<strong>Choisissez quand l'optimiseur doit traiter les articles :</strong><br>
										• <strong>Standard</strong> : Traite TOUS les paragraphes longs de tous les articles (recommandé pour la plupart des sites).<br>
										• <strong>Conservateur</strong> : Identique au mode Standard, mais avec des règles plus strictes (évite les contenus avec liens ou balises HTML complexes).<br>
										• <strong>Manuel</strong> : Traite UNIQUEMENT les articles où vous avez coché la metabox "Activer l'optimisation" dans l'éditeur d'article (contrôle total).
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Options de découpage -->
				<div class="te-section">
					<h3>Options de découpage</h3>
					<table class="form-table ultimate-shanks-form-table">
						<tbody>
							<tr>
								<th scope="row">
									<label for="line_breaks">Espacement entre paragraphes</label>
								</th>
								<td>
									<select id="line_breaks" name="line_breaks">
										<option value="0" <?php selected($line_breaks, '0'); ?>>Espacement standard (par défaut)</option>
										<option value="1" <?php selected($line_breaks, '1'); ?>>Espacement aéré (+1 ligne)</option>
										<option value="2" <?php selected($line_breaks, '2'); ?>>Espacement large (+2 lignes)</option>
										<option value="3" <?php selected($line_breaks, '3'); ?>>Espacement très large (+3 lignes)</option>
									</select>
									<p class="description">
										Choisissez l'espacement entre les paragraphes découpés. L'espacement standard utilise les marges naturelles des paragraphes.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="min_length">Longueur minimale d'un paragraphe</label>
								</th>
								<td>
									<input
										type="number"
										id="min_length"
										name="min_length"
										value="<?php echo esc_attr($min_length); ?>"
										min="100"
										max="2000"
										step="50"
										class="small-text"
									> caractères
									<p class="description">
										<strong>Un paragraphe doit contenir AU MOINS ce nombre de caractères pour être découpé.</strong><br>
										Exemple : Si vous mettez 300, seuls les paragraphes de 300 caractères ou plus seront divisés en plusieurs petits paragraphes.<br>
										Les paragraphes courts (moins de 300 caractères) ne seront pas touchés.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="sentences_per_p">Phrases par paragraphe</label>
								</th>
								<td>
									<input
										type="number"
										id="sentences_per_p"
										name="sentences_per_p"
										value="<?php echo esc_attr($sentences_per_p); ?>"
										min="1"
										max="10"
										class="small-text"
									> phrases
									<p class="description">
										<strong>Nombre de phrases à regrouper dans chaque nouveau paragraphe.</strong><br>
										Exemple : Si vous mettez 2, chaque nouveau paragraphe contiendra 2 phrases. Si vous mettez 4, chaque paragraphe contiendra 4 phrases.<br>
										Recommandation : 2-3 phrases pour une meilleure lisibilité.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">Options d'exclusion</th>
								<td>
									<fieldset>
										<label>
											<input type="checkbox" name="ignore_links" value="1" <?php checked($ignore_links, '1'); ?>>
											Ignorer les paragraphes contenant des liens
										</label><br>

										<label>
											<input type="checkbox" name="ignore_shortcodes" value="1" <?php checked($ignore_shortcodes, '1'); ?>>
											Ignorer les paragraphes contenant des shortcodes
										</label>
									</fieldset>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="ignore_classes">Classes CSS à ignorer</label>
								</th>
								<td>
									<input
										type="text"
										id="ignore_classes"
										name="ignore_classes"
										value="<?php echo esc_attr($ignore_classes); ?>"
										class="regular-text"
										placeholder="intro, citation, highlight"
									>
									<p class="description">
										<strong>Liste de classes CSS à exclure, séparées par des virgules.</strong><br>
										Les paragraphes contenant ces classes (dans le `&lt;p&gt;` ou dans des balises internes) ne seront pas traités.<br>
										Exemple : Si vous mettez "intro, citation", les paragraphes `&lt;p class="intro"&gt;` ou contenant `&lt;span class="citation"&gt;` seront ignorés.
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Options SEO -->
				<div class="te-section">
					<h3>Corrections SEO automatiques</h3>
					<table class="form-table ultimate-shanks-form-table">
						<tbody>
							<tr>
								<th scope="row">Corrections typographiques</th>
								<td>
									<fieldset>
										<label>
											<input type="checkbox" name="fix_em_dash" value="1" <?php checked($fix_em_dash, '1'); ?>>
											Remplacer les tirets cadratins (—) par des virgules (,)
										</label>
										<p class="description">
											Exemple : "quotidien — suivre" devient "quotidien, suivre"
										</p>
									</fieldset>
								</td>
							</tr>
							<tr>
								<th scope="row">Séparateurs horizontaux</th>
								<td>
									<fieldset>
										<label>
											<input type="checkbox" name="remove_hr" value="1" <?php checked($remove_hr, '1'); ?>>
											Supprimer tous les séparateurs horizontaux (HR)
										</label>
										<p class="description">
											Supprime toutes les balises &lt;hr&gt; du contenu (y compris les séparateurs Gutenberg).<br>
											<strong>Note :</strong> Vous pouvez conserver les séparateurs sur un article spécifique via la metabox dans l'éditeur d'article.
										</p>
									</fieldset>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Mode Debug -->
				<div class="te-section">
					<h3>Mode Debug</h3>
					<table class="form-table ultimate-shanks-form-table">
						<tbody>
							<tr>
								<th scope="row">
									<label for="debug_mode">Mode Debug</label>
								</th>
								<td>
									<label>
										<input type="checkbox" id="debug_mode" name="debug_mode" value="1" <?php checked($debug_mode, '1'); ?>>
										Entourer les paragraphes modifiés avec la classe <code>te-debug-highlight</code>
									</label>
									<p class="description">
										Utile pour visualiser les paragraphes qui ont été traités. Ajoutez du CSS personnalisé pour les mettre en évidence.
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Exclusions globales -->
				<div class="te-section">
					<h3>Exclusions globales</h3>
					<table class="form-table ultimate-shanks-form-table">
						<tbody>
							<tr>
								<th scope="row">
									<label for="excluded_post_types">Types de contenu exclus</label>
								</th>
								<td>
									<?php
									$post_types = get_post_types(['public' => true], 'objects');
									foreach ($post_types as $post_type) {
										$checked = in_array($post_type->name, (array) $excluded_post_types);
										?>
										<label>
											<input type="checkbox" name="excluded_post_types[]" value="<?php echo esc_attr($post_type->name); ?>" <?php checked($checked); ?>>
											<?php echo esc_html($post_type->label); ?>
										</label><br>
										<?php
									}
									?>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="excluded_ids">IDs exclus</label>
								</th>
								<td>
									<input
										type="text"
										id="excluded_ids"
										name="excluded_ids"
										value="<?php echo esc_attr($excluded_ids); ?>"
										class="regular-text"
										placeholder="12, 45, 789"
									>
									<p class="description">
										IDs d'articles séparés par des virgules.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="excluded_slugs">Slugs exclus</label>
								</th>
								<td>
									<input
										type="text"
										id="excluded_slugs"
										name="excluded_slugs"
										value="<?php echo esc_attr($excluded_slugs); ?>"
										class="regular-text"
										placeholder="about, contact"
									>
									<p class="description">
										Slugs d'articles séparés par des virgules.
									</p>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="excluded_categories">Catégories exclues</label>
								</th>
								<td>
									<?php
									$categories = get_categories(['hide_empty' => false]);
									foreach ($categories as $category) {
										$checked = in_array($category->term_id, (array) $excluded_categories);
										?>
										<label>
											<input type="checkbox" name="excluded_categories[]" value="<?php echo esc_attr($category->term_id); ?>" <?php checked($checked); ?>>
											<?php echo esc_html($category->name); ?>
										</label><br>
										<?php
									}
									?>
								</td>
							</tr>

							<tr>
								<th scope="row">
									<label for="excluded_keywords">Mots-clés d'exclusion</label>
								</th>
								<td>
									<input
										type="text"
										id="excluded_keywords"
										name="excluded_keywords"
										value="<?php echo esc_attr($excluded_keywords); ?>"
										class="regular-text"
										placeholder="citation, code, technique"
									>
									<p class="description">
										Si un de ces mots est présent dans le contenu, l'article ne sera pas traité. Séparés par des virgules.
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<?php submit_button('Enregistrer les paramètres', 'primary', 'ultimate_shanks_text_enhancer_submit'); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Sauvegarde les paramètres
	 */
	private static function save_settings()
	{
		// Les types de contenu sont des slugs, les catégories des term_id (voir les checkboxes du formulaire)
		$excluded_post_types = isset($_POST['excluded_post_types']) && is_array($_POST['excluded_post_types'])
			? array_map('sanitize_key', $_POST['excluded_post_types'])
			: [];
		$excluded_categories = isset($_POST['excluded_categories']) && is_array($_POST['excluded_categories'])
			? array_map('intval', $_POST['excluded_categories'])
			: [];

		update_option('ultimate_shanks_text_enhancer_enabled', isset($_POST['text_enhancer_enabled']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_mode', sanitize_text_field($_POST['text_enhancer_mode'] ?? 'standard'));
		update_option('ultimate_shanks_text_enhancer_min_length', intval($_POST['min_length'] ?? 400));
		update_option('ultimate_shanks_text_enhancer_sentences_per_p', intval($_POST['sentences_per_p'] ?? 2));
		update_option('ultimate_shanks_text_enhancer_line_breaks', intval($_POST['line_breaks'] ?? 0));
		update_option('ultimate_shanks_text_enhancer_ignore_links', isset($_POST['ignore_links']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_ignore_shortcodes', isset($_POST['ignore_shortcodes']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_ignore_classes', sanitize_text_field($_POST['ignore_classes'] ?? ''));
		update_option('ultimate_shanks_text_enhancer_fix_em_dash', isset($_POST['fix_em_dash']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_remove_hr', isset($_POST['remove_hr']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_debug_mode', isset($_POST['debug_mode']) ? '1' : '0');
		update_option('ultimate_shanks_text_enhancer_excluded_post_types', $excluded_post_types);
		update_option('ultimate_shanks_text_enhancer_excluded_ids', sanitize_text_field($_POST['excluded_ids'] ?? ''));
		update_option('ultimate_shanks_text_enhancer_excluded_slugs', sanitize_text_field($_POST['excluded_slugs'] ?? ''));
		update_option('ultimate_shanks_text_enhancer_excluded_categories', $excluded_categories);
		update_option('ultimate_shanks_text_enhancer_excluded_keywords', sanitize_text_field($_POST['excluded_keywords'] ?? ''));
	}
}
