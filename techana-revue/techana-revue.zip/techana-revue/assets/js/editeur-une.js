/**
 * Panneau « TechAna » de l'éditeur d'article : case « Afficher à la une »
 * (méta _techana_une), les cinq points « En bref » (méta _techana_en_bref),
 * l'encart épinglé sur cet article (métas _techana_encart_epingle*) et la
 * variante sponsorisée (métas _techana_sponsorise et _techana_annonceur_*).
 *
 * La liste des encarts publiés arrive par window.techanaRevueEncarts, posée
 * avant ce script par inc/metas.php.
 *
 * Sans build, comme editeur-blocs.js — wp.element en direct, pas de JSX.
 */
( function ( plugins, editor, editPost, components, data, element ) {
    'use strict';

    var el = element.createElement;
    var POINTS_EN_BREF = 5;
    var ENCARTS = Array.isArray( window.techanaRevueEncarts ) ? window.techanaRevueEncarts : [];
    // PluginDocumentSettingPanel a migré de wp-edit-post vers wp-editor (WP 6.6+).
    var Panneau = ( editor && editor.PluginDocumentSettingPanel )
        || ( editPost && editPost.PluginDocumentSettingPanel );

    if ( ! Panneau || ! plugins ) {
        return;
    }

    /** Les cinq champs « En bref », vides compris pour que les rangs ne glissent pas. */
    function champsEnBref( enBref, changerPoint ) {
        var champs = [];
        for ( var i = 0; i < POINTS_EN_BREF; i++ ) {
            champs.push( el( components.TextControl, {
                key: 'en-bref-' + i,
                'aria-label': 'Point ' + ( i + 1 ),
                placeholder: 'Point ' + ( i + 1 ),
                value: enBref[ i ] || '',
                __next40pxDefaultSize: true,
                onChange: ( function ( index ) {
                    return function ( valeur ) {
                        changerPoint( index, valeur );
                    };
                }( i ) )
            } ) );
        }
        return champs;
    }

    /** Choix de l'encart épinglé, puis de son emplacement s'il y en a un. */
    function champsEncart( metas, editerArticle ) {
        var choisi = parseInt( metas._techana_encart_epingle, 10 ) || 0;
        var position = metas._techana_encart_epingle_position || 'corps';

        if ( ! ENCARTS.length ) {
            return [ el( components.BaseControl, {
                key: 'encart-vide',
                __nextHasNoMarginBottom: true,
                label: 'Encart de cet article',
                help: 'Aucun encart publié pour l’instant — ils se créent dans le menu « Encarts ».',
                children: []
            } ) ];
        }

        var options = [ { label: '— aucun (suivre la rubrique)', value: 0 } ];
        ENCARTS.forEach( function ( encart ) {
            options.push( { label: encart.titre, value: encart.id } );
        } );

        var champs = [ el( components.SelectControl, {
            key: 'encart-choix',
            label: 'Encart de cet article',
            help: choisi
                ? 'Cet encart passe avant le ciblage par rubrique, à l’emplacement choisi.'
                : 'Sans choix, l’article reçoit les encarts de sa rubrique.',
            value: choisi,
            options: options,
            __next40pxDefaultSize: true,
            __nextHasNoMarginBottom: true,
            onChange: function ( valeur ) {
                editerArticle( { meta: { _techana_encart_epingle: parseInt( valeur, 10 ) || 0 } } );
            }
        } ) ];

        if ( choisi ) {
            champs.push( el( components.SelectControl, {
                key: 'encart-position',
                label: 'Emplacement',
                value: position,
                options: [
                    { label: 'Dans le corps de l’article', value: 'corps' },
                    { label: 'En pied d’article', value: 'pied' }
                ],
                __next40pxDefaultSize: true,
                __nextHasNoMarginBottom: true,
                onChange: function ( valeur ) {
                    editerArticle( { meta: { _techana_encart_epingle_position: valeur } } );
                }
            } ) );
        }
        return champs;
    }

    /** Variante sponsorisée : la case, puis l'annonceur quand elle est cochée. */
    function champsSponsorise( metas, editerArticle ) {
        var sponsorise = !! metas._techana_sponsorise;
        var champs = [ el( components.CheckboxControl, {
            key: 'sponsorise',
            label: 'Article sponsorisé',
            help: sponsorise
                ? 'Bandeau « Contenu sponsorisé », pavé annonceur, et rel="sponsored" sur tous les liens du corps.'
                : 'À cocher pour un contenu financé par un annonceur (publireportage).',
            checked: sponsorise,
            __nextHasNoMarginBottom: true,
            onChange: function ( coche ) {
                editerArticle( { meta: { _techana_sponsorise: !! coche } } );
            }
        } ) ];

        if ( ! sponsorise ) {
            return champs;
        }

        var annonceur = [
            { cle: '_techana_annonceur_nom', label: 'Nom de l’annonceur' },
            { cle: '_techana_annonceur_texte', label: 'Texte de présentation' },
            { cle: '_techana_annonceur_url', label: 'Lien de l’annonceur' }
        ];
        annonceur.forEach( function ( champ ) {
            champs.push( el( components.TextControl, {
                key: champ.cle,
                label: champ.label,
                value: metas[ champ.cle ] || '',
                __next40pxDefaultSize: true,
                __nextHasNoMarginBottom: true,
                onChange: ( function ( cle ) {
                    return function ( valeur ) {
                        var maj = {};
                        maj[ cle ] = valeur;
                        editerArticle( { meta: maj } );
                    };
                }( champ.cle ) )
            } ) );
        } );
        champs.push( el( components.BaseControl, {
            key: 'annonceur-aide',
            __nextHasNoMarginBottom: true,
            help: 'Sans nom d’annonceur, le pavé « À propos de l’annonceur » n’est pas affiché.',
            children: []
        } ) );
        return champs;
    }

    function PanneauTechana() {
        var typeArticle = data.useSelect( function ( select ) {
            return select( 'core/editor' ).getCurrentPostType();
        }, [] );
        var metas = data.useSelect( function ( select ) {
            return select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {};
        }, [] );
        var editerArticle = data.useDispatch( 'core/editor' ).editPost;

        if ( 'post' !== typeArticle ) {
            return null;
        }

        var estALaUne = !! metas._techana_une;
        var enBref = Array.isArray( metas._techana_en_bref ) ? metas._techana_en_bref : [];

        function changerPoint( index, valeur ) {
            var points = [];
            for ( var i = 0; i < POINTS_EN_BREF; i++ ) {
                points[ i ] = i === index ? valeur : ( enBref[ i ] || '' );
            }
            // Les vides de fin ne sont pas stockés ; ceux du milieu gardent leur
            // rang pour que les champs ne glissent pas pendant la saisie.
            while ( points.length && '' === points[ points.length - 1 ].trim() ) {
                points.pop();
            }
            editerArticle( { meta: { _techana_en_bref: points } } );
        }

        return el(
            Panneau,
            { name: 'techana-une', title: 'TechAna' },
            el( components.CheckboxControl, {
                label: 'Afficher à la une',
                help: estALaUne
                    ? 'Cet article occupe une place en page d’accueil, avant les articles récents.'
                    : 'Réservé aux articles à mettre en avant sur la page d’accueil.',
                checked: estALaUne,
                __nextHasNoMarginBottom: true,
                onChange: function ( coche ) {
                    editerArticle( { meta: { _techana_une: !! coche } } );
                }
            } ),
            el( components.BaseControl, {
                __nextHasNoMarginBottom: true,
                label: 'En bref',
                help: 'Jusqu’à cinq points affichés en tête d’article. Quand ils sont '
                    + 'remplis, la section « à retenir » du corps n’est plus transformée.',
                children: champsEnBref( enBref, changerPoint )
            } ),
            el( 'hr', { style: { margin: '16px 0' } } ),
            champsEncart( metas, editerArticle ),
            el( 'hr', { style: { margin: '16px 0' } } ),
            champsSponsorise( metas, editerArticle )
        );
    }

    plugins.registerPlugin( 'techana-une', {
        render: PanneauTechana,
        icon: 'star-filled'
    } );
}(
    window.wp.plugins,
    window.wp.editor,
    window.wp.editPost,
    window.wp.components,
    window.wp.data,
    window.wp.element
) );
