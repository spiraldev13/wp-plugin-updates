/**
 * Configurateur tarifs Evolution'R — logique métier pure (prix, paliers, promotions).
 *
 * Couche GELÉE : déplacée verbatim depuis configurateur.js (refonte rendu/animation).
 * Zéro DOM ici — uniquement du calcul à partir de `state` et du modèle back-office
 * (window.evolutionrPricing, cf. inc/pricing.php). Si une valeur produite ici change,
 * c'est une régression tarifaire : ce module ne doit PAS évoluer dans la refonte
 * d'animation (seul le rendu et les transitions changent).
 */

export const pricingData = window.evolutionrPricing || { services: {}, options: {}, rates: {}, groups: {}, promotions: [] };

export const ADDON_GROUPS = ['maintenance_hebergee', 'seo'];
export const GROUP_LABELS = { maintenance_hebergee: 'Maintenance + Hébergement', seo: 'Référencement SEO' };

/* ────────────────────────────────────────────────────────────────────
 *  STATE & HELPERS
 * ──────────────────────────────────────────────────────────────────── */

export function createState() {
    return {
        service: 'creation',
        mode: 'one_shot',
        offerIndex: 0,
        tiers: {},            // paliers récurrents choisis (1 par groupe) : { maintenance_hebergee, seo }
        extras: new Set(),    // add-ons ponctuels cumulables (ex. Audit SEO) — noms de paliers
        ponctuelles: new Set(),
        regieQty: 1,
        ttc: false,           // affichage HT (false) ou TTC (true)
    };
}

export function serviceModes(id) {
    return Object.keys(pricingData.services[id]?.modes ?? {});
}
export function currentOffers(state) {
    const svc = pricingData.services[state.service];
    if (!svc) return [];
    // Régie : pas de toggle de mode → on aplatit toutes les offres (heure + jour).
    if (state.service === 'regie') {
        return Object.values(svc.modes).flat();
    }
    return svc.modes[state.mode] ?? [];
}
export function currentOffer(state) {
    const offers = currentOffers(state);
    return offers[state.offerIndex] ?? offers[0] ?? null;
}
export function groupTiers(group) {
    return pricingData.groups[group]?.tiers ?? [];
}
export function tierByName(group, name) {
    return groupTiers(group).find((t) => t.name === name) ?? null;
}
/** Retrouve un palier ponctuel (non récurrent, ex. audit) par son nom. */
export function ponctualTierByName(name) {
    for (const g of ADDON_GROUPS) {
        const t = tierByName(g, name);
        if (t && !t.recurring) return { group: g, tier: t };
    }
    return null;
}
export function isSite(state) {
    return state.service === 'creation';
}
export function isRegie(state) {
    return state.service === 'regie';
}
/**
 * Contexte « Pack Maintenance + Hébergement » : le site est hébergé chez nous —
 * soit le service est directement le Pack M+H, soit c'est un site neuf (création)
 * dont le palier maintenance hébergée est actif. Conditionne la visibilité des
 * options serveur et de la migration entrante (R3).
 */
export function isPackMH(state) {
    return state.service === 'maintenance_hebergee'
        || (isSite(state) && !!state.tiers.maintenance_hebergee);
}
/**
 * Le contexte propose-t-il des add-ons (options/paliers) ? Site neuf OU Pack M+H direct.
 * SOURCE UNIQUE pour l'affichage (renderAddons), le calcul (compute) et les promos
 * (presentFamilies) — sinon une option visible peut ne pas être facturée/comptée.
 */
export function hasAddons(state) {
    return isSite(state) || isPackMH(state);
}
/** Une option est-elle proposable dans le contexte courant ? (R3) */
export function optionAllowed(state, opt) {
    const family = (opt && opt.family) || 'service';
    if (family === 'service') return true; // service : partout
    return isPackMH(state);                 // serveur & migration : Pack M+H uniquement
}
export function fmtEur(value) {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(value);
}

// Bascule HT / TTC : les prix sont stockés HT ; en TTC on applique la TVA à l'affichage.
export const TVA = Number(pricingData.rates && pricingData.rates.tva) || 20;
let displayTtc = false;
/** Bascule l'affichage HT/TTC (lue par money()). Appelée par la couche de rendu. */
export function setDisplayTtc(value) { displayTtc = !!value; }
export function money(value) {
    return fmtEur(displayTtc ? value * (1 + TVA / 100) : value);
}

/** Palier inclus de base pour un groupe (abonnement uniquement). */
export function baselineTier(state, group) {
    if (state.mode !== 'abonnement') return null;
    const offer = currentOffer(state);
    return offer?.baseline?.[group] || null;
}

/** Réinitialise les paliers sélectionnés selon l'offre/mode courants. */
export function resetTiers(state) {
    state.tiers = {};
    if (!isSite(state) || state.mode !== 'abonnement') return;
    // Les groupes incluables démarrent sur leur palier inclus (plancher).
    ['maintenance_hebergee'].forEach((g) => {
        const base = baselineTier(state, g);
        if (base) state.tiers[g] = base;
    });
}

/**
 * Changement d'offre (même service/mode) : on GARDE les add-ons choisis et on
 * recale seulement les planchers inclus de la nouvelle offre — pour ne pas
 * effacer les avantages déjà débloqués quand l'utilisateur compare des offres.
 */
export function rebaseTiers(state) {
    if (!isSite(state) || state.mode !== 'abonnement') return;
    ['maintenance_hebergee'].forEach((g) => {
        const base = baselineTier(state, g);
        if (!base) return;
        const tiers = groupTiers(g);
        const baseIdx = tiers.findIndex((t) => t.name === base);
        const selIdx = state.tiers[g] ? tiers.findIndex((t) => t.name === state.tiers[g]) : -1;
        // Rien de choisi ou sous le nouveau plancher → caler sur le plancher.
        if (selIdx < baseIdx) state.tiers[g] = base;
    });
}

/* ────────────────────────────────────────────────────────────────────
 *  CALCUL
 * ──────────────────────────────────────────────────────────────────── */

/**
 * Ensemble des « dimensions » présentes dans la config (pour matcher les promos).
 * Une dimension = clé stable d'un élément ajoutable :
 *   · catégorie de service        → le slug (`creation`…`regie`)
 *   · option (serveur/migration/ponctuelle) → `opt:<clé>`
 *   · add-on cumulable d'un groupe (ex. Audit SEO) → `add:<nom>`
 * Comptage UNIFORME : toute option sélectionnée pèse pour elle-même, jamais pour le
 * service de son groupe (D1 : un Audit SEO ≠ le service « Référencement SEO »).
 */
export function presentFamilies(state) {
    const dims = new Set([state.service]);
    if (hasAddons(state)) {
        ADDON_GROUPS.forEach((g) => {
            const sel = state.tiers[g];
            if (!sel) return;
            // L'inclus de base ne déclenche jamais une promo (D14) :
            // seul un palier RÉCURRENT réel (optionnel, upgrade, SEO) rend la catégorie présente.
            const base = baselineTier(state, g);
            if (g === 'seo' || !base || sel !== base) dims.add(g);
        });
        // Add-ons cumulables (ex. Audit SEO) → leur PROPRE dimension (D1), pas leur groupe.
        state.extras.forEach((name) => dims.add(`add:${name}`));
        // Options ponctuelles / serveur / migration → une dimension par option (D2).
        state.ponctuelles.forEach((key) => {
            const opt = pricingData.options[key];
            if (opt && optionAllowed(state, opt)) dims.add(`opt:${key}`);
        });
    }
    return dims;
}

/** Libellé lisible d'une dimension de promo (catégorie, option ou add-on cumulable). */
export function dimensionLabel(dim) {
    if (dim.startsWith('opt:')) return pricingData.options[dim.slice(4)]?.label || dim.slice(4);
    if (dim.startsWith('add:')) return dim.slice(4); // nom du palier ponctuel
    return GROUP_LABELS[dim] || pricingData.services[dim]?.label || dim;
}

/** Comment rendre une dimension « présente » (upsell « Ajouter X »), ou null si non ajoutable. */
export function dimensionAddTarget(state, dim) {
    if (!isSite(state)) return null;
    if (dim.startsWith('opt:')) {
        const key = dim.slice(4);
        const opt = pricingData.options[key];
        return (opt && optionAllowed(state, opt)) ? { kind: 'option', key } : null;
    }
    if (dim.startsWith('add:')) {
        const name = dim.slice(4);
        return ponctualTierByName(name) ? { kind: 'extra', name } : null;
    }
    return ADDON_GROUPS.includes(dim) ? familyAddTarget(state, dim) : null;
}

export function bestPromo(families, oneShot, monthly) {
    let best = null;
    let bestReduction = 0;
    (pricingData.promotions || []).forEach((p) => {
        if (!(p.requires || []).every((f) => families.has(f))) return;
        let reduction = 0;
        if (p.target === 'one_shot' || p.target === 'les_deux') reduction += (oneShot * p.pct) / 100;
        if (p.target === 'mensuel' || p.target === 'les_deux') reduction += (monthly * p.pct) / 100;
        if (reduction > bestReduction) {
            bestReduction = reduction;
            best = p;
        }
    });
    return best;
}

/**
 * Cible d'ajout pour rendre une famille « présente » (déclenche les promos).
 * @returns { kind:'tier', group, name } | { kind:'extra', name } | null si impossible.
 */
export function familyAddTarget(state, family) {
    const recurring = groupTiers(family).filter((t) => t.recurring);
    const ponctual = groupTiers(family).filter((t) => !t.recurring);
    const first = (arr, kind) => (arr.length ? (kind === 'tier' ? { kind, group: family, name: arr[0].name } : { kind, name: arr[0].name }) : null);

    if (family === 'seo') {
        return first(recurring, 'tier') || first(ponctual, 'extra');
    }
    // maintenance hébergée (Pack M+H)
    const base = baselineTier(state, family);
    if (base) {
        // Abonnement avec plancher inclus : il faut un palier AU-DESSUS pour compter (D14).
        const baseIdx = recurring.findIndex((t) => t.name === base);
        const upgrade = recurring[baseIdx + 1];
        if (upgrade) return { kind: 'tier', group: family, name: upgrade.name };
        return first(ponctual, 'extra');
    }
    return first(recurring, 'tier') || first(ponctual, 'extra');
}

/**
 * Échelle « Vos avantages » construite depuis `pricingData.promotions` (aucune
 * valeur en dur). Pour chaque promo : familles manquantes + faisabilité de l'ajout.
 * @returns [{ label, pct, acquired, applied, missing:[{family,label,target}] }]
 */
export function buildAvantages(state, appliedPromo) {
    const families = presentFamilies(state);
    return (pricingData.promotions || [])
        .slice()
        .sort((a, b) => (a.pct || 0) - (b.pct || 0))
        .map((p) => {
            const missing = (p.requires || [])
                .filter((f) => !families.has(f))
                .map((f) => ({
                    family: f,
                    label: dimensionLabel(f),
                    target: dimensionAddTarget(state, f),
                }));
            return {
                label: p.label,
                pct: p.pct,
                acquired: missing.length === 0,
                applied: !!appliedPromo && p === appliedPromo,
                actionable: missing.some((m) => m.target),
                missing,
            };
        });
}

export function compute(state) {
    const offer = currentOffer(state);
    const lines = [];
    let oneShot = 0;
    let monthly = 0;

    if (!offer) {
        return { oneShot, monthly, lines, promo: null, payOneShot: 0, payMonthly: 0 };
    }

    // ─── Service principal
    if (isRegie(state)) {
        const sub = (offer.price || 0) * state.regieQty;
        oneShot += sub;
        const unit = offer.unit === 'journalier' ? 'jour' : 'h';
        lines.push({ label: `${offer.name} × ${state.regieQty} ${unit}`, value: money(sub) });
    } else if (state.mode === 'abonnement') {
        // Le nom de l'offre (ex. « Site one page ») toujours en PREMIER ; la mise en
        // service vient APRÈS — sinon elle « passe devant » au changement de mode (gênant).
        monthly += offer.monthlyPrice || 0;
        lines.push({ label: offer.name, value: `${money(offer.monthlyPrice || 0)}/mois` });
        if (offer.setupFee) {
            oneShot += offer.setupFee;
            lines.push({ label: 'Mise en service', value: money(offer.setupFee) });
        }
    } else {
        oneShot += offer.price || 0;
        lines.push({ label: offer.name, value: money(offer.price || 0) });
    }

    // ─── Add-ons (sites neufs + Pack M+H direct)
    if (hasAddons(state)) {
        ADDON_GROUPS.forEach((g) => {
            const sel = state.tiers[g];
            if (!sel) return;
            const tier = tierByName(g, sel);
            if (!tier) return;

            const base = baselineTier(state, g);
            if (state.mode === 'abonnement' && g !== 'seo' && base) {
                if (sel === base) {
                    lines.push({ label: tier.name, value: 'inclus', muted: true });
                    return;
                }
                const baseTier = tierByName(g, base);
                const delta = tier.price - (baseTier?.price || 0);
                monthly += delta;
                lines.push({ label: tier.name, value: `+ ${money(delta)}/mois` });
            } else if (tier.recurring) {
                monthly += tier.price;
                lines.push({ label: tier.name, value: `+ ${money(tier.price)}/mois` });
            } else {
                oneShot += tier.price;
                lines.push({ label: tier.name, value: `+ ${money(tier.price)}` });
            }
        });

        // Add-ons ponctuels cumulables (ex. Audit SEO) — paiement unique.
        state.extras.forEach((name) => {
            const found = ponctualTierByName(name);
            if (!found) return;
            oneShot += found.tier.price;
            lines.push({ label: found.tier.name, value: `+ ${money(found.tier.price)}` });
        });

        state.ponctuelles.forEach((key) => {
            const opt = pricingData.options[key];
            if (!opt || !optionAllowed(state, opt)) return; // option hors contexte → non comptée
            if (opt.type === 'monthly') {
                monthly += opt.price;
                lines.push({ label: opt.label, value: `+ ${money(opt.price)}/mois` });
            } else {
                oneShot += opt.price;
                lines.push({ label: opt.label, value: `+ ${money(opt.price)}` });
            }
        });
    }

    // ─── Promotion (best-match, sans cumul)
    const promo = bestPromo(presentFamilies(state), oneShot, monthly);
    let payOneShot = oneShot;
    let payMonthly = monthly;
    if (promo) {
        if (promo.target === 'one_shot' || promo.target === 'les_deux') payOneShot = oneShot * (1 - promo.pct / 100);
        if (promo.target === 'mensuel' || promo.target === 'les_deux') payMonthly = monthly * (1 - promo.pct / 100);
    }

    return { oneShot, monthly, lines, promo, payOneShot, payMonthly };
}

/** Récapitulatif texte de la configuration, injecté dans le formulaire CF7. */
export function buildConfigText(state) {
    const offer = currentOffer(state);
    if (!offer) return '';
    setDisplayTtc(state.ttc);
    const { lines, promo, oneShot, monthly, payOneShot, payMonthly } = compute(state);
    const out = [];
    out.push(`Service : ${pricingData.services[state.service]?.label || state.service}`);
    out.push(`Prix affichés : ${state.ttc ? `TTC (TVA ${TVA} %)` : 'HT'}`);
    lines.forEach((l) => out.push(`- ${l.label} : ${l.value}`));
    if (oneShot > 0) out.push(`Total paiement unique : ${money(promo ? payOneShot : oneShot)}${promo ? ` (au lieu de ${money(oneShot)})` : ''}`);
    if (monthly > 0) out.push(`Total mensuel : ${money(promo ? payMonthly : monthly)}/mois${promo ? ` (au lieu de ${money(monthly)}/mois)` : ''}`);
    if (promo) out.push(`Remise appliquée : ${promo.label} (−${promo.pct} %)`);
    return out.join('\n');
}
