<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Matrice d'activation/exclusions de contenu — consolidée depuis le Text
 * Enhancer d'ultimate-shanks (mêmes critères, même normalisation amont des
 * listes). C'est elle qui décide où le walker agit (AD-10) ; les réglages
 * par article (metas activer/désactiver) restent l'affaire des modules.
 * Exclusion-only par conception : l'activation par type de contenu est un
 * réglage de chaque module (2.6+), pas de la matrice.
 */
final class ContentRules
{
    /** Option canonique des règles — lue ici, écrite par le tableau de bord (6.4). */
    public const OPTION = 'spiralbase_content_rules';

    /** @var \Closure(int): array|null */
    private readonly ?\Closure $categoriesProvider;

    /**
     * @param array{post_types?: mixed, ids?: mixed, slugs?: mixed, categories?: mixed, mots_cles?: mixed} $regles
     * @param callable|null $categoriesProvider injectable (testabilité) — reçoit l'ID du post, rend ses IDs de catégories
     */
    public function __construct(
        private readonly array $regles = [],
        ?callable $categoriesProvider = null,
    ) {
        $this->categoriesProvider = $categoriesProvider === null ? null : $categoriesProvider(...);
    }

    /** Le walker doit-il agir sur ce contenu ? false = exclu par la matrice. */
    public function appliesTo(object $post): bool
    {
        if (in_array((string) ($post->post_type ?? ''), $this->chaines('post_types'), true)) {
            return false;
        }

        if (in_array((int) ($post->ID ?? 0), $this->entiers('ids'), true)) {
            return false;
        }

        if (in_array((string) ($post->post_name ?? ''), $this->chaines('slugs'), true)) {
            return false;
        }

        $categories = $this->entiers('categories');

        if ($categories !== [] && $this->categoriesProvider !== null) {
            $duPost = array_map('intval', array_filter(($this->categoriesProvider)((int) ($post->ID ?? 0)), 'is_scalar'));

            if (array_intersect($duPost, $categories) !== []) {
                return false;
            }
        }

        $contenu = (string) ($post->post_content ?? '');

        foreach ($this->chaines('mots_cles') as $motCle) {
            if (stripos($contenu, $motCle) !== false) {
                return false;
            }
        }

        return true;
    }

    /**
     * Normalisation amont (comme la source) : scalaire isolé accepté comme
     * liste d'un élément, non-scalaires écartés, vides éliminés.
     *
     * @return list<string>
     */
    private function chaines(string $cle): array
    {
        $valeurs = array_map(
            static fn (mixed $v): string => trim((string) $v),
            array_filter($this->liste($cle), 'is_scalar')
        );

        return array_values(array_filter($valeurs, static fn (string $v): bool => $v !== ''));
    }

    /** @return list<int> */
    private function entiers(string $cle): array
    {
        $valeurs = array_map('intval', array_filter($this->liste($cle), 'is_scalar'));

        return array_values(array_filter($valeurs, static fn (int $v): bool => $v > 0));
    }

    /** @return list<mixed> */
    private function liste(string $cle): array
    {
        $valeur = $this->regles[$cle] ?? [];

        if (is_array($valeur)) {
            return array_values($valeur);
        }

        /* Règle scalaire isolée : la traiter comme une liste d'un élément
           plutôt que de la vider en silence (fail-open indétectable). */
        return is_scalar($valeur) ? [$valeur] : [];
    }
}
