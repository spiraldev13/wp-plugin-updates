<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Lecture défensive des attributs d'un bloc dynamique (revue 3.1).
 *
 * Fait LU dans le cœur : `WP_Block_Type::prepare_attributes_for_render()`
 * (`wp-includes/class-wp-block-type.php:497-533`) **valide sans convertir** —
 * `rest_validate_value_from_schema('false', ['type' => 'boolean'])` accepte,
 * et l'attribut reste la CHAÎNE `"false"`. Prouvé au rendu : un bloc dont
 * les trois attributs valaient `"false"` affichait ses trois sections.
 *
 * L'éditeur écrit bien des booléens ; un commentaire de bloc rédigé à la
 * main (pattern livré, contenu importé, filtre `render_block_data` d'un
 * tiers) n'en offre aucune garantie. Une seule règle pour tout le parent,
 * plutôt que deux politiques opposées d'un module à l'autre.
 */
final class AttributsBloc
{
    /**
     * @param array<string, mixed> $attributs
     * @param bool                 $defaut valeur retenue si l'attribut est absent ou inintelligible
     */
    public static function booleen(array $attributs, string $nom, bool $defaut): bool
    {
        if (!array_key_exists($nom, $attributs)) {
            return $defaut;
        }

        $valeur = $attributs[$nom];

        if (is_bool($valeur)) {
            return $valeur;
        }

        /* '1'/'true'/'on'/'yes' et leurs contraires sont reconnus ; tout le
           reste (tableau, objet, chaîne quelconque) retombe sur le défaut
           déclaré plutôt que sur un cast PHP silencieux. */
        $interprete = filter_var($valeur, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

        return $interprete ?? $defaut;
    }
}
