<?php
/**
 * Sources de block bindings + injections de rendu.
 *
 * Les gabarits restent du markup de blocs pur ; ces sources fournissent les
 * valeurs que les blocs core ne savent pas produire (temps de lecture, date de
 * mise à jour conditionnelle, compteurs), et le filtre k-auto porte la couleur
 * de rubrique sans qu'aucune valeur ne soit codée dans les templates.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'techanaRevueRegisterBindings' );
add_filter( 'render_block', 'techanaRevueKClassFilter', 10, 3 );
add_filter( 'render_block_core/post-featured-image', 'techanaRevuePhImgFallback', 10, 3 );
add_action( 'template_redirect', 'techanaRevueCompterVue' );

/**
 * Réserve .ph-img du design : une carte sans image à la une affiche le cadre
 * surface au bon rapport d'aspect au lieu de casser la grille.
 */
function techanaRevuePhImgFallback( string $content, array $block, WP_Block $instance ): string {
    $classes = $block['attrs']['className'] ?? '';
    if ( '' !== trim( $content ) || ! str_contains( $classes, 'ph-auto' ) ) {
        return $content;
    }
    $carre = str_contains( $classes, 'square' ) ? ' square' : '';
    return '<span class="ph-img' . $carre . '"></span>';
}

function techanaRevueRegisterBindings() {
    register_block_bindings_source( 'techana/lecture', array(
        'label'              => 'Temps de lecture',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingLecture',
    ) );
    register_block_bindings_source( 'techana/mots', array(
        'label'              => 'Nombre de mots',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingMots',
    ) );
    register_block_bindings_source( 'techana/maj', array(
        'label'              => 'Mise à jour (si différente)',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingMaj',
    ) );
    register_block_bindings_source( 'techana/compteur-rubrique', array(
        'label'              => 'Compteur d\'articles de la rubrique',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingCompteur',
    ) );
    register_block_bindings_source( 'techana/date-jour', array(
        'label'              => 'Date du jour',
        'get_value_callback' => 'techanaRevueBindingDateJour',
    ) );
    register_block_bindings_source( 'techana/compte-une', array(
        'label'              => 'Compte des articles de la une',
        'get_value_callback' => 'techanaRevueBindingCompteUne',
    ) );
    register_block_bindings_source( 'techana/meta-carte', array(
        'label'              => 'Signature de carte (date · auteur)',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingMetaCarte',
    ) );
    register_block_bindings_source( 'techana/meta-grande', array(
        'label'              => 'Signature complète (publié · mis à jour · auteur)',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingMetaGrande',
    ) );
    register_block_bindings_source( 'techana/meta-hub', array(
        'label'              => 'Signature de hub (dates · auteur · lecture)',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingMetaHub',
    ) );
    register_block_bindings_source( 'techana/rubrique-nom', array(
        'label'              => 'Nom de la rubrique requêtée',
        'get_value_callback' => 'techanaRevueBindingRubriqueNom',
    ) );
    register_block_bindings_source( 'techana/chapo', array(
        'label'              => 'Chapô (extrait de l\'article)',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingChapo',
    ) );
    register_block_bindings_source( 'techana/nom-rubrique-article', array(
        'label'              => 'Rubrique principale de l\'article',
        'uses_context'       => array( 'postId' ),
        'get_value_callback' => 'techanaRevueBindingNomRubriqueArticle',
    ) );
}

/**
 * Chapô : l'extrait de l'article, sans lien « lire la suite ».
 */
function techanaRevueBindingChapo( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    return $postId ? techanaRevueResume( (int) $postId ) : '';
}

/**
 * Nom de la rubrique principale de l'article courant (pavé de l'en-tête).
 */
function techanaRevueBindingNomRubriqueArticle( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    $cats = get_the_category( $postId );
    return $cats ? $cats[0]->name : '';
}

/**
 * « Publié le X · mis à jour le Y · Auteur · N min de lecture » — unité hub.
 */
function techanaRevueBindingMetaHub( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    $sortie = techanaRevueBindingMetaGrande( $args, $block );
    return $sortie . ' · ' . techanaRevueTempsLecture( $postId ) . ' min de lecture';
}

/**
 * Nom du terme requêté (hub) ou de l'auteur requêté (page auteur).
 */
function techanaRevueBindingRubriqueNom(): string {
    $objet = get_queried_object();
    if ( $objet instanceof WP_Term ) {
        return $objet->name;
    }
    if ( $objet instanceof WP_User ) {
        return $objet->display_name;
    }
    return '';
}

/**
 * « 26 juil. 2026 · Marc Delaunay » — signature des unités liste et moyenne.
 */
function techanaRevueBindingMetaCarte( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    $auteur = get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $postId ) );
    return get_the_date( 'j M Y', $postId ) . ' · ' . $auteur;
}

/**
 * « Publié le 27 juil. · mis à jour le 29 juil. · Marc Delaunay » — unité grande.
 * La mention de mise à jour ne sort que si le jour diffère de la publication.
 */
function techanaRevueBindingMetaGrande( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    $sortie = 'Publié le ' . get_the_date( 'j M', $postId );
    if ( get_the_date( 'Y-m-d', $postId ) !== get_the_modified_date( 'Y-m-d', $postId ) ) {
        $sortie .= ' · mis à jour le ' . get_the_modified_date( 'j M', $postId );
    }
    $auteur = get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $postId ) );
    return $sortie . ' · ' . $auteur;
}

/**
 * « Mercredi 29 juillet 2026 » — la barre supérieure du design.
 */
function techanaRevueBindingDateJour(): string {
    return ucfirst( wp_date( 'l j F Y' ) );
}

/**
 * Libellé du pavé « À la une » : suit le volume réglé (Apparence → Une de
 * l'accueil). Écrit en dur dans le gabarit, il mentirait au premier réglage.
 */
function techanaRevueBindingCompteUne(): string {
    $nombre = techanaRevueReglagesUne()['une'];
    $pluriel = $nombre > 1 ? 's' : '';
    return sprintf(
        '%s article%s sélectionné%s',
        number_format_i18n( $nombre ),
        $pluriel,
        $pluriel
    );
}

function techanaRevueBindingLecture( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    return techanaRevueTempsLecture( $postId ) . ' min';
}

function techanaRevueBindingMots( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    $mots = (int) get_post_meta( $postId, '_techana_mots', true );
    if ( $mots < 1 ) {
        $mots = techanaRevueWordCount( get_post_field( 'post_content', $postId ) );
    }
    return number_format_i18n( $mots ) . ' mots';
}

/**
 * La date de mise à jour n'est un signal que si elle diffère du jour de
 * publication — même règle que le JSON-LD (spec gabarits-editoriaux).
 */
function techanaRevueBindingMaj( array $args, $block ): string {
    $postId = $block->context['postId'] ?? get_the_ID();
    if ( ! $postId ) {
        return '';
    }
    if ( get_the_date( 'Y-m-d', $postId ) === get_the_modified_date( 'Y-m-d', $postId ) ) {
        return '';
    }
    return 'Mis à jour le ' . get_the_modified_date( '', $postId );
}

/**
 * Compteur du pavé de section : terme passé en args.terme (accueil), sinon
 * terme requêté (hub), sinon rubrique principale de l'article courant.
 */
function techanaRevueBindingCompteur( array $args, $block ): string {
    if ( is_author() ) {
        $total = count_user_posts( get_queried_object_id(), 'post', true );
        return number_format_i18n( $total ) . ' articles';
    }
    $term = null;
    if ( ! empty( $args['terme'] ) ) {
        $term = get_term_by( 'slug', $args['terme'], 'category' );
    } elseif ( is_category() ) {
        $term = get_queried_object();
    } elseif ( ! empty( $block->context['postId'] ) ) {
        $cats = get_the_category( $block->context['postId'] );
        $term = $cats[0] ?? null;
    }
    if ( ! $term instanceof WP_Term ) {
        return '';
    }
    return number_format_i18n( $term->count ) . ' articles';
}

/**
 * Clé de couleur d'un terme, repli chaîne vide (la CSS retombe sur --accent).
 */
function techanaRevueCleRubrique( ?WP_Term $term ): string {
    if ( ! $term instanceof WP_Term ) {
        return '';
    }
    $cle = get_term_meta( $term->term_id, '_techana_cle', true );
    return is_string( $cle ) ? sanitize_html_class( $cle ) : '';
}

/**
 * Les templates portent la classe neutre `k-auto` ; au rendu elle devient
 * `k-<cle>` selon le contexte (article de la boucle, hub requêté), ou
 * disparaît si aucune clé n'existe — jamais de valeur en dur dans le markup.
 */
function techanaRevueKClassFilter( string $content, array $block, WP_Block $instance ): string {
    $classes = $block['attrs']['className'] ?? '';
    if ( ! str_contains( $classes, 'k-auto' ) || ! str_contains( $content, 'k-auto' ) ) {
        return $content;
    }

    // Un core/group ne déclare pas `postId` dans uses_context : à l'intérieur
    // d'un post-template, son contexte de bloc est vide (vérifié : `context` et
    // `available_context` le sont tous les deux). L'article courant se lit alors
    // sur la boucle elle-même, que core/post-template amorce à chaque item —
    // sans quoi aucune carte de l'accueil ne recevait sa couleur de rubrique.
    $postId = $instance->available_context['postId']
        ?? $instance->context['postId']
        ?? (int) get_the_ID();

    $term = null;
    if ( $postId ) {
        $cats = get_the_category( $postId );
        $term = $cats[0] ?? null;
    } elseif ( is_category() ) {
        $term = get_queried_object();
    } elseif ( is_singular( 'post' ) ) {
        $cats = get_the_category();
        $term = $cats[0] ?? null;
    }

    $cle       = techanaRevueCleRubrique( $term );
    $remplace  = ( '' === $cle ) ? '' : 'k-' . $cle;
    $nettoyage = static function ( string $html ) use ( $remplace ): string {
        $html = str_replace( 'k-auto', $remplace, $html );
        return str_replace( array( 'class=" ', '  ' ), array( 'class="', ' ' ), $html );
    };
    return $nettoyage( $content );
}

/**
 * Compteur de vues minimal pour « les plus lus » — pas de plugin, pas de
 * précision d'audience : un ordre de grandeur suffit pour trier.
 */
function techanaRevueCompterVue() {
    if ( ! is_singular( 'post' ) || is_preview() || is_user_logged_in() ) {
        return;
    }
    $postId = get_queried_object_id();
    $vues   = (int) get_post_meta( $postId, '_techana_vues', true );
    update_post_meta( $postId, '_techana_vues', $vues + 1 );
    if ( ! get_option( 'techana_a_des_vues' ) ) {
        update_option( 'techana_a_des_vues', 1, true );
    }
}
