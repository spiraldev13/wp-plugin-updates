<?php
/**
 * 01 — Bandeau d'accueil (hero).
 *
 * Visuel : grand titre avec mot en accent cyan + sous-titre + 2 CTAs (primaire
 * et fantôme) + 3 badges de réassurance + à droite, le visuel SVG « node graph »
 * encadré, avec 2 cartes statistiques flottantes (Core Web Vitals / Trafic).
 *
 * Pilotage ACF :
 *   - Front-page : hero_status_text, hero_title_lead, hero_title_accent,
 *     hero_title_trail, hero_sub, hero_visual_label, hero_meta (repeater),
 *     hero_stats (repeater), hero_cta_primary_show / _label / _url,
 *     hero_cta_secondary_show / _label / _url.
 *
 * Sous-fichier inclus : sections/01-accueil-bandeau-visuel.php (SVG animé).
 */

if (!defined('ABSPATH')) {
    exit;
}

$status   = get_field('hero_status_text') ?: get_field('hero_status_text', 'option') ?: __('Disponible — projet livré en 2 à 4 semaines', 'evolutionr');
$lead     = get_field('hero_title_lead') ?: __('Des sites pensés pour', 'evolutionr');
$accent   = get_field('hero_title_accent') ?: __('performer', 'evolutionr');
$trail    = get_field('hero_title_trail') ?: __('dès le premier clic.', 'evolutionr');
$sub      = get_field('hero_sub') ?: __('Architecture SEO native, code allégé, données mesurables. Evolution\'R conçoit des sites qui se classent, convertissent et tiennent dans le temps.', 'evolutionr');
$visualLabel = get_field('hero_visual_label') ?: 'site_architecture.map';

// CTA primaire — piloté en page d'accueil, avec fallback éventuel sur les options.
$ctaPrimaryShow  = get_field('hero_cta_primary_show');
$ctaPrimaryShow  = ($ctaPrimaryShow === null) ? true : (bool) $ctaPrimaryShow;
$ctaPrimaryLabel = get_field('hero_cta_primary_label')
    ?: (get_field('cta_primary_label', 'option') ?: __('Démarrer mon projet', 'evolutionr'));
$ctaPrimaryUrl   = get_field('hero_cta_primary_url')
    ?: (get_field('cta_primary_url', 'option') ?: '/contact/');

// CTA secondaire — entièrement piloté en page d'accueil.
$ctaSecondaryShow  = get_field('hero_cta_secondary_show');
$ctaSecondaryShow  = ($ctaSecondaryShow === null) ? true : (bool) $ctaSecondaryShow;
$ctaSecondaryLabel = get_field('hero_cta_secondary_label') ?: __('Voir les réalisations', 'evolutionr');
// Ancre vers la section #works (08-realisations.php) avec scroll smooth
// (cf. base/_base.scss). Pas de page /realisations/ standalone publiée.
$ctaSecondaryUrl   = get_field('hero_cta_secondary_url') ?: '#works';
?>
<section class="hero" aria-labelledby="hero-title">
    <div class="container hero-grid">
        <div>
            <?php if ($status): ?>
                <div class="hero-status">
                    <span class="status-dot" aria-hidden="true"></span>
                    <span><?php echo esc_html($status); ?></span>
                </div>
            <?php endif; ?>

            <h1 class="hero-title" id="hero-title">
                <?php echo esc_html($lead); ?><br>
                <span class="accent"><?php echo esc_html($accent); ?></span> <?php echo esc_html($trail); ?>
            </h1>

            <?php if ($sub): ?>
                <p class="hero-sub"><?php echo esc_html($sub); ?></p>
            <?php endif; ?>

            <?php if (($ctaPrimaryShow && $ctaPrimaryLabel) || ($ctaSecondaryShow && $ctaSecondaryLabel)): ?>
                <div class="hero-actions">
                    <?php if ($ctaPrimaryShow && $ctaPrimaryLabel): ?>
                        <a class="btn btn-primary" href="<?php echo esc_url($ctaPrimaryUrl); ?>">
                            <?php echo esc_html($ctaPrimaryLabel); ?>
                            <?php evolutionr_icon('arrow-right', 16); ?>
                        </a>
                    <?php endif; ?>
                    <?php if ($ctaSecondaryShow && $ctaSecondaryLabel): ?>
                        <a class="btn btn-ghost" href="<?php echo esc_url($ctaSecondaryUrl); ?>">
                            <span class="btn-inner">
                                <?php echo esc_html($ctaSecondaryLabel); ?>
                            </span>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (have_rows('hero_meta')): ?>
                <div class="hero-meta">
                    <?php $first = true; while (have_rows('hero_meta')): the_row();
                        if (!$first): ?>
                            <span class="hero-meta-divider" aria-hidden="true"></span>
                        <?php endif; $first = false; ?>
                        <span class="hero-meta-item">
                            <?php evolutionr_icon('check', 12); ?>
                            <?php echo esc_html(get_sub_field('label')); ?>
                        </span>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="hero-visual">
            <div class="hero-visual-frame">
                <span class="hero-visual-corner tl"></span>
                <span class="hero-visual-corner tr"></span>
                <span class="hero-visual-corner bl"></span>
                <span class="hero-visual-corner br"></span>
                <span class="hero-visual-label"><?php echo esc_html($visualLabel); ?></span>
                <span class="hero-visual-readout">
                    <span class="readout-dot" aria-hidden="true"></span>
                    live
                </span>
                <?php get_template_part('template-parts/sections/01-accueil-bandeau-visuel'); ?>
            </div>

            <?php if (have_rows('hero_stats')):
                $statIndex = 1;
                ?>
                <div class="hero-stats">
                    <?php while (have_rows('hero_stats')): the_row(); ?>
                        <div class="hero-stat-card s<?php echo esc_attr((string) $statIndex); ?>">
                            <div class="label"><?php echo esc_html(get_sub_field('label')); ?></div>
                            <div class="value"><?php echo esc_html(get_sub_field('value')); ?></div>
                            <?php if ($delta = get_sub_field('delta')): ?>
                                <div class="delta"><?php echo esc_html($delta); ?></div>
                            <?php endif; ?>
                        </div>
                        <?php $statIndex++; ?>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
