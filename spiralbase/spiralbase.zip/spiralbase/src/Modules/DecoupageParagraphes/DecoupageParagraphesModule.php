<?php

declare(strict_types=1);

namespace SpiralBase\Modules\DecoupageParagraphes;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;
use SpiralBase\Core\Walker;

/**
 * Découpage des paragraphes longs (CAP-9, story 2.6) — TRANSFORMATION du
 * walker (AD-10) : le rendu change, la base JAMAIS. La meta d'article
 * `spiralbase_decoupage_desactive` (AC 2) prime sur tout réglage global ;
 * un contenu exclu par ContentRules n'atteint jamais la transformation
 * (structurel, 1.4).
 *
 * Sonde (faits LUS dans le plugin legacy installé) : cède quand la CLASSE
 * du Text Enhancer est chargée (plugin actif — `MP_PATH` écarté en revue :
 * constante générique) ET son réglage global vaut '1'. LIMITES DOCUMENTÉES
 * (revue 2.6) : la porte réelle du legacy inclut aussi une metabox par
 * article et un mode « manual » — invisibles à `after_setup_theme` (métas
 * par post). La cohabitation spiralbase + ultimate-shanks est TRANSITOIRE
 * (la consolidation retire le legacy de la flotte) : le cas dominant
 * (global '1') est couvert, les cas metabox résiduels peuvent produire un
 * double découpage pendant la transition — assumé et tracé.
 */
final class DecoupageParagraphesModule implements Module
{
    public const OPTION = 'spiralbase_decoupage';

    public const META = 'spiralbase_decoupage_desactive';

    /** @param \Closure():bool|null $faitTextEnhancer fait injectable pour les tests */
    public function __construct(
        private readonly Walker $walker,
        private readonly Options $options,
        private readonly ?\Closure $faitTextEnhancer = null,
    ) {
    }

    public function slug(): string
    {
        return 'decoupage_paragraphes';
    }

    public function boot(): void
    {
        register_post_meta('post', self::META, [
            'single'        => true,
            'type'          => 'boolean',
            'default'       => false,
            'show_in_rest'  => true,
            'auth_callback' => static fn (): bool => current_user_can('edit_posts'),
        ]);

        $this->walker->addTransformation(
            'decoupage_paragraphes',
            fn (string $contenu, array $contexte): string => $this->transformer($contenu)
        );
    }

    public function defaultSettings(): array
    {
        return ['longueur_min' => 400, 'phrases_par_paragraphe' => 2];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitTextEnhancer ?? static fn (): bool => class_exists('UltimateShanks\\TextEnhancer\\TextEnhancer', false)
                && get_option('ultimate_shanks_text_enhancer_enabled', '0') === '1',
            static fn (): string => __('Découpage réellement assuré par le Text Enhancer d\'ultimate-shanks.', 'spiralbase')
        );
    }

    /** Transformation du walker — le walker attrape les Throwable (1.4). */
    private function transformer(string $contenu): string
    {
        $post = get_post();

        /* Périmètre : les ARTICLES seulement (le legacy excluait les pages,
           et la meta AC 2 n'existe que pour 'post' — revue 2.6). */
        if (!is_object($post) || (($post->post_type ?? 'post') !== 'post')) {
            return $contenu;
        }

        /* AC 2 : le choix PAR ARTICLE prime sur tout. */
        if (!empty(get_post_meta((int) ($post->ID ?? 0), self::META, true))) {
            return $contenu;
        }

        return $this->decoupeur()->decouper($contenu);
    }

    /** Réglages assainis : une valeur corrompue retombe sur le défaut sûr. */
    private function decoupeur(): Decoupeur
    {
        $reglages = $this->options->get(self::OPTION, []);
        $reglages = is_array($reglages) ? $reglages : [];
        $defauts  = $this->defaultSettings();

        $longueur = is_numeric($reglages['longueur_min'] ?? null) && (int) $reglages['longueur_min'] > 0
            ? (int) $reglages['longueur_min'] : $defauts['longueur_min'];
        $phrases  = is_numeric($reglages['phrases_par_paragraphe'] ?? null) && (int) $reglages['phrases_par_paragraphe'] > 0
            ? (int) $reglages['phrases_par_paragraphe'] : $defauts['phrases_par_paragraphe'];

        return new Decoupeur($longueur, $phrases);
    }
}
