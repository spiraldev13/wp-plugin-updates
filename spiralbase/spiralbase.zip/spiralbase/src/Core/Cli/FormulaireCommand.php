<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Core\Options;
use SpiralBase\Modules\FormulaireContact\FormulaireContactModule;

/**
 * `wp spiralbase formulaire` — la porte de configuration du formulaire.
 *
 * Sans elle, l'AC 3 était inatteignable : l'option `spiralbase_formulaire`
 * n'était écrite par AUCUN chemin supporté, donc ni le destinataire ni les
 * clés Turnstile ne pouvaient être posés. C'est le défaut exact déjà payé en
 * story 3.4, où l'AC parlait d'une URL « configurée » qu'aucune commande ne
 * permettait d'écrire.
 *
 * Les réglages sont écrits SANS autoload : `turnstile_secret` est un secret,
 * il n'a rien à faire dans `alloptions`, chargé sur chaque requête du site
 * (leçon 3.3).
 */
final class FormulaireCommand
{
    public function __construct(private readonly Options $options)
    {
    }

    /**
     * Enregistre l'adresse qui reçoit les messages.
     *
     * ## OPTIONS
     *
     * <email>
     * : Adresse de destination. Vide pour revenir à l'adresse d'administration.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase formulaire destinataire contact@restaurant.fr
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function destinataire(array $args, array $assocArgs): void
    {
        $email = trim((string) ($args[0] ?? ''));

        if ($email !== '' && sanitize_email($email) === '') {
            \WP_CLI::error('Adresse refusée : une adresse e-mail valide est attendue.');

            return;
        }

        $this->ecrire(['destinataire' => $email === '' ? '' : sanitize_email($email)]);

        \WP_CLI::success($email === ''
            ? 'Destinataire remis à l\'adresse d\'administration du site.'
            : sprintf('Les messages seront envoyés à %s.', sanitize_email($email)));
    }

    /**
     * Enregistre les clés Cloudflare Turnstile (couche anti-spam facultative).
     *
     * ## OPTIONS
     *
     * <cle-site>
     * : Clé publique du site. Vide pour éteindre la couche.
     *
     * [<cle-secrete>]
     * : Clé secrète. Obligatoire si la clé de site est fournie.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase formulaire turnstile 0x4AAA... 0x4AAA...
     *     wp spiralbase formulaire turnstile ""
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function turnstile(array $args, array $assocArgs): void
    {
        $site   = trim((string) ($args[0] ?? ''));
        $secret = trim((string) ($args[1] ?? ''));

        if ($site === '' && $secret === '') {
            $this->ecrire(['turnstile_site' => '', 'turnstile_secret' => '']);
            \WP_CLI::success('Turnstile éteint : les quatre couches natives restent actives.');

            return;
        }

        /* Les deux clés ou aucune : une configuration à moitié posée laisse
           l'opérateur croire son formulaire protégé alors qu'il ne l'est pas. */
        if ($site === '' || $secret === '') {
            \WP_CLI::error('Turnstile a besoin des DEUX clés : celle du site et la clé secrète.');

            return;
        }

        $this->ecrire(['turnstile_site' => $site, 'turnstile_secret' => $secret]);

        \WP_CLI::success('Turnstile activé — il s\'AJOUTE aux quatre couches natives, il ne les remplace pas.');
    }

    /**
     * Affiche la configuration en vigueur.
     *
     * ## EXAMPLES
     *
     *     wp spiralbase formulaire etat
     *
     * @param array<int, string>    $args
     * @param array<string, string> $assocArgs
     */
    public function etat(array $args, array $assocArgs): void
    {
        $reglages = $this->reglages();
        $email    = trim((string) ($reglages['destinataire'] ?? ''));

        \WP_CLI::log($email === ''
            ? 'Destinataire : adresse d\'administration du site (aucun destinataire propre).'
            : sprintf('Destinataire : %s', $email));

        /* La clé secrète n'est JAMAIS affichée, même à un administrateur : un
           journal de terminal se copie, se partage et se sauvegarde. */
        \WP_CLI::log(trim((string) ($reglages['turnstile_site'] ?? '')) !== ''
            && trim((string) ($reglages['turnstile_secret'] ?? '')) !== ''
                ? 'Turnstile : activé (clé secrète enregistrée, non affichée).'
                : 'Turnstile : éteint.');
    }

    /** @param array<string, string> $modifications */
    private function ecrire(array $modifications): void
    {
        $this->options->set(
            FormulaireContactModule::OPTION,
            array_merge($this->reglages(), $modifications),
            false
        );
    }

    /** @return array<string, mixed> */
    private function reglages(): array
    {
        $valeurs = $this->options->get(FormulaireContactModule::OPTION, []);

        return is_array($valeurs) ? $valeurs : [];
    }
}
