<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\Signal;

/**
 * Rendu serveur du bloc `spiralbase/menu` — la carte elle-même.
 *
 * Le parent n'a AUCUN contenu propre : il enveloppe le HTML de ses sections,
 * reçu déjà rendu et déjà échappé en 2ᵉ argument (`class-wp-block.php:544-581`
 * assemble les enfants avant d'appeler le `render_callback`). Le re-parser,
 * ou pire le re-filtrer, casserait la mise en forme des enfants et
 * introduirait un second juge du même HTML.
 *
 * Sa seule décision : la mise en forme, qu'il déclare aussi à ses descendants
 * par le contexte de bloc natif.
 */
final class RenduMenu extends RenduBloc
{
    protected function nomDuBloc(): string
    {
        return 'spiralbase/menu';
    }

    protected function composer(array $attributs, string $contenu, mixed $bloc): string
    {
        $variante = Variantes::depuisAttributs($attributs);

        /* Carte sans aucune section : pas de conteneur vide dans la page —
           un bloc fraîchement inséré et jamais rempli ne doit rien peser. */
        if (trim($contenu) === '') {
            $this->signalerCarteVide($bloc);

            return '';
        }

        return '<div ' . $this->conteneur('spiralbase-menu spiralbase-menu--' . $variante) . '>' . $contenu . '</div>';
    }

    /**
     * Une carte QUI A des sections mais ne rend rien est un silence coûteux :
     * l'opérateur voit sa carte dans l'éditeur et rien sur le site. C'est
     * l'état exact que produit le gabarit auto-inséré quand on saisit le
     * titre d'une section sans remplir un seul plat. Le distinguer de la
     * carte vraiment vide demande de compter les enfants — la seule
     * information que le rendu ne peut pas déduire du HTML reçu.
     */
    private function signalerCarteVide(mixed $bloc): void
    {
        try {
            $enfants = is_object($bloc) ? ($bloc->inner_blocks ?? null) : null;
            $nombre  = is_countable($enfants) ? count($enfants) : 0;
        } catch (\Throwable) {
            return;
        }

        if ($nombre === 0) {
            return;
        }

        Signal::emettre(
            'spiralbase_bloc_menu_carte_vide',
            sprintf('carte rendue vide : %d section(s) sans plat exploitable', $nombre),
            'bloc menu'
        );
    }
}
