<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocCoordonnees;

use SpiralBase\Core\AttributsBloc;
use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\Signal;

/**
 * Rendu serveur du bloc `spiralbase/coordonnees` (story 3.1) — nom, adresse
 * postale et téléphone, lus dans la porte unique `DonneesMetier` (AD-2), la
 * même que celle du JSON-LD `schema_metier` : une saisie, deux sorties.
 *
 * Échappement AU POINT DE SORTIE, par contexte : `esc_html` pour le texte,
 * `esc_url` pour le `href` (le protocole `tel` est autorisé par le cœur —
 * `wp-includes/functions.php:7245`). La relecture de `DonneesMetier` valide
 * la FORME, pas l'innocuité du contenu : une base altérée hors porte peut
 * livrer un nom porteur de balises, seul ce point de sortie l'arrête.
 *
 * Aucun chemin fatal : toute exception rend une chaîne vide + signal NFR13.
 */
final class RenduCoordonnees
{
    /**
     * Ce qui reste d'un numéro composable : chiffres et un « + » de tête.
     * Plafond à 15 chiffres — la longueur maximale d'un numéro E.164 ; à 20,
     * deux numéros français concaténés passaient pile la borne.
     */
    private const COMPOSABLE = '/^\+?\d{4,15}$/';

    public function __construct(private readonly DonneesMetier $donnees)
    {
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs): string
    {
        try {
            return $this->contenu($attributs);
        } catch (\Throwable $e) {
            $this->signaler('spiralbase_bloc_coordonnees_echec', 'rendu interrompu : ' . $e->getMessage());

            return '';
        }
    }

    /**
     * Signal borné à UNE émission par requête et par message : N blocs
     * coordonnées sur une page ne doivent pas produire N journaux. Le
     * mécanisme vit dans le noyau depuis la story 3.2 (`Core\Signal`).
     */
    private function signaler(string $hook, string $message): void
    {
        Signal::emettre($hook, $message, 'bloc coordonnées');
    }

    /** @param array<string, mixed> $attributs */
    private function contenu(array $attributs): string
    {
        $donnees = $this->donnees->get();

        if ($donnees === null) {
            return '';
        }

        $sections = '';

        if (AttributsBloc::booleen($attributs, 'afficherNom', true)) {
            $sections .= $this->nom($donnees);
        }

        if (AttributsBloc::booleen($attributs, 'afficherAdresse', true)) {
            $sections .= $this->adresse($donnees);
        }

        if (AttributsBloc::booleen($attributs, 'afficherTelephone', true)) {
            $sections .= $this->telephone($donnees);
        }

        /* Rien à dire : pas de conteneur vide dans la page. */
        if ($sections === '') {
            return '';
        }

        return '<div ' . EnveloppeBloc::attributs('spiralbase-coordonnees') . '>' . $sections . '</div>';
    }

    /** @param array<string, mixed> $donnees */
    private function nom(array $donnees): string
    {
        $nom = trim((string) ($donnees['nom'] ?? ''));

        return $nom === '' ? '' : '<p class="spiralbase-coordonnees__nom">' . esc_html($nom) . '</p>';
    }

    /** @param array<string, mixed> $donnees */
    private function adresse(array $donnees): string
    {
        $adresse = is_array($donnees['adresse'] ?? null) ? $donnees['adresse'] : [];
        $rue     = trim((string) ($adresse['rue'] ?? ''));
        $ville   = trim(trim((string) ($adresse['code_postal'] ?? '')) . ' ' . trim((string) ($adresse['ville'] ?? '')));

        /* Un champ manquant ne laisse ni ligne vide ni séparateur orphelin :
           on ne compose qu'avec ce qui est réellement renseigné. */
        $lignes = array_values(array_filter([$rue, $ville], static fn (string $ligne): bool => $ligne !== ''));

        if ($lignes === []) {
            return '';
        }

        return '<address class="spiralbase-coordonnees__adresse">'
            . implode('<br />', array_map('esc_html', $lignes))
            . '</address>';
    }

    /** @param array<string, mixed> $donnees */
    private function telephone(array $donnees): string
    {
        $telephone = trim((string) ($donnees['telephone'] ?? ''));

        if ($telephone === '') {
            return '';
        }

        $compose = $this->numeroComposable($telephone);
        $libelle = esc_html($telephone);

        /* « sur demande », deux numéros, une extension : on affiche la
           mention telle quelle plutôt qu'un lien tel: qui composerait un
           numéro faux. L'opérateur en est averti (NFR13) — sans cela, il ne
           découvrirait le lien mort que par un client mécontent. */
        if ($compose === null) {
            $this->signaler(
                'spiralbase_bloc_coordonnees_telephone_non_composable',
                sprintf('téléphone affiché sans lien (numéro non composable) : « %s »', $telephone)
            );
        }

        $corps = $compose === null
            ? $libelle
            : '<a href="' . esc_url('tel:' . $compose) . '">' . $libelle . '</a>';

        return '<p class="spiralbase-coordonnees__telephone">' . $corps . '</p>';
    }

    /**
     * Numéro réduit à ce qu'un téléphone sait composer, ou null s'il n'en
     * est pas un.
     *
     * La première version jugeait sur les CHIFFRES EXTRAITS, en effaçant
     * tout le reste : « 01 23 45 67 89 ou 06 12 34 56 78 » (deux numéros,
     * forme très courante) donnait `tel:01234567890612345678`, et
     * « Tel. +33 1 23 45 67 89 » perdait son `+` — le libellé restait juste,
     * la cible était fausse, et un tap composait un numéro inexistant
     * (revue 3.1, prouvé aux trois couches).
     *
     * Règle retenue : le champ doit contenir UN numéro, éventuellement
     * décoré de séparateurs typographiques. Toute lettre, tout séparateur
     * de liste, tout second numéro ⇒ pas de lien. On n'invente jamais un
     * numéro à partir d'une phrase.
     */
    private function numeroComposable(string $telephone): ?string
    {
        /* Seuls les séparateurs internes d'UN numéro sont effacés : ni « / »
           ni « , » (ils annoncent un second numéro), aucune lettre. */
        $normalise = preg_replace('/[\s\x{00A0}\x{202F}.\x{2010}-\x{2015}\x{2212}-]+/u', '', trim($telephone)) ?? '';

        /* « +33 (0)1 … » : le zéro national est redondant derrière un
           indicatif international — c'est la seule parenthèse admise. */
        $normalise = preg_replace('/^(\+\d{1,3})\(0\)/', '$1', $normalise) ?? $normalise;

        return preg_match(self::COMPOSABLE, $normalise) === 1 ? $normalise : null;
    }
}
