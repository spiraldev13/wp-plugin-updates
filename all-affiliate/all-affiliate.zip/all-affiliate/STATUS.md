# makedev — Status

**Derniere mise a jour** : 2026-04-09

## Disponibilite

- Prod : ✅ live (branche main)
- Dev  : branche dev — fonctionnalites en cours

## Activite

- Statut : 🟡 En cours
- Phase actuelle : Ajout commandes WordPress, generation fichiers projet, refonte help et README
- Blocage : —

## Prochaine action

Committer et pusher toutes les modifications en cours sur dev.

## Historique recent

- 2026-04-09 — Ajout .TREE.md et STATUS.md generes par make init
- 2026-04-09 — Ajout commande make droits (permissions WordPress)
- 2026-04-09 — Help conditionnel par type de projet (section WordPress)
- 2026-04-09 — Correction clone Claude (copie depuis claude-code-projet/)
- 2026-04-09 — Ajout UPDATES_REPO dans project.conf pour WordPress
- 2026-04-09 — Mise a jour README (types, variables, GitHub CLI, self-update)
- 2026-04-09 — Ajout section installation GitHub CLI (Linux/WSL)
