<?php
/**
 * Title: Lien vers toutes les publications
 * Slug: techana-revue/lien-publications
 * Inserter: no
 * Description: Lien « Toutes les publications » de l'accueil — URL résolue côté
 * serveur pour rester valable en local (sous-dossier) comme en production.
 */
?>
<!-- wp:html -->
<p class="sec-more"><a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ); ?>">Toutes les publications →</a></p>
<!-- /wp:html -->
