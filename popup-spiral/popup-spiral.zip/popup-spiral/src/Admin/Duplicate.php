<?php

namespace Spiral\Admin;

use Spiral\PostTypes;
use Spiral\Settings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Action « Dupliquer » dans la liste des popups : copie le popup
 * et tous ses réglages en brouillon.
 */
final class Duplicate
{
    public static function register(): void
    {
        add_filter('post_row_actions', [self::class, 'addRowAction'], 10, 2);
        add_action('admin_post_spiral_duplicate_popup', [self::class, 'handle']);
    }

    /**
     * @param array    $actions
     * @param \WP_Post $post
     * @return array
     */
    public static function addRowAction($actions, $post)
    {
        if ($post->post_type !== PostTypes::POPUP || !current_user_can('edit_post', $post->ID)) {
            return $actions;
        }

        $url = wp_nonce_url(
            admin_url('admin-post.php?action=spiral_duplicate_popup&popup=' . $post->ID),
            'spiral_duplicate_' . $post->ID
        );

        $actions['spiral_duplicate'] = '<a href="' . esc_url($url) . '">' . esc_html__('Dupliquer', 'popup-spiral') . '</a>';

        return $actions;
    }

    public static function handle(): void
    {
        $popupId = isset($_GET['popup']) ? (int) $_GET['popup'] : 0;

        check_admin_referer('spiral_duplicate_' . $popupId);

        $source = get_post($popupId);

        if (!$source instanceof \WP_Post
            || $source->post_type !== PostTypes::POPUP
            || !current_user_can('edit_post', $popupId)
        ) {
            wp_die(esc_html__('Action non autorisée.', 'popup-spiral'));
        }

        $newId = wp_insert_post([
            'post_type' => PostTypes::POPUP,
            'post_status' => 'draft',
            'post_title' => sprintf(
                /* translators: %s : titre du popup dupliqué */
                __('%s (copie)', 'popup-spiral'),
                $source->post_title
            ),
            'post_content' => $source->post_content,
        ]);

        if ($newId && !is_wp_error($newId)) {
            update_post_meta($newId, Settings::META_KEY, get_post_meta($popupId, Settings::META_KEY, true));

            $thumbnailId = get_post_thumbnail_id($popupId);

            if ($thumbnailId) {
                set_post_thumbnail($newId, $thumbnailId);
            }
        }

        wp_safe_redirect(admin_url('edit.php?post_type=' . PostTypes::POPUP));
        exit;
    }
}
