<?php
/**
 * Diffusion des encarts commerciaux : quel encart, à quel endroit.
 *
 * Les encarts eux-mêmes sont des contenus (`inc/encarts.php`) ; ce module les
 * choisit et les rend. Cinq emplacements, commandés chacun par un interrupteur
 * global (« Apparence → Publicité ») : couper un emplacement n'efface aucun
 * encart, il cesse simplement d'être servi.
 *
 * Sans encart applicable, l'emplacement n'est montré qu'à qui peut le remplir :
 * un cadre vide servi aux visiteurs afficherait un trou.
 *
 * Le module porte aussi les deux sollicitations maison des latérales, réglées
 * sur le même écran : la proposition d'achat d'un espace vide et l'encart
 * « Publier chez nous ».
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_PUB_OPTION = 'techana_pub';
const TECHANA_PUB_PAGE   = 'techana-publicite';

add_action( 'init', 'techanaRevueRegisterBlocPub' );
add_action( 'init', 'techanaRevueRegisterBlocPitch' );
add_action( 'admin_init', 'techanaRevuePubSettings' );
add_action( 'admin_menu', 'techanaRevuePubMenu' );
add_filter( 'the_content', 'techanaRevueEncartDansCorps', 20 );

/**
 * Champs libres du bloc « espace à vendre ».
 *
 * @return array<string, array{label: string, aide: string, defaut: string}>
 */
function techanaRevuePromoChamps(): array {
    return array(
        'promo_titre'  => array(
            'label'  => 'Titre',
            'aide'   => 'L’accroche, en une ligne. Vide, le bloc n’est pas affiché du tout.',
            'defaut' => 'Votre publicité ici',
        ),
        'promo_texte'  => array(
            'label'  => 'Texte',
            'aide'   => 'Deux lignes au plus : ce que l’annonceur y gagne. Le détail vit sur la page « Annoncez sur TechAna ».',
            'defaut' => 'Cet emplacement est disponible pour votre marque, auprès d’un lectorat tech, SEO et marketing digital.',
        ),
        'promo_bouton' => array(
            'label'  => 'Libellé du bouton',
            'aide'   => 'Vide, le bloc s’affiche sans bouton.',
            'defaut' => 'Réserver cet espace',
        ),
        'promo_lien'   => array(
            'label'  => 'Lien du bouton',
            'aide'   => 'Où mène le bouton. Vide, le bloc s’affiche sans bouton plutôt qu’avec un bouton mort.',
            'defaut' => '',
        ),
    );
}

/**
 * Page « Annoncez sur TechAna », destination naturelle du bouton.
 *
 * Résolue une seule fois par requête : elle ne sert qu'à remplir le champ tant
 * que l'administrateur n'a pas enregistré ses propres réglages.
 */
function techanaRevuePromoLienDefaut(): string {
    static $lien = null;
    if ( null === $lien ) {
        $page = get_page_by_path( 'annonceurs' );
        $lien = $page ? (string) get_permalink( $page ) : '';
    }
    return $lien;
}

/** Réglages effectifs — défauts fusionnés avec l'option stockée. */
function techanaRevueReglagesPub(): array {
    $stockes = get_option( TECHANA_PUB_OPTION, array() );
    $stockes = is_array( $stockes ) ? $stockes : array();

    $reglages = array( 'paragraphes' => max( 1, min( 20, (int) ( $stockes['paragraphes'] ?? 4 ) ) ) );
    foreach ( array_keys( techanaRevueEncartEmplacements() ) as $cle ) {
        $reglages[ $cle . '_actif' ] = ! empty( $stockes[ $cle . '_actif' ] );
        // Proposition d'achat : les colonnes et le bandeau de rubrique d'office,
        // pas le fil du texte — une sollicitation au milieu d'une lecture agace.
        $defautPromo = in_array( $cle, array( 'lateral', 'article', 'hub' ), true );
        $reglages[ 'promo_' . $cle . '_actif' ] = isset( $stockes[ 'promo_' . $cle . '_actif' ] )
            ? ! empty( $stockes[ 'promo_' . $cle . '_actif' ] )
            : $defautPromo;
    }
    $reglages['pitch_actif'] = ! empty( $stockes['pitch_actif'] );
    foreach ( techanaRevuePromoChamps() as $cle => $def ) {
        $reglages[ $cle ] = isset( $stockes[ $cle ] )
            ? (string) $stockes[ $cle ]
            : ( 'promo_lien' === $cle ? techanaRevuePromoLienDefaut() : $def['defaut'] );
    }
    return $reglages;
}

/**
 * @param mixed $entree Valeurs postées.
 */
function techanaRevuePubSanitize( $entree ): array {
    $entree = is_array( $entree ) ? $entree : array();
    $propre = array( 'paragraphes' => max( 1, min( 20, (int) ( $entree['paragraphes'] ?? 4 ) ) ) );
    foreach ( array_keys( techanaRevueEncartEmplacements() ) as $cle ) {
        $propre[ $cle . '_actif' ]           = ! empty( $entree[ $cle . '_actif' ] );
        $propre[ 'promo_' . $cle . '_actif' ] = ! empty( $entree[ 'promo_' . $cle . '_actif' ] );
    }
    $propre['pitch_actif'] = ! empty( $entree['pitch_actif'] );
    foreach ( array_keys( techanaRevuePromoChamps() ) as $cle ) {
        $valeur = (string) ( $entree[ $cle ] ?? '' );
        // Le lien passe par esc_url_raw, qui écarte les protocoles exécutables.
        $propre[ $cle ] = 'promo_lien' === $cle
            ? esc_url_raw( trim( $valeur ) )
            : sanitize_text_field( $valeur );
    }
    return $propre;
}

/**
 * Rubrique de la vue courante : le terme sur un hub, la rubrique principale sur
 * un article, 0 partout ailleurs (accueil, publications) — 0 appelle alors les
 * encarts par défaut.
 */
function techanaRevueRubriqueCourante(): int {
    if ( is_category() ) {
        $terme = get_queried_object();
        return $terme instanceof WP_Term ? (int) $terme->term_id : 0;
    }
    if ( is_singular( 'post' ) ) {
        $cats = get_the_category();
        return $cats ? (int) $cats[0]->term_id : 0;
    }
    return 0;
}

/**
 * Encart épinglé sur l'article courant pour cet emplacement, ou null.
 *
 * Un épinglage est une décision prise article par article : il passe donc avant
 * le ciblage par rubrique — mais pour son seul emplacement, les latérales et le
 * bandeau de rubrique continuant de suivre les règles habituelles. L'encart doit
 * être publié : repassé en brouillon, il s'éteint comme partout ailleurs et
 * l'article retombe sur sa rubrique.
 */
function techanaRevueEncartEpingle( string $emplacement ): ?WP_Post {
    $positions = array( 'article_corps' => 'corps', 'article_pied' => 'pied' );
    if ( ! isset( $positions[ $emplacement ] ) || ! is_singular( 'post' ) ) {
        return null;
    }
    $postId = get_the_ID();
    $id     = (int) get_post_meta( $postId, '_techana_encart_epingle', true );
    if ( ! $id ) {
        return null;
    }
    $position = (string) get_post_meta( $postId, '_techana_encart_epingle_position', true );
    if ( $positions[ $emplacement ] !== ( '' !== $position ? $position : 'corps' ) ) {
        return null;
    }
    $encart = get_post( $id );
    if ( ! $encart instanceof WP_Post
        || TECHANA_ENCART_TYPE !== $encart->post_type
        || 'publish' !== $encart->post_status ) {
        return null;
    }
    return $encart;
}

/**
 * Encart à servir pour un emplacement, ou null.
 *
 * Les encarts de la rubrique courante l'emportent ; à défaut, ceux qui ne
 * ciblent aucune rubrique. Plusieurs candidats : tirage aléatoire — c'est ce
 * qui fait tourner les liens, un tri fixe ne montrerait jamais que le premier.
 */
function techanaRevueEncartPour( string $emplacement ): ?WP_Post {
    $epingle = techanaRevueEncartEpingle( $emplacement );
    if ( $epingle ) {
        return $epingle;
    }

    $commun = array(
        'post_type'      => TECHANA_ENCART_TYPE,
        'post_status'    => 'publish',
        'posts_per_page' => 50,
        'meta_query'     => array(
            array(
                'key'     => '_techana_encart_emplacements',
                'value'   => '"' . $emplacement . '"',
                'compare' => 'LIKE',
            ),
        ),
    );

    $rubrique = techanaRevueRubriqueCourante();
    $cibles   = array();
    if ( $rubrique ) {
        $cibles = get_posts( $commun + array( 'category__in' => array( $rubrique ) ) );
    }
    if ( ! $cibles ) {
        // Encarts par défaut : ceux qui ne visent aucune rubrique.
        $sans = get_posts( $commun );
        $cibles = array_values( array_filter( $sans, static function ( WP_Post $encart ): bool {
            $termes = get_the_terms( $encart, 'category' );
            return ! $termes || is_wp_error( $termes );
        } ) );
    }
    if ( ! $cibles ) {
        return null;
    }
    return $cibles[ array_rand( $cibles ) ];
}

/**
 * Rend un encart : libellé, contenu, mention.
 *
 * @param WP_Post $encart      Encart à rendre.
 * @param string  $emplacement Sert de classe de format.
 */
function techanaRevueRendreEncart( WP_Post $encart, string $emplacement ): string {
    $champs  = techanaRevueEncartChamps( $encart->ID );
    $libelle = '' !== $champs['libelle'] ? $champs['libelle'] : 'Publicité';

    if ( '' !== $champs['code'] ) {
        $contenu = $champs['code'];
    } else {
        $contenu = techanaRevueEncartVisuel( $encart, $champs, $emplacement );
    }
    if ( '' === $contenu ) {
        return '';
    }

    $mention = '' !== $champs['mention']
        ? '<p class="mention">' . esc_html( $champs['mention'] ) . '</p>'
        : '';

    return sprintf(
        '<section class="aside-block adslot adslot-%s"><span class="tagline">%s</span>%s%s</section>',
        esc_attr( str_replace( '_', '-', $emplacement ) ),
        esc_html( $libelle ),
        $contenu,
        $mention
    );
}

/**
 * Visuel de l'encart, lié si une destination est renseignée.
 *
 * @param string $emplacement Détermine la taille demandée : une latérale tient
 *                            dans 300 px, un bandeau de rubrique non.
 */
function techanaRevueEncartVisuel( WP_Post $encart, array $champs, string $emplacement = 'lateral' ): string {
    $large = in_array( $emplacement, array( 'hub', 'article_corps', 'article_pied' ), true );
    $image = get_the_post_thumbnail( $encart, $large ? 'large' : 'medium', array(
        'class'   => 'pub-visuel',
        'alt'     => '',
        'loading' => 'lazy',
    ) );
    if ( ! $image ) {
        return '';
    }
    if ( '' === $champs['lien'] ) {
        return $image;
    }
    // Déclaration choisie encart par encart (`sponsored`, `nofollow`, les deux
    // ou aucune) : c'est l'éditeur qui sait si le lien est commercial.
    $rel = $champs['rel']
        ? ' rel="' . esc_attr( implode( ' ', $champs['rel'] ) ) . '"'
        : '';
    return '<a href="' . esc_url( $champs['lien'] ) . '"' . $rel . '>' . $image . '</a>';
}

/**
 * Proposition d'achat servie à un emplacement resté vide.
 *
 * Ce bloc n'est pas une publicité : il ne porte donc pas la mention
 * « Publicité », que la page annonceurs réserve aux encarts payés. Il annonce
 * ce qu'il est — un espace disponible — et conduit à la page qui détaille
 * formats, conditions et contact.
 */
function techanaRevueRendrePromo( string $emplacement ): string {
    $reglages = techanaRevueReglagesPub();
    $titre    = trim( $reglages['promo_titre'] );
    if ( '' === $titre ) {
        return '';
    }
    $texte  = trim( $reglages['promo_texte'] );
    $lien   = trim( $reglages['promo_lien'] );
    $bouton = trim( $reglages['promo_bouton'] );

    return sprintf(
        '<section class="aside-block adslot adslot-promo adslot-%s">'
            . '<span class="tagline">Espace disponible</span>'
            . '<h3>%s</h3>%s%s</section>',
        esc_attr( str_replace( '_', '-', $emplacement ) ),
        esc_html( $titre ),
        '' !== $texte ? '<p>' . esc_html( $texte ) . '</p>' : '',
        ( '' !== $lien && '' !== $bouton )
            ? sprintf( '<a class="btn btn-primary" href="%s">%s</a>', esc_url( $lien ), esc_html( $bouton ) )
            : ''
    );
}

/**
 * Encart complet d'un emplacement : interrupteur, encart, repli visible du
 * seul administrateur.
 */
function techanaRevueEncartEmplacement( string $emplacement ): string {
    $reglages = techanaRevueReglagesPub();
    if ( empty( $reglages[ $emplacement . '_actif' ] ) ) {
        return '';
    }
    $encart = techanaRevueEncartPour( $emplacement );
    if ( $encart ) {
        return techanaRevueRendreEncart( $encart, $emplacement );
    }
    // Emplacement vide : proposé à la vente s'il est coché pour cela, sinon
    // signalé au seul administrateur.
    if ( ! empty( $reglages[ 'promo_' . $emplacement . '_actif' ] ) ) {
        return techanaRevueRendrePromo( $emplacement );
    }
    if ( current_user_can( 'edit_theme_options' ) ) {
        return sprintf(
            '<section class="aside-block adslot adslot-%s"><span class="tagline">Publicité</span>'
                . '<div class="frame">Aucun encart<br />pour cet emplacement</div></section>',
            esc_attr( str_replace( '_', '-', $emplacement ) )
        );
    }
    return '';
}

/**
 * Encart « Publier chez nous » des colonnes latérales.
 *
 * Il vivait en dur dans les deux `parts/` : impossible de l'éteindre sans
 * toucher au thème, alors qu'il renvoie vers une page que le site peut ne pas
 * proposer. Bloc dynamique, donc, commandé depuis Apparence → Publicité.
 */
function techanaRevueRegisterBlocPitch() {
    register_block_type( 'techana/pitch', array(
        'api_version'     => 3,
        'render_callback' => 'techanaRevueBlocPitch',
    ) );
}

function techanaRevueBlocPitch(): string {
    if ( empty( techanaRevueReglagesPub()['pitch_actif'] ) ) {
        return '';
    }
    return '<section class="wp-block-group aside-block"><div class="wp-block-group pitch">'
        . '<h3 class="wp-block-heading">Publier chez nous</h3>'
        . '<p>Nous étudions les propositions d’articles techniques et les partenariats '
        . 'éditoriaux. Réponse sous 48 heures ouvrées.</p>'
        . '<a class="btn btn-primary" href="' . esc_url( home_url( '/publier-chez-nous/' ) ) . '">'
        . 'Proposer un article</a>'
        . '</div></section>';
}

function techanaRevueRegisterBlocPub() {
    register_block_type( 'techana/pub', array(
        'api_version'     => 3,
        'render_callback' => 'techanaRevueBlocPub',
        'attributes'      => array(
            'emplacement' => array( 'type' => 'string', 'default' => 'lateral' ),
        ),
    ) );
}

function techanaRevueBlocPub( array $attrs ): string {
    $emplacement = (string) ( $attrs['emplacement'] ?? 'lateral' );
    if ( ! isset( techanaRevueEncartEmplacements()[ $emplacement ] ) ) {
        return '';
    }
    return techanaRevueEncartEmplacement( $emplacement );
}

/**
 * Insertion au fil du texte, après N paragraphes de premier niveau.
 *
 * Écartée sur un article sponsorisé : il porte déjà ses encarts annonceur, en
 * ajouter un troisième message commercial noierait la mention de sponsoring.
 */
function techanaRevueEncartDansCorps( string $contenu ): string {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
        return $contenu;
    }
    // Un article sponsorisé porte déjà ses encarts annonceur : aucun encart n'y
    // est inséré d'office. Un encart épinglé, lui, a été choisi pour cet article
    // précis — c'est une décision explicite, elle passe.
    if ( get_post_meta( get_the_ID(), '_techana_sponsorise', true )
        && ! techanaRevueEncartEpingle( 'article_corps' ) ) {
        return $contenu;
    }
    $encart = techanaRevueEncartEmplacement( 'article_corps' );
    if ( '' === $encart ) {
        return $contenu;
    }

    $position = techanaRevueFinParagraphe( $contenu, techanaRevueReglagesPub()['paragraphes'] );
    // Moins de paragraphes que le seuil : mieux vaut ne rien insérer que coller
    // l'encart juste avant la boîte auteur.
    if ( null === $position ) {
        return $contenu;
    }
    return substr( $contenu, 0, $position ) . $encart . substr( $contenu, $position );
}

/**
 * Position juste après la fermeture du n-ième paragraphe **de premier niveau**,
 * ou null s'il y en a moins que demandé.
 *
 * Les paragraphes d'une citation, d'une figure, d'une liste ou d'un tableau ne
 * comptent pas et ne peuvent pas recevoir l'encart : y insérer une section le
 * placerait à l'intérieur du bloc.
 */
function techanaRevueFinParagraphe( string $html, int $rang ): ?int {
    if ( $rang < 1 ) {
        return null;
    }
    $conteneurs = 'figure|blockquote|ul|ol|table|details|aside';
    $motif      = '~</p>|<(' . $conteneurs . ')\b|</(' . $conteneurs . ')>~i';

    if ( ! preg_match_all( $motif, $html, $trouves, PREG_OFFSET_CAPTURE ) ) {
        return null;
    }

    $profondeur = 0;
    $compte     = 0;
    foreach ( $trouves[0] as $trouve ) {
        $balise = strtolower( $trouve[0] );
        if ( '</p>' === $balise ) {
            if ( 0 === $profondeur && ++$compte === $rang ) {
                return $trouve[1] + strlen( $trouve[0] );
            }
            continue;
        }
        if ( str_starts_with( $balise, '</' ) ) {
            $profondeur = max( 0, $profondeur - 1 );
        } else {
            $profondeur++;
        }
    }
    return null;
}

function techanaRevuePubSettings() {
    register_setting( TECHANA_PUB_OPTION, TECHANA_PUB_OPTION, array(
        'type'              => 'array',
        'sanitize_callback' => 'techanaRevuePubSanitize',
        'default'           => array(),
    ) );

    add_settings_section(
        'techana-pub-emplacements',
        'Emplacements',
        'techanaRevuePubIntroEmplacements',
        TECHANA_PUB_PAGE
    );
    foreach ( techanaRevueEncartEmplacements() as $cle => $def ) {
        add_settings_field(
            'techana-pub-' . $cle,
            esc_html( $def['label'] ),
            'techanaRevuePubChampCase',
            TECHANA_PUB_PAGE,
            'techana-pub-emplacements',
            array( 'cle' => $cle, 'label_for' => 'techana-pub-' . $cle )
        );
    }

    techanaRevuePubSettingsPromo();

    add_settings_section(
        'techana-pub-pitch',
        'Encart « Publier chez nous »',
        'techanaRevuePubIntroPitch',
        TECHANA_PUB_PAGE
    );
    add_settings_field(
        'techana-pitch-actif',
        'Afficher l’encart',
        'techanaRevuePubChampPitch',
        TECHANA_PUB_PAGE,
        'techana-pub-pitch',
        array( 'label_for' => 'techana-pitch-actif' )
    );

    add_settings_section(
        'techana-pub-corps',
        'Insertion dans le corps des articles',
        '__return_false',
        TECHANA_PUB_PAGE
    );
    add_settings_field(
        'techana-pub-paragraphes',
        'Après combien de paragraphes',
        'techanaRevuePubChampParagraphes',
        TECHANA_PUB_PAGE,
        'techana-pub-corps',
        array( 'label_for' => 'techana-pub-paragraphes' )
    );
}

/** Section « Espace à vendre » : où proposer l'espace, et avec quels mots. */
function techanaRevuePubSettingsPromo() {
    add_settings_section(
        'techana-pub-promo',
        'Espace à vendre',
        'techanaRevuePubIntroPromo',
        TECHANA_PUB_PAGE
    );
    foreach ( techanaRevueEncartEmplacements() as $cle => $def ) {
        add_settings_field(
            'techana-promo-' . $cle,
            esc_html( $def['label'] ),
            'techanaRevuePubChampPromoCase',
            TECHANA_PUB_PAGE,
            'techana-pub-promo',
            array( 'cle' => $cle, 'label_for' => 'techana-promo-' . $cle )
        );
    }
    foreach ( techanaRevuePromoChamps() as $cle => $def ) {
        add_settings_field(
            'techana-' . $cle,
            esc_html( $def['label'] ),
            'techanaRevuePubChampPromoTexte',
            TECHANA_PUB_PAGE,
            'techana-pub-promo',
            array( 'cle' => $cle, 'label_for' => 'techana-' . $cle )
        );
    }
}

function techanaRevuePubIntroPromo() {
    echo '<p>Quand un emplacement est allumé mais qu’aucun encart n’est disponible, '
        . 'il peut proposer l’espace aux visiteurs au lieu de rester vide. '
        . '<strong>Un encart réel reprend toujours la place</strong> : la proposition '
        . 'disparaît d’elle-même dès qu’une campagne est en ligne, sans rien décocher. '
        . 'Ce bloc ne porte pas la mention « Publicité » — ce n’en est pas une.</p>';
}

/**
 * @param array $args Contient la clé de l'emplacement.
 */
function techanaRevuePubChampPromoCase( array $args ) {
    $cle      = $args['cle'];
    $reglages = techanaRevueReglagesPub();
    printf(
        '<label><input type="checkbox" id="techana-promo-%s" name="%s[promo_%s_actif]" value="1"%s /> %s</label>',
        esc_attr( $cle ),
        esc_attr( TECHANA_PUB_OPTION ),
        esc_attr( $cle ),
        checked( $reglages[ 'promo_' . $cle . '_actif' ], true, false ),
        'Proposer l’espace ici quand il est vide'
    );
}

/**
 * @param array $args Contient la clé du champ.
 */
function techanaRevuePubChampPromoTexte( array $args ) {
    $cle      = $args['cle'];
    $def      = techanaRevuePromoChamps()[ $cle ];
    $reglages = techanaRevueReglagesPub();
    $large    = 'promo_texte' === $cle;
    printf(
        '<input type="%s" id="techana-%s" name="%s[%s]" value="%s" class="%s" />',
        'promo_lien' === $cle ? 'url' : 'text',
        esc_attr( $cle ),
        esc_attr( TECHANA_PUB_OPTION ),
        esc_attr( $cle ),
        esc_attr( $reglages[ $cle ] ),
        $large ? 'large-text' : 'regular-text'
    );
    printf( '<p class="description">%s</p>', esc_html( $def['aide'] ) );
}

function techanaRevuePubIntroEmplacements() {
    printf(
        '<p>Chaque emplacement s’allume et s’éteint séparément, sans toucher aux encarts : '
            . 'les éteindre tous retire la publicité du site en gardant tout le reste. '
            . 'Le contenu, lui, se règle dans <a href="%s">Encarts</a> — un encart par '
            . 'annonceur, ciblé sur les rubriques de votre choix.</p>',
        esc_url( admin_url( 'edit.php?post_type=' . TECHANA_ENCART_TYPE ) )
    );
}

/**
 * @param array $args Contient la clé de l'emplacement.
 */
function techanaRevuePubChampCase( array $args ) {
    $cle      = $args['cle'];
    $def      = techanaRevueEncartEmplacements()[ $cle ];
    $reglages = techanaRevueReglagesPub();
    printf(
        '<label><input type="checkbox" id="techana-pub-%s" name="%s[%s_actif]" value="1"%s /> %s</label>',
        esc_attr( $cle ),
        esc_attr( TECHANA_PUB_OPTION ),
        esc_attr( $cle ),
        checked( $reglages[ $cle . '_actif' ], true, false ),
        'Diffuser à cet emplacement'
    );
    printf( '<p class="description">%s</p>', esc_html( $def['aide'] ) );
}

function techanaRevuePubIntroPitch() {
    $page = get_page_by_path( 'publier-chez-nous' );
    printf(
        '<p>L’encart des colonnes latérales qui appelle à proposer un article. Son bouton '
            . 'mène à <code>/publier-chez-nous/</code> : %s</p>',
        $page && 'publish' === $page->post_status
            ? 'cette page existe et est publiée.'
            : '<strong>cette page n’existe pas ou n’est pas publiée</strong> — le bouton mènerait '
                . 'vers une erreur 404, d’où l’encart éteint.'
    );
}

function techanaRevuePubChampPitch() {
    $reglages = techanaRevueReglagesPub();
    printf(
        '<label><input type="checkbox" id="techana-pitch-actif" name="%s[pitch_actif]" value="1"%s /> %s</label>',
        esc_attr( TECHANA_PUB_OPTION ),
        checked( $reglages['pitch_actif'], true, false ),
        'Afficher l’encart dans les colonnes latérales'
    );
}

function techanaRevuePubChampParagraphes() {
    $reglages = techanaRevueReglagesPub();
    printf(
        '<input type="number" id="techana-pub-paragraphes" name="%s[paragraphes]" value="%d" min="1" max="20" step="1" class="small-text" />',
        esc_attr( TECHANA_PUB_OPTION ),
        (int) $reglages['paragraphes']
    );
    echo '<p class="description">L’encart « dans le corps » se place après ce nombre de '
        . 'paragraphes. Un article plus court que ce seuil n’en reçoit aucun.</p>';
}

function techanaRevuePubMenu() {
    add_theme_page(
        'Publicité',
        'Publicité',
        'edit_theme_options',
        TECHANA_PUB_PAGE,
        'techanaRevuePubPage'
    );
}

function techanaRevuePubPage() {
    if ( ! current_user_can( 'edit_theme_options' ) ) {
        wp_die( 'Accès refusé.' );
    }
    echo '<div class="wrap"><h1>Publicité</h1><form action="options.php" method="post">';
    settings_fields( TECHANA_PUB_OPTION );
    do_settings_sections( TECHANA_PUB_PAGE );
    submit_button();
    echo '</form></div>';
}
