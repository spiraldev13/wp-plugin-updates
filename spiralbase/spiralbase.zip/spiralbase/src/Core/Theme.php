<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Point d'entrée du noyau spiralbase.
 *
 * Le noyau ne contient aucune logique métier (AD-1) : il câble le registre
 * et le service Options, puis démarre les modules actifs. Les modules du
 * parent s'enregistreront ici, un par un, au fil des epics — il n'y a pas
 * de fenêtre d'enregistrement externe : le thème enfant est design-only
 * (AD-5), aucun code tiers n'enregistre de module.
 */
final class Theme
{
    private static ?Registry $registry = null;

    private static ?Options $options = null;

    private static ?Walker $walker = null;

    private static ?RecipeStore $recipeStore = null;

    private static ?DonneesMetier $donneesMetier = null;

    private static ?Profils $profils = null;

    public static function boot(): void
    {
        add_action('after_setup_theme', [self::class, 'setup']);
    }

    public static function setup(): void
    {
        /* Idempotent : un hook déclenché deux fois ne reconstruit pas le noyau. */
        if (self::$registry !== null) {
            return;
        }

        load_theme_textdomain('spiralbase', get_template_directory() . '/languages');

        /* Opt-in : pose le hook de résumé si SPIRALBASE_PROFILE est vrai.
           Les sections du noyau (registre, walker, updater) s'instrumentent
           elles-mêmes via Profiler::start()/stop(). */
        Profiler::init();

        self::$options = new Options();

        /*
         * Profils métier (AD-14) : le registre reste l'unique PROPRIÉTAIRE de
         * l'état d'activation ; le profil n'en est que le fournisseur de
         * DÉFAUT, pour les modules qu'aucun humain n'a tranchés.
         */
        self::$profils  = new Profils(get_template_directory() . '/profiles');
        self::$registry = new Registry(self::$options, self::$profils);

        /*
         * Le walker existe AVANT le boot des modules : ils déclarent leurs
         * opérations dans leur boot(). L'option des règles est en lecture
         * seule ici — son écriture arrivera par le tableau de bord (6.4).
         */
        $regles       = get_option(ContentRules::OPTION, []);
        $contentRules = new ContentRules(
            is_array($regles) ? $regles : [],
            static function (int $postId): array {
                $categories = wp_get_post_categories($postId);

                /* WP_Error (taxonomie invalide) : aucune catégorie, jamais d'exclusion fantôme. */
                return is_wp_error($categories) ? [] : (array) $categories;
            }
        );
        self::$walker = new Walker($contentRules);

        /*
         * L'UNIQUE add_filter('the_content') de tout le parent (AD-10).
         * Borné à la boucle principale : widgets, extraits et constructeurs
         * qui appliquent the_content hors boucle ne reçoivent ni sommaire
         * ni encarts — et get_post() y désignerait parfois un autre post.
         */
        add_filter('the_content', static function ($content): string {
            $post = get_post();

            /* Boucle principale SINGULIÈRE : les enrichissements du walker
               (sommaire, encarts, fil d'Ariane) n'ont de sens que sur un
               contenu affiché seul — la garde rend le contrat mécanique
               (revue 2.2 : WP_User et page des articles passaient en
               contexte classique). */
            if (!is_string($content) || $post === null || !in_the_loop() || !is_main_query() || !is_singular()) {
                return is_string($content) ? $content : '';
            }

            return self::walker()->process($content, $post);
        }, 20);

        self::$recipeStore = new RecipeStore(
            new RecipeValidator(),
            new Archetypes(get_template_directory() . '/archetypes')
        );

        if (defined('WP_CLI') && WP_CLI) {
            \WP_CLI::add_command('spiralbase recipe', new Cli\RecipeCommand(self::$recipeStore));
            \WP_CLI::add_command('spiralbase formulaire', new Cli\FormulaireCommand(self::$options));
            \WP_CLI::add_command('spiralbase profil', new Cli\ProfilCommand(self::$profils, self::$registry));
            \WP_CLI::add_command('spiralbase module', new Cli\ModuleCommand(self::$registry));
        }

        /*
         * Updater de flotte : indexé sur get_template() — les sites tournent
         * sur thème enfant, la mise à jour vise TOUJOURS le parent (AD-13).
         * Version lue dans le style.css du parent.
         */
        $updater = new Updater(
            Updater::TYPE_THEME,
            get_template(),
            (string) wp_get_theme(get_template())->get('Version'),
            Updater::urlManifestePourSlug(get_template())
        );
        $updater->enregistrer();

        /*
         * Modules du parent — injection stricte des services du noyau (AD-4).
         * L'enregistrement est gardé : une déclaration fautive d'un module ne
         * doit pas écrouler tout le site depuis after_setup_theme.
         */
        self::$donneesMetier = new DonneesMetier();

        $modules = [
            new \SpiralBase\Modules\SiteHealth\SiteHealthModule(self::$registry, $updater, self::$walker),
            new \SpiralBase\Modules\Opengraph\OpengraphModule(self::$options),
            new \SpiralBase\Modules\SitemapXml\SitemapXmlModule(),
            new \SpiralBase\Modules\Breadcrumbs\BreadcrumbsModule(self::$walker),
            new \SpiralBase\Modules\SchemaMetier\SchemaMetierModule(self::$donneesMetier),
            new \SpiralBase\Modules\PerfWebp\PerfWebpModule(),
            new \SpiralBase\Modules\PerfLazyLoading\PerfLazyLoadingModule(),
            new \SpiralBase\Modules\PerfFontsLocales\PerfFontsLocalesModule(),
            new \SpiralBase\Modules\RgpdConsentement\RgpdConsentementModule(self::$options),
            new \SpiralBase\Modules\RgpdPagesLegales\RgpdPagesLegalesModule(self::$donneesMetier),
            new \SpiralBase\Modules\DecoupageParagraphes\DecoupageParagraphesModule(self::$walker, self::$options),
            new \SpiralBase\Modules\SommaireAuto\SommaireAutoModule(self::$walker, self::$options),
            new \SpiralBase\Modules\RelatedPostsInline\RelatedPostsInlineModule(self::$walker, self::$options),
            new \SpiralBase\Modules\MaillageInterne\MaillageInterneModule(self::$walker, self::$options),
            new \SpiralBase\Modules\PageSitemapHtml\PageSitemapHtmlModule(self::$options),
            new \SpiralBase\Modules\DuplicationDePage\DuplicationDePageModule(),
            new \SpiralBase\Modules\BlocHoraires\BlocHorairesModule(self::$donneesMetier),
            new \SpiralBase\Modules\BlocCoordonnees\BlocCoordonneesModule(self::$donneesMetier),
            new \SpiralBase\Modules\BlocMenu\BlocMenuModule(),
            new \SpiralBase\Modules\BlocAvisGoogle\BlocAvisGoogleModule(self::$options),
            new \SpiralBase\Modules\BlocRdv\BlocRdvModule(self::$options),
            new \SpiralBase\Modules\BlocCarrousel\BlocCarrouselModule(),
            new \SpiralBase\Modules\BlocEncartEvenement\BlocEncartEvenementModule(),
            new \SpiralBase\Modules\BlocSelectionEditoriale\BlocSelectionEditorialeModule(self::$options),
            new \SpiralBase\Modules\FormulaireContact\FormulaireContactModule(self::$options),
        ];

        foreach ($modules as $module) {
            try {
                self::$registry->register($module);
            } catch (\Throwable $e) {
                error_log(sprintf('[spiralbase] module « %s » non enregistré : %s', $module->slug(), $e->getMessage()));
            }
        }

        /*
         * Les MESSAGES REÇUS survivent au module qui les a créés.
         *
         * Le type de contenu était déclaré dans `boot()` : dès que Contact
         * Form 7 était activé — la cession que la sonde est faite pour
         * honorer — ou que l'interrupteur passait OFF, le type cessait
         * d'exister et l'historique des demandes clients disparaissait de
         * l'interface, tout en restant en base. Un module éteint ne laisse
         * aucune trace ACTIVE (AD-3) ; il n'emporte pas les archives avec lui.
         */
        add_action('init', static function (): void {
            $messages = new \SpiralBase\Modules\FormulaireContact\Messages();
            $messages->declarer();
            $messages->brancherEcranAdmin();
        });

        self::$registry->bootActive();
    }

    public static function recipeStore(): RecipeStore
    {
        return self::$recipeStore ?? throw self::noyauNonDemarre();
    }

    public static function walker(): Walker
    {
        return self::$walker ?? throw self::noyauNonDemarre();
    }

    public static function registry(): Registry
    {
        return self::$registry ?? throw self::noyauNonDemarre();
    }

    public static function options(): Options
    {
        return self::$options ?? throw self::noyauNonDemarre();
    }

    /** Porte UNIQUE des données métier (AD-2) — source unique, zéro duplication. */
    public static function donneesMetier(): DonneesMetier
    {
        return self::$donneesMetier ?? throw self::noyauNonDemarre();
    }

    /** Profils métier (AD-14) — fournisseur de défauts, jamais propriétaire d'un état. */
    public static function profils(): Profils
    {
        return self::$profils ?? throw self::noyauNonDemarre();
    }

    private static function noyauNonDemarre(): RegistryException
    {
        return new RegistryException(
            'Le noyau n\'a pas démarré — after_setup_theme n\'est pas encore passé, '
            . 'ou un garde-fou du bootstrap l\'a interrompu (planchers WP/PHP, noyau introuvable).'
        );
    }
}
