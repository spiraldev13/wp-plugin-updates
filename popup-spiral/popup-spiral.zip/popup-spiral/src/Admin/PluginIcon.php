<?php

namespace Spiral\Admin;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Icône de l'extension dans l'admin : écran Mises à jour et liste Extensions.
 *
 * L'updater (template makedev, régénérable) n'est pas modifié : l'icône est
 * ajoutée à la lecture du cache de mises à jour, quel que soit son contenu.
 */
final class PluginIcon
{
    private const ICON = 'assets/img/icon.svg';

    public static function register(): void
    {
        add_filter('site_transient_update_plugins', [self::class, 'addUpdateIcon']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueueListIcon']);
    }

    /**
     * @param mixed $transient
     * @return mixed
     */
    public static function addUpdateIcon($transient)
    {
        if (!is_object($transient)) {
            return $transient;
        }

        $basename = plugin_basename(SPIRAL_POPUP_FILE);

        foreach (['response', 'no_update'] as $list) {
            if (isset($transient->{$list}[$basename]) && is_object($transient->{$list}[$basename])) {
                $transient->{$list}[$basename]->icons = ['svg' => self::iconUrl()];
            }
        }

        return $transient;
    }

    /**
     * La liste Extensions ne prévoit aucune icône : ajout en CSS, sur notre ligne seulement.
     */
    public static function enqueueListIcon(string $hook): void
    {
        if ($hook !== 'plugins.php') {
            return;
        }

        $selector = sprintf('tr[data-plugin="%s"] .plugin-title strong', esc_attr(plugin_basename(SPIRAL_POPUP_FILE)));
        $css = $selector . '::before {'
            . 'content: ""; display: inline-block; width: 20px; height: 20px;'
            . 'margin: 0 6px 0 0; vertical-align: -4px; background: url("' . esc_url(self::iconUrl()) . '") center / contain no-repeat;'
            . '}';

        wp_register_style('spiral-plugin-icon', false, [], null);
        wp_enqueue_style('spiral-plugin-icon');
        wp_add_inline_style('spiral-plugin-icon', $css);
    }

    private static function iconUrl(): string
    {
        $version = (string) filemtime(SPIRAL_POPUP_DIR . self::ICON);

        return SPIRAL_POPUP_URL . self::ICON . '?ver=' . $version;
    }
}
