# Leçons apprises

> Ce fichier est géré par Claude Code.
> Après chaque correction de l'utilisateur, Claude ajoute le pattern ici et relit ce fichier en début de session.
> Objectif : ne jamais faire deux fois la même erreur sur ce projet.

---

## Comment utiliser ce fichier

Claude lit ce fichier au début de chaque session.
Quand l'utilisateur corrige une erreur, Claude ajoute une entrée ici :

```markdown
### YYYY-MM-DD — [Titre court de l'erreur]
**Ce qui s'est passé :** [Description de l'erreur]
**Cause racine :** [Pourquoi c'est arrivé]
**Règle à suivre désormais :** [La règle spécifique pour éviter que ça se reproduise]
```

---

## Leçons

<!-- Claude ajoute des entrées ici au fil du temps -->

_Aucune leçon enregistrée pour l'instant. Ce fichier va grandir au fur et à mesure que le projet évolue._
