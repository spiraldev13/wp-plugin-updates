<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Walker de contenu — unique propriétaire de `the_content` (AD-10).
 *
 * Trois phases fixes : analyse (le noyau calcule le contexte UNE fois),
 * transformations, insertions à points nommés. L'ordre intra-phase est
 * arbitré ici : priorité croissante puis FIFO. Les positions d'insertion
 * sont résolues sur le contenu courant (post-transformations), toutes en
 * UNE passe sur une copie masquée (commentaires/scripts neutralisés), puis
 * appliquées du plus grand offset au plus petit : les fragments insérés ne
 * décalent jamais les cibles des autres. Le contexte passé aux callables
 * reste celui de l'analyse — contrat figé.
 */
final class Walker
{
    public const POINT_DEBUT = 'debut_contenu';
    public const POINT_FIN = 'fin_contenu';
    public const POINT_APRES_PARAGRAPHE = 'apres_paragraphe';
    public const POINT_AVANT_HEADING = 'avant_heading';

    private const POINTS = [
        self::POINT_DEBUT,
        self::POINT_FIN,
        self::POINT_APRES_PARAGRAPHE,
        self::POINT_AVANT_HEADING,
    ];

    private const FERMETURE_P = '~</p\s*>~i';
    private const OUVERTURE_HEADING = '~<h[1-6][\s/>]~i';
    private const ZONES_INERTES = '~<!--.*?-->|<script\b[^>]*>.*?</script>~is';

    /** @var array<string, array{operation: \Closure, priorite: int, ordre: int}> */
    private array $transformations = [];

    /** @var array<string, array{operation: \Closure, point: string, index: int, priorite: int, ordre: int}> */
    private array $insertions = [];

    /**
     * Échecs de la dernière passe (slug => message). Chaque échec est aussi
     * signalé hors requête : `do_action('spiralbase_walker_echec')` +
     * `error_log` sous WP_DEBUG — jamais d'échec silencieux (NFR13), jamais
     * de fatal sur the_content. L'exposition persistante arrive en 6.4.
     *
     * @var array<string, string>
     */
    private array $echecs = [];

    private int $sequence = 0;

    public function __construct(private readonly ContentRules $rules)
    {
    }

    /** @param callable(string, array): string $transformation */
    public function addTransformation(string $slug, callable $transformation, int $priorite = 10): void
    {
        $this->exigerSlugLibre($slug);

        $this->transformations[$slug] = [
            'operation' => $transformation(...),
            'priorite'  => $priorite,
            'ordre'     => $this->sequence++,
        ];
    }

    /** @param callable(array): string $rendu rend le HTML à insérer au point nommé */
    public function addInsertion(string $slug, string $point, callable $rendu, int $index = 1, int $priorite = 10): void
    {
        $this->exigerSlugLibre($slug);

        if (!in_array($point, self::POINTS, true)) {
            throw new RegistryException(sprintf(
                'Point d\'insertion inconnu : « %s » (points nommés : %s).',
                $point,
                implode(', ', self::POINTS)
            ));
        }

        if ($index < 1) {
            throw new RegistryException(sprintf('Insertion « %s » : index 1-based attendu (%d reçu).', $slug, $index));
        }

        if ($index !== 1 && in_array($point, [self::POINT_DEBUT, self::POINT_FIN], true)) {
            throw new RegistryException(sprintf(
                'Insertion « %s » : l\'index n\'a pas de sens pour %s — le laisser à 1.',
                $slug,
                $point
            ));
        }

        $this->insertions[$slug] = [
            'operation' => $rendu(...),
            'point'     => $point,
            'index'     => $index,
            'priorite'  => $priorite,
            'ordre'     => $this->sequence++,
        ];
    }

    /**
     * Point d'entrée unique de `the_content` — aucun chemin ne peut
     * fataliser la page.
     *
     * CONTRAT contexte/offsets (tranché en 2.7, différé 2.6) : le CONTEXTE
     * (headings, ancres, compte de paragraphes) est calculé sur le contenu
     * D'ORIGINE, AVANT les transformations ; les OFFSETS d'insertion
     * (`apres_paragraphe N`, `avant_heading N`) sont résolus sur le contenu
     * TRANSFORMÉ. « Après le paragraphe N » compte donc les unités APRÈS
     * découpage (2.6) — comportement voulu (insérer entre des unités
     * courtes) ; aucune transformation du parent ne crée ni ne supprime d'OUVREUR
     * de heading (poser un id ne change pas le match), `avant_heading`
     * est stable. Testé :
     * RelatedPostsInlineModuleTest::testContratTask0DecoupagePlusInsertions.
     */
    public function process(string $content, object $post): string
    {
        $this->echecs = [];

        if ($content === '' || ($this->transformations === [] && $this->insertions === [])) {
            return $content;
        }

        try {
            if (!$this->rules->appliesTo($post)) {
                return $content;
            }
        } catch (\Throwable $e) {
            $this->signaler('content_rules', 'évaluation des règles : ' . $e->getMessage());

            return $content;
        }

        $chrono = Profiler::start('walker.contenu');

        try {
            $chronoAnalyse = Profiler::start('walker.analyse');
            $contexte      = $this->analyser($content);
            Profiler::stop('walker.analyse', $chronoAnalyse, ['taille' => strlen($content)]);
        } catch (\Throwable $e) {
            $this->signaler('analyse', 'analyse du contenu : ' . $e->getMessage());

            return $content;
        }

        foreach ($this->parOrdreArbitre($this->transformations) as $slug => $op) {
            try {
                $resultat = ($op['operation'])($content, $contexte);

                if (!is_string($resultat)) {
                    $this->signaler($slug, sprintf('transformation : retour hors contrat (%s reçu, string attendue)', get_debug_type($resultat)));

                    continue;
                }

                if ($resultat === '' && $content !== '') {
                    $this->signaler($slug, 'transformation : contenu intégralement effacé — retour ignoré');

                    continue;
                }

                $content = $resultat;
            } catch (\Throwable $e) {
                $this->signaler($slug, 'transformation : ' . $e->getMessage());
            }
        }

        $content = $this->appliquerInsertions($content, $contexte);

        Profiler::stop('walker.contenu', $chrono, ['operations' => count($this->transformations) + count($this->insertions)]);

        return $content;
    }

    /**
     * Phase d'analyse — contrat de contexte FIGÉ :
     * `{paragraphes: int, headings: list<{niveau, texte, ancre}>, ancres: list<string>}`.
     *
     * Deux chemins, même sortie (parité vérifiée par `bin/verifier-parite.php`
     * sur le WordPress réel) : flux de tokens WP_HTML_Tag_Processor en
     * production, fallback (zones inertes retirées, comptage `</p>`, regex
     * headings avec entités décodées) hors WordPress.
     *
     * @return array{paragraphes: int, headings: list<array{niveau: int, texte: string, ancre: ?string}>, ancres: list<string>}
     */
    public function analyser(string $html): array
    {
        return class_exists('WP_HTML_Tag_Processor')
            ? $this->analyserParTokens($html)
            : $this->analyserParRepli($html);
    }

    /** @return array<string, string> slug => message, depuis la dernière passe */
    public function derniersEchecs(): array
    {
        return $this->echecs;
    }

    /** @return array{paragraphes: int, headings: list<array{niveau: int, texte: string, ancre: ?string}>, ancres: list<string>} */
    private function analyserParTokens(string $html): array
    {
        $processor   = new \WP_HTML_Tag_Processor($html);
        $paragraphes = 0;
        $headings    = [];
        $enCours     = null;
        $texte       = '';

        while ($processor->next_token()) {
            $type = $processor->get_token_type();

            if ($type === '#tag') {
                $tag = (string) $processor->get_tag();

                if ($tag === 'P') {
                    /* Un heading jamais fermé ne doit pas aspirer les paragraphes. */
                    if (!$processor->is_tag_closer()) {
                        $enCours = null;
                    } elseif ($enCours === null) {
                        $paragraphes++;
                    }

                    continue;
                }

                if (preg_match('/^H([1-6])$/', $tag, $m)) {
                    if (!$processor->is_tag_closer()) {
                        $enCours = ['niveau' => (int) $m[1], 'ancre' => $processor->get_attribute('id')];
                        $texte   = '';
                    } elseif ($enCours !== null) {
                        $headings[] = [
                            'niveau' => $enCours['niveau'],
                            'texte'  => trim($texte),
                            'ancre'  => is_string($enCours['ancre']) && $enCours['ancre'] !== '' ? $enCours['ancre'] : null,
                        ];
                        $enCours = null;
                    }
                }

                continue;
            }

            if ($type === '#text' && $enCours !== null) {
                $texte .= $processor->get_modifiable_text();
            }
        }

        return $this->contexte($paragraphes, $headings);
    }

    /** @return array{paragraphes: int, headings: list<array{niveau: int, texte: string, ancre: ?string}>, ancres: list<string>} */
    private function analyserParRepli(string $html): array
    {
        /* Les zones inertes (commentaires, scripts) ne comptent pas — comme pour le tokenizer. */
        $html = (string) preg_replace(self::ZONES_INERTES, '', $html);

        $paragraphes = preg_match_all(self::FERMETURE_P, $html);
        $headings    = [];

        if (preg_match_all('~<h([1-6])([^>]*)>(.*?)</h\1\s*>~is', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $ancre = $this->ancreDansAttributs($m[2]);

                $headings[] = [
                    'niveau' => (int) $m[1],
                    'texte'  => trim(html_entity_decode(strip_tags($m[3]), ENT_QUOTES | ENT_HTML5)),
                    'ancre'  => is_string($ancre) && $ancre !== '' ? $ancre : null,
                ];
            }
        }

        return $this->contexte((int) $paragraphes, $headings);
    }

    /**
     * Un « id = » DANS une valeur d'attribut (title="mon id = 1") n'est pas
     * un id : les valeurs quotées sont masquées à longueur constante avant
     * de chercher l'attribut, puis la valeur est relue à sa position dans
     * la chaîne originale — même logique que le garde de pose du sommaire.
     */
    private function ancreDansAttributs(string $attrs): ?string
    {
        /* Masque non-blanc à longueur constante : un blanc laisserait le
           \s* du motif avaler le masque et décaler la lecture de la valeur. */
        $masque = (string) preg_replace_callback(
            '/"[^"]*"|\'[^\']*\'/',
            static fn (array $v): string => str_repeat("\x1F", strlen($v[0])),
            $attrs
        );

        if (!preg_match('/(?:^|\s)id\s*=\s*/i', $masque, $m, PREG_OFFSET_CAPTURE)) {
            return null;
        }

        $valeur = substr($attrs, $m[0][1] + strlen($m[0][0]));

        if (preg_match('/\A(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/', $valeur, $v)) {
            return $v[1] !== '' ? $v[1] : (($v[2] ?? '') !== '' ? $v[2] : ($v[3] ?? null));
        }

        return null;
    }

    /**
     * @param list<array{niveau: int, texte: string, ancre: ?string}> $headings
     *
     * @return array{paragraphes: int, headings: list<array{niveau: int, texte: string, ancre: ?string}>, ancres: list<string>}
     */
    private function contexte(int $paragraphes, array $headings): array
    {
        return [
            'paragraphes' => $paragraphes,
            'headings'    => $headings,
            'ancres'      => array_values(array_filter(array_column($headings, 'ancre'), 'is_string')),
        ];
    }

    /**
     * Résout TOUS les offsets d'abord (sur une copie masquée : les `</p>`
     * d'un commentaire, d'un script ou d'un fragment déjà inséré ne sont
     * jamais des cibles), puis insère du plus grand offset au plus petit.
     * À offset égal, l'opération arbitrée première apparaît première dans
     * le document — quel que soit le point.
     *
     * @param array{paragraphes: int, headings: list<array{niveau: int, texte: string, ancre: ?string}>, ancres: list<string>} $contexte
     */
    private function appliquerInsertions(string $content, array $contexte): string
    {
        if ($this->insertions === []) {
            return $content;
        }

        $masque   = $this->masquerZonesInertes($content);
        $resolues = [];
        $rang     = 0;

        foreach ($this->parOrdreArbitre($this->insertions) as $slug => $op) {
            try {
                $fragment = ($op['operation'])($contexte);
            } catch (\Throwable $e) {
                $this->signaler($slug, 'insertion : ' . $e->getMessage());

                continue;
            }

            if (!is_string($fragment)) {
                $this->signaler($slug, sprintf('insertion : retour hors contrat (%s reçu, string attendue)', get_debug_type($fragment)));

                continue;
            }

            $resolues[] = [
                'offset'   => $this->resoudreOffset($masque, $op['point'], $op['index']),
                'fragment' => $fragment,
                'rang'     => $rang++,
            ];
        }

        /* Plus grand offset d'abord ; à offset égal, dernier rang d'abord
           (ainsi le premier rang finit le plus à gauche dans le document). */
        usort($resolues, static fn (array $a, array $b): int => [$b['offset'], $b['rang']] <=> [$a['offset'], $a['rang']]);

        foreach ($resolues as $insertion) {
            $content = substr($content, 0, $insertion['offset'])
                . $insertion['fragment']
                . substr($content, $insertion['offset']);
        }

        return $content;
    }

    /** Repli documenté : cible introuvable ou hors bornes → fin de contenu. */
    private function resoudreOffset(string $masque, string $point, int $index): int
    {
        if ($point === self::POINT_DEBUT) {
            return 0;
        }

        if ($point === self::POINT_APRES_PARAGRAPHE) {
            $n = preg_match_all(self::FERMETURE_P, $masque, $m, PREG_OFFSET_CAPTURE);

            if ($n !== false && $n >= $index) {
                return $m[0][$index - 1][1] + strlen($m[0][$index - 1][0]);
            }

            return strlen($masque);
        }

        if ($point === self::POINT_AVANT_HEADING) {
            $n = preg_match_all(self::OUVERTURE_HEADING, $masque, $m, PREG_OFFSET_CAPTURE);

            if ($n !== false && $n >= $index) {
                return $m[0][$index - 1][1];
            }

            return strlen($masque);
        }

        return strlen($masque);
    }

    /**
     * Remplace commentaires et scripts par des espaces — mêmes longueurs,
     * offsets préservés. PUBLIC depuis 2.7 : les transformations qui
     * repèrent des balises par regex DOIVENT travailler sur le contenu
     * masqué pour rester alignées avec l'analyse (qui ignore les zones
     * inertes) — revue 2.7, désalignement de rang prouvé sinon.
     */
    public function masquerZonesInertes(string $content): string
    {
        $masque = preg_replace_callback(
            self::ZONES_INERTES,
            static fn (array $m): string => str_repeat(' ', strlen($m[0])),
            $content
        );

        return is_string($masque) ? $masque : $content;
    }

    private function signaler(string $slug, string $message): void
    {
        $this->echecs[$slug] = $message;

        /* Signal hors requête : hook toujours, error_log sous WP_DEBUG. */
        do_action('spiralbase_walker_echec', $slug, $message);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf('[spiralbase] walker/%s : %s', $slug, $message));
        }
    }

    /**
     * @template T of array{priorite: int, ordre: int}
     *
     * @param array<string, T> $operations
     *
     * @return array<string, T> priorité croissante, FIFO à priorité égale
     */
    private function parOrdreArbitre(array $operations): array
    {
        uasort($operations, static fn (array $a, array $b): int => [$a['priorite'], $a['ordre']] <=> [$b['priorite'], $b['ordre']]);

        return $operations;
    }

    private function exigerSlugLibre(string $slug): void
    {
        if (isset($this->transformations[$slug]) || isset($this->insertions[$slug])) {
            throw new RegistryException(sprintf('Slug d\'opération de walker en doublon : « %s ».', $slug));
        }
    }
}
