<?php
/**
 * Head complet émis par le thème — spec seo-crawl.
 *
 * Ordre d'émission (integration-wordpress.md) : description, canonical,
 * favicon SVG, robots (via l'API wp_robots), Open Graph + twitter:card,
 * JSON-LD. Toutes les URL absolues passent par home_url()/get_permalink() —
 * jamais de domaine en dur. À la bascule en production, les modules head de
 * Rank Math doivent être coupés (il garde sitemap et redirections).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'wp_head', 'techanaRevueHead', 1 );
add_filter( 'wp_robots', 'techanaRevueRobots' );
add_action( 'template_redirect', 'techanaRevueFrontSansPagination' );
add_filter( 'pre_get_document_title', 'techanaRevueTitre', 20 );

/**
 * Titre de document de tous les gabarits. Sur pre_get_document_title en
 * priorité 20 pour passer après Rank Math — dont le titre SEO saisi à la main
 * (16 contenus) arrive dans $titre et n'est jamais écrasé ici.
 *
 * Trois corrections par rapport au titre reçu : les libellés d'archive
 * (« Archives des X », « X, auteur/autrice sur Y ») sont des intitulés
 * d'administration, la page de pagination est nommée (31 pages de
 * /publications/ portaient le même titre), et le nom du site ferme le titre.
 */
function techanaRevueTitre( string $titre ): string {
    $site = get_bloginfo( 'name' );

    // L'accueil est une page statique (« Home », requise pour découpler
    // /publications/) : son titre reste « nom du site — slogan », et sa
    // pagination part en 301 (techanaRevueFrontSansPagination).
    if ( is_front_page() ) {
        return $site . ' – ' . get_bloginfo( 'description' );
    }

    if ( is_category() ) {
        $titre = single_term_title( '', false );
    } elseif ( is_author() ) {
        $titre = (string) get_the_author_meta( 'display_name', get_queried_object_id() );
    } elseif ( is_search() ) {
        $titre = 'Recherche : ' . get_search_query();
    } elseif ( is_404() ) {
        $titre = 'Page introuvable';
    }

    $page = (int) get_query_var( 'paged' );
    if ( $page > 1 ) {
        $titre .= ' – Page ' . $page;
    }

    if ( ! str_contains( $titre, $site ) ) {
        $titre .= ' – ' . $site;
    }
    // pre_get_document_title court-circuite l'échappement de wp_get_document_title().
    return wp_strip_all_tags( $titre );
}
remove_action( 'wp_head', 'rel_canonical' );
// Le favicon du design (SVG en data-URI) remplace les icônes de site de WP.
add_filter( 'site_icon_meta_tags', '__return_empty_array' );
// Rank Math reste actif (sitemap, redirections, base de catégorie dépouillée)
// mais le head appartient au thème : toute sa sortie wp_head est retirée.
add_action( 'template_redirect', 'techanaRevueSilenceRankMathHead', 5 );

function techanaRevueSilenceRankMathHead() {
    if ( class_exists( 'RankMath' ) ) {
        remove_all_actions( 'rank_math/head' );
        remove_all_actions( 'rank_math/opengraph/facebook' );
        remove_all_actions( 'rank_math/opengraph/twitter' );
        // Rank Math vide tous les filtres wp_robots (le nôtre compris) au
        // profit du sien — silencié ci-dessus. On rebranche le nôtre pour le
        // noindex recherche/404.
        if ( ! has_action( 'wp_head', 'wp_robots' ) ) {
            add_action( 'wp_head', 'wp_robots', 1 );
        }
        add_filter( 'wp_robots', 'techanaRevueRobots' );
    }
}

/**
 * /page/N/ de l'accueil : l'écran n'a pas de pagination (design), servir un
 * duplicata indexable serait rejouer la cause racine n°1 — redirection 301.
 * La page des articles (/publications/), elle, pagine réellement : is_home()
 * n'est plus concerné depuis qu'elle est séparée de l'accueil.
 */
function techanaRevueFrontSansPagination() {
    if ( is_front_page() && is_paged() ) {
        wp_safe_redirect( home_url( '/' ), 301 );
        exit;
    }
}

/**
 * noindex,follow sur recherche et 404 uniquement — aucun autre gabarit du
 * thème n'émet de directive robots.
 */
function techanaRevueRobots( array $robots ): array {
    if ( is_search() || is_404() ) {
        $robots['noindex'] = true;
        $robots['follow']  = true;
    }
    return $robots;
}

/**
 * Description de la vue courante, tronquée à 185 caractères sur un mot.
 *
 * L'accueil et la page des articles sont des pages statiques : elles passent
 * donc par is_singular() si on ne les traite pas d'abord. Leur contenu ne
 * décrit pas le site (celui de l'accueil ne contenait qu'un conteneur vide
 * hérité de l'ancien constructeur, que l'extrait automatique recopiait tel
 * quel dans la balise) — description saisie, sinon le slogan, jamais l'extrait.
 */
function techanaRevueDescription(): string {
    $texte = '';
    if ( is_front_page() ) {
        $texte = techanaRevueResume( (int) get_option( 'page_on_front' ) );
        $texte = '' !== $texte ? $texte : get_bloginfo( 'description' );
    } elseif ( is_home() ) {
        $texte = techanaRevueResume( (int) get_option( 'page_for_posts' ) );
        $texte = '' !== $texte ? $texte : get_bloginfo( 'description' );
    } elseif ( is_singular() ) {
        // Même source que le chapô visible, extrait automatique en dernier
        // recours : une balise vide serait pire qu'une description imparfaite.
        $texte = techanaRevueResume( get_queried_object_id(), true );
    } elseif ( is_category() ) {
        $texte = wp_strip_all_tags( term_description() );
    } elseif ( is_author() ) {
        $texte = wp_strip_all_tags( get_the_author_meta( 'description', get_queried_object_id() ) );
    }
    $texte = trim( preg_replace( '/\s+/u', ' ', $texte ) );
    if ( mb_strlen( $texte ) > 185 ) {
        $coupe   = mb_substr( $texte, 0, 185 );
        $dernier = mb_strrpos( $coupe, ' ' );
        $texte   = rtrim( mb_substr( $coupe, 0, $dernier ? $dernier : 185 ), ' ,;:.' ) . '…';
    }
    // Sans cette mention, les 31 pages de /publications/ et les 18 pages de la
    // rubrique la plus fournie partagent une description au mot près.
    $page = (int) get_query_var( 'paged' );
    return $page > 1 && '' !== $texte ? $texte . ' – Page ' . $page : $texte;
}

/** Ajoute /page/N/ à une URL de liste quand la vue est paginée. */
function techanaRevuePagine( string $base ): string {
    $page = (int) get_query_var( 'paged' );
    return $page > 1 ? trailingslashit( $base ) . 'page/' . $page . '/' : $base;
}

/** URL canonique de la vue courante, pagination comprise. */
function techanaRevueCanonical(): string {
    if ( is_home() && ! is_front_page() ) {
        return techanaRevuePagine( (string) get_permalink( get_option( 'page_for_posts' ) ) );
    }
    if ( is_singular() ) {
        return (string) get_permalink();
    }
    // Test avant is_category() : get_term_link() reçoit sinon le WP_User de la
    // vue auteur et émet trois Warning en plein <head>.
    if ( is_author() ) {
        return techanaRevuePagine( get_author_posts_url( get_queried_object_id() ) );
    }
    if ( is_category() ) {
        $base = get_term_link( get_queried_object() );
        return is_wp_error( $base ) ? home_url( '/' ) : techanaRevuePagine( (string) $base );
    }
    return home_url( '/' );
}

/** Image de partage : image à la une, sinon le repli du thème (1200 × 630). */
function techanaRevueImagePartage(): string {
    if ( is_singular() && has_post_thumbnail() ) {
        $src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'techana-lead' );
        if ( $src ) {
            return $src[0];
        }
    }
    return get_theme_file_uri( 'assets/img/partage-accueil.jpg' );
}

/** Favicon : la marque du design en SVG, dans une URI de données. */
function techanaRevueFavicon(): string {
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">'
        . '<rect width="24" height="24" fill="#33373f"/>'
        . '<path d="M6.5 8.5L10 12l-3.5 3.5" stroke="#fcfcfd" stroke-width="2.1" stroke-linecap="square"/>'
        . '<path d="M12.5 15.6h5.5" stroke="#fcfcfd" stroke-width="2.1" stroke-linecap="square"/></svg>';
    return 'data:image/svg+xml,' . rawurlencode( $svg );
}

function techanaRevueHead() {
    $description = techanaRevueDescription();
    if ( $description ) {
        echo '<meta name="description" content="' . esc_attr( $description ) . '"/>' . "\n";
    }
    // Recherche et 404 sont en noindex : y déclarer l'accueil comme canonique
    // enverrait deux consignes contradictoires sur la même page. Aucune
    // canonique ne vaut mieux qu'une canonique fausse.
    if ( ! is_search() && ! is_404() ) {
        echo '<link rel="canonical" href="' . esc_url( techanaRevueCanonical() ) . '"/>' . "\n";
    }
    echo '<link rel="icon" type="image/svg+xml" href="' . esc_attr( techanaRevueFavicon() ) . '"/>' . "\n";

    if ( ! is_search() && ! is_404() ) {
        techanaRevueOpenGraph( $description );
        techanaRevueJsonLd( $description );
    }
}

function techanaRevueOpenGraph( string $description ) {
    $titre = wp_get_document_title();
    $type  = is_singular( 'post' ) ? 'article' : 'website';
    echo '<meta property="og:type" content="' . esc_attr( $type ) . '"/>' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '"/>' . "\n";
    echo '<meta property="og:title" content="' . esc_attr( $titre ) . '"/>' . "\n";
    if ( $description ) {
        echo '<meta property="og:description" content="' . esc_attr( $description ) . '"/>' . "\n";
    }
    echo '<meta property="og:url" content="' . esc_url( techanaRevueCanonical() ) . '"/>' . "\n";
    echo '<meta property="og:image" content="' . esc_url( techanaRevueImagePartage() ) . '"/>' . "\n";
    echo '<meta property="og:locale" content="fr_FR"/>' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image"/>' . "\n";
}

/**
 * L'éditeur, décrit une fois et référencé partout par son @id : le publisher
 * d'un article, l'éditeur du site et l'entité de marque doivent être la même
 * chose aux yeux d'un moteur. Le logo est un fichier du thème — schema.org
 * attend une URL d'image, le logo affiché est un SVG en ligne.
 */
function techanaRevueOrganisation(): array {
    return array(
        '@type' => 'Organization',
        '@id'   => home_url( '/#organisation' ),
        'name'  => get_bloginfo( 'name' ),
        'url'   => home_url( '/' ),
        'logo'  => array(
            '@type'  => 'ImageObject',
            'url'    => get_theme_file_uri( 'assets/img/logo-techana.png' ),
            'width'  => 512,
            'height' => 512,
        ),
    );
}

/**
 * Émet un bloc JSON-LD, slashes et unicode non échappés.
 *
 * Les entités HTML sont décodées d'abord : elles viennent des titres et du
 * slogan (« Tutoriels &amp; fiches ») et n'ont aucun sens dans du JSON, où
 * elles seraient lues à la lettre.
 */
function techanaRevueEmettreJsonLd( array $donnees ) {
    array_walk_recursive( $donnees, static function ( &$valeur ) {
        if ( is_string( $valeur ) ) {
            $valeur = html_entity_decode( $valeur, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        }
    } );
    // JSON_HEX_TAG/AMP : un titre décodé pourrait sinon refermer le <script>.
    echo '<script type="application/ld+json">'
        . wp_json_encode(
            $donnees,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
        )
        . '</script>' . "\n";
}

/** BreadcrumbList depuis le même chemin que le fil d'Ariane affiché. */
function techanaRevueJsonLdAriane(): ?array {
    $chemin = techanaRevueFilAriane();
    if ( count( $chemin ) < 2 ) {
        return null;
    }
    $items = array();
    foreach ( $chemin as $i => $etape ) {
        $item = array(
            '@type'    => 'ListItem',
            'position' => $i + 1,
            'name'     => $etape[0],
        );
        if ( '' !== $etape[1] ) {
            $item['item'] = $etape[1];
        }
        $items[] = $item;
    }
    return array(
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $items,
    );
}

/**
 * JSON-LD par gabarit — mêmes données que l'affichage (dates de la signature,
 * FAQ du bloc rendu, sponsor de la mention visible).
 */
function techanaRevueJsonLd( string $description ) {
    // L'entité du site n'est déclarée que sur l'accueil : la page des articles
    // est une collection parmi d'autres, pas une seconde définition du site.
    if ( is_front_page() ) {
        techanaRevueEmettreJsonLd( array(
            '@context'        => 'https://schema.org',
            '@type'           => 'WebSite',
            'name'            => get_bloginfo( 'name' ),
            'url'             => home_url( '/' ),
            'description'     => $description,
            'inLanguage'      => 'fr-FR',
            'publisher'       => array( '@id' => home_url( '/#organisation' ) ),
            'potentialAction' => array(
                '@type'       => 'SearchAction',
                'target'      => home_url( '/?s={search_term_string}' ),
                'query-input' => 'required name=search_term_string',
            ),
        ) );
        techanaRevueEmettreJsonLd(
            array( '@context' => 'https://schema.org' ) + techanaRevueOrganisation()
        );
        return;
    }

    $ariane = techanaRevueJsonLdAriane();

    if ( is_singular( 'post' ) ) {
        $postId  = get_the_ID();
        $auteurId = (int) get_post_field( 'post_author', $postId );
        $article = array(
            '@context'         => 'https://schema.org',
            '@type'            => 'Article',
            'headline'         => get_the_title(),
            'description'      => $description,
            'datePublished'    => get_the_date( 'c' ),
            'dateModified'     => get_the_modified_date( 'c' ),
            'mainEntityOfPage' => get_permalink(),
            'image'            => techanaRevueImagePartage(),
            'author'           => array(
                '@type' => 'Person',
                'name'  => get_the_author_meta( 'display_name', $auteurId ),
                'url'   => get_author_posts_url( $auteurId ),
            ),
            'publisher'        => techanaRevueOrganisation(),
            'inLanguage'       => 'fr-FR',
        );
        $annonceur = get_post_meta( $postId, '_techana_annonceur_nom', true );
        if ( get_post_meta( $postId, '_techana_sponsorise', true ) && $annonceur ) {
            $article['sponsor'] = array(
                '@type' => 'Organization',
                'name'  => $annonceur,
            );
        }
        techanaRevueEmettreJsonLd( $article );
        if ( $ariane ) {
            techanaRevueEmettreJsonLd( $ariane );
        }
        $faq = techanaRevueFaqAffichee( $postId );
        if ( $faq ) {
            techanaRevueEmettreJsonLd( array(
                '@context'   => 'https://schema.org',
                '@type'      => 'FAQPage',
                'mainEntity' => array_map( static function ( array $paire ): array {
                    return array(
                        '@type'          => 'Question',
                        'name'           => $paire['question'],
                        'acceptedAnswer' => array(
                            '@type' => 'Answer',
                            'text'  => $paire['reponse'],
                        ),
                    );
                }, $faq ),
            ) );
        }
        return;
    }

    if ( is_home() ) {
        techanaRevueEmettreJsonLd( array(
            '@context'    => 'https://schema.org',
            '@type'       => 'CollectionPage',
            'name'        => get_the_title( (int) get_option( 'page_for_posts' ) ),
            'description' => $description,
            'url'         => techanaRevueCanonical(),
        ) );
    } elseif ( is_category() ) {
        techanaRevueEmettreJsonLd( array(
            '@context'    => 'https://schema.org',
            '@type'       => 'CollectionPage',
            'name'        => single_term_title( '', false ),
            'description' => $description,
            'url'         => techanaRevueCanonical(),
        ) );
    } elseif ( is_author() ) {
        $auteur  = get_queried_object();
        $persone = array(
            '@type'       => 'Person',
            'name'        => $auteur->display_name,
            'description' => get_the_author_meta( 'description', $auteur->ID ),
            'url'         => get_author_posts_url( $auteur->ID ),
        );
        // Sans portrait dans la médiathèque, get_avatar_url() retombe sur
        // Gravatar : déclarer sa silhouette générique comme portrait de
        // l'auteur, c'est annoncer une image qui n'en est pas une.
        if ( techanaRevuePortraitId( (int) $auteur->ID ) ) {
            $persone['image'] = get_avatar_url( $auteur->ID, array( 'size' => 144 ) );
        }
        techanaRevueEmettreJsonLd( array(
            '@context'   => 'https://schema.org',
            '@type'      => 'ProfilePage',
            'url'        => techanaRevueCanonical(),
            'mainEntity' => $persone,
        ) );
    } elseif ( is_page() ) {
        techanaRevueEmettreJsonLd( array(
            '@context'    => 'https://schema.org',
            '@type'       => 'WebPage',
            'name'        => get_the_title(),
            'description' => $description,
            'url'         => get_permalink(),
        ) );
    }

    if ( $ariane ) {
        techanaRevueEmettreJsonLd( $ariane );
    }
}
