<?php
/**
 * 06 — Portfolio des réalisations (works).
 *
 * Visuel : en-tête (eyebrow + titre à gauche + bouton « Voir tout le portfolio »
 * à droite) puis grille bento (1 col mobile, 2 col tablette, 6 col desktop)
 * mélangeant des cartes en formats tall/wide/sq. Chaque carte affiche le visuel
 * en fond + overlay dégradé bas avec tag secteur, titre client et meta.
 *
 * Pilotage ACF (front-page) : works_eyebrow, works_title, works_url.
 * Cartes alimentées par le CPT `realisation` (champs ACF realisation_*).
 * Carte unitaire : template-parts/cards/carte-realisation.php
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow     = get_field('works_eyebrow') ?: __('Réalisations récentes', 'evolutionr');
$title       = get_field('works_title') ?: __('Des sites livrés. Des positions gagnées.', 'evolutionr');
// Le CTA « Voir tout le portfolio » n'est affiché QUE si une URL est
// explicitement renseignée en BO (champ ACF `works_url`). Pas de fallback
// vers une archive de CPT publique si elle n'existe pas — un CTA mort
// vaut moins qu'un CTA absent.
$portfolioUrl = (string) get_field('works_url');

$works = new WP_Query([
    'post_type'      => 'realisation',
    // -1 : pas de plafond — toutes les réalisations publiées s'affichent (5
    // aujourd'hui, davantage si Cyril en ajoute). L'ordre est piloté à la main
    // (glisser-déposer en admin → menu_order croissant ; à défaut, plus récent).
    'posts_per_page' => -1,
    'orderby'        => ['menu_order' => 'ASC', 'date' => 'DESC'],
    'no_found_rows'  => true,
]);

if (!$works->have_posts()) {
    return;
}
?>
<section class="section" id="works" aria-labelledby="works-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <h2 class="section-title" id="works-title"><?php echo esc_html($title); ?></h2>
            </div>
            <?php if ($portfolioUrl): ?>
                <a class="btn btn-ghost" href="<?php echo esc_url($portfolioUrl); ?>">
                    <span class="btn-inner">
                        <?php esc_html_e('Voir tout le portfolio', 'evolutionr'); ?>
                        <?php evolutionr_icon('arrow-up-right', 14); ?>
                    </span>
                </a>
            <?php endif; ?>
        </header>

        <div class="works-grid">
            <?php while ($works->have_posts()): $works->the_post();
                get_template_part('template-parts/cards/carte-realisation');
            endwhile;
            wp_reset_postdata(); ?>
        </div>
    </div>
</section>
