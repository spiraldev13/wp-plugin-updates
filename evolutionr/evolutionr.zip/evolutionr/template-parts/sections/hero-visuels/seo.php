<?php
/**
 * Motif hero « Consultant SEO » — courbe de positions + mots-clés qui montent.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Une courbe SVG ascendante (la position qui s'améliore) surmontant des barres
 * de mots-clés. viewBox + preserveAspectRatio → responsive 320px → desktop.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Mots-clés décoratifs : libellé + progression (%) de la barre.
$keywords = [
    ['name' => 'agence web',      'pos' => 92],
    ['name' => 'création site',   'pos' => 74],
    ['name' => 'seo local',       'pos' => 58],
];
?>
<div class="hvr">
    <div class="hvr-graph">
        <svg viewBox="0 0 100 40" preserveAspectRatio="none" focusable="false" aria-hidden="true">
            <polyline class="hvr-curve" pathLength="100" points="2,37 22,31 42,27 60,16 80,10 98,3" />
        </svg>
        <span class="hvr-badge"><span class="hvr-peak"></span> #1</span>
    </div>
    <div class="hvr-keywords">
        <?php foreach ($keywords as $i => $kw): ?>
            <div class="hvr-kw" style="--pos: <?php echo (int) $kw['pos']; ?>%; --i: <?php echo (int) $i; ?>;">
                <span class="hvr-kw-name"><?php echo esc_html($kw['name']); ?></span>
                <span class="hvr-kw-track"><span class="hvr-kw-fill"></span></span>
            </div>
        <?php endforeach; ?>
    </div>
</div>
