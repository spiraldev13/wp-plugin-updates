<?php
/**
 * Réglages de la une — écran « Apparence → Une de l'accueil ».
 *
 * Les volumes de chaque section de la page d'accueil vivent dans une option
 * unique ; aucun n'est codé ailleurs (inc/accueil.php et inc/blocs.php lisent
 * tous techanaRevueReglagesUne()). Le schéma ci-dessous est la seule source
 * des défauts, des bornes et des libellés : ajouter un volume = une entrée.
 *
 * La mosaïque fait exception et reste en lecture seule : sa grille CSS
 * (2fr 1fr 1fr sur deux rangées, première carte à cheval) vaut exactement
 * cinq cases — un autre nombre la laisserait trouée.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_UNE_OPTION = 'techana_une_reglages';
const TECHANA_UNE_PAGE   = 'techana-une';

add_action( 'admin_init', 'techanaRevueUneSettings' );
add_action( 'admin_menu', 'techanaRevueUneMenu' );

/**
 * Schéma des volumes : défaut, bornes, libellé et aide de chaque réglage.
 * `fige` marque les valeurs imposées par le design (affichées, non éditables).
 *
 * @return array<string, array>
 */
function techanaRevueUneSchema(): array {
    return array(
        'mosaique'  => array(
            'defaut' => 5,
            'min'    => 5,
            'max'    => 5,
            'fige'   => true,
            'label'  => 'Mosaïque de tête',
            'aide'   => 'Imposé par la grille du design : la première carte occupe deux rangées, les quatre autres complètent le damier.',
        ),
        'une'       => array(
            'defaut' => 20,
            'min'    => 0,
            'max'    => 40,
            'label'  => 'Section « À la une »',
            'aide'   => 'Articles listés sous la mosaïque, en deux colonnes. 0 retire la section.',
        ),
        'derniers'  => array(
            'defaut' => 12,
            'min'    => 0,
            'max'    => 24,
            'label'  => 'Section « Derniers articles »',
            'aide'   => 'Les plus récents, hors articles déjà affichés plus haut. 0 retire la section.',
        ),
        'rubriques' => array(
            'defaut' => 6,
            'min'    => 0,
            'max'    => 6,
            'label'  => 'Blocs de rubrique',
            'aide'   => 'Nombre de rubriques mises en avant, prises par volume d’articles. 6 maximum : au-delà il faut ajouter des sections dans l’éditeur de site.',
        ),
        'rub_liste' => array(
            'defaut' => 3,
            'min'    => 0,
            'max'    => 6,
            'label'  => 'Articles par bloc de rubrique',
            'aide'   => 'En plus de l’article mis en avant en tête de chaque bloc.',
        ),
        'ticker'    => array(
            'defaut' => 4,
            'min'    => 0,
            'max'    => 10,
            'label'  => 'Fil défilant',
            'aide'   => 'Titres du bandeau « À la une » en haut de page. 0 retire le bandeau.',
        ),
    );
}

/**
 * Volumes effectifs — défauts fusionnés avec l'option, valeurs figées forcées.
 *
 * @return array<string, int>
 */
function techanaRevueReglagesUne(): array {
    $schema  = techanaRevueUneSchema();
    $stockes = get_option( TECHANA_UNE_OPTION, array() );
    $stockes = is_array( $stockes ) ? $stockes : array();

    $reglages = array();
    foreach ( $schema as $cle => $def ) {
        $valeur = empty( $def['fige'] ) && isset( $stockes[ $cle ] )
            ? (int) $stockes[ $cle ]
            : $def['defaut'];
        $reglages[ $cle ] = max( $def['min'], min( $def['max'], $valeur ) );
    }
    return $reglages;
}

/**
 * Sanitisation : entiers bornés par le schéma, réglages figés jamais écrits.
 *
 * @param mixed $entree Valeurs postées.
 * @return array<string, int>
 */
function techanaRevueUneSanitize( $entree ): array {
    $entree = is_array( $entree ) ? $entree : array();
    $propre = array();
    foreach ( techanaRevueUneSchema() as $cle => $def ) {
        if ( ! empty( $def['fige'] ) || ! isset( $entree[ $cle ] ) ) {
            continue;
        }
        $propre[ $cle ] = max( $def['min'], min( $def['max'], (int) $entree[ $cle ] ) );
    }
    return $propre;
}

function techanaRevueUneSettings() {
    register_setting( TECHANA_UNE_OPTION, TECHANA_UNE_OPTION, array(
        'type'              => 'array',
        'sanitize_callback' => 'techanaRevueUneSanitize',
        'default'           => array(),
    ) );

    add_settings_section(
        'techana-une-volumes',
        'Volumes de la page d’accueil',
        'techanaRevueUneIntroSection',
        TECHANA_UNE_PAGE
    );

    foreach ( techanaRevueUneSchema() as $cle => $def ) {
        add_settings_field(
            'techana-une-' . $cle,
            esc_html( $def['label'] ),
            'techanaRevueUneChamp',
            TECHANA_UNE_PAGE,
            'techana-une-volumes',
            array( 'cle' => $cle, 'label_for' => 'techana-une-' . $cle )
        );
    }
}

function techanaRevueUneIntroSection() {
    echo '<p>Les articles cochés « Afficher à la une » remplissent d’abord la mosaïque, '
        . 'puis la section « À la une ». Les places restantes sont complétées automatiquement '
        . 'par les articles les plus récents — un même article n’apparaît jamais deux fois '
        . 'sur l’accueil.</p>';
}

/**
 * Champ nombre d'un volume ; les volumes figés s'affichent en lecture seule.
 *
 * @param array $args Contient la clé du schéma.
 */
function techanaRevueUneChamp( array $args ) {
    $cle       = $args['cle'];
    $def       = techanaRevueUneSchema()[ $cle ];
    $reglages  = techanaRevueReglagesUne();
    $id        = 'techana-une-' . $cle;

    if ( ! empty( $def['fige'] ) ) {
        printf(
            '<input type="number" id="%s" value="%d" class="small-text" disabled /> '
                . '<em>valeur imposée</em>',
            esc_attr( $id ),
            (int) $reglages[ $cle ]
        );
    } else {
        printf(
            '<input type="number" id="%s" name="%s[%s]" value="%d" min="%d" max="%d" step="1" class="small-text" />',
            esc_attr( $id ),
            esc_attr( TECHANA_UNE_OPTION ),
            esc_attr( $cle ),
            (int) $reglages[ $cle ],
            (int) $def['min'],
            (int) $def['max']
        );
    }
    printf( '<p class="description">%s</p>', esc_html( $def['aide'] ) );
}

function techanaRevueUneMenu() {
    add_theme_page(
        'Une de l’accueil',
        'Une de l’accueil',
        'edit_theme_options',
        TECHANA_UNE_PAGE,
        'techanaRevueUnePage'
    );
}

/**
 * Articles actuellement cochés « à la une », les plus récents d'abord.
 *
 * @return WP_Post[]
 */
function techanaRevueUneMarques(): array {
    return get_posts( array(
        'numberposts' => 50,
        'meta_key'    => '_techana_une',
        'meta_value'  => '1',
    ) );
}

/**
 * Récapitulatif des articles cochés — la contrepartie lisible de la case à
 * cocher de l'éditeur : sans lui, rien n'indique où en est la sélection.
 */
function techanaRevueUneRecap() {
    $marques = techanaRevueUneMarques();
    echo '<h2>Articles marqués à la une</h2>';
    if ( ! $marques ) {
        echo '<p>Aucun article n’est marqué pour l’instant : l’accueil affiche '
            . 'les articles les plus récents. Ouvrez un article et cochez '
            . '« Afficher à la une » dans le panneau <strong>TechAna</strong> '
            . 'de la barre latérale.</p>';
        return;
    }
    printf(
        '<p>%s article(s) marqué(s), du plus récent au plus ancien :</p><ol>',
        number_format_i18n( count( $marques ) )
    );
    foreach ( $marques as $post ) {
        printf(
            '<li><a href="%s">%s</a> <span class="description">— %s</span></li>',
            esc_url( (string) get_edit_post_link( $post ) ),
            esc_html( get_the_title( $post ) ),
            esc_html( get_the_date( '', $post ) )
        );
    }
    echo '</ol>';
}

function techanaRevueUnePage() {
    if ( ! current_user_can( 'edit_theme_options' ) ) {
        wp_die( 'Accès refusé.' );
    }
    echo '<div class="wrap"><h1>Une de l’accueil</h1><form action="options.php" method="post">';
    settings_fields( TECHANA_UNE_OPTION );
    do_settings_sections( TECHANA_UNE_PAGE );
    submit_button();
    echo '</form>';
    techanaRevueUneRecap();
    echo '</div>';
}
