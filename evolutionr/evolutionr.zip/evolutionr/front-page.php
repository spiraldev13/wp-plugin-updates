<?php
/**
 * Page d'accueil — enchaîne les 10 sections SITE.MD dans l'ordre vertical.
 * Chaque section est isolée dans son template-part numéroté (template-parts/sections/).
 * Voir template-parts/README.md pour la carte de référence complète.
 *
 * Ordre vertical (SITE.MD § 3) :
 *   01 Hero            → 02 Chiffres/réassurance → 03 Prestations
 *   04 Paiement modes  → 05 Raisons/piliers     → 06 Méthode
 *   07 Aperçu tarifs   → 08 Réalisations        → 09 Journal (conditionnel)
 *   10 FAQ             → 11 CTA final
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

get_template_part('template-parts/sections/01-accueil-bandeau');
get_template_part('template-parts/sections/02-chiffres-cles');
get_template_part('template-parts/sections/03-prestations');
get_template_part('template-parts/sections/04-paiement-modes');
get_template_part('template-parts/sections/05-raisons');
get_template_part('template-parts/sections/06-methode-etapes');
get_template_part('template-parts/sections/07-apercu-tarifs');
get_template_part('template-parts/sections/08-realisations');
get_template_part('template-parts/sections/09-journal');
get_template_part('template-parts/sections/10-questions-reponses');
get_template_part('template-parts/sections/11-contact-final');

get_footer();
