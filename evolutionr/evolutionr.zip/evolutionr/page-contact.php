<?php
/**
 * Template — Page « Contact » (slug `contact`).
 *
 * Structure SITE.MD § page Contact :
 *   1. Hero court (titre + sous-titre)
 *   2. Formulaire Contact Form 7 (shortcode ACF cf7_shortcode) — formulaire
 *      DÉDIÉ « Contact Evolution'R », distinct du « Devis Evolution'R » de la
 *      page Tarifs : sans le bloc « Récapitulatif de votre configuration »
 *      (propre au configurateur). Câblé par evolutionr_seed_contact_form().
 *   3. Coordonnées + délai de réponse + zone d'intervention
 *   4. Carte d'accès optionnelle (si embed renseigné)
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main class="page-internal page-contact-layout" id="content">

    <section class="page-hero page-hero--prestation" aria-labelledby="page-hero-title">
        <div class="container">

            <?php evolutionr_breadcrumb(); ?>

            <?php
            $eyebrow = (string) get_field('hero_eyebrow');
            $title   = (string) get_field('hero_title') ?: get_the_title();
            $sub     = (string) get_field('hero_sub');
            ?>
            <div class="page-hero-grid">
                <div>
                    <?php if ($eyebrow): ?>
                        <div class="section-eyebrow-wrap" style="margin-bottom: 20px;">
                            <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                        </div>
                    <?php endif; ?>

                    <h1 class="page-hero-title" id="page-hero-title"><?php echo esc_html($title); ?></h1>

                    <?php if ($sub): ?>
                        <p class="page-hero-sub"><?php echo esc_html($sub); ?></p>
                    <?php endif; ?>
                </div>

                <div class="page-hero-aside">
                    <?php get_template_part('template-parts/cards/hero-visuel', null, [
                        'label'  => 'contact.channels',
                        'visual' => 'contact',
                    ]); ?>

                    <?php if (have_rows('hero_stats')): ?>
                        <div class="page-hero-stats">
                            <?php while (have_rows('hero_stats')): the_row();
                                $sLabel = (string) get_sub_field('label');
                                $sValue = (string) get_sub_field('value');
                                if (!$sValue) continue;
                                ?>
                                <div class="mini-stat">
                                    <?php if ($sLabel): ?><div class="label"><?php echo esc_html($sLabel); ?></div><?php endif; ?>
                                    <div class="value"><?php echo esc_html($sValue); ?></div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div><?php /* .page-hero-aside */ ?>
            </div>
        </div>
    </section>

    <section class="page-section page-contact-section" aria-labelledby="contact-form-title">
        <div class="container">
            <div class="page-contact-grid">

                <?php /* ─── Formulaire CF7 ─── */ ?>
                <div class="page-contact-form-wrap">
                    <h2 class="page-section-title page-section-title--inline" id="contact-form-title">
                        <?php esc_html_e('Décrivez-nous votre projet', 'evolutionr'); ?>
                    </h2>
                    <?php
                    $shortcode = (string) get_field('cf7_shortcode') ?: '[contact-form-7 id="69"]';
                    echo do_shortcode($shortcode);
                    ?>
                </div>

                <?php /* ─── Coordonnées + délai + zone ─── */ ?>
                <aside class="page-contact-aside">

                    <?php
                    $delaiTitle = (string) get_field('delai_title');
                    $delaiText  = (string) get_field('delai_text');
                    ?>
                    <?php if ($delaiTitle || $delaiText): ?>
                        <div class="page-contact-block page-contact-block--accent">
                            <?php if ($delaiTitle): ?>
                                <h3 class="page-contact-block-title"><?php echo esc_html($delaiTitle); ?></h3>
                            <?php endif; ?>
                            <?php if ($delaiText): ?>
                                <p class="page-contact-block-text"><?php echo esc_html($delaiText); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php
                    $contactEmail = (string) get_field('contact_email', 'option');
                    $contactPhone = (string) get_field('contact_phone', 'option');
                    $contactCity  = (string) get_field('contact_city', 'option');
                    $emailLabel   = (string) get_field('coords_email_label') ?: __('Par email', 'evolutionr');
                    $phoneLabel   = (string) get_field('coords_phone_label') ?: __('Par téléphone', 'evolutionr');
                    ?>
                    <div class="page-contact-block">
                        <h3 class="page-contact-block-title"><?php esc_html_e('Coordonnées', 'evolutionr'); ?></h3>

                        <?php if ($contactEmail): ?>
                            <div class="page-contact-coord">
                                <span class="page-contact-coord-label"><?php echo esc_html($emailLabel); ?></span>
                                <a class="page-contact-coord-value" href="mailto:<?php echo esc_attr($contactEmail); ?>">
                                    <?php echo esc_html($contactEmail); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if ($contactPhone): ?>
                            <div class="page-contact-coord">
                                <span class="page-contact-coord-label"><?php echo esc_html($phoneLabel); ?></span>
                                <a class="page-contact-coord-value" href="tel:<?php echo esc_attr(preg_replace('/\s+/', '', $contactPhone)); ?>">
                                    <?php echo esc_html($contactPhone); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if ($contactCity): ?>
                            <div class="page-contact-coord">
                                <span class="page-contact-coord-label"><?php esc_html_e('Basé à', 'evolutionr'); ?></span>
                                <span class="page-contact-coord-value"><?php echo esc_html($contactCity); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php
                    $zoneTitle = (string) get_field('zone_title');
                    $zoneText  = (string) get_field('zone_text');
                    ?>
                    <?php if ($zoneTitle || $zoneText): ?>
                        <div class="page-contact-block">
                            <?php if ($zoneTitle): ?>
                                <h3 class="page-contact-block-title"><?php echo esc_html($zoneTitle); ?></h3>
                            <?php endif; ?>
                            <?php if ($zoneText): ?>
                                <p class="page-contact-block-text"><?php echo esc_html($zoneText); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </aside>

            </div>

            <?php /* ─── Carte d'accès optionnelle ─── */ ?>
            <?php $mapEmbed = (string) get_field('map_embed'); ?>
            <?php if ($mapEmbed): ?>
                <div class="page-contact-map">
                    <?php
                    echo wp_kses(
                        $mapEmbed,
                        [
                            'iframe' => [
                                'src' => true, 'width' => true, 'height' => true, 'frameborder' => true,
                                'allow' => true, 'allowfullscreen' => true, 'loading' => true, 'referrerpolicy' => true,
                                'style' => true, 'title' => true,
                            ],
                        ]
                    );
                    ?>
                </div>
            <?php endif; ?>

        </div>
    </section>

</main>

<?php get_footer(); ?>
