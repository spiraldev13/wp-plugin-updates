#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Chargement de la configuration projet
# Source project.conf + types/$PROJECT_TYPE/type.conf
# Prerequis : utils.sh doit etre source avant ce fichier
# =============================================================================

load_project_config() {
  local project_root="${1:-.}"
  local makedev_dir="$project_root/.make"

  # Fallback : si pas de .make/, on est dans le repo makedev lui-meme
  if [ ! -d "$makedev_dir" ]; then
    makedev_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
  fi

  # Source project.conf
  if [ -f "$project_root/project.conf" ]; then
    source "$project_root/project.conf"
  fi

  # Valeurs par defaut
  PROJECT_TYPE="${PROJECT_TYPE:-basic}"
  PROJECT_SLUG="${PROJECT_SLUG:-$(basename "$(cd "$project_root" && pwd)")}"

  # Verifier que le type existe
  local type_dir="$makedev_dir/types/$PROJECT_TYPE"
  if [ ! -d "$type_dir" ]; then
    error "Type de projet inconnu : $PROJECT_TYPE"
    error "Types disponibles : $(ls "$makedev_dir/types/" 2>/dev/null | tr '\n' ' ')"
    exit 1
  fi

  # Source type.conf
  if [ -f "$type_dir/type.conf" ]; then
    source "$type_dir/type.conf"
  fi

  # Valeurs par defaut du type
  VERSION_FILE="${VERSION_FILE:-version.txt}"
  VERSION_FORMAT="${VERSION_FORMAT:-semver}"

  # Exporter MAKEDEV_DIR pour les autres scripts
  MAKEDEV_DIR="$makedev_dir"
}
