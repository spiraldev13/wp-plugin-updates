<?php

namespace Spiral;

use Spiral\Admin\Assets;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Prévisualisation sécurisée d'un popup.
 *
 * Rend une page autonome, non indexable et réservée à un utilisateur autorisé
 * (nonce + capacité `edit_post` sur le popup visé). Le popup s'ouvre
 * immédiatement, sans toucher aux cookies du visiteur ni incrémenter les
 * statistiques, et fonctionne même pour un brouillon ou un popup désactivé —
 * contrairement à l'ancien `?spiral-test` public.
 */
final class Preview
{
    private const ACTION = 'spiral_preview';

    public static function register(): void
    {
        add_action('admin_post_' . self::ACTION, [self::class, 'render']);
        // Non connecté : handler explicite pour un refus propre (pas de page blanche).
        add_action('admin_post_nopriv_' . self::ACTION, [self::class, 'denyGuest']);
    }

    /**
     * URL signée de prévisualisation d'un popup.
     *
     * @param int    $popupId ID du popup.
     * @param bool   $frame   Vrai pour le contenu de l'iframe (popup seul).
     * @param string $device  Appareil initial : desktop, tablet ou mobile.
     */
    public static function url(int $popupId, bool $frame = false, string $device = 'desktop'): string
    {
        $args = [
            'action' => self::ACTION,
            'popup' => $popupId,
            '_wpnonce' => wp_create_nonce(self::ACTION . '_' . $popupId),
        ];

        if ($frame) {
            $args['frame'] = '1';
        }

        if (in_array($device, ['tablet', 'mobile'], true)) {
            $args['device'] = $device;
        }

        return add_query_arg($args, admin_url('admin-post.php'));
    }

    public static function denyGuest(): void
    {
        wp_die(
            esc_html__('Vous devez être connecté pour prévisualiser ce popup.', 'popup-spiral'),
            esc_html__('Prévisualisation', 'popup-spiral'),
            ['response' => 403]
        );
    }

    /**
     * Rend la page de prévisualisation (ou son iframe).
     */
    public static function render(): void
    {
        $popupId = isset($_GET['popup']) ? absint($_GET['popup']) : 0;
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';

        if ($popupId <= 0 || !wp_verify_nonce($nonce, self::ACTION . '_' . $popupId)) {
            wp_die(
                esc_html__('Lien de prévisualisation invalide ou expiré.', 'popup-spiral'),
                esc_html__('Prévisualisation', 'popup-spiral'),
                ['response' => 403]
            );
        }

        if (!current_user_can('edit_post', $popupId)) {
            wp_die(
                esc_html__('Vous n\'avez pas l\'autorisation de prévisualiser ce popup.', 'popup-spiral'),
                esc_html__('Prévisualisation', 'popup-spiral'),
                ['response' => 403]
            );
        }

        $popup = get_post($popupId);

        if (!$popup instanceof \WP_Post || $popup->post_type !== PostTypes::POPUP) {
            wp_die(
                esc_html__('Popup introuvable.', 'popup-spiral'),
                esc_html__('Prévisualisation', 'popup-spiral'),
                ['response' => 404]
            );
        }

        // Jamais d'indexation ni de mise en cache d'une page de prévisualisation.
        nocache_headers();
        header('X-Robots-Tag: noindex, nofollow', true);
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));

        if (isset($_GET['frame'])) {
            self::renderFrame($popup);
        } else {
            self::renderChrome($popup);
        }

        exit;
    }

    /**
     * Contenu de l'iframe : le popup seul, sur un fond neutre, forcé ouvert.
     */
    private static function renderFrame(\WP_Post $popup): void
    {
        $config = Frontend::previewConfig($popup);
        $cssUrl = SPIRAL_POPUP_URL . 'assets/spiral.css';
        $jsUrl = SPIRAL_POPUP_URL . 'assets/spiral.js';
        ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html(get_the_title($popup)); ?></title>
    <link rel="stylesheet" href="<?php echo esc_url($cssUrl . '?ver=' . Assets::assetVersion('spiral.css')); ?>">
    <style>
        body { margin: 0; min-height: 100vh; background: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .spiral-preview-hint { position: fixed; inset: auto 0 0 0; text-align: center; padding: 10px; color: #64748b; font-size: 13px; }
    </style>
</head>
<body>
    <p class="spiral-preview-hint"><?php esc_html_e('Aperçu — le popup ci-dessus est forcé ouvert.', 'popup-spiral'); ?></p>
    <?php
    echo Frontend::designsCssTag([$popup]);
    echo Frontend::renderPopupHtml($popup);
    ?>
    <script>window.spiralPopups = <?php echo wp_json_encode($config); ?>;</script>
    <script src="<?php echo esc_url($jsUrl . '?ver=' . Assets::assetVersion('spiral.js')); ?>"></script>
</body>
</html>
        <?php
    }

    /**
     * Page « cadre » : bandeau de prévisualisation + bascule d'appareil + iframe.
     */
    private static function renderChrome(\WP_Post $popup): void
    {
        $frameUrl = self::url((int) $popup->ID, true);
        $title = get_the_title($popup);
        $devices = [
            'desktop' => [__('Ordinateur', 'popup-spiral'), '100%'],
            'tablet' => [__('Tablette', 'popup-spiral'), '768px'],
            'mobile' => [__('Mobile', 'popup-spiral'), '375px'],
        ];
        ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php printf(esc_html__('Aperçu : %s', 'popup-spiral'), esc_html($title)); ?></title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #e2e8f0; }
        .spiral-pv-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 16px; padding: 12px 20px; background: #1e293b; border-bottom: 1px solid #334155; }
        .spiral-pv-badge { background: #f59e0b; color: #111827; font-weight: 700; padding: 4px 10px; border-radius: 999px; font-size: 12px; text-transform: uppercase; letter-spacing: .04em; }
        .spiral-pv-title { font-weight: 600; }
        .spiral-pv-note { color: #94a3b8; font-size: 13px; }
        .spiral-pv-devices { margin-left: auto; display: flex; gap: 8px; }
        .spiral-pv-devices button { cursor: pointer; border: 1px solid #475569; background: #0f172a; color: #e2e8f0; padding: 6px 14px; border-radius: 6px; font-size: 13px; }
        .spiral-pv-devices button[aria-pressed="true"] { background: #38bdf8; color: #0f172a; border-color: #38bdf8; font-weight: 600; }
        .spiral-pv-stage { display: flex; justify-content: center; padding: 24px; }
        .spiral-pv-frame { width: 100%; max-width: 100%; height: calc(100vh - 130px); background: #f1f5f9; border: 0; border-radius: 10px; box-shadow: 0 20px 60px rgba(0,0,0,.5); transition: max-width .2s ease; }
    </style>
</head>
<body>
    <div class="spiral-pv-bar">
        <span class="spiral-pv-badge"><?php esc_html_e('Mode prévisualisation', 'popup-spiral'); ?></span>
        <span class="spiral-pv-title"><?php echo esc_html($title); ?></span>
        <span class="spiral-pv-note"><?php esc_html_e('Page non indexée · aucune statistique · aucun cookie', 'popup-spiral'); ?></span>
        <div class="spiral-pv-devices" role="group" aria-label="<?php esc_attr_e('Choisir l\'appareil', 'popup-spiral'); ?>">
            <?php foreach ($devices as $key => $device) : ?>
                <button type="button" data-width="<?php echo esc_attr($device[1]); ?>" aria-pressed="<?php echo $key === 'desktop' ? 'true' : 'false'; ?>"><?php echo esc_html($device[0]); ?></button>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="spiral-pv-stage">
        <iframe class="spiral-pv-frame" src="<?php echo esc_url($frameUrl); ?>" title="<?php esc_attr_e('Aperçu du popup', 'popup-spiral'); ?>"></iframe>
    </div>
    <script>
        (function () {
            var frame = document.querySelector('.spiral-pv-frame');
            var buttons = document.querySelectorAll('.spiral-pv-devices button');
            buttons.forEach(function (button) {
                button.addEventListener('click', function () {
                    frame.style.maxWidth = button.getAttribute('data-width');
                    buttons.forEach(function (other) { other.setAttribute('aria-pressed', 'false'); });
                    button.setAttribute('aria-pressed', 'true');
                });
            });
        })();
    </script>
</body>
</html>
        <?php
    }
}
