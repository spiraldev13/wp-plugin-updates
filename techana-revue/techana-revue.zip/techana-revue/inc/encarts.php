<?php
/**
 * Encarts commerciaux — un contenu par encart, ciblé par rubrique et par
 * emplacement.
 *
 * Chaque encart est un `techana_encart` : la liste des contenus sert de tableau
 * de bord (état, ciblage, aperçu), le passage en brouillon l'éteint, la
 * duplication en crée un autre. Le ciblage par rubrique passe par la taxonomie
 * `category` du site : aucun sélecteur maison, et la liste des rubriques suit
 * d'elle-même la taxonomie.
 *
 * Le titre est un nom de travail (« Hébergeur X »), jamais affiché : ce qui
 * s'affiche au-dessus de l'encart est le libellé, champ séparé qui vaut
 * « Publicité » à défaut — un encart commercial non signalé expose l'éditeur.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const TECHANA_ENCART_TYPE = 'techana_encart';

add_action( 'init', 'techanaRevueEnregistrerEncart' );
add_action( 'add_meta_boxes', 'techanaRevueEncartMetabox' );
add_action( 'save_post_' . TECHANA_ENCART_TYPE, 'techanaRevueEncartSuspendreSuiviSeo', 1 );
add_action( 'wp_insert_post', 'techanaRevueEncartRetablirSuiviSeo', 1 );
add_action( 'save_post_' . TECHANA_ENCART_TYPE, 'techanaRevueEncartEnregistrer' );
add_filter( 'wp_insert_post_data', 'techanaRevueEncartMarquerEnregistrement', 10, 2 );
add_action( 'wp_insert_post', 'techanaRevueEncartFinEnregistrement', 99 );
add_action( 'publish_future_post', 'techanaRevueEncartMarquerPublicationDifferee', 5 );
add_filter( 'option_default_category', 'techanaRevueEncartNeutraliserRubriqueParDefaut' );
add_action( 'admin_enqueue_scripts', 'techanaRevueEncartAssets' );
add_filter( 'manage_' . TECHANA_ENCART_TYPE . '_posts_columns', 'techanaRevueEncartColonnes' );
add_action( 'manage_' . TECHANA_ENCART_TYPE . '_posts_custom_column', 'techanaRevueEncartColonne', 10, 2 );

/**
 * Emplacements où un encart peut être servi.
 *
 * @return array<string, array{label: string, aide: string}>
 */
function techanaRevueEncartEmplacements(): array {
    return array(
        'lateral'      => array(
            'label' => 'Latérale de l’accueil et des rubriques',
            'aide'  => 'Colonne de droite de l’accueil, des hubs de rubrique et des publications, sous « Les plus lus ».',
        ),
        'article'      => array(
            'label' => 'Latérale d’article',
            'aide'  => 'Colonne de droite des articles, sous « Les plus lus ».',
        ),
        'article_corps' => array(
            'label' => 'Dans le corps de l’article',
            'aide'  => 'Inséré au fil du texte, après le nombre de paragraphes réglé dans Apparence → Publicité. Jamais dans un article sponsorisé, qui a déjà ses encarts annonceur.',
        ),
        'article_pied' => array(
            'label' => 'En pied d’article',
            'aide'  => 'Sous le contenu, avant la boîte auteur.',
        ),
        'hub'          => array(
            'label' => 'Bandeau de rubrique',
            'aide'  => 'Bandeau large sous le pavé de titre d’un hub de rubrique — format horizontal.',
        ),
    );
}

/**
 * Déclarations que le lien de l'encart peut porter.
 *
 * `sponsored` est ce que Google attend d'un lien payé — publicité comme
 * affiliation ; `nofollow` est l'attribut générique historique, encore le seul
 * que Bing interprète vraiment. Le choix reste à l'éditeur : c'est lui qui sait
 * si le lien est commercial.
 *
 * @return array<string, string> Valeur => aide affichée.
 */
function techanaRevueEncartRelDisponibles(): array {
    return array(
        'sponsored' => 'Lien payé : publicité, partenariat, affiliation. C’est la déclaration'
            . ' que Google attend — sans elle, un lien commercial passe pour une recommandation'
            . ' éditoriale, ce qui expose le site à une pénalité.',
        'nofollow'  => 'Attribut historique, plus large : « ne suis pas ce lien ». Google se'
            . ' contente de `sponsored`, mais Bing et les autres moteurs ne comprennent bien'
            . ' que celui-ci. Les deux peuvent être cochés ensemble.',
    );
}

/** Déclarations d'un encart jamais enregistré depuis l'ajout de ce choix. */
function techanaRevueEncartRelDefaut(): array {
    return array( 'sponsored' );
}

function techanaRevueEnregistrerEncart() {
    register_post_type( TECHANA_ENCART_TYPE, array(
        'labels'          => array(
            'name'               => 'Encarts',
            'singular_name'      => 'Encart',
            'add_new'            => 'Ajouter',
            'add_new_item'       => 'Nouvel encart',
            'edit_item'          => 'Modifier l’encart',
            'search_items'       => 'Rechercher un encart',
            'not_found'          => 'Aucun encart',
            'not_found_in_trash' => 'Aucun encart à la corbeille',
            'menu_name'          => 'Encarts',
        ),
        // Aucune URL propre : un encart n'est pas une page, il s'insère.
        'public'          => false,
        'show_ui'         => true,
        'show_in_menu'    => true,
        'show_in_rest'    => false,
        'menu_icon'       => 'dashicons-megaphone',
        'menu_position'   => 26,
        'supports'        => array( 'title', 'thumbnail' ),
        'capability_type' => 'post',
        'taxonomies'      => array( 'category' ),
    ) );
    // Rattachement explicite : `taxonomies` seul ne suffit pas quand la
    // taxonomie est déclarée avant le type.
    register_taxonomy_for_object_type( 'category', TECHANA_ENCART_TYPE );
}

/**
 * Instance du surveillant Analytics de Rank Math, si elle existe.
 *
 * @return object|null
 */
function techanaRevueWatcherSeo() {
    if ( ! class_exists( '\RankMath\Analytics\Watcher' ) ) {
        return null;
    }
    return \RankMath\Analytics\Watcher::get();
}

/**
 * Retire le suivi Analytics de Rank Math le temps d'enregistrer un encart.
 *
 * Quand un compte Google est connecté, Rank Math surveille `save_post` : pour
 * tout contenu qu'il ne suit pas — dont un encart, qui n'a pas d'URL — il
 * nettoie sa table `rank_math_analytics_objects`. Cette table n'existe pas sur
 * cette installation, et l'erreur SQL remonte alors dans l'éditeur.
 *
 * Un encart n'a de toute façon rien à faire dans des statistiques de position :
 * le suivi est suspendu, puis rétabli aussitôt pour ne rien changer aux autres
 * contenus enregistrés dans la même requête.
 */
function techanaRevueEncartSuspendreSuiviSeo() {
    $watcher = techanaRevueWatcherSeo();
    if ( ! $watcher ) {
        return;
    }
    remove_action( 'save_post', array( $watcher, 'update_post_info' ), 101 );
}

function techanaRevueEncartRetablirSuiviSeo( $postId ) {
    $watcher = techanaRevueWatcherSeo();
    if ( ! $watcher || TECHANA_ENCART_TYPE !== get_post_type( $postId ) ) {
        return;
    }
    add_action( 'save_post', array( $watcher, 'update_post_info' ), 101 );
}

/**
 * Neutralisation de la rubrique par défaut, le temps d'enregistrer un encart.
 *
 * WordPress refuse qu'un contenu publié rattaché à `category` n'ait aucun terme :
 * il applique la rubrique par défaut du site (`wp_insert_post()` et surtout
 * `wp_publish_post()`, donc dès qu'un encart passe de brouillon à publié). Pour
 * un encart, cette rubrique fantôme n'est pas cosmétique : « aucune rubrique
 * cochée » signifie **encart par défaut, servi partout**, et une rubrique
 * imposée le restreindrait sans que personne l'ait demandé.
 *
 * L'option lue à 0, le cœur de WordPress conclut qu'aucun terme par défaut
 * n'est défini et n'en applique aucun. Le drapeau ne vit que le temps de
 * l'écriture : la rubrique par défaut du site reste intacte pour les articles.
 *
 * Couvre les chemins d'écriture réels — formulaire d'édition, modification
 * rapide, création programmatique (`wp_insert_post()`) et publication planifiée
 * (`publish_future_post`). Un `wp_publish_post()` appelé nu par du code tiers
 * échappe au drapeau : le filet du formulaire ci-dessous rattrape l'encart au
 * premier enregistrement suivant.
 *
 * @param mixed $valeur Identifiant de la rubrique par défaut du site.
 * @return mixed
 */
function techanaRevueEncartNeutraliserRubriqueParDefaut( $valeur ) {
    return techanaRevueEncartEnEcriture() ? 0 : $valeur;
}

/**
 * Drapeau « un encart est en cours d'écriture ».
 *
 * @param bool|null $etat Nouvel état, ou null pour lire.
 */
function techanaRevueEncartEnEcriture( ?bool $etat = null ): bool {
    static $enCours = false;
    if ( null !== $etat ) {
        $enCours = $etat;
    }
    return $enCours;
}

/**
 * @param array $donnees Données assainies du contenu en cours d'écriture.
 * @param array $brutes  Tableau d'origine.
 */
function techanaRevueEncartMarquerEnregistrement( array $donnees, array $brutes ): array {
    $type = $donnees['post_type'] ?? ( $brutes['post_type'] ?? '' );
    techanaRevueEncartEnEcriture( TECHANA_ENCART_TYPE === $type );
    return $donnees;
}

function techanaRevueEncartFinEnregistrement() {
    techanaRevueEncartEnEcriture( false );
}

/** Publication différée : `wp_publish_post()` applique aussi le terme par défaut. */
function techanaRevueEncartMarquerPublicationDifferee( int $postId ) {
    if ( TECHANA_ENCART_TYPE === get_post_type( $postId ) ) {
        techanaRevueEncartEnEcriture( true );
    }
}

/** Champs d'un encart, avec leurs valeurs par défaut. */
function techanaRevueEncartChamps( int $encartId ): array {
    $emplacements = (array) get_post_meta( $encartId, '_techana_encart_emplacements', true );
    // Absence de la méta = encart antérieur à ce choix : il gardait `sponsored`.
    // Un tableau vide, lui, est une décision explicite — d'où `metadata_exists`.
    $rel = metadata_exists( 'post', $encartId, '_techana_encart_rel' )
        ? (array) get_post_meta( $encartId, '_techana_encart_rel', true )
        : techanaRevueEncartRelDefaut();
    return array(
        'libelle'      => (string) get_post_meta( $encartId, '_techana_encart_libelle', true ),
        'lien'         => (string) get_post_meta( $encartId, '_techana_encart_lien', true ),
        'mention'      => (string) get_post_meta( $encartId, '_techana_encart_mention', true ),
        'code'         => (string) get_post_meta( $encartId, '_techana_encart_code', true ),
        'emplacements' => array_values( array_filter( $emplacements, 'is_string' ) ),
        'rel'          => array_values( array_filter( $rel, 'is_string' ) ),
    );
}

/**
 * Encarts publiés, pour les listes de choix de l'administration.
 *
 * Le titre est le nom de travail de l'encart : c'est ce qui permet de s'y
 * retrouver, jamais ce qui s'affiche sur le site.
 *
 * @return array<int, array{id: int, titre: string}>
 */
function techanaRevueEncartsPublies(): array {
    $encarts = get_posts( array(
        'post_type'      => TECHANA_ENCART_TYPE,
        'post_status'    => 'publish',
        'posts_per_page' => 100,
        'orderby'        => 'title',
        'order'          => 'ASC',
    ) );
    return array_map(
        static function ( WP_Post $encart ): array {
            return array(
                'id'    => (int) $encart->ID,
                'titre' => '' !== $encart->post_title ? $encart->post_title : '(encart sans titre)',
            );
        },
        $encarts
    );
}

function techanaRevueEncartMetabox() {
    add_meta_box(
        'techana-encart',
        'Contenu de l’encart',
        'techanaRevueEncartMetaboxRendu',
        TECHANA_ENCART_TYPE,
        'normal',
        'high'
    );
    add_meta_box(
        'techana-encart-emplacements',
        'Emplacements',
        'techanaRevueEncartMetaboxEmplacements',
        TECHANA_ENCART_TYPE,
        'side',
        'default'
    );
}

function techanaRevueEncartMetaboxRendu( WP_Post $post ) {
    $champs = techanaRevueEncartChamps( $post->ID );
    wp_nonce_field( 'techana-encart', 'techana_encart_nonce' );
    ?>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="techana-encart-libelle">Libellé affiché</label></th>
            <td>
                <input type="text" id="techana-encart-libelle" name="techana_encart_libelle"
                       value="<?php echo esc_attr( $champs['libelle'] ); ?>"
                       class="regular-text" placeholder="Publicité" />
                <p class="description">
                    Mention obligatoire au-dessus de l’encart : « Publicité »,
                    « Partenaire », « Lien affilié »… Laissé vide, il affiche
                    <strong>Publicité</strong> — un encart commercial doit toujours
                    être signalé.
                </p>
            </td>
        </tr>
        <tr>
            <th><label for="techana-encart-lien">Destination</label></th>
            <td>
                <input type="url" id="techana-encart-lien" name="techana_encart_lien"
                       value="<?php echo esc_attr( $champs['lien'] ); ?>"
                       class="regular-text" placeholder="https://" />
                <p class="description">Page ouverte au clic, dans l’onglet courant.</p>
            </td>
        </tr>
        <tr>
            <th>Déclaration du lien</th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text">Attributs rel du lien</legend>
                    <?php foreach ( techanaRevueEncartRelDisponibles() as $valeur => $aide ) : ?>
                        <p>
                            <label>
                                <input type="checkbox" name="techana_encart_rel[]"
                                       value="<?php echo esc_attr( $valeur ); ?>"
                                       <?php checked( in_array( $valeur, $champs['rel'], true ) ); ?> />
                                <code>rel="<?php echo esc_html( $valeur ); ?>"</code>
                            </label>
                            <br /><span class="description"><?php echo esc_html( $aide ); ?></span>
                        </p>
                    <?php endforeach; ?>
                    <p class="description">
                        Les deux décochés, le lien part <strong>nu</strong> : à ne faire que
                        pour un lien qui n’est pas commercial.
                    </p>
                </fieldset>
            </td>
        </tr>
        <tr>
            <th><label for="techana-encart-mention">Mention sous l’encart</label></th>
            <td>
                <input type="text" id="techana-encart-mention" name="techana_encart_mention"
                       value="<?php echo esc_attr( $champs['mention'] ); ?>" class="large-text" />
                <p class="description">
                    Par exemple : « Ce lien est affilié : un achat peut nous rémunérer,
                    sans surcoût pour vous. » Obligatoire pour un lien d’affiliation.
                </p>
            </td>
        </tr>
        <tr>
            <th>Visuel</th>
            <td>
                <?php
                techanaRevueChampImage( array(
                    'nom'    => 'techana_encart_visuel',
                    'valeur' => (int) get_post_thumbnail_id( $post ),
                    'titre'  => 'Visuel de l’encart',
                    'vide'   => 'Aucun visuel : le code de régie est utilisé s’il est rempli.',
                    'cote'   => 300,
                ) );
                ?>
                <p class="description">300 × 250 pour les latérales, format large pour un bandeau de rubrique.</p>
            </td>
        </tr>
        <tr>
            <th><label for="techana-encart-code">Code de régie</label></th>
            <td>
                <textarea id="techana-encart-code" name="techana_encart_code" rows="5"
                          class="large-text code"><?php echo esc_textarea( $champs['code'] ); ?></textarea>
                <p class="description">
                    <?php if ( current_user_can( 'unfiltered_html' ) ) : ?>
                        Balise fournie par une régie, insérée telle quelle. Elle
                        <strong>l’emporte sur le visuel</strong>.
                    <?php else : ?>
                        Votre compte ne peut pas publier de script : ce champ sera filtré.
                    <?php endif; ?>
                </p>
            </td>
        </tr>
    </table>
    <?php
}

function techanaRevueEncartMetaboxEmplacements( WP_Post $post ) {
    $actifs = techanaRevueEncartChamps( $post->ID )['emplacements'];
    echo '<p>Où cet encart peut apparaître :</p>';
    foreach ( techanaRevueEncartEmplacements() as $cle => $def ) {
        printf(
            '<p><label><input type="checkbox" name="techana_encart_emplacements[]" value="%s"%s /> %s</label>'
                . '<br /><span class="description">%s</span></p>',
            esc_attr( $cle ),
            checked( in_array( $cle, $actifs, true ), true, false ),
            esc_html( $def['label'] ),
            esc_html( $def['aide'] )
        );
    }
    echo '<p class="description"><strong>Rubriques</strong> : cochez-les dans la boîte '
        . '« Catégories ». Aucune cochée = encart par défaut, servi partout où aucun '
        . 'encart de rubrique ne s’applique.</p>';
}

function techanaRevueEncartEnregistrer( int $postId ) {
    $nonce = $_POST['techana_encart_nonce'] ?? '';
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), 'techana-encart' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_post', $postId ) ) {
        return;
    }

    $textes = array(
        '_techana_encart_libelle' => sanitize_text_field( wp_unslash( $_POST['techana_encart_libelle'] ?? '' ) ),
        '_techana_encart_mention' => sanitize_text_field( wp_unslash( $_POST['techana_encart_mention'] ?? '' ) ),
        '_techana_encart_lien'    => esc_url_raw( wp_unslash( $_POST['techana_encart_lien'] ?? '' ) ),
    );
    foreach ( $textes as $cle => $valeur ) {
        if ( '' === $valeur ) {
            delete_post_meta( $postId, $cle );
        } else {
            update_post_meta( $postId, $cle, $valeur );
        }
    }

    // Script exécutable : accepté tel quel du seul compte qui a le droit d'en
    // publier, filtré pour les autres.
    $code = (string) wp_unslash( $_POST['techana_encart_code'] ?? '' );
    if ( ! current_user_can( 'unfiltered_html' ) ) {
        $code = wp_kses_post( $code );
    }
    $code = trim( $code );
    if ( '' === $code ) {
        delete_post_meta( $postId, '_techana_encart_code' );
    } else {
        update_post_meta( $postId, '_techana_encart_code', $code );
    }

    $connus = array_keys( techanaRevueEncartEmplacements() );
    $postes = (array) ( $_POST['techana_encart_emplacements'] ?? array() );
    $propre = array_values( array_intersect( $connus, array_map( 'sanitize_key', $postes ) ) );
    if ( $propre ) {
        update_post_meta( $postId, '_techana_encart_emplacements', $propre );
    } else {
        delete_post_meta( $postId, '_techana_encart_emplacements' );
    }

    // Toujours écrite, même vide : « aucune déclaration » est un choix, pas un
    // retour au défaut.
    $relConnus = array_keys( techanaRevueEncartRelDisponibles() );
    $relPostes = array_map( 'sanitize_key', (array) ( $_POST['techana_encart_rel'] ?? array() ) );
    update_post_meta( $postId, '_techana_encart_rel', array_values( array_intersect( $relConnus, $relPostes ) ) );

    // Filet côté formulaire : aucune rubrique cochée = aucune rubrique, y compris
    // celle qu'une version antérieure aurait collée à l'encart.
    if ( isset( $_POST['post_category'] ) ) {
        $rubriques = array_filter( array_map( 'absint', (array) $_POST['post_category'] ) );
        if ( ! $rubriques ) {
            wp_set_object_terms( $postId, array(), 'category' );
        }
    }

    // Le visuel passe par l'image à la une : même médiathèque, mêmes tailles.
    $visuel = techanaRevueImageValide( $_POST['techana_encart_visuel'] ?? 0 );
    if ( $visuel ) {
        set_post_thumbnail( $postId, $visuel );
    } else {
        delete_post_thumbnail( $postId );
    }
}

function techanaRevueEncartAssets( string $hook ) {
    if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
        return;
    }
    if ( TECHANA_ENCART_TYPE !== get_post_type() ) {
        return;
    }
    techanaRevueChampImageAssets();
}

/**
 * Colonnes de la liste : ce qu'il faut pour piloter une campagne d'un coup
 * d'œil — visuel, libellé, rubriques visées, emplacements.
 */
function techanaRevueEncartColonnes( array $colonnes ): array {
    $avant = array_slice( $colonnes, 0, 2, true );
    $apres = array_slice( $colonnes, 2, null, true );
    return $avant + array(
        'techana_visuel'       => 'Visuel',
        'techana_libelle'      => 'Libellé',
        'techana_rubriques'    => 'Rubriques',
        'techana_emplacements' => 'Emplacements',
    ) + $apres;
}

function techanaRevueEncartColonne( string $colonne, int $postId ) {
    $champs = techanaRevueEncartChamps( $postId );

    if ( 'techana_visuel' === $colonne ) {
        $visuel = get_the_post_thumbnail( $postId, array( 80, 80 ) );
        echo $visuel ? $visuel : ( $champs['code'] ? '<em>code de régie</em>' : '—' );
        return;
    }
    if ( 'techana_libelle' === $colonne ) {
        echo esc_html( '' !== $champs['libelle'] ? $champs['libelle'] : 'Publicité' );
        return;
    }
    if ( 'techana_rubriques' === $colonne ) {
        $termes = get_the_terms( $postId, 'category' );
        if ( ! $termes || is_wp_error( $termes ) ) {
            echo '<em>toutes (par défaut)</em>';
            return;
        }
        echo esc_html( implode( ', ', wp_list_pluck( $termes, 'name' ) ) );
        return;
    }
    if ( 'techana_emplacements' === $colonne ) {
        $connus = techanaRevueEncartEmplacements();
        $noms   = array();
        foreach ( $champs['emplacements'] as $cle ) {
            if ( isset( $connus[ $cle ] ) ) {
                $noms[] = $connus[ $cle ]['label'];
            }
        }
        echo $noms ? esc_html( implode( ', ', $noms ) ) : '<em>aucun — invisible</em>';
    }
}
