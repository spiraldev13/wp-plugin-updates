<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('evolutionr_register_cpt')) {
    function evolutionr_register_cpt(): void
    {
        // Décision design D5 du change lancement-site-evolutionr : le CPT
        // realisation est un réservoir de données pour la section portfolio de
        // la home, sans URL publique (ni archive, ni single post). Les
        // prestations et la FAQ sont désormais des repeaters ACF (`services_cards`,
        // `faq_items`) édités directement sur la page d'accueil.
        register_post_type('realisation', [
            'labels' => [
                'name'               => __('Réalisations', 'evolutionr'),
                'singular_name'      => __('Réalisation', 'evolutionr'),
                'add_new'            => __('Ajouter', 'evolutionr'),
                'add_new_item'       => __('Ajouter une réalisation', 'evolutionr'),
                'edit_item'          => __('Modifier la réalisation', 'evolutionr'),
                'new_item'           => __('Nouvelle réalisation', 'evolutionr'),
                'view_item'          => __('Voir la réalisation', 'evolutionr'),
                'search_items'       => __('Chercher une réalisation', 'evolutionr'),
                'not_found'          => __('Aucune réalisation', 'evolutionr'),
                'not_found_in_trash' => __('Aucune réalisation à la corbeille', 'evolutionr'),
                'menu_name'          => __('Réalisations', 'evolutionr'),
            ],
            'public'              => true,
            'publicly_queryable'  => false,
            'has_archive'         => false,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => false,
            'menu_position'       => 21,
            'menu_icon'           => 'dashicons-images-alt2',
            'show_in_rest'        => true,
            'rewrite'             => false,
            'supports'            => ['title', 'editor', 'page-attributes', 'thumbnail', 'excerpt'],
            'hierarchical'        => false,
        ]);

    }
}

add_action('init', 'evolutionr_register_cpt');
