<?php
/**
 * Template d'un popup — surchargeable en copiant ce fichier
 * dans {votre-theme}/popup-spiral/popup.php.
 *
 * Variables disponibles :
 *
 * @var \WP_Post $spiralPopup      Le post popup.
 * @var array    $spiralSettings   Réglages complets du popup.
 * @var string   $spiralDesignSlug Slug du design appliqué.
 * @var array    $spiralDesign     Réglages du design (couleurs, coins…).
 * @var string   $spiralContent    Contenu HTML prêt à afficher.
 * @var string   $spiralPosition   Position (center, bottom-right, bar-top…).
 * @var int      $spiralZindex     Z-index du popup.
 */

if (!defined('ABSPATH')) {
    exit;
}

$spiralImage = $spiralSettings['display']['image'];
$spiralButton = $spiralSettings['button'];

// Résolution centralisée (intégrées, réutilisables, replis) ;
// chaîne vide = taille automatique selon le contenu.
$spiralWidth = \Spiral\Settings::widthCssFor($spiralSettings['display']);

$spiralPopupClasses = [
    'spiral-popup',
    'spiral-design-' . sanitize_html_class($spiralDesignSlug),
    'spiral-img-' . sanitize_html_class($spiralImage['layout']),
    'spiral-imgpad-' . sanitize_html_class($spiralImage['padding']),
    'spiral-close-' . sanitize_html_class($spiralDesign['close_position']),
    'spiral-closestyle-' . sanitize_html_class($spiralDesign['close_style']),
    'spiral-valign-' . sanitize_html_class($spiralSettings['display']['content_valign']),
];

if (!empty($spiralDesign['neutral'])) {
    $spiralPopupClasses[] = 'spiral-neutral';
}

if ($spiralWidth === '') {
    $spiralPopupClasses[] = 'spiral-size-auto';
}

if ($spiralSettings['display']['height'] === 'custom') {
    $spiralPopupClasses[] = 'spiral-has-height';
}

if ($spiralImage['border'] !== 'none') {
    $spiralPopupClasses[] = 'spiral-imgborder-' . sanitize_html_class($spiralImage['border']);
}

$spiralPopupStyle = ($spiralWidth !== '' ? '--spiral-width: ' . $spiralWidth . ';' : '')
    . ' --spiral-img-w: ' . (int) $spiralImage['width'] . '%;'
    . ' --spiral-btn-size: ' . (int) $spiralButton['text_size'] . 'px;'
    . ' --spiral-text-size: ' . (int) $spiralSettings['display']['text_size'] . 'px;';

if ($spiralSettings['display']['height'] === 'custom') {
    $spiralPopupStyle .= ' min-height: min(' . (int) $spiralSettings['display']['custom_height'] . 'px, 90vh);';
}

if ($spiralImage['padding'] === 'custom') {
    $spiralPopupStyle .= ' --spiral-img-pad: ' . (int) $spiralImage['custom_padding'] . 'px;';
}

if ($spiralImage['border'] !== 'none') {
    $spiralPopupStyle .= ' --spiral-img-border-color: ' . $spiralImage['border_color'] . ';';

    if ($spiralImage['border'] === 'custom') {
        $spiralPopupStyle .= ' --spiral-img-border-w: ' . (int) $spiralImage['border_width'] . 'px;';
    }
}

// Sans image choisie dans les réglages, l'image mise en avant prend le relais.
$spiralImageId = (int) $spiralImage['id'];

if ($spiralImageId === 0) {
    $spiralImageId = (int) get_post_thumbnail_id($spiralPopup);
}

if ($spiralImage['layout'] === 'background' && $spiralImageId > 0) {
    $spiralBgUrl = wp_get_attachment_image_url($spiralImageId, 'large');

    if ($spiralBgUrl) {
        $spiralPopupStyle .= ' background-image: url(' . esc_url($spiralBgUrl) . ');';
    }
}

$spiralImageHtml = '';

if (in_array($spiralImage['layout'], ['banner', 'left', 'right'], true) && $spiralImageId > 0) {
    $spiralImageHtml = wp_get_attachment_image(
        $spiralImageId,
        'large',
        false,
        ['class' => 'spiral-image-media', 'alt' => '']
    );
}

$spiralButtonHtml = '';

if (!empty($spiralButton['enabled']) && $spiralButton['label'] !== '') {
    if ($spiralButton['target'] === 'url') {
        $spiralButtonUrl = $spiralButton['url'];
    } elseif ((int) $spiralButton['page'] === -1) {
        $spiralButtonUrl = home_url('/');
    } else {
        $spiralButtonUrl = $spiralButton['page'] > 0 ? get_permalink((int) $spiralButton['page']) : '';
    }

    if (!empty($spiralButtonUrl)) {
        $spiralButtonHtml = sprintf(
            '<p class="spiral-actions spiral-align-%s"><a class="spiral-btn" href="%s"%s>%s</a></p>',
            sanitize_html_class($spiralButton['align']),
            esc_url($spiralButtonUrl),
            $spiralButton['new_tab'] ? ' target="_blank" rel="noopener"' : '',
            esc_html($spiralButton['label'])
        );
    }
}
?>
<div
    id="spiral-popup-<?php echo (int) $spiralPopup->ID; ?>"
    class="spiral-root spiral-pos-<?php echo esc_attr($spiralPosition); ?> spiral-mode-<?php echo esc_attr($spiralDesign['overlay']); ?>"
    data-spiral-id="<?php echo (int) $spiralPopup->ID; ?>"
    style="z-index: <?php echo (int) $spiralZindex; ?>;"
    hidden
>
    <div class="spiral-overlay"<?php echo empty($spiralSettings['triggers']['no_overlay_close']) ? ' data-spiral-close' : ''; ?>></div>
    <div
        class="<?php echo esc_attr(implode(' ', $spiralPopupClasses)); ?>"
        style="<?php echo esc_attr($spiralPopupStyle); ?>"
        role="dialog"
        aria-modal="true"
        aria-label="<?php echo esc_attr(get_the_title($spiralPopup)); ?>"
    >
        <?php if ($spiralImageHtml !== '' && $spiralImage['layout'] === 'banner') : ?>
            <div class="spiral-image spiral-image-banner"><?php echo $spiralImageHtml; ?></div>
        <?php endif; ?>

        <div class="spiral-body">
            <?php if ($spiralImageHtml !== '' && in_array($spiralImage['layout'], ['left', 'right'], true)) : ?>
                <div class="spiral-image spiral-image-side"><?php echo $spiralImageHtml; ?></div>
            <?php endif; ?>

            <div class="spiral-content">
                <?php echo $spiralContent; // Déjà filtré via spiral_popup_content. ?>
                <?php echo $spiralButtonHtml; // Construit et échappé ci-dessus. ?>
            </div>
        </div>

        <button type="button" class="spiral-close spiral-close-style-<?php echo esc_attr($spiralDesign['close_style']); ?>" data-spiral-close aria-label="<?php esc_attr_e('Fermer', 'popup-spiral'); ?>">
            <?php if ($spiralDesign['close_style'] === 'text') : ?>
                <?php esc_html_e('Fermer', 'popup-spiral'); ?>
            <?php else : ?>
                <span aria-hidden="true">&times;</span>
            <?php endif; ?>
        </button>
    </div>
</div>
