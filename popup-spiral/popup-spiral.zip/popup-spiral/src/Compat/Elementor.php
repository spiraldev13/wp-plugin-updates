<?php

namespace Spiral\Compat;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Compatibilité Elementor : un template Elementor peut servir de contenu
 * de popup — l'utilisateur construit son design dans Elementor, le popup
 * l'affiche avec ses styles.
 */
final class Elementor
{
    public const TEMPLATE_POST_TYPE = 'elementor_library';

    public static function register(): void
    {
        // Rien à hooker : la classe expose des services utilisés au rendu
        // et par l'éditeur de popup, uniquement si Elementor est actif.
    }

    public static function isActive(): bool
    {
        return class_exists('\Elementor\Plugin');
    }

    public static function templateExists(int $templateId): bool
    {
        if (!self::isActive()) {
            return false;
        }

        $template = get_post($templateId);

        return $template instanceof \WP_Post
            && $template->post_type === self::TEMPLATE_POST_TYPE
            && $template->post_status === 'publish';
    }

    /**
     * Rendu complet d'un template (styles Elementor inclus) ; chaîne vide
     * si Elementor est absent ou le template supprimé.
     */
    public static function renderTemplate(int $templateId): string
    {
        if (!self::templateExists($templateId)) {
            return '';
        }

        return (string) \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($templateId);
    }

    /**
     * Templates sélectionnables dans l'éditeur de popup.
     *
     * @return array<int, string> id => titre
     */
    public static function templatesList(): array
    {
        if (!self::isActive()) {
            return [];
        }

        $templates = get_posts([
            'post_type' => self::TEMPLATE_POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => 200,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $list = [];

        foreach ($templates as $template) {
            $list[$template->ID] = $template->post_title !== '' ? $template->post_title : ('#' . $template->ID);
        }

        return $list;
    }
}
