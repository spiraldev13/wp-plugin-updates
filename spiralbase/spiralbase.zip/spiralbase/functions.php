<?php

declare(strict_types=1);

/*
 * spiralbase — bootstrap du thème parent.
 * Aucune logique ici : autoload, garde-fous de plancher, démarrage du noyau.
 */

if (!defined('ABSPATH')) {
    exit;
}

/*
 * Défense en profondeur : WordPress refuse déjà l'activation sous les
 * planchers via les en-têtes de style.css (Requires PHP / Requires at least) ;
 * ces gardes couvrent un downgrade PHP ou WordPress survenant APRÈS
 * activation. Seule la couche PHP du thème se retire alors — les templates
 * de blocs restent servis, d'où le libellé des notices. Le textdomain est
 * chargé dans chaque callback : sur ces chemins, le noyau ne démarre pas.
 */
if (version_compare(PHP_VERSION, '8.3', '<')) {
    add_action('admin_notices', static function (): void {
        load_theme_textdomain('spiralbase', get_template_directory() . '/languages');
        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            esc_html__('spiralbase requiert PHP 8.3 ou supérieur — les fonctionnalités PHP du thème sont désactivées, les templates de blocs restent servis.', 'spiralbase')
        );
    });

    return;
}

if (version_compare($GLOBALS['wp_version'], '6.8', '<')) {
    add_action('admin_notices', static function (): void {
        load_theme_textdomain('spiralbase', get_template_directory() . '/languages');
        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            esc_html__('spiralbase requiert WordPress 6.8 ou supérieur — les fonctionnalités PHP du thème sont désactivées, les templates de blocs restent servis.', 'spiralbase')
        );
    });

    return;
}

require_once __DIR__ . '/src/autoload.php';

/*
 * Jamais d'échec silencieux (NFR13) : un noyau introuvable (déploiement
 * incomplet, fichier supprimé) doit se signaler au lieu de fataliser tout
 * le site, admin comprise.
 */
if (!class_exists(SpiralBase\Core\Theme::class)) {
    add_action('admin_notices', static function (): void {
        load_theme_textdomain('spiralbase', get_template_directory() . '/languages');
        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            esc_html__('spiralbase : fichiers du noyau introuvables (installation incomplète ?) — les fonctionnalités PHP du thème sont désactivées.', 'spiralbase')
        );
    });

    return;
}

SpiralBase\Core\Theme::boot();
