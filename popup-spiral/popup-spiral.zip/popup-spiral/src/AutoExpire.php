<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Auto-désactivation optionnelle du toggle « Actif » en fin de planification.
 *
 * Confort visuel uniquement : un popup expiré ne s'affiche JAMAIS de toute façon
 * (`Schedule::isActive` le bloque côté serveur ET côté navigateur, que le cron
 * soit passé ou non). Cette option bascule simplement `spiral_enabled` à `'0'`
 * pour que la liste reflète d'un coup d'œil ce qui est terminé.
 *
 * Désactivée par défaut : une planification expirée est un état *calculé*, tandis
 * que le toggle est une décision *manuelle* — les fusionner ferait perdre cette
 * distinction (réactiver un popup réutilisable resterait toujours possible).
 *
 * Limite de WP-Cron : déclenché par le trafic, il peut ne pas tourner à l'heure
 * exacte sur un site peu visité. C'est pourquoi la sûreté d'affichage n'en
 * dépend pas — l'option n'est qu'un reflet cosmétique.
 */
final class AutoExpire
{
    public const HOOK = 'spiral_auto_disable_expired';

    public const OPTION = 'spiral_auto_disable_expired';

    public static function register(): void
    {
        add_action(self::HOOK, [self::class, 'run']);
        add_action('admin_init', [self::class, 'syncSchedule']);
    }

    public static function isEnabled(): bool
    {
        return (bool) get_option(self::OPTION, false);
    }

    /**
     * Programme ou retire l'événement quotidien selon l'état de l'option.
     */
    public static function syncSchedule(): void
    {
        $scheduled = wp_next_scheduled(self::HOOK);

        if (self::isEnabled() && !$scheduled) {
            wp_schedule_event(time() + MINUTE_IN_SECONDS, 'daily', self::HOOK);
        } elseif (!self::isEnabled() && $scheduled) {
            wp_unschedule_event($scheduled, self::HOOK);
        }
    }

    /**
     * Retire l'événement (désinstallation).
     */
    public static function clearSchedule(): void
    {
        $scheduled = wp_next_scheduled(self::HOOK);

        if ($scheduled) {
            wp_unschedule_event($scheduled, self::HOOK);
        }
    }

    /**
     * Désactive les popups dont la date de fin est passée.
     */
    public static function run(): void
    {
        if (!self::isEnabled()) {
            return;
        }

        $popups = get_posts([
            'post_type' => PostTypes::POPUP,
            'post_status' => 'publish',
            'numberposts' => -1,
            'fields' => 'ids',
        ]);

        $now = Dates::now();

        foreach ($popups as $popupId) {
            if (get_post_meta($popupId, 'spiral_enabled', true) === '0') {
                continue;
            }

            $end = Schedule::parse(Settings::get($popupId)['schedule']['end'] ?? '');

            if ($end !== null && $now > $end) {
                update_post_meta($popupId, 'spiral_enabled', '0');
            }
        }
    }
}
