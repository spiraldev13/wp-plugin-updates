<?php
/**
 * Contrôle « choisir une image dans la médiathèque », partagé par les écrans
 * d'administration du thème : portrait de rédacteur (écran de profil) et
 * visuel publicitaire (Apparence → Publicité).
 *
 * Le contrôle ne connaît ni l'un ni l'autre : il rend un champ caché, un
 * aperçu et deux boutons, que `assets/js/choix-image.js` pilote par attributs
 * de données. Un troisième usage n'ajoutera pas une ligne de JavaScript.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Charge la médiathèque et le script du contrôle. À appeler depuis le hook
 * d'assets de l'écran concerné, jamais globalement.
 */
function techanaRevueChampImageAssets() {
    wp_enqueue_media();
    wp_enqueue_script(
        'techana-revue-choix-image',
        get_theme_file_uri( 'assets/js/choix-image.js' ),
        array( 'jquery' ),
        TECHANA_REVUE_VERSION,
        true
    );
}

/**
 * Rend le contrôle.
 *
 * @param array $args {
 *     @type string $nom     Nom du champ posté (obligatoire).
 *     @type int    $valeur  Identifiant de la pièce jointe sélectionnée, 0 sinon.
 *     @type string $titre   Titre de la fenêtre de médiathèque.
 *     @type string $vide    Texte affiché quand aucune image n'est choisie.
 *     @type string $taille  Taille d'image utilisée pour l'aperçu.
 *     @type int    $cote    Largeur maximale de l'aperçu, en pixels.
 * }
 */
function techanaRevueChampImage( array $args ) {
    $args = wp_parse_args( $args, array(
        'nom'    => '',
        'valeur' => 0,
        'titre'  => 'Choisir une image',
        'vide'   => 'Aucune image choisie.',
        'taille' => 'medium',
        'cote'   => 220,
    ) );
    if ( '' === $args['nom'] ) {
        return;
    }

    $piece  = (int) $args['valeur'];
    $apercu = $piece ? wp_get_attachment_image_url( $piece, $args['taille'] ) : '';
    $id     = 'techana-image-' . sanitize_key( str_replace( array( '[', ']' ), '-', $args['nom'] ) );

    printf(
        '<div data-techana-image data-titre="%s" data-vide="%s" data-cote="%d">',
        esc_attr( $args['titre'] ),
        esc_attr( $args['vide'] ),
        (int) $args['cote']
    );

    echo '<div data-role="apercu" style="margin-bottom:10px">';
    if ( $apercu ) {
        printf(
            '<img src="%s" alt="" style="max-width:%dpx;height:auto;display:block" />',
            esc_url( $apercu ),
            (int) $args['cote']
        );
    } else {
        printf( '<em>%s</em>', esc_html( $args['vide'] ) );
    }
    echo '</div>';

    printf(
        '<input type="hidden" data-role="valeur" id="%s" name="%s" value="%s" />',
        esc_attr( $id ),
        esc_attr( $args['nom'] ),
        esc_attr( (string) $piece )
    );
    printf(
        '<button type="button" class="button" data-role="choisir" id="%s-bouton">Choisir une image</button> ',
        esc_attr( $id )
    );
    printf(
        '<button type="button" class="button-link" data-role="retirer"%s>Retirer</button>',
        $piece ? '' : ' hidden'
    );

    echo '</div>';
}

/**
 * Identifiant de pièce jointe validé : l'entrée doit désigner une image
 * existante de la médiathèque, 0 sinon.
 *
 * @param mixed $valeur Entrée à valider.
 */
function techanaRevueImageValide( $valeur ): int {
    $piece = (int) $valeur;
    if ( $piece <= 0 || 'attachment' !== get_post_type( $piece ) ) {
        return 0;
    }
    return wp_attachment_is_image( $piece ) ? $piece : 0;
}
