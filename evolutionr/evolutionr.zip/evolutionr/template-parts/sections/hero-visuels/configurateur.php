<?php
/**
 * Motif hero « Tarifs » — curseurs / réglages (évoque le configurateur de devis).
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Anciennement `template-parts/sections/tarifs-hero-visuel.php` : le cadre
 * (coins + label + readout) est désormais porté par le composant `.hv`, ce
 * fichier ne rend plus que le contenu. Unités relatives → responsive.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Positions purement décoratives (curseurs figés à des réglages variés).
$sliders = [
    ['name' => 'Pages',         'pos' => 62],
    ['name' => 'Référencement', 'pos' => 40],
    ['name' => 'Maintenance',   'pos' => 76],
    ['name' => 'Hébergement',   'pos' => 30],
];
?>
<div class="hvg-sliders">
    <?php foreach ($sliders as $i => $slider): ?>
        <div class="hvg-slider" style="--pos: <?php echo (int) $slider['pos']; ?>%; --i: <?php echo (int) $i; ?>;">
            <span class="hvg-name"><?php echo esc_html($slider['name']); ?></span>
            <span class="hvg-track"><span class="hvg-handle"></span></span>
        </div>
    <?php endforeach; ?>
</div>

<div class="hvg-estimate">
    <span class="hvg-estimate-label">estimation</span>
    <span class="hvg-estimate-value">en direct</span>
</div>
