#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Permissions WordPress (fichiers 664, dossiers 775)
# Usage: bash droits.sh
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"

source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/load-config.sh"

load_project_config "$PROJECT_ROOT"

# === Verifier le type de projet ===

if [ "$PROJECT_TYPE" != "wordpress-plugin" ] && [ "$PROJECT_TYPE" != "wordpress-theme" ]; then
  error "Cette commande est reservee aux projets WordPress (type actuel : $PROJECT_TYPE)."
  exit 1
fi

# === Detecter l'utilisateur et le groupe web ===

CURRENT_USER="$(whoami)"
OS="$(uname -s)"

case "$OS" in
  Linux)
    WEB_GROUP="www-data"
    ;;
  Darwin)
    WEB_GROUP="_www"
    ;;
  *)
    error "OS non supporte : $OS (attendu : Linux ou Darwin/Mac)."
    exit 1
    ;;
esac

# === Appliquer les permissions ===

echo ""
info "Permissions WordPress : $CURRENT_USER:$WEB_GROUP"
info "Fichiers → 664, Dossiers → 775"
echo ""

sudo chown -R "$CURRENT_USER":"$WEB_GROUP" .
sudo find . -type f -exec chmod 664 {} +
sudo find . -type d -exec chmod 775 {} +

echo ""
ok "Permissions appliquees ($CURRENT_USER:$WEB_GROUP)."
echo ""
