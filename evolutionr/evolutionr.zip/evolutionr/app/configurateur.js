/**
 * Configurateur tarifs Evolution'R — module JS natif autonome.
 *
 * Chargé uniquement sur /tarifs/ via enqueue conditionnel (config-viteJs.php).
 * Données : window.evolutionrPricing (modèle back-office, cf. inc/pricing.php).
 *
 * Parcours :
 *   1. Service principal (catégorie)        → cartes radio
 *   2. Mode (paiement unique / abonnement)   → si plusieurs modes
 *   3. Offre                                 → cartes SÉLECTIONNABLES
 *        (régie : sélecteur de quantité × tarif)
 *   4. Add-ons (sites uniquement)            → groupes à paliers :
 *        - abonnement : palier inclus marqué + upgrade = différence (plancher)
 *        - paiement unique : add-ons optionnels (prix entier)
 *        - SEO toujours optionnel ; + options ponctuelles au forfait
 *   5. Résumé + promotions (best-match, sans cumul)
 *
 * Accessibilité WCAG AA : role=radio, aria-checked, navigation clavier.
 */

import './stylesheets/components/_configurateur.scss';
import {
    pricingData, ADDON_GROUPS, GROUP_LABELS, TVA,
    createState, setDisplayTtc, money,
    serviceModes, currentOffers, currentOffer,
    groupTiers, tierByName,
    isSite, isRegie, hasAddons, optionAllowed,
    baselineTier, resetTiers, rebaseTiers,
    dimensionAddTarget, buildAvantages, compute, buildConfigText,
} from './cfg-pricing.js';
import { reveal, collapse, swapHeight, countUp, prefersReducedMotion } from './cfg-animate.js';

/* ────────────────────────────────────────────────────────────────────
 *  ICÔNES
 * ──────────────────────────────────────────────────────────────────── */

const ICONS = {
    check: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6L9 17l-5-5"/></svg>',
    cross: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 5l7 7-7 7"/></svg>',
};

/* ────────────────────────────────────────────────────────────────────
 *  RENDU
 * ──────────────────────────────────────────────────────────────────── */

function renderServices(root, state) {
    const list = root.querySelector('[data-configurateur-services]');
    if (!list) return;
    // Composition fixe (la liste des services ne change jamais) → on construit une seule
    // fois, puis on ne fait QUE patcher l'état actif. Les boutons persistent → la
    // transition CSS `.is-active` joue d'elle-même, aucun rebuild (donc aucune saccade).
    // Garde sur la présence d'un bouton (et non children.length : le conteneur héberge
    // déjà un <noscript> côté template).
    if (!list.querySelector('[data-service]')) {
        list.setAttribute('role', 'radiogroup');
        list.setAttribute('aria-label', 'Choix du service');
        Object.entries(pricingData.services).forEach(([id, service]) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'cfg-service';
            btn.setAttribute('role', 'radio');
            btn.dataset.service = id;
            btn.innerHTML = `<span class="cfg-service-label">${service.label}</span>`;
            list.appendChild(btn);
        });
    }
    list.querySelectorAll('[data-service]').forEach((btn) => {
        const on = btn.dataset.service === state.service;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-checked', String(on));
    });
}

function renderMode(root, state) {
    const wrap = root.querySelector('[data-configurateur-mode]');
    if (!wrap) return;
    const step = wrap.closest('.cfg-step');

    // 3 « formes » possibles : masquée (régie), message simple (1 seul mode), ou toggle.
    // On ne reconstruit l'intérieur QUE si la forme change (changement de service) ; sinon
    // on patche en place (la pastille glisse via `data-active`, plus de rebuild du toggle
    // à chaque sélection d'offre). `wrap.dataset.shape` mémorise la forme courante.

    // Régie : pas de mode (les unités heure/jour sont des offres). On masque l'étape.
    if (isRegie(state)) {
        if (wrap.dataset.shape !== 'hidden') { wrap.innerHTML = ''; wrap.dataset.shape = 'hidden'; }
        if (step) step.hidden = true;
        return;
    }
    if (step) step.hidden = false;

    const modes = serviceModes(state.service);
    const hasToggle = modes.includes('one_shot') && modes.includes('abonnement');

    if (!hasToggle) {
        const map = {
            abonnement: 'Cette prestation est proposée en abonnement mensuel.',
            one_shot: 'Cette prestation est proposée en paiement unique.',
            horaire: 'Cette prestation est facturée au taux horaire.',
            journalier: 'Cette prestation est facturée à la journée.',
        };
        const shape = `only:${modes[0]}`;
        if (wrap.dataset.shape !== shape) {
            wrap.innerHTML = `<p class="cfg-mode-only">${map[modes[0]] ?? ''}</p>`;
            wrap.dataset.shape = shape;
        }
        return;
    }

    // Toggle : construit une seule fois.
    if (wrap.dataset.shape !== 'toggle') {
        const group = document.createElement('div');
        group.className = 'cfg-mode-switch';
        group.setAttribute('role', 'radiogroup');
        group.setAttribute('aria-label', 'Mode de facturation');
        [
            { id: 'one_shot', label: 'Paiement unique' },
            { id: 'abonnement', label: 'Abonnement mensuel' },
        ].forEach(({ id, label }) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'cfg-mode-option';
            btn.setAttribute('role', 'radio');
            btn.dataset.mode = id;
            btn.textContent = label;
            group.appendChild(btn);
        });
        wrap.innerHTML = '';
        wrap.appendChild(group);
        wrap.dataset.shape = 'toggle';
    }
    // Patch de l'état actif en place (pastille glissante + aria).
    const sw = wrap.querySelector('.cfg-mode-switch');
    if (sw) sw.dataset.active = state.mode;
    wrap.querySelectorAll('[data-mode]').forEach((btn) => {
        const on = btn.dataset.mode === state.mode;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-checked', String(on));
    });
}

function renderOffers(root, state) {
    const list = root.querySelector('[data-configurateur-offers]');
    if (!list) return;
    setDisplayTtc(state.ttc);
    list.setAttribute('role', 'radiogroup');
    list.setAttribute('aria-label', 'Choix de l\'offre');

    const offers = currentOffers(state);
    // Signature du SET courant (service + mode + noms d'offres) : tant qu'elle ne change
    // pas, on ne reconstruit rien → patch en place (sélection + prix HT/TTC). Quand le set
    // change (service/mode), on échange le contenu en animant la hauteur (pas de saut).
    const sig = `${state.service}|${state.mode}|${offers.map((o) => o.name).join('~')}`;
    const first = !list.dataset.sig;

    if (list.dataset.sig === sig) {
        patchOffers(list, state, offers);
        return;
    }
    const build = () => buildOffersInto(list, state, offers);
    if (first) build();           // 1er rendu : aucune animation
    else swapHeight(list, build); // changement de set : transition de hauteur
    list.dataset.sig = sig;
}

/** (Re)construit le contenu de la liste d'offres (cartes + sélecteur régie). */
function buildOffersInto(list, state, offers) {
    if (offers.length === 0) {
        list.innerHTML = '<p class="cfg-empty">Aucune offre pour ce choix. Contactez-nous pour un devis personnalisé.</p>';
        return;
    }
    list.innerHTML = '';
    offers.forEach((offer, index) => {
        const selected = index === state.offerIndex;
        const cardClasses = ['cfg-offer'];
        if (selected) cardClasses.push('is-selected');
        if (offer.featured) cardClasses.push('is-featured');

        const includedList = (offer.included || [])
            .map((item) => `<li>${ICONS.check}<span>${item}</span></li>`)
            .join('');

        // « i » : inclus ✓ + non inclus ✕ — placé hors du bouton (HTML valide).
        const info = infoDisclosure(offer.name, null, offer.included, offer.excluded);

        const item = document.createElement('div');
        item.className = 'cfg-offer-wrap';
        item.innerHTML = `
            <button type="button" class="${cardClasses.join(' ')}" role="radio" aria-checked="${selected}" data-offer="${index}">
                ${offer.featured && offer.badge ? `<span class="cfg-offer-badge">${offer.badge}</span>` : ''}
                <span class="cfg-offer-head">
                    <span class="cfg-offer-name">${offer.name}</span>
                    <span class="cfg-offer-price">${state.ttc && offer.priceLabelTtc ? offer.priceLabelTtc : offer.priceLabel}</span>
                    ${offer.commitment ? `<span class="cfg-offer-meta">${offer.commitment}</span>` : ''}
                    ${offer.delay ? `<span class="cfg-offer-meta cfg-offer-meta--muted">${offer.delay}</span>` : ''}
                </span>
                ${includedList ? `<ul class="cfg-offer-list">${includedList}</ul>` : ''}
            </button>
            ${info.btn}${info.panel}
        `;
        list.appendChild(item);
    });

    // Régie : sélecteur de quantité (unité = celle de l'offre sélectionnée).
    if (isRegie(state)) {
        const selected = currentOffer(state);
        const label = selected && selected.unit === 'journalier' ? 'Nombre de jours' : "Nombre d'heures";
        const qty = document.createElement('div');
        qty.className = 'cfg-regie-qty';
        qty.innerHTML = `
            <label for="cfg-regie-input">${label}</label>
            <input id="cfg-regie-input" type="number" min="1" step="1" value="${state.regieQty}" data-regie-qty>
        `;
        list.appendChild(qty);
    }
}

/** Set d'offres inchangé : patch sélection + prix (HT/TTC) en place, sans rebuild. */
function patchOffers(list, state, offers) {
    list.querySelectorAll('[data-offer]').forEach((btn) => {
        const index = Number(btn.dataset.offer);
        const offer = offers[index];
        const on = index === state.offerIndex;
        btn.classList.toggle('is-selected', on);
        btn.setAttribute('aria-checked', String(on));
        if (offer) {
            const priceEl = btn.querySelector('.cfg-offer-price');
            if (priceEl) priceEl.textContent = state.ttc && offer.priceLabelTtc ? offer.priceLabelTtc : offer.priceLabel;
        }
    });
    if (isRegie(state)) {
        const sel = currentOffer(state);
        const label = list.querySelector('.cfg-regie-qty label');
        if (label) label.textContent = sel && sel.unit === 'journalier' ? 'Nombre de jours' : "Nombre d'heures";
    }
}

function renderAddons(root, state) {
    const wrap = root.querySelector('[data-configurateur-options]');
    if (!wrap) return;
    setDisplayTtc(state.ttc);
    const step = wrap.closest('.cfg-step');

    // Étape add-ons : sites neufs, ET dès que le Pack M+H est en jeu (serveur/migration),
    // y compris en service direct « Maintenance + Hébergement ».
    const site = isSite(state);
    const visible = hasAddons(state);
    if (!visible) {
        // Étape non pertinente : on replie ce qui reste (en douceur) puis on masque.
        const blocks = [...wrap.children].filter((el) => el.dataset.key);
        if (blocks.length && !prefersReducedMotion()) {
            let pending = blocks.length;
            blocks.forEach((el) => collapse(el, { remove: true, onDone: () => { if (--pending === 0 && step) step.hidden = true; } }));
        } else {
            wrap.innerHTML = '';
            if (step) step.hidden = true;
        }
        wrap.dataset.ready = '';
        return;
    }
    if (step) step.hidden = false;
    const first = !wrap.dataset.ready; // 1er affichage de l'étape → pas d'animation d'entrée
    wrap.dataset.ready = '1';

    // Options du contexte courant, regroupées par famille.
    const allowedOpts = Object.entries(pricingData.options || {})
        .filter(([, opt]) => optionAllowed(state, opt));
    const byFamily = (fam) => allowedOpts.filter(([, o]) => (o.family || 'service') === fam);

    // Liste ORDONNÉE des blocs voulus (clé stable + create + update). Le reconcile gère
    // l'apparition (reveal) / la disparition (collapse) ; les blocs persistants sont
    // patchés en place (jamais reconstruits → 0 « re-clignote » sur HT/TTC, offre, etc.).
    const blocks = [];
    if (site) {
        ADDON_GROUPS.forEach((group) => {
            if (groupTiers(group).length === 0) return;
            blocks.push({
                key: `group:${group}`,
                create: () => buildGroupBlock(group, state),
                update: (el) => patchGroupBlock(el, group, state),
            });
            // Améliorations serveur + migration rattachées au Pack M+H (juste sous M+H).
            if (group === 'maintenance_hebergee') pushPackMHBlocks(blocks, byFamily, state);
        });
        const serviceOpts = byFamily('service');
        if (serviceOpts.length) {
            blocks.push({
                key: 'options:service',
                create: () => buildOptBlock(serviceOpts, 'Options ponctuelles', '', '', state),
                update: (el) => patchOptBlock(el, state),
            });
        }
    } else {
        // Service direct « Maintenance + Hébergement » : seulement les rattachées.
        pushPackMHBlocks(blocks, byFamily, state);
    }

    reconcileBlocks(wrap, blocks, first);
}

/** Ajoute les blocs « Amélioration serveur » (exclusif) + « Migration » du Pack M+H. */
function pushPackMHBlocks(blocks, byFamily, state) {
    const serveur = byFamily('serveur');
    if (serveur.length) {
        blocks.push({
            key: 'sub:serveur',
            create: () => buildOptBlock(serveur, 'Amélioration serveur', ' data-option-family="serveur"', 'cfg-serveurs cfg-addon-sub', state),
            update: (el) => patchOptBlock(el, state),
        });
    }
    const migration = byFamily('migration');
    if (migration.length) {
        blocks.push({
            key: 'sub:migration',
            create: () => buildOptBlock(migration, 'Migration', '', 'cfg-addon-sub', state),
            update: (el) => patchOptBlock(el, state),
        });
    }
}

/**
 * Réconcilie les blocs de 1er niveau d'un conteneur sur la liste voulue (par `key`) :
 *  clé conservée → update en place · clé nouvelle → create + reveal · clé disparue →
 *  collapse + retrait. Les blocs persistants ne sont JAMAIS reconstruits.
 */
function reconcileBlocks(container, blocks, noAnim) {
    const wanted = new Set(blocks.map((b) => b.key));
    const existing = new Map();
    [...container.children].forEach((el) => { if (el.dataset.key) existing.set(el.dataset.key, el); });

    // Sorties (clés présentes mais plus voulues).
    existing.forEach((el, k) => {
        if (!wanted.has(k)) {
            existing.delete(k);
            el.dataset.key = ''; // exclu du chaînage d'ordre ci-dessous (peut encore animer)
            if (noAnim || prefersReducedMotion()) el.remove();
            else collapse(el, { remove: true });
        }
    });

    // Entrées (create + reveal) et mises à jour (update), dans l'ordre voulu.
    let prev = null;
    blocks.forEach((b) => {
        let el = existing.get(b.key);
        if (el) {
            if (b.update) b.update(el);
        } else {
            el = b.create();
            el.dataset.key = b.key;
            container.insertBefore(el, prev ? prev.nextSibling : container.firstChild);
            if (!noAnim && !prefersReducedMotion()) reveal(el);
        }
        prev = el;
    });
}

/* ─── Add-ons : construction + patch des blocs (réutilisés par le reconcile) ─── */

/** Une option ponctuelle (case à cocher + prix + « i »). */
function buildOptionItem(key, opt, familyAttr, state) {
    const checked = state.ponctuelles.has(key) ? 'checked' : '';
    const suffix = opt.type === 'monthly' ? '/mois' : '';
    const priceHtml = opt.surDevis ? opt.priceLabel : `+ ${money(opt.price)}${suffix}`;
    const info = infoDisclosure(opt.label, opt.descriptionDetail, null);
    const item = document.createElement('div');
    item.className = 'cfg-ponctuelle-wrap';
    item.innerHTML = `
                <label class="cfg-ponctuelle">
                    <input type="checkbox" data-ponctuelle="${key}"${familyAttr} ${checked}>
                    <span class="cfg-ponctuelle-body">
                        <span class="cfg-ponctuelle-name">${opt.label}</span>
                        ${opt.description ? `<span class="cfg-tier-desc">${opt.description}</span>` : ''}
                    </span>
                    <span class="cfg-ponctuelle-price">${priceHtml}</span>
                </label>
                ${info.btn}
                ${info.panel}
            `;
    return item;
}

/** Un bloc d'options (titre + items) — serveur / migration / options de service. */
function buildOptBlock(items, title, familyAttr, extraClass, state) {
    const block = document.createElement('div');
    block.className = 'cfg-ponctuelles' + (extraClass ? ` ${extraClass}` : '');
    block.innerHTML = `<h4 class="cfg-addon-title">${title}</h4>`;
    items.forEach(([key, opt]) => block.appendChild(buildOptionItem(key, opt, familyAttr, state)));
    return block;
}

/** Bloc d'options persistant : patch cases cochées + prix (HT/TTC) en place. */
function patchOptBlock(el, state) {
    el.querySelectorAll('[data-ponctuelle]').forEach((input) => {
        const key = input.dataset.ponctuelle;
        const opt = pricingData.options[key];
        input.checked = state.ponctuelles.has(key);
        if (opt && !opt.surDevis) {
            const priceEl = input.closest('.cfg-ponctuelle')?.querySelector('.cfg-ponctuelle-price');
            if (priceEl) {
                const suffix = opt.type === 'monthly' ? '/mois' : '';
                priceEl.textContent = `+ ${money(opt.price)}${suffix}`;
            }
        }
    });
}

/** Un groupe d'add-ons à paliers (Maintenance + Hébergement, SEO). */
function buildGroupBlock(group, state) {
    const recurringTiers = groupTiers(group).filter((t) => t.recurring);
    const ponctualTiers = groupTiers(group).filter((t) => !t.recurring);
    const base = baselineTier(state, group);
    const selected = state.tiers[group] || null;

    const block = document.createElement('div');
    block.className = 'cfg-addon-group';
    block.dataset.group = group; // cible de scroll pour l'upsell « + Ajouter »

    const optionalHint = (state.mode !== 'abonnement' || group === 'seo')
        ? '<span class="cfg-addon-hint">Optionnel</span>'
        : '';
    let html = `<h4 class="cfg-addon-title">${GROUP_LABELS[group]} ${optionalHint}</h4>`;

    // Paliers récurrents = choix unique (radio).
    if (recurringTiers.length > 0) {
        const baseIndex = base ? recurringTiers.findIndex((t) => t.name === base) : -1;
        const rows = recurringTiers.map((tier, i) => {
            const isIncluded = base && tier.name === base;
            const isBelowFloor = base ? i < baseIndex : false; // plancher
            const isSelected = selected === tier.name || (state.mode === 'abonnement' && group !== 'seo' && base && !selected && tier.name === base);
            const classes = ['cfg-tier'];
            if (isSelected) classes.push('is-selected');
            if (isIncluded) classes.push('is-included');
            if (isBelowFloor) classes.push('is-disabled');

            let priceTag;
            if (isIncluded) priceTag = 'inclus';
            else if (isBelowFloor) priceTag = '—';
            else if (state.mode === 'abonnement' && group !== 'seo' && base) {
                const delta = tier.price - (tierByName(group, base)?.price || 0);
                priceTag = `+ ${money(delta)}/mois`;
            } else {
                priceTag = `+ ${money(tier.price)}/mois`;
            }

            const btn = `
                    <button type="button" class="${classes.join(' ')}" role="radio"
                            aria-checked="${isSelected ? 'true' : 'false'}"
                            ${isBelowFloor ? 'disabled aria-disabled="true"' : ''}
                            data-tier-group="${group}" data-tier-name="${tier.name}">
                        <span class="cfg-tier-name">${tier.name}</span>
                        <span class="cfg-tier-price">${priceTag}</span>
                    </button>`;
            return tierWrap(btn, tier);
        }).join('');
        html += `<div class="cfg-tiers" role="radiogroup" aria-label="${GROUP_LABELS[group]}">${rows}</div>`;
    }

    // Paliers ponctuels = cases cumulables (ex. Audit SEO, ajoutable en plus d'un pack).
    if (ponctualTiers.length > 0) {
        const rows = ponctualTiers.map((tier) => {
            const checked = state.extras.has(tier.name);
            const btn = `
                    <button type="button" class="cfg-tier cfg-tier--checkbox ${checked ? 'is-selected' : ''}"
                            role="checkbox" aria-checked="${checked ? 'true' : 'false'}"
                            data-extra-name="${tier.name}">
                        <span class="cfg-tier-name">${tier.name}</span>
                        <span class="cfg-tier-price">+ ${money(tier.price)}</span>
                    </button>`;
            return tierWrap(btn, tier);
        }).join('');
        html += `<div class="cfg-tiers cfg-tiers--ponctuel">${rows}</div>`;
    }

    block.innerHTML = html;
    return block;
}

/** Groupe persistant : patch sélection / inclus / plancher + prix (mode, HT/TTC) en place. */
function patchGroupBlock(el, group, state) {
    const recurring = groupTiers(group).filter((t) => t.recurring);
    const base = baselineTier(state, group);
    const selected = state.tiers[group] || null;
    const baseIndex = base ? recurring.findIndex((t) => t.name === base) : -1;

    // Indice « Optionnel » (dépend du mode).
    const titleEl = el.querySelector('.cfg-addon-title');
    if (titleEl) {
        const showHint = state.mode !== 'abonnement' || group === 'seo';
        let hint = titleEl.querySelector('.cfg-addon-hint');
        if (showHint && !hint) {
            titleEl.appendChild(document.createTextNode(' '));
            hint = document.createElement('span');
            hint.className = 'cfg-addon-hint';
            hint.textContent = 'Optionnel';
            titleEl.appendChild(hint);
        } else if (!showHint && hint) {
            hint.remove();
        }
    }

    // Paliers récurrents.
    el.querySelectorAll('[data-tier-group]').forEach((btn) => {
        const i = recurring.findIndex((t) => t.name === btn.dataset.tierName);
        const tier = recurring[i];
        if (!tier) return;
        const isIncluded = !!(base && tier.name === base);
        const isBelowFloor = base ? i < baseIndex : false;
        const isSelected = selected === tier.name || (state.mode === 'abonnement' && group !== 'seo' && base && !selected && tier.name === base);
        btn.classList.toggle('is-selected', !!isSelected);
        btn.classList.toggle('is-included', isIncluded);
        btn.classList.toggle('is-disabled', isBelowFloor);
        btn.setAttribute('aria-checked', isSelected ? 'true' : 'false');
        if (isBelowFloor) { btn.setAttribute('disabled', ''); btn.setAttribute('aria-disabled', 'true'); }
        else { btn.removeAttribute('disabled'); btn.removeAttribute('aria-disabled'); }
        const priceEl = btn.querySelector('.cfg-tier-price');
        if (priceEl) {
            let priceTag;
            if (isIncluded) priceTag = 'inclus';
            else if (isBelowFloor) priceTag = '—';
            else if (state.mode === 'abonnement' && group !== 'seo' && base) {
                priceTag = `+ ${money(tier.price - (tierByName(group, base)?.price || 0))}/mois`;
            } else {
                priceTag = `+ ${money(tier.price)}/mois`;
            }
            priceEl.textContent = priceTag;
        }
    });

    // Paliers ponctuels cumulables (ex. Audit SEO).
    el.querySelectorAll('[data-extra-name]').forEach((btn) => {
        const tier = tierByName(group, btn.dataset.extraName);
        const on = state.extras.has(btn.dataset.extraName);
        btn.classList.toggle('is-selected', on);
        btn.setAttribute('aria-checked', on ? 'true' : 'false');
        const priceEl = btn.querySelector('.cfg-tier-price');
        if (tier && priceEl) priceEl.textContent = `+ ${money(tier.price)}`;
    });
}

/**
 * Icône « i » + bulle tooltip (ouverture au survol/focus, repli au clic tactile).
 * Liste « inclus » (✓) et, optionnellement, liste « non inclus » (✕).
 */
function infoDisclosure(title, detailText, includedList, excludedList) {
    const listOf = (items, cls, icon) => (items && items.length)
        ? `<ul class="cfg-tip-list ${cls}">${items.map((i) => `<li>${icon}<span>${i}</span></li>`).join('')}</ul>`
        : '';
    const inc = listOf(includedList, 'cfg-tip-list--inc', ICONS.check);
    const exc = listOf(excludedList, 'cfg-tip-list--exc', ICONS.cross);
    const para = detailText ? `<p>${detailText}</p>` : '';
    if (!inc && !exc && !para) return { btn: '', panel: '' };
    return {
        btn: `<span class="cfg-info-wrap">
                <button type="button" class="cfg-info" data-info aria-label="Plus d'infos : ${title}">i</button>
                <span class="cfg-tip" role="tooltip">
                    <span class="cfg-tip__inner">${para}${inc}${exc}</span>
                    <span class="cfg-tip__arrow"></span>
                </span>
              </span>`,
        panel: '',
    };
}

/** Enveloppe un palier dans un wrapper avec son icône « i » (HTML valide : i hors du bouton). */
function tierWrap(buttonHtml, tier) {
    const info = infoDisclosure(tier.name, null, tier.included);
    return `<div class="cfg-tier-wrap">${buttonHtml}${info.btn}${info.panel}</div>`;
}

/** Construit le squelette du résumé une seule fois (les sections sont ensuite patchées). */
function ensureSummary(wrap) {
    if (wrap.dataset.skeleton === '1') return;
    wrap.dataset.skeleton = '1';
    wrap.innerHTML = `
        <p class="cfg-summary-empty" hidden>Sélectionnez une offre pour voir le récapitulatif.</p>
        <div class="cfg-summary-head">
            <h3 class="cfg-summary-title">Votre configuration</h3>
            <div class="cfg-ht-ttc" role="radiogroup" aria-label="Affichage des prix">
                <button type="button" class="cfg-ht-ttc-opt" role="radio" data-ttc="0">HT</button>
                <button type="button" class="cfg-ht-ttc-opt" role="radio" data-ttc="1">TTC</button>
            </div>
        </div>
        <div class="cfg-summary-list"></div>
        <div class="cfg-summary-totals"></div>
        <div class="cfg-avantages" hidden>
            <h4 class="cfg-avantages-title">Vos avantages</h4>
            <ul class="cfg-avantages-list"></ul>
        </div>
        <p class="cfg-summary-tva"></p>
        <a class="cfg-summary-cta btn btn-primary" href="#cfg-devis">
            <span>Recevoir ce devis</span>${ICONS.arrow}
        </a>
    `;
}

function renderSummary(root, state) {
    const wrap = root.querySelector('[data-configurateur-summary]');
    if (!wrap) return;
    setDisplayTtc(state.ttc);
    ensureSummary(wrap);

    const { lines, promo, oneShot, monthly, payOneShot, payMonthly } = compute(state);
    const empty = wrap.querySelector('.cfg-summary-empty');
    const head = wrap.querySelector('.cfg-summary-head');
    const listEl = wrap.querySelector('.cfg-summary-list');
    const totalsEl = wrap.querySelector('.cfg-summary-totals');
    const avWrap = wrap.querySelector('.cfg-avantages');
    const avList = wrap.querySelector('.cfg-avantages-list');
    const tvaEl = wrap.querySelector('.cfg-summary-tva');
    const cta = wrap.querySelector('.cfg-summary-cta');

    // État vide (aucune offre) : message seul, le reste masqué.
    if (lines.length === 0) {
        empty.hidden = false;
        [head, listEl, totalsEl, avWrap, tvaEl, cta].forEach((el) => { if (el) el.hidden = true; });
        wrap.dataset.built = '';
        fillDevisField(state);
        return;
    }
    const first = wrap.dataset.built !== '1'; // 1re construction réelle → pas d'animation d'entrée
    empty.hidden = true;
    [head, listEl, totalsEl, tvaEl, cta].forEach((el) => { if (el) el.hidden = false; });

    // HT / TTC : état actif.
    wrap.querySelectorAll('[data-ttc]').forEach((b) => {
        const on = (b.dataset.ttc === '1') === !!state.ttc;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-checked', String(on));
    });

    // Lignes : reconcile par libellé (entrée reveal / sortie collapse / persistant patch).
    reconcileBlocks(listEl, lines.map((l) => ({
        key: l.label,
        create: () => buildSumRow(l),
        update: (el) => patchSumRow(el, l),
    })), first);

    // Totaux : paiement unique / mensuel (entrée/sortie + count-up du nombre).
    const totalDefs = [];
    if (oneShot > 0) totalDefs.push({ key: 'oneShot', label: 'Total paiement unique', original: oneShot, discounted: payOneShot, suffix: '', promo });
    if (monthly > 0) totalDefs.push({ key: 'monthly', label: 'Total mensuel', original: monthly, discounted: payMonthly, suffix: '<span class="cfg-summary-suffix">/mois</span>', promo });
    reconcileBlocks(totalsEl, totalDefs.map((d) => ({
        key: d.key,
        create: () => buildTotalRow(d),
        update: (el) => patchTotalRow(el, d),
    })), first);

    // Avantages : reconcile des paliers + ouverture/fermeture animée du bloc.
    const savedText = (() => {
        if (!promo) return '';
        const parts = [];
        const sOne = Math.round(oneShot) - Math.round(payOneShot);
        const sMonth = Math.round(monthly) - Math.round(payMonthly);
        if (sOne > 0) parts.push(money(sOne));
        if (sMonth > 0) parts.push(`${money(sMonth)}/mois`);
        return parts.length ? `Vous économisez ${parts.join(' + ')}` : '';
    })();
    const avRows = buildAvantages(state, promo).filter((a) => a.acquired || a.actionable);
    const avDefs = avRows.map((a) => ({
        key: a.label,
        create: () => buildAvRow(a, savedText),
        update: (el) => patchAvRow(el, a, savedText),
    }));
    if (avRows.length) {
        const wasHidden = avWrap.hidden || avWrap.dataset.collapsed === '1';
        if (wasHidden) {
            // Bloc fermé → on le REMPLIT d'abord (sans animer chaque ligne), PUIS on ouvre
            // le bloc entier (sinon `reveal` mesurerait une hauteur vide).
            reconcileBlocks(avList, avDefs, true);
            setBlockVisible(avWrap, true, !first);
        } else {
            reconcileBlocks(avList, avDefs, first); // déjà ouvert → on anime les lignes
        }
    } else {
        setBlockVisible(avWrap, false, !first, () => { avList.innerHTML = ''; });
    }

    if (tvaEl) tvaEl.textContent = state.ttc ? `Prix TTC (TVA ${TVA} %)` : 'Prix hors taxes (HT)';

    wrap.dataset.built = '1';
    fillDevisField(state);
}

/* ─── Résumé : lignes ─── */
function buildSumRow(l) {
    const row = document.createElement('div');
    row.className = 'cfg-sum-row' + (l.muted ? ' is-muted' : '');
    row.innerHTML = `<span class="cfg-sum-k">${l.label}</span><span class="cfg-sum-v">${l.value}</span>`;
    return row;
}
function patchSumRow(el, l) {
    el.classList.toggle('is-muted', !!l.muted);
    const v = el.querySelector('.cfg-sum-v');
    if (v) v.textContent = l.value;
}

/* ─── Résumé : totaux (count-up du nombre, prix barré si promo) ─── */
function buildTotalRow(d) {
    const row = document.createElement('div');
    row.className = 'cfg-summary-total';
    const showStrike = d.promo && d.discounted < d.original;
    const to = Math.round(d.discounted);
    row.innerHTML = `<span>${d.label}</span><strong>${showStrike ? `<span class="cfg-strike">${money(d.original)}${d.suffix}</span>` : ''}<span class="cfg-total-num">${money(to)}</span>${d.suffix}</strong>`;
    row.querySelector('.cfg-total-num')._cfgVal = to;
    return row;
}
function patchTotalRow(el, d) {
    const strong = el.querySelector('strong');
    const num = el.querySelector('.cfg-total-num');
    const showStrike = d.promo && d.discounted < d.original;
    let strike = strong.querySelector('.cfg-strike');
    if (showStrike) {
        if (!strike) { strike = document.createElement('span'); strike.className = 'cfg-strike'; strong.insertBefore(strike, strong.firstChild); }
        strike.innerHTML = `${money(d.original)}${d.suffix}`;
    } else if (strike) {
        strike.remove();
    }
    const to = Math.round(d.discounted);
    if (num) { countUp(num, num._cfgVal, to, (v) => money(v)); num._cfgVal = to; }
}

/* ─── Résumé : échelle « Vos avantages » ─── */
function avStateClass(a) {
    return a.applied ? 'is-applied' : a.acquired ? 'is-acquired' : 'is-locked';
}
function avRowInner(a, savedText) {
    const icon = a.acquired ? ICONS.check : '<span class="cfg-av-dot">+</span>';
    const action = a.acquired ? '' : a.missing
        .filter((m) => m.target)
        .map((m) => `<button type="button" class="cfg-av-add" data-add-family="${m.family}">${ICONS.arrow}<span>Ajouter ${m.label}</span></button>`)
        .join('');
    const note = a.applied && savedText ? `<span class="cfg-av-save">${savedText}</span>` : '';
    return `
                <span class="cfg-av-line">
                    <span class="cfg-av-state">${icon}</span>
                    <span class="cfg-av-label">${a.label}</span>
                    <span class="cfg-av-pct">−${a.pct} %</span>
                </span>
                ${action}${note}`;
}
function buildAvRow(a, savedText) {
    const li = document.createElement('li');
    li.className = `cfg-av ${avStateClass(a)}`;
    li.innerHTML = avRowInner(a, savedText);
    return li;
}
/** Patch EN PLACE (la ligne et la pastille % persistent → le surlignage transitionne). */
function patchAvRow(el, a, savedText) {
    el.classList.remove('is-applied', 'is-acquired', 'is-locked');
    el.classList.add(avStateClass(a));
    const stateEl = el.querySelector('.cfg-av-state');
    if (stateEl) stateEl.innerHTML = a.acquired ? ICONS.check : '<span class="cfg-av-dot">+</span>';
    const pct = el.querySelector('.cfg-av-pct');
    if (pct) pct.textContent = `−${a.pct} %`;
    const label = el.querySelector('.cfg-av-label');
    if (label) label.textContent = a.label;
    // Boutons « Ajouter » + note d'économie : régénérés (présents selon l'état).
    el.querySelectorAll('.cfg-av-add, .cfg-av-save').forEach((n) => n.remove());
    const action = a.acquired ? '' : a.missing
        .filter((m) => m.target)
        .map((m) => `<button type="button" class="cfg-av-add" data-add-family="${m.family}">${ICONS.arrow}<span>Ajouter ${m.label}</span></button>`)
        .join('');
    const note = a.applied && savedText ? `<span class="cfg-av-save">${savedText}</span>` : '';
    if (action || note) {
        const tpl = document.createElement('template');
        tpl.innerHTML = `${action}${note}`;
        el.appendChild(tpl.content);
    }
}

/** Affiche / replie un bloc (le conteneur « Vos avantages ») en animant, sans le retirer. */
function setBlockVisible(el, show, animate, onHidden) {
    if (!el) return;
    const collapsed = el.dataset.collapsed === '1';
    if (show) {
        if (el.hidden || collapsed) {
            delete el.dataset.collapsed;
            if (animate) reveal(el); // reveal nettoie hidden + styles inline
            else el.hidden = false;
        }
    } else if (!el.hidden && !collapsed) {
        if (animate) collapse(el, { remove: false, onDone: () => { el.hidden = true; el.dataset.collapsed = '1'; if (onHidden) onHidden(); } });
        else { el.hidden = true; el.dataset.collapsed = '1'; if (onHidden) onHidden(); }
    } else if (onHidden) {
        onHidden();
    }
}

/** Renseigne le champ caché « your-config » du formulaire de devis CF7. */
function fillDevisField(state) {
    const field = document.querySelector('[name="your-config"]');
    if (field) field.value = buildConfigText(state);
}

function renderAll(root, state) {
    renderServices(root, state);
    renderMode(root, state);
    renderOffers(root, state);
    renderAddons(root, state);
    renderSummary(root, state);
}

/* ────────────────────────────────────────────────────────────────────
 *  ÉVÉNEMENTS
 * ──────────────────────────────────────────────────────────────────── */

function attachEvents(root, state) {
    root.addEventListener('click', (event) => {
        // Icône « i » : bascule la bulle (tactile). Au survol/focus, c'est le CSS qui l'ouvre.
        const infoBtn = event.target.closest('[data-info]');
        if (infoBtn) {
            const tip = infoBtn.parentElement.querySelector('.cfg-tip');
            if (tip) tip.classList.toggle('is-open');
            return;
        }

        // Upsell « + Ajouter <famille> » : ajoute la famille puis scrolle vers son bloc.
        const addFamilyBtn = event.target.closest('[data-add-family]');
        if (addFamilyBtn) {
            const family = addFamilyBtn.dataset.addFamily; // dimension : slug | opt:<clé> | add:<nom>
            const target = dimensionAddTarget(state, family);
            if (target) {
                if (target.kind === 'tier') state.tiers[target.group] = target.name;
                else if (target.kind === 'option') state.ponctuelles.add(target.key);
                else state.extras.add(target.name); // kind 'extra'
                renderAll(root, state);
                // Scroll vers le groupe (tier/extra) ou, pour une option, vers la zone d'options.
                smoothScrollTo(root.querySelector(`[data-group="${family}"]`)
                    || root.querySelector('[data-configurateur-options]'));
            }
            return;
        }

        const serviceBtn = event.target.closest('[data-service]');
        if (serviceBtn) {
            const id = serviceBtn.dataset.service;
            if (id && pricingData.services[id]) {
                state.service = id;
                if (!serviceModes(id).includes(state.mode)) state.mode = serviceModes(id)[0];
                state.offerIndex = 0;
                state.ponctuelles.clear();
                state.extras.clear();
                state.regieQty = 1;
                resetTiers(state);
                renderAll(root, state);
            }
            return;
        }

        const modeBtn = event.target.closest('[data-mode]');
        if (modeBtn) {
            const m = modeBtn.dataset.mode;
            if (m && m !== state.mode && serviceModes(state.service).includes(m)) {
                state.mode = m;
                state.offerIndex = 0;
                resetTiers(state);
                renderMode(root, state);     // pastille glisse (patch en place)
                renderOffers(root, state);   // set d'offres différent → swapHeight (pas de saut)
                renderAddons(root, state);   // reconcile (prix/hints + présence M+H)
                renderSummary(root, state);
            }
            return;
        }

        const offerBtn = event.target.closest('[data-offer]');
        if (offerBtn) {
            state.offerIndex = Number(offerBtn.dataset.offer) || 0;
            rebaseTiers(state); // garde les add-ons, recale juste les planchers
            renderAll(root, state);
            return;
        }

        const tierBtn = event.target.closest('[data-tier-group]');
        if (tierBtn && !tierBtn.disabled) {
            const group = tierBtn.dataset.tierGroup;
            const name = tierBtn.dataset.tierName;
            const base = baselineTier(state, group);
            const optional = state.mode !== 'abonnement' || group === 'seo' || !base;
            // Optionnel : clic = bascule. Inclus/upgrade : clic = sélection (jamais sous le plancher).
            if (optional && state.tiers[group] === name) delete state.tiers[group];
            else state.tiers[group] = name;
            // Le reconcile gère tout : si la présence du Pack M+H change, les sous-panneaux
            // serveur/migration s'ouvrent (reveal) ou se replient (collapse) ; sinon la
            // sélection est patchée en place (la bordure cyan transitionne, pas de rebuild).
            renderAddons(root, state);
            renderSummary(root, state);
            return;
        }

        // Add-on ponctuel cumulable (ex. Audit SEO) : bascule.
        const extraBtn = event.target.closest('[data-extra-name]');
        if (extraBtn) {
            const name = extraBtn.dataset.extraName;
            if (state.extras.has(name)) state.extras.delete(name);
            else state.extras.add(name);
            renderAddons(root, state);
            renderSummary(root, state);
            return;
        }

        // Bascule HT / TTC : tous les prix affichés se recalculent.
        const ttcBtn = event.target.closest('[data-ttc]');
        if (ttcBtn) {
            state.ttc = ttcBtn.dataset.ttc === '1';
            renderOffers(root, state);
            renderAddons(root, state);
            renderSummary(root, state);
            return;
        }
    });

    root.addEventListener('change', (event) => {
        const opt = event.target.closest('[data-ponctuelle]');
        if (opt) {
            const key = opt.dataset.ponctuelle;
            if (opt.checked) {
                // Niveaux serveur exclusifs (R2) : on retire les autres de l'état ; le
                // reconcile patchera leurs cases (le panneau M+H ne se reconstruit pas).
                if (opt.dataset.optionFamily === 'serveur') {
                    root.querySelectorAll('[data-option-family="serveur"]').forEach((el) => {
                        if (el !== opt) state.ponctuelles.delete(el.dataset.ponctuelle);
                    });
                }
                state.ponctuelles.add(key);
            } else {
                state.ponctuelles.delete(key);
            }
            renderAddons(root, state); // reflète l'exclusivité serveur (patch en place)
            renderSummary(root, state);
        }
    });

    root.addEventListener('input', (event) => {
        const qty = event.target.closest('[data-regie-qty]');
        if (qty) {
            state.regieQty = Math.max(1, parseInt(qty.value, 10) || 1);
            renderSummary(root, state);
        }
    });

    root.addEventListener('keydown', (event) => {
        const target = event.target;
        if (!target.closest('[data-configurateur-services], [data-configurateur-mode]')) return;
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            navigateRadioGroup(target, 1);
        } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            navigateRadioGroup(target, -1);
        }
    });
}

function navigateRadioGroup(currentBtn, direction) {
    const group = currentBtn.closest('[role="radiogroup"]');
    if (!group) return;
    const items = Array.from(group.querySelectorAll('[role="radio"]'));
    const index = items.indexOf(currentBtn);
    if (index < 0) return;
    const next = items[(index + direction + items.length) % items.length];
    if (next) {
        next.focus();
        next.click();
    }
}

/**
 * Scroll souple vers un élément — réplique l'amorti du « retour en haut » du
 * thème (désactive le scroll-behavior CSS, anime frame par frame en easeOutQuint),
 * décalé de la hauteur du header sticky. scrollIntoView natif sautait sec après
 * le re-rendu du DOM.
 */
function smoothScrollTo(el) {
    if (!el) return;
    const header = document.querySelector('.header');
    const offset = (header ? header.offsetHeight : 0) + 12;
    const start = window.scrollY || window.pageYOffset;
    const end = Math.max(0, el.getBoundingClientRect().top + start - offset);
    const distance = end - start;
    if (Math.abs(distance) < 2) return;

    document.documentElement.style.scrollBehavior = 'auto';
    const ease = (t) => 1 - Math.pow(1 - t, 5);
    const duration = Math.min(2000, Math.max(500, Math.abs(distance) * 0.7));
    const startTime = performance.now();
    const stepFrame = (now) => {
        const p = Math.min((now - startTime) / duration, 1);
        window.scrollTo(0, start + distance * ease(p));
        if (p < 1) requestAnimationFrame(stepFrame);
        else document.documentElement.style.scrollBehavior = '';
    };
    requestAnimationFrame(stepFrame);
}

/* ────────────────────────────────────────────────────────────────────
 *  POINT D'ENTRÉE
 * ──────────────────────────────────────────────────────────────────── */

function renderConfigurateur(root) {
    const serviceIds = Object.keys(pricingData.services);
    if (serviceIds.length === 0) {
        const wrap = root.querySelector('[data-configurateur-services]') || root;
        wrap.innerHTML = '<p class="cfg-empty">Nos tarifs sont en cours de mise à jour. Contactez-nous pour un devis personnalisé.</p>';
        return;
    }

    const state = createState();
    const params = new URLSearchParams(window.location.search);

    const presetService = params.get('service');
    if (presetService && pricingData.services[presetService]) state.service = presetService;
    if (!pricingData.services[state.service]) state.service = serviceIds[0];

    const modes = serviceModes(state.service);
    const presetMode = params.get('mode');
    if (presetMode && modes.includes(presetMode)) state.mode = presetMode;
    else if (!modes.includes(state.mode)) state.mode = modes[0];

    // Pré-sélection d'offre par index ou par nom.
    const presetOffer = params.get('offer');
    if (presetOffer) {
        const offers = currentOffers(state);
        const byIndex = Number(presetOffer);
        if (!Number.isNaN(byIndex) && offers[byIndex]) {
            state.offerIndex = byIndex;
        } else {
            const idx = offers.findIndex((o) => o.name === presetOffer);
            if (idx >= 0) state.offerIndex = idx;
        }
    }

    resetTiers(state);
    renderAll(root, state);
    attachEvents(root, state);
}

document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('[data-configurateur]');
    if (root) renderConfigurateur(root);
});
