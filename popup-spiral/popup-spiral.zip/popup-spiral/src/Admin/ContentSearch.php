<?php

namespace Spiral\Admin;

use Spiral\Designs\CssGenerator;
use Spiral\Designs\Repository;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Points AJAX de l'admin : recherche de contenus pour le ciblage
 * et CSS d'aperçu live pour le créateur de designs.
 */
final class ContentSearch
{
    public static function register(): void
    {
        add_action('wp_ajax_spiral_search_content', [self::class, 'searchContent']);
        add_action('wp_ajax_spiral_design_css', [self::class, 'designCss']);
        add_action('wp_ajax_spiral_toggle_popup', [self::class, 'togglePopup']);
    }

    /**
     * Active / désactive un popup depuis le toggle de la liste.
     */
    public static function togglePopup(): void
    {
        check_ajax_referer('spiral_admin', 'nonce');

        $popupId = isset($_POST['popup_id']) ? (int) $_POST['popup_id'] : 0;
        $popup = get_post($popupId);

        if (!$popup instanceof \WP_Post
            || $popup->post_type !== \Spiral\PostTypes::POPUP
            || !current_user_can('edit_post', $popupId)
        ) {
            wp_send_json_error(null, 403);
        }

        $enabled = isset($_POST['enabled']) && $_POST['enabled'] === '1';
        update_post_meta($popupId, 'spiral_enabled', $enabled ? '1' : '0');

        wp_send_json_success(['enabled' => $enabled]);
    }

    /**
     * Recherche de pages ou d'articles par titre (ciblage).
     */
    public static function searchContent(): void
    {
        check_ajax_referer('spiral_admin', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(null, 403);
        }

        $type = isset($_GET['type']) && $_GET['type'] === 'post' ? 'post' : 'page';
        $query = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';

        $posts = get_posts([
            'post_type' => $type,
            'post_status' => 'publish',
            's' => $query,
            'numberposts' => 20,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $results = [];

        foreach ($posts as $post) {
            $results[] = [
                'id' => $post->ID,
                'title' => $post->post_title !== '' ? $post->post_title : ('#' . $post->ID),
            ];
        }

        wp_send_json_success($results);
    }

    /**
     * CSS généré pour l'aperçu live du créateur de designs — le même
     * générateur PHP que le front, pour un aperçu strictement fidèle.
     */
    public static function designCss(): void
    {
        check_ajax_referer('spiral_admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(null, 403);
        }

        $raw = isset($_POST['settings']) && is_array($_POST['settings'])
            ? wp_unslash($_POST['settings'])
            : [];
        $customCss = isset($_POST['custom_css'])
            ? Repository::sanitizeCss((string) wp_unslash($_POST['custom_css']))
            : '';

        $settings = Repository::sanitizeSettings($raw);
        $css = CssGenerator::generate('apercu', $settings, $customCss);

        wp_send_json_success(['css' => $css, 'overlay' => $settings['overlay']]);
    }
}
