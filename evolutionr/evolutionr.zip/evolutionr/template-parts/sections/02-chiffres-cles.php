<?php
/**
 * 02 — Barre de chiffres clés (réassurance).
 *
 * Visuel : bande horizontale fine entre 2 hairlines, listant 4 chiffres clés
 * (ex. « Sites livrés 84+ », « Optimisation SEO native », « Délai moyen 5 sem. »,
 * « Suivi inclus 6 mois »). Chaque item est précédé d'un point cyan glow.
 *
 * Pilotage ACF (front-page) : reassure_items (repeater de { label, value }).
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!have_rows('reassure_items')) {
    return;
}
?>
<section class="reassure" aria-label="<?php esc_attr_e('Chiffres clés', 'evolutionr'); ?>">
    <div class="container reassure-row">
        <?php while (have_rows('reassure_items')): the_row();
            $label = get_sub_field('label');
            $value = get_sub_field('value');
            ?>
            <div class="reassure-item">
                <span class="dot" aria-hidden="true"></span>
                <span><?php echo esc_html($label); ?> <strong><?php echo esc_html($value); ?></strong></span>
            </div>
        <?php endwhile; ?>
    </div>
</section>
