<?php

declare(strict_types=1);

namespace SpiralBase\Modules\PageSitemapHtml;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;

/**
 * Page sitemap HTML (CAP-9, story 2.9) — PREMIER bloc custom du parent
 * (AD-6), dynamique UNIQUEMENT (AD-12) : `blocks/plan-de-site/block.json`
 * + rendu PHP serveur. Le rendu passe par `render_callback` (et non un
 * render.php isolé) : c'est le SEUL moyen d'injecter le service Options
 * du noyau sans état statique — divergence de forme assumée, le fond
 * d'AD-12 (rendu serveur, zéro HTML figé en base) est respecté.
 *
 * Interrupteur OFF ⇒ bloc jamais enregistré : le markup auto-fermant
 * `<!-- wp:spiralbase/plan-de-site /-->` rend alors du vide (AD-3).
 *
 * AD-6 prescrit « OFF par défaut » pour les blocs custom — ce module est
 * ON par défaut (revue 2.9, choix DOCUMENTÉ) : il appartient aux
 * « fondamentaux automatiques » de l'Epic 2 (AD-2 le classe avec
 * opengraph/sitemap-xml, tous ON), et un bloc enregistré ne rend RIEN
 * tant que l'opérateur ne l'a pas posé sur une page — la pose est le
 * véritable acte d'activation, l'esprit d'AD-6 (rien d'imposé au client)
 * est respecté.
 *
 * Sonde (faits LUS dans le plugin réel wp-sitemap-page) : cède quand le
 * plugin est réellement actif — `WSP_PLUGIN_NAME` (wp-sitemap-page.php:51)
 * ET sa fonction de shortcode (:474, shortcode `wp_sitemap_page` :478).
 * Rank Math n'entre PAS dans cette sonde : il ne fait que du XML (AC 1).
 * LIMITE DOCUMENTÉE : le shortcode ne rend que là où l'opérateur l'a posé
 * — la cession évite le doublon d'outils, pas un conflit de rendu.
 */
final class PageSitemapHtmlModule implements Module
{
    public const OPTION = 'spiralbase_plan_site';

    /** @param \Closure():bool|null $faitWsp fait injectable pour les tests */
    public function __construct(
        private readonly Options $options,
        private readonly ?\Closure $faitWsp = null,
    ) {
    }

    public function slug(): string
    {
        return 'page_sitemap_html';
    }

    public function boot(): void
    {
        /* boot() court sur after_setup_theme ; le cœur enregistre les blocs
           sur init — on s'y range. */
        add_action('init', function (): void {
            register_block_type(
                get_template_directory() . '/blocks/plan-de-site',
                ['render_callback' => fn (): string => (new PlanDeSite($this->options))->rendre()]
            );
        });
    }

    public function defaultSettings(): array
    {
        return ['profondeur_pages' => 0, 'types_exclus' => []];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitWsp ?? static fn (): bool => defined('WSP_PLUGIN_NAME')
                && function_exists('wsp_wp_sitemap_page_main_func'),
            static fn (): string => __('Plan de site réellement assuré par WP Sitemap Page.', 'spiralbase')
        );
    }
}
