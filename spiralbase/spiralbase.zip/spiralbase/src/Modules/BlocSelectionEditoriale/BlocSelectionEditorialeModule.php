<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocSelectionEditoriale;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;

/**
 * Bloc « sélection éditoriale » (CAP-12, story 3.7) — les articles que
 * l'opérateur met en avant, dans l'ordre qu'il a choisi.
 *
 * OFF par défaut (AD-6). Aucune sonde de cession (`null`) : aucun plugin de
 * mise en avant n'est installé dans l'environnement de dev, et la discipline
 * du projet interdit une sonde sur des faits non lus (leçon 2.4).
 *
 * Le bloc n'entre dans AUCUNE liste d'extrait : il liste d'AUTRES articles, et
 * laisser leurs titres nourrir l'extrait ferait décrire une page par le
 * contenu d'une autre (leçon directe de la 3.6, où la question de l'extrait a
 * coûté deux défauts).
 */
final class BlocSelectionEditorialeModule implements Module
{
    public const HANDLE_STYLE = 'spiralbase-selection-editoriale';

    public const NOM = 'spiralbase/selection-editoriale';

    private const REPERTOIRE = 'selection-editoriale';

    private MiseEnAvant $miseEnAvant;

    public function __construct(?Options $options = null, ?MiseEnAvant $miseEnAvant = null)
    {
        $this->miseEnAvant = $miseEnAvant ?? new MiseEnAvant($options);
    }

    public function slug(): string
    {
        return 'bloc_selection_editoriale';
    }

    public function boot(): void
    {
        $miseEnAvant = $this->miseEnAvant;

        add_action('init', static function () use ($miseEnAvant): void {
            $miseEnAvant->declarer();

            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => static fn (array $attributs, string $contenu = '', mixed $bloc = null): string
                    => (new RenduSelection($miseEnAvant))->rendre($attributs, $contenu, $bloc)]
            );

            if ($type === false) {
                $doublon = class_exists('WP_Block_Type_Registry')
                    && \WP_Block_Type_Registry::get_instance()->is_registered(self::NOM);

                Signal::emettre(
                    'spiralbase_bloc_selection_enregistrement_echoue',
                    $doublon
                        ? 'bloc « selection-editoriale » non enregistré : le nom ' . self::NOM . ' est déjà enregistré par une extension ou un thème enfant'
                        : 'bloc « selection-editoriale » non enregistré : répertoire ou block.json illisible',
                    'bloc sélection'
                );
            }
        });

        /*
         * La mise en avant est une décision de portée SITE : elle ne suit pas
         * une copie d'article. Sans cette exclusion, dupliquer un article de
         * la sélection en créait un second, au même rang, dès sa publication.
         */
        add_filter('spiralbase_metas_non_duplicables', static function ($metas): array {
            return array_values(array_unique(array_merge(is_array($metas) ? $metas : [], [MiseEnAvant::META])));
        });

        /* Bascule dans la liste des articles — même forme que la duplication
           de page (2.9) : action de ligne, nonce lié à l'article, capacité. */
        add_filter('post_row_actions', [$this, 'actionDeLigne'], 10, 2);

        /*
         * La redirection vit DANS le hook, comme à la duplication (2.9) :
         * `admin_action_{$action}` est la dernière instruction de
         * `wp-admin/admin.php` (:429, sur 430 lignes). Sans elle, la réponse
         * a un corps VIDE — mesuré à 0 octet — et l'URL, nonce compris, reste
         * dans la barre d'adresse : un simple F5 rebasculait le marquage et
         * renvoyait l'article en fin de sélection.
         */
        add_action('admin_action_' . self::ACTION, function (): void {
            $resultat = $this->basculer();

            wp_safe_redirect(add_query_arg([self::RESULTAT => $resultat], $this->listeDOrigine()));
            exit;
        });

        /* Le refus était tracé pour la supervision, invisible pour l'humain :
           il voyait la même liste après un succès et après un échec. */
        add_action('admin_notices', [$this, 'afficherResultat']);
    }

    public const ACTION = 'spiralbase_basculer_mise_en_avant';

    public const RESULTAT = 'spiralbase_selection';

    /**
     * @param  array<string, string> $actions
     * @return array<string, string>
     */
    public function actionDeLigne(array $actions, mixed $post = null): array
    {
        $id = (int) (is_object($post) ? ($post->ID ?? 0) : $post);

        /*
         * Le cœur applique `post_row_actions` à TOUS les types non
         * hiérarchiques (`class-wp-posts-list-table.php:1589-1604`) : sans
         * cette garde, le lien s'affichait sur les pièces jointes, les blocs
         * réutilisables et tout CPT d'un site client — et proposait « Retirer
         * de la sélection » pour un contenu qui n'y entrera jamais.
         */
        if ($id === 0 || !$this->estUnArticleEligible($id) || !$this->peutModifier($id)) {
            return $actions;
        }

        $lien = add_query_arg(
            ['action' => self::ACTION, 'post' => $id, '_wpnonce' => wp_create_nonce(self::ACTION . '_' . $id)],
            admin_url('admin.php')
        );

        $actions['spiralbase_mise_en_avant'] = '<a href="' . esc_url($lien) . '">'
            . ($this->miseEnAvant->estMisEnAvant($id)
                ? esc_html__('Retirer de la sélection', 'spiralbase')
                : esc_html__('Mettre en avant', 'spiralbase'))
            . '</a>';

        return $actions;
    }

    /**
     * Bascule le marquage.
     *
     * Quatre gardes, toutes nécessaires : le nonce (un lien forgé depuis un
     * autre site ne vaut rien), la capacité de site (un contributeur ne
     * reclasse pas l'accueil), la capacité SUR CETTE CIBLE, et le type de
     * contenu. Le premier jet n'avait que les deux premières et castait
     * `$_REQUEST['post']` sans rien vérifier : la meta s'écrivait sur une
     * page, une pièce jointe, un ID inexistant — laissant des lignes
     * orphelines qu'aucune suppression d'article ne nettoiera — et un
     * `post[]=9` casté à `1` marquait un article que personne n'avait
     * désigné.
     *
     * `$_GET` et non `$_REQUEST` : le lien émis est un GET, et sur un
     * hébergement où `request_order` inclut les cookies, un cookie `post`
     * primerait sur l'URL.
     */
    public function basculer(): string
    {
        $brut = $_GET['post'] ?? 0;
        $id   = is_scalar($brut) ? (int) $brut : 0;

        if ($id === 0 || !$this->estUnArticleEligible($id) || !$this->peutModifier($id)) {
            return $this->refuser('cible invalide ou droits insuffisants');
        }

        if (!wp_verify_nonce((string) ($_GET['_wpnonce'] ?? ''), self::ACTION . '_' . $id)) {
            return $this->refuser('jeton de sécurité absent ou périmé');
        }

        if ($this->miseEnAvant->estMisEnAvant($id)) {
            $this->miseEnAvant->retirer($id);

            return 'retire';
        }

        $this->miseEnAvant->marquer($id);

        return $this->miseEnAvant->estMisEnAvant($id) ? 'marque' : 'refuse';
    }

    /**
     * Retour à la liste D'OÙ VIENT le clic.
     *
     * Une redirection inconditionnelle vers `edit.php` renvoyait l'opérateur
     * sur la page 1 de la liste non filtrée : sur un site à quelques centaines
     * d'articles, il refaisait son filtre et sa pagination à chaque marquage.
     */
    public function listeDOrigine(): string
    {
        $referent = wp_get_referer();

        return is_string($referent) && str_contains($referent, 'edit.php')
            ? $referent
            : admin_url('edit.php');
    }

    /** Affiche le résultat de la dernière bascule — succès comme refus. */
    public function afficherResultat(): void
    {
        $resultat = (string) ($_GET[self::RESULTAT] ?? '');

        $messages = [
            'marque' => [__('Article ajouté à la sélection éditoriale.', 'spiralbase'), 'success'],
            'retire' => [__('Article retiré de la sélection éditoriale.', 'spiralbase'), 'success'],
            'refuse' => [__('Sélection éditoriale : action refusée. Vérifiez vos droits, ou rechargez la liste des articles.', 'spiralbase'), 'error'],
        ];

        if (!isset($messages[$resultat])) {
            return;
        }

        [$texte, $ton] = $messages[$resultat];

        printf(
            '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
            esc_attr($ton),
            esc_html($texte)
        );
    }

    /**
     * Le marquage ne vaut que pour un article existant qui peut atteindre la
     * sélection — jamais une page, une pièce jointe, un ID mort, ni un
     * contenu à la corbeille.
     *
     * Le cœur applique `post_row_actions` AUSSI dans la vue Corbeille
     * (`class-wp-posts-list-table.php:1604`) : le lien y était proposé, et le
     * rang écrit sur un article que le calcul de rang ne voit pas — soit
     * exactement la recette d'un ex æquo, en deux gestes ordinaires.
     */
    private function estUnArticleEligible(int $id): bool
    {
        $post = get_post($id);

        if (!is_object($post) || ($post->post_type ?? '') !== 'post') {
            return false;
        }

        return !in_array($post->post_status ?? 'publish', ['trash', 'auto-draft'], true);
    }

    /**
     * Capacité de SITE et capacité sur la CIBLE. La première seule laisserait
     * un éditeur marquer un contenu qu'il n'a pas le droit de modifier.
     */
    private function peutModifier(int $id): bool
    {
        return current_user_can('edit_others_posts') && current_user_can('edit_post', $id);
    }

    /**
     * Un refus muet est indiscernable d'un succès. Le signal trace pour la
     * supervision ; le verdict rendu ici remonte jusqu'à l'écran, où
     * `afficherResultat()` le montre à l'opérateur.
     */
    private function refuser(string $raison): string
    {
        Signal::emettre('spiralbase_bloc_selection_refus', 'bascule refusée : ' . $raison, 'bloc sélection');

        return 'refuse';
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        /* Le verrou du calcul de rang est une option : elle doit être
           DÉCLARÉE pour être écrite (invariant AD-11). */
        return [MiseEnAvant::VERROU];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
