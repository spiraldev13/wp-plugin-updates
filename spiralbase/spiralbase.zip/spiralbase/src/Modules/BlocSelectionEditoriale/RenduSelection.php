<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocSelectionEditoriale;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;

/**
 * Rendu serveur du bloc `spiralbase/selection-editoriale` (story 3.7).
 *
 * Le bloc affiche des articles TIERS : leurs titres sont du texte brut
 * échappé, jamais du texte riche — `Core\TexteRiche` est le juge du texte
 * d'ÉDITEUR du bloc courant (règle établie en 3.3, après qu'un auteur d'avis
 * Google a pu poser du gras sur la page d'un client).
 *
 * Aucune sélection : rien. Pas de squelette vide, pas de « aucun article » à
 * l'écran — un bloc qui n'a rien à montrer disparaît (AD-3).
 */
final class RenduSelection
{
    /** Plafond dur : au-delà, ce n'est plus une sélection éditoriale. */
    public const PLAFOND = 12;

    public const DEFAUT = 3;

    public function __construct(private readonly MiseEnAvant $miseEnAvant)
    {
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs, string $contenu = '', mixed $bloc = null): string
    {
        try {
            return $this->composer($attributs);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_bloc_selection_echec', 'rendu interrompu : ' . $e->getMessage(), 'bloc sélection');

            return '';
        }
    }

    /** @param array<string, mixed> $attributs */
    private function composer(array $attributs): string
    {
        $articles = $this->miseEnAvant->articlesMarques($this->nombre($attributs));

        if ($articles === []) {
            return '';
        }

        $entrees = '';

        foreach ($articles as $article) {
            $entrees .= $this->entree($article);
        }

        if ($entrees === '') {
            return '';
        }

        return '<div ' . EnveloppeBloc::attributs('spiralbase-selection') . '>'
            . '<ul class="spiralbase-selection__liste">' . $entrees . '</ul>'
            . '</div>';
    }

    private function entree(object $article): string
    {
        $lien = get_permalink($article);

        /*
         * Le cœur rend `false` pour un article introuvable. Un titre sans lien
         * cliquable serait une impasse dans une liste dont le seul but est de
         * mener quelque part : on l'écarte plutôt que de publier un lien mort.
         */
        if (!is_string($lien) || trim($lien) === '') {
            return '';
        }

        /*
         * PAS de `wp_strip_all_tags` : `strip_tags()` coupe à partir de tout
         * `<` suivi d'un caractère non blanc, jusqu'à la fin de la chaîne.
         * Un titre « Menu <20 EUR » sortait amputé en « Menu », et
         * « <20 EUR le menu » devenait vide — l'article que l'opérateur avait
         * explicitement placé en une disparaissait alors sans un mot.
         * `esc_html()` seul est intégralement sûr ici : il neutralise `<`,
         * `>`, `&` et les guillemets au point de sortie.
         */
        $titre = trim((string) ($article->post_title ?? ''));

        if ($titre === '') {
            return '';
        }

        return '<li class="spiralbase-selection__entree">'
            . '<a class="spiralbase-selection__lien" href="' . esc_url($lien) . '">'
            . esc_html($titre)
            . '</a></li>';
    }

    /** @param array<string, mixed> $attributs */
    private function nombre(array $attributs): int
    {
        $valeur = $attributs['nombre'] ?? null;

        if (!is_int($valeur) && !(is_string($valeur) && preg_match('/^\d+$/', $valeur) === 1)) {
            return self::DEFAUT;
        }

        return max(1, min((int) $valeur, self::PLAFOND));
    }
}
