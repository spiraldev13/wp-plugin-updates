<?php

declare(strict_types=1);

namespace SpiralBase\Modules\MaillageInterne;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\SondeCession;
use SpiralBase\Core\Walker;

/**
 * Maillage interne (CAP-9, story 2.8) — TRANSFORMATION du walker (AD-10) :
 * la première occurrence de chaque mot-clé du dictionnaire devient un lien
 * interne, dans la limite du plafond par article. Le rendu change, la base
 * JAMAIS.
 *
 * Dictionnaire = réglage `spiralbase_maillage` (`mots_cles` : mot => URL).
 * Divergence ASSUMÉE avec Internal Link Juicer, qui pilote par meta de post
 * cible (`ilj_linkdefinition`, database/postmeta.php:18) : spiralbase choisit
 * la porte unique d'un dictionnaire global (AD-2) — l'UI d'admin arrive avec
 * le tableau de bord.
 *
 * Sonde (faits LUS dans le plugin réel `internal-links`) : le hook ILJ est
 * INCONDITIONNEL dès l'activation — `core/app.php:674` enregistre
 * `the_content` (prio PHP_INT_MAX) depuis `plugins_loaded`, aucune option ne
 * le gate. Plugin actif = effectif : la sonde teste la classe principale
 * (`ILJ\Core\App`, core/app.php:51). LIMITE DOCUMENTÉE : les exclusions
 * fines par post (`ilj_blacklistdefinition`) ne changent rien au verdict.
 */
final class MaillageInterneModule implements Module
{
    public const OPTION = 'spiralbase_maillage';

    /** Masque non-blanc des zones déjà consommées (leçon 2.7 : un blanc fausserait les bornes). */
    private const MASQUE_CONSOMME = "\x1A";

    /** @param \Closure():bool|null $faitIlj fait injectable pour les tests */
    public function __construct(
        private readonly Walker $walker,
        private readonly Options $options,
        private readonly ?\Closure $faitIlj = null,
    ) {
    }

    public function slug(): string
    {
        return 'maillage_interne';
    }

    public function boot(): void
    {
        $this->walker->addTransformation(
            'maillage_interne',
            fn (string $contenu, array $contexte): string => $this->mailler($contenu)
        );
    }

    public function defaultSettings(): array
    {
        return ['plafond' => 3, 'mots_cles' => []];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            $this->faitIlj ?? static fn (): bool => class_exists('ILJ\\Core\\App', false),
            static fn (): string => __('Maillage interne réellement assuré par Internal Link Juicer.', 'spiralbase')
        );
    }

    /** Transformation du walker — le walker attrape les Throwable (1.4). */
    private function mailler(string $contenu): string
    {
        $post = get_post();

        /* Périmètre : les ARTICLES seulement (politique éditoriale 2.6). */
        if (!is_object($post) || (($post->post_type ?? 'post') !== 'post')) {
            return $contenu;
        }

        $motsCles = $this->motsCles();

        if ($motsCles === []) {
            return $contenu;
        }

        /* Le garde d'équilibre lit la MÊME VUE que le masquage (revue 2.8 :
           compté sur le brut, un <a> ou un </a> planqué dans un commentaire
           le trompait dans les deux sens). Un <a> réellement jamais fermé
           rend les zones sûres INDÉCIDABLES — fail-safe : aucun lien posé
           (au pire un lien manquant, jamais un lien imbriqué). */
        $masque = $this->walker->masquerZonesInertes($contenu);

        if (preg_match_all('~<a[\s>]~i', $masque) !== preg_match_all('~</a\s*>~i', $masque)) {
            $this->signaler('éléments <a> déséquilibrés — aucun lien posé (fail-safe)');

            return $contenu;
        }

        $permalien = get_permalink();
        $masque    = $this->masquerZonesInterdites($masque);
        $poses     = [];
        $plafond   = $this->plafond();

        foreach ($motsCles as $mot => $url) {
            /* PHP re-caste les clés numériques en int même dans le
               dictionnaire assaini — le motif attend une string. */
            $mot = (string) $mot;

            if (count($poses) >= $plafond) {
                break;
            }

            /* Un article cible ne se lie jamais lui-même. */
            if (is_string($permalien) && $this->estAutoLien($url, $permalien)) {
                continue;
            }

            $urlSure = esc_url($url);

            if ($urlSure === '') {
                continue;
            }

            $trouve = @preg_match($this->motifDuMot($mot), $masque, $m, PREG_OFFSET_CAPTURE);

            if ($trouve !== 1) {
                if ($trouve === false) {
                    $this->signaler(sprintf('mot-clé ignoré (motif invalide) : %s', $mot));
                }

                continue;
            }

            [$occurrence, $offset] = $m[0];
            $longueur = strlen($occurrence);
            $poses[]  = [$offset, $longueur, $urlSure];

            /* La zone consommée est masquée : un autre mot-clé ne peut plus
               matcher DANS le texte d'un lien qui vient d'être décidé. */
            $masque = substr_replace($masque, str_repeat(self::MASQUE_CONSOMME, $longueur), $offset, $longueur);
        }

        /* Du dernier au premier : les offsets restent valides pendant l'édition. */
        usort($poses, static fn (array $a, array $b): int => $b[0] <=> $a[0]);
        $sortie = $contenu;

        foreach ($poses as [$offset, $longueur, $urlSure]) {
            $texte  = substr($sortie, $offset, $longueur);
            $sortie = substr_replace($sortie, '<a href="' . $urlSure . '">' . $texte . '</a>', $offset, $longueur);
        }

        return $sortie;
    }

    /**
     * Copie de travail à LONGUEUR CONSTANTE où toute zone interdite est
     * blanchie : éléments <a> complets (jamais de lien dans un lien),
     * headings entiers (les ancres du sommaire 2.7 ne sont jamais altérées),
     * l'intérieur de toute balise — chevrons quotés compris, `title="a>b"`
     * ne fuit pas (revue 2.8) — et les entités HTML (`&amp;` n'est jamais
     * déchirée par un mot-clé homonyme, revue 2.8). Reçoit le contenu DÉJÀ
     * passé par masquerZonesInertes ; les offsets valent dans l'original.
     * Limite documentée : un mot-clé coupé par du balisage inline
     * (`grand <em>chat</em>`) n'est pas lié — fail-safe, jamais de lien cassé.
     */
    private function masquerZonesInterdites(string $masque): string
    {
        $motifs = [
            '~<a\b.*?</a\s*>~is',
            '~<h([1-6])\b.*?</h\1\s*>~is',
            '~<(?:[^>"\']|"[^"]*"|\'[^\']*\')*>~',
            '~&(?:#\d+|#x[0-9a-f]+|[a-z][a-z0-9]{1,31});~i',
        ];

        foreach ($motifs as $motif) {
            $masque = (string) preg_replace_callback(
                $motif,
                static fn (array $m): string => str_repeat(' ', strlen($m[0])),
                $masque
            );
        }

        return $masque;
    }

    /**
     * Motif du mot-clé : mot entier (bornes Unicode), insensible à la casse,
     * tolérant aux réécritures du cœur EN AMONT du walker (revue 2.8 :
     * wptexturize tourne prio 10, le walker prio 20) — apostrophe droite du
     * réglage ↔ apostrophe typographique du contenu, espaces variables.
     */
    private function motifDuMot(string $mot): string
    {
        $litteral = preg_quote($mot, '/');
        $litteral = (string) preg_replace('/\s+/u', '\\\\s+', $litteral);
        $litteral = (string) preg_replace("/['\u{2019}]/u", "['\u{2019}]", $litteral);

        return '/(?<![\p{L}\p{N}])' . $litteral . '(?![\p{L}\p{N}])/iu';
    }

    /**
     * L'URL cible désigne-t-elle l'article courant ? Comparaison NORMALISÉE
     * (revue 2.8 : l'égalité brute était contournable) : hôtes insensibles à
     * la casse et au `www.`, chemins sans slash final, query/fragment
     * indifférents ; une cible relative se compare par chemin ; une cible
     * sans hôte NI chemin (`#ancre`, `?x`) est toujours la page courante.
     */
    private function estAutoLien(string $url, string $permalien): bool
    {
        $cible   = parse_url($url);
        $courant = parse_url($permalien);

        if (!is_array($cible) || !is_array($courant)) {
            return false;
        }

        $hoteCible   = (string) preg_replace('/^www\./', '', strtolower((string) ($cible['host'] ?? '')));
        $hoteCourant = (string) preg_replace('/^www\./', '', strtolower((string) ($courant['host'] ?? '')));

        if ($hoteCible !== '' && $hoteCible !== $hoteCourant) {
            return false;
        }

        $cheminCible   = untrailingslashit((string) ($cible['path'] ?? ''));
        $cheminCourant = untrailingslashit((string) ($courant['path'] ?? ''));

        if ($hoteCible === '' && $cheminCible === '') {
            return true;
        }

        return $cheminCible === $cheminCourant;
    }

    /**
     * Dictionnaire assaini : les entrées corrompues sont ignorées UNE À UNE.
     * Une clé int est LÉGITIME (revue 2.8 : PHP caste « 2024 » en int à la
     * construction du tableau — la jeter perdait un mot-clé métier valide) ;
     * un mot-clé portant un caractère de contrôle est refusé ET signalé
     * (l'octet sentinelle du masque ne doit jamais être matchable).
     *
     * @return array<string, string>
     */
    private function motsCles(): array
    {
        $reglages = $this->options->get(self::OPTION, []);
        $bruts    = is_array($reglages) && is_array($reglages['mots_cles'] ?? null) ? $reglages['mots_cles'] : [];
        $sains    = [];

        foreach ($bruts as $mot => $url) {
            if (!is_string($mot) && !is_int($mot)) {
                continue;
            }

            $mot = (string) $mot;

            if (trim($mot) === '' || !is_string($url) || trim($url) === '') {
                continue;
            }

            if (preg_match('/[\x00-\x1F\x7F]/', $mot) === 1) {
                $this->signaler('mot-clé ignoré (caractère de contrôle)');

                continue;
            }

            $sains[$mot] = $url;
        }

        return $sains;
    }

    private function plafond(): int
    {
        $reglages = $this->options->get(self::OPTION, []);
        $plafond  = is_array($reglages) && is_numeric($reglages['plafond'] ?? null) ? (int) $reglages['plafond'] : 0;

        return $plafond > 0 ? $plafond : (int) $this->defaultSettings()['plafond'];
    }

    /** NFR13 : signal systématique + trace sous WP_DEBUG, jamais de fatal. */
    private function signaler(string $detail): void
    {
        do_action('spiralbase_maillage_ignore', $detail);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[spiralbase] maillage : ' . $detail);
        }
    }
}
