<?php

namespace Spiral\Admin;

use Spiral\Designs\CssGenerator;
use Spiral\Designs\Presets;
use Spiral\Designs\Repository;
use Spiral\PostTypes;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Page « Designs » : galerie des designs fournis et personnels,
 * créateur 100 % clic avec aperçu live.
 */
final class DesignsPage
{
    private const PAGE_SLUG = 'spiral-designs';

    private const BG_SWATCHES = [
        '#ffffff', '#f8fafc', '#fef3c7', '#ecfdf5', '#eff6ff',
        '#fdf2f8', '#1e293b', '#111827', '#0f172a', '#7f1d1d',
    ];

    private const ACCENT_SWATCHES = [
        '#2271b1', '#0ea5e9', '#16a34a', '#f59e0b', '#dc2626',
        '#7c3aed', '#db2777', '#334155',
    ];

    private const TEXT_SWATCHES = [
        '#1e293b', '#334155', '#64748b', '#f8fafc', '#ffffff',
        '#fef3c7', '#dc2626', '#2271b1',
    ];

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addMenu']);
        add_action('admin_post_spiral_save_design', [self::class, 'handleSave']);
        add_action('admin_post_spiral_delete_design', [self::class, 'handleDelete']);
    }

    public static function addMenu(): void
    {
        add_submenu_page(
            'edit.php?post_type=' . PostTypes::POPUP,
            __('Designs de popup', 'popup-spiral'),
            __('Designs', 'popup-spiral'),
            'manage_options',
            self::PAGE_SLUG,
            [self::class, 'render']
        );
    }

    public static function render(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $action = isset($_GET['action']) ? sanitize_key($_GET['action']) : '';

        if ($action === 'edit' || $action === 'new') {
            self::renderEditor();
            return;
        }

        self::renderGallery();
    }

    /* ---------- Galerie ---------- */

    private static function renderGallery(): void
    {
        $newUrl = esc_url(self::pageUrl(['action' => 'new']));
        ?>
        <div class="wrap spiral-admin">
            <h1>
                <?php esc_html_e('Designs de popup', 'popup-spiral'); ?>
                <a href="<?php echo $newUrl; ?>" class="page-title-action"><?php esc_html_e('Créer un design', 'popup-spiral'); ?></a>
            </h1>

            <?php if (isset($_GET['saved'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Design enregistré.', 'popup-spiral'); ?></p></div>
            <?php endif; ?>
            <?php if (isset($_GET['deleted'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Design supprimé.', 'popup-spiral'); ?></p></div>
            <?php endif; ?>

            <h2><?php esc_html_e('Designs fournis', 'popup-spiral'); ?></h2>
            <div class="spiral-design-gallery spiral-design-gallery-page">
                <?php foreach (Repository::all() as $slug => $design) : ?>
                    <?php if (!$design['builtin']) { continue; } ?>
                    <?php self::renderGalleryCard($slug, $design); ?>
                <?php endforeach; ?>
            </div>

            <h2><?php esc_html_e('Mes designs', 'popup-spiral'); ?></h2>
            <div class="spiral-design-gallery spiral-design-gallery-page">
                <?php $hasUserDesign = false; ?>
                <?php foreach (Repository::all() as $slug => $design) : ?>
                    <?php if ($design['builtin']) { continue; } ?>
                    <?php $hasUserDesign = true; ?>
                    <?php self::renderGalleryCard($slug, $design); ?>
                <?php endforeach; ?>
                <?php if (!$hasUserDesign) : ?>
                    <p class="description"><?php esc_html_e('Aucun design personnel pour l\'instant. Créez-en un, ou personnalisez un design fourni : il sera copié ici.', 'popup-spiral'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private static function renderGalleryCard(string $slug, array $design): void
    {
        $editUrl = esc_url(self::pageUrl(['action' => 'edit', 'design' => $slug]));
        $deleteUrl = esc_url(wp_nonce_url(
            admin_url('admin-post.php?action=spiral_delete_design&design=' . rawurlencode($slug)),
            'spiral_delete_design_' . $slug
        ));
        $settings = $design['settings'];
        ?>
        <div class="spiral-design-card spiral-design-card-static">
            <span class="spiral-design-thumb spiral-design-thumb-lg" style="<?php echo esc_attr(self::thumbStyle($settings)); ?>">
                <span class="spiral-design-thumb-bar" style="background: <?php echo esc_attr($settings['accent']); ?>;"></span>
            </span>
            <span class="spiral-design-name">
                <?php echo esc_html($design['name']); ?>
                <?php if ($design['builtin']) : ?>
                    <em><?php esc_html_e('Fourni', 'popup-spiral'); ?></em>
                <?php endif; ?>
            </span>
            <span class="spiral-design-actions">
                <a href="<?php echo $editUrl; ?>" class="button button-small">
                    <?php $design['builtin'] ? esc_html_e('Personnaliser (copie)', 'popup-spiral') : esc_html_e('Modifier', 'popup-spiral'); ?>
                </a>
                <?php if (!$design['builtin']) : ?>
                    <a href="<?php echo $deleteUrl; ?>" class="button button-small spiral-delete" data-confirm="<?php esc_attr_e('Supprimer ce design ?', 'popup-spiral'); ?>">
                        <?php esc_html_e('Supprimer', 'popup-spiral'); ?>
                    </a>
                <?php endif; ?>
            </span>
        </div>
        <?php
    }

    /* ---------- Créateur / éditeur ---------- */

    private static function renderEditor(): void
    {
        $slug = isset($_GET['design']) ? sanitize_key($_GET['design']) : '';
        $design = $slug !== '' ? Repository::get($slug) : null;

        if ($design === null) {
            $slug = '';
            $design = [
                'name' => '',
                'settings' => Presets::all()['annonce']['settings'],
                'custom_css' => '',
                'builtin' => false,
            ];
        }

        $settings = $design['settings'];
        $name = $design['builtin']
            ? sprintf(/* translators: %s : nom du design copié */ __('%s (copie)', 'popup-spiral'), $design['name'])
            : $design['name'];
        $previewCss = CssGenerator::generate('apercu', $settings, $design['custom_css']);
        ?>
        <div class="wrap spiral-admin">
            <h1><?php $slug === '' ? esc_html_e('Créer un design', 'popup-spiral') : esc_html_e('Modifier le design', 'popup-spiral'); ?></h1>

            <?php if ($design['builtin']) : ?>
                <div class="notice notice-info"><p><?php esc_html_e('Les designs fournis restent intacts : vos modifications seront enregistrées comme un nouveau design dans « Mes designs ».', 'popup-spiral'); ?></p></div>
            <?php endif; ?>

            <form id="spiral-design-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="spiral-design-editor">
                <input type="hidden" name="action" value="spiral_save_design" />
                <input type="hidden" name="design_slug" value="<?php echo esc_attr($slug); ?>" />
                <?php wp_nonce_field('spiral_save_design'); ?>

                <div class="spiral-editor-fields">
                    <div class="spiral-card">
                        <label>
                            <strong><?php esc_html_e('Nom du design', 'popup-spiral'); ?></strong>
                            <input type="text" name="design_name" value="<?php echo esc_attr($name); ?>" required placeholder="<?php esc_attr_e('Ex. Promo Noël', 'popup-spiral'); ?>" />
                        </label>
                    </div>

                    <?php
                    $textColor = !empty($settings['text'])
                        ? $settings['text']
                        : CssGenerator::readableTextColor($settings['bg']);
                    ?>
                    <div class="spiral-card">
                        <strong><?php esc_html_e('Couleur de fond', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[bg]', $settings['bg'], self::BG_SWATCHES); ?>
                        <strong><?php esc_html_e('Couleur du texte', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[text]', $textColor, self::TEXT_SWATCHES); ?>
                        <strong><?php esc_html_e('Couleur d\'accent (fond des boutons, liens)', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[accent]', $settings['accent'], self::ACCENT_SWATCHES); ?>
                        <strong><?php esc_html_e('Couleur du texte des boutons', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[btn_text]', !empty($settings['btn_text']) ? $settings['btn_text'] : '#ffffff', self::TEXT_SWATCHES); ?>
                    </div>

                    <div class="spiral-card">
                        <strong><?php esc_html_e('Couleur de la croix (bouton fermer)', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[close_color]', !empty($settings['close_color']) ? $settings['close_color'] : $textColor, self::TEXT_SWATCHES); ?>
                        <strong><?php esc_html_e('Fond de la croix', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[close_bg]', !empty($settings['close_bg']) ? $settings['close_bg'] : '#e2e8f0', self::BG_SWATCHES); ?>
                        <strong><?php esc_html_e('Couleur de la croix au survol', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[close_hover_color]', !empty($settings['close_hover_color']) ? $settings['close_hover_color'] : $textColor, self::TEXT_SWATCHES); ?>
                        <strong><?php esc_html_e('Fond de la croix au survol', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[close_hover_bg]', !empty($settings['close_hover_bg']) ? $settings['close_hover_bg'] : '#cbd5e1', self::BG_SWATCHES); ?>
                        <?php
                        self::renderChoices(__('Trait souligné sous la croix', 'popup-spiral'), 'settings[close_underline]', !empty($settings['close_underline']) ? '1' : '0', [
                            '0' => __('Désactivé', 'popup-spiral'),
                            '1' => __('Activé', 'popup-spiral'),
                        ]);
                        ?>
                    </div>

                    <div class="spiral-card">
                        <?php
                        self::renderChoices(__('Bordure autour du popup', 'popup-spiral'), 'settings[border]', (string) ($settings['border'] ?? 'none'), [
                            'none' => __('Aucune', 'popup-spiral'),
                            'thin' => __('Fine (1px)', 'popup-spiral'),
                            'thick' => __('Épaisse (3px)', 'popup-spiral'),
                            'custom' => __('Personnalisée', 'popup-spiral'),
                        ]);
                        ?>
                        <p class="spiral-conditional" data-when="settings[border]" data-value="custom">
                            <?php esc_html_e('Épaisseur :', 'popup-spiral'); ?>
                            <input type="number" name="settings[border_width]" value="<?php echo (int) ($settings['border_width'] ?? 2); ?>" min="1" max="20" class="spiral-input-small" />
                            <?php esc_html_e('pixels', 'popup-spiral'); ?>
                        </p>
                        <strong><?php esc_html_e('Couleur de la bordure', 'popup-spiral'); ?></strong>
                        <?php self::renderColorField('settings[border_color]', !empty($settings['border_color']) ? $settings['border_color'] : $settings['accent'], self::ACCENT_SWATCHES); ?>
                    </div>

                    <div class="spiral-card">
                        <?php
                        self::renderChoices(__('Coins', 'popup-spiral'), 'settings[corners]', $settings['corners'], [
                            'square' => __('Carrés', 'popup-spiral'),
                            'rounded' => __('Arrondis (12px)', 'popup-spiral'),
                            'pill' => __('Très arrondis (28px)', 'popup-spiral'),
                            'custom' => __('Personnalisé', 'popup-spiral'),
                        ]);
                        ?>
                        <p class="spiral-conditional" data-when="settings[corners]" data-value="custom">
                            <?php esc_html_e('Arrondi :', 'popup-spiral'); ?>
                            <input type="number" name="settings[corners_radius]" value="<?php echo (int) ($settings['corners_radius'] ?? 16); ?>" min="0" max="60" class="spiral-input-small" />
                            <?php esc_html_e('pixels', 'popup-spiral'); ?>
                        </p>
                        <?php
                        self::renderChoices(__('Ombre', 'popup-spiral'), 'settings[shadow]', $settings['shadow'], [
                            'none' => __('Aucune', 'popup-spiral'),
                            'soft' => __('Douce', 'popup-spiral'),
                            'strong' => __('Forte', 'popup-spiral'),
                            'custom' => __('Personnalisée', 'popup-spiral'),
                        ]);
                        ?>
                        <p class="spiral-conditional" data-when="settings[shadow]" data-value="custom">
                            <?php esc_html_e('Flou :', 'popup-spiral'); ?>
                            <input type="number" name="settings[shadow_blur]" value="<?php echo (int) ($settings['shadow_blur'] ?? 40); ?>" min="0" max="120" class="spiral-input-small" />
                            <?php esc_html_e('px — Opacité :', 'popup-spiral'); ?>
                            <input type="number" name="settings[shadow_opacity]" value="<?php echo (int) ($settings['shadow_opacity'] ?? 25); ?>" min="0" max="100" class="spiral-input-small" />
                            <?php esc_html_e('%', 'popup-spiral'); ?>
                        </p>
                        <?php
                        self::renderChoices(__('Fond derrière le popup', 'popup-spiral'), 'settings[overlay]', $settings['overlay'], [
                            'dim' => __('Assombri', 'popup-spiral'),
                            'blur' => __('Flouté', 'popup-spiral'),
                            'none' => __('Aucun', 'popup-spiral'),
                        ]);
                        self::renderChoices(__('Bouton fermer', 'popup-spiral'), 'settings[close_style]', $settings['close_style'], [
                            'cross' => __('Croix', 'popup-spiral'),
                            'text' => __('Texte « Fermer »', 'popup-spiral'),
                        ]);
                        self::renderChoices(__('Position du bouton fermer', 'popup-spiral'), 'settings[close_position]', $settings['close_position'], [
                            'inside' => __('À l\'intérieur', 'popup-spiral'),
                            'outside' => __('À l\'extérieur', 'popup-spiral'),
                        ]);
                        self::renderChoices(__('Police', 'popup-spiral'), 'settings[font]', $settings['font'], [
                            'theme' => __('Celle du thème', 'popup-spiral'),
                            'modern' => __('Moderne (système)', 'popup-spiral'),
                        ]);
                        ?>
                    </div>

                    <details class="spiral-advanced spiral-card">
                        <summary><?php esc_html_e('Avancé — CSS manuel (optionnel)', 'popup-spiral'); ?></summary>
                        <p class="description"><?php esc_html_e('Appliqué uniquement à ce design. À réserver aux cas que les réglages ci-dessus ne couvrent pas.', 'popup-spiral'); ?></p>
                        <textarea name="custom_css" rows="8" spellcheck="false" placeholder=".spiral-content h2 { text-transform: uppercase; }"><?php echo esc_textarea($design['custom_css']); ?></textarea>
                    </details>

                    <p>
                        <button type="submit" class="button button-primary button-large"><?php esc_html_e('Enregistrer le design', 'popup-spiral'); ?></button>
                        <a href="<?php echo esc_url(self::pageUrl()); ?>" class="button button-large"><?php esc_html_e('Annuler', 'popup-spiral'); ?></a>
                    </p>
                </div>

                <div class="spiral-editor-preview">
                    <h2><?php esc_html_e('Aperçu', 'popup-spiral'); ?></h2>
                    <style id="spiral-preview-css"><?php echo $previewCss; // CSS généré par le plugin, déjà nettoyé. ?></style>
                    <div class="spiral-preview-stage" data-overlay="<?php echo esc_attr($settings['overlay']); ?>">
                        <div class="spiral-popup spiral-design-apercu" id="spiral-preview-popup">
                            <div class="spiral-body">
                                <div class="spiral-content">
                                    <h2><?php esc_html_e('Titre du popup', 'popup-spiral'); ?></h2>
                                    <p><?php esc_html_e('Un court texte d\'exemple pour visualiser votre design : couleurs, police, taille et coins.', 'popup-spiral'); ?></p>
                                    <a href="#" class="spiral-btn" onclick="return false;"><?php esc_html_e('Bouton d\'action', 'popup-spiral'); ?></a>
                                </div>
                            </div>
                            <button type="button" class="spiral-close spiral-close-style-<?php echo esc_attr($settings['close_style']); ?>" id="spiral-preview-close" onclick="return false;"><?php echo $settings['close_style'] === 'text' ? esc_html__('Fermer', 'popup-spiral') : '<span aria-hidden="true">&times;</span>'; ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }

    /* ---------- Traitements ---------- */

    public static function handleSave(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Action non autorisée.', 'popup-spiral'));
        }

        check_admin_referer('spiral_save_design');

        $slug = isset($_POST['design_slug']) ? sanitize_key($_POST['design_slug']) : '';
        $name = isset($_POST['design_name']) ? sanitize_text_field(wp_unslash($_POST['design_name'])) : '';
        $settings = isset($_POST['settings']) && is_array($_POST['settings']) ? wp_unslash($_POST['settings']) : [];
        $customCss = isset($_POST['custom_css']) ? (string) wp_unslash($_POST['custom_css']) : '';

        Repository::save($slug, $name, $settings, $customCss);

        wp_safe_redirect(self::pageUrl(['saved' => 1]));
        exit;
    }

    public static function handleDelete(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Action non autorisée.', 'popup-spiral'));
        }

        $slug = isset($_GET['design']) ? sanitize_key($_GET['design']) : '';

        check_admin_referer('spiral_delete_design_' . $slug);

        Repository::delete($slug);

        wp_safe_redirect(self::pageUrl(['deleted' => 1]));
        exit;
    }

    /* ---------- Helpers ---------- */

    private static function pageUrl(array $args = []): string
    {
        return add_query_arg(
            array_merge(['post_type' => PostTypes::POPUP, 'page' => self::PAGE_SLUG], $args),
            admin_url('edit.php')
        );
    }

    /**
     * Champ couleur : pastilles cliquables + sélecteur natif pour une teinte libre.
     */
    private static function renderColorField(string $name, string $value, array $swatches): void
    {
        ?>
        <div class="spiral-color-field">
            <?php foreach ($swatches as $swatch) : ?>
                <button type="button" class="spiral-swatch" style="background: <?php echo esc_attr($swatch); ?>;" data-color="<?php echo esc_attr($swatch); ?>" aria-label="<?php echo esc_attr($swatch); ?>"></button>
            <?php endforeach; ?>
            <input type="color" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" class="spiral-color-input" />
        </div>
        <?php
    }

    /**
     * Groupe de cartes-radio : le composant de choix fermé commun à tous les écrans.
     */
    private static function renderChoices(string $label, string $name, string $current, array $choices): void
    {
        ?>
        <strong><?php echo esc_html($label); ?></strong>
        <div class="spiral-choice-row">
            <?php foreach ($choices as $value => $text) : ?>
                <label class="spiral-choice-card">
                    <input type="radio" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" <?php checked($current, $value); ?> />
                    <span><?php echo esc_html($text); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <?php
    }

    private static function thumbStyle(array $settings): string
    {
        $radius = ['square' => '2px', 'rounded' => '8px', 'pill' => '16px'][$settings['corners']] ?? '8px';
        $shadow = $settings['shadow'] === 'none' ? 'none' : '0 4px 12px rgba(0, 0, 0, 0.18)';
        $bg = !empty($settings['neutral']) ? 'repeating-conic-gradient(#f1f5f9 0% 25%, #ffffff 0% 50%) 50% / 12px 12px' : $settings['bg'];

        return 'background: ' . $bg . '; border-radius: ' . $radius . '; box-shadow: ' . $shadow . ';';
    }
}
