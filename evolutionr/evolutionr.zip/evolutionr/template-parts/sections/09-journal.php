<?php
/**
 * 07 — Journal (3 derniers articles de blog).
 *
 * Visuel : en-tête (eyebrow + titre à gauche + bouton « Tous les articles »
 * à droite) puis liste de 3 lignes denses. Chaque ligne : numéro mono à gauche
 * + catégorie + titre éditorial + date + flèche ronde à droite (cyan au hover).
 *
 * Pilotage ACF (front-page) : blog_eyebrow, blog_title, blog_archive_url.
 * Contenu : 3 derniers `post` publiés (type natif WordPress).
 * Ligne unitaire : template-parts/cards/ligne-journal.php
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow    = get_field('blog_eyebrow') ?: __('Journal', 'evolutionr');
$title      = get_field('blog_title') ?: __('Notes, méthodes et retours de terrain.', 'evolutionr');
$archiveUrl = get_field('blog_archive_url') ?: get_post_type_archive_link('post');

$posts = new WP_Query([
    'post_type'      => 'post',
    'posts_per_page' => 3,
    'no_found_rows'  => true,
]);

if (!$posts->have_posts()) {
    return;
}
?>
<section class="section" id="blog" aria-labelledby="blog-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <h2 class="section-title" id="blog-title"><?php echo esc_html($title); ?></h2>
            </div>
            <?php if ($archiveUrl): ?>
                <a class="btn btn-ghost" href="<?php echo esc_url($archiveUrl); ?>">
                    <span class="btn-inner">
                        <?php esc_html_e('Tous les articles', 'evolutionr'); ?>
                        <?php evolutionr_icon('arrow-up-right', 14); ?>
                    </span>
                </a>
            <?php endif; ?>
        </header>

        <div class="blog-list">
            <?php $i = 1; while ($posts->have_posts()): $posts->the_post();
                set_query_var('index', $i);
                get_template_part('template-parts/cards/ligne-journal', null, ['index' => $i]);
                $i++;
            endwhile;
            wp_reset_postdata(); ?>
        </div>
    </div>
</section>
