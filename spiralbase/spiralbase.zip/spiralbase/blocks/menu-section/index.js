/**
 * Bloc spiralbase/menu-section — JS éditeur écrit à la main, SANS build.
 *
 * La mise en forme n'est PAS un attribut de la section : elle arrive par le
 * contexte de bloc (`usesContext`), fourni par la carte parente. Changer de
 * présentation ne réécrit donc aucune section — c'est ce qui rend l'AC 2
 * vraie par construction plutôt que par une migration de données.
 *
 * `save()` retourne `InnerBlocks.Content` : sans cela, les plats ne seraient
 * pas sérialisés dans le contenu de l'article (voir le bloc parent).
 */
( function ( blocks, element, blockEditor, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    /* Miroir de Core\TexteRiche::AUTORISE — les deux listes se répondent :
       gras, italique, barré, indice, exposant. */
    var FORMATS = [
        'core/bold',
        'core/italic',
        'core/strikethrough',
        'core/subscript',
        'core/superscript',
    ];

    blocks.registerBlockType( 'spiralbase/menu-section', {
        edit: function ( props ) {
            var variante = ( props.context && props.context[ 'spiralbase/variante' ] ) || 'liste';

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-menu-section spiralbase-menu-section--' + variante,
            } );

            /* Le conteneur des plats porte lui-même les props des blocs
               internes : le composant `InnerBlocks` y interposerait deux
               `<div>`, et la grille de la variante « cartes », posée sur ce
               conteneur, ne s'appliquerait qu'à eux (revue 3.2). */
            var platsProps = blockEditor.useInnerBlocksProps(
                { className: 'spiralbase-menu-section__plats' },
                {
                    allowedBlocks: [ 'spiralbase/menu-plat' ],
                    template: [ [ 'spiralbase/menu-plat' ] ],
                }
            );

            return e(
                'section',
                blockProps,
                e( blockEditor.RichText, {
                    tagName: 'h3',
                    className: 'spiralbase-menu-section__titre',
                    /* Exactement les formats que le serveur laisse passer
                       (Core\TexteRiche) : ce que la barre d'outils propose
                       est ce que le front affichera. */
                    allowedFormats: FORMATS,
                    value: props.attributes.titre,
                    placeholder: __( 'Titre de la section (Entrées, Plats, Desserts…)', 'spiralbase' ),
                    onChange: function ( valeur ) {
                        props.setAttributes( { titre: valeur } );
                    },
                } ),
                e( 'div', platsProps )
            );
        },
        save: function () {
            return e( blockEditor.InnerBlocks.Content );
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.i18n
);
