<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocAvisGoogle;

use SpiralBase\Core\AttributsBloc;
use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;

/**
 * Rendu serveur du bloc `spiralbase/avis-google` (story 3.3).
 *
 * Lit le cache, et rien d'autre : aucun appel réseau ne part du chemin d'un
 * visiteur (AC 1). Pas de données ⇒ bloc vide, jamais de message d'erreur à
 * l'écran (AC 2, AD-3).
 *
 * Trois règles que le code ne doit jamais enfreindre :
 *  - la note agrégée affichée est CELLE DE GOOGLE, jamais recalculée depuis
 *    les avis retenus : afficher « 4,8 » calculé sur trois avis choisis
 *    pendant que Google affiche « 4,1 » serait une contre-vérité opposable
 *    au client ;
 *  - le texte d'un avis est du TEXTE, jamais du HTML. Il vient d'un inconnu :
 *    une liste blanche « emphase » y laissait passer quarante `<br>`, un
 *    `<b>PROMO chez mon concurrent</b>` et un `<s>` barrant le nom de
 *    l'établissement — et supprimait au passage un « menu <plat du jour> »
 *    parfaitement légitime (revue 3.3) ;
 *  - l'attribution est obligatoire (conditions d'utilisation de l'API
 *    Places) : chaque avis cite son auteur, renvoie vers l'avis d'origine, et
 *    la source est nommée avec un lien vers la fiche — construit depuis
 *    l'identifiant de lieu quand la réponse n'en fournit pas.
 */
final class RenduAvis
{
    private const NOMBRE_DEFAUT = 3;

    /** Places (New) ne renvoie jamais plus de 5 avis : au-delà, la borne est cosmétique. */
    private const NOMBRE_MAX = 5;

    public function __construct(private readonly AvisGoogle $service)
    {
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs): string
    {
        try {
            return $this->composer($attributs);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_avis_google_echec', 'rendu interrompu : ' . $e->getMessage(), 'avis google');

            return '';
        }
    }

    /** @param array<string, mixed> $attributs */
    private function composer(array $attributs): string
    {
        $donnees = $this->service->donnees();

        if ($donnees === null) {
            return '';
        }

        $entete = AttributsBloc::booleen($attributs, 'afficherNote', true) ? $this->entete($donnees) : '';
        $liste  = $this->avis($donnees, $attributs);

        /* Ni note ni témoignage : une coquille contenant le seul lien
           « Avis publiés sur Google » n'attribue rien et n'apprend rien
           (AD-3). */
        if ($entete === '' && $liste === '') {
            return '';
        }

        return '<div ' . EnveloppeBloc::attributs('spiralbase-avis-google') . '>'
            . $entete . $liste . $this->attribution()
            . '</div>';
    }

    /** @param array<string, mixed> $donnees */
    private function entete(array $donnees): string
    {
        $note  = $donnees['note'] ?? null;
        $total = (int) ($donnees['total'] ?? 0);

        /* Établissement sans avis, ou charge sans note : pas d'en-tête
           inventé. « 0,0 ☆☆☆☆☆ 0 avis » est une contre-preuve sociale que
           Google n'a jamais publiée. */
        if (!is_float($note) || $total <= 0) {
            return '';
        }

        return '<p class="spiralbase-avis-google__note">'
            . '<span class="spiralbase-avis-google__valeur">' . esc_html(number_format_i18n($note, 1)) . '</span>'
            . ' <span class="spiralbase-avis-google__etoiles" aria-hidden="true">' . $this->etoiles($note) . '</span>'
            . ' <span class="spiralbase-avis-google__total">'
            /* translators: %s : nombre d'avis. */
            . esc_html(sprintf(_n('%s avis', '%s avis', $total, 'spiralbase'), number_format_i18n($total)))
            . '</span></p>';
    }

    /**
     * Les étoiles sont décoratives (`aria-hidden`) : la note chiffrée qui les
     * précède est la version lisible par un lecteur d'écran, et elle est plus
     * précise.
     *
     * L'arrondi est un arrondi PAR DÉFAUT, avec demi-étoile : `round()`
     * affichait cinq étoiles pleines pour 4,6 — l'illustration surévaluait
     * la note que le texte, lui, donne exactement.
     */
    private function etoiles(float $note): string
    {
        $note    = max(0.0, min(5.0, $note));
        $pleines = (int) floor($note);
        $demie   = ($note - $pleines) >= 0.5 ? 1 : 0;

        return str_repeat('★', $pleines)
            . str_repeat('⯨', $demie)
            . str_repeat('☆', 5 - $pleines - $demie);
    }

    /**
     * @param array<string, mixed> $donnees
     * @param array<string, mixed> $attributs
     */
    private function avis(array $donnees, array $attributs): string
    {
        $nombre  = $this->entier($attributs['nombre'] ?? null, self::NOMBRE_DEFAUT, 1, self::NOMBRE_MAX);
        $minimum = $this->entier($attributs['noteMinimale'] ?? null, 0, 0, 5);
        $rendus  = '';
        $poses   = 0;

        foreach ($donnees['avis'] ?? [] as $avis) {
            if ($poses >= $nombre) {
                break;
            }

            if (!is_array($avis)) {
                continue;
            }

            /* Un avis dont Google n'a pas renvoyé la note n'est pas un avis à
               zéro étoile : le filtre ne s'applique qu'à ce qui est noté. */
            $note = $avis['note'] ?? null;

            if ($minimum > 0 && is_int($note) && $note < $minimum) {
                continue;
            }

            $html = $this->unAvis($avis);

            /* Un avis qui ne rend rien ne consomme pas le budget d'affichage :
               trois demandés donnaient un seul témoignage (revue 3.3). */
            if ($html === '') {
                continue;
            }

            $rendus .= $html;
            $poses++;
        }

        return $rendus === '' ? '' : '<ul class="spiralbase-avis-google__liste">' . $rendus . '</ul>';
    }

    /** @param array<string, mixed> $avis */
    private function unAvis(array $avis): string
    {
        $brut = trim((string) ($avis['texte'] ?? ''));

        if ($brut === '') {
            return '';
        }

        /* Texte d'un inconnu : échappé, jamais interprété. `nl2br` conserve
           la mise en forme réelle d'un avis (des retours ligne) sans lui
           ouvrir le HTML. */
        $texte     = nl2br(esc_html($brut));
        $auteur    = esc_html((string) ($avis['auteur'] ?? ''));
        $urlAuteur = (string) ($avis['url_auteur'] ?? '');
        $signature = $urlAuteur === ''
            ? $auteur
            : '<a href="' . esc_url($urlAuteur) . '" rel="nofollow noopener">' . $auteur . '</a>';
        $quand     = trim((string) ($avis['quand'] ?? ''));
        $note      = $avis['note'] ?? null;
        $langue    = trim((string) ($avis['langue'] ?? ''));
        $urlAvis   = (string) ($avis['url'] ?? '');

        /* `dir="auto"` fait porter la direction au NAVIGATEUR d'après le
           premier caractère fort : un avis arabe dans une page française
           s'affiche à l'endroit, ponctuation et nombres compris. */
        $citation = '<blockquote class="spiralbase-avis-google__texte" dir="auto"'
            . ($langue === '' ? '' : ' lang="' . esc_attr($langue) . '"')
            . '>' . $texte . '</blockquote>';

        return '<li class="spiralbase-avis-google__avis">'
            . $this->noteDeLAvis($note)
            . $citation
            . '<p class="spiralbase-avis-google__auteur">' . $signature
            . ($quand === '' ? '' : ' <span class="spiralbase-avis-google__date">' . esc_html($quand) . '</span>')
            . ($urlAvis === '' ? '' : ' <a class="spiralbase-avis-google__lien" href="' . esc_url($urlAvis) . '" rel="nofollow noopener">'
                . esc_html__('Voir l’avis', 'spiralbase') . '</a>')
            . '</p></li>';
    }

    /**
     * La note d'un avis existe aussi pour qui ne voit pas les étoiles :
     * elles sont décoratives, l'équivalent textuel est lu par les lecteurs
     * d'écran.
     */
    private function noteDeLAvis(mixed $note): string
    {
        if (!is_int($note)) {
            return '';
        }

        return '<p class="spiralbase-avis-google__avis-note">'
            . '<span class="screen-reader-text">'
            /* translators: %s : note de l'avis, sur 5. */
            . esc_html(sprintf(__('Note : %s sur 5', 'spiralbase'), number_format_i18n($note)))
            . '</span>'
            . '<span aria-hidden="true">' . $this->etoiles((float) $note) . '</span>'
            . '</p>';
    }

    private function attribution(): string
    {
        $url     = $this->service->urlFiche();
        $libelle = esc_html__('Avis publiés sur Google', 'spiralbase');

        return '<p class="spiralbase-avis-google__source">'
            . ($url === '' ? $libelle : '<a href="' . esc_url($url) . '" rel="nofollow noopener">' . $libelle . '</a>')
            . '</p>';
    }

    /**
     * Le cœur valide le TYPE d'un attribut sans le convertir
     * (`class-wp-block-type.php:497-533`) : une valeur écrite à la main peut
     * arriver en chaîne, et les bornes du `block.json` ne protègent pas un
     * appel direct du `render_callback`.
     */
    private function entier(mixed $valeur, int $defaut, int $min, int $max): int
    {
        if (is_bool($valeur) || (!is_int($valeur) && !is_string($valeur) && !is_float($valeur))) {
            return $defaut;
        }

        if (is_string($valeur) && !is_numeric($valeur)) {
            return $defaut;
        }

        return max($min, min($max, (int) $valeur));
    }
}
