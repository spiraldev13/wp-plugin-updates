<?php
if (!defined('ABSPATH')) {
    exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php wp_head(); ?>
</head>
<body <?php body_class('mood-quantum density-editorial'); ?>>
<?php wp_body_open(); ?>

<a class="sr-only skip-link" href="#content"><?php esc_html_e('Aller au contenu', 'evolutionr'); ?></a>

<div class="page">
    <header class="header" role="banner">
        <div class="container header-inner">
            <?php
            $logoUrl  = evolutionr_logo_url();
            $logoAlt  = evolutionr_logo_alt();
            $hasLogo  = evolutionr_has_logo();
            ?>
            <a class="logo-mark<?php echo $hasLogo ? ' logo-mark--image-only' : ''; ?>" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr($logoAlt); ?>">
                <img src="<?php echo esc_url($logoUrl); ?>" alt="<?php echo esc_attr($logoAlt); ?>" width="32" height="32">
                <?php if (!$hasLogo) : ?>
                    <span class="logo-text">EVOLUTION<span class="accent">'R</span></span>
                <?php endif; ?>
            </a>

            <button class="nav-toggle" type="button" data-nav-toggle aria-controls="primary-nav" aria-expanded="false" aria-label="<?php esc_attr_e('Ouvrir le menu', 'evolutionr'); ?>">
                <svg class="icon-open" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                <svg class="icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>

            <nav class="nav" id="primary-nav" data-nav aria-label="<?php esc_attr_e('Navigation principale', 'evolutionr'); ?>">
                <?php
                wp_nav_menu([
                    'theme_location' => 'main',
                    'container'      => false,
                    'items_wrap'     => '%3$s',
                    'walker'         => new Walker_Nav_Header(),
                    'depth'          => 2,
                    'fallback_cb'    => false,
                ]);
                ?>

                <div class="header-cta-mobile">
                    <?php evolutionr_header_ctas(); ?>
                </div>
            </nav>

            <div class="header-cta">
                <?php evolutionr_header_ctas(); ?>
            </div>
        </div>
    </header>

    <main id="content">
