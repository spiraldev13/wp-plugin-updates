# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/),
et ce projet adhère au [Semantic Versioning](https://semver.org/lang/fr/).

---

## [Unreleased]

### Ajoute
- Images IA : huit modeles Flux integres (Flux Dev, Pro 1.1, Pro 1.1 Ultra,
  FLUX.2 Klein 4B/9B, Pro, Flex, Max) et modeles personnalises ajoutables dans
  les reglages (endpoint, libelle, mode de dimensions, prix).
- Images IA : bloc Gutenberg « Image IA » a inserer n'importe ou dans le
  contenu, remplace par un bloc image natif apres generation.
- Images IA : cout estime affiche avant chaque generation (metabox, bloc,
  confirmation du bouton colonne, notice bulk), grille de prix modifiable, et
  suivi de consommation (compteur mensuel + journal des 200 dernieres
  generations, meta `_ultimate_shanks_ai_cost` sur chaque image).

### Corrige
- Images IA : le parametre `aspect_ratio` etait envoye a des endpoints qui ne
  l'acceptent pas (seul `/flux-pro-1.1-ultra` le supporte) — les images
  sortaient toujours en 1024x768. Le format est desormais converti en
  `width`/`height` (~1 megapixel, multiples de 32) pour les modeles concernes.
- Images IA : les erreurs metier (cle absente, moderation, timeout) arrivaient
  en HTTP 4xx/5xx et s'affichaient en « Erreur inattendue » — le message
  detaille est desormais lu depuis la reponse JSON.
- Module Images IA (`src/ai-images/`) : generation d'images via l'API Flux de
  Black Forest Labs, avec abstraction fournisseur extensible (filtre
  `ultimate_shanks_ai_image_providers`). Desactive par defaut.
- Quatre declencheurs : metabox dans l'editeur (articles et pages), bouton
  « Generer par IA » dans la colonne d'image a la une, action groupee (3 contenus
  par lot au maximum) et endpoint REST `POST /cmd/v1/ai-image`.
- Import des images en mediatheque avec texte alternatif et metadonnees de
  tracabilite (`_ultimate_shanks_ai_*` : prompt, fournisseur, modele, date).
- Onglet de reglages « Images IA » : fournisseur, format et destination par
  defaut, cle API jamais reaffichee (constante `ULTIMATE_SHANKS_BFL_API_KEY`
  prioritaire), test de connexion sans consommation de credit.
- Diagnostic Site Health en lecture seule pour le module Images IA.
- Hook `ultimate_shanks_featured_image_column_actions` dans la colonne d'image
  a la une pour les actions de modules tiers.
- Diagnostics en lecture seule dans Sante du site pour le CSS genere, le manifeste de mise a jour et les integrations.
- Controle d'activation de l'integration Rank Math dans l'onglet Options.
- Documentation utilisateur, technique et securite alignee sur la version 1.10.0.

### Modifie
- Les routes REST Otomatic AI et Rank Math ne sont plus enregistrees lorsque leur integration est desactivee.
- La valeur par defaut des integrations reste active pour preserver les installations existantes.

### Securite
- Validation AJAX de l'existence du contenu, du type de piece jointe, du MIME image et des capacites sur le contenu et le media.
- Documentation explicite de la limite actuelle de la verification SHA-256 des mises a jour.

## [1.1.2] - 2025-12-02

### Corrigé
- **CRITIQUE : Sauvegarde des paramètres Style**
  - Les champs texte de couleur avaient le même `name` que les color pickers, causant des conflits lors de la soumission
  - Les champs texte sont maintenant en lecture seule (readonly) et servent uniquement d'affichage
  - Seul le color picker envoie la valeur au serveur
  - **Impact** : Les modifications de couleurs sont maintenant correctement sauvegardées

### Modifié
- `src/style/settings.php` - Suppression de l'attribut `name` sur tous les champs texte de couleur (readonly)
- `assets/js/style-manager-admin.js` - Simplification de la synchronisation color picker ↔ texte (unidirectionnelle)

---

## [1.1.1] - 2025-12-02

### Corrigé
- **CRITIQUE : Préservation des paramètres Style lors des mises à jour**
  - Le fichier `generated-styles.css` n'est plus versionné dans Git (.gitignore)
  - Le hook d'activation régénère automatiquement le CSS depuis les options WordPress existantes
  - Les styles personnalisés sont maintenant préservés lors des mises à jour du plugin
  - **Impact** : Résout le problème où les utilisateurs devaient reconfigurer leurs styles après chaque mise à jour

### Modifié
- `wp-github-updater.php` - Hook d'activation amélioré avec régénération intelligente du CSS
- `.gitignore` - Ajout de `assets/css/generated-styles.css`

---

## [1.1.0] - 2025-12-02

### Ajouté
- **Suppression des séparateurs HR**
  - Nouvelle option dans "Corrections SEO automatiques"
  - Supprime toutes les balises `<hr>` du contenu (y compris séparateurs Gutenberg)
  - Checkbox d'exception par article : "Conserver les séparateurs (HR) pour cet article"
  - Permet de garder les HR sur des articles spécifiques même avec l'option globale activée
  - Nettoyage automatique des sauts de ligne multiples après suppression

- **Refactorisation complète du code**
  - Headers détaillés sur tous les fichiers PHP documentant les assets associés
  - Séparation complète HTML/CSS/JS du code PHP
  - Code "simple et efficace" comme demandé
  - Documentation claire et concise

### Modifié
- `src/text-enhancer/settings.php` - Ajout option suppression HR dans SEO
- `src/text-enhancer/text-enhancer.php` - Gestion exception HR par article + metabox
- `src/text-enhancer/processor.php` - Logique de suppression des balises `<hr>`
- README.md - Restructuration complète (170 lignes vs 722 lignes)
- DEVELOPMENT.md - Guide technique exhaustif pour développeurs et IA

### Supprimé
- 10 fichiers .md obsolètes (FEATURES.md, H2_*.md, etc.)
- Fichiers .bak et .broken
- 198 lignes de CSS/JS inline dans settings.php

---

## [1.0.1] - 2025-11-27

### Ajouté
- **Séparation CSS/JS**
  - Extraction du CSS inline vers `/assets/css/admin-settings.css`
  - CSS maintenant minifiable par WP Rocket et autres plugins de cache
  - JavaScript extrait dans `/assets/js/style-manager-admin.js`
  - Enqueue automatique et conditionnel des assets admin

- **Documentation**
  - Commentaires détaillés dans tous les fichiers PHP
  - DEVELOPMENT.md avec guide technique complet
  - README.md professionnel restructuré
  - Consignes de base pour l'IA documentées

- **Optimiseur de Paragraphes**
  - Option pour désactiver l'optimisation sur un article spécifique (modes Standard/Conservateur)
  - La metabox s'adapte automatiquement au mode configuré
  - Permet un contrôle granulaire article par article

### Modifié
- `src/style/style-manager.php` - Enqueue CSS + JS admin
- `src/style/settings.php` - CSS et JS inline supprimés
- `assets/css/admin-settings.css` - Styles complets pour l'admin
- `src/text-enhancer/text-enhancer.php` - Ajout option de désactivation par article
- Architecture: code modulaire, propre et maintenable

### Corrigé
- Permissions du fichier CSS généré (chmod 666 pour permettre l'écriture par www-data)
- Génération du CSS lors de la sauvegarde des paramètres de style
- **Optimiseur de Paragraphes** : Les tableaux ne bloquent plus tout le traitement
  - Avant : Un tableau dans l'article empêchait le traitement de TOUS les paragraphes
  - Après : Seuls les paragraphes contenant des tableaux sont ignorés
  - Les autres paragraphes sont traités normalement

---

## [1.0.0] - 2025-11-27

### Ajouté
- **Style Manager** - Système complet de gestion des styles CSS
  - Support des titres H1-H6 avec couleur, fond avec opacité, padding, margin, bordure, angles arrondis
  - Support des listes UL et OL avec couleur, fond avec opacité, padding, margin, bordure, angles arrondis
  - Support des tableaux TH et TD avec couleur, fond avec opacité, padding, bordure
  - Support des liens A avec couleur normale/survol, décoration, font-weight, transition
  - Support des citations Blockquote avec couleur texte, fond avec opacité, padding, bordure gauche
  - Système de checkbox pour activer/désactiver la couleur de fond avec gestion de l'opacité
  - Conversion automatique hex vers rgba() quand l'opacité est inférieure à 1
  - Scope d'application configurable (Global, Articles uniquement, Pages uniquement)
  - Interface utilisateur dépliable pour une meilleure organisation
  - Génération automatique de CSS optimisé dans `/assets/css/generated-styles.css`

- **Text Enhancer (Optimiseur de Paragraphes)**
  - Amélioration automatique de la typographie et de la lisibilité
  - Metabox dans l'éditeur WordPress pour contrôle par article/page
  - Traitement intelligent du contenu

- **Featured Images Manager**
  - Gestion avancée des images à la une
  - Configuration personnalisée via l'interface d'administration

- **Auto-Updater GitHub**
  - Système de mise à jour automatique depuis GitHub (dépôt privé)
  - Configuration via token personnel GitHub
  - Vérification automatique des nouvelles versions
  - Installation en un clic depuis l'admin WordPress

- **Architecture**
  - Structure modulaire avec namespaces PHP
  - Séparation claire des responsabilités
  - Hooks WordPress pour extensibilité

### Modifié
- Décoration des liens définie sur "Aucune" par défaut
- Bordure gauche des citations avec valeur par défaut de 4px
- Organisation du code en modules indépendants

### Supprimé
- Option "Texte en italique" pour les citations (comportement natif conservé)
- Option "Angles arrondis" pour les tableaux (simplification de l'interface)

### Technique
- Implémentation du système de checkbox `.hn-bg-checkbox` pour toggle d'affichage
- Utilisation de classes conditionnelles `.hn-bg-row` et `.hn-opacity-row`
- JavaScript générique pour gestion des sliders d'opacité
- Pattern de génération CSS réutilisable pour tous les éléments HTML

---

## Notes historiques non publiees

### Modifié
- **Mises à jour post-migration (path lock)**
  - Suppression du renommage automatique du dossier plugin pendant l'upgrade.
  - Chemin canonique désormais requis : `ultimate-shanks/ultimate-shanks.php`.
  - Les installations legacy (ex: dossier suffixé par branche) ne sont plus supportées après migration.
  - Ajout d'un diagnostic admin explicite "migration requise" si le chemin réel n'est pas canonique.

### À venir
- Export/Import des configurations de style
- Prévisualisations en temps réel des styles
- Bibliothèque de presets de styles
- Mode dark/light pour l'interface d'administration
- API REST pour gestion programmatique des styles

---

## Guide des versions

### Types de changements
- **Ajouté** - Nouvelles fonctionnalités
- **Modifié** - Changements dans les fonctionnalités existantes
- **Déprécié** - Fonctionnalités qui seront supprimées
- **Supprimé** - Fonctionnalités retirées
- **Corrigé** - Corrections de bugs
- **Sécurité** - Correctifs de vulnérabilités

### Numérotation sémantique (SemVer)
- **MAJOR** (X.0.0) - Changements incompatibles avec les versions précédentes
- **MINOR** (0.X.0) - Nouvelles fonctionnalités compatibles avec les versions précédentes
- **PATCH** (0.0.X) - Corrections de bugs compatibles avec les versions précédentes
