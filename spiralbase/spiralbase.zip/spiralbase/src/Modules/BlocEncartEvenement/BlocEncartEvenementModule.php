<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocEncartEvenement;

use SpiralBase\Core\Module;
use SpiralBase\Core\Signal;

/**
 * Bloc « encart événementiel auto-expirant » (CAP-12, story 3.6).
 *
 * OFF par défaut (AD-6). Aucune sonde de cession (`null`) : aucun plugin
 * d'événements n'est installé dans l'environnement de dev, et la discipline du
 * projet interdit une sonde sur des faits non lus (leçon 2.4). Le fond est
 * celui du carrousel (3.5) : ce bloc ne rend que là où l'opérateur l'a POSÉ —
 * céder ferait disparaître un encart explicitement placé.
 *
 * LIMITE CONNUE, propre à ce bloc et vérifiée en revue : éteindre le module
 * alors que des encarts existent en base les fait RÉAPPARAÎTRE, périmés
 * compris. C'est le comportement du cœur pour tout bloc non enregistré — il
 * rend alors le contenu sérialisé, ici les `InnerBlocks` — et non un défaut du
 * module ; mais la conséquence est ici l'inverse de l'intention, là où un
 * carrousel éteint se dégrade sans danger. Le module doit donc rester allumé
 * tant qu'un encart subsiste dans les contenus.
 */
final class BlocEncartEvenementModule implements Module
{
    public const HANDLE_STYLE = 'spiralbase-encart-evenement';

    public const NOM = 'spiralbase/encart-evenement';

    private const REPERTOIRE = 'encart-evenement';

    public function slug(): string
    {
        return 'bloc_encart_evenement';
    }

    public function boot(): void
    {
        add_action('init', static function (): void {
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => static fn (array $attributs, string $contenu = '', mixed $bloc = null): string
                    => (new RenduEncart())->rendre($attributs, $contenu, $bloc)]
            );

            if ($type === false) {
                $doublon = class_exists('WP_Block_Type_Registry')
                    && \WP_Block_Type_Registry::get_instance()->is_registered(self::NOM);

                Signal::emettre(
                    'spiralbase_bloc_encart_enregistrement_echoue',
                    $doublon
                        ? 'bloc « encart-evenement » non enregistré : le nom ' . self::NOM . ' est déjà enregistré par une extension ou un thème enfant'
                        : 'bloc « encart-evenement » non enregistré : répertoire ou block.json illisible',
                    'bloc encart'
                );
            }
        });

        /*
         * Ce bloc n'entre dans AUCUNE des deux listes d'extrait, contrairement
         * au menu (3.2) et au carrousel (3.5). C'est un choix, et il est
         * mécanique — pas une politique à respecter.
         *
         * Le premier jet inscrivait le bloc dans `excerpt_allowed_blocks` en
         * comptant sur `render_block()` (`blocks.php:2259`) pour appliquer la
         * garde d'expiration. Faux dès qu'un ANCÊTRE est un wrapper : le cœur
         * passe alors par `_excerpt_render_inner_blocks()`, qui recurse dans
         * tout bloc autorisé ayant des enfants (`blocks.php:2298-2314`) et
         * rend ces enfants DIRECTEMENT — le `render_callback` du parent n'est
         * jamais appelé. Un simple « Grouper » dans Gutenberg suffisait donc à
         * republier un encart périmé : prouvé en revue sur la page de
         * recherche du site, dans le flux RSS et dans les balises de partage.
         *
         * Hors des listes, le cœur ignore le bloc aux DEUX endroits
         * (`:2241` au premier niveau, `:2302` dans la récursion) : aucune
         * profondeur d'imbrication ne peut faire fuir un contenu périmé.
         *
         * Contrepartie assumée : un encart, même valide, ne nourrit jamais
         * l'extrait automatique. C'est cohérent avec ce qu'il est — une
         * annonce datée posée À CÔTÉ du contenu, qui n'a pas vocation à
         * décrire la page dans les moteurs et les partages.
         */
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
