<?php
/**
 * Title: Encadré Information
 * Slug: techana-revue/note-information
 * Categories: techana
 * Keywords: note, information, encadré
 * Viewport Width: 720
 * Description: Encadré d'information du corps d'article (design article) —
 * filet bleu rubrique, titre en capitales, un paragraphe.
 */
?>
<!-- wp:group {"className":"note info"} -->
<div class="wp-block-group note info"><!-- wp:heading {"level":4} -->
<h4 class="wp-block-heading">Information</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Le complément utile qui n'interrompt pas la lecture : précision de version, prérequis, cas particulier.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
