<?php
/**
 * Preloader maison — overlay léger affiché pendant le chargement, piloté par le Customizer
 * (Apparence → Personnaliser → Preloader).
 *
 * Remplace le plugin The Preloader sans dégrader le LCP : le contenu n'est jamais masqué
 * (l'overlay se superpose seulement). Il disparaît au chargement de la page (window.load),
 * mais pas avant la durée minimale ; la durée maximale reste un plafond absolu.
 */

if (!defined('ABSPATH')) {
    exit;
}

function divi_child_preloader_defaults() {
    return [
        'enabled'  => true,
        'style'    => 'image',
        'image'    => get_stylesheet_directory_uri() . '/images/preloader.gif',
        'bg_color' => '#f8f9fa',
        'min_time' => 0,
        'max_time' => 3,
        'scope'    => 'site',
    ];
}

function divi_child_preloader_option($key) {
    $defaults = divi_child_preloader_defaults();

    return get_theme_mod('divi_child_preloader_' . $key, $defaults[$key]);
}

/**
 * Durée en secondes arrondie à la demi-seconde et bornée ; accepte « 1,5 » comme « 1.5 ».
 */
function divi_child_preloader_sanitize_seconds($value, $min) {
    $seconds = round((float) str_replace(',', '.', (string) $value) * 2) / 2;

    return min(10, max($min, $seconds));
}

function divi_child_preloader_sanitize_min_time($value) {
    return divi_child_preloader_sanitize_seconds($value, 0);
}

function divi_child_preloader_sanitize_max_time($value) {
    return divi_child_preloader_sanitize_seconds($value, 1);
}

function divi_child_preloader_sanitize_scope($value) {
    return in_array($value, ['site', 'home', 'pages_posts'], true) ? $value : 'site';
}

function divi_child_preloader_sanitize_style($value) {
    return in_array($value, ['image', 'canard', 'infinity'], true) ? $value : 'image';
}

/**
 * Enregistre la section Customizer « Preloader » et ses réglages.
 *
 * @param WP_Customize_Manager $wp_customize
 */
function divi_child_preloader_customize($wp_customize) {
    $defaults  = divi_child_preloader_defaults();
    $sanitizes = [
        'enabled'  => 'wp_validate_boolean',
        'style'    => 'divi_child_preloader_sanitize_style',
        'image'    => 'esc_url_raw',
        'bg_color' => 'sanitize_hex_color',
        'min_time' => 'divi_child_preloader_sanitize_min_time',
        'max_time' => 'divi_child_preloader_sanitize_max_time',
        'scope'    => 'divi_child_preloader_sanitize_scope',
    ];

    $wp_customize->add_section('divi_child_preloader', [
        'title'       => __('Preloader', 'divi-child'),
        'description' => __('Écran de chargement affiché à l\'arrivée sur le site.', 'divi-child'),
        'priority'    => 200,
    ]);

    foreach ($sanitizes as $key => $callback) {
        $wp_customize->add_setting('divi_child_preloader_' . $key, [
            'default'           => $defaults[$key],
            'sanitize_callback' => $callback,
        ]);
    }

    divi_child_preloader_controls($wp_customize);
}
add_action('customize_register', 'divi_child_preloader_customize');

/**
 * Ajoute les contrôles de la section « Preloader ».
 *
 * @param WP_Customize_Manager $wp_customize
 */
function divi_child_preloader_controls($wp_customize) {
    $wp_customize->add_control('divi_child_preloader_enabled', [
        'section' => 'divi_child_preloader',
        'label'   => __('Activer le preloader', 'divi-child'),
        'type'    => 'checkbox',
    ]);

    $wp_customize->add_control('divi_child_preloader_style', [
        'section' => 'divi_child_preloader',
        'label'   => __('Style du loader', 'divi-child'),
        'type'    => 'select',
        'choices' => [
            'image'    => __('Image', 'divi-child'),
            'canard'   => __('Canard animé (dessin)', 'divi-child'),
            'infinity' => __('Infinity (comme l\'ancien plugin)', 'divi-child'),
        ],
    ]);

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'divi_child_preloader_image', [
        'section'         => 'divi_child_preloader',
        'label'           => __('Image du loader', 'divi-child'),
        'description'     => __('Si vide, un spinner CSS est affiché.', 'divi-child'),
        // Visible uniquement avec le style « Image » : évite de choisir une image
        // qui ne s'affichera pas parce qu'un canard est actif.
        'active_callback' => function ($control) {
            return 'image' === $control->manager->get_setting('divi_child_preloader_style')->value();
        },
    ]));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'divi_child_preloader_bg_color', [
        'section' => 'divi_child_preloader',
        'label'   => __('Couleur de fond', 'divi-child'),
    ]));

    $wp_customize->add_control('divi_child_preloader_min_time', [
        'section'     => 'divi_child_preloader',
        'label'       => __('Durée minimale d\'affichage (secondes)', 'divi-child'),
        'description' => __('L\'overlay reste affiché au moins cette durée, même si la page est déjà chargée. 0 : il disparaît dès le chargement.', 'divi-child'),
        'type'        => 'number',
        'input_attrs' => ['min' => 0, 'max' => 10, 'step' => 0.5],
    ]);

    $wp_customize->add_control('divi_child_preloader_max_time', [
        'section'     => 'divi_child_preloader',
        'label'       => __('Durée maximale d\'affichage (secondes)', 'divi-child'),
        'description' => __('L\'overlay disparaît au plus tard à cette échéance, même si la page charge encore ; elle prime sur la durée minimale.', 'divi-child'),
        'type'        => 'number',
        'input_attrs' => ['min' => 1, 'max' => 10, 'step' => 0.5],
    ]);

    $wp_customize->add_control('divi_child_preloader_scope', [
        'section' => 'divi_child_preloader',
        'label'   => __('Afficher sur', 'divi-child'),
        'type'    => 'select',
        'choices' => [
            'site'        => __('Tout le site', 'divi-child'),
            'home'        => __('Page d\'accueil uniquement', 'divi-child'),
            'pages_posts' => __('Pages et articles', 'divi-child'),
        ],
    ]);
}

/**
 * L'overlay doit-il s'afficher sur la requête courante ?
 */
function divi_child_preloader_should_display() {
    if (!divi_child_preloader_option('enabled') || is_admin() || is_feed()) {
        return false;
    }

    // Jamais dans le Visual Builder Divi : l'overlay gênerait l'édition.
    if (function_exists('et_core_is_fb_enabled') && et_core_is_fb_enabled()) {
        return false;
    }

    $scope = divi_child_preloader_option('scope');

    if ('home' === $scope) {
        return is_front_page();
    }

    if ('pages_posts' === $scope) {
        return is_page() || is_singular('post');
    }

    return true;
}

function divi_child_preloader_is_canard($style) {
    return 'canard' === $style;
}

function divi_child_preloader_styles() {
    if (!divi_child_preloader_should_display()) {
        return;
    }

    $bg    = divi_child_preloader_option('bg_color');
    $style = divi_child_preloader_option('style');
    ?>
    <style id="divi-child-preloader-css">
        #divi-child-preloader{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;
            justify-content:center;background:<?php echo esc_attr($bg); ?>;opacity:1;transition:opacity .4s ease;}
        #divi-child-preloader.is-hidden{opacity:0;pointer-events:none;}
        .divi-child-preloader-spinner{width:48px;height:48px;border:4px solid rgba(0,0,0,.12);
            border-top-color:rgba(0,0,0,.5);border-radius:50%;animation:divi-child-preloader-spin 1s linear infinite;}
        @keyframes divi-child-preloader-spin{to{transform:rotate(360deg);}}
        <?php if (divi_child_preloader_is_canard($style)) {
            divi_child_preloader_canard_css();
        } elseif ('infinity' === $style) {
            divi_child_preloader_infinity_css();
        } ?>
        @media (prefers-reduced-motion:reduce){
            #divi-child-preloader{transition:none;}
            .divi-child-preloader-spinner,.divi-child-canard-duck,
            .divi-child-preloader-infinity::before,.divi-child-preloader-infinity::after{animation:none;}
        }
    </style>
    <?php
}
add_action('wp_head', 'divi_child_preloader_styles', 1);

/**
 * CSS du canard (couleurs surchargeables par variables CSS).
 */
function divi_child_preloader_canard_css() {
    ?>
        .divi-child-preloader-canard{position:relative;width:120px;height:96px;}
        .divi-child-canard-duck{position:absolute;inset:0;transform-origin:50% 70%;
            animation:divi-child-canard-bob 1.8s ease-in-out infinite;}
        .divi-child-canard-duck svg{display:block;width:100%;height:100%;}
        @keyframes divi-child-canard-bob{
            0%,100%{transform:translateY(0) rotate(-2deg);}
            50%{transform:translateY(5px) rotate(3deg);}
        }
    <?php
}

/**
 * CSS du loader « Infinity » — reprise du template infinity-loader de l'ancien
 * plugin The Preloader (deux carrés à coins arrondis en contre-rotation),
 * avec la couleur configurée à l'époque (#aeb3b7).
 */
function divi_child_preloader_infinity_css() {
    ?>
        .divi-child-preloader-infinity{position:relative;width:60px;height:30px;transform:rotate(90deg);}
        .divi-child-preloader-infinity::before,.divi-child-preloader-infinity::after{content:'';
            position:absolute;top:0;left:0;width:30px;height:30px;
            border:4px solid var(--dc-infinity,#aeb3b7);border-radius:50px 50px 0 50px;
            transform:rotate(-45deg);animation:divi-child-infinity-a 2s linear infinite;}
        .divi-child-preloader-infinity::after{left:auto;right:0;border-radius:50px 50px 50px 0;
            transform:rotate(45deg);animation:divi-child-infinity-b 2s linear infinite;}
        @keyframes divi-child-infinity-a{
            0%{transform:rotate(-45deg);}50%{transform:rotate(135deg);}100%{transform:rotate(315deg);}
        }
        @keyframes divi-child-infinity-b{
            0%{transform:rotate(45deg);}50%{transform:rotate(225deg);}100%{transform:rotate(405deg);}
        }
    <?php
}

/**
 * Canard cartoon en SVG inline : jaune vif à gros contour noir, style pictogramme
 * (référence fournie par l'utilisateur dans img/canard.jpg — dessin original, pas une copie).
 * Couleurs surchargeables par variables CSS (variante mauve).
 */
function divi_child_preloader_duck_svg() {
    $trait = 'stroke:#1c1c1c;stroke-width:5;stroke-linejoin:round;stroke-linecap:round';

    return '<svg viewBox="0 0 150 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">'
        // Queue pointue relevée à l'arrière
        . '<path style="fill:var(--dc-corps,#ffd800);' . $trait . '" d="M12 36 Q34 44 46 60 Q28 70 18 62'
        . ' Q8 48 12 36 Z"/>'
        // Corps (bien rond, comme la référence)
        . '<ellipse style="fill:var(--dc-corps,#ffd800);' . $trait . '" cx="66" cy="78" rx="50" ry="34"/>'
        // Tête ronde (grosse, comme la référence)
        . '<circle style="fill:var(--dc-corps,#ffd800);' . $trait . '" cx="96" cy="34" r="30"/>'
        // Aile au trait sur le corps
        . '<path style="fill:var(--dc-corps,#ffd800);' . $trait . '" d="M42 72 Q70 58 94 72 Q90 96 62 100'
        . ' Q42 92 42 72 Z"/>'
        . '<path style="fill:none;' . $trait . ';stroke-width:4" d="M54 84 L84 79 M56 92 L80 88"/>'
        // Bec orange
        . '<path style="fill:var(--dc-bec,#f5893d);' . $trait . '" d="M124 26 Q142 30 145 40 Q142 50 126 48'
        . ' Q120 37 124 26 Z"/>'
        // Œil
        . '<circle style="fill:#1c1c1c" cx="108" cy="28" r="5"/>'
        . '</svg>';
}

function divi_child_preloader_duck_html() {
    return '<span class="divi-child-canard-duck">' . divi_child_preloader_duck_svg() . '</span>';
}

/**
 * HTML du loader canard : conteneur et canard seul.
 */
function divi_child_preloader_canard_html() {
    return '<span class="divi-child-preloader-canard">'
        . divi_child_preloader_duck_html()
        . '</span>';
}

function divi_child_preloader_markup() {
    if (!divi_child_preloader_should_display()) {
        return;
    }

    $style  = divi_child_preloader_option('style');
    $image  = divi_child_preloader_option('image');
    $max_ms = (int) round(divi_child_preloader_option('max_time') * 1000);
    // Le plafond prime : un minimum supérieur au maximum est ramené au maximum.
    $min_ms = min((int) round(divi_child_preloader_option('min_time') * 1000), $max_ms);
    ?>
    <div id="divi-child-preloader" aria-hidden="true">
        <?php if (divi_child_preloader_is_canard($style)) : ?>
            <?php echo divi_child_preloader_canard_html(); ?>
        <?php elseif ('infinity' === $style) : ?>
            <span class="divi-child-preloader-infinity"></span>
        <?php elseif ($image) : ?>
            <img src="<?php echo esc_url($image); ?>" alt="" width="64" height="64"
                 fetchpriority="low" decoding="async">
        <?php else : ?>
            <span class="divi-child-preloader-spinner"></span>
        <?php endif; ?>
    </div>
    <script>
        (function () {
            var overlay = document.getElementById('divi-child-preloader');
            if (!overlay) { return; }
            var isHidden = false;
            var shownAt = Date.now();
            function hide() {
                if (isHidden) { return; }
                isHidden = true;
                overlay.classList.add('is-hidden');
                setTimeout(function () {
                    if (overlay.parentNode) { overlay.parentNode.removeChild(overlay); }
                }, 400);
            }
            var reduceMotion = window.matchMedia
                && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            // Page chargée : on attend que la durée minimale soit écoulée depuis l'apparition.
            function hideAfterMin() {
                setTimeout(hide, Math.max(0, <?php echo (int) $min_ms; ?> - (Date.now() - shownAt)));
            }
            if (reduceMotion) {
                hide();
                return;
            }
            if (document.readyState === 'complete') {
                hideAfterMin();
                return;
            }
            window.addEventListener('load', hideAfterMin);
            setTimeout(hide, <?php echo (int) $max_ms; ?>);
        })();
    </script>
    <?php
}
add_action('wp_body_open', 'divi_child_preloader_markup');
