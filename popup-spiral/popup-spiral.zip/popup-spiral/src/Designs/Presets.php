<?php

namespace Spiral\Designs;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Les 6 designs fournis, définis en code : ils sont immuables,
 * toute modification passe par une copie dans « Mes designs ».
 */
final class Presets
{
    /**
     * @return array<string, array{name: string, settings: array}>
     */
    public static function all(): array
    {
        return [
            'annonce' => [
                'name' => __('Annonce', 'popup-spiral'),
                'settings' => [
                    'bg' => '#ffffff',
                    'accent' => '#2271b1',
                    'corners' => 'rounded',
                    'shadow' => 'soft',
                    'close_style' => 'cross',
                    'close_position' => 'inside',
                    'overlay' => 'dim',
                    'font' => 'theme',
                    'neutral' => false,
                ],
            ],
            'optin-email' => [
                'name' => __('Opt-in email', 'popup-spiral'),
                'settings' => [
                    'bg' => '#ffffff',
                    'accent' => '#16a34a',
                    'corners' => 'rounded',
                    'shadow' => 'strong',
                    'close_style' => 'cross',
                    'close_position' => 'outside',
                    'overlay' => 'blur',
                    'font' => 'modern',
                    'neutral' => false,
                ],
            ],
            'promo-urgence' => [
                'name' => __('Promo / urgence', 'popup-spiral'),
                'settings' => [
                    'bg' => '#111827',
                    'accent' => '#f59e0b',
                    'corners' => 'rounded',
                    'shadow' => 'strong',
                    'close_style' => 'cross',
                    'close_position' => 'inside',
                    'overlay' => 'dim',
                    'font' => 'modern',
                    'neutral' => false,
                ],
            ],
            'notice-basse' => [
                'name' => __('Notice discrète (bas)', 'popup-spiral'),
                'settings' => [
                    'bg' => '#f8fafc',
                    'accent' => '#2271b1',
                    'corners' => 'rounded',
                    'shadow' => 'soft',
                    'close_style' => 'text',
                    'close_position' => 'inside',
                    'overlay' => 'none',
                    'font' => 'modern',
                    'neutral' => false,
                ],
            ],
            'barre-flottante' => [
                'name' => __('Barre flottante', 'popup-spiral'),
                'settings' => [
                    'bg' => '#1e293b',
                    'accent' => '#38bdf8',
                    'corners' => 'square',
                    'shadow' => 'soft',
                    'close_style' => 'cross',
                    'close_position' => 'inside',
                    'overlay' => 'none',
                    'font' => 'modern',
                    'neutral' => false,
                ],
            ],
            'neutre-builder' => [
                'name' => __('Neutre (page builders)', 'popup-spiral'),
                'settings' => [
                    'bg' => '#ffffff',
                    'accent' => '#2271b1',
                    'corners' => 'square',
                    'shadow' => 'none',
                    'close_style' => 'cross',
                    'close_position' => 'outside',
                    'overlay' => 'dim',
                    'font' => 'theme',
                    'neutral' => true,
                ],
            ],
        ];
    }
}
