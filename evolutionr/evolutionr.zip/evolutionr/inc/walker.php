<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Walker du menu principal du header — supporte 2 niveaux.
 *
 * Markup produit :
 *
 *   Item top-level SANS enfants (lien classique) :
 *     <div class="nav-item">
 *         <a class="nav-link [active]" href="…">Libellé</a>
 *     </div>
 *
 *   Item top-level AVEC enfants (parent toggle) :
 *     <div class="nav-item has-submenu">
 *         <button type="button" class="nav-link nav-link--toggle [is-current]"
 *                 aria-expanded="false" data-submenu-toggle>
 *             Libellé <svg class="nav-chevron">…</svg>
 *         </button>
 *         <ul class="nav-submenu" role="menu">
 *             <li><a class="nav-sublink [active]" href="…">Enfant</a></li>
 *             …
 *         </ul>
 *     </div>
 *
 * Le parent d'un sous-menu est un `<button>` non navigable, pas un lien :
 * il sert uniquement à ouvrir/fermer le sous-menu (hover desktop + click).
 * Pas de destination → pas de 404 possible, sémantique HTML correcte,
 * accessibilité clavier native (Espace/Entrée déclenchent le toggle).
 *
 * La classe `is-current` (sur le button parent) ou `active` (sur les liens)
 * reprend `current-menu-item`, `current-menu-ancestor` et `current-menu-parent`.
 *
 * CSS associé : `app/stylesheets/components/_menu.scss`.
 * JS associé : `app/main.js` → `initSubmenuToggle()`.
 */
class Walker_Nav_Header extends Walker_Nav_Menu
{
    public $tree_type = ['post_type', 'taxonomy', 'custom'];

    public function start_lvl(&$output, $depth = 0, $args = null)
    {
        // Ouvre le <ul> du sous-menu uniquement entre niveau 0 et 1.
        if ($depth === 0) {
            $output .= '<ul class="nav-submenu" role="menu">';
        }
    }

    public function end_lvl(&$output, $depth = 0, $args = null)
    {
        if ($depth === 0) {
            $output .= '</ul>';
        }
    }

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        // Profondeur max imposée côté `wp_nav_menu(['depth' => 2])`.
        if ($depth > 1) {
            return;
        }

        $classes = empty($item->classes) ? [] : (array) $item->classes;
        $isActive = in_array('current-menu-item', $classes, true)
            || in_array('current-menu-ancestor', $classes, true)
            || in_array('current-menu-parent', $classes, true);

        $href  = !empty($item->url) ? esc_url($item->url) : '#';
        $title = esc_html(apply_filters('the_title', $item->title, $item->ID));

        if ($depth === 0) {
            $hasChildren = in_array('menu-item-has-children', $classes, true);
            $itemClasses = 'nav-item' . ($hasChildren ? ' has-submenu' : '');

            $output .= '<div class="' . esc_attr($itemClasses) . '">';

            if ($hasChildren) {
                // Parent d'un sous-menu : <button> non navigable, jamais un lien.
                // Pas de href = pas de 404 possible, et un <button> est la bonne
                // sémantique pour un toggle. aria-expanded reflète l'état ouvert/fermé.
                $btnClasses = 'nav-link nav-link--toggle' . ($isActive ? ' is-current' : '');

                $output .= '<button type="button" class="' . esc_attr($btnClasses) . '" aria-expanded="false" data-submenu-toggle>'
                         . $title
                         . '<svg class="nav-chevron" viewBox="0 0 12 8" aria-hidden="true" focusable="false">'
                         . '<path d="M1 1l5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'
                         . '</svg>'
                         . '</button>';
            } else {
                // Item top-level sans sous-menu : <a href> classique inchangé.
                $linkClasses = 'nav-link' . ($isActive ? ' active' : '');

                $output .= '<a href="' . $href . '" class="' . esc_attr($linkClasses) . '"'
                         . ($isActive ? ' aria-current="page"' : '')
                         . '>' . $title . '</a>';
            }
        } else {
            $linkClasses = 'nav-sublink' . ($isActive ? ' active' : '');
            $output .= '<li>';
            $output .= '<a href="' . $href . '" class="' . esc_attr($linkClasses) . '"'
                     . ($isActive ? ' aria-current="page"' : '')
                     . '>' . $title . '</a>';
        }
    }

    public function end_el(&$output, $item, $depth = 0, $args = null)
    {
        if ($depth > 1) {
            return;
        }

        if ($depth === 0) {
            $output .= '</div>';
        } else {
            $output .= '</li>';
        }
    }
}

if (!class_exists('Walker_Nav_Primary')) {
    class Walker_Nav_Primary extends Walker_Nav_Menu {}
}
