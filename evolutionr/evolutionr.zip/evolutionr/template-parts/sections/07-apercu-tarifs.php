<?php
/**
 * 07 — Section Aperçu tarifs (jusqu'à 6 tarifs d'entrée + CTA vers /tarifs/).
 *
 * Visuel : en-tête (eyebrow + titre + lede) puis grille de cartes tarifs
 * (type de prestation, prix « à partir de », description courte), suivie d'un
 * CTA principal vers la page Tarifs.
 *
 * Source de données — repeater ACF `apercu_tarifs_items` (front-page) :
 *   - `afficher`  : curation locale de l'accueil (retire la carte du sous-ensemble
 *     mis en avant, sans toucher à la visibilité globale de l'offre) ;
 *   - `offre_ref` : « catégorie|nom|facturation » → prix + visibilité lus en direct
 *     du modèle central via `evolutionr_offer_resolve`. Une offre `actif = non`
 *     (ou non liée) rend la carte non visible → elle est masquée (jamais de prix
 *     figé périmé, jamais de carte sans prix).
 *
 * Pilotage ACF (front-page) : apercu_tarifs_eyebrow, apercu_tarifs_title,
 * apercu_tarifs_lede, apercu_tarifs_items (repeater), apercu_tarifs_cta_label,
 * apercu_tarifs_cta_url.
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow  = get_field('apercu_tarifs_eyebrow');
$title    = get_field('apercu_tarifs_title');
$lede     = get_field('apercu_tarifs_lede');
$ctaLabel = (string) get_field('apercu_tarifs_cta_label') ?: __('Configurer mon devis', 'evolutionr');
$ctaUrl   = (string) get_field('apercu_tarifs_cta_url') ?: '/tarifs/';

// Cartes visibles uniquement. Prix + visibilité viennent du modèle central (offre
// liée) ; une offre inactive/absente masque la carte. `afficher` = curation accueil.
$items = get_field('apercu_tarifs_items');
$cards = [];

if (is_array($items)) {
    foreach ($items as $row) {
        if (empty($row['afficher'])) {
            continue; // retirée du sous-ensemble mis en avant sur l'accueil
        }

        $offer = evolutionr_offer_resolve((string) ($row['offre_ref'] ?? ''));
        if (!$offer['visible']) {
            continue; // offre `actif = non` ou non liée → carte masquée
        }

        $cards[] = [
            'label' => (string) ($row['label'] ?? ''),
            'price' => $offer['price_label'],
            'desc'  => (string) ($row['desc'] ?? ''),
        ];
    }
}

// Aucune carte visible → la section ne s'affiche pas.
if (empty($cards)) {
    return;
}
?>
<section class="section section-apercu-tarifs" id="apercu-tarifs" aria-labelledby="apercu-tarifs-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <?php if ($eyebrow): ?>
                    <div class="section-eyebrow-wrap">
                        <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($title): ?>
                    <h2 class="section-title" id="apercu-tarifs-title"><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
            </div>
            <?php if ($lede): ?>
                <p class="section-lede"><?php echo esc_html($lede); ?></p>
            <?php endif; ?>
        </header>

        <div class="apercu-tarifs-grid">
            <?php foreach ($cards as $card): ?>
                <article class="apercu-tarif-card">
                    <h3 class="apercu-tarif-label"><?php echo esc_html($card['label']); ?></h3>
                    <?php if ($card['price'] !== ''): ?>
                        <p class="apercu-tarif-price"><?php echo esc_html($card['price']); ?></p>
                    <?php endif; ?>
                    <?php if ($card['desc']): ?>
                        <p class="apercu-tarif-desc"><?php echo esc_html($card['desc']); ?></p>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>

        <div class="apercu-tarifs-cta-wrap">
            <a class="btn btn-primary" href="<?php echo esc_url($ctaUrl); ?>">
                <?php echo esc_html($ctaLabel); ?>
                <?php evolutionr_icon('arrow-right', 16); ?>
            </a>
        </div>
    </div>
</section>
