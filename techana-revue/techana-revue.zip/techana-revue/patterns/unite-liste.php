<?php
/**
 * Title: Unité article — liste
 * Slug: techana-revue/unite-liste
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Vignette 1:1, rubrique, titre, signature — le format le plus utilisé du thème.
 * Viewport Width: 640
 */
?>
<!-- wp:group {"className":"u-list k-auto"} -->
<div class="wp-block-group u-list k-auto"><!-- wp:post-featured-image {"sizeSlug":"techana-1-1","className":"ph-auto square"} /-->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:post-terms {"term":"category","className":"u-cat"} /-->

<!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:paragraph {"className":"meta","metadata":{"bindings":{"content":{"source":"techana/meta-carte"}}}} -->
<p class="meta"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
