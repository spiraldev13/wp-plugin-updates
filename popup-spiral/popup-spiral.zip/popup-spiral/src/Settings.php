<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Modèle des réglages d'un popup : une meta unique structurée par section,
 * avec valeurs par défaut et sanitation centralisées.
 */
final class Settings
{
    public const META_KEY = 'spiral_popup_settings';

    /** Plafond CNIL (~13 mois) pour la durée du cookie de fréquence. */
    public const MAX_FREQUENCY_DAYS = 395;

    public const POSITIONS = [
        'top-left', 'top-center', 'top-right',
        'center-left', 'center', 'center-right',
        'bottom-left', 'bottom-center', 'bottom-right',
        'bar-top', 'bar-bottom',
    ];

    public const FREQUENCY_MODES = ['always', 'session', 'forever', 'days'];

    public const CONTENT_SOURCES = ['editor', 'elementor_template'];

    /** Tailles intégrées ; les tailles réutilisables (clés `c-*`) s'y ajoutent. */
    public const SIZES = ['auto', 'small', 'medium', 'large', 'custom'];

    /** Option des tailles réutilisables gérées sur la page Réglages. */
    public const SIZE_PRESETS_OPTION = 'spiral_size_presets';

    public const IMAGE_LAYOUTS = ['none', 'banner', 'left', 'right', 'background'];

    /** Largeur de l'image en % de l'espace disponible. */
    public const IMAGE_WIDTHS = [25, 50, 75, 100];

    public const IMAGE_PADDINGS = ['none', 'small', 'medium', 'custom'];

    public const IMAGE_BORDERS = ['none', 'thin', 'thick', 'custom'];

    public const HEIGHTS = ['auto', 'custom'];

    public const CONTENT_VALIGNS = ['top', 'center', 'bottom'];

    public const BUTTON_TARGETS = ['page', 'url'];

    public const BUTTON_ALIGNS = ['left', 'center', 'right'];

    /**
     * Valeurs par défaut : un popup créé sans rien toucher est fonctionnel
     * (design Annonce, centre, délai 2 s, tous les 30 jours) — seule la
     * cible reste à cocher.
     */
    public static function defaults(): array
    {
        return [
            'targeting' => [
                'whole_site' => false,
                'front_page' => false,
                'pages' => [],
                'posts' => [],
                'categories' => [],
            ],
            'schedule' => [
                'start' => '',
                'end' => '',
            ],
            'triggers' => [
                'delay_enabled' => true,
                'delay' => 2,
                'click_enabled' => true,
                'click_selector' => '',
                'exit_intent' => false,
                'no_overlay_close' => false,
            ],
            'frequency' => [
                'mode' => 'days',
                'days' => 30,
            ],
            'display' => [
                'design' => 'annonce',
                'position' => 'center',
                'size' => self::defaultSize(),
                'custom_width' => 560,
                'height' => 'auto',
                'custom_height' => 400,
                'content_valign' => 'top',
                'text_size' => 16,
                'zindex' => 1999999999,
                'image' => [
                    'layout' => 'left',
                    'id' => 0,
                    'width' => self::defaultImageWidth(),
                    'padding' => 'small',
                    'custom_padding' => 16,
                    'border' => 'none',
                    'border_width' => 2,
                    'border_color' => '#e2e8f0',
                ],
            ],
            'button' => [
                'enabled' => false,
                'label' => '',
                'target' => 'page',
                'page' => 0,
                'url' => '',
                'new_tab' => false,
                'align' => 'center',
                'text_size' => 16,
            ],
            'content_source' => [
                'type' => 'editor',
                'elementor_template' => 0,
            ],
        ];
    }

    /**
     * Réglages complets d'un popup, fusionnés avec les valeurs par défaut.
     */
    public static function get(int $popupId): array
    {
        $saved = get_post_meta($popupId, self::META_KEY, true);

        if (!is_array($saved)) {
            $saved = [];
        }

        return self::mergeWithDefaults($saved, self::defaults());
    }

    /**
     * Nettoie puis enregistre les réglages d'un popup.
     */
    public static function save(int $popupId, array $raw): void
    {
        update_post_meta($popupId, self::META_KEY, self::sanitize($raw));
    }

    /**
     * Sanitation complète des réglages bruts (formulaire admin).
     */
    public static function sanitize(array $raw): array
    {
        $defaults = self::defaults();

        $targeting = isset($raw['targeting']) && is_array($raw['targeting']) ? $raw['targeting'] : [];
        $schedule = isset($raw['schedule']) && is_array($raw['schedule']) ? $raw['schedule'] : [];
        $triggers = isset($raw['triggers']) && is_array($raw['triggers']) ? $raw['triggers'] : [];
        $frequency = isset($raw['frequency']) && is_array($raw['frequency']) ? $raw['frequency'] : [];
        $display = isset($raw['display']) && is_array($raw['display']) ? $raw['display'] : [];
        $image = isset($display['image']) && is_array($display['image']) ? $display['image'] : [];
        $button = isset($raw['button']) && is_array($raw['button']) ? $raw['button'] : [];
        $source = isset($raw['content_source']) && is_array($raw['content_source']) ? $raw['content_source'] : [];

        return [
            'targeting' => [
                'whole_site' => !empty($targeting['whole_site']),
                'front_page' => !empty($targeting['front_page']),
                'pages' => self::sanitizeIdList($targeting['pages'] ?? []),
                'posts' => self::sanitizeIdList($targeting['posts'] ?? []),
                'categories' => self::sanitizeIdList($targeting['categories'] ?? []),
            ],
            'schedule' => [
                'start' => self::sanitizeDatetime($schedule['start'] ?? ''),
                'end' => self::sanitizeDatetime($schedule['end'] ?? ''),
            ],
            'triggers' => [
                'delay_enabled' => !empty($triggers['delay_enabled']),
                'delay' => max(0, min(600, (int) ($triggers['delay'] ?? $defaults['triggers']['delay']))),
                'click_enabled' => !empty($triggers['click_enabled']),
                'click_selector' => sanitize_text_field((string) ($triggers['click_selector'] ?? '')),
                'exit_intent' => !empty($triggers['exit_intent']),
                'no_overlay_close' => !empty($triggers['no_overlay_close']),
            ],
            'frequency' => [
                'mode' => self::whitelist((string) ($frequency['mode'] ?? ''), self::FREQUENCY_MODES, $defaults['frequency']['mode']),
                'days' => max(1, min(self::MAX_FREQUENCY_DAYS, (int) ($frequency['days'] ?? $defaults['frequency']['days']))),
            ],
            'display' => [
                'design' => sanitize_key((string) ($display['design'] ?? $defaults['display']['design'])),
                'position' => self::whitelist((string) ($display['position'] ?? ''), self::POSITIONS, $defaults['display']['position']),
                'size' => self::whitelist((string) ($display['size'] ?? ''), self::allowedSizes(), self::defaultSize()),
                'custom_width' => max(200, min(2000, (int) ($display['custom_width'] ?? $defaults['display']['custom_width']))),
                'height' => self::whitelist((string) ($display['height'] ?? ''), self::HEIGHTS, 'auto'),
                'custom_height' => max(100, min(2000, (int) ($display['custom_height'] ?? $defaults['display']['custom_height']))),
                'content_valign' => self::whitelist((string) ($display['content_valign'] ?? ''), self::CONTENT_VALIGNS, 'top'),
                'text_size' => max(10, min(40, (int) ($display['text_size'] ?? $defaults['display']['text_size']))),
                'zindex' => max(1, (int) ($display['zindex'] ?? $defaults['display']['zindex'])),
                'image' => [
                    'layout' => self::whitelist((string) ($image['layout'] ?? ''), self::IMAGE_LAYOUTS, 'none'),
                    'id' => max(0, (int) ($image['id'] ?? 0)),
                    'width' => in_array($imageWidth = (int) ($image['width'] ?? 100), self::allowedImageWidths(), true)
                        ? $imageWidth
                        : self::defaultImageWidth(),
                    'padding' => self::whitelist((string) ($image['padding'] ?? ''), self::IMAGE_PADDINGS, 'none'),
                    'custom_padding' => max(0, min(100, (int) ($image['custom_padding'] ?? 16))),
                    'border' => self::whitelist((string) ($image['border'] ?? ''), self::IMAGE_BORDERS, 'none'),
                    'border_width' => max(1, min(20, (int) ($image['border_width'] ?? 2))),
                    'border_color' => sanitize_hex_color((string) ($image['border_color'] ?? '')) ?: '#e2e8f0',
                ],
            ],
            'button' => [
                'enabled' => !empty($button['enabled']),
                'label' => sanitize_text_field((string) ($button['label'] ?? '')),
                'target' => self::whitelist((string) ($button['target'] ?? ''), self::BUTTON_TARGETS, 'page'),
                // -1 = page d'accueil du site.
                'page' => max(-1, (int) ($button['page'] ?? 0)),
                'url' => esc_url_raw((string) ($button['url'] ?? '')),
                'new_tab' => !empty($button['new_tab']),
                'align' => self::whitelist((string) ($button['align'] ?? ''), self::BUTTON_ALIGNS, $defaults['button']['align']),
                'text_size' => max(10, min(40, (int) ($button['text_size'] ?? $defaults['button']['text_size']))),
            ],
            'content_source' => [
                'type' => self::whitelist((string) ($source['type'] ?? ''), self::CONTENT_SOURCES, $defaults['content_source']['type']),
                'elementor_template' => max(0, (int) ($source['elementor_template'] ?? 0)),
            ],
        ];
    }

    /**
     * Fusion récursive qui garantit la présence de toutes les clés par défaut.
     */
    private static function mergeWithDefaults(array $saved, array $defaults): array
    {
        $merged = $defaults;

        foreach ($defaults as $key => $default) {
            if (!array_key_exists($key, $saved)) {
                continue;
            }

            if (is_array($default) && self::isAssoc($default)) {
                $merged[$key] = self::mergeWithDefaults(
                    is_array($saved[$key]) ? $saved[$key] : [],
                    $default
                );
            } else {
                $merged[$key] = $saved[$key];
            }
        }

        return $merged;
    }

    private static function isAssoc(array $array): bool
    {
        return $array !== [] && array_keys($array) !== range(0, count($array) - 1);
    }

    /**
     * @param mixed $value
     */
    private static function sanitizeIdList($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map('intval', $value), static function ($id) {
            return $id > 0;
        }));
    }

    /**
     * Valide un datetime-local (« 2026-07-03T18:30 ») ; vide sinon.
     * Certains navigateurs ajoutent les secondes — elles sont ignorées.
     */
    private static function sanitizeDatetime(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/', $value)) {
            return '';
        }

        return substr($value, 0, 16);
    }

    private static function whitelist(string $value, array $allowed, string $fallback): string
    {
        return in_array($value, $allowed, true) ? $value : $fallback;
    }

    /* ---------- Tailles réutilisables (option de la page Réglages) ---------- */

    /**
     * Structure complète et nettoyée de l'option des tailles réutilisables.
     *
     * @return array{sizes: array, default_size: string, image_widths: array, default_image_width: int}
     */
    public static function sizePresets(): array
    {
        $raw = get_option(self::SIZE_PRESETS_OPTION, []);

        return self::sanitizeSizePresets(is_array($raw) ? $raw : []);
    }

    /**
     * Sanitation de l'option des tailles réutilisables (register_setting).
     *
     * @param mixed $raw
     */
    public static function sanitizeSizePresets($raw): array
    {
        $raw = is_array($raw) ? $raw : [];
        $sizes = self::sanitizePresetSizes((array) ($raw['sizes'] ?? []));
        $imageWidths = self::sanitizePresetImageWidths((array) ($raw['image_widths'] ?? []));

        $keys = array_column($sizes, 'key');
        $defaultSize = (string) ($raw['default_size'] ?? 'auto');

        // « custom » est ponctuel par popup : pas un défaut global valable.
        if ($defaultSize === 'custom' || !in_array($defaultSize, array_merge(self::SIZES, $keys), true)) {
            $defaultSize = 'auto';
        }

        $defaultImageWidth = (int) ($raw['default_image_width'] ?? 100);

        if (!in_array($defaultImageWidth, array_merge(self::IMAGE_WIDTHS, $imageWidths), true)) {
            $defaultImageWidth = 100;
        }

        return [
            'sizes' => $sizes,
            'default_size' => $defaultSize,
            'image_widths' => $imageWidths,
            'default_image_width' => $defaultImageWidth,
        ];
    }

    public static function allowedSizes(): array
    {
        return array_merge(self::SIZES, array_column(self::sizePresets()['sizes'], 'key'));
    }

    public static function allowedImageWidths(): array
    {
        return array_merge(self::IMAGE_WIDTHS, self::sizePresets()['image_widths']);
    }

    public static function defaultSize(): string
    {
        return self::sizePresets()['default_size'];
    }

    public static function defaultImageWidth(): int
    {
        return self::sizePresets()['default_image_width'];
    }

    /**
     * Choix de taille pour la metabox : intégrées + réutilisables, clé => libellé.
     */
    public static function sizeChoices(): array
    {
        $choices = [
            'auto' => __('Automatique (selon le contenu)', 'popup-spiral'),
            'small' => __('Petit (360px)', 'popup-spiral'),
            'medium' => __('Moyen (560px)', 'popup-spiral'),
            'large' => __('Grand (820px)', 'popup-spiral'),
        ];

        foreach (self::sizePresets()['sizes'] as $size) {
            $choices[$size['key']] = sprintf('%s (%dpx)', $size['label'], $size['width']);
        }

        $choices['custom'] = __('Personnalisée (ponctuelle)', 'popup-spiral');

        return $choices;
    }

    /**
     * Largeur CSS effective d'un popup ; chaîne vide = taille automatique
     * (le template pose alors la classe spiral-size-auto).
     */
    public static function widthCssFor(array $display): string
    {
        $size = (string) $display['size'];

        if ($size === 'custom') {
            return 'min(' . (int) $display['custom_width'] . 'px, 94vw)';
        }

        $css = self::sizeWidthCss($size);

        if ($css !== null) {
            return $css;
        }

        // Taille réutilisable supprimée : repli sur la taille par défaut.
        return self::sizeWidthCss(self::defaultSize()) ?? 'min(560px, 92vw)';
    }

    /**
     * @return array<int, array{key: string, label: string, width: int}>
     */
    private static function sanitizePresetSizes(array $raw): array
    {
        $sizes = [];
        $keys = [];

        foreach ($raw as $size) {
            if (!is_array($size)) {
                continue;
            }

            $label = sanitize_text_field((string) ($size['label'] ?? ''));

            if ($label === '') {
                continue;
            }

            $key = sanitize_key((string) ($size['key'] ?? ''));

            // Préfixe c- : jamais de collision avec les tailles intégrées.
            if ($key === '' || strpos($key, 'c-') !== 0) {
                $key = self::uniquePresetKey($label, $keys);
            }

            if (in_array($key, $keys, true)) {
                continue;
            }

            $keys[] = $key;
            $sizes[] = [
                'key' => $key,
                'label' => $label,
                'width' => max(200, min(2000, (int) ($size['width'] ?? 560))),
            ];
        }

        return $sizes;
    }

    private static function sanitizePresetImageWidths(array $raw): array
    {
        $widths = [];

        foreach ($raw as $width) {
            $width = (int) $width;

            if ($width >= 5 && $width <= 100
                && !in_array($width, self::IMAGE_WIDTHS, true)
                && !in_array($width, $widths, true)
            ) {
                $widths[] = $width;
            }
        }

        rsort($widths);

        return $widths;
    }

    private static function uniquePresetKey(string $label, array $taken): string
    {
        $base = 'c-' . sanitize_key(sanitize_title($label));

        if ($base === 'c-') {
            $base = 'c-taille';
        }

        $key = $base;
        $i = 2;

        while (in_array($key, $taken, true)) {
            $key = $base . '-' . $i;
            $i++;
        }

        return $key;
    }

    /**
     * @return string|null Null si la taille est inconnue (supprimée).
     */
    private static function sizeWidthCss(string $size): ?string
    {
        $builtin = [
            'auto' => '',
            'small' => 'min(360px, 92vw)',
            'medium' => 'min(560px, 92vw)',
            'large' => 'min(820px, 94vw)',
        ];

        if (isset($builtin[$size])) {
            return $builtin[$size];
        }

        foreach (self::sizePresets()['sizes'] as $preset) {
            if ($preset['key'] === $size) {
                return 'min(' . (int) $preset['width'] . 'px, 94vw)';
            }
        }

        return null;
    }
}
