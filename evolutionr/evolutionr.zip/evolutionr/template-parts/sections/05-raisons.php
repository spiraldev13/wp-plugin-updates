<?php
/**
 * 04 — Quatre raisons « Pourquoi Evolution'R ».
 *
 * Visuel : grille 4 colonnes (1 col mobile / 2 col tablette / 4 col desktop)
 * de pavés contigus séparés par des hairlines. Chaque pavé : icône cyan +
 * titre court + description.
 *
 * Pilotage ACF (front-page) :
 *   - pillars_eyebrow, pillars_title.
 *   - pillars (repeater de { icon (select), title, desc }).
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow = get_field('pillars_eyebrow') ?: __('Pourquoi Evolution\'R', 'evolutionr');
$title   = get_field('pillars_title') ?: __('Quatre raisons de nous confier votre projet.', 'evolutionr');

if (!have_rows('pillars')) {
    return;
}
?>
<section class="section" aria-labelledby="pillars-title">
    <div class="container">
        <header class="section-head">
            <div class="section-head-left">
                <div class="section-eyebrow-wrap">
                    <span class="eyebrow"><?php echo esc_html($eyebrow); ?></span>
                </div>
                <h2 class="section-title" id="pillars-title"><?php echo esc_html($title); ?></h2>
            </div>
        </header>

        <div class="pillars-grid">
            <?php while (have_rows('pillars')): the_row();
                $icon  = get_sub_field('icon') ?: 'shield';
                $name  = get_sub_field('title');
                $desc  = get_sub_field('desc');
                ?>
                <div class="pillar">
                    <div class="pillar-icon" aria-hidden="true">
                        <?php evolutionr_icon((string) $icon, 26); ?>
                    </div>
                    <div class="pillar-title"><?php echo esc_html($name); ?></div>
                    <?php if ($desc): ?>
                        <p class="pillar-desc"><?php echo esc_html($desc); ?></p>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
