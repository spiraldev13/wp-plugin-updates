<?php

declare(strict_types=1);

namespace SpiralBase\Modules\FormulaireContact;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;
use SpiralBase\Core\SondeCession;

/**
 * Formulaire de contact natif (CAP-12, story 3.8).
 *
 * OFF par défaut (AD-6). CÈDE devant Contact Form 7 — le seul module de bloc
 * de cet epic à porter une sonde, parce qu'un formulaire est une
 * fonctionnalité de SITE : quand un vrai plugin de formulaires est en place,
 * l'opérateur y crée ses formulaires et deux systèmes concurrents ne feraient
 * que semer la confusion.
 *
 * Le bloc n'entre dans aucune liste d'extrait : un formulaire ne décrit pas
 * une page (même raisonnement qu'en 3.6 et 3.7).
 */
final class FormulaireContactModule implements Module
{
    public const HANDLE_STYLE = 'spiralbase-formulaire-contact';

    public const NOM = 'spiralbase/formulaire-contact';

    public const ACTION = 'spiralbase_formulaire_contact';

    public const OPTION = 'spiralbase_formulaire';

    private const REPERTOIRE = 'formulaire-contact';

    private Messages $messages;

    /** @var \Closure(): array<string, bool> faits injectables — jamais devinés */
    private \Closure $faits;

    public function __construct(
        private readonly Options $options,
        ?Messages $messages = null,
        ?\Closure $faits = null,
    ) {
        $this->messages = $messages ?? new Messages();
        $this->faits    = $faits ?? static fn (): array => [
            'charge' => defined('WPCF7_VERSION'),
            'classe' => class_exists('WPCF7_ContactForm'),
        ];
    }

    public function slug(): string
    {
        return 'formulaire_contact';
    }

    public function boot(): void
    {
        add_action('init', function (): void {
            /* Le type `spiralbase_message` est déclaré par le noyau, hors du
               cycle de vie de ce module : les archives ne doivent pas
               disparaître le jour où il cède. */
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => function (array $attributs, string $contenu = '', mixed $bloc = null): string {
                    return (new RenduFormulaire(new AntiSpam(), $this->turnstile()))
                        ->rendre($attributs, $contenu, $bloc);
                }]
            );

            if ($type === false) {
                $doublon = class_exists('WP_Block_Type_Registry')
                    && \WP_Block_Type_Registry::get_instance()->is_registered(self::NOM);

                Signal::emettre(
                    'spiralbase_formulaire_enregistrement_echoue',
                    $doublon
                        ? 'bloc « formulaire-contact » non enregistré : le nom ' . self::NOM . ' est déjà enregistré par une extension ou un thème enfant'
                        : 'bloc « formulaire-contact » non enregistré : répertoire ou block.json illisible',
                    'formulaire'
                );
            }
        });

        /* Chemin natif de WordPress pour un POST hors REST : pas d'AJAX
           maison, pas d'endpoint à sécuriser en plus. Les deux hooks sont
           nécessaires — un visiteur non connecté passe par `nopriv`. */
        $recevoir = function (): void {
            $this->recevoir(new AntiSpam(), $this->adresseVisiteur());
            $this->repartir();
        };

        add_action('admin_post_nopriv_' . self::ACTION, $recevoir);
        add_action('admin_post_' . self::ACTION, $recevoir);
    }

    /**
     * Traite une soumission — rend `'ok'` ou `'rejete'`.
     *
     * Le verdict ne sort JAMAIS vers le visiteur : quel que soit le résultat,
     * il voit le même message. Un robot qui distingue « rejeté » d'« accepté »
     * apprend à contourner ; et un visiteur légitime écarté à tort par une
     * couche ne gagnerait rien à l'apprendre. C'est pourquoi chaque rejet est
     * SIGNALÉ côté serveur : c'est la seule trace dont dispose l'opérateur
     * d'un formulaire qui refuserait tout.
     */
    public function recevoir(AntiSpam $antiSpam, string $ip): string
    {
        /*
         * Le SEUL chemin public non authentifié du thème était le seul sans
         * filet, alors que le rendu — bien moins exposé — en avait un. Toute
         * exception ici donnerait une page blanche à un visiteur anonyme, et
         * le message serait perdu APRÈS avoir été accepté.
         */
        try {
            return $this->traiter($antiSpam, $ip);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_formulaire_echec', 'réception interrompue : ' . $e->getMessage(), 'formulaire');

            return 'rejete';
        }
    }

    private function traiter(AntiSpam $antiSpam, string $ip): string
    {
        /* TOUTE tentative compte, réussie ou non : un robot qui échoue en
           boucle ne consommait aucun quota et pouvait donc essayer sans fin. */
        $antiSpam->compter($ip);

        $donnees = array_map(
            static fn (mixed $v): mixed => is_string($v) ? wp_unslash($v) : $v,
            $_POST
        );

        /* `is_string` avant le cast : `_wpnonce[]=x` faisait émettre un
           « Array to string conversion » AVANT la redirection — journal
           rempli à la demande d'un anonyme, et en-têtes perdus sous
           WP_DEBUG_DISPLAY. */
        $nonce = $donnees['_wpnonce'] ?? null;

        if (!is_string($nonce) || !wp_verify_nonce($nonce, self::ACTION)) {
            return $this->rejeter('nonce');
        }

        $raison = $antiSpam->verifier($donnees, $ip);

        if ($raison !== null) {
            return $this->rejeter($raison);
        }

        /* Turnstile APRÈS les couches natives, jamais à leur place : une
           soumission qui a déjà échoué au leurre ou au délai n'a aucune raison
           de coûter un appel réseau. */
        if (!$this->turnstile()->verifier($donnees, $ip)) {
            return $this->rejeter('turnstile');
        }

        $copie = [
            'nom'     => (string) ($donnees['spiralbase_nom'] ?? ''),
            'email'   => (string) ($donnees['spiralbase_email'] ?? ''),
            'message' => (string) ($donnees['spiralbase_message'] ?? ''),
        ];

        /* EN BASE D'ABORD. Un SMTP en panne est la défaillance la plus banale
           d'un site vitrine : si l'email partait en premier, le message serait
           perdu sans laisser de trace. */
        $id = $this->messages->enregistrer($copie);

        if ($id === 0) {
            Signal::emettre('spiralbase_formulaire_copie_echouee', 'message non enregistré en base', 'formulaire');
        }

        $this->envoyer($copie, $id);

        return 'ok';
    }

    /** @param array{nom: string, email: string, message: string} $copie */
    private function envoyer(array $copie, int $id): void
    {
        $destinataire = sanitize_email((string) ($this->reglages()['destinataire'] ?? ''));

        if ($destinataire === '') {
            $destinataire = (string) get_option('admin_email', '');
        }

        if (sanitize_email($destinataire) === '') {
            Signal::emettre('spiralbase_formulaire_envoi_echoue', 'aucun destinataire configuré', 'formulaire');

            return;
        }

        $envoye = wp_mail(
            $destinataire,
            sprintf(
                /* translators: %s : nom de l'expéditeur */
                __('Message depuis le site : %s', 'spiralbase'),
                sanitize_text_field($copie['nom'])
            ),
            $this->messages->rendreExtrait($copie),
            [
                'Content-Type: text/html; charset=UTF-8',
                /* `Reply-To` et JAMAIS `From` : usurper l'adresse du visiteur
                   ferait échouer SPF et DMARC, et le message finirait en
                   indésirable — l'inverse du but. */
                'Reply-To: ' . sanitize_email($copie['email']),
            ]
        );

        if ($envoye === false) {
            $this->messages->marquerEchecEnvoi($id, 'wp_mail a rendu false');
            Signal::emettre(
                'spiralbase_formulaire_envoi_echoue',
                'courriel non parti — la copie du message reste en base',
                'formulaire'
            );
        }
    }

    public function turnstile(): Turnstile
    {
        $reglages = $this->reglages();

        return new Turnstile(
            (string) ($reglages['turnstile_site'] ?? ''),
            (string) ($reglages['turnstile_secret'] ?? '')
        );
    }

    private function rejeter(string $raison): string
    {
        Signal::emettre('spiralbase_formulaire_rejet', 'soumission rejetée : ' . $raison, 'formulaire');

        return 'rejete';
    }

    /**
     * Adresse du visiteur — jamais un en-tête de proxy.
     *
     * `X-Forwarded-For` est réécrit par le client : s'y fier laisserait
     * n'importe qui contourner le plafond en changeant d'en-tête à chaque
     * requête. `REMOTE_ADDR` est le seul champ que le serveur constate.
     */
    private function adresseVisiteur(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        return is_string($ip) && filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '0.0.0.0';
    }

    /** Retour à la page d'origine, avec un accusé identique dans tous les cas. */
    private function repartir(): void
    {
        $referent = wp_get_referer();
        $retour   = is_string($referent) && $referent !== '' ? $referent : home_url('/');

        wp_safe_redirect(add_query_arg(['spiralbase_message' => 'envoye'], $retour));
        exit;
    }

    /** @return array<string, mixed> */
    private function reglages(): array
    {
        $valeurs = $this->options->get(self::OPTION, $this->defaultSettings());

        return is_array($valeurs) ? $valeurs + $this->defaultSettings() : $this->defaultSettings();
    }

    public function defaultSettings(): array
    {
        return [
            'destinataire'      => '',
            'turnstile_site'    => '',
            'turnstile_secret'  => '',
        ];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    /**
     * Cède devant un Contact Form 7 EFFECTIF.
     *
     * Faits LUS dans le plugin réel (v6.1.6, installé dans le dev) :
     *  - `WPCF7_VERSION` est défini dès le chargement du fichier principal
     *    (`wp-contact-form-7.php:15`) ;
     *  - la classe `WPCF7_ContactForm` (`includes/contact-form.php:8`) vient de
     *    `load.php`, inclus par ce même fichier (`:72`).
     *
     * Les DEUX sont exigés — pattern du fait composé (2.5, 3.4) : la constante
     * seule pourrait être posée par un extrait de code ou une copie du plugin
     * laissée sur le disque, la classe seule par un chargeur qui n'a pas
     * exécuté le fichier principal.
     *
     * LIMITE ASSUMÉE, mesurée sur le WP réel : le fait le plus probant serait
     * l'enregistrement du type `wpcf7_contact_form`, mais il n'a lieu que sur
     * `init` (`includes/functions.php:283-285`) — soit APRÈS `bootActive()`,
     * qui tourne sur `after_setup_theme`. L'exiger rendait la sonde toujours
     * fausse au front et vraie en WP-CLI : deux verdicts opposés pour un même
     * site, exactement ce que la règle du projet interdit. Les deux faits
     * retenus sont disponibles au moment où le registre décide.
     */
    public function cessionProbe(): ?callable
    {
        return SondeCession::surFait(
            $this->slug(),
            function (): bool {
                $faits = ($this->faits)();

                /* Fait COMPOSÉ (pattern 2.5, confirmé en 3.4) : les deux
                   ensemble ne mentent pas, et valent la même chose au front,
                   en administration, en REST et en cron. */
                return ($faits['charge'] ?? false) && ($faits['classe'] ?? false);
            },
            /* Le produit est NOMMÉ : la sonde ne reconnaît que Contact Form 7,
               seul plugin de formulaire lu. Annoncer « un plugin de
               formulaire » ferait croire à une couverture que le code n'a
               pas — Gravity Forms, WPForms ou Forminator ne déclenchent rien. */
            static fn (): string => __('Contact Form 7 est actif — le formulaire du thème s\'efface devant lui.', 'spiralbase')
        );
    }
}
