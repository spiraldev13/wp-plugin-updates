<?php

declare(strict_types=1);

namespace SpiralBase\Core\Cli;

use SpiralBase\Modules\RgpdPagesLegales\RgpdPagesLegalesModule;

/**
 * `wp spiralbase rgpd` — coquille CLI : délègue TOUT au module (pattern
 * RecipeCommand). Messages CLI non traduits (convention WP-CLI).
 */
final class RgpdCommand
{
    public function __construct(private readonly RgpdPagesLegalesModule $module)
    {
    }

    /**
     * Génère les pages légales (brouillons pré-remplis, à compléter).
     *
     * ## EXAMPLES
     *
     *     wp spiralbase rgpd generer-pages
     *
     * @param array<int, string> $args
     * @param array<string, string> $assocArgs
     *
     * @subcommand generer-pages
     */
    public function genererPages(array $args, array $assocArgs): void
    {
        $resultat = $this->module->genererPages();

        if ($resultat instanceof \WP_Error) {
            /* État partiel AVANT l'erreur : l'opérateur sait ce qui existe. */
            $donnees = is_array($resultat->get_error_data()) ? $resultat->get_error_data() : [];

            foreach ((array) ($donnees['creees'] ?? []) as $slug) {
                \WP_CLI::success(sprintf('Page « %s » créée en brouillon AVANT l\'échec.', $slug));
            }

            \WP_CLI::error($resultat->get_error_message());

            return;
        }

        foreach ($resultat['creees'] as $slug) {
            \WP_CLI::success(sprintf('Page « %s » créée en brouillon — à compléter puis publier.', $slug));
        }

        foreach ($resultat['sautees'] as $slug) {
            \WP_CLI::log(sprintf('Page « %s » déjà existante : non touchée.', $slug));
        }

        if ($resultat['creees'] === [] && $resultat['sautees'] === []) {
            \WP_CLI::log('Rien à faire.');
        }
    }
}
