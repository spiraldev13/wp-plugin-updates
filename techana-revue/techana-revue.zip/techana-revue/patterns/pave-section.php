<?php
/**
 * Title: Pavé de section
 * Slug: techana-revue/pave-section
 * Categories: techana, text
 * Description: L'élément signature du design — rectangle accent, capitales, filet jusqu'au bord, compteur et lien.
 * Viewport Width: 800
 */
?>
<!-- wp:group {"className":"sec-head k-auto"} -->
<div class="wp-block-group sec-head k-auto"><!-- wp:paragraph {"className":"sec-tag"} -->
<p class="sec-tag">Rubrique</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<span class="line"></span>
<!-- /wp:html -->

<!-- wp:paragraph {"className":"sec-count","metadata":{"bindings":{"content":{"source":"techana/compteur-rubrique"}}}} -->
<p class="sec-count"></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"sec-more"} -->
<p class="sec-more"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Voir la rubrique →</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
