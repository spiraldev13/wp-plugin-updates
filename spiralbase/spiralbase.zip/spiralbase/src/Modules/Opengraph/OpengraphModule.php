<?php

declare(strict_types=1);

namespace SpiralBase\Modules\Opengraph;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;
use SpiralBase\Core\SondeCession;

/**
 * Balises de partage OpenGraph + Twitter Card, générées automatiquement
 * dans le head (CAP-15, story 2.1) — première unité de cession SEO fine
 * (AD-2) : ce module cède face à Rank Math, et lui seul.
 *
 * Sonde d'effectivité (AD-3), faits vérifiés sur le plugin réel : Rank
 * Math n'émet de l'OpenGraph que si (1) le plugin est actif, (2) son
 * enregistrement est valide — sinon `init_frontend()` s'interrompt et
 * AUCUNE balise ne sort (vérifié sur requête réelle : RM fraîchement
 * activé n'émet rien), (3) il ne se neutralise pas lui-même (aperçu du
 * Customizer, filtre public `rank_math/frontend/disable_integration`).
 * Le point (2) réutilise le prédicat de RM (`is_invalid_registration()`,
 * lecture d'options uniquement) — un renvoi plutôt qu'une copie.
 *
 * Contrainte de timing assumée (règle d'or 1.3) : la sonde court à
 * `after_setup_theme` — une neutralisation du filtre RM doit donc être
 * enregistrée AVANT ce hook (mu-plugin ou chargement de plugin, le cas
 * d'usage réel) ; un `add_filter` posé à `init` est invisible pour la
 * requête courante.
 */
final class OpengraphModule implements Module
{
    public const OPTION = 'spiralbase_opengraph';

    /** Contenus déjà rendus dans cette requête, par post — voir `contenuPublie()`. */
    private array $contenusRendus = [];

    /** Garde de réentrance du rendu de blocs — voir `contenuPublie()`. */
    private bool $rendEnCours = false;

    /**
     * @param \Closure():bool|null $faitOgRankMath fait injectable pour les
     *                                             tests ; null = faits réels
     */
    public function __construct(
        private readonly Options $options,
        private readonly ?\Closure $faitOgRankMath = null,
    ) {
    }

    public function slug(): string
    {
        return 'opengraph';
    }

    public function boot(): void
    {
        /* Tôt dans le head (priorité 5) : les aspirateurs de métadonnées
           lisent rarement au-delà des premiers Ko. */
        add_action('wp_head', [$this, 'emettreBalises'], 5);
    }

    public function defaultSettings(): array
    {
        return ['image_secours' => ''];
    }

    public function options(): array
    {
        return [self::OPTION];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        /* Wrapper commun du noyau (fait illisible = main gardée + signal) :
           un renvoi plutôt qu'une copie — mutualisé en 2.2. */
        return SondeCession::surFait(
            $this->slug(),
            $this->faitOgRankMath ?? \Closure::fromCallable([self::class, 'rankMathEmetLOpengraph']),
            static fn (): string => __('OpenGraph réellement émis par Rank Math.', 'spiralbase')
        );
    }

    /**
     * Le fait « Rank Math émettra de l'OpenGraph sur cette requête » —
     * chaque condition reflète le code réel de RM (class-frontend.php :
     * `integrations()` gardée par le filtre, `init_frontend()` gardé par
     * l'enregistrement).
     */
    private static function rankMathEmetLOpengraph(): bool
    {
        if (!class_exists('RankMath', false) || !class_exists('\\RankMath\\Helper')) {
            return false;
        }

        if (\RankMath\Helper::is_invalid_registration()) {
            return false;
        }

        /* RM se neutralise lui-même dans l'aperçu du Customizer. */
        if (is_customize_preview()) {
            return false;
        }

        /* Truthiness, comme RM (`if ($this->do_filter(...))`) — jamais de
           comparaison stricte qu'un callback à `1` ou `'yes'` déjouerait. */
        return !apply_filters('rank_math/frontend/disable_integration', false);
    }

    public function emettreBalises(): void
    {
        try {
            $balises = $this->balises();
        } catch (\Throwable $e) {
            /* Des métadonnées ne fatalisent JAMAIS la page (précédent
               Walker : aucun chemin fatal dans le rendu). */
            error_log('[spiralbase] opengraph : émission abandonnée — ' . $e->getMessage());

            return;
        }

        foreach ($balises as $cle => $contenu) {
            /* Échappement UNE fois, au point de sortie (précédent 1.7). */
            printf(
                '<meta %s="%s" content="%s">' . "\n",
                str_starts_with($cle, 'twitter:') ? 'name' : 'property',
                esc_attr($cle),
                esc_attr($contenu)
            );
        }
    }

    /**
     * Balises à émettre — aucune valeur vide : une balise sans contenu (ou
     * au contenu invalide) est pire qu'une balise absente.
     *
     * Public pour l'émission et les tests UNIQUEMENT — pas un service :
     * aucun autre module ne doit le consommer (AD-4).
     *
     * @return array<string, string>
     */
    public function balises(): array
    {
        $post  = is_singular() ? get_queried_object() : null;
        $post  = is_object($post) ? $post : null;
        /* Contenu verrouillé : ne rien divulguer (ni extrait ni image à la
           une) — les balises retombent sur les valeurs génériques du site. */
        $prive = $post !== null && post_password_required($post);

        $titre       = trim(wp_get_document_title());
        $description = $this->description($prive ? null : $post);
        $image       = $this->image($prive ? null : $post);

        $balises = [
            'og:locale'           => get_locale(),
            'og:type'             => $post !== null && !is_front_page() ? 'article' : 'website',
            'og:title'            => $titre,
            'og:description'      => $description,
            'og:image'            => $image,
            'og:url'              => $this->url($post),
            'og:site_name'        => get_bloginfo('name'),
            'twitter:card'        => $image !== '' ? 'summary_large_image' : 'summary',
            'twitter:title'       => $titre,
            'twitter:description' => $description,
            'twitter:image'       => $image,
        ];

        return array_filter($balises, static fn (string $contenu): bool => trim($contenu) !== '');
    }

    private function description(?object $post): string
    {
        $texte = '';

        if ($post !== null) {
            /* Champs BRUTS uniquement : get_the_excerpt() rejouerait toute
               la chaîne the_content dans le head, hors boucle — coût réel
               et fatals tiers possibles. */
            $texte = trim((string) ($post->post_excerpt ?? ''));

            if ($texte === '') {
                $contenu = wp_strip_all_tags(strip_shortcodes($this->contenuPublie($post)));
                $texte   = wp_trim_words($contenu, 25);
            }
        }

        if (trim($texte) === '') {
            /* Le slogan du site décrit mieux la page qu'un vide. */
            $texte = get_bloginfo('description');
        }

        return trim(wp_strip_all_tags($texte));
    }

    /**
     * Contenu d'où tirer une description — ce qui est PUBLIÉ, pas ce qui est
     * stocké.
     *
     * Le contenu brut ignore les blocs dynamiques : ce que leur rendu masque
     * réapparaissait ici. Prouvé en 3.6 — un encart d'événement périmé
     * disparaissait bien du corps de la page, mais l'`og:description` le
     * publiait encore : la carte de partage annonçait « Soirée de Noël 2019 »
     * sur un site de 2026.
     *
     * `excerpt_remove_blocks()` est le chemin du cœur pour ça : il appelle
     * `render_block()` sur les blocs autorisés (`blocks.php:2259`), donc les
     * masquages sont respectés, SANS rejouer la chaîne `the_content` — la
     * réserve posée en revue 2.1 visait `get_the_excerpt()`, qui l'applique
     * (`formatting.php:3983`) ; elle ne vaut pas ici.
     *
     * Un rendu VIDE est une information, pas une panne : il signifie que rien
     * de ce contenu n'est publiable. Retomber sur le contenu brut dans ce cas
     * — ce que faisait le premier jet — annulait exactement le masquage qu'on
     * venait d'obtenir : sur une page dont l'encart périmé était le seul bloc,
     * la carte de partage réannonçait « Soirée de Noël 2019 » (prouvé en revue
     * 3.6). On laisse donc le vide remonter, et l'appelant retombe sur le
     * slogan du site.
     *
     * Fail-safe : le rendu d'un bloc traverse du code tiers. Une défaillance
     * fait retomber sur le contenu brut — une description imparfaite vaut
     * mieux qu'un `wp_head` interrompu. C'est le SEUL cas de repli.
     */
    private function contenuPublie(object $post): string
    {
        $brut = (string) ($post->post_content ?? '');

        if ($brut === '' || !has_blocks($brut)) {
            return $brut;
        }

        /*
         * Garde de réentrance. Le cœur avertit qu'un bloc dynamique inscrit
         * dans `excerpt_allowed_blocks` ne doit pas produire d'extrait à son
         * tour, « sous peine de boucle infinie » (`blocks.php:2226-2231`), et
         * ce chemin ouvre une seconde porte vers ce mécanisme — dans
         * `wp_head`, sur chaque page. Elle ne prétend PAS casser une boucle
         * interne au cœur (`wp_trim_excerpt` ↔ `excerpt_remove_blocks`, qui
         * ne repasse pas ici) : elle empêche seulement qu'un bloc rendu
         * depuis le head ne relance cette même méthode. Un dépassement de
         * pile n'est pas un `Throwable` — aucun filet ne le rattraperait.
         */
        if ($this->rendEnCours) {
            return $brut;
        }

        /* Mémoïsation par requête : `balises()` est appelable plusieurs fois,
           et le rendu des blocs est la partie coûteuse. L'état vit sur
           l'instance — le module en a une seule par requête — plutôt qu'en
           statique, qui survivrait d'une requête à l'autre en CLI. */
        $cle = (string) ($post->ID ?? '') . ':' . md5($brut);

        if (isset($this->contenusRendus[$cle])) {
            return $this->contenusRendus[$cle];
        }

        $this->rendEnCours = true;

        try {
            $rendu = excerpt_remove_blocks($brut);
        } catch (\Throwable $e) {
            Signal::emettre(
                'spiralbase_opengraph_description_degradee',
                'rendu des blocs indisponible, description tirée du contenu brut : ' . $e->getMessage(),
                'opengraph'
            );

            $rendu = $brut;
        } finally {
            $this->rendEnCours = false;
        }

        return $this->contenusRendus[$cle] = $rendu;
    }

    private function image(?object $post): string
    {
        if ($post !== null && has_post_thumbnail($post)) {
            $url = get_the_post_thumbnail_url($post, 'full');

            if (is_string($url) && trim($url) !== '') {
                return trim($url);
            }
        }

        return $this->imageSecours();
    }

    private function imageSecours(): string
    {
        $reglages = $this->options->get(self::OPTION, []);
        $reglages = is_array($reglages) ? $reglages : [];
        $url      = $reglages['image_secours'] ?? '';
        $url      = is_string($url) ? trim($url) : '';

        if ($url === '') {
            return '';
        }

        /* La spec OpenGraph exige une URL absolue : une valeur invalide
           serait ignorée en silence par les scrapers — aucune balise, et
           un signal pour l'opérateur. */
        if (!preg_match('#^https?://#i', $url)) {
            error_log(sprintf('[spiralbase] opengraph : image_secours ignorée (URL absolue http(s) attendue) : « %s »', $url));

            return '';
        }

        return $url;
    }

    /**
     * URL canonique du partage : permalien en singulier, accueil sur la
     * page d'accueil — ailleurs (archives, recherche, 404), AUCUNE og:url
     * plutôt qu'une URL mensongère qui canoniserait la page vers la home.
     */
    private function url(?object $post): string
    {
        if ($post !== null) {
            $permalien = get_permalink($post);

            return is_string($permalien) ? trim($permalien) : '';
        }

        return is_front_page() ? home_url('/') : '';
    }
}
