<?php
/**
 * Carte « formule / pack » d'une page prestation (SEO, Identité, Maintenance).
 *
 * Rend UNE carte depuis la ligne de repeater COURANTE (`packs` ou
 * `hosting_offers`) — à appeler dans une boucle `while (have_rows(...)): the_row()`.
 * Le prix provient de l'offre résolue passée en argument
 * (`evolutionr_offer_resolve`). La visibilité et le compteur de position restent
 * gérés par la page appelante. La page Création garde son propre rendu (double
 * prix unique/abonnement), hors de ce partial.
 *
 * @param array $args {
 *     @type array  $offer       Offre résolue (clé `price_label`).
 *     @type int    $index       Position 0-based de la carte visible (numéro de repli).
 *     @type string $cta_default Libellé CTA par défaut si le sous-champ `cta_label` est vide.
 * }
 */

if (!defined('ABSPATH')) {
    exit;
}

$offer      = isset($args['offer']) && is_array($args['offer']) ? $args['offer'] : [];
$index      = isset($args['index']) ? (int) $args['index'] : 0;
$ctaDefault = isset($args['cta_default']) ? (string) $args['cta_default'] : __('Demander un devis', 'evolutionr');

$pNum         = (string) get_sub_field('num');
$pLabel       = (string) get_sub_field('label');
$pPrice       = (string) ($offer['price_label'] ?? '');
$pDesc        = (string) get_sub_field('desc');
$pFeatured    = (bool) get_sub_field('featured');
$pFeaturedLbl = (string) get_sub_field('featured_label') ?: __('Le plus choisi', 'evolutionr');
$pCtaLbl      = (string) get_sub_field('cta_label') ?: $ctaDefault;
$pCtaUrl      = (string) get_sub_field('cta_url') ?: '/contact/';
$displayNum   = $pNum ?: sprintf('%02d', $index + 1);
?>
<div class="formule-card-wrap<?php echo $pFeatured ? ' featured' : ''; ?>">
    <?php if ($pFeatured): ?>
        <div class="formule-badge"><?php echo esc_html($pFeaturedLbl); ?></div>
    <?php endif; ?>
    <article class="formule-card<?php echo $pFeatured ? ' featured' : ''; ?>">
    <?php if ($displayNum): ?><div class="formule-num">— <?php echo esc_html($displayNum); ?></div><?php endif; ?>
    <?php if ($pLabel): ?><h3 class="formule-name"><?php echo esc_html($pLabel); ?></h3><?php endif; ?>
    <div class="formule-price">
        <span class="amount"><?php echo esc_html($pPrice); ?></span>
    </div>
    <?php if ($pDesc): ?><p class="formule-desc"><?php echo esc_html($pDesc); ?></p><?php endif; ?>
    <?php if (have_rows('included')): ?>
        <ul class="formule-features">
            <?php while (have_rows('included')): the_row();
                $iText = (string) get_sub_field('text');
                if (!$iText) continue;
                ?>
                <li>
                    <?php evolutionr_icon('check', 14); ?>
                    <span><?php echo esc_html($iText); ?></span>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php endif; ?>
    <?php if ($pCtaLbl): ?>
        <a class="formule-cta" href="<?php echo esc_url($pCtaUrl); ?>">
            <span class="btn-inner">
                <?php echo esc_html($pCtaLbl); ?>
                <?php evolutionr_icon('arrow-right', 14); ?>
            </span>
        </a>
    <?php endif; ?>
    </article>
</div>
