/**
 * Glisser-déposer des réalisations dans la liste d'admin.
 *
 * Rend les lignes du tableau (#the-list) triables verticalement et persiste le
 * nouvel ordre (menu_order) via AJAX. Données injectées par wp_localize_script :
 * window.EvorRealOrder = { ajaxUrl, nonce }.
 */
(function ($) {
    'use strict';

    $(function () {
        var $list = $('#the-list');
        if (!$list.length || typeof window.EvorRealOrder === 'undefined') {
            return;
        }

        $list.sortable({
            items: '> tr',
            axis: 'y',
            cursor: 'move',
            opacity: 0.7,
            // Fige la largeur des cellules pour éviter l'effondrement du clone
            // pendant le glissement.
            helper: function (event, $row) {
                $row.children().each(function () {
                    $(this).width($(this).width());
                });
                return $row;
            },
            start: function (event, ui) {
                ui.item.addClass('evor-sorting');
            },
            stop: function (event, ui) {
                ui.item.removeClass('evor-sorting');
            },
            update: function () {
                var order = $list.children('tr').map(function () {
                    return parseInt(this.id.replace('post-', ''), 10) || 0;
                }).get();

                $.post(window.EvorRealOrder.ajaxUrl, {
                    action: 'evolutionr_reorder_realisation',
                    nonce: window.EvorRealOrder.nonce,
                    order: order
                });
            }
        });
    });
})(jQuery);
