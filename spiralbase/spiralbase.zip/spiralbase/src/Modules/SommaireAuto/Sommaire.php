<?php

declare(strict_types=1);

namespace SpiralBase\Modules\SommaireAuto;

/**
 * Référentiel UNIQUE des ancres du sommaire (story 2.7) : la slugification
 * utilisée pour POSER les id (transformation) et pour les LIER (rendu du
 * nav) est la même méthode — les deux ne peuvent pas diverger.
 * Classe PURE : aucune fonction WordPress.
 */
final class Sommaire
{
    /** Slug d'ancre : accents translittérés, kebab-case ASCII. */
    public function slug(string $texte): string
    {
        $texte = html_entity_decode($texte, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $translit = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texte);
        $texte = is_string($translit) ? $translit : $texte;
        $texte = strtolower((string) preg_replace('/[^a-z0-9]+/i', '-', $texte));

        return trim($texte, '-') !== '' ? trim($texte, '-') : 'section';
    }

    /**
     * Slug garanti unique dans l'ensemble donné — l'ensemble est ENRICHI
     * (déduplication cumulative -2/-3…).
     *
     * @param list<string> $pris passé par référence
     */
    public function slugUnique(string $texte, array &$pris): string
    {
        $base      = $this->slug($texte);
        $candidat  = $base;
        $suffixe   = 2;

        while (in_array($candidat, $pris, true)) {
            $candidat = $base . '-' . $suffixe;
            $suffixe++;
        }

        $pris[] = $candidat;

        return $candidat;
    }

    /**
     * Attribue une ancre à chaque heading du contexte : l'existante fait
     * FOI, les manquantes sont générées (même slugification que la pose).
     *
     * @param list<array{niveau: int, texte: string, ancre: ?string}> $headings
     *
     * @return list<array{niveau: int, texte: string, ancre: string}>
     */
    public function resoudreAncres(array $headings): array
    {
        $pris = [];

        foreach ($headings as $heading) {
            if (is_string($heading['ancre'] ?? null) && $heading['ancre'] !== '') {
                $pris[] = $heading['ancre'];
            }
        }

        $resolus = [];

        foreach ($headings as $heading) {
            $ancre = is_string($heading['ancre'] ?? null) && $heading['ancre'] !== ''
                ? $heading['ancre']
                : $this->slugUnique((string) ($heading['texte'] ?? ''), $pris);

            $resolus[] = ['niveau' => (int) ($heading['niveau'] ?? 2), 'texte' => (string) ($heading['texte'] ?? ''), 'ancre' => $ancre];
        }

        return $resolus;
    }
}
