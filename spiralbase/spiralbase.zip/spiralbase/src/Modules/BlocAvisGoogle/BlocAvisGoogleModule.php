<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocAvisGoogle;

use SpiralBase\Core\Module;
use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;

/**
 * Bloc « avis Google » (CAP-12, story 3.3) — la preuve sociale du client,
 * servie depuis un cache et jamais depuis le chemin d'un visiteur.
 *
 * Le rafraîchissement passe par WP-Cron : un appel synchrone au rendu ferait
 * payer à un visiteur la latence de Google, et l'AC 1 l'interdit
 * explicitement (« pas d'appel API à chaque page »). Le cron n'est planifié
 * que si le site est configuré — et il est retiré dès qu'il ne l'est plus,
 * pour ne pas laisser tourner deux échecs par jour sur toute la flotte.
 *
 * Réglages du module plutôt que `DonneesMetier` (AD-2) : la clé d'API est un
 * secret technique du site, pas une donnée d'identité de l'établissement, et
 * le vocabulaire de `DonneesMetier` est fermé et validé (2.3).
 *
 * OFF par défaut (AD-6). Aucune sonde de cession (`null`) : aucun plugin
 * d'avis n'est installé dans l'environnement de dev, et la discipline du
 * projet interdit une sonde sur des faits non lus (leçon 2.4).
 */
final class BlocAvisGoogleModule implements Module
{
    public const HANDLE_STYLE = 'spiralbase-avis-google';

    /**
     * Convention rendue exécutoire par le registre (revue 3.3) : une tâche
     * planifiée porte le préfixe `spiralbase_<slug>_`, ce qui permet au
     * noyau de la purger quand le module est éteint — un module OFF ne
     * boote pas, il ne peut pas nettoyer derrière lui.
     */
    public const HOOK_CRON = 'spiralbase_bloc_avis_google_rafraichir';

    private const REPERTOIRE = 'avis-google';

    /** Cadence STRICTEMENT plus longue que la fraîcheur du cache (voir AvisGoogle::TTL_FRAICHEUR). */
    private const CADENCE = 'twicedaily';

    private ?AvisGoogle $service = null;

    /** @param callable|null $transport injecté pour les tests et les preuves */
    public function __construct(
        private readonly Options $options,
        private readonly mixed $transport = null,
    ) {
    }

    public function slug(): string
    {
        return 'bloc_avis_google';
    }

    public function boot(): void
    {
        add_action('init', function (): void {
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/' . self::REPERTOIRE . '/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            $type = register_block_type(
                get_template_directory() . '/blocks/' . self::REPERTOIRE,
                ['render_callback' => fn (array $attributs): string => (new RenduAvis($this->service()))->rendre($attributs)]
            );

            if ($type === false) {
                Signal::emettre(
                    'spiralbase_avis_google_echec',
                    'bloc « avis-google » non enregistré : répertoire ou block.json illisible',
                    'avis google'
                );
            }

            $this->planifier();
        });

        add_action(self::HOOK_CRON, function (): void {
            $this->service()->rafraichir();
        });

        if (defined('WP_CLI') && WP_CLI) {
            \WP_CLI::add_command('spiralbase avis', new \SpiralBase\Core\Cli\AvisGoogleCommand($this->service()));
        }
    }

    /**
     * Le cron n'existe que pour un site configuré : sans clé ni identifiant
     * de lieu, il ne produirait que des échecs — deux fois par jour, sur
     * chaque site de la flotte qui a activé le module sans le remplir.
     */
    private function planifier(): void
    {
        $planifie = wp_next_scheduled(self::HOOK_CRON);

        if (!$this->service()->estConfigure()) {
            if ($planifie !== false) {
                wp_clear_scheduled_hook(self::HOOK_CRON);
            }

            return;
        }

        if ($planifie === false) {
            wp_schedule_event(time(), self::CADENCE, self::HOOK_CRON);
        }
    }

    public function service(): AvisGoogle
    {
        return $this->service ??= new AvisGoogle(
            $this->options,
            is_callable($this->transport) ? $this->transport : null
        );
    }

    public function defaultSettings(): array
    {
        return ['place_id' => '', 'cle_api' => ''];
    }

    /**
     * Le VERROU en fait partie : c'est une option (seul `add_option` est
     * atomique), elle doit donc être déclarée comme les autres — AD-11 ne
     * distingue pas l'option de réglage de l'option de service.
     *
     * Autoload : les RÉGLAGES restent chargés d'office — ils sont lus à
     * chaque requête (`planifier()` sur `init`) et pèsent quelques dizaines
     * d'octets. La COPIE DE SECOURS, elle, est écrite avec `autoload = false`
     * : plusieurs dizaines de kilo-octets d'avis désérialisés sur chaque page
     * du site, y compris celles sans le bloc (revue 3.3).
     */
    public function options(): array
    {
        return [AvisGoogle::OPTION, AvisGoogle::OPTION_SECOURS, AvisGoogle::OPTION_VERROU];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
