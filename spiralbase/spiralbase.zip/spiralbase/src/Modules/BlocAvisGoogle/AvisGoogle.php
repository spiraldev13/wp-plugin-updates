<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocAvisGoogle;

use SpiralBase\Core\Options;
use SpiralBase\Core\Signal;

/**
 * Récupération et conservation des avis Google (story 3.3).
 *
 * Deux niveaux de cache, un seul qui expire :
 *  - le transient de FRAÎCHEUR porte la seule décision « faut-il rappeler
 *    Google ? » ;
 *  - la COPIE DE SECOURS n'expire jamais et porte la dernière réponse
 *    valide.
 *
 * C'est ce qui rend l'AC 2 vraie par construction : une API en panne, un
 * quota dépassé ou une clé révoquée ne peuvent pas VIDER ce que le site
 * affiche — seulement l'empêcher de rajeunir. Un transient unique aurait fait
 * disparaître les avis au premier incident, c'est-à-dire le jour de forte
 * affluence où ils comptent le plus.
 *
 * Le service ne rend jamais d'erreur au visiteur : tout échec part en signal
 * NFR13, et la clé d'API n'apparaît ni dans une URL, ni dans un journal, ni
 * dans une page — ni chez la cible d'une redirection (revue 3.3 : WordPress
 * suit 5 redirections par défaut et REJOUE les en-têtes).
 */
final class AvisGoogle
{
    /** Réglages saisis par l'opérateur (place_id, clé d'API). */
    public const OPTION = 'spiralbase_avis_google';

    /** Dernière réponse valide — écrite par le module seul, jamais expirée. */
    public const OPTION_SECOURS = 'spiralbase_avis_google_secours';

    /** Verrou d'appel — option et non transient : seul `add_option` est atomique. */
    public const OPTION_VERROU = 'spiralbase_avis_google_verrou';

    public const TRANSIENT_FRAICHEUR = 'spiralbase_avis_google_frais';

    /**
     * Strictement INFÉRIEUR à la cadence du cron (`twicedaily`, 12 h) : le
     * transient est posé APRÈS l'appel, il est donc encore frais quand le
     * passage suivant se présente à l'heure. À 12 h, un passage sur deux ne
     * faisait rien et le rafraîchissement tombait à une fois par jour
     * (mesuré en revue 3.3).
     */
    public const TTL_FRAICHEUR = 11 * HOUR_IN_SECONDS;

    /**
     * Le verrou couvre la durée d'un appel HTTP, pas celle du cache : il
     * protège d'un doublon simultané (cron + WP-CLI), pas d'un rappel
     * légitime une fois la fraîcheur expirée.
     */
    public const TTL_VERROU = 5 * MINUTE_IN_SECONDS;

    /** Version de la charge mise en cache — une forme inconnue est refusée en LECTURE. */
    public const VERSION_CHARGE = 1;

    /** Résultats possibles d'un rafraîchissement — la CLI en fait des messages distincts. */
    public const RESULTAT_OK = 'ok';
    public const RESULTAT_NON_CONFIGURE = 'non_configure';
    public const RESULTAT_FRAIS = 'frais';
    public const RESULTAT_VERROUILLE = 'verrouille';
    public const RESULTAT_ECHEC = 'echec';

    private const ENDPOINT = 'https://places.googleapis.com/v1/places/';

    /** Lien officiel vers une fiche à partir de son identifiant (documentation Google Maps URLs). */
    private const FICHE = 'https://www.google.com/maps/place/?q=place_id:';

    /**
     * Masque de champs OBLIGATOIRE côté Places (New) : sans lui, l'API
     * refuse la requête — et avec un masque trop large, elle facture au
     * tarif le plus élevé. On ne demande que ce qui est affiché.
     */
    private const CHAMPS = 'rating,userRatingCount,googleMapsUri,reviews';

    /** Un avis Google plafonne à ~4 000 caractères ; au-delà, la réponse n'est pas de Google. */
    private const TEXTE_MAX = 4000;

    /** @var \Closure(string, array): (array|\WP_Error) */
    private \Closure $transport;

    /** @var \Closure(): int */
    private \Closure $horloge;

    /**
     * @param callable|null $transport injecté pour les tests et les preuves
     *                                 (`pre_http_request` couvre le reste)
     */
    public function __construct(
        private readonly Options $options,
        ?callable $transport = null,
        ?callable $horloge = null,
    ) {
        $this->transport = $transport === null
            ? static fn (string $url, array $args): array|\WP_Error => wp_remote_get($url, $args)
            : \Closure::fromCallable($transport);

        $this->horloge = $horloge === null
            ? static fn (): int => time()
            : \Closure::fromCallable($horloge);
    }

    /**
     * Dernière réponse valide connue, ou null. JAMAIS d'appel réseau ici.
     *
     * La charge est REVALIDÉE à la lecture, comme `DonneesMetier` depuis la
     * story 2.3 : une option écrite hors porte (import, migration, version
     * antérieure du thème) ne doit pas devenir une source de vérité. Sans
     * cela, une charge d'ancienne forme fabriquait une note « 0,0 » que
     * Google n'a jamais donnée (revue 3.3).
     */
    public function donnees(): ?array
    {
        $secours = $this->options->get(self::OPTION_SECOURS, null);

        if (!is_array($secours) || ($secours['v'] ?? null) !== self::VERSION_CHARGE) {
            return null;
        }

        $note  = $secours['note'] ?? null;
        $total = $secours['total'] ?? null;

        if (!is_array($secours['avis'] ?? null) || !is_int($total) || ($note !== null && !is_float($note))) {
            return null;
        }

        return $secours;
    }

    public function estFrais(): bool
    {
        return get_transient(self::TRANSIENT_FRAICHEUR) !== false;
    }

    /**
     * Vrai si le site est configuré ET que la donnée a vieilli — ou qu'il
     * n'y en a aucune : une fraîcheur posée sans copie de secours (écriture
     * refusée, purge d'options par un tiers) laissait sinon le bloc vide
     * pendant 12 h, cron muet (revue 3.3).
     */
    public function doitRafraichir(): bool
    {
        return $this->estConfigure() && (!$this->estFrais() || $this->donnees() === null);
    }

    public function estConfigure(): bool
    {
        [$placeId, $cle] = $this->identifiants();

        return $placeId !== '' && $cle !== '';
    }

    /**
     * Rappelle Google si c'est utile et possible.
     *
     * @param bool $force ignore la fraîcheur (commande WP-CLI de l'opérateur),
     *                    jamais le verrou : un appel déjà en vol reste unique.
     * @return bool vrai si une nouvelle réponse valide a été enregistrée
     */
    public function rafraichir(bool $force = false): bool
    {
        return $this->rafraichirDetaille($force) === self::RESULTAT_OK;
    }

    /**
     * Même chose, en nommant la cause : « rien à faire » et « appel refusé »
     * sont deux situations opposées pour l'opérateur, et la CLI les
     * confondait — elle annonçait « aucun appel émis » après un vrai
     * HTTP 400 (revue 3.3).
     */
    public function rafraichirDetaille(bool $force = false): string
    {
        [$placeId, $cle] = $this->identifiants();

        if ($placeId === '' || $cle === '') {
            return self::RESULTAT_NON_CONFIGURE;
        }

        if (!$force && $this->estFrais() && $this->donnees() !== null) {
            return self::RESULTAT_FRAIS;
        }

        $jeton = uniqid('spiralbase', true);

        if (!$this->options->acquerirVerrou(self::OPTION_VERROU, self::TTL_VERROU, $jeton)) {
            return self::RESULTAT_VERROUILLE;
        }

        try {
            $donnees = $this->appeler($placeId, $cle);
        } catch (\Throwable $e) {
            /* Le message peut venir d'un tiers : il ne doit contenir que ce
               que nous y avons mis. */
            $this->signaler($e->getMessage());

            return self::RESULTAT_ECHEC;
        } finally {
            $this->options->relacherVerrou(self::OPTION_VERROU, $jeton);
        }

        $donnees = $this->preserverLesAvis($donnees);

        /* La fraîcheur ne se pose QU'APRÈS une persistance constatée : sinon
           une écriture refusée (base en lecture seule, filtre tiers, quota)
           gelait le bloc 12 h en annonçant un succès (revue 3.3).
           `Options::set` rend aussi `false` quand la valeur est inchangée —
           d'où la relecture plutôt que le seul retour. */
        $this->options->set(self::OPTION_SECOURS, $donnees, false);

        if ($this->donnees() === null) {
            $this->signaler('copie de secours non persistée — aucune fraîcheur posée');

            return self::RESULTAT_ECHEC;
        }

        set_transient(self::TRANSIENT_FRAICHEUR, 1, self::TTL_FRAICHEUR);

        return self::RESULTAT_OK;
    }

    /**
     * Une réponse comprise à moitié n'efface jamais les témoignages.
     *
     * Cas réel : Google renomme un champ, restreint le masque, ou renvoie
     * une fiche amputée. `rating` et `userRatingCount` arrivent, `reviews`
     * non — la réponse est « valide » et écrasait une copie complète. La
     * preuve sociale disparaissait alors de toute la flotte, définitivement
     * (il n'existe pas de version antérieure), et la CLI annonçait
     * « Success » (revue 3.3, prouvé aux trois couches).
     *
     * On garde donc les avis précédents et on met la note à jour — la page
     * reste vraie sur les deux plans — et l'opérateur est averti.
     */
    private function preserverLesAvis(array $donnees): array
    {
        $ancien = $this->donnees();

        if ($donnees['avis'] !== [] || $ancien === null || ($ancien['avis'] ?? []) === []) {
            return $donnees;
        }

        $this->signaler(sprintf(
            'réponse sans avis exploitable : les %d avis précédents sont conservés',
            count($ancien['avis'])
        ));

        $donnees['avis'] = $ancien['avis'];

        return $donnees;
    }

    /** @return array{0: string, 1: string} */
    private function identifiants(): array
    {
        $reglages = $this->options->get(self::OPTION, []);

        if (!is_array($reglages)) {
            $this->signaler('réglages corrompus — aucun appel émis');

            return ['', ''];
        }

        $placeId = trim((string) ($reglages['place_id'] ?? ''));
        $cle     = trim((string) ($reglages['cle_api'] ?? ''));

        /* Un retour à la ligne dans la clé scinde l'en-tête HTTP et permet
           d'en injecter un second (prouvé en revue 3.3 sur une requête
           réelle). La valeur vient de l'opérateur, mais un import de
           réglages ou un compte compromis suffit. */
        foreach ([$placeId, $cle] as $valeur) {
            if (preg_match('/[\x00-\x1F\x7F]/', $valeur) === 1) {
                $this->signaler('identifiant contenant un caractère de contrôle — aucun appel émis');

                return ['', ''];
            }
        }

        return [$placeId, $cle];
    }

    /**
     * @throws \RuntimeException message SANS donnée secrète, destiné au journal
     */
    private function appeler(string $placeId, string $cle): array
    {
        /* L'identifiant de lieu part dans le CHEMIN : encodé, jamais
           concaténé brut (un place_id est fourni par l'opérateur). La clé
           part en EN-TÊTE — dans l'URL, elle atterrirait dans les journaux
           du serveur, les référents et les caches de proxy. */
        $reponse = ($this->transport)(self::ENDPOINT . rawurlencode($placeId), [
            'timeout' => 8,
            /* Aucune redirection : le cœur en suit 5 par défaut et REJOUE
               les en-têtes vers la nouvelle cible — la clé d'API partirait
               chez l'hôte de destination (prouvé). L'endpoint Places est un
               point fixe : une redirection y est déjà une anomalie. */
            'redirection' => 0,
            /* Une réponse Places à 5 avis pèse quelques kilo-octets ; sans
               plafond, un endpoint détourné faisait charger 5 Mo en mémoire
               puis en base. */
            'limit_response_size' => 256 * KB_IN_BYTES,
            'headers' => [
                'X-Goog-Api-Key'   => $cle,
                'X-Goog-FieldMask' => self::CHAMPS,
                'Accept'           => 'application/json',
            ],
        ]);

        if (is_wp_error($reponse)) {
            throw new \RuntimeException('appel refusé : ' . $reponse->get_error_code());
        }

        $code = wp_remote_retrieve_response_code($reponse);

        if ($code !== 200) {
            throw new \RuntimeException('réponse HTTP ' . $code);
        }

        $charge = json_decode(wp_remote_retrieve_body($reponse), true);

        if (!is_array($charge) || array_is_list($charge)) {
            throw new \RuntimeException('réponse illisible ou hors contrat');
        }

        return $this->normaliser($charge);
    }

    /**
     * Traduit la réponse de Google en structure interne stable.
     *
     * Rien n'est supposé présent : une API tierce change de forme sans
     * prévenir, et une réponse partiellement comprise ne doit jamais
     * remplacer une copie de secours qui, elle, est complète (garantie tenue
     * par `preserverLesAvis()`).
     *
     * @throws \RuntimeException si la réponse est hors contrat
     */
    private function normaliser(array $charge): array
    {
        $note  = $this->nombre($charge['rating'] ?? null);
        $total = $this->nombre($charge['userRatingCount'] ?? null);

        /* Établissement RÉEL sans aucun avis : Places omet les deux champs
           plutôt que de renvoyer 0. Les refuser condamnait un site qui
           fonctionne à deux appels facturés et deux journaux par jour, à
           perpétuité (revue 3.3). L'absence est donc un état valide — le
           rendu, lui, n'affichera pas d'en-tête. */
        $sansAvis = !array_key_exists('rating', $charge) && !array_key_exists('userRatingCount', $charge);

        if ($sansAvis) {
            $note  = null;
            $total = 0;
        } else {
            if ($note === null || $note < 0 || $note > 5) {
                throw new \RuntimeException('note absente ou hors de l\'échelle 0-5');
            }

            if ($total === null || $total < 0) {
                throw new \RuntimeException('nombre d\'avis absent ou négatif');
            }
        }

        $avis = [];

        foreach (is_array($charge['reviews'] ?? null) ? $charge['reviews'] : [] as $brut) {
            $normalise = $this->normaliserAvis(is_array($brut) ? $brut : []);

            if ($normalise !== null) {
                $avis[] = $normalise;
            }
        }

        return [
            'v'           => self::VERSION_CHARGE,
            'note'        => $note === null ? null : (float) $note,
            'total'       => (int) $total,
            'url'         => $this->urlSure($charge['googleMapsUri'] ?? ''),
            'avis'        => $avis,
            'recupere_le' => ($this->horloge)(),
        ];
    }

    /**
     * Le mapping JSON canonique de protobuf sérialise certains nombres en
     * CHAÎNES, et Google l'applique déjà sur d'autres champs de Places :
     * refuser « "128" » aurait jeté toute la réponse (revue 3.3).
     */
    private function nombre(mixed $valeur): int|float|null
    {
        if (is_int($valeur) || is_float($valeur)) {
            return $valeur;
        }

        return is_string($valeur) && is_numeric($valeur) ? $valeur + 0 : null;
    }

    private function normaliserAvis(array $brut): ?array
    {
        $auteur = is_array($brut['authorAttribution'] ?? null) ? $brut['authorAttribution'] : [];

        /* `text` est un objet localisé `{text, languageCode}` en Places
           (New), une chaîne dans l'ancienne API : les deux formes sont lues,
           et l'absence n'est pas une erreur — l'avis est simplement écarté. */
        $champTexte = $brut['text'] ?? null;
        $texte      = trim((string) (is_array($champTexte) ? ($champTexte['text'] ?? '') : $champTexte));

        /* Nom d'auteur et date relative viennent d'un TIERS et sont du texte
           pur : tout balisage y est du bruit ou une tentative. On le retire à
           l'entrée plutôt que de l'échapper à l'affichage — un visiteur n'a
           pas à lire « <img src=x onerror=…>Camille ». Le TEXTE de l'avis,
           lui, reste brut : c'est le rendu qui l'échappe, sans jamais en
           supprimer un mot (« Menu <plat du jour> excellent » perdait son
           milieu de phrase — revue 3.3). */
        $nom = trim(wp_strip_all_tags((string) ($auteur['displayName'] ?? '')));

        if ($nom === '' || $texte === '') {
            return null;
        }

        $note = $this->nombre($brut['rating'] ?? null);

        return [
            'auteur'     => $nom,
            'url_auteur' => $this->urlSure($auteur['uri'] ?? ''),
            'note'       => $note === null ? null : max(0, min(5, (int) round((float) $note))),
            'texte'      => mb_substr($texte, 0, self::TEXTE_MAX),
            /* Conservée pour `lang`/`dir` au rendu : un avis arabe dans une
               page française s'affiche autrement à l'endroit. */
            'langue'     => trim(wp_strip_all_tags((string) (is_array($champTexte) ? ($champTexte['languageCode'] ?? '') : ''))),
            'quand'      => trim(wp_strip_all_tags((string) ($brut['relativePublishTimeDescription'] ?? ''))),
            /* Lien vers L'AVIS, exigé par les conditions d'utilisation de
               Places — le profil de l'auteur ne le remplace pas. */
            'url'        => $this->urlSure($brut['googleMapsUri'] ?? ''),
        ];
    }

    /**
     * Une URL venue d'un tiers n'est retenue que si elle est http(s) : un
     * `javascript:` recopié dans un lien de profil deviendrait une XSS à
     * l'échelle de la flotte.
     */
    private function urlSure(mixed $url): string
    {
        if (!is_string($url)) {
            return '';
        }

        $schema = strtolower((string) parse_url(trim($url), PHP_URL_SCHEME));

        return in_array($schema, ['http', 'https'], true) ? trim($url) : '';
    }

    /**
     * Lien de repli vers la fiche, construit depuis l'identifiant de lieu
     * quand la réponse n'a pas fourni d'URL : l'attribution Google ne peut
     * pas être « parfois un lien, parfois du texte nu ».
     */
    public function urlFiche(): string
    {
        $donnees = $this->donnees();
        $url     = (string) ($donnees['url'] ?? '');

        if ($url !== '') {
            return $url;
        }

        [$placeId] = $this->identifiants();

        return $placeId === '' ? '' : self::FICHE . rawurlencode($placeId);
    }

    private function signaler(string $message): void
    {
        Signal::emettre('spiralbase_avis_google_echec', $message, 'avis google');
    }
}
