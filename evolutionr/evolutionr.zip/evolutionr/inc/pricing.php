<?php
/**
 * Accesseur du modèle de prix central.
 *
 * Seul point de lecture des tarifs (page d'options ACF « Tarifs »).
 * Les templates (page Création) et le configurateur (`app/configurateur.js`,
 * via wp_localize) consomment ces fonctions — jamais les champs ACF bruts.
 *
 * Cf. change tarifs-pilotes-back-office (décisions D2, D4, D5).
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Libellés lisibles des catégories de service. */
function evolutionr_pricing_category_labels(): array
{
    return [
        'creation'    => __('Création de site', 'evolutionr'),
        'seo'         => __('Référencement SEO', 'evolutionr'),
        'maintenance_hebergee' => __('Pack Maintenance + Hébergement', 'evolutionr'),
        'maintenance_seule'    => __('Maintenance seule', 'evolutionr'),
        'logo'        => __('Création de logo', 'evolutionr'),
        'regie'       => __('Régie / sur-mesure', 'evolutionr'),
    ];
}

/**
 * La catégorie a-t-elle au moins une offre visible dans le modèle central ?
 * Sert aux gabarits de prestation pour masquer une section de prix entièrement
 * vide (catégorie masquée dans les réglages Tarifs, ou plus aucune offre active).
 */
function evolutionr_category_has_offers(string $cat): bool
{
    return !empty(evolutionr_get_pricing()['services'][$cat]['modes']);
}

/**
 * Peuple le champ « Catégories masquées » (réglages Tarifs) depuis la liste
 * centrale des catégories — source unique, jamais de dérive. Admin uniquement.
 */
add_filter('acf/load_field/name=categories_masquees', function (array $field): array {
    if (is_admin()) {
        $field['choices'] = evolutionr_pricing_category_labels();
    }
    return $field;
});

/**
 * Modèle de prix normalisé.
 *
 * @return array{rates:array{tva:float},options:array<string,array>,services:array<string,array>}
 */
function evolutionr_get_pricing(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $data = [
        'rates'      => ['tva' => 20.0],
        'options'    => [],
        'services'   => [],
        'groups'     => [],
        'promotions' => [],
    ];

    if (function_exists('evolutionr_acf_is_active') && !evolutionr_acf_is_active()) {
        return $cache = $data;
    }

    $data['rates']['tva'] = (float) (get_field('tva_pct', 'option') ?: 20);

    $labels = evolutionr_pricing_category_labels();
    // Catégories masquées globalement (réglages Tarifs) : leurs offres sont
    // exclues du modèle → invisibles partout (configurateur, aperçu, pages).
    $hidden = (array) get_field('categories_masquees', 'option');

    $offres = get_field('offres', 'option');
    if (is_array($offres)) {
        foreach ($offres as $row) {
            if (empty($row['actif'])) {
                continue;
            }
            $cat = (string) ($row['categorie'] ?? '');
            if ($cat === '' || in_array($cat, $hidden, true)) {
                continue;
            }
            $fact  = (string) ($row['facturation'] ?? 'paiement_unique');
            $offer = evolutionr_pricing_normalize_offer($row, $fact);

            if (!isset($data['services'][$cat])) {
                $data['services'][$cat] = [
                    'label' => $labels[$cat] ?? $cat,
                    'modes' => [],
                ];
            }
            $data['services'][$cat]['modes'][$fact][] = $offer;
        }
    }

    $options = get_field('options', 'option');
    if (is_array($options)) {
        foreach ($options as $opt) {
            // Option désactivée (actif explicitement faux) → ignorée.
            if (array_key_exists('actif', $opt) && !$opt['actif']) {
                continue;
            }
            $label = (string) ($opt['label'] ?? '');
            // Clé optionnelle : dérivée du libellé si laissée vide.
            $cle = (string) ($opt['cle'] ?? '');
            if ($cle === '') {
                $cle = sanitize_title($label);
            }
            if ($cle === '') {
                continue;
            }
            $optUnit     = (string) ($opt['unite'] ?? 'mensuel');
            $optPrice    = (float) ($opt['prix'] ?? 0);
            $optSurDevis = !empty($opt['sur_devis']);
            $optPrefix   = !empty($opt['prefixe_a_partir']);
            // Libellé de prix unifié (réutilise la logique des offres) : unité
            // « mensuel » → « …/mois », sinon paiement unique. « Sur devis » prime ;
            // « à partir de » via le préfixe.
            $optFact  = ($optUnit === 'mensuel') ? 'abonnement' : 'paiement_unique';
            $optLabel = $optSurDevis
                ? __('Sur devis', 'evolutionr')
                : evolutionr_pricing_format_label($optFact, $optPrice, 0.0, $optPrefix);

            $data['options'][$cle] = [
                'label'              => $label,
                'famille'            => (string) ($opt['famille'] ?? 'service'),
                'unit'               => $optUnit,
                'price'              => $optPrice,
                'sur_devis'          => $optSurDevis,
                'prefix_from'        => $optPrefix,
                'price_label'        => $optLabel,
                'description'        => (string) ($opt['description'] ?? ''),
                'description_detail' => (string) ($opt['description_detail'] ?? ''),
            ];
        }
    }

    // Groupes d'add-ons à paliers : Pack M+H (maintenance hébergée) et SEO.
    // L'hébergement n'est plus un produit autonome (fondu dans le Pack M+H).
    // Paliers = offres de la catégorie, triées par prix croissant.
    // SEO jamais incluable (never_included).
    $data['groups'] = [];
    foreach (['maintenance_hebergee', 'seo'] as $groupCat) {
        $tiers = [];
        foreach ($data['services'][$groupCat]['modes'] ?? [] as $offers) {
            foreach ($offers as $o) {
                $tiers[] = $o;
            }
        }
        usort($tiers, static fn ($a, $b) => $a['price'] <=> $b['price']);
        $data['groups'][$groupCat] = [
            'never_included' => ($groupCat === 'seo'),
            'tiers'          => $tiers,
        ];
    }

    // Promotions actives uniquement.
    $promos = get_field('promotions', 'option');
    if (is_array($promos)) {
        foreach ($promos as $p) {
            if (empty($p['actif'])) {
                continue;
            }
            $familles = $p['familles_requises'] ?? [];
            $data['promotions'][] = [
                'label'    => (string) ($p['label'] ?? ''),
                'pct'      => (float) ($p['remise_pct'] ?? 0),
                'target'   => (string) ($p['cible'] ?? 'mensuel'),
                'requires' => is_array($familles) ? array_values($familles) : [],
            ];
        }
    }

    return $cache = $data;
}

/** Normalise une ligne de repeater « offre » en structure exploitable. */
function evolutionr_pricing_normalize_offer(array $row, string $fact): array
{
    $price    = (float) ($row['prix'] ?? 0);
    $setup    = (float) ($row['frais_setup'] ?? 0);
    $prefix   = !empty($row['prefixe_a_partir']);
    $surDevis = !empty($row['sur_devis']);

    return [
        'name'        => (string) ($row['nom'] ?? ''),
        'facturation' => $fact,
        'price'       => $price,
        'setup_fee'   => $setup,
        'engagement'  => (string) ($row['engagement'] ?? ''),
        'delay'       => (string) ($row['delai'] ?? ''),
        'prefix_from' => $prefix,
        'sur_devis'   => $surDevis,
        'price_label' => $surDevis ? __('Sur devis', 'evolutionr') : evolutionr_pricing_format_label($fact, $price, $setup, $prefix),
        'included'    => evolutionr_pricing_list($row['inclus'] ?? []),
        'excluded'    => evolutionr_pricing_list($row['exclus'] ?? []),
        'featured'    => !empty($row['mis_en_avant']),
        'badge'       => (string) ($row['libelle_badge'] ?? ''),
        // Paliers inclus de base (abonnement) : nom de l'offre-palier, ou '' si aucun.
        'baseline'    => [
            // Hébergement fondu dans le Pack M+H → plus de palier hébergement séparé.
            'maintenance_hebergee' => (string) ($row['inclus_maintenance'] ?? ''),
        ],
    ];
}

/** Formatage monétaire français : 1890 → « 1 890 € ». */
function evolutionr_pricing_eur(float $amount): string
{
    return number_format($amount, 0, ',', "\u{202f}") . "\u{202f}€";
}

/** Construit le libellé de prix selon l'unité de facturation. */
function evolutionr_pricing_format_label(string $fact, float $price, float $setup, bool $prefix): string
{
    $from = $prefix ? 'à partir de ' : '';

    switch ($fact) {
        case 'abonnement':
            $base = $setup > 0
                ? evolutionr_pricing_eur($setup) . ' + ' . evolutionr_pricing_eur($price) . '/mois'
                : evolutionr_pricing_eur($price) . '/mois';
            return $from . $base;
        case 'horaire':
            return $from . evolutionr_pricing_eur($price) . '/h';
        case 'journalier':
            return $from . evolutionr_pricing_eur($price) . '/jour';
        default:
            return $from . evolutionr_pricing_eur($price);
    }
}

/** Aplati un sous-repeater [{texte:…}] en tableau de chaînes. */
function evolutionr_pricing_list($rows): array
{
    $out = [];
    if (is_array($rows)) {
        foreach ($rows as $r) {
            $t = is_array($r) ? (string) ($r['texte'] ?? '') : (string) $r;
            if ($t !== '') {
                $out[] = $t;
            }
        }
    }
    return $out;
}

/** Normalise un nom pour l'appariement (minuscules, sans accents). */
function evolutionr_pricing_norm(string $s): string
{
    $s = remove_accents(mb_strtolower(trim($s)));
    $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
    return trim((string) $s);
}

/**
 * Cherche une offre d'une catégorie par nom et mode de facturation.
 * Utilisé pour le double-ancrage de la page Création.
 */
function evolutionr_pricing_find_offer(string $cat, string $name, string $facturation): ?array
{
    $pricing = evolutionr_get_pricing();
    $offers  = $pricing['services'][$cat]['modes'][$facturation] ?? [];
    $needle  = evolutionr_pricing_norm($name);

    foreach ($offers as $offer) {
        if (evolutionr_pricing_norm($offer['name']) === $needle) {
            return $offer;
        }
    }
    return null;
}

/**
 * Résout une référence d'offre « catégorie|nom|facturation » vers son prix et sa
 * visibilité. Point unique partagé par toutes les surfaces vitrine (section 07,
 * packs des pages prestation, types de la page Création) — aucune duplication de la
 * logique de cascade.
 *
 * La visibilité découle de `actif` : les offres `actif = non` sont déjà exclues de
 * `evolutionr_get_pricing()`, donc introuvables ici → `visible = false`. Une carte
 * non liée (réf vide/mal formée) est également non visible.
 *
 * @return array{price_label: string, visible: bool}
 */
function evolutionr_offer_resolve(string $offre_ref): array
{
    $hidden = ['price_label' => '', 'visible' => false];

    $ref = trim($offre_ref);
    if ($ref === '') {
        return $hidden;
    }

    [$cat, $name, $fact] = array_pad(explode('|', $ref, 3), 3, '');
    if ($cat === '' || $name === '' || $fact === '') {
        return $hidden;
    }

    $offer = evolutionr_pricing_find_offer($cat, $name, $fact);
    if ($offer === null) {
        return $hidden;
    }

    return ['price_label' => (string) $offer['price_label'], 'visible' => true];
}

/**
 * Charge utile JSON pour le configurateur (`window.evolutionrPricing`).
 * Reshape le modèle dans la forme attendue par `app/configurateur.js`.
 */
function evolutionr_pricing_js_payload(): array
{
    $pricing  = evolutionr_get_pricing();
    $services = [];
    $tvaMult  = 1 + (($pricing['rates']['tva'] ?? 20) / 100);

    foreach ($pricing['services'] as $cat => $svc) {
        $modes = [];
        foreach ($svc['modes'] as $fact => $offers) {
            // Le configurateur attend la clé `one_shot` pour le paiement unique.
            $bucketKey = ($fact === 'paiement_unique') ? 'one_shot' : $fact;
            $bucket = [];
            foreach ($offers as $o) {
                // Une offre « sur devis » n'a pas de prix chiffrable → hors configurateur.
                if (!empty($o['sur_devis'])) {
                    continue;
                }
                $js = [
                    'name'         => $o['name'],
                    'priceLabel'   => $o['price_label'],
                    'priceLabelTtc' => evolutionr_pricing_format_label($o['facturation'], $o['price'] * $tvaMult, $o['setup_fee'] * $tvaMult, $o['prefix_from']),
                    'delay'      => $o['delay'],
                    'included'   => $o['included'],
                    'excluded'   => $o['excluded'],
                    'featured'   => $o['featured'],
                    'badge'      => $o['badge'],
                    'unit'       => $fact, // facturation d'origine (paiement_unique/abonnement/horaire/journalier)
                    'setupFee'   => null,
                    'commitment' => null,
                    'baseline'   => $o['baseline'], // { maintenance_hebergee } nom de palier inclus
                ];
                if ($fact === 'abonnement') {
                    $js['monthlyPrice'] = $o['price'];
                    $js['setupFee']     = $o['setup_fee'] > 0 ? $o['setup_fee'] : null;
                    $js['commitment']   = $o['engagement'] !== '' ? $o['engagement'] : null;
                } else {
                    $js['price'] = $o['price'];
                }
                $bucket[] = $js;
            }
            $modes[$bucketKey] = $bucket;
        }
        $services[$cat] = ['label' => $svc['label'], 'modes' => $modes];
    }

    $options = [];
    foreach ($pricing['options'] as $cle => $opt) {
        $options[$cle] = [
            'label'             => $opt['label'],
            'family'            => $opt['famille'],
            'type'              => $opt['unit'] === 'mensuel' ? 'monthly' : 'one_shot',
            'price'             => $opt['price'],
            'priceLabel'        => $opt['price_label'],
            'surDevis'          => $opt['sur_devis'],
            'description'       => $opt['description'],
            'descriptionDetail' => $opt['description_detail'],
        ];
    }

    // Groupes d'add-ons à paliers, prêts pour le configurateur.
    $groups = [];
    foreach ($pricing['groups'] as $cat => $group) {
        $tiers = [];
        foreach ($group['tiers'] as $t) {
            $tiers[] = [
                'name'        => $t['name'],
                'price'       => $t['price'],
                'priceLabel'  => $t['price_label'],
                'included'    => $t['included'],
                'recurring'   => ($t['facturation'] === 'abonnement'),
            ];
        }
        $groups[$cat] = [
            'neverIncluded' => $group['never_included'],
            'tiers'         => $tiers,
        ];
    }

    return [
        'services'   => $services,
        'options'    => $options,
        'rates'      => $pricing['rates'],
        'groups'     => $groups,
        'promotions' => $pricing['promotions'],
    ];
}

/**
 * Injecte le modèle de prix dans le DOM de la page Tarifs, avant le
 * module configurateur (handle `theme-configurateur`, cf. config-viteJs).
 */
add_action('wp_enqueue_scripts', function (): void {
    if (!is_page('tarifs')) {
        return;
    }
    $json = wp_json_encode(evolutionr_pricing_js_payload());
    wp_add_inline_script(
        'theme-configurateur',
        'window.evolutionrPricing = ' . $json . ';',
        'before'
    );
}, 20);

/** Libellé lisible d'un mode de facturation. */
function evolutionr_facturation_label(string $fact): string
{
    $map = [
        'paiement_unique' => __('paiement unique', 'evolutionr'),
        'abonnement'      => __('abonnement', 'evolutionr'),
        'horaire'         => __('horaire', 'evolutionr'),
        'journalier'      => __('journalier', 'evolutionr'),
    ];
    return $map[$fact] ?? $fact;
}

/**
 * Peuple dynamiquement le select « Offre liée » de l'aperçu tarifs (page d'accueil)
 * depuis le modèle de prix central. Valeur stockée : « catégorie|nom|facturation ».
 * Admin uniquement : en front, le template lit la valeur brute (pas besoin des choix).
 */
add_filter('acf/load_field/name=offre_ref', function (array $field): array {
    if (!is_admin() || !function_exists('evolutionr_get_pricing')) {
        return $field;
    }

    // Le menu « Offre liée » ne propose que les catégories pertinentes pour la
    // surface, déterminées par la clé du sous-champ. Clé non mappée → toutes
    // (sécurité : ne jamais renvoyer une liste vide).
    $categoriesByKey = [
        'field_evor_ps_pack_offre_ref'  => ['seo'],
        'field_evor_pm_pack_offre_ref'  => ['maintenance_hebergee'],
        'field_evor_pm_host_offre_ref'  => ['maintenance_seule'],
        'field_evor_piv_pack_offre_ref' => ['logo'],
        'field_evor_pc_type_offre_ref'  => ['creation'],
    ];
    $key     = (string) ($field['key'] ?? '');
    $allowed = $categoriesByKey[$key] ?? null; // null = toutes les catégories
    // La page Création affiche les deux modes par nom → une seule entrée par offre.
    $dedupeByName = ($key === 'field_evor_pc_type_offre_ref');

    $choices = [];
    $seen    = [];
    foreach (evolutionr_get_pricing()['services'] as $cat => $svc) {
        if ($allowed !== null && !in_array($cat, $allowed, true)) {
            continue;
        }
        foreach ($svc['modes'] as $fact => $offers) {
            foreach ($offers as $offer) {
                if ($dedupeByName) {
                    if (isset($seen[$offer['name']])) {
                        continue;
                    }
                    $seen[$offer['name']] = true;
                    // Valeur canonique : le template Création n'exploite que le nom.
                    $choices[$cat . '|' . $offer['name'] . '|paiement_unique'] =
                        $svc['label'] . ' — ' . $offer['name'];
                    continue;
                }
                $value = $cat . '|' . $offer['name'] . '|' . $fact;
                $choices[$value] = sprintf(
                    '%s — %s (%s) · %s',
                    $svc['label'],
                    $offer['name'],
                    evolutionr_facturation_label($fact),
                    $offer['price_label']
                );
            }
        }
    }

    $field['choices'] = $choices;
    return $field;
});

/**
 * Choix du palier « Maintenance + Hébergement inclus de base » : alimentés dynamiquement par
 * les paliers réellement définis dans la catégorie maintenance_hebergee, au lieu de noms codés
 * en dur. Ainsi renommer un palier met la liste à jour (plus de choix figé). Même pattern que
 * `offre_ref` / `categories_masquees`. La valeur stockée reste le NOM du palier (le modèle indexe
 * par nom) : après un renommage, re-sélectionner le palier dans cette liste désormais à jour.
 */
add_filter('acf/load_field/name=inclus_maintenance', function (array $field): array {
    // Garde anti-réentrance : ce champ est un SOUS-CHAMP du repeater des offres que
    // `evolutionr_get_pricing()` lit. Lire les offres recharge la définition du champ →
    // re-déclenche ce filtre → re-appellerait get_pricing (cache pas encore posé) → récursion
    // infinie. Le flag fait court-circuiter l'appel imbriqué (il renvoie le champ tel quel ;
    // get_pricing lit les VALEURS, pas les choices, donc rien n'est faussé).
    static $loading = false;
    if ($loading || !is_admin() || !function_exists('evolutionr_get_pricing')) {
        return $field;
    }

    $loading = true;
    try {
        $choices = [];
        $svc = evolutionr_get_pricing()['services']['maintenance_hebergee'] ?? null;
        if ($svc) {
            foreach ($svc['modes'] as $offers) {
                foreach ($offers as $offer) {
                    $choices[$offer['name']] = $offer['name'];
                }
            }
        }
        $field['choices'] = $choices;
    } finally {
        $loading = false;
    }

    return $field;
});

/**
 * Choix des « éléments requis » d'une promo : générés dynamiquement (plus de codage en dur).
 * Une promo se conditionne désormais sur n'importe quel élément ajoutable, sous forme de
 * « dimension » à clé stable :
 *   · catégorie de service        → slug (`creation`…`regie`)
 *   · option (serveur/migration/ponctuelle) → `opt:<clé>`
 *   · add-on cumulable d'un groupe (ex. Audit SEO) → `add:<nom>`
 * Garde anti-réentrance : `familles_requises` est un sous-champ du repeater promotions que
 * `get_pricing()` lit → même piège de récursion que `inclus_maintenance`.
 */
add_filter('acf/load_field/name=familles_requises', function (array $field): array {
    static $loading = false;
    if ($loading || !is_admin() || !function_exists('evolutionr_get_pricing')) {
        return $field;
    }

    $loading = true;
    try {
        $choices = [];
        // Catégories de service (liste centrale).
        foreach (evolutionr_pricing_category_labels() as $slug => $label) {
            $choices[$slug] = $label;
        }
        $pricing = evolutionr_get_pricing();
        // Options (serveur, migration, ponctuelles) → une dimension par option.
        foreach ($pricing['options'] as $cle => $opt) {
            $choices['opt:' . $cle] = 'Option — ' . ($opt['label'] ?? $cle);
        }
        // Add-ons cumulables des groupes (paliers non récurrents, ex. Audit SEO).
        foreach ($pricing['groups'] as $group) {
            foreach ($group['tiers'] as $t) {
                if (($t['facturation'] ?? '') !== 'abonnement') {
                    $choices['add:' . $t['name']] = 'Option — ' . $t['name'];
                }
            }
        }
        $field['choices'] = $choices;
    } finally {
        $loading = false;
    }

    return $field;
});
