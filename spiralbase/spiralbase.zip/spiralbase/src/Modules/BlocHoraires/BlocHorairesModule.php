<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocHoraires;

use SpiralBase\Core\DonneesMetier;
use SpiralBase\Core\Module;

/**
 * Bloc métier « Horaires » (CAP-12, story 3.1) — PREMIER bloc de l'Epic 3,
 * écrit sur le pattern de référence établi en 2.9 et gravé dans la spine le
 * 2026-07-30 : `block.json` + `index.js` à la main + `index.asset.php` à la
 * main + `render_callback` porté par le module (AD-12, forme canonique).
 *
 * Le `render_callback` est ce qui rend ce module possible : il injecte le
 * service `DonneesMetier` du noyau (AD-2/AD-4) dans le rendu. Un `render.php`
 * isolé n'y accéderait que par un état statique — interdit ici.
 *
 * OFF par défaut (AD-6, sans exception pour les blocs métier) : la
 * pertinence d'un bloc horaires dépend du métier du client, c'est
 * exactement ce que la règle protège. Interrupteur OFF ⇒ bloc jamais
 * enregistré ⇒ le markup auto-fermant rend du vide (AD-3).
 *
 * Aucune sonde de cession (`null`, comme `schema_metier` 2.3) : aucun plugin
 * d'horaires n'est installé dans l'environnement de dev, et la discipline du
 * projet interdit une sonde sur des faits non lus dans un plugin réel (leçon
 * 2.4). Le fond diffère d'ailleurs des modules SEO : ce bloc ne rend que là
 * où l'opérateur l'a POSÉ — céder ferait disparaître un bloc explicitement
 * placé sur une page.
 */
final class BlocHorairesModule implements Module
{
    public function __construct(private readonly DonneesMetier $donnees)
    {
    }

    /** Handle de la feuille du bloc — voir boot(). */
    public const HANDLE_STYLE = 'spiralbase-horaires';

    public function slug(): string
    {
        return 'bloc_horaires';
    }

    public function boot(): void
    {
        /* boot() court sur after_setup_theme ; le cœur enregistre les blocs
           sur init — on s'y range (même séquencement qu'en 2.9). */
        add_action('init', function (): void {
            /* Feuille enregistrée ICI, et déclarée par HANDLE dans le
               block.json : le cœur versionne les feuilles depuis le
               block.json (`blocks.php:350-351`), fichier statique — la
               version y restait figée à 1.0.0 et une correction livrée par
               une release de la flotte n'aurait jamais franchi les caches
               (revue 3.2 ; les scripts étaient déjà couverts par leur
               manifeste depuis la revue 3.1). */
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/horaires/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            register_block_type(
                get_template_directory() . '/blocks/horaires',
                ['render_callback' => fn (array $attributs): string => (new RenduHoraires($this->donnees))->rendre($attributs)]
            );
        });
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
