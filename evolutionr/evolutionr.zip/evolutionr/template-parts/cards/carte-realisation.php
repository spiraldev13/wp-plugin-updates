<?php
/**
 * Carte unitaire — Réalisation (CPT `realisation`).
 *
 * Inclue depuis sections/06-realisations.php. Le format dans la grille bento
 * est piloté par le champ `realisation_layout` (tall / wide / sq).
 *
 * Champs ACF (CPT realisation) :
 *   realisation_client, realisation_mission, realisation_year,
 *   realisation_layout, realisation_visual, realisation_url.
 * Taxonomie `secteur` : affichée comme tag en overlay (1er terme).
 * Carte cliquable (nouvel onglet) si `realisation_url` est renseignée, sinon
 * conteneur statique non cliquable (le CPT n'a pas d'URL publique → 404 évitée).
 */

if (!defined('ABSPATH')) {
    exit;
}

$client  = get_field('realisation_client') ?: get_the_title();
$mission = get_field('realisation_mission');
$year    = get_field('realisation_year') ?: get_the_date('Y');
$layout  = get_field('realisation_layout') ?: 'sq';
$visual  = get_field('realisation_visual');
$url     = trim((string) get_field('realisation_url'));

$terms = get_the_terms(get_the_ID(), 'secteur');
$tag   = (!is_wp_error($terms) && !empty($terms)) ? $terms[0]->name : '';

// La carte n'est cliquable que si une URL est renseignée. Le CPT est non public
// (publicly_queryable=false) : sans URL, un lien mènerait à une 404 → conteneur
// statique non cliquable. Le style `.work-card` est porté par la classe, donc
// identique en <a> ou en <div>.
$classes = 'work-card layout-' . $layout . ($url ? '' : ' work-card--static');
if ($url) {
    printf(
        '<a class="%s" href="%s" target="_blank" rel="noopener noreferrer">',
        esc_attr($classes),
        esc_url($url)
    );
} else {
    printf('<div class="%s">', esc_attr($classes));
}
?>
    <div class="work-canvas">
        <?php if (is_array($visual) && !empty($visual['url'])): ?>
            <img src="<?php echo esc_url($visual['url']); ?>" alt="<?php echo esc_attr($visual['alt'] ?? $client); ?>" loading="lazy">
        <?php elseif (has_post_thumbnail()): ?>
            <?php the_post_thumbnail('large', ['loading' => 'lazy', 'alt' => esc_attr($client)]); ?>
        <?php endif; ?>
    </div>
    <div class="work-overlay">
        <?php if ($tag): ?>
            <div class="work-tag"><?php echo esc_html($tag); ?></div>
        <?php endif; ?>
        <div class="work-title"><?php echo esc_html($client); ?></div>
        <div class="work-meta">
            <?php if ($mission): ?>
                <span><?php echo esc_html($mission); ?></span>
            <?php endif; ?>
            <?php if ($year): ?>
                <span class="year"><?php echo esc_html((string) $year); ?></span>
            <?php endif; ?>
        </div>
    </div>
<?php echo $url ? '</a>' : '</div>'; ?>
