<?php

/*
 * Manifeste d'asset ÉCRIT À LA MAIN (pas de build — AD-12).
 * La version suit celle du THÈME, jamais un numéro figé : le cœur en fait le
 * `?ver=` du script (garde-fou testé : AssetsBlocsTest).
 */
return [
    'dependencies' => ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n'],
    'version'      => (string) wp_get_theme(get_template())->get('Version'),
];
