<?php
/**
 * Title: Unité article — grande
 * Slug: techana-revue/unite-grande
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Tête de bloc de rubrique — image 3:2, titre 26px, extrait, signature complète.
 * Viewport Width: 500
 */
?>
<!-- wp:group {"className":"u-big k-auto"} -->
<div class="wp-block-group u-big k-auto"><!-- wp:post-featured-image {"sizeSlug":"techana-3-2","className":"ph-auto"} /-->

<!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:post-excerpt {"excerptLength":22} /-->

<!-- wp:paragraph {"className":"meta","metadata":{"bindings":{"content":{"source":"techana/meta-grande"}}}} -->
<p class="meta"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
