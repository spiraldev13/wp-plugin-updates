<?php

/**
 * AI Images - Registre des fournisseurs de génération d'images
 *
 * Construit et expose les providers disponibles. Extensible via le filtre
 * `ultimate_shanks_ai_image_providers` : les entrées ajoutées doivent
 * implémenter ProviderInterface (les autres sont écartées).
 *
 * Fichiers liés :
 * - src/ai-images/provider-interface.php
 * - src/ai-images/provider-flux.php
 *
 * @package UltimateShanks\AiImages
 */

namespace UltimateShanks\AiImages;

if (!defined('ABSPATH')) {
	exit;
}

class Providers
{
	const DEFAULT_PROVIDER = 'flux-bfl';

	/**
	 * Cache des instances construites (une seule construction par requête)
	 *
	 * @var array|null
	 */
	private static $providers = null;

	/**
	 * Retourne tous les providers disponibles, indexés par identifiant
	 *
	 * @return ProviderInterface[]
	 */
	public static function get_all()
	{
		if (self::$providers !== null) {
			return self::$providers;
		}

		$providers = [
			self::DEFAULT_PROVIDER => new FluxProvider(),
		];

		$providers = apply_filters('ultimate_shanks_ai_image_providers', $providers);

		// Écarte toute entrée externe qui ne respecte pas le contrat
		self::$providers = array_filter($providers, function ($provider) {
			return $provider instanceof ProviderInterface;
		});

		return self::$providers;
	}

	/**
	 * Retourne un provider par identifiant
	 *
	 * @param string $id
	 * @return ProviderInterface|null
	 */
	public static function get($id)
	{
		$providers = self::get_all();

		return isset($providers[$id]) ? $providers[$id] : null;
	}

	/**
	 * Retourne le provider actif (option), avec repli sur Flux si l'option
	 * pointe vers un provider disparu
	 *
	 * @return ProviderInterface
	 */
	public static function get_active()
	{
		$id = get_option('ultimate_shanks_ai_images_provider', self::DEFAULT_PROVIDER);
		$provider = self::get($id);

		return $provider !== null ? $provider : self::get(self::DEFAULT_PROVIDER);
	}

	/**
	 * Lit une option de réglage propre à un provider.
	 * Convention de nommage : ultimate_shanks_ai_images_{provider}_{key},
	 * où l'identifiant du provider est normalisé en snake_case
	 * (ex. 'flux-bfl' + 'api_key' → ultimate_shanks_ai_images_flux_bfl_api_key).
	 *
	 * @param string $provider_id
	 * @param string $key
	 * @param mixed  $default
	 * @return mixed
	 */
	public static function get_setting($provider_id, $key, $default = '')
	{
		return get_option(self::setting_option_name($provider_id, $key), $default);
	}

	/**
	 * Construit le nom d'option d'un champ de provider
	 *
	 * @param string $provider_id
	 * @param string $key
	 * @return string
	 */
	public static function setting_option_name($provider_id, $key)
	{
		$slug = str_replace('-', '_', sanitize_key($provider_id));

		return 'ultimate_shanks_ai_images_' . $slug . '_' . sanitize_key($key);
	}
}
