/**
 * Bloc spiralbase/plan-de-site — JS éditeur écrit à la main, SANS build
 * (AD-12 : build en dev uniquement, artefacts livrés — ce fichier EST
 * l'artefact). Bloc 100 % dynamique : save() rend null, le serveur rend tout.
 */
( function ( blocks, element, blockEditor, i18n ) {
    'use strict';

    blocks.registerBlockType( 'spiralbase/plan-de-site', {
        edit: function () {
            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-plan-site-apercu',
                style: {
                    border: '1px dashed currentColor',
                    borderRadius: '4px',
                    opacity: 0.8,
                    padding: '1em',
                },
            } );

            return element.createElement(
                'div',
                blockProps,
                element.createElement( 'strong', null, i18n.__( 'Plan de site', 'spiralbase' ) ),
                element.createElement(
                    'p',
                    { style: { margin: '0.5em 0 0' } },
                    i18n.__( 'L’arborescence des contenus publics est rendue sur le site.', 'spiralbase' )
                )
            );
        },
        save: function () {
            return null;
        },
    } );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.i18n );
