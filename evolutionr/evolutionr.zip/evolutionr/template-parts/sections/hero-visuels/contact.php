<?php
/**
 * Motif hero « Contact » — canaux + disponibilité.
 *
 * Décor fixe (aucun champ ACF). Inclus via template-parts/cards/hero-visuel.php.
 * Trois canaux (email, téléphone, localisation) + un badge de disponibilité et
 * un délai de réponse. SVG inline (pas dans le catalogue d'icônes du thème).
 * Unités relatives → responsive 320px → desktop.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Icônes décoratives inline (24×24, stroke currentColor).
$icons = [
    'mail'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    'pin'   => '<path d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
];

$channels = [
    ['icon' => 'mail',  'value' => 'Formulaire de contact'],
    ['icon' => 'pin',   'value' => 'France · à distance'],
];

$svg = function (string $key) use ($icons): string {
    $paths = $icons[$key] ?? '';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" '
        . 'stroke-linecap="round" stroke-linejoin="round" focusable="false" aria-hidden="true">'
        . $paths . '</svg>';
};
?>
<div class="hvk">
    <ul class="hvk-channels">
        <?php foreach ($channels as $i => $ch): ?>
            <li class="hvk-channel" style="--i: <?php echo (int) $i; ?>;">
                <span class="hvk-icon"><?php echo $svg($ch['icon']); // SVG statique de confiance ?></span>
                <span class="hvk-value"><?php echo esc_html($ch['value']); ?></span>
            </li>
        <?php endforeach; ?>
    </ul>
    <div class="hvk-avail">
        <span class="hvk-avail-dot"></span>
        <span class="hvk-avail-text">Disponible — réponse sous 48&nbsp;h</span>
    </div>
</div>
