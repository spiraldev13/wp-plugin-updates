<?php

declare(strict_types=1);

namespace SpiralBase\Modules\PerfWebp;

use SpiralBase\Core\Module;

/**
 * Sous-tailles WebP au téléversement (CAP-15, AC 1 story 2.4) — levier WP
 * natif : le mapping `image_editor_output_format`
 * (`wp_get_image_editor_output_format()`) fait générer les tailles
 * intermédiaires en WebP, servies via srcset.
 *
 * Périmètre : JPEG UNIQUEMENT (le cas photo, le vrai gain). Vérifié sur le
 * WP réel : `imagewebp()` (GD) refuse les PNG palette — mapper les PNG
 * produirait un warning PHP à chaque téléversement de logo sur la flotte.
 * GIF (animations), HEIC→JPEG du cœur et images déjà téléversées ne sont
 * pas touchés (aucune régénération rétroactive).
 *
 * Sonde `null` documentée : FlyingPress ne convertit pas en WebP — aucun
 * équivalent à qui céder. Les convertisseurs dédiés (Imagify, EWWW)
 * relèvent du différé « politique multi-tiers » (revue 2.2).
 */
final class PerfWebpModule implements Module
{
    public function slug(): string
    {
        return 'perf_webp';
    }

    public function boot(): void
    {
        add_filter('image_editor_output_format', [$this, 'formatsDeSortie'], 10, 3);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return true;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }

    /**
     * Frontière de filtre public : TOUT paramètre est `mixed` — vérifié sur
     * le WP réel, le cœur passe `$fichier = null` sur certains chemins de
     * `_save()` ; un typehint strict fatalerait le téléversement.
     *
     * @return array<string, string>
     */
    public function formatsDeSortie(mixed $formats, mixed $fichier = null, mixed $mime = null): array
    {
        if (!is_array($formats)) {
            $formats = [];
        }

        /* Respect de l'amont (revue 2.4) : un convertisseur dédié qui a déjà
           mappé les JPEG (ex. → AVIF) garde son choix — le module ne comble
           que l'absence, il n'écrase personne (cohérent avec sa sonde null :
           « personne à qui céder » vaut aussi « personne à dominer »). */
        return $formats + ['image/jpeg' => 'image/webp'];
    }
}
