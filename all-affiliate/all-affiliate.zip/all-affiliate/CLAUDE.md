# Projet : [NOM_DU_PROJET]

> Remplace tous les [PLACEHOLDERS] avant de committer.
> Objectif : rester sous 150 lignes. Supprime les sections inutiles.

---

## Stack & Commandes
```bash
# [ADAPTER À TON STACK]
npm run dev        # Démarrer le serveur
npm run build      # Build de production
npm run test       # Lancer les tests
npm run lint       # Lint + formatage
```

---

## Architecture

- **Stack :** [ex. Laravel 11 + Vue 3]
- **Base de données :** [ex. MySQL via Eloquent]
- **Répertoires clés :**
  - `[dossier]` — [rôle]
  - `[dossier]` — [rôle]

---

## Conventions

- [ex. Toujours utiliser le logger custom, jamais console.log]
- [ex. Toutes les réponses API suivent le format { data, error }]

---

## Points d'attention

- [ex. Les tests utilisent une vraie DB locale — lancer `npm run db:reset` d'abord]
- [ex. Variables d'env requises : copier .env.example → .env]

---

## Règles projet

<important if="toujours">
- Branche de travail : `dev` — vérifier avec `git branch --show-current` avant tout commit
- Ne jamais committer directement sur `main` — c'est la production
</important>

---

## Documentation

- Architecture : @.claude/docs/STRUCTURE.md
- Contexte : @.claude/docs/CONTEXT.md
- Roadmap : @.claude/docs/ROADMAP.md
- Tâches en cours : @tasks/todo.md
- Leçons apprises : @tasks/lessons.md