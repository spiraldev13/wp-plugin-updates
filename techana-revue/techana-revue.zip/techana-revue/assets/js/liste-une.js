/**
 * Colonne « À la une » de la liste des articles : la case s'enregistre au clic.
 *
 * Délégation sur le tableau — la liste est re-rendue par la modification
 * rapide de WordPress, un écouteur par case ne survivrait pas au remplacement.
 */
( function ( reglages ) {
    'use strict';

    if ( ! reglages || ! reglages.url ) {
        return;
    }

    var ETAT_OK = '✓';
    var ETAT_KO = '!';

    function marquer( temoin, classe, texte, titre ) {
        if ( ! temoin ) {
            return;
        }
        temoin.className = 'techana-une-etat' + ( classe ? ' ' + classe : '' );
        temoin.textContent = texte;
        temoin.title = titre || '';
    }

    function enregistrer( _case ) {
        var temoin = _case.parentNode.querySelector( '.techana-une-etat' );
        var actif = _case.checked;
        var corps = new FormData();

        corps.append( 'action', reglages.action );
        corps.append( '_ajax_nonce', reglages.nonce );
        corps.append( 'post', _case.dataset.post );
        corps.append( 'actif', actif ? 'true' : 'false' );

        _case.disabled = true;
        marquer( temoin, '', '…' );

        window.fetch( reglages.url, {
            method: 'POST',
            credentials: 'same-origin',
            body: corps
        } ).then( function ( reponse ) {
            return reponse.json().then( function ( donnees ) {
                if ( ! reponse.ok || ! donnees.success ) {
                    throw new Error(
                        ( donnees.data && donnees.data.message ) || reglages.erreur
                    );
                }
                return donnees.data;
            } );
        } ).then( function () {
            marquer( temoin, 'ok', ETAT_OK );
        } ).catch( function ( erreur ) {
            // Rétablir la case : l'écran doit refléter la base, pas le clic.
            _case.checked = ! actif;
            marquer( temoin, 'ko', ETAT_KO, erreur.message || reglages.erreur );
        } ).then( function () {
            _case.disabled = false;
        } );
    }

    document.addEventListener( 'change', function ( evenement ) {
        var cible = evenement.target;
        if ( cible && cible.classList && cible.classList.contains( 'techana-une-case' ) ) {
            enregistrer( cible );
        }
    } );
}( window.techanaUne ) );
