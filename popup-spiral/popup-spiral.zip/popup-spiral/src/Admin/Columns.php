<?php

namespace Spiral\Admin;

use Spiral\Frontend;
use Spiral\PostTypes;
use Spiral\Settings;
use Spiral\Targeting;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Colonnes de la liste des popups : statistiques et réglages clés en un coup d'œil.
 */
final class Columns
{
    public static function register(): void
    {
        add_filter('manage_' . PostTypes::POPUP . '_posts_columns', [self::class, 'columns']);
        add_action('manage_' . PostTypes::POPUP . '_posts_custom_column', [self::class, 'renderColumn'], 10, 2);
    }

    /**
     * @param array $columns
     * @return array
     */
    public static function columns($columns)
    {
        $date = $columns['date'] ?? null;
        unset($columns['date']);

        $columns['spiral_enabled'] = __('Actif', 'popup-spiral');
        $columns['spiral_status'] = __('Statut', 'popup-spiral');
        $columns['spiral_design'] = __('Design', 'popup-spiral');
        $columns['spiral_schedule'] = __('Planification', 'popup-spiral');
        $columns['spiral_opens'] = __('Vues', 'popup-spiral');
        $columns['spiral_clicks'] = __('Clics', 'popup-spiral');

        if ($date !== null) {
            $columns['date'] = $date;
        }

        return $columns;
    }

    /**
     * @param string $column
     * @param int    $postId
     */
    public static function renderColumn($column, $postId): void
    {
        switch ($column) {
            case 'spiral_enabled':
                $isEnabled = get_post_meta($postId, 'spiral_enabled', true) !== '0';
                ?>
                <label class="spiral-switch" title="<?php esc_attr_e('Autorisation manuelle : activer / désactiver ce popup, indépendamment de la planification', 'popup-spiral'); ?>">
                    <input type="checkbox" class="spiral-toggle" data-id="<?php echo (int) $postId; ?>" <?php checked($isEnabled); ?> />
                    <span></span>
                </label>
                <?php
                break;

            case 'spiral_status':
                self::renderStatus((int) $postId);
                break;

            case 'spiral_opens':
                echo esc_html(number_format_i18n((int) get_post_meta($postId, 'spiral_open_count', true)));
                break;

            case 'spiral_clicks':
                echo esc_html(number_format_i18n((int) get_post_meta($postId, 'spiral_click_count', true)));
                break;

            case 'spiral_design':
                $settings = Settings::get((int) $postId);
                $design = \Spiral\Designs\Repository::get($settings['display']['design']);
                echo esc_html($design !== null ? $design['name'] : $settings['display']['design']);
                break;

            case 'spiral_schedule':
                self::renderScheduleBadge((int) $postId);
                break;
        }
    }

    /**
     * Statut d'affichage calculé (Visible / Masqué : raison) + résumé du ciblage.
     * Distinct du toggle « Actif » (autorisation manuelle) et du badge de
     * planification (timeline) : répond à « pourquoi ne s'affiche-t-il pas ? ».
     */
    private static function renderStatus(int $postId): void
    {
        $status = Frontend::displayStatus($postId);
        $settings = Settings::get($postId);

        $class = $status['can'] ? 'spiral-badge-active' : 'spiral-badge-off';
        $prefix = $status['can'] ? '' : __('Masqué : ', 'popup-spiral');

        echo '<span class="spiral-badge ' . esc_attr($class) . '">' . esc_html($prefix . $status['label']) . '</span>';
        echo '<span class="spiral-status-target">' . esc_html(Targeting::summary($settings['targeting'])) . '</span>';
    }

    private static function renderScheduleBadge(int $postId): void
    {
        $settings = Settings::get($postId);
        $schedule = $settings['schedule'];

        if ($schedule['start'] === '' && $schedule['end'] === '') {
            echo '<span class="spiral-badge">' . esc_html__('Permanent', 'popup-spiral') . '</span>';
            return;
        }

        if (\Spiral\Schedule::isActive($schedule)) {
            // Vert « en cours » uniquement si le popup est réellement affichable
            // (sinon le toggle OFF ou une autre cause le masque : badge neutre).
            $active = Frontend::displayStatus($postId)['can'];
            $class = $active ? 'spiral-badge spiral-badge-active' : 'spiral-badge';
            echo '<span class="' . esc_attr($class) . '">' . esc_html__('En cours', 'popup-spiral') . '</span>';
            self::renderScheduleDates($schedule);
            return;
        }

        $now = new \DateTimeImmutable('now', wp_timezone());
        $start = \Spiral\Schedule::parse($schedule['start']);

        if ($start instanceof \DateTimeImmutable && $now < $start) {
            echo '<span class="spiral-badge spiral-badge-planned">' . esc_html__('Programmé', 'popup-spiral') . '</span>';
        } else {
            echo '<span class="spiral-badge spiral-badge-expired">' . esc_html__('Expiré', 'popup-spiral') . '</span>';
        }

        self::renderScheduleDates($schedule);
    }

    /**
     * Jour et heure des bornes, sous le badge d'état.
     */
    private static function renderScheduleDates(array $schedule): void
    {
        $lines = [];
        $start = \Spiral\Schedule::parse($schedule['start']);
        $end = \Spiral\Schedule::parse($schedule['end']);

        if ($start !== null) {
            /* translators: %s : date et heure de début */
            $lines[] = sprintf(__('Du %s', 'popup-spiral'), wp_date('d/m/Y H:i', $start->getTimestamp()));
        }

        if ($end !== null) {
            /* translators: %s : date et heure de fin */
            $lines[] = sprintf(__('Au %s', 'popup-spiral'), wp_date('d/m/Y H:i', $end->getTimestamp()));
        }

        if ($lines !== []) {
            echo '<span class="spiral-schedule-dates">' . esc_html(implode(' — ', $lines)) . '</span>';
        }
    }
}
