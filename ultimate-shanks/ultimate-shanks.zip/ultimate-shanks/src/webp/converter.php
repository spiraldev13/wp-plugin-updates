<?php

/**
 * WebP - Moteur de conversion des attachements
 *
 * Convertit un JPEG/PNG de la médiathèque en WebP ou AVIF « en place » : même
 * attachment ID, fichier attaché remplacé, miniatures régénérées, URLs en dur
 * réécrites nom-par-nom dans post_content. L'original reste sur disque avec
 * une méta de liaison jusqu'à validation explicite (restauration possible) —
 * décisions D2, D3, D4 du design.
 *
 * Fichiers liés :
 * - src/webp/presets.php, src/webp/capabilities.php
 * - src/webp/panel.php (listes et actions AJAX)
 * - src/ai-images/generator.php (conversion à la volée via maybe_convert_tmp_file)
 *
 * @package UltimateShanks\Webp
 */

namespace UltimateShanks\Webp;

if (!defined('ABSPATH')) {
	exit;
}

class Converter
{
	const META_KEY = '_ultimate_shanks_webp_original';

	const AUTO_AI_OPTION = 'ultimate_shanks_webp_auto_ai_enabled';

	/**
	 * Convertit un attachement selon un preset. L'original est conservé.
	 *
	 * @param int    $attachment_id
	 * @param string $preset_id Vide = preset par défaut
	 * @return array|\WP_Error ['old_size','new_size','file']
	 */
	public static function convert_attachment($attachment_id, $preset_id = '')
	{
		$preset = $preset_id !== '' ? Presets::get($preset_id) : Presets::get_default();
		if ($preset === null) {
			return new \WP_Error('webp_no_preset', 'Preset de conversion introuvable.');
		}
		if (!Capabilities::supports($preset['format'])) {
			return new \WP_Error('webp_unsupported', sprintf('Le serveur ne sait pas encoder le format %s.', strtoupper($preset['format'])));
		}

		$check = self::check_convertible($attachment_id);
		if (is_wp_error($check)) {
			return $check;
		}

		$old_file = get_attached_file($attachment_id);
		$old_meta = wp_get_attachment_metadata($attachment_id);
		$old_mime = get_post_mime_type($attachment_id);
		$old_size = (int) filesize($old_file);
		$old_sizes_files = self::collect_size_files($old_file, $old_meta);

		$new_file = self::encode($old_file, $preset);
		if (is_wp_error($new_file)) {
			return $new_file;
		}

		update_attached_file($attachment_id, $new_file);
		wp_update_post(['ID' => $attachment_id, 'post_mime_type' => Capabilities::mime($preset['format'])]);
		$new_meta = wp_generate_attachment_metadata($attachment_id, $new_file);
		wp_update_attachment_metadata($attachment_id, $new_meta);

		$mapping = self::build_url_mapping($old_file, $old_meta, $new_file, $new_meta);
		self::rewrite_urls($mapping);

		update_post_meta($attachment_id, self::META_KEY, [
			'file'        => self::to_relative($old_file),
			'mime'        => $old_mime,
			'size'        => $old_size,
			'sizes_files' => array_map([self::class, 'to_relative'], $old_sizes_files),
			'mapping'     => $mapping,
			'preset'      => $preset['id'],
			'date'        => time(),
		]);

		return [
			'old_size' => $old_size,
			'new_size' => (int) filesize($new_file),
			'file'     => $new_file,
		];
	}

	/**
	 * Restaure une conversion non validée : l'original redevient le fichier
	 * attaché, les fichiers convertis sont supprimés, les URLs inversées
	 *
	 * @param int $attachment_id
	 * @return true|\WP_Error
	 */
	public static function restore_attachment($attachment_id)
	{
		$original = get_post_meta($attachment_id, self::META_KEY, true);
		if (!is_array($original) || empty($original['file'])) {
			return new \WP_Error('webp_no_pending', 'Aucune conversion en attente sur ce média.');
		}

		$original_file = self::to_absolute($original['file']);
		if (!file_exists($original_file)) {
			return new \WP_Error('webp_original_missing', 'Le fichier original a disparu du disque : restauration impossible.');
		}

		// Supprime le fichier converti et ses miniatures
		$converted_file = get_attached_file($attachment_id);
		$converted_meta = wp_get_attachment_metadata($attachment_id);
		foreach (array_merge([$converted_file], self::collect_size_files($converted_file, $converted_meta)) as $path) {
			if ($path && file_exists($path)) {
				@unlink($path);
			}
		}

		update_attached_file($attachment_id, $original_file);
		wp_update_post(['ID' => $attachment_id, 'post_mime_type' => $original['mime']]);
		$meta = wp_generate_attachment_metadata($attachment_id, $original_file);
		wp_update_attachment_metadata($attachment_id, $meta);

		self::rewrite_urls(array_flip((array) $original['mapping']));
		delete_post_meta($attachment_id, self::META_KEY);

		return true;
	}

	/**
	 * Supprime définitivement les fichiers originaux d'une conversion
	 * (validation) — action irréversible, réservée au panneau
	 *
	 * @param int $attachment_id
	 * @return true|\WP_Error
	 */
	public static function delete_originals($attachment_id)
	{
		$original = get_post_meta($attachment_id, self::META_KEY, true);
		if (!is_array($original) || empty($original['file'])) {
			return new \WP_Error('webp_no_pending', 'Aucune conversion en attente sur ce média.');
		}

		$paths = array_merge([$original['file']], (array) $original['sizes_files']);
		foreach ($paths as $relative) {
			$absolute = self::to_absolute($relative);
			if ($absolute && file_exists($absolute)) {
				@unlink($absolute);
			}
		}

		delete_post_meta($attachment_id, self::META_KEY);

		return true;
	}

	/**
	 * Conversion à la volée d'un fichier temporaire (images IA), selon le
	 * preset par défaut. En cas d'échec, le fichier d'origine est conservé :
	 * la génération n'est jamais perdue.
	 *
	 * @param string $path Fichier temporaire
	 * @param string $ext  Extension actuelle
	 * @return array ['path' => string, 'ext' => string]
	 */
	public static function maybe_convert_tmp_file($path, $ext)
	{
		if (get_option(self::AUTO_AI_OPTION, '0') !== '1') {
			return ['path' => $path, 'ext' => $ext];
		}

		$preset = Presets::get_default();
		if ($preset === null || !Capabilities::supports($preset['format'])) {
			return ['path' => $path, 'ext' => $ext];
		}

		$converted = self::encode($path, $preset);
		if (is_wp_error($converted)) {
			if (function_exists('error_log') && defined('WP_DEBUG') && WP_DEBUG) {
				error_log('[Ultimate Shanks WebP] Conversion à la volée en échec : ' . $converted->get_error_message());
			}

			return ['path' => $path, 'ext' => $ext];
		}

		@unlink($path);

		return ['path' => $converted, 'ext' => Capabilities::extension($preset['format'])];
	}

	/**
	 * Vérifie qu'un attachement est convertible (MIME source, fichier présent,
	 * pas de conversion déjà en attente)
	 *
	 * @param int $attachment_id
	 * @return true|\WP_Error
	 */
	public static function check_convertible($attachment_id)
	{
		$post = get_post($attachment_id);
		if (!$post || $post->post_type !== 'attachment') {
			return new \WP_Error('webp_no_attachment', 'Média introuvable.');
		}

		// Méta testée avant le MIME : un média déjà converti (MIME webp/avif)
		// doit être signalé « en attente », pas « type non convertible »
		if (get_post_meta($attachment_id, self::META_KEY, true)) {
			return new \WP_Error('webp_pending', 'Une conversion est déjà en attente de validation sur ce média.');
		}

		if (!in_array(get_post_mime_type($attachment_id), Capabilities::SOURCE_MIMES, true)) {
			return new \WP_Error('webp_bad_mime', 'Seuls les JPEG et PNG sont convertibles.');
		}

		$file = get_attached_file($attachment_id);
		if (!$file || !file_exists($file)) {
			return new \WP_Error('webp_file_missing', 'Le fichier du média est introuvable sur le disque.');
		}

		return true;
	}

	/**
	 * Encode un fichier vers le format du preset, dans le même dossier,
	 * sous un nom unique
	 *
	 * @param string $source_file
	 * @param array  $preset
	 * @return string|\WP_Error Chemin du fichier encodé
	 */
	private static function encode($source_file, $preset)
	{
		$editor = wp_get_image_editor($source_file);
		if (is_wp_error($editor)) {
			return new \WP_Error('webp_editor', 'Lecture de l\'image impossible : ' . $editor->get_error_message());
		}

		$editor->set_quality((int) $preset['quality']);

		$dir = dirname($source_file);
		$name = pathinfo($source_file, PATHINFO_FILENAME) . '.' . Capabilities::extension($preset['format']);
		$name = wp_unique_filename($dir, $name);

		$saved = $editor->save(trailingslashit($dir) . $name, Capabilities::mime($preset['format']));
		if (is_wp_error($saved)) {
			return new \WP_Error('webp_encode', 'Encodage impossible : ' . $saved->get_error_message());
		}

		return $saved['path'];
	}

	/**
	 * Chemins absolus des miniatures listées dans des métadonnées d'attachement
	 *
	 * @param string $main_file Fichier principal (pour le dossier)
	 * @param array  $meta      Métadonnées wp_get_attachment_metadata
	 * @return string[]
	 */
	private static function collect_size_files($main_file, $meta)
	{
		$files = [];
		$dir = trailingslashit(dirname($main_file));

		if (is_array($meta) && !empty($meta['sizes'])) {
			foreach ($meta['sizes'] as $size) {
				if (!empty($size['file'])) {
					$files[] = $dir . $size['file'];
				}
			}
		}

		return $files;
	}

	/**
	 * Mapping des noms de fichiers ancien → nouveau (fichier principal +
	 * tailles communes aux deux jeux de métadonnées)
	 *
	 * @param string $old_file
	 * @param array  $old_meta
	 * @param string $new_file
	 * @param array  $new_meta
	 * @return array old_basename => new_basename
	 */
	private static function build_url_mapping($old_file, $old_meta, $new_file, $new_meta)
	{
		$mapping = [wp_basename($old_file) => wp_basename($new_file)];

		$old_sizes = (is_array($old_meta) && !empty($old_meta['sizes'])) ? $old_meta['sizes'] : [];
		$new_sizes = (is_array($new_meta) && !empty($new_meta['sizes'])) ? $new_meta['sizes'] : [];

		foreach ($old_sizes as $size_name => $size) {
			if (!empty($size['file']) && !empty($new_sizes[$size_name]['file'])) {
				$mapping[$size['file']] = $new_sizes[$size_name]['file'];
			}
		}

		return $mapping;
	}

	/**
	 * Remplace chaque nom de fichier dans post_content (remplacement littéral,
	 * aucune regex — décision D3)
	 *
	 * @param array $mapping old => new
	 * @return void
	 */
	private static function rewrite_urls($mapping)
	{
		global $wpdb;

		foreach ($mapping as $old => $new) {
			if (!is_string($old) || !is_string($new) || $old === '' || $old === $new) {
				continue;
			}

			$like = '%' . $wpdb->esc_like($old) . '%';
			$ids = $wpdb->get_col($wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s",
				$like
			));
			if ($ids === []) {
				continue;
			}

			$wpdb->query($wpdb->prepare(
				"UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s)
					WHERE post_content LIKE %s",
				$old,
				$new,
				$like
			));

			// SQL direct : le cache objet des posts touchés doit être invalidé
			foreach ($ids as $id) {
				clean_post_cache((int) $id);
			}
		}
	}

	/**
	 * Chemin relatif au dossier uploads (portabilité des métas)
	 *
	 * @param string $absolute
	 * @return string
	 */
	private static function to_relative($absolute)
	{
		$basedir = trailingslashit(wp_get_upload_dir()['basedir']);

		return strpos($absolute, $basedir) === 0 ? substr($absolute, strlen($basedir)) : $absolute;
	}

	/**
	 * Chemin absolu depuis un chemin relatif au dossier uploads
	 *
	 * @param string $relative
	 * @return string
	 */
	private static function to_absolute($relative)
	{
		if (path_is_absolute($relative)) {
			return $relative;
		}

		return trailingslashit(wp_get_upload_dir()['basedir']) . $relative;
	}
}
