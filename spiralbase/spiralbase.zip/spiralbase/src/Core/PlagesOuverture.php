<?php

declare(strict_types=1);

namespace SpiralBase\Core;

/**
 * Analyse du format `openingHours` schema.org — JUGE UNIQUE des horaires du
 * projet (AD-2 : les modules partagent par le noyau, jamais entre eux).
 *
 * Vit dans le noyau, et non dans le module qui l'a fait naître (revue 3.1) :
 * le bloc horaires et le module `schema_metier` publient tous deux les
 * horaires du site ; en les filtrant différemment, ils ont réellement
 * publié deux vérités contradictoires — le visiteur lisait deux lignes,
 * Google en recevait quatre. Un seul juge, un seul verdict (leçon Epic 1 :
 * les référentiels dupliqués divergent).
 *
 * Classe pure : aucune écriture, aucun accès WordPress, testable seule.
 *
 * Conventions internes (figées ici, consommées par tous les rendus) :
 *  - jour 0 = lundi … 6 = dimanche (l'ordre d'affichage français) ;
 *  - une plage est [début, fin] en minutes depuis minuit du jour concerné ;
 *  - une fin > 1440 signale une plage qui traverse minuit (`Su 22:00-02:00`
 *    donne [1320, 1560]) — jamais un jour de plus dans la liste des jours ;
 *  - un segment de semaine est [début, fin[ en minutes depuis lundi 00:00,
 *    borne de fin EXCLUSIVE (à l'heure de fermeture pile, c'est fermé).
 *
 * Toute entrée illisible vaut `null` : l'appelant l'ignore et signale
 * (NFR13). Le parseur n'invente jamais d'horaire — une saisie douteuse ne
 * doit pas faire annoncer « ouvert » à un visiteur devant une porte close.
 * Mais il ne doit pas non plus être plus strict que nécessaire : refuser un
 * horaire fait disparaître une journée entière du site, et l'erreur
 * symétrique — annoncer « fermé » devant une boutique ouverte — coûte tout
 * aussi cher (revue 3.1, où elle s'est produite).
 */
final class PlagesOuverture
{
    public const JOUR = 1440;

    public const SEMAINE = 10080;

    /**
     * Une plage qui traverse minuit doit finir au petit matin ET rester de
     * durée plausible : sans ces bornes, `Mo 14:00-12:00` (transposition de
     * saisie) devenait 22 heures d'ouverture INVENTÉES (revue 3.1).
     */
    private const FIN_DE_NUIT = 360;

    private const DUREE_MAX = 720;

    /** Noms canoniques : la reconnaissance accepte le nom entier, ses 2 ou ses 3 premières lettres. */
    private const NOMS = [0 => 'monday', 1 => 'tuesday', 2 => 'wednesday', 3 => 'thursday', 4 => 'friday', 5 => 'saturday', 6 => 'sunday'];

    /**
     * @return array{jours: list<int>, plages: list<array{0: int, 1: int}>}|null
     */
    public static function analyserEntree(string $entree): ?array
    {
        $entree = self::normaliser($entree);

        if ($entree === '') {
            return null;
        }

        /* Frontière jours / heures : le PREMIER CHIFFRE. Un nom de jour n'en
           contient jamais, une heure commence toujours par là. Découper au
           premier ESPACE (première version) faisait tomber « Mo, Tu 09:00 »
           et « Mo-Fr 09:00-12:00 14:00-18:00 » — deux formes que l'humain
           tape naturellement et que la porte DonneesMetier accepte : le bloc
           perdait la journée sans que personne ne l'apprenne. */
        if (preg_match('/\d/', $entree, $trouve, PREG_OFFSET_CAPTURE) !== 1) {
            $jours = self::jours($entree);

            /* « Mo-Su » sans heures = ouvert toute la journée ces jours-là. */
            return $jours === null ? null : ['jours' => $jours, 'plages' => [[0, self::JOUR]]];
        }

        $position = (int) $trouve[0][1];
        $jours    = self::jours(substr($entree, 0, $position));

        if ($jours === null) {
            return null;
        }

        $plages = self::plages(substr($entree, $position));

        return $plages === null ? null : ['jours' => $jours, 'plages' => $plages];
    }

    /**
     * Segments de semaine de toutes les entrées analysées, dans l'ordre
     * d'apparition. Les entrées nulles (illisibles) sont ignorées.
     *
     * @param  list<array{jours: list<int>, plages: list<array{0: int, 1: int}>}|null> $analysees
     * @return list<array{0: int, 1: int}>
     */
    public static function segments(array $analysees): array
    {
        $segments = [];

        foreach ($analysees as $analysee) {
            if (!is_array($analysee) || !isset($analysee['jours'], $analysee['plages'])) {
                continue;
            }

            foreach ($analysee['jours'] as $jour) {
                foreach ($analysee['plages'] as [$debut, $fin]) {
                    $debutSemaine = $jour * self::JOUR + $debut;
                    $finSemaine   = $jour * self::JOUR + $fin;

                    if ($finSemaine <= self::SEMAINE) {
                        $segments[] = [$debutSemaine, $finSemaine];

                        continue;
                    }

                    /* Dimanche soir déborde sur lundi matin : deux segments,
                       sinon la nuit du dimanche serait perdue. */
                    $segments[] = [$debutSemaine, self::SEMAINE];
                    $segments[] = [0, $finSemaine - self::SEMAINE];
                }
            }
        }

        return $segments;
    }

    /**
     * @param list<array{0: int, 1: int}> $segments
     * @param int                         $minuteSemaine minutes depuis lundi 00:00, dans le fuseau du site
     */
    public static function estOuvert(array $segments, int $minuteSemaine): bool
    {
        foreach ($segments as [$debut, $fin]) {
            if ($minuteSemaine >= $debut && $minuteSemaine < $fin) {
                return true;
            }
        }

        return false;
    }

    /**
     * Espaces (y compris insécables) réduits, tirets typographiques ramenés
     * au tiret ASCII : une saisie passée par un traitement de texte ne doit
     * pas rendre les horaires illisibles (leçon 2.6-2.8 sur les frontières
     * de texte).
     */
    private static function normaliser(string $entree): string
    {
        $entree = str_replace(["\u{2010}", "\u{2011}", "\u{2012}", "\u{2013}", "\u{2014}", "\u{2212}"], '-', $entree);
        $entree = preg_replace('/[\s\x{00A0}\x{202F}]+/u', ' ', $entree);

        return trim((string) $entree);
    }

    /**
     * Découpe une liste sur ses virgules en tolérant les séparateurs
     * surnuméraires : espace autour d'une virgule ou d'un tiret, espace
     * SEUL comme séparateur (`Mo Tu`, `09:00-12:00 14:00-18:00`), virgule
     * finale. Aucune de ces formes ne change le sens — les refuser faisait
     * disparaître la journée du site.
     *
     * @return list<string>
     */
    private static function decouper(string $expression): array
    {
        $expression = preg_replace('/\s*([-,])\s*/', '$1', trim($expression)) ?? '';
        $expression = preg_replace('/\s+/', ',', $expression) ?? '';
        $expression = trim((string) preg_replace('/,+/', ',', $expression), ',');

        return $expression === '' ? [] : explode(',', $expression);
    }

    /** @return list<int>|null jours distincts, dans l'ordre de saisie */
    private static function jours(string $expression): ?array
    {
        $parties = self::decouper($expression);

        if ($parties === []) {
            return null;
        }

        $jours = [];

        foreach ($parties as $partie) {
            if (!str_contains($partie, '-')) {
                $jour = self::jour($partie);

                if ($jour === null) {
                    return null;
                }

                $jours[] = $jour;

                continue;
            }

            $bornes = explode('-', $partie);

            if (count($bornes) !== 2) {
                return null;
            }

            $depuis = self::jour($bornes[0]);
            $vers   = self::jour($bornes[1]);

            if ($depuis === null || $vers === null) {
                return null;
            }

            /* `Fr-Mo` enjambe la fin de semaine : on tourne, jamais plus d'un
               tour (la garde rend la boucle mécaniquement finie). */
            for ($jour = $depuis, $tours = 0; $tours <= 7; $jour = ($jour + 1) % 7, $tours++) {
                $jours[] = $jour;

                if ($jour === $vers) {
                    break;
                }
            }
        }

        return array_values(array_unique($jours));
    }

    private static function jour(string $jeton): ?int
    {
        $jeton = strtolower(trim($jeton));

        if (strlen($jeton) < 2) {
            return null;
        }

        foreach (self::NOMS as $index => $nom) {
            if ($jeton === $nom || $jeton === substr($nom, 0, 2) || $jeton === substr($nom, 0, 3)) {
                return $index;
            }
        }

        return null;
    }

    /** @return list<array{0: int, 1: int}>|null */
    private static function plages(string $expression): ?array
    {
        $parties = self::decouper($expression);
        $plages  = [];

        foreach ($parties as $partie) {
            if (preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?-(\d{1,2}):(\d{2})(?::\d{2})?$/', $partie, $capture) !== 1) {
                return null;
            }

            [, $heureDebut, $minuteDebut, $heureFin, $minuteFin] = array_map('intval', $capture);

            if ($minuteDebut > 59 || $minuteFin > 59 || $heureDebut > 23 || $heureFin > 24) {
                return null;
            }

            $debut = $heureDebut * 60 + $minuteDebut;
            $fin   = $heureFin * 60 + $minuteFin;

            if ($fin > self::JOUR || $debut === $fin) {
                return null;
            }

            if ($fin < $debut) {
                /* Fin avant le début : soit la plage passe minuit (bar,
                   boulangerie), soit l'opérateur a transposé ses heures. On
                   ne tranche en faveur de la nuit que lorsque c'en est
                   vraisemblablement une — sinon on refuse plutôt qu'inventer. */
                if ($fin > self::FIN_DE_NUIT || $fin + self::JOUR - $debut > self::DUREE_MAX) {
                    return null;
                }

                $fin += self::JOUR;
            }

            $plages[] = [$debut, $fin];
        }

        return $plages === [] ? null : $plages;
    }
}
