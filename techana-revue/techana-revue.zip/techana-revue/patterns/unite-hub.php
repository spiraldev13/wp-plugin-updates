<?php
/**
 * Title: Unité article — hub
 * Slug: techana-revue/unite-hub
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Liste des hubs de rubrique — vignette 1:1, titre, extrait, signature complète avec temps de lecture.
 * Viewport Width: 640
 */
?>
<!-- wp:group {"className":"u-hub"} -->
<div class="wp-block-group u-hub"><!-- wp:post-featured-image {"sizeSlug":"techana-1-1","className":"ph-auto square"} /-->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:post-excerpt {"excerptLength":40} /-->

<!-- wp:paragraph {"className":"meta","metadata":{"bindings":{"content":{"source":"techana/meta-hub"}}}} -->
<p class="meta"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
