/**
 * Bloc spiralbase/carrousel — JS éditeur écrit à la main, SANS build (AD-12).
 *
 * `save()` rend `InnerBlocks.Content` : un bloc à enfants dont le save rend
 * null ne sérialise pas ses éléments — ils disparaîtraient du contenu à
 * l'enregistrement (clause AD-12 établie en 3.2).
 *
 * L'édition est directe : les éléments s'empilent verticalement dans
 * l'éditeur plutôt que de défiler. C'est délibéré — on manipule mal un bloc
 * qui glisse sous le curseur, et la mise en forme réelle se vérifie d'un
 * coup d'œil au front.
 */
( function ( blocks, element, blockEditor, components, i18n ) {
    'use strict';

    var e = element.createElement;
    var __ = i18n.__;

    var VARIANTES = [
        { value: 'cartes', label: __( 'Cartes — plusieurs éléments visibles', 'spiralbase' ) },
        { value: 'pleine-largeur', label: __( 'Plein écran — un élément à la fois', 'spiralbase' ) },
        { value: 'logos', label: __( 'Bandeau de logos', 'spiralbase' ) },
    ];

    blocks.registerBlockType( 'spiralbase/carrousel', {
        edit: function ( props ) {
            var variante = props.attributes.variante || 'cartes';

            var blockProps = blockEditor.useBlockProps( {
                className: 'spiralbase-carrousel-edition spiralbase-carrousel--' + variante,
            } );

            var innerProps = blockEditor.useInnerBlocksProps( blockProps, {
                template: [ [ 'core/image' ], [ 'core/image' ] ],
            } );

            return e(
                element.Fragment,
                null,
                e(
                    blockEditor.InspectorControls,
                    null,
                    e(
                        components.PanelBody,
                        { title: __( 'Réglages du carrousel', 'spiralbase' ) },
                        e( components.SelectControl, {
                            label: __( 'Présentation', 'spiralbase' ),
                            value: variante,
                            options: VARIANTES,
                            help: __(
                                'Change la présentation seule : les éléments du carrousel sont conservés.',
                                'spiralbase'
                            ),
                            onChange: function ( valeur ) {
                                props.setAttributes( { variante: valeur } );
                            },
                        } ),
                        e( components.TextControl, {
                            label: __( 'Nom du carrousel', 'spiralbase' ),
                            help: __(
                                'Annoncé aux lecteurs d’écran : « Nos réalisations », « Ils nous font confiance »…',
                                'spiralbase'
                            ),
                            value: props.attributes.libelle,
                            onChange: function ( valeur ) {
                                props.setAttributes( { libelle: valeur } );
                            },
                        } )
                    )
                ),
                e( 'div', innerProps )
            );
        },
        save: function () {
            return e( blockEditor.InnerBlocks.Content );
        },
    } );
} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.blockEditor,
    window.wp.components,
    window.wp.i18n
);
