<?php

/**
 * Détecte si le serveur de développement Vite est actif.
 *
 * Le résultat (URL ou « pas de dev server ») est mis en cache via un
 * transient WordPress pour éviter un appel HTTP bloquant à chaque
 * chargement de page (cause de FOUC : la page attendait jusqu'à 500 ms
 * que la sonde timeoute avant d'enqueue le CSS).
 *
 * Pour rafraîchir la détection (ex. après avoir démarré ou arrêté
 * `npm run dev`) : supprimer le transient `theme_vite_dev_origin` ou
 * appeler `delete_transient('theme_vite_dev_origin')`. Le TTL est
 * volontairement court (60 s) pour rester confortable côté dev.
 */
function theme_get_vite_dev_origin(): ?string
{
	static $cached_origin = null;

	if ($cached_origin !== null) {
		return $cached_origin === false ? null : $cached_origin;
	}

	// Bypass explicite : `define('EVOLUTIONR_DISABLE_VITE_PROBE', true);`
	// dans wp-config.php pour les serveurs de production où on est certain
	// que Vite ne tourne jamais. Pas de bypass automatique basé sur
	// `wp_get_environment_type()` : la valeur par défaut est 'production',
	// ce qui empêcherait le HMR en dev local non configuré.
	if (defined('EVOLUTIONR_DISABLE_VITE_PROBE') && EVOLUTIONR_DISABLE_VITE_PROBE) {
		$cached_origin = false;
		return null;
	}

	// Cache inter-requêtes (60 s) : la sonde ne tourne qu'une fois par
	// minute au maximum, le reste du temps la réponse est instantanée.
	$cached = get_transient('theme_vite_dev_origin');
	if ($cached !== false) {
		$cached_origin = ($cached === 'none') ? false : $cached;
		return $cached_origin === false ? null : $cached_origin;
	}

	$port = getenv('VITE_DEV_PORT') ?: '5173';
	$origins = [
		sprintf('http://localhost:%s', $port),
		sprintf('http://127.0.0.1:%s', $port),
	];

	foreach ($origins as $origin) {
		$response = @wp_remote_get(
			$origin . '/app/main.js',
			[
				'timeout'   => 0.1, // Le dev server local répond en quelques ms.
				'headers'   => ['Accept' => 'text/javascript'],
				'sslverify' => false,
			]
		);

		if (!is_wp_error($response)) {
			$status = wp_remote_retrieve_response_code($response);
			if ($status >= 200 && $status < 300) {
				$cached_origin = $origin;
				set_transient('theme_vite_dev_origin', $origin, 60);
				return $cached_origin;
			}
		}
	}

	$cached_origin = false;
	set_transient('theme_vite_dev_origin', 'none', 60);
	return null;
}

/**
 * Charge les assets en mode production depuis le manifest
 */
function theme_enqueue_vite_prod_assets(string $entry): void
{
	$possible_manifests = [
		get_template_directory() . '/dist/manifest.json',
		get_template_directory() . '/dist/.vite/manifest.json', // Vite 5+ default
	];

	$manifest_path = null;

	foreach ($possible_manifests as $path) {
		if (file_exists($path)) {
			$manifest_path = $path;
			break;
		}
	}

	if (!$manifest_path) {
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log('❌ Vite manifest introuvable dans dist/.');
		}
		return;
	}

	$manifest = json_decode(file_get_contents($manifest_path), true);

	if (!isset($manifest[$entry])) {
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log('❌ Entrée "' . $entry . '" non trouvée dans manifest.json');
		}
		return;
	}

	$asset = $manifest[$entry];
	$theme_uri = get_template_directory_uri();
	$handle = 'theme-' . basename($entry, '.js');

	// Charge le CSS si présent
	if (!empty($asset['css']) && is_array($asset['css'])) {
		foreach ($asset['css'] as $i => $css) {
			wp_enqueue_style(
				$handle . '-style-' . $i,
				$theme_uri . '/dist/' . $css,
				[],
				null
			);
		}
	}

	// Charge le JavaScript
	wp_enqueue_script(
		$handle,
		$theme_uri . '/dist/' . $asset['file'],
		[],
		null,
		true
	);
}

/**
 * Charge les assets Vite (dev ou prod selon disponibilité du serveur)
 */
function theme_enqueue_vite_assets(string $entry = 'app/main.js'): void
{
	$dev_origin = theme_get_vite_dev_origin();
	// Handle unique par entry — sinon le 2e appel (ex. configurateur.js)
	// est silencieusement ignoré par WordPress car `theme-main` est déjà
	// enqueue. Aligne le mode dev sur le mode prod (`theme-<basename>`).
	$handle = 'theme-' . basename($entry, '.js');

	if ($dev_origin) {
		// ✅ Mode développement
		wp_enqueue_script('vite-client', $dev_origin . '/@vite/client', [], null, false);
		wp_enqueue_script($handle, $dev_origin . '/' . $entry, ['vite-client'], null, false);
	} else {
		// 🏁 Mode production
		theme_enqueue_vite_prod_assets($entry);
	}
}

add_action('wp_enqueue_scripts', function () {
	// Charge l'entrée principale (main.js + main.css) sur toutes les pages
	theme_enqueue_vite_assets('app/main.js');

	// Configurateur tarifs : chargé uniquement sur /tarifs/
	// (cf. change lancement-site-evolutionr capability configurateur-tarifs).
	if (is_page('tarifs')) {
		theme_enqueue_vite_assets('app/configurateur.js');
	}
});

/**
 * Ajoute type="module" aux scripts Vite
 */
function theme_add_module_type($tag, $handle, $src): string
{
	if (strpos($handle, 'vite-client') !== false || strpos($handle, 'theme-') === 0) {
		return str_replace('<script ', ' <script type="module" ', $tag);
	}
	return $tag;
}
add_filter('script_loader_tag', 'theme_add_module_type', 10, 3);
