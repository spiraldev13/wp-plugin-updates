<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocEncartEvenement;

use SpiralBase\Core\EnveloppeBloc;
use SpiralBase\Core\Signal;
use SpiralBase\Core\TexteRiche;

/**
 * Rendu serveur du bloc `spiralbase/encart-evenement` (story 3.6).
 *
 * Le serveur est SEUL juge de l'expiration : un encart périmé ne rend rien du
 * tout — ni conteneur masqué en CSS, ni contenu envoyé puis caché par un
 * script. Un « Menu de Noël » ne doit pas rester lisible dans la source d'une
 * page en février.
 *
 * Le sens des défaillances est inversé par rapport aux horaires (3.1) : là-bas
 * une entrée illisible est ignorée, ici l'ignorer signifierait SUPPRIMER du
 * contenu client. Toute incertitude — date incomprise, horloge en panne —
 * laisse donc l'encart VISIBLE, et le signale.
 */
final class RenduEncart
{
    /** @var \Closure(): \DateTimeImmutable */
    private \Closure $maintenant;

    public function __construct(?\Closure $maintenant = null)
    {
        $this->maintenant = $maintenant ?? static fn (): \DateTimeImmutable => current_datetime();
    }

    /** @param array<string, mixed> $attributs */
    public function rendre(array $attributs, string $contenu = '', mixed $bloc = null): string
    {
        try {
            return $this->composer($attributs, $contenu);
        } catch (\Throwable $e) {
            Signal::emettre('spiralbase_bloc_encart_echec', 'rendu interrompu : ' . $e->getMessage(), 'bloc encart');

            /*
             * Le filet rend le contenu, JAMAIS le vide — c'est le seul bloc du
             * parent où échouer en effaçant serait pire qu'échouer en
             * affichant. Prouvé en revue : une heure hors bornes faisait lever
             * la construction de date, l'exception remontait jusqu'ici, et un
             * encart parfaitement valide disparaissait du site en silence.
             * Le contenu arrive déjà rendu par le cœur : le sortir tel quel
             * est sûr, seule l'enveloppe du bloc est perdue.
             */
            return $contenu;
        }
    }

    /** @param array<string, mixed> $attributs */
    private function composer(array $attributs, string $contenu): string
    {
        if ($this->sansAucunElement($contenu)) {
            return '';
        }

        if ($this->estPerime($attributs['expiration'] ?? null)) {
            return '';
        }

        return '<aside ' . EnveloppeBloc::attributs('spiralbase-encart-evenement') . '>'
            . $contenu
            . '</aside>';
    }

    /**
     * Verdict d'expiration — `false` chaque fois qu'un doute subsiste.
     *
     * Aucune date, date illisible, horloge en panne : l'encart reste. Seule
     * une comparaison réussie entre deux instants connus peut le faire
     * disparaître.
     */
    private function estPerime(mixed $expiration): bool
    {
        /* Une valeur réduite à des blancs est un champ vide, pas une saisie
           incomprise : la signaler à chaque affichage de la page noierait les
           vraies erreurs. */
        if ($expiration === null || (is_string($expiration) && trim($expiration) === '')) {
            return false;
        }

        try {
            $maintenant = ($this->maintenant)();
        } catch (\Throwable $e) {
            Signal::emettre(
                'spiralbase_bloc_encart_echec',
                'horloge du site illisible, encart conservé : ' . $e->getMessage(),
                'bloc encart'
            );

            return false;
        }

        $limite = $this->limite($expiration, $maintenant->getTimezone());

        if ($limite === null) {
            Signal::emettre(
                'spiralbase_bloc_encart_date_illisible',
                sprintf(
                    'date de péremption « %s » illisible, encart conservé',
                    /* Borné : un attribut est une chaîne libre, et un journal
                       n'a pas à recopier 100 000 caractères collés par erreur. */
                    mb_substr(
                        is_int($expiration) || is_float($expiration) || is_string($expiration)
                            ? (string) $expiration
                            : get_debug_type($expiration),
                        0,
                        40
                    )
                ),
                'bloc encart'
            );

            return false;
        }

        /* `>=` et non `>` : la limite est le PREMIER instant où l'encart n'est
           plus affiché, jamais le dernier où il l'est encore. Avec `>`, une
           horloge à microsecondes (`current_datetime()` en porte) faisait
           basculer l'encart dès la première microseconde de sa dernière
           seconde d'affichage. */
        return $maintenant >= $limite;
    }

    /**
     * PREMIER instant où l'encart n'est plus affiché, au fuseau du SITE.
     *
     * Une date nue n'est pas un instant : « 2026-07-30 » lue en UTC éteindrait
     * l'encart deux heures trop tôt sur un site à Paris. Et une date sans
     * heure vaut jusqu'à la FIN de ce jour — l'opérateur qui saisit le jour de
     * son événement veut le voir affiché ce jour-là. La borne est donc MINUIT
     * DU LENDEMAIN, pas `23:59:59` : cette dernière laissait tomber la
     * dernière seconde du jour, et surtout elle est AMBIGUË dans les fuseaux
     * dont le retour à l'heure d'hiver se fait à minuit (`America/Santiago`,
     * `America/Havana`, `Asia/Beirut`), où la plage 23 h existe deux fois —
     * l'encart s'y éteignait une heure trop tôt, une nuit par an. Minuit du
     * lendemain n'est jamais ambigu.
     *
     * Rend `null` — verdict « illisible », donc encart CONSERVÉ — pour toute
     * valeur qu'on ne sait pas lire avec certitude.
     */
    private function limite(mixed $expiration, \DateTimeZone $fuseau): ?\DateTimeImmutable
    {
        if (!is_string($expiration)) {
            return null;
        }

        $brut = trim($expiration);

        /* Vocabulaire fermé : le champ d'éditeur est un sélecteur de date, il
           produit `AAAA-MM-JJ` ou `AAAA-MM-JJTHH:MM:SS`. Accepter « demain »
           ou « 30/07/2026 » via `strtotime` inviterait des lectures ambiguës
           (mm/jj vs jj/mm) à décider de la disparition d'un contenu. */
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?$/', $brut, $m) !== 1) {
            return null;
        }

        if (!checkdate((int) $m[2], (int) $m[3], (int) $m[1])) {
            return null;
        }

        /* L'éditeur (JavaScript) refuse les années à moins de quatre chiffres
           significatifs — le constructeur `Date` y lit 1900+n. Le serveur s'en
           tient à la même borne, sans quoi les deux juges rendraient des
           verdicts opposés sur la même saisie. */
        if ((int) $m[1] < 1000) {
            return null;
        }

        $jour = $m[1] . '-' . $m[2] . '-' . $m[3];

        if (!isset($m[4])) {
            /* Date nue : minuit du lendemain, obtenu par `modify` pour ne pas
               réinventer le calendrier (fins de mois, bissextiles). */
            return (new \DateTimeImmutable($jour . ' 00:00:00', $fuseau))->modify('+1 day') ?: null;
        }

        [$heures, $minutes, $secondes] = [(int) $m[4], (int) $m[5], (int) ($m[6] ?? 0)];

        /*
         * Bornes NUMÉRIQUES. Une comparaison de chaînes (`'10:60:00' >
         * '23:59:59'`) est fausse dès que le premier caractère diffère : elle
         * laissait passer `10:60`, `22:75` et `09:00:99` — 148 121 chaînes au
         * total — jusqu'à une construction de date qui levait, dont
         * l'exception faisait DISPARAÎTRE un encart valide (revue 3.6).
         */
        if ($heures > 23 || $minutes > 59 || $secondes > 59) {
            return null;
        }

        try {
            return new \DateTimeImmutable(
                sprintf('%s %02d:%02d:%02d', $jour, $heures, $minutes, $secondes),
                $fuseau
            );
        } catch (\Throwable $e) {
            /* Ceinture : aucune valeur connue n'atteint ce point, mais la
               décision « illisible ⇒ conservé » doit être prise ICI, jamais
               par un filet plus haut qui, lui, ne sait pas de quoi il hérite. */
            return null;
        }
    }

    /**
     * « Aucun élément » n'est pas « aucun texte » (juge établi en revue 3.5) :
     * un encart réduit à une image n'a pas un caractère de texte et n'est pas
     * vide pour autant.
     */
    private function sansAucunElement(string $contenu): bool
    {
        $utile = preg_replace('/<!--.*?-->/s', '', $contenu) ?? $contenu;

        if (preg_match('/<[a-z!\/]/i', $utile) === 1) {
            return false;
        }

        return TexteRiche::estVide($utile);
    }
}
