<?php
/**
 * Habillage du corps d'article au rendu — composants du template
 * design/article-dmz-vlan.html : tableau sous .table-scroll avec indice de
 * défilement, bloc de code sous .codeblock (barre de langue + bouton Copier),
 * section « En bref » (.tldr) détectée dans le contenu.
 *
 * Tout se joue au rendu : la base n'est jamais réécrite, les 303 contenus
 * existants comme les futurs sont habillés d'office, et tout est réversible.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'render_block_core/table', 'techanaRevueHabilleTableau', 10, 2 );
add_filter( 'render_block_core/code', 'techanaRevueHabilleCode', 10, 2 );
// Priorité 12 : après do_blocks (9) — la détection lit du HTML rendu, sans
// commentaires de blocs — et avant l'insertion d'encart (20). Le h2 remplacé
// perd l'id posé par les ancres (8) et sort du sommaire.
add_filter( 'the_content', 'techanaRevueEnBrefDansCorps', 12 );
// Priorité 11 : après do_blocks (9) et wpautop (10), sur le HTML final.
add_filter( 'the_content', 'techanaRevueClasseListesBrutes', 11 );

/**
 * Tableau : la figure du bloc devient elle-même le conteneur défilant
 * (.table-scroll : bordure + overflow-x), suivie de l'indice de défilement —
 * masqué par le CSS aux paliers larges, il ne parle qu'aux écrans étroits.
 * Envelopper la figure au lieu de la classer poserait sa marge .prose figure
 * à l'intérieur du cadre.
 */
function techanaRevueHabilleTableau( string $rendu, array $bloc ): string {
    if ( ! str_contains( $rendu, '<table' ) ) {
        return $rendu;
    }
    $balises = new WP_HTML_Tag_Processor( $rendu );
    if ( ! $balises->next_tag( 'figure' ) ) {
        return $rendu;
    }
    $balises->add_class( 'table-scroll' );
    return $balises->get_updated_html()
        . '<p class="scroll-hint">&#8596; Faites défiler le tableau horizontalement</p>';
}

/**
 * Bloc de code : structure .codeblock du template — barre avec libellé de
 * langue (classe language-* si l'éditeur en pose une, « code » sinon) et
 * bouton Copier, branché par le gestionnaire déjà présent dans techana.js.
 * Le <pre class="wp-block-code"> du bloc est conservé tel quel.
 */
function techanaRevueHabilleCode( string $rendu, array $bloc ): string {
    $langue = 'code';
    if ( preg_match( '~language-([a-z0-9+#-]+)~i', $bloc['attrs']['className'] ?? '', $m ) ) {
        $langue = $m[1];
    }
    return '<div class="codeblock"><div class="bar"><span class="lang">' . esc_html( $langue )
        . '</span><button class="copy" type="button">Copier</button></div>' . $rendu . '</div>';
}

/**
 * Listes brutes : les styles de liste vivent dans theme.json, sur le bloc
 * `core/list` (`.wp-block-list`). Le bloc pose lui-même cette classe sur sa
 * balise externe, jamais sur une sous-liste écrite en HTML (ancien format du
 * bloc) ni sur une liste collée dans un bloc HTML. Ces listes-là reçoivent la
 * classe au rendu, comme le bloc l'aurait fait : même apparence, sans une
 * seconde règle CSS à tenir en phase.
 */
function techanaRevueClasseListesBrutes( string $contenu ): string {
    if ( ! preg_match( '/<[uo]l\b/i', $contenu ) ) {
        return $contenu;
    }
    $balises = new WP_HTML_Tag_Processor( $contenu );
    while ( $balises->next_tag() ) {
        if ( in_array( $balises->get_tag(), array( 'UL', 'OL' ), true )
            && ! $balises->has_class( 'wp-block-list' ) ) {
            $balises->add_class( 'wp-block-list' );
        }
    }
    return $balises->get_updated_html();
}

/**
 * « En bref » détecté dans le corps : un h2/h3 récapitulatif (« En bref »,
 * « Ce qu'il faut retenir »…) immédiatement suivi d'une liste devient la
 * section .tldr du template, titre normalisé. Le h2 remplacé n'a plus d'id :
 * il n'entre ni dans le sommaire ni dans le compteur de sections.
 *
 * La méta _techana_en_bref reste la voie canonique : quand elle est remplie,
 * le bloc techana/en-bref rend déjà la boîte en tête d'article et la
 * détection s'efface — jamais deux « En bref » sur la même page.
 */
function techanaRevueEnBrefDansCorps( string $contenu ): string {
    $points = get_post_meta( get_the_ID(), '_techana_en_bref', true );
    if ( is_array( $points ) && array_filter( $points ) ) {
        return $contenu;
    }

    $candidats = array();
    if ( preg_match_all( '~<h([23])\b[^>]*>(.*?)</h\1>~is', $contenu, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
        foreach ( $m as $titre ) {
            if ( techanaRevueEstTitreEnBref( $titre[2][0] ) ) {
                $candidats[] = $titre[0];
            }
        }
    }
    // Étiquette en paragraphe — la forme la plus répandue dans les contenus
    // générés (120 articles) : <p><strong>En bref 🔍</strong></p> juste avant
    // la liste. Une étiquette est courte (40 caractères au plus dans le
    // corpus) ; les vraies phrases « En résumé, … » devant une liste dépassent
    // toutes 180 — au-delà du seuil, transformer perdrait du texte.
    if ( preg_match_all( '~<p\b[^>]*>(.*?)</p>~is', $contenu, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
        foreach ( $m as $para ) {
            if ( mb_strlen( trim( wp_strip_all_tags( $para[1][0] ) ) ) <= 60
                && techanaRevueEstTitreEnBref( $para[1][0] ) ) {
                $candidats[] = $para[0];
            }
        }
    }
    if ( ! $candidats ) {
        return $contenu;
    }

    // Offsets décroissants : les remplacements ne décalent pas les suivants.
    usort( $candidats, static fn( array $a, array $b ): int => $b[1] <=> $a[1] );
    foreach ( $candidats as $candidat ) {
        $apresTitre = $candidat[1] + strlen( $candidat[0] );
        $finListe   = techanaRevueFinListe( $contenu, $apresTitre );
        if ( null === $finListe ) {
            continue;
        }
        $liste   = substr( $contenu, $apresTitre, $finListe - $apresTitre );
        $contenu = substr( $contenu, 0, $candidat[1] )
            . '<section class="tldr"><h2>En bref</h2>' . trim( $liste ) . '</section>'
            . substr( $contenu, $finListe );
    }
    return $contenu;
}

/**
 * Un intertitre est récapitulatif quand son texte — émojis et ponctuation de
 * tête retirés — COMMENCE par un des libellés recensés dans les articles.
 * « Bonnes pratiques à retenir » ou « Les compétences essentielles » sont des
 * sections ordinaires : le libellé au milieu du titre ne compte pas.
 */
function techanaRevueEstTitreEnBref( string $titre ): bool {
    $texte = html_entity_decode( wp_strip_all_tags( $titre ), ENT_QUOTES | ENT_HTML5 );
    $texte = str_replace( array( '’', '‘' ), "'", $texte );
    $texte = (string) preg_replace( '~^[^\p{L}]+~u', '', $texte );
    $texte = mb_strtolower( trim( $texte ) );
    return (bool) preg_match(
        "~^(en bref|en résumé|ce qu'il faut retenir|à retenir|l'essentiel à retenir)~u",
        $texte
    );
}

/**
 * Position après la fermeture de la liste qui suit immédiatement $depuis
 * (blancs admis), imbrications comprises — null si autre chose s'intercale.
 * Couper à la première fermeture, comme le font les regex paresseuses,
 * amputerait une liste à sous-listes.
 */
function techanaRevueFinListe( string $html, int $depuis ): ?int {
    if ( ! preg_match( '~\G\s*<(?:ul|ol)\b~iA', $html, $ouverture, 0, $depuis ) ) {
        return null;
    }
    if ( ! preg_match_all( '~</?(?:ul|ol)\b~i', $html, $balises, PREG_OFFSET_CAPTURE, $depuis ) ) {
        return null;
    }
    $profondeur = 0;
    foreach ( $balises[0] as $balise ) {
        $profondeur += str_starts_with( $balise[0], '</' ) ? -1 : 1;
        if ( 0 === $profondeur ) {
            $fin = strpos( $html, '>', $balise[1] );
            return false === $fin ? null : $fin + 1;
        }
    }
    return null;
}
