<?php
/**
 * Diagnostics en lecture seule pour l'écran Outils > Santé du site.
 *
 * @package UltimateShanks\Admin
 */

namespace UltimateShanks\Admin;

if (!defined('ABSPATH')) {
	exit;
}

class SiteHealth
{
	public static function init()
	{
		add_filter('site_status_tests', [self::class, 'register_tests']);
	}

	public static function register_tests($tests)
	{
		$tests['direct']['ultimate_shanks_css'] = [
			'label' => 'Ultimate Shanks : CSS généré',
			'test'  => [self::class, 'test_generated_css'],
		];
		$tests['direct']['ultimate_shanks_manifest'] = [
			'label' => 'Ultimate Shanks : manifeste de mise à jour',
			'test'  => [self::class, 'test_update_manifest'],
		];
		$tests['direct']['ultimate_shanks_integrations'] = [
			'label' => 'Ultimate Shanks : intégrations',
			'test'  => [self::class, 'test_integrations'],
		];
		$tests['direct']['ultimate_shanks_ai_images'] = [
			'label' => 'Ultimate Shanks : images IA',
			'test'  => [self::class, 'test_ai_images'],
		];

		return $tests;
	}

	public static function test_generated_css()
	{
		$css_file = \UltimateShanks\Style\CSSGenerator::get_css_file_path();
		$updated_at = (int) get_option('ultimate_shanks_style_updated_at', 0);
		$is_current = file_exists($css_file) && (int) filemtime($css_file) >= $updated_at;

		return self::result(
			'css',
			$is_current ? 'good' : 'recommended',
			$is_current ? 'Le CSS généré est disponible et à jour' : 'Le CSS généré est absent ou périmé',
			$is_current
				? 'Le fichier public de styles correspond aux derniers réglages enregistrés.'
				: 'Le plugin utilisera son fallback inline. Vérifiez les permissions du dossier uploads si le problème persiste.',
			'performance'
		);
	}

	public static function test_update_manifest()
	{
		$manifest = function_exists('ultimate_shanks_get_manifest_data')
			? ultimate_shanks_get_manifest_data()
			: null;
		$is_available = is_array($manifest) && !empty($manifest['version']) && !empty($manifest['download_url']);

		return self::result(
			'manifest',
			$is_available ? 'good' : 'recommended',
			$is_available ? 'Le manifeste de mise à jour est accessible' : 'Le manifeste de mise à jour est indisponible',
			$is_available
				? 'Version distante détectée : ' . esc_html($manifest['version']) . '.'
				: 'Les mises à jour automatiques ne pourront pas être détectées tant que le manifeste reste indisponible.',
			'security'
		);
	}

	public static function test_integrations()
	{
		$otomatic = get_option('ultimate_shanks_otomatic_enabled', '1') === '1';
		$rankmath = get_option('ultimate_shanks_rankmath_enabled', '1') === '1';
		$description = sprintf(
			'Otomatic AI : %s. Rank Math : %s. Les routes actives exigent la capacité manage_options.',
			$otomatic ? 'activée' : 'désactivée',
			$rankmath ? 'activée' : 'désactivée'
		);

		return self::result('integrations', 'good', 'Les accès aux intégrations sont contrôlés', $description, 'security');
	}

	public static function test_ai_images()
	{
		$enabled = \UltimateShanks\AiImages\AiImages::is_enabled();
		$provider = \UltimateShanks\AiImages\Providers::get_active();
		$key_source = $provider instanceof \UltimateShanks\AiImages\FluxProvider
			? $provider->get_api_key_source()
			: 'none';

		$sources = [
			'constant' => 'clé définie par la constante wp-config.php',
			'option'   => 'clé enregistrée dans les réglages',
			'none'     => 'aucune clé configurée',
		];
		$description = sprintf(
			'Module %s. Fournisseur actif : %s (%s).',
			$enabled ? 'activé' : 'désactivé',
			$provider->get_label(),
			$sources[$key_source]
		);

		$is_ok = !$enabled || $key_source !== 'none';

		return self::result(
			'ai_images',
			$is_ok ? 'good' : 'recommended',
			$is_ok ? 'La génération d\'images IA est correctement configurée' : 'La génération d\'images IA est activée sans clé API',
			$is_ok ? $description : $description . ' La génération échouera tant qu\'aucune clé n\'est configurée.',
			'security'
		);
	}

	private static function result($test, $status, $label, $description, $badge)
	{
		return [
			'status'      => $status,
			'label'       => $label,
			'description' => '<p>' . wp_kses_post($description) . '</p>',
			'badge'       => [
				'label' => ucfirst($badge),
				'color' => 'blue',
			],
			'test'        => 'ultimate_shanks_' . $test,
		];
	}
}
