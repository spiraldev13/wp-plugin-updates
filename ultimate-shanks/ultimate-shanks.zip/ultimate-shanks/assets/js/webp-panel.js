/**
 * Ultimate Shanks - WebP (panneau de conversion et réglages)
 *
 * Conversion par lots AJAX successifs (5 images en WebP, 2 en AVIF — encodage
 * plus lent), suppression des originaux avec confirmation récapitulative,
 * restauration unitaire, et gestion des lignes de presets. Les erreurs métier
 * arrivent en HTTP 4xx/5xx : leur JSON est lu dans le .fail().
 */
(function ($) {
	'use strict';

	var config = window.ultimateShanksWebp || {};

	function failMessage(jqXHR) {
		var json = jqXHR && jqXHR.responseJSON;
		return (json && json.data && json.data.message) || config.strings.error;
	}

	function checkedValues(selector) {
		return $(selector + ':checked').map(function () {
			return $(this).val();
		}).get();
	}

	// --- Cases « tout sélectionner » (une par tableau) ---
	$(document).on('change', '.us-webp-check-all', function () {
		$(this).closest('table').find('tbody input[type="checkbox"]').prop('checked', this.checked);
	});

	// --- Conversion par lots successifs avec progression ---
	$(document).on('click', '#us_webp_convert_btn', function () {
		var ids = checkedValues('.us-webp-convert-check');
		if (!ids.length) {
			alert(config.strings.nothing);
			return;
		}

		var $preset = $('#us_webp_preset');
		var format = $preset.find('option:selected').data('format') || 'webp';
		var batchSize = (config.batchSizes && config.batchSizes[format]) || 5;
		var $button = $(this).prop('disabled', true);
		var $progress = $('#us_webp_convert_progress');
		var total = ids.length;
		var stats = { ok: 0, failed: 0 };

		$progress.text(config.strings.converting + ' (0/' + total + ')');

		(function run(remaining) {
			if (!remaining.length) {
				$progress.text(config.strings.converted.replace('%d', stats.ok).replace('%d', stats.failed));
				window.location.reload();
				return;
			}

			var batch = remaining.slice(0, batchSize);

			$.post(config.ajaxurl, {
				action: 'ultimate_shanks_webp_convert',
				nonce: config.nonce,
				ids: batch,
				preset_id: $preset.val()
			}).done(function (response) {
				var results = (response.data && response.data.results) || {};
				Object.keys(results).forEach(function (id) {
					if (results[id].success) {
						stats.ok++;
					} else {
						stats.failed++;
					}
				});
			}).fail(function (jqXHR) {
				stats.failed += batch.length;
				alert(failMessage(jqXHR));
			}).always(function () {
				$progress.text(config.strings.converting + ' (' + (stats.ok + stats.failed) + '/' + total + ')');
				run(remaining.slice(batchSize));
			});
		})(ids);
	});

	// --- Suppression des originaux (validation) ---
	$(document).on('click', '#us_webp_delete_btn', function () {
		var ids = checkedValues('.us-webp-pending-check');
		if (!ids.length) {
			alert(config.strings.nothing);
			return;
		}
		if (!window.confirm(config.strings.confirmDelete.replace('%d', ids.length))) {
			return;
		}

		var $button = $(this).prop('disabled', true).text(config.strings.deleting);

		$.post(config.ajaxurl, {
			action: 'ultimate_shanks_webp_delete_originals',
			nonce: config.nonce,
			ids: ids
		}).done(function () {
			window.location.reload();
		}).fail(function (jqXHR) {
			alert(failMessage(jqXHR));
			$button.prop('disabled', false).text('Supprimer les originaux sélectionnés');
		});
	});

	// --- Restauration unitaire ---
	$(document).on('click', '.us-webp-restore-btn', function () {
		if (!window.confirm(config.strings.confirmRestore)) {
			return;
		}

		var $button = $(this).prop('disabled', true);

		$.post(config.ajaxurl, {
			action: 'ultimate_shanks_webp_restore',
			nonce: config.nonce,
			id: $button.data('id')
		}).done(function () {
			window.location.reload();
		}).fail(function (jqXHR) {
			alert(failMessage(jqXHR));
			$button.prop('disabled', false);
		});
	});

	// --- Presets : ajout et suppression de lignes ---
	var presetIndex = 1000;

	$(document).on('click', '#us_webp_add_preset', function () {
		var i = presetIndex++;
		var row = '<tr class="us-webp-preset-row">'
			+ '<td style="text-align:center;"><input type="radio" name="us_webp_default" value="">'
			+ '<input type="hidden" name="us_webp_presets[' + i + '][id]" value=""></td>'
			+ '<td><input type="text" style="width:100%;" name="us_webp_presets[' + i + '][label]" value="" placeholder="Nom du preset"></td>'
			+ '<td><select name="us_webp_presets[' + i + '][format]">'
			+ '<option value="webp">WebP</option>'
			+ '<option value="avif">AVIF</option>'
			+ '</select></td>'
			+ '<td><input type="number" min="1" max="100" style="width:80px;" name="us_webp_presets[' + i + '][quality]" value="80"></td>'
			+ '<td><button type="button" class="button button-small us-webp-remove-preset">Supprimer</button></td>'
			+ '</tr>';
		$('#us_webp_presets_table tbody').append(row);
	});

	$(document).on('click', '.us-webp-remove-preset', function () {
		$(this).closest('tr').remove();
	});
})(jQuery);
