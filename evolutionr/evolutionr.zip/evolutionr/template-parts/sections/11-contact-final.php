<?php
/**
 * 09 — CTA final (contact, bas de page).
 *
 * Visuel : grand cartouche centré avec halo cyan + bordure cyan, eyebrow
 * « point glow + texte », titre large, paragraphe, 2 boutons centrés
 * (primaire mailto + ghost optionnel pour appel).
 *
 * Pilotage ACF (front-page) :
 *   - final_cta_eyebrow, final_cta_title, final_cta_paragraph.
 *   - final_cta_primary_label, final_cta_primary_url (vide = mailto vers
 *     l'email de contact global).
 *   - final_cta_secondary_label, final_cta_secondary_url.
 * Fallback : contact_email (page d'options) si primary_url vide.
 */

if (!defined('ABSPATH')) {
    exit;
}

$eyebrow      = get_field('final_cta_eyebrow') ?: __('Audit gratuit • Réponse sous 24h', 'evolutionr');
$title        = get_field('final_cta_title') ?: __('Prêt à faire évoluer votre présence en ligne ?', 'evolutionr');
$paragraph    = get_field('final_cta_paragraph') ?: __('Un audit gratuit de votre site actuel, une stratégie claire, un devis ferme. On commence par une conversation — pas par un bon de commande.', 'evolutionr');
$primaryLabel = get_field('final_cta_primary_label') ?: __('Demander un audit gratuit', 'evolutionr');
$primaryUrl   = get_field('final_cta_primary_url');
// CTA secondaire facultatif : ne s'affiche QUE si label ET URL renseignés
// en BO (pas de fallback automatique, on évite les CTA morts type
// « Réserver un appel » sans téléphone configuré).
$secondaryLabel = (string) get_field('final_cta_secondary_label');
$secondaryUrl   = (string) get_field('final_cta_secondary_url');

if (!$primaryUrl) {
    $email = get_field('contact_email', 'option');
    $primaryUrl = $email ? 'mailto:' . $email : '/contact/';
}
?>
<section class="final-cta" id="contact" aria-labelledby="final-cta-title">
    <div class="container">
        <div class="final-cta-inner">
            <div class="final-cta-eyebrow">
                <span class="eyebrow no-rule">
                    <span class="glow-dot" aria-hidden="true"></span>
                    <?php echo esc_html($eyebrow); ?>
                </span>
            </div>
            <h2 id="final-cta-title"><?php echo esc_html($title); ?></h2>
            <p><?php echo esc_html($paragraph); ?></p>
            <div class="actions">
                <a class="btn btn-primary" href="<?php echo esc_url($primaryUrl); ?>">
                    <?php echo esc_html($primaryLabel); ?>
                    <?php evolutionr_icon('arrow-right', 16); ?>
                </a>
                <?php if ($secondaryLabel && $secondaryUrl): ?>
                    <a class="btn btn-ghost" href="<?php echo esc_url($secondaryUrl); ?>">
                        <span class="btn-inner">
                            <?php echo esc_html($secondaryLabel); ?>
                        </span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
