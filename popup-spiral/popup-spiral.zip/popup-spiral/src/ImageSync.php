<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Une seule image par popup, deux points d'entrée : l'image mise en avant
 * (box WP / éditeur de blocs via REST) et le champ image du panneau Affichage
 * restent en miroir dans les deux sens.
 */
final class ImageSync
{
    /** @var bool Garde anti-boucle : nos écritures déclenchent nos propres hooks. */
    private static $syncing = false;

    public static function register(): void
    {
        // Hooks meta et non save_post : l'éditeur de blocs modifie l'image
        // mise en avant par REST, hors de tout écran admin.
        add_action('added_post_meta', [self::class, 'onThumbnailMeta'], 10, 4);
        add_action('updated_post_meta', [self::class, 'onThumbnailMeta'], 10, 4);
        add_action('deleted_post_meta', [self::class, 'onThumbnailDeleted'], 10, 3);
    }

    /**
     * @param int|array $metaId Ignoré (tableau d'ids pour deleted_post_meta).
     * @param int       $postId
     * @param string    $metaKey
     * @param mixed     $metaValue
     */
    public static function onThumbnailMeta($metaId, $postId, $metaKey, $metaValue = null): void
    {
        if ($metaKey !== '_thumbnail_id') {
            return;
        }

        self::mirrorToPanel((int) $postId, max(0, (int) $metaValue));
    }

    /**
     * @param int|array $metaIds
     * @param int       $postId
     * @param string    $metaKey
     */
    public static function onThumbnailDeleted($metaIds, $postId, $metaKey): void
    {
        if ($metaKey !== '_thumbnail_id') {
            return;
        }

        self::mirrorToPanel((int) $postId, 0);
    }

    /**
     * Choix fait dans le panneau : répercuté sur l'image mise en avant.
     */
    public static function applyPanelChoice(int $postId, int $imageId): void
    {
        if (self::$syncing) {
            return;
        }

        self::$syncing = true;

        if ($imageId > 0) {
            set_post_thumbnail($postId, $imageId);
        } else {
            delete_post_thumbnail($postId);
        }

        self::$syncing = false;
    }

    /**
     * Image mise en avant modifiée : répercutée sur le réglage du panneau.
     */
    private static function mirrorToPanel(int $postId, int $imageId): void
    {
        if (self::$syncing || get_post_type($postId) !== PostTypes::POPUP) {
            return;
        }

        $settings = Settings::get($postId);

        if ((int) $settings['display']['image']['id'] === $imageId) {
            return;
        }

        $settings['display']['image']['id'] = $imageId;

        self::$syncing = true;
        // Les réglages sortent de Settings::get, donc déjà normalisés ;
        // Settings::save les repasse par la sanitation, sans risque.
        Settings::save($postId, $settings);
        self::$syncing = false;
    }
}
