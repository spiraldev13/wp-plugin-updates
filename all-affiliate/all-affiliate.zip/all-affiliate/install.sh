#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# makedev — Installation sur un projet
#
# Usage :
#   cd mon-projet && git clone git@github.com:spiraldev13/makedev.git
#   cd makedev && make install
#   cd .. && rm -rf makedev/
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
MAKE_DIR="$PROJECT_DIR/.make"

# Couleurs
if [ -t 1 ]; then
  C_RESET='\033[0m'; C_RED='\033[31m'; C_GREEN='\033[32m'; C_CYAN='\033[36m'; C_YELLOW='\033[33m'
else
  C_RESET=''; C_RED=''; C_GREEN=''; C_CYAN=''; C_YELLOW=''
fi
info()  { printf "%bINFO:%b %s\n" "$C_CYAN" "$C_RESET" "$*"; }
ok()    { printf "%bOK:%b %s\n" "$C_GREEN" "$C_RESET" "$*"; }
warn()  { printf "%bWARN:%b %s\n" "$C_YELLOW" "$C_RESET" "$*"; }
error() { printf "%bERROR:%b %s\n" "$C_RED" "$C_RESET" "$*" >&2; }

# Verification : on est bien dans le dossier makedev clone
if [ ! -d "$SCRIPT_DIR/core" ] || [ ! -d "$SCRIPT_DIR/types" ]; then
  error "Ce script doit etre lance depuis le dossier makedev clone."
  exit 1
fi

echo ""
printf "%b\033[1mmakedev — Installation%b\n" "$C_CYAN" "$C_RESET"
printf "%b======================%b\n\n" "$C_CYAN" "$C_RESET"

info "Projet cible : $PROJECT_DIR"
echo ""

# Etape 1 : Copier core/ et types/ dans .make/
if [ -d "$MAKE_DIR" ]; then
  warn ".make/ existe deja. Remplacement..."
  rm -rf "$MAKE_DIR"
fi

mkdir -p "$MAKE_DIR"
cp -r "$SCRIPT_DIR/core" "$MAKE_DIR/core"
cp -r "$SCRIPT_DIR/types" "$MAKE_DIR/types"
cp "$SCRIPT_DIR/install.sh" "$MAKE_DIR/install.sh"
[ -f "$SCRIPT_DIR/README.md" ] && cp "$SCRIPT_DIR/README.md" "$MAKE_DIR/README.md"
ok ".make/ cree avec core/ et types/"

# Etape 2 : Gerer le Makefile du projet
MAKEFILE_PATH=""
if [ -f "$PROJECT_DIR/Makefile" ]; then
  MAKEFILE_PATH="$PROJECT_DIR/Makefile"
elif [ -f "$PROJECT_DIR/makefile" ]; then
  MAKEFILE_PATH="$PROJECT_DIR/makefile"
fi

if [ -n "$MAKEFILE_PATH" ]; then
  # Verifier si c'est deja un Makefile makedev
  if grep -q 'include .make/core/makefile' "$MAKEFILE_PATH" 2>/dev/null; then
    info "Makefile makedev deja en place."
  else
    warn "Un Makefile existant a ete detecte: $(basename "$MAKEFILE_PATH")"
    echo ""
    read -r -p "Sauvegarder et remplacer ? (o/n) [o] : " choice
    choice="${choice:-o}"
    case "$choice" in
      o|O|oui|OUI|y|Y|yes)
        local_timestamp="$(date +%Y%m%d-%H%M%S)"
        cp "$MAKEFILE_PATH" "$MAKEFILE_PATH.bak.$local_timestamp"
        ok "Backup cree: $(basename "$MAKEFILE_PATH").bak.$local_timestamp"
        ;;
      *)
        warn "Installation annulee. Le Makefile existant n est pas compatible avec makedev."
        exit 1
        ;;
    esac
  fi
fi

# Creer/remplacer le Makefile makedev
cat > "$PROJECT_DIR/Makefile" << 'MAKEFILE'
SHELL := /bin/bash
.DEFAULT_GOAL := help
.PHONY: help init git merge feature feature-merge self-update

include .make/core/makefile
MAKEFILE
ok "Makefile makedev en place."

# Etape 3 : Lancer make init
echo ""
info "Lancement de make init..."
echo ""
make -C "$PROJECT_DIR" init

echo ""
info "Vous pouvez maintenant supprimer le dossier makedev/ :"
info "  cd $PROJECT_DIR && rm -rf $(basename "$SCRIPT_DIR")/"
echo ""
