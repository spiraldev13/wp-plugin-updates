<?php
/**
 * Section FAQ des pages prestation (Création, SEO, Identité, Maintenance).
 *
 * Accordéon piloté par le repeater `faq` (sous-champs question/answer) du post
 * courant. Markup factorisé — était dupliqué verbatim sur les 4 pages. La
 * section s'auto-masque si le repeater est vide.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<?php if (have_rows('faq')):
    $faqEyebrow = (string) get_field('faq_eyebrow');
    $faqTitle   = (string) get_field('faq_title');
    ?>
    <section class="section section--prestation section--no-pad-top" aria-labelledby="faq-title">
        <div class="container">
            <?php if ($faqEyebrow || $faqTitle): ?>
                <div class="section-head">
                    <div class="section-head-left">
                        <?php if ($faqEyebrow): ?>
                            <div class="section-eyebrow-wrap">
                                <span class="eyebrow"><?php echo esc_html($faqEyebrow); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($faqTitle): ?>
                            <h2 class="section-title" id="faq-title"><?php echo esc_html($faqTitle); ?></h2>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="page-faq">
                <?php while (have_rows('faq')): the_row();
                    $q = (string) get_sub_field('question');
                    $a = (string) get_sub_field('answer');
                    if (!$q) continue;
                    ?>
                    <div class="page-faq-item">
                        <button class="page-faq-summary" type="button" aria-expanded="false">
                            <span><?php echo esc_html($q); ?></span>
                        </button>
                        <div class="page-faq-answer">
                            <div class="page-faq-answer-inner"><?php echo wp_kses_post(wpautop($a)); ?></div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
