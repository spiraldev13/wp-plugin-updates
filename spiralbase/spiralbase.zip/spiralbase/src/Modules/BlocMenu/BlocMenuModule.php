<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\Module;
use SpiralBase\Core\Signal;

/**
 * Module « carte / menu » (CAP-12, story 3.2) — trois blocs imbriqués qui ne
 * forment qu'UNE unité : une section hors carte, un plat hors section n'ont
 * aucun sens. D'où un seul interrupteur pour les trois (AD-2 : l'unité de
 * cession est le comportement, pas le fichier).
 *
 * Forme canonique des blocs métier (AD-12) : `block.json` + `index.js` écrit à
 * la main + `index.asset.php` à la main + `render_callback` porté par le
 * module. Aucun contenu n'est figé dans le HTML sauvegardé : les plats vivent
 * en attributs, le HTML est régénéré à chaque affichage — c'est ce qui rend
 * l'AC 2 vraie par construction (changer de variante ne touche à aucune
 * donnée) et ce qui permettra à une correction de rendu livrée par la flotte
 * d'atteindre les cartes déjà publiées.
 *
 * OFF par défaut (AD-6, sans exception pour les blocs métier) : un site de
 * plombier n'a pas de carte.
 *
 * Aucune sonde de cession (`null`) : aucun plugin de carte n'est installé
 * dans l'environnement de dev, et la discipline du projet interdit une sonde
 * sur des faits non lus dans un plugin réel (leçon 2.4). Le fond diffère
 * d'ailleurs des modules SEO : ce bloc ne rend que là où l'opérateur l'a
 * POSÉ — céder ferait disparaître une carte explicitement placée sur une page.
 */
final class BlocMenuModule implements Module
{
    /**
     * Répertoire du bloc => rendu associé. L'ordre n'a aucune importance
     * côté serveur : `WP_Block_Type_Registry` ne connaît pas la contrainte
     * `parent`, qui est résolue par l'inséreur de l'éditeur (vérifié — zéro
     * occurrence de `parent` dans le registre du cœur). Il suit simplement
     * la lecture naturelle : la carte, puis ses sections, puis ses plats.
     *
     * @var array<string, class-string<RenduBloc>>
     */
    private const BLOCS = [
        'menu'         => RenduMenu::class,
        'menu-section' => RenduSection::class,
        'menu-plat'    => RenduPlat::class,
    ];

    /**
     * Handle de la feuille PARTAGÉE par les trois blocs — déclaré tel quel
     * dans les trois `block.json` (`"style": "spiralbase-menu"`).
     *
     * Deux défauts réglés d'un coup :
     *  - le cœur versionne les feuilles depuis le `block.json`
     *    (`blocks.php:350-351`), qui est un fichier statique : la version y
     *    reste figée et une correction CSS livrée par une release ne
     *    franchirait jamais les caches. Enregistrée ici, la feuille suit la
     *    version du thème, exactement comme les scripts via leur manifeste ;
     *  - un bloc enfant rendu hors de sa carte (copier-coller, duplication de
     *    page, futur pattern) n'enfilait AUCUNE feuille : le cœur n'enfile
     *    que les handles du bloc effectivement rendu
     *    (`class-wp-block.php:625-629`).
     */
    public const HANDLE_STYLE = 'spiralbase-menu';

    public function slug(): string
    {
        return 'bloc_menu';
    }

    public function boot(): void
    {
        /* boot() court sur after_setup_theme ; le cœur enregistre les blocs
           sur init — on s'y range (pattern 2.9, 3.1). */
        add_action('init', static function (): void {
            wp_register_style(
                self::HANDLE_STYLE,
                get_template_directory_uri() . '/blocks/menu/style.css',
                [],
                (string) wp_get_theme(get_template())->get('Version')
            );

            foreach (self::BLOCS as $repertoire => $rendu) {
                $type = register_block_type(
                    get_template_directory() . '/blocks/' . $repertoire,
                    ['render_callback' => static fn (array $attributs, string $contenu = '', mixed $bloc = null): string
                        => (new $rendu())->rendre($attributs, $contenu, $bloc)]
                );

                /* Le cœur rend `false` sans rien dire d'audible hors
                   WP_DEBUG (`_doing_it_wrong`) : un répertoire absent après
                   une mise à jour partielle ferait disparaître la carte de
                   tout le site en silence (NFR13). */
                if ($type === false) {
                    Signal::emettre(
                        'spiralbase_bloc_menu_enregistrement_echoue',
                        sprintf('bloc « %s » non enregistré : répertoire ou block.json illisible', $repertoire),
                        'bloc menu'
                    );
                }
            }
        });

        /*
         * Une page dont le contenu est une carte est faite à 100 % de blocs
         * dynamiques : `excerpt_remove_blocks()` ne garde que les blocs
         * déclarés, l'extrait automatique en ressortait VIDE — donc pas de
         * description dans les partages sociaux (le repli d'`opengraph`
         * s'effondre lui aussi), ni dans le flux RSS, ni dans les archives.
         * C'est la page la plus partagée d'un restaurant.
         *
         * Les DEUX listes sont nécessaires : un bloc autorisé qui a des
         * enfants est ignoré (`blocks.php:2248-2256`) tant qu'il n'est pas
         * déclaré « wrapper » (`:2243-2246`) — seule cette seconde liste
         * autorise la descente dans les sections puis les plats.
         */
        $noms = array_map(static fn (string $r): string => 'spiralbase/' . $r, array_keys(self::BLOCS));

        $ajouter = static function ($blocs) use ($noms): array {
            return array_values(array_unique(array_merge(is_array($blocs) ? $blocs : [], $noms)));
        };

        add_filter('excerpt_allowed_blocks', $ajouter);
        add_filter('excerpt_allowed_wrapper_blocks', $ajouter);
    }

    public function defaultSettings(): array
    {
        return [];
    }

    public function options(): array
    {
        return [];
    }

    public function enabledByDefault(): bool
    {
        return false;
    }

    public function cessionProbe(): ?callable
    {
        return null;
    }
}
