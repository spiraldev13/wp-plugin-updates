<?php

namespace Spiral;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Planification d'un popup : dates de début et de fin optionnelles,
 * interprétées dans le fuseau horaire du site.
 */
final class Schedule
{
    public static function isActive(array $schedule): bool
    {
        $now = new \DateTimeImmutable('now', wp_timezone());

        $start = self::parse($schedule['start'] ?? '');
        if ($start !== null && $now < $start) {
            return false;
        }

        $end = self::parse($schedule['end'] ?? '');
        if ($end !== null && $now > $end) {
            return false;
        }

        return true;
    }

    /**
     * Bornes en millisecondes epoch pour le garde-fou côté navigateur
     * (une page en cache peut contenir un popup déjà expiré).
     *
     * @return array{start: int|null, end: int|null}
     */
    public static function boundsMs(array $schedule): array
    {
        $start = self::parse($schedule['start'] ?? '');
        $end = self::parse($schedule['end'] ?? '');

        return [
            'start' => $start !== null ? $start->getTimestamp() * 1000 : null,
            'end' => $end !== null ? $end->getTimestamp() * 1000 : null,
        ];
    }

    /**
     * Date d'une borne de planification, dans le fuseau du site ; null si vide
     * ou invalide. Publique : la colonne admin l'utilise pour l'affichage.
     */
    public static function parse(string $value): ?\DateTimeImmutable
    {
        if ($value === '') {
            return null;
        }

        // Tolère les secondes éventuelles laissées par d'anciennes sauvegardes.
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', substr($value, 0, 16), wp_timezone());

        return $date instanceof \DateTimeImmutable ? $date : null;
    }
}
