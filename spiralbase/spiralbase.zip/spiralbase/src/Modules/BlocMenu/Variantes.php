<?php

declare(strict_types=1);

namespace SpiralBase\Modules\BlocMenu;

use SpiralBase\Core\Signal;

/**
 * Juge UNIQUE de la mise en forme de la carte — consommé par les trois
 * niveaux de blocs (carte, section, plat).
 *
 * La variante est saisie sur le bloc parent et descend aux enfants par le
 * contexte natif (`providesContext` / `usesContext`). Le cœur transmet la
 * valeur BRUTE de l'attribut du parent (`class-wp-block.php:190-195`), et un
 * tiers peut encore la réécrire au vol par le filtre `render_block_context`
 * (`:564`). Trois consommateurs, une seule lecture possible : sinon la carte
 * et ses plats afficheraient deux mises en forme contradictoires (leçon 3.1).
 *
 * Vocabulaire FERMÉ : la valeur finit dans une classe CSS. Une valeur
 * inconnue retombe sur « liste » plutôt que de fabriquer une classe depuis
 * une chaîne venue de l'extérieur.
 */
final class Variantes
{
    public const DEFAUT = 'liste';

    /** @var list<string> */
    public const CONNUES = ['liste', 'cartes', 'compact'];

    private const HOOK_INCONNUE = 'spiralbase_bloc_menu_variante_inconnue';

    /** Nom du contexte de bloc porté par le parent. */
    public const CONTEXTE = 'spiralbase/variante';

    public static function juger(mixed $valeur): string
    {
        if (is_string($valeur) && in_array($valeur, self::CONNUES, true)) {
            return $valeur;
        }

        /* Absente ou vide : cas nominal (bloc rendu hors de sa carte, attribut
           laissé au défaut) — rien à signaler.
           Une valeur PRÉSENTE mais inconnue est une anomalie. Portée réelle
           du signal, mesurée : l'`enum` du block.json fait déjà retomber
           l'attribut du parent sur « liste » AVANT le rendu
           (`class-wp-block-type.php:517-529`) — une carte écrite à la main
           n'atteint donc jamais ce chemin. Restent le contexte réécrit par un
           filtre `render_block_context` tiers et l'appel direct du rendu par
           une extension : c'est là, et là seulement, que ce signal parle
           (NFR13). */
        if ($valeur !== null && $valeur !== '') {
            Signal::emettre(
                self::HOOK_INCONNUE,
                sprintf(
                    'mise en forme « %s » inconnue, « %s » appliquée',
                    is_scalar($valeur) ? (string) $valeur : get_debug_type($valeur),
                    self::DEFAUT
                ),
                'bloc menu'
            );
        }

        return self::DEFAUT;
    }

    /** Variante déclarée sur le bloc parent lui-même. @param array<string, mixed> $attributs */
    public static function depuisAttributs(array $attributs): string
    {
        return self::juger($attributs['variante'] ?? null);
    }

    /**
     * Variante héritée du parent par le contexte de bloc.
     *
     * L'objet reçu est un `WP_Block` en production, mais rien ne le garantit :
     * un filtre tiers peut passer autre chose, et l'aperçu d'un bloc rendu
     * hors de sa carte n'a pas de contexte du tout. Toute lecture qui échoue
     * vaut « pas de contexte » — un rendu ne s'écroule pas pour une classe CSS.
     */
    public static function depuisContexte(mixed $bloc): string
    {
        try {
            $contexte = is_object($bloc) ? ($bloc->context ?? null) : null;
        } catch (\Throwable) {
            $contexte = null;
        }

        return self::juger(is_array($contexte) ? ($contexte[self::CONTEXTE] ?? null) : null);
    }
}
