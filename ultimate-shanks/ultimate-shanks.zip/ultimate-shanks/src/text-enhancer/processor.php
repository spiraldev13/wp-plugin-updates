<?php
/**
 * Processor - Moteur de traitement des paragraphes
 *
 * Ce fichier contient la logique de découpage des paragraphes longs.
 * Aucun asset associé (logique pure).
 *
 * Fichiers liés :
 * - text-enhancer.php : Hook the_content et appel du processeur
 *
 * @package UltimateShanks\TextEnhancer
 */

namespace UltimateShanks\TextEnhancer;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Moteur de traitement des paragraphes
 *
 * @package UltimateShanks
 * @subpackage TextEnhancer
 */
class Processor
{
	/**
	 * Éléments complexes qui empêchent le traitement
	 */
	private static $complex_elements = [
		'<figure',
		'<iframe',
		'<table',
		'<pre',
		'<code',
		'<form',
		'<script',
		'<style',
		'<!-- wp:gallery',
		'<!-- wp:columns',
		'<!-- wp:group',
	];

	/**
	 * Mots courants qui ne terminent pas une phrase
	 */
	private static $false_endings = [
		'M\.',
		'Mme\.',
		'Mlle\.',
		'Dr\.',
		'Pr\.',
		'etc\.',
		'vs\.',
		'ex\.',
		'cf\.',
		'n°',
		'N°',
		'\d+\.',  // Numéros comme "1.", "2."
	];

	/**
	 * Vérifie si le contenu contient des éléments complexes
	 *
	 * @param string $content Contenu à vérifier
	 * @return bool True si contenu complexe, False sinon
	 */
	public static function has_complex_elements($content)
	{
		// Vérifier les éléments HTML/Gutenberg complexes
		foreach (self::$complex_elements as $element) {
			if (stripos($content, $element) !== false) {
				return true;
			}
		}

		// Vérifier les shortcodes
		if (preg_match('/\[[a-z0-9_-]+/', $content)) {
			return true;
		}

		return false;
	}

	/**
	 * Découpe les paragraphes longs
	 *
	 * @param string $content Contenu à traiter
	 * @param array $options Options de traitement
	 * @return string Contenu traité
	 */
	public static function split_long_paragraphs($content, $options = [])
	{
		// Options par défaut
		$defaults = [
			'min_length' => 400,
			'sentences_per_paragraph' => 2,
			'line_breaks' => 0,
			'ignore_links' => false,
			'ignore_shortcodes' => true,
			'ignore_classes' => [],
			'debug_mode' => false,
		];

		$options = array_merge($defaults, $options);

		// Pattern pour trouver les paragraphes
		$pattern = '/<p\b([^>]*)>(.*?)<\/p>/is';

		return preg_replace_callback($pattern, function($matches) use ($options) {
			return self::process_paragraph($matches, $options);
		}, $content);
	}

	/**
	 * Traite un paragraphe individuel
	 *
	 * @param array $matches Résultats du regex
	 * @param array $options Options de traitement
	 * @return string Paragraphe traité
	 */
	private static function process_paragraph($matches, $options)
	{
		$attributes = $matches[1]; // Attributs du <p>
		$html_content = $matches[2]; // Contenu avec HTML
		$text_only = trim(strip_tags($html_content)); // Texte seul pour vérifications

		// Vérifications préliminaires
		if (strlen($text_only) < $options['min_length']) {
			return $matches[0]; // Trop court, on garde tel quel
		}

		// Ignorer si le paragraphe contient des éléments complexes
		if (self::has_complex_elements($html_content)) {
			return $matches[0];
		}

		// Ignorer si contient des liens
		if ($options['ignore_links'] && stripos($html_content, '<a') !== false) {
			return $matches[0];
		}

		// Ignorer si contient des shortcodes
		if ($options['ignore_shortcodes'] && preg_match('/\[[a-z0-9_-]+/', $html_content)) {
			return $matches[0];
		}

		// Ignorer si classe CSS exclue
		// Chercher les classes dans les attributs du <p> ET dans le contenu HTML
		if (!empty($options['ignore_classes'])) {
			foreach ($options['ignore_classes'] as $class) {
				if (empty($class)) continue;

				// Pattern pour chercher class="...classe..." ou class='...classe...'
				$pattern = '/class=["\'][^"\']*\b' . preg_quote(trim($class), '/') . '\b[^"\']*["\']/i';

				// Vérifier dans les attributs du <p>
				if (preg_match($pattern, $attributes)) {
					return $matches[0];
				}

				// Vérifier dans le contenu HTML interne
				if (preg_match($pattern, $html_content)) {
					return $matches[0];
				}
			}
		}

		// Découper en phrases (avec HTML préservé)
		$sentences = self::split_into_sentences_with_html($html_content);

		// Si peu de phrases, ne pas découper
		if (count($sentences) <= $options['sentences_per_paragraph']) {
			return $matches[0];
		}

		// Regrouper en paragraphes
		return self::regroup_sentences($sentences, $attributes, $options);
	}

	/**
	 * Découpe le texte en phrases intelligemment
	 *
	 * @param string $text Texte à découper
	 * @return array Tableau de phrases
	 */
	private static function split_into_sentences($text)
	{
		// Découpage simple sur les points, points d'exclamation et d'interrogation
		// suivis d'un espace et d'un nouveau token textuel (gère aussi les minuscules/quotes)
		$pattern = "/(?<=[.!?])\\s+(?=['\"«“(\\[]*[\\p{L}\\p{N}])/u";

		$sentences = preg_split($pattern, $text, -1, PREG_SPLIT_NO_EMPTY);

		// Filtrer les faux positifs (M., Dr., etc.)
		$filtered_sentences = [];
		$current_sentence = '';

		foreach ($sentences as $sentence) {
			$current_sentence .= ($current_sentence ? ' ' : '') . $sentence;

			// Vérifier si c'est un vrai fin de phrase
			if (!self::is_false_ending($current_sentence)) {
				$filtered_sentences[] = trim($current_sentence);
				$current_sentence = '';
			}
		}

		// Ajouter la dernière phrase si elle existe
		if (!empty($current_sentence)) {
			$filtered_sentences[] = trim($current_sentence);
		}

		return $filtered_sentences;
	}

	/**
	 * Découpe le texte en phrases intelligemment (AVEC HTML préservé)
	 *
	 * @param string $html_content Contenu HTML à découper
	 * @return array Tableau de phrases avec HTML
	 */
	private static function split_into_sentences_with_html($html_content)
	{
		// Sauvegarder les balises HTML avec des marqueurs temporaires
		$html_tags = [];
		$placeholder_index = 0;

		// Base de marqueur unique par exécution : un contenu qui contiendrait littéralement
		// un marqueur fixe (ex. article documentant ce plugin) serait sinon corrompu à la restauration.
		$marker_base = '___HTML_TAG_' . dechex(mt_rand()) . '_';

		// Remplacer toutes les balises HTML par des marqueurs uniques
		$text_with_placeholders = preg_replace_callback('/<[^>]+>/', function($match) use (&$html_tags, &$placeholder_index, $marker_base) {
			$placeholder = "{$marker_base}{$placeholder_index}___";
			$html_tags[$placeholder] = $match[0];
			$placeholder_index++;
			return $placeholder;
		}, $html_content);

		// Découper en phrases (sans les balises HTML), tout en tolérant des balises inline
		// en début de phrase (ex: <strong>Texte</strong>).
		$marker_regex = preg_quote($marker_base, '/');
		$pattern = "/(?<=[.!?])\\s+(?=(?:{$marker_regex}\\d+___\\s*)*['\"«“(\\[]*[\\p{L}\\p{N}])/u";
		$sentences = preg_split($pattern, $text_with_placeholders, -1, PREG_SPLIT_NO_EMPTY);

		// Filtrer les faux positifs
		$filtered_sentences = [];
		$current_sentence = '';

		foreach ($sentences as $sentence) {
			$current_sentence .= ($current_sentence ? ' ' : '') . $sentence;

			// Retirer les placeholders temporairement pour vérifier la fin de phrase
			$text_only = $current_sentence;
			foreach ($html_tags as $placeholder => $tag) {
				$text_only = str_replace($placeholder, '', $text_only);
			}

			// Vérifier si c'est un vrai fin de phrase
			if (!self::is_false_ending($text_only)) {
				// Restaurer les balises HTML
				$sentence_with_html = $current_sentence;
				foreach ($html_tags as $placeholder => $tag) {
					$sentence_with_html = str_replace($placeholder, $tag, $sentence_with_html);
				}
				$filtered_sentences[] = trim($sentence_with_html);
				$current_sentence = '';
			}
		}

		// Ajouter la dernière phrase si elle existe
		if (!empty($current_sentence)) {
			$sentence_with_html = $current_sentence;
			foreach ($html_tags as $placeholder => $tag) {
				$sentence_with_html = str_replace($placeholder, $tag, $sentence_with_html);
			}
			$filtered_sentences[] = trim($sentence_with_html);
		}

		return $filtered_sentences;
	}

	/**
	 * Vérifie si une phrase se termine par un faux positif
	 *
	 * @param string $sentence Phrase à vérifier
	 * @return bool True si faux positif
	 */
	private static function is_false_ending($sentence)
	{
		// Liste des abréviations courantes
		$abbreviations = ['M.', 'Mme.', 'Mlle.', 'Dr.', 'Pr.', 'etc.', 'vs.', 'ex.', 'cf.'];

		foreach ($abbreviations as $abbr) {
			if (substr(trim($sentence), -strlen($abbr)) === $abbr) {
				return true;
			}
		}

		// Vérifier si se termine par un numéro suivi d'un point (1., 2., etc.)
		if (preg_match('/\d+\.$/', trim($sentence))) {
			return true;
		}

		return false;
	}

	/**
	 * Regroupe les phrases en paragraphes
	 *
	 * @param array $sentences Phrases à regrouper
	 * @param string $attributes Attributs du paragraphe original
	 * @param array $options Options de traitement
	 * @return string HTML des nouveaux paragraphes
	 */
	private static function regroup_sentences($sentences, $attributes, $options)
	{
		$output = '';
		$buffer = [];
		$sentences_per_p = (int) $options['sentences_per_paragraph'];
		$line_breaks = isset($options['line_breaks']) ? (int) $options['line_breaks'] : 1;

		// Debug : afficher le nombre de phrases par paragraphe configuré
		if ($options['debug_mode']) {
			error_log('[Text Enhancer Debug] Sentences per paragraph: ' . $sentences_per_p);
			error_log('[Text Enhancer Debug] Total sentences to process: ' . count($sentences));
		}

		// Classe debug si activée
		$debug_class = '';
		if ($options['debug_mode']) {
			if (stripos($attributes, 'class=') !== false) {
				$attributes = preg_replace('/class=["\']([^"\']*)["\']/', 'class="$1 te-debug-highlight"', $attributes);
			} else {
				$debug_class = ' class="te-debug-highlight"';
			}
		}

		$paragraph_count = 0;
		foreach ($sentences as $sentence) {
			$buffer[] = $sentence;

			if (count($buffer) >= $sentences_per_p) {
				$output .= '<p' . $attributes . $debug_class . '>' . implode(' ', $buffer) . '</p>';

				// Ajouter les sauts de ligne HTML
				for ($i = 0; $i < $line_breaks; $i++) {
					$output .= '<br>';
				}

				$buffer = [];
				$paragraph_count++;
			}
		}

		// Dernières phrases restantes
		if (!empty($buffer)) {
			// Ajouter un saut de ligne avant le dernier paragraphe si ce n'est pas le premier
			if ($paragraph_count > 0) {
				for ($i = 0; $i < $line_breaks; $i++) {
					$output .= '<br>';
				}
			}
			$output .= '<p' . $attributes . $debug_class . '>' . implode(' ', $buffer) . '</p>';
		}

		return $output;
	}

	/**
	 * Applique les corrections SEO au contenu
	 *
	 * @param string $content Contenu à corriger
	 * @param array $options Options SEO
	 * @return string Contenu corrigé
	 */
	public static function apply_seo_corrections($content, $options = [])
	{
		if (empty($options)) {
			return $content;
		}

		// Tirets cadratins vers virgules
		if (!empty($options['fix_em_dash'])) {
			// Remplacer — par ,
			$content = str_replace(' — ', ', ', $content);
			$content = str_replace('— ', ', ', $content);
			$content = str_replace(' —', ', ', $content);
			// Aussi le tiret long unicode
			$content = str_replace(' – ', ', ', $content);
			$content = str_replace('– ', ', ', $content);
			$content = str_replace(' –', ', ', $content);
		}

		// Supprimer les séparateurs horizontaux (HR)
		if (!empty($options['remove_hr'])) {
			// Supprimer toutes les balises <hr> avec tous leurs attributs possibles
			$content = preg_replace('/<hr\b[^>]*>/i', '', $content);
			// Nettoyer les éventuels doubles sauts de ligne créés
			$content = preg_replace('/\n\s*\n\s*\n/', "\n\n", $content);
		}

		return $content;
	}
}
