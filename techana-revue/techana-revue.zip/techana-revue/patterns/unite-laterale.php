<?php
/**
 * Title: Unité article — latérale
 * Slug: techana-revue/unite-laterale
 * Categories: techana, posts
 * Block Types: core/post-template
 * Description: Vignette 1:1 de 64px, titre 14px, signature — listes de la latérale.
 * Viewport Width: 340
 */
?>
<!-- wp:group {"className":"u-side k-auto"} -->
<div class="wp-block-group u-side k-auto"><!-- wp:post-featured-image {"sizeSlug":"techana-side","className":"ph-auto square"} /-->

<!-- wp:group -->
<div class="wp-block-group"><!-- wp:post-title {"level":3,"isLink":true} /-->

<!-- wp:paragraph {"className":"meta","metadata":{"bindings":{"content":{"source":"techana/meta-carte"}}}} -->
<p class="meta"></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
