<?php

namespace Spiral\Admin;

use Spiral\Dates;
use Spiral\Install;
use Spiral\PostTypes;
use Spiral\Stats\Repository as Stats;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Panneau de statistiques : totaux, taux de clic, courbe chronologique et
 * tableau récapitulatif par popup, filtrables par popup et par période.
 *
 * Lecture seule sur la table d'agrégats journaliers — aucune donnée personnelle.
 */
final class StatsPage
{
    public const CAPABILITY = 'edit_posts';

    private const PERIODS = [7, 30, 90];

    public static function register(): void
    {
        add_action('admin_menu', [self::class, 'addPage']);
    }

    public static function addPage(): void
    {
        add_submenu_page(
            'edit.php?post_type=' . PostTypes::POPUP,
            __('Statistiques des popups', 'popup-spiral'),
            __('Statistiques', 'popup-spiral'),
            /** Capacité filtrable pour les rôles personnalisés. */
            (string) apply_filters('spiral_stats_capability', self::CAPABILITY),
            'spiral-stats',
            [self::class, 'render']
        );
    }

    public static function render(): void
    {
        if (!current_user_can((string) apply_filters('spiral_stats_capability', self::CAPABILITY))) {
            wp_die(esc_html__('Accès refusé.', 'popup-spiral'));
        }

        [$from, $to, $period] = self::resolveRange();
        $popupId = isset($_GET['popup']) ? absint($_GET['popup']) : 0;

        $totals = Stats::totals($popupId ?: null, $from, $to);
        $cumulative = Stats::cumulativeTotals($popupId ?: null);
        $series = Stats::dailySeries($popupId ?: null, $from, $to);
        $dailyHasData = Stats::firstDay() !== null;

        echo '<div class="wrap spiral-stats">';
        echo '<h1>' . esc_html__('Statistiques des popups', 'popup-spiral') . '</h1>';

        self::renderFilters($popupId, $period, $from, $to);

        // Vraiment rien nulle part (ni détail journalier, ni total hérité).
        if (!$dailyHasData && $cumulative['views'] === 0 && $cumulative['clicks'] === 0) {
            self::renderEmptyState();
            echo '</div>';
            return;
        }

        echo '<h2>' . esc_html__('Total cumulé (depuis toujours)', 'popup-spiral') . '</h2>';
        self::renderCards($cumulative);

        if (!$dailyHasData) {
            echo '<p class="notice notice-info spiral-stats-hint" style="padding:8px 12px;">'
                . esc_html__('Le suivi détaillé par jour vient d\'être activé : la courbe et les totaux « sur la période » ci-dessous se rempliront à partir des prochaines vues. Vos compteurs existants restent visibles dans le total cumulé ci-dessus.', 'popup-spiral')
                . '</p>';
        }

        echo '<h2>' . esc_html__('Sur la période sélectionnée', 'popup-spiral') . '</h2>';
        self::renderCards($totals);
        self::renderChart($series);
        self::renderTable($from, $to);
        self::renderSinceNote();

        echo '</div>';
        self::renderInlineAssets();
    }

    /**
     * Résout la plage de dates à partir de la période demandée.
     *
     * @return array{0: string, 1: string, 2: string} from, to, period
     */
    private static function resolveRange(): array
    {
        $period = isset($_GET['period']) ? sanitize_key((string) $_GET['period']) : '30';
        $today = Dates::today();

        if ($period === 'custom') {
            $from = isset($_GET['from']) ? (Dates::sanitizeDay((string) $_GET['from']) ?? '') : '';
            $to = isset($_GET['to']) ? (Dates::sanitizeDay((string) $_GET['to']) ?? '') : '';

            if ($from === '' || $to === '' || $from > $to) {
                $from = self::daysAgo(30);
                $to = $today;
                $period = '30';
            }

            return [$from, $to, $period];
        }

        $days = in_array((int) $period, self::PERIODS, true) ? (int) $period : 30;

        return [self::daysAgo($days - 1), $today, (string) $days];
    }

    private static function daysAgo(int $days): string
    {
        return Dates::now()->sub(new \DateInterval('P' . max(0, $days) . 'D'))->format(Dates::DAY);
    }

    private static function renderFilters(int $popupId, string $period, string $from, string $to): void
    {
        $popups = get_posts([
            'post_type' => PostTypes::POPUP,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
        ?>
        <form method="get" class="spiral-stats-filters">
            <input type="hidden" name="post_type" value="<?php echo esc_attr(PostTypes::POPUP); ?>">
            <input type="hidden" name="page" value="spiral-stats">

            <label for="spiral-stats-popup"><?php esc_html_e('Popup', 'popup-spiral'); ?></label>
            <select id="spiral-stats-popup" name="popup">
                <option value="0"><?php esc_html_e('Tous les popups', 'popup-spiral'); ?></option>
                <?php foreach ($popups as $popup) : ?>
                    <option value="<?php echo (int) $popup->ID; ?>" <?php selected($popupId, $popup->ID); ?>>
                        <?php echo esc_html($popup->post_title !== '' ? $popup->post_title : __('(sans titre)', 'popup-spiral')); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="spiral-stats-period"><?php esc_html_e('Période', 'popup-spiral'); ?></label>
            <select id="spiral-stats-period" name="period">
                <option value="7" <?php selected($period, '7'); ?>><?php esc_html_e('7 derniers jours', 'popup-spiral'); ?></option>
                <option value="30" <?php selected($period, '30'); ?>><?php esc_html_e('30 derniers jours', 'popup-spiral'); ?></option>
                <option value="90" <?php selected($period, '90'); ?>><?php esc_html_e('90 derniers jours', 'popup-spiral'); ?></option>
                <option value="custom" <?php selected($period, 'custom'); ?>><?php esc_html_e('Personnalisée', 'popup-spiral'); ?></option>
            </select>

            <span class="spiral-stats-custom"<?php echo $period === 'custom' ? '' : ' hidden'; ?>>
                <input type="date" name="from" value="<?php echo esc_attr($from); ?>" aria-label="<?php esc_attr_e('Du', 'popup-spiral'); ?>">
                <input type="date" name="to" value="<?php echo esc_attr($to); ?>" aria-label="<?php esc_attr_e('Au', 'popup-spiral'); ?>">
            </span>

            <button type="submit" class="button"><?php esc_html_e('Appliquer', 'popup-spiral'); ?></button>
        </form>
        <?php
    }

    /**
     * @param array{views: int, clicks: int} $totals
     */
    private static function renderCards(array $totals): void
    {
        $ctr = Stats::ctr($totals['views'], $totals['clicks']);
        $cards = [
            [__('Vues', 'popup-spiral'), number_format_i18n($totals['views'])],
            [__('Clics', 'popup-spiral'), number_format_i18n($totals['clicks'])],
            [__('Taux de clic', 'popup-spiral'), number_format_i18n($ctr, 1) . ' %'],
        ];

        echo '<div class="spiral-stats-cards">';

        foreach ($cards as $card) {
            echo '<div class="spiral-stats-card">';
            echo '<span class="spiral-stats-card-value">' . esc_html($card[1]) . '</span>';
            echo '<span class="spiral-stats-card-label">' . esc_html($card[0]) . '</span>';
            echo '</div>';
        }

        echo '</div>';
    }

    /**
     * Courbe chronologique vues/clics en SVG inline (aucune dépendance).
     *
     * @param array<int, array{date: string, views: int, clicks: int}> $series
     */
    private static function renderChart(array $series): void
    {
        $count = count($series);

        if ($count === 0) {
            return;
        }

        $max = 1;

        foreach ($series as $point) {
            $max = max($max, $point['views'], $point['clicks']);
        }

        $width = 960;
        $height = 260;
        $padX = 40;
        $padY = 20;
        $plotW = $width - $padX * 2;
        $plotH = $height - $padY * 2;

        $viewsPoints = self::seriesPoints($series, 'views', $max, $padX, $padY, $plotW, $plotH);
        $clicksPoints = self::seriesPoints($series, 'clicks', $max, $padX, $padY, $plotW, $plotH);

        $label = sprintf(
            /* translators: 1: première date, 2: dernière date, 3: valeur max */
            __('Évolution des vues et des clics du %1$s au %2$s, maximum %3$d par jour.', 'popup-spiral'),
            $series[0]['date'],
            $series[$count - 1]['date'],
            $max
        );

        echo '<div class="spiral-stats-chart">';
        echo '<div class="spiral-stats-legend">';
        echo '<span class="spiral-stats-legend-item spiral-legend-views">' . esc_html__('Vues', 'popup-spiral') . '</span>';
        echo '<span class="spiral-stats-legend-item spiral-legend-clicks">' . esc_html__('Clics', 'popup-spiral') . '</span>';
        echo '</div>';

        echo '<svg viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="' . esc_attr($label) . '" preserveAspectRatio="xMidYMid meet">';
        echo '<title>' . esc_html($label) . '</title>';

        // Ligne de base et valeur maximale.
        $baseY = $padY + $plotH;
        echo '<line x1="' . $padX . '" y1="' . $baseY . '" x2="' . ($padX + $plotW) . '" y2="' . $baseY . '" stroke="#cbd5e1" stroke-width="1" />';
        echo '<text x="' . ($padX - 6) . '" y="' . ($padY + 4) . '" text-anchor="end" font-size="11" fill="#64748b">' . esc_html((string) $max) . '</text>';
        echo '<text x="' . ($padX - 6) . '" y="' . ($baseY + 4) . '" text-anchor="end" font-size="11" fill="#64748b">0</text>';

        echo '<polyline fill="none" stroke="#2271b1" stroke-width="2" points="' . esc_attr($viewsPoints) . '" />';
        echo '<polyline fill="none" stroke="#16a34a" stroke-width="2" points="' . esc_attr($clicksPoints) . '" />';

        // Dates aux extrémités.
        echo '<text x="' . $padX . '" y="' . ($height - 2) . '" font-size="11" fill="#64748b">' . esc_html($series[0]['date']) . '</text>';
        echo '<text x="' . ($padX + $plotW) . '" y="' . ($height - 2) . '" text-anchor="end" font-size="11" fill="#64748b">' . esc_html($series[$count - 1]['date']) . '</text>';

        echo '</svg>';
        echo '</div>';
    }

    /**
     * Chaîne « x,y x,y … » des points d'une série pour un <polyline>.
     *
     * @param array<int, array{date: string, views: int, clicks: int}> $series
     */
    private static function seriesPoints(array $series, string $key, int $max, int $padX, int $padY, int $plotW, int $plotH): string
    {
        $count = count($series);
        $points = [];

        foreach ($series as $i => $point) {
            $x = $count > 1 ? $padX + $i * ($plotW / ($count - 1)) : $padX + $plotW / 2;
            $y = $padY + $plotH - ($point[$key] / $max) * $plotH;
            $points[] = round($x, 1) . ',' . round($y, 1);
        }

        return implode(' ', $points);
    }

    private static function renderTable(string $from, string $to): void
    {
        $perPopup = Stats::perPopup($from, $to);

        echo '<h2>' . esc_html__('Détail par popup', 'popup-spiral') . '</h2>';

        if ($perPopup === []) {
            echo '<p>' . esc_html__('Aucun événement sur cette période.', 'popup-spiral') . '</p>';
            return;
        }

        echo '<table class="widefat striped spiral-stats-table">';
        echo '<thead><tr>';
        echo '<th data-sort="text">' . esc_html__('Popup', 'popup-spiral') . '</th>';
        echo '<th data-sort="num">' . esc_html__('Vues', 'popup-spiral') . '</th>';
        echo '<th data-sort="num">' . esc_html__('Clics', 'popup-spiral') . '</th>';
        echo '<th data-sort="num">' . esc_html__('Taux de clic', 'popup-spiral') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($perPopup as $id => $row) {
            $title = get_the_title($id);
            $ctr = Stats::ctr($row['views'], $row['clicks']);

            echo '<tr>';
            echo '<td>' . esc_html($title !== '' ? $title : __('(sans titre)', 'popup-spiral')) . '</td>';
            echo '<td data-value="' . (int) $row['views'] . '">' . esc_html(number_format_i18n($row['views'])) . '</td>';
            echo '<td data-value="' . (int) $row['clicks'] . '">' . esc_html(number_format_i18n($row['clicks'])) . '</td>';
            echo '<td data-value="' . esc_attr((string) $ctr) . '">' . esc_html(number_format_i18n($ctr, 1)) . ' %</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    private static function renderSinceNote(): void
    {
        $since = get_option(Install::STATS_SINCE_OPTION);

        if (!$since) {
            return;
        }

        echo '<p class="description spiral-stats-since">';
        printf(
            /* translators: %s : date de début du suivi détaillé */
            esc_html__('Suivi détaillé par jour depuis le %s. Les totaux cumulés affichés dans la liste des popups peuvent inclure une activité antérieure à cette date, non détaillée ici.', 'popup-spiral'),
            esc_html($since)
        );
        echo '</p>';
    }

    private static function renderEmptyState(): void
    {
        echo '<div class="spiral-stats-empty">';
        echo '<p>' . esc_html__('Aucune statistique pour l\'instant.', 'popup-spiral') . '</p>';
        echo '<p class="description">' . esc_html__('Les vues et les clics s\'afficheront ici dès que vos popups seront vus par des visiteurs.', 'popup-spiral') . '</p>';
        echo '</div>';
    }

    /**
     * Styles et tri du tableau — inline, sans dépendance ni fichier séparé.
     */
    private static function renderInlineAssets(): void
    {
        ?>
        <style>
            .spiral-stats-filters { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; margin: 16px 0; }
            .spiral-stats-cards { display: flex; flex-wrap: wrap; gap: 16px; margin: 16px 0; }
            .spiral-stats-card { flex: 1 1 160px; background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px 20px; }
            .spiral-stats-card-value { display: block; font-size: 28px; font-weight: 700; line-height: 1.2; }
            .spiral-stats-card-label { display: block; color: #646970; margin-top: 4px; }
            .spiral-stats-chart { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 16px; margin: 16px 0; overflow-x: auto; }
            .spiral-stats-chart svg { width: 100%; height: auto; min-width: 480px; }
            .spiral-stats-legend { display: flex; gap: 20px; margin-bottom: 8px; font-size: 13px; }
            .spiral-stats-legend-item::before { content: ""; display: inline-block; width: 12px; height: 12px; border-radius: 2px; margin-right: 6px; vertical-align: middle; }
            .spiral-legend-views::before { background: #2271b1; }
            .spiral-legend-clicks::before { background: #16a34a; }
            .spiral-stats-table th[data-sort] { cursor: pointer; }
            .spiral-stats-table th[data-sort]::after { content: " \2195"; color: #a7aaad; }
            .spiral-stats-empty { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 40px; text-align: center; }
        </style>
        <script>
            (function () {
                var table = document.querySelector('.spiral-stats-table');
                if (!table) { return; }
                var headers = table.querySelectorAll('th[data-sort]');
                headers.forEach(function (th, index) {
                    th.addEventListener('click', function () {
                        var tbody = table.querySelector('tbody');
                        var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
                        var numeric = th.getAttribute('data-sort') === 'num';
                        var asc = th.getAttribute('data-asc') !== 'true';
                        rows.sort(function (a, b) {
                            var ca = a.children[index], cb = b.children[index];
                            if (numeric) {
                                return (parseFloat(cb.getAttribute('data-value')) - parseFloat(ca.getAttribute('data-value'))) * (asc ? -1 : 1);
                            }
                            return ca.textContent.localeCompare(cb.textContent) * (asc ? 1 : -1);
                        });
                        headers.forEach(function (other) { other.removeAttribute('data-asc'); });
                        th.setAttribute('data-asc', asc ? 'true' : 'false');
                        rows.forEach(function (row) { tbody.appendChild(row); });
                    });
                });
                var period = document.getElementById('spiral-stats-period');
                var custom = document.querySelector('.spiral-stats-custom');
                if (period && custom) {
                    period.addEventListener('change', function () {
                        if (period.value === 'custom') { custom.removeAttribute('hidden'); }
                        else { custom.setAttribute('hidden', ''); }
                    });
                }
            })();
        </script>
        <?php
    }
}
