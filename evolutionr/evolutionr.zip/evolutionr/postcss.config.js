/**
 * ════════════════════════════════════════════════════════════════════════════
 * 🎨 CONFIGURATION POSTCSS
 * ════════════════════════════════════════════════════════════════════════════
 * PostCSS traite votre CSS après compilation Sass
 */
export default {
  plugins: {
    /**
     * Autoprefixer : Ajoute automatiquement les préfixes CSS
     * Exemple : display: flex → display: -webkit-box; display: flex;
     * 
     * Liste des navigateurs cibles :
     * - last 2 versions : les 2 dernières versions de chaque navigateur
     * - > 1% : navigateurs utilisés par plus de 1% des utilisateurs
     * - not dead : exclut les navigateurs non maintenus
     */
    autoprefixer: {
      overrideBrowserslist: [
        'last 2 versions',
        '> 1%',
        'not dead',
        'not op_mini all',
      ],
    },
  },
}
