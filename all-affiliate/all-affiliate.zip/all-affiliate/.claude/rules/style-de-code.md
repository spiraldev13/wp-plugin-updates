# Règles de style de code

> Adapte ces règles aux conventions de ton projet. Supprime ce qui ne s'applique pas.

## Nommage

- Variables et fonctions : `camelCase`
- Classes et types : `PascalCase`
- Constantes : `MAJUSCULES_AVEC_UNDERSCORES`
- Fichiers : `kebab-case.ts` (ou adapter selon ton stack)

## Fonctions

- Préférer les fonctions petites à responsabilité unique
- Maximum ~40 lignes par fonction — découper si plus long
- Fonctions pures quand possible ; isoler les effets de bord

## Commentaires

- Les commentaires expliquent le *pourquoi*, pas le *quoi*
- Pas de code commenté dans les commits
- JSDoc / PHPDoc uniquement sur les méthodes d'API publique

## Imports

- [ex. Imports absolus uniquement, pas de `../../` relatif]
- [ex. Grouper : libs externes → modules internes → types]
- Supprimer les imports inutilisés — le mode strict les détecte de toute façon

## Gestion des erreurs

- Ne jamais ignorer silencieusement une erreur
- Utiliser le logger du projet, jamais `console.log`
- Messages d'erreur informatifs — ne jamais exposer les stack traces aux utilisateurs finaux
